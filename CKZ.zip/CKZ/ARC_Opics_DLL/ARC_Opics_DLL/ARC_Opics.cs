﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading;
using System.Data;
using System.Windows;
//using MODI;
//using System.Drawing;
using System.Windows.Forms;
using System.Drawing.Imaging;
using Excel = Microsoft.Office.Interop.Excel;
using System.Data.SqlClient;
using System.Collections;
using System.Runtime.InteropServices;
using System.IO;
using System.Drawing;
using Microsoft.Office.Interop.Word;
using iTextSharp.text.pdf;
using iTextSharp.text.pdf.parser;
using System.Diagnostics;
using System.Threading;
using System.Data.OleDb;
//using Microsoft.Office.Interop.Word;

namespace ARC_Opics_DLL
{
    public partial class ARC_Opics : Component
    {
        static System.Timers.Timer aTimer = new System.Timers.Timer();
        cls_KeybdEvents objclsfunopics = new cls_KeybdEvents();
        Cls_ImgCmp objclsImgCmp = new Cls_ImgCmp();
        clsIndiaClearing objIndiaClearing = new clsIndiaClearing();
        clsAvoidLock objAvoidLock = new clsAvoidLock();
        [DllImport("User32.dll", SetLastError = true)]
        static extern void SwitchToThisWindow(IntPtr hWnd, bool fAltTab);
        public ARC_Opics()
        {
            InitializeComponent();
        }
        public ARC_Opics(IContainer container)
        {
            container.Add(this);

            InitializeComponent();
        }
        public void delete(string filename)
        {
            if (System.IO.File.Exists(@"C:\test.txt" + filename))
            {
                System.IO.File.Delete(@"C:\test.txt" + filename);
            }
        }
        public void ctrlManage(int flag)
        {            
            if (flag == 1)
            {
                objclsfunopics.startprocess(300, 140, 20, 20, 2000, "ctrlPress", "");
            }
            else
            {
                objclsfunopics.startprocess(100, 100, 100, 20, 2000, "ctrlRelease", "");
            }

        }
        public bool IsExcelCreated(string fileName)
        {
            bool result = false;
            var processes = from p in Process.GetProcessesByName("wfica32")
                            select p;

            foreach (var process in processes)
            {
                //Microsoft Excel - INDO_ONL_REV_15022018.Prn - \\Remote
                if (process.MainWindowTitle.Contains("Microsoft Excel - " + fileName + ".Prn - \\\\Remote"))
                {
                    result = true;
                }
            }
            return result;
        }
        public System.Data.DataTable AddAutoIncrementColumn(System.Data.DataTable dt)
        {
            DataColumn ID = new DataColumn();
            ID.DataType = System.Type.GetType("System.Int32");
            ID.AutoIncrement = true;
            ID.AutoIncrementSeed = 0;
            ID.AutoIncrementStep = 1;
            ID.ColumnName = "ID";
            dt.Columns.Add(ID);
            int index = -1;
            foreach (DataRow row in dt.Rows)
            {
                row.SetField(ID, ++index);
            }
            return dt;
        }
        public void changeResolution(int screenWidth, int screenHeight)
        {
            ARC_Opics_DLL.Cls_Resolution.CResolution objCResolution = new ARC_Opics_DLL.Cls_Resolution.CResolution(screenWidth, screenHeight);
        }
        public void ScreenCapture(string path)
        {
            Bitmap bmpScreenshot;
            Graphics GLO_Screenshot;
            bmpScreenshot = new Bitmap(Screen.PrimaryScreen.Bounds.Width, Screen.PrimaryScreen.Bounds.Height, PixelFormat.Format32bppArgb);
            //Create a graphics object from the bitmap
            GLO_Screenshot = Graphics.FromImage(bmpScreenshot);
            GLO_Screenshot.CopyFromScreen(Screen.PrimaryScreen.Bounds.X, Screen.PrimaryScreen.Bounds.Y, 0, 0, Screen.PrimaryScreen.Bounds.Size, CopyPixelOperation.SourceCopy);
            bmpScreenshot.Save(path, System.Drawing.Imaging.ImageFormat.Jpeg);
            bmpScreenshot.Dispose();
        }
        public string ReadTextFromImage(string path)
        {
            string content = "";
            try
            {                
                //MODI.Document ModiObj = new MODI.Document();
                //ModiObj.Create(path);
                //ModiObj.OCR(MODI.MiLANGUAGES.miLANG_ENGLISH, true, true);
                //MODI.Image ModiImageObj = (MODI.Image)ModiObj.Images[0];
                //content = ModiImageObj.Layout.Text;
                //ModiObj.Close();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);

            }
            return content;
        }
        public bool check_text(int identity, string reconName)
        {
            string text = "";
            text = ReadTextFromImage(ReadTextFromImage(@"C:\" + reconName + "_ScreenShots\\SS_" + identity + ".JPG"));
            bool result = false;
            switch (identity)
            {
                case 1:  //              
                    if (text.Contains("Instruments") && text.Contains("Analytics") && text.Contains("Inquiries and Reports") && text.Contains("System Administration"))
                    {
                        result = true;
                        text = "";
                    }
                    break;
                case 2:  //          
                    if (text.Contains("View Data") && text.Contains("Draw Query") && text.Contains("Bun Query") && text.Contains("Clear"))
                    {
                        result = true;
                        text = "";
                    }
                    break;
                case 3:  //         
                    if (text.Contains("Home") && text.Contains("End") && text.Contains("PgUp") && text.Contains("PgDn"))
                    {
                        result = true;
                        text = "";
                    }
                    break;
                case 4:  //         
                    if (text.Contains("I c E F C H I J K") && text.Contains("1 2 3 4"))
                    {
                        result = true;
                        text = "";
                    }
                    break;
                default:
                    result = false;
                    break;
            }
            return result;
        }
        public void deleteFiles(string dirpath)
        {
            System.IO.DirectoryInfo di = new DirectoryInfo(dirpath);
            foreach (FileInfo file in di.GetFiles())
            {
                file.Delete();
            }
            foreach (DirectoryInfo dir in di.GetDirectories())
            {
                dir.Delete(true);
            }

        }
        public void transferfile_opics(string input, string output,string reconName)
        {
            string extn = "";
            if (reconName == "Sophis BTB")
            {
                extn = @"*.sqy";
            }
            else if (reconName == "Structured Funding  - BTS VS Custody")
            {
                extn = @"*.Prn";
            }
            else
            {
                extn = @"*.xls";
            }
            string[] CrystalFilePaths = Directory.GetFiles(input, extn);
            foreach (var filePath in CrystalFilePaths)
            {
                var FileName = Path.GetFileName(filePath);
                FileName = FileName.Replace("prn_", "");
                File.Move(filePath, output + FileName);
            }
        }
        public void transferfile_opics_prn(string input, string output, string reconName)
        {
            string extn = "";
            
            extn = @"*.Prn";
            
            string[] CrystalFilePaths = Directory.GetFiles(input, extn);
            foreach (var filePath in CrystalFilePaths)
            {
                var FileName = Path.GetFileName(filePath);
                FileName = FileName.Replace("prn_", "");
                File.Move(filePath, output + FileName);
            }
        }
        public bool opics_QueryRecons(string con, string reconName, string opicsRegion, string Country, string Date, string Downloadpath, out string ErrorMsg)
        {
            bool result = false;
            ErrorMsg = string.Empty;            
            string strQuery = string.Empty;
            string FileName = string.Empty;
            string Region = string.Empty;
            int Org_screenWidth = Screen.PrimaryScreen.Bounds.Width;
            int Org_screenHeight = Screen.PrimaryScreen.Bounds.Height;
            //changeResolution(1024, 768);
            Create_Directory(@"C:\ARC\");
            Create_Directory(@"C:\ARC\" + reconName);
            Create_Directory(@"C:\ARC\" + reconName + "_ScreenShots");
            deleteFiles(@"C:\ARC\" + reconName);            
            try
            {                
                int chck = FindNoOfOpenWindow();
                if (chck == 1)
                {
                    SqlConnection conn = new SqlConnection(con);
                    SqlCommand com = new SqlCommand();
                    conn.Open();
                    strQuery = "select * from  Arc_opics_query where recon='" + reconName + "' and opics_Region = '" + opicsRegion + "'";
                    com = new SqlCommand(strQuery, conn);
                    SqlDataAdapter da = new SqlDataAdapter(com);
                    System.Data.DataTable dt = new System.Data.DataTable();
                    da.Fill(dt);
                    conn.Close();
                    string Query = string.Empty;
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        FileName = dt.Rows[i]["File_Name"].ToString();
                        Region = dt.Rows[i]["Opics_Region"].ToString();
                        if (reconName == "FX Cash Position reconciliation - FEDS vs Opics")
                        {
                            string dtimefrm = Convert.ToDateTime(Date).ToString("dd.MM.yyyy");
                            FileName = FileName.Replace("DD.MM.YYYY", dtimefrm);
                            //FileName = FileName.Replace()
                        }
                        else
                        {
                            string dtimefrm1 = Convert.ToDateTime(Date).ToString("ddMMyyyy");
                            FileName = FileName.Replace("DDMMYYYY", dtimefrm1);
                        }
                        if (i == 0)
                        {
                            //---1
                            Thread.Sleep(10000);
                            //objclsfunopics.startprocess(14, 56, 100, 20, 3000, "Alt+Space+x", "");
                            //ScreenCapture(@"C:\" + reconName + "_ScreenShots\\SS_1.jpeg");
                            //if (!(check_text(1, reconName)))
                            //{
                            //    ErrorMsg = "Page not Found";
                            //    return false;
                            //}
                            objclsfunopics.startprocess(14, 56, 100, 20, 5000, "Alt+Space+X", "");
                            objclsfunopics.startprocess(25, 56, 100, 20, 2000, "Lclick", "");
                            Query = "GRSS";
                            objclsfunopics.startprocess(25, 56, 100, 20, 7000, "Passvalue", Query);
                            //MessageBox.Show(Query);
                            Query = "";
                            objclsfunopics.startprocess(110, 57, 100, 20, 4000, "Lclick", "");
                            objclsfunopics.startprocess(14, 56, 100, 20, 5000, "Alt+Space+X", "");
                            //---2
                            //ScreenCapture(@"C:\" + reconName + "_ScreenShots\\SS_2.jpeg");
                            //if (!(check_text(2, reconName)))
                            //{
                            //    ErrorMsg = "Page not Found";
                            //    return false;
                            //}
                            objclsfunopics.startprocess(130, 80, 100, 20, 4000, "Lclick", "");
                            objclsfunopics.startprocess(321, 193, 100, 20, 4000, "Lclick", "");
                            Query = dt.Rows[i]["Query"].ToString();
                            if (Query.Contains(":ReconDate"))
                            {
                                Query = Query.Replace(":ReconDate", Date);
                            }
                            objclsfunopics.startprocess(321, 193, 100, 20, 4000, "Passvalue", Query);
                            Query = "";
                            if (FileName.Contains("US_FMO_TXN"))
                            {
                                objclsfunopics.startprocess(48, 79, 100, 20, 20000, "Lclick", "");
                            }
                            else if (FileName.Contains("INDO_ONL"))
                            {
                                objclsfunopics.startprocess(48, 79, 100, 20, 20000, "Lclick", "");
                            }
                            else
                            {
                                objclsfunopics.startprocess(48, 79, 100, 20, 6000, "Lclick", "");
                            }
                            //ScreenCapture(@"C:\" + reconName + "_ScreenShots\\SS_3.jpeg");
                            //if (!(check_text(3, reconName)))
                            //{
                            //    ErrorMsg = "Page not Found";
                            //    return false;
                            //}
                            if (FileName.Contains("US_FMO_TXN"))
                            {
                                objclsfunopics.startprocess(14, 56, 100, 20, 5000, "Alt+Space+X", "");
                                objclsfunopics.startprocess(764, 161, 100, 20, 30000, "Alt+X+E", "");
                            }
                            else
                            {
                                objclsfunopics.startprocess(14, 56, 100, 20, 5000, "Alt+Space+X", "");
                                objclsfunopics.startprocess(764, 161, 100, 20, 7000, "Alt+X+E", "");
                            }
                            Query = @"V:\ARC\" + reconName + "\\" + FileName;
                            objclsfunopics.startprocess(203, 337, 100, 20, 7000, "Passvalue", Query);
                            //bala
                            //objclsfunopics.startprocess(203, 337, 100, 20, 7000, "Passvalue", FileName);
                            //bala
                            Query = "";
                            objclsfunopics.startprocess(203, 337, 100, 20, 90000, "2Tab+Enter", "");
                            objclsfunopics.startprocess(650, 28, 100, 20, 4000, "Lclick", "");
                            //ScreenCapture(@"C:\" + reconName + "_ScreenShots\\SS_4.jpeg");
                            //if (!(check_text(4, reconName)))
                            //{
                            //    ErrorMsg = "Page not Found";
                            //    return false;
                            //}
                            objclsfunopics.startprocess(650, 28, 100, 20, 4000, "Alt+F+X+N", "");
                            //bala
                            //objclsfunopics.startprocess(764, 161, 100, 20, 7000, "Alt+X+E", "");
                            //objclsfunopics.startprocess(764, 161, 100, 20, 7000, "6 tab, Space, ctrl+c,tab - local path, 6tab,space,ctrl+v,4tab,Enter,alt+q", "");
                            //bala
                            objclsfunopics.startprocess(20, 30, 100, 20, 4000, "Alt+Q", "");
                            if (dt.Rows.Count == 1)
                            {
                                objclsfunopics.startprocess(37, 32, 100, 20, 4000, "Lclick", "");
                                objclsfunopics.startprocess(71, 73, 100, 20, 4000, "Lclick", "");
                            }
                        }
                        else if (i == dt.Rows.Count - 1)
                        {
                            //---2
                            //ScreenCapture(@"C:\" + reconName + "_ScreenShots\\SS_2.jpeg");
                            //if (!(check_text(2, reconName)))
                            //{
                            //    ErrorMsg = "Page not Found";
                            //    return false;
                            //}
                            objclsfunopics.startprocess(130, 80, 100, 20, 4000, "Lclick", "");
                            objclsfunopics.startprocess(321, 193, 100, 20, 4000, "Lclick", "");
                            Query = dt.Rows[i]["Query"].ToString();
                            if (Query.Contains(":ReconDate"))
                            {
                                Query = Query.Replace(":ReconDate", Date);
                            }
                            objclsfunopics.startprocess(321, 193, 100, 20, 4000, "Passvalue", Query);
                            Query = "";
                            if (FileName.Contains("US_FMO_TXN"))
                            {
                                objclsfunopics.startprocess(48, 79, 100, 20, 20000, "Lclick", "");
                            }
                            else if (FileName.Contains("INDO_ONL"))
                            {
                                objclsfunopics.startprocess(48, 79, 100, 20, 20000, "Lclick", "");
                            }
                            else
                            {
                                objclsfunopics.startprocess(48, 79, 100, 20, 6000, "Lclick", "");
                            }
                            //ScreenCapture(@"C:\" + reconName + "_ScreenShots\\SS_3.jpeg");
                            //if (!(check_text(3, reconName)))
                            //{
                            //    ErrorMsg = "Page not Found";
                            //    return false;
                            //}
                            if (FileName.Contains("US_FMO_TXN"))
                            {
                                objclsfunopics.startprocess(14, 56, 100, 20, 5000, "Alt+Space+X", "");
                                objclsfunopics.startprocess(764, 161, 100, 20, 30000, "Alt+X+E", "");
                            }
                            else
                            {
                                objclsfunopics.startprocess(14, 56, 100, 20, 5000, "Alt+Space+X", "");
                                objclsfunopics.startprocess(764, 161, 100, 20, 7000, "Alt+X+E", "");
                            }
                            Query = @"V:\ARC\" + reconName + "\\" + FileName;
                            objclsfunopics.startprocess(203, 337, 100, 20, 7000, "Passvalue", Query);
                            Query = "";
                            objclsfunopics.startprocess(203, 337, 100, 20, 90000, "2Tab+Enter", "");
                            objclsfunopics.startprocess(650, 28, 100, 20, 4000, "Lclick", "");
                            //ScreenCapture(@"C:\" + reconName + "_ScreenShots\\SS_4.jpeg");
                            //if (!(check_text(4, reconName)))
                            //{
                            //    ErrorMsg = "Page not Found";
                            //    return false;
                            //}
                            objclsfunopics.startprocess(650, 28, 100, 20, 4000, "Alt+F+X+N", "");
                            objclsfunopics.startprocess(20, 30, 100, 20, 4000, "Alt+Q", "");
                            objclsfunopics.startprocess(37, 32, 100, 20, 4000, "Lclick", "");
                            objclsfunopics.startprocess(71, 73, 100, 20, 4000, "Lclick", "");
                        }
                        else if (i > 0)
                        {
                            //---2
                            //ScreenCapture(@"C:\" + reconName + "_ScreenShots\\SS_2.jpeg");
                            //if (!(check_text(2, reconName)))
                            //{
                            //    ErrorMsg = "Page not Found";
                            //    return false;
                            //}
                            objclsfunopics.startprocess(130, 80, 100, 20, 4000, "Lclick", "");
                            objclsfunopics.startprocess(321, 193, 100, 20, 4000, "Lclick", "");
                            Query = dt.Rows[i]["Query"].ToString();
                            if (Query.Contains(":ReconDate"))
                            {
                                Query = Query.Replace(":ReconDate", Date);
                            }
                            objclsfunopics.startprocess(321, 193, 100, 20, 4000, "Passvalue", Query);
                            Query = "";
                            if (FileName.Contains("US_FMO_TXN"))
                            {
                                objclsfunopics.startprocess(48, 79, 100, 20, 20000, "Lclick", "");
                            }
                            else if (FileName.Contains("INDO_ONL"))
                            {
                                objclsfunopics.startprocess(48, 79, 100, 20, 20000, "Lclick", "");
                            }
                            else
                            {
                                objclsfunopics.startprocess(48, 79, 100, 20, 6000, "Lclick", "");
                            }
                            //ScreenCapture(@"C:\" + reconName + "_ScreenShots\\SS_3.jpeg");
                            //if (!(check_text(3, reconName)))
                            //{
                            //    ErrorMsg = "Page not Found";
                            //    return false;
                            //}
                            if (FileName.Contains("US_FMO_TXN"))
                            {
                                objclsfunopics.startprocess(14, 56, 100, 20, 5000, "Alt+Space+X", "");
                                objclsfunopics.startprocess(764, 161, 100, 20, 30000, "Alt+X+E", "");
                            }
                            else
                            {
                                objclsfunopics.startprocess(14, 56, 100, 20, 5000, "Alt+Space+X", "");
                                objclsfunopics.startprocess(764, 161, 100, 20, 7000, "Alt+X+E", "");
                            }
                            Query = @"V:\ARC\" + reconName + "\\" + FileName;
                            objclsfunopics.startprocess(203, 337, 100, 20, 7000, "Passvalue", Query);
                            Query = "";
                            objclsfunopics.startprocess(203, 337, 100, 20, 90000, "2Tab+Enter", "");
                            objclsfunopics.startprocess(650, 28, 100, 20, 4000, "Lclick", "");
                            //ScreenCapture(@"C:\" + reconName + "_ScreenShots\\SS_4.jpeg");
                            //if (!(check_text(4, reconName)))
                            //{
                            //    ErrorMsg = "Page not Found";
                            //    return false;
                            //}
                            objclsfunopics.startprocess(650, 28, 100, 20, 4000, "Alt+F+X+N", "");
                            objclsfunopics.startprocess(20, 30, 100, 20, 4000, "Alt+Q", "");
                        }
                    }
                    //                
                    string dtime = DateTime.Now.ToString("dd-MMM-yyyy");
                    Downloadpath = Downloadpath + dtime + "_Files" + "\\Input\\" + Region + "\\";
                    //MessageBox.Show(Region);
                    transferfile_opics(@"C:\ARC\" + reconName + "\\", Downloadpath, reconName);
                }
                result = true;
            }
            catch (Exception ex)
            {
                ErrorMsg = ex.ToString();
            }
            changeResolution(Org_screenWidth, Org_screenHeight);
            return result;
            
        }
        public bool opics_Recons(string con, string reconName, string opicsRegion, string Country, string Date, string Downloadpath, string userid, out string ErrorMsg)
        {            
            bool result = false;
            ErrorMsg = string.Empty;
            string strQuery = string.Empty;
            string FileName = string.Empty;
            string Region = string.Empty;
            int Org_screenWidth = Screen.PrimaryScreen.Bounds.Width;
            int Org_screenHeight = Screen.PrimaryScreen.Bounds.Height;
            //changeResolution(1024, 768);
            Create_Directory(@"C:\ARC\");
            Create_Directory(@"C:\ARC\" + reconName);
            Create_Directory(@"C:\ARC\" + reconName + "_ScreenShots");
            deleteFiles(@"C:\ARC\" + reconName);
            try
            {
                int chck = FindNoOfOpenWindow();
                if (chck == 1)
                {
                    SqlConnection conn = new SqlConnection(con);
                    SqlCommand com = new SqlCommand();
                    conn.Open();
                    strQuery = "select * from  Arc_opics_query where recon='" + reconName + "' and opics_Region = '" + opicsRegion + "'";
                    com = new SqlCommand(strQuery, conn);
                    SqlDataAdapter da = new SqlDataAdapter(com);
                    System.Data.DataTable dt = new System.Data.DataTable();
                    da.Fill(dt);
                    conn.Close();
                    string shortName = "";
                    string Query = string.Empty;
                    int noofTab = 0;
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        FileName = dt.Rows[i]["File_Name"].ToString();
                        Region = dt.Rows[i]["Opics_Region"].ToString();                        
                        if (reconName == "Structured Finance Position Monthly")
                        {
                            string MMM = Convert.ToDateTime(Date).ToString("MMM");
                            string YYYY = Convert.ToDateTime(Date).ToString("yyyy");
                            FileName = FileName.Replace("MMM", MMM);
                            FileName = FileName.Replace("YYYY", YYYY);
                        }
                        else
                        {
                            string dtimefrm1 = Convert.ToDateTime(Date).ToString("ddMMyyyy");
                            FileName = FileName.Replace("DDMMYYYY", dtimefrm1);
                        }
                        
                        shortName = FileName.Substring(0, 2);
                        if (i == 0)
                        {                            
                            Thread.Sleep(10000);                            
                            objclsfunopics.startprocess(14, 56, 100, 20, 5000, "Alt+Space+X", "");
                            objclsfunopics.startprocess(25, 56, 100, 20, 2000, "Lclick", "");
                            Query = "GRSS";
                            objclsfunopics.startprocess(25, 56, 100, 20, 7000, "Passvalue", Query);                            
                            Query = "";
                            objclsfunopics.startprocess(110, 57, 100, 20, 4000, "Lclick", "");
                            objclsfunopics.startprocess(14, 56, 100, 20, 5000, "Alt+Space+X", "");                            
                            objclsfunopics.startprocess(130, 80, 100, 20, 4000, "Lclick", "");
                            objclsfunopics.startprocess(321, 193, 100, 20, 4000, "Lclick", "");
                            Query = dt.Rows[i]["Query"].ToString();
                            if (Query.Contains(":ReconDate"))
                            {
                                Query = Query.Replace(":ReconDate", Date);
                            }
                            objclsfunopics.startprocess(321, 193, 100, 20, 4000, "Passvalue", Query);
                            Query = "";
                            objclsfunopics.startprocess(48, 79, 100, 20, 12000, "Lclick", "");
                            objclsfunopics.startprocess(14, 56, 100, 20, 5000, "Alt+Space+X", "");
                            //
                            objclsfunopics.startprocess(764, 161, 100, 20, 7000, "Alt+X+E", "");
                            noofTab = 6;
                            objclsfunopics.startprocess(203, 337, 100, 20, 7000, "Passvalue", "Dummyexcel");
                            Query = "";
                            for (int j = 0; j < 10; j++)
                            {
                                objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Tab", "");
                            }
                            objclsfunopics.startprocess(146, 126, 100, 20, 2000, "Enter", "");                            
                            for (int j = 0; j < 10; j++)
                            {
                                if (IsExcelCreated("Dummyexcel"))
                                {
                                    //newly added
                                    objclsfunopics.startprocess(14, 56, 100, 20, 5000, "Alt+Space+X", "");
                                    noofTab = 7;
                                    break;
                                }
                                Thread.Sleep(10000);
                            }
                            objclsfunopics.startprocess(650, 28, 100, 20, 4000, "Lclick", "");
                            objclsfunopics.startprocess(650, 28, 100, 20, 4000, "Alt+F+X+N", "");
                            //
                            objclsfunopics.startprocess(764, 161, 100, 20, 7000, "Alt+X+E", "");
                            if (noofTab == 6)
                            {
                                Query = FileName;
                            }
                            else
                            {
                                Query = FileName;
                                //if (Region == "OpicsPlus" || Region == "OpicsReg")
                                //{
                                //    Query = @"D:\opxcom\" + userid + "\\" + FileName;
                                //}
                                //else if (Region == "OpicsPVB")
                                //{
                                //    Query = @"C:\opxcom\" + userid + "\\" + FileName;
                                //}
                            }
                            objclsfunopics.startprocess(203, 337, 100, 20, 7000, "Passvalue", Query);
                            Query = "";                                                                                    
                            objclsfunopics.startprocess(203, 337, 100, 20, 10000, "2Tab+Enter", "");
                            
                            for (int j = 0; j < 10; j++)
                            {
                                if (IsExcelCreated(FileName))
                                {
                                    objclsfunopics.startprocess(14, 56, 100, 20, 5000, "Alt+Space+X", "");
                                    break;                                    
                                }
                                Thread.Sleep(10000);
                            }
                            objclsfunopics.startprocess(650, 28, 100, 20, 4000, "Lclick", "");                            
                            objclsfunopics.startprocess(650, 28, 100, 20, 4000, "Alt+F+X+N", "");

                            objclsfunopics.startprocess(764, 161, 100, 20, 7000, "Alt+X+E", "");
                            //int noofTab = 0;
                            //Clipboard.SetText("Nothing");
                            //for (int j = 0; j< 7; j++)
                            //{
                            //    objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Tab", "");
                            //}
                            //objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Copy", "");

                            //if (Clipboard.GetText() == "Nothing")
                            //{
                            //    noofTab = 7;
                            //    objclsfunopics.startprocess(764, 161, 100, 20, 2000, "Tab", "");
                            //}
                            //else
                            //{
                            //    noofTab = 6;
                            //}                            
                            for (int j = 0; j < noofTab; j++)
                            {
                                objclsfunopics.startprocess(764, 161, 100, 20, 2000, "Tab", "");
                            }
                            objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Space", "");                                                        
                            objclsfunopics.startprocess(203, 337, 100, 20, 1000, "Passvalue", shortName);
                            objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Cut", "");
                            objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Tab", "");
                            
                            Query = @"V:\ARC\" + reconName + "\\";
                            objclsfunopics.startprocess(203, 337, 100, 20, 2000, "Passvalue", Query);
                            Query = "";                            
                            objclsfunopics.startprocess(146, 126, 100, 20, 1000, "Enter", "");
                            for (int j = 0; j < noofTab; j++)
                            {
                                objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Tab", "");
                            }
                            Thread.Sleep(2000);
                            objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Space", "");
                            objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Paste", "");
                            for (int m = 0; m < 10; m++)
                            {
                                Thread.Sleep(5000);
                            }
                            for (int y = 0; y < 4; y++)
                            {
                                objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Tab", "");
                            }
                            objclsfunopics.startprocess(146, 126, 100, 20, 1000, "Enter", "");
                            objclsfunopics.startprocess(20, 30, 100, 20, 4000, "Alt+Q", "");
                            if (dt.Rows.Count == 1)
                            {
                                objclsfunopics.startprocess(37, 32, 100, 20, 4000, "Lclick", "");
                                objclsfunopics.startprocess(71, 73, 100, 20, 4000, "Lclick", "");
                            }
                        }
                        else if (i == dt.Rows.Count - 1)
                        {                            
                            objclsfunopics.startprocess(130, 80, 100, 20, 4000, "Lclick", "");
                            objclsfunopics.startprocess(321, 193, 100, 20, 4000, "Lclick", "");
                            Query = dt.Rows[i]["Query"].ToString();
                            if (Query.Contains(":ReconDate"))
                            {
                                Query = Query.Replace(":ReconDate", Date);
                            }
                            objclsfunopics.startprocess(321, 193, 100, 20, 4000, "Passvalue", Query);
                            Query = "";
                            objclsfunopics.startprocess(48, 79, 100, 20, 12000, "Lclick", "");
                            if (FileName.Contains("US_FMO_TXN"))
                            {
                                Thread.Sleep(15000);
                            }
                            objclsfunopics.startprocess(14, 56, 100, 20, 5000, "Alt+Space+X", "");                            
                            objclsfunopics.startprocess(764, 161, 100, 20, 7000, "Alt+X+E", "");
                            if (noofTab == 6)
                            {
                                Query = FileName;
                            }
                            else
                            {
                                Query = FileName;
                                //if (Region == "OpicsPlus" || Region == "OpicsReg")
                                //{
                                //    Query = @"D:\opxcom\" + userid + "\\" + FileName;
                                //}
                                //else if (Region == "OpicsPVB")
                                //{
                                //    Query = @"C:\opxcom\" + userid + "\\" + FileName;
                                //}
                            }
                            objclsfunopics.startprocess(203, 337, 100, 20, 7000, "Passvalue", Query);
                            Query = "";                                                                                    
                            objclsfunopics.startprocess(203, 337, 100, 20, 10000, "2Tab+Enter", "");
                            
                            for (int j = 0; j < 10; j++)
                            {
                                if (IsExcelCreated(FileName))
                                {                                    
                                    break;                                    
                                }
                                Thread.Sleep(10000);
                            }
                            objclsfunopics.startprocess(650, 28, 100, 20, 4000, "Lclick", "");                            
                            objclsfunopics.startprocess(650, 28, 100, 20, 4000, "Alt+F+X+N", "");

                            objclsfunopics.startprocess(764, 161, 100, 20, 7000, "Alt+X+E", "");
                            //int noofTab = 0;
                            //Clipboard.SetText("Nothing");
                            //for (int j = 0; j< 7; j++)
                            //{
                            //    objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Tab", "");
                            //}
                            //objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Copy", "");

                            //if (Clipboard.GetText() == "Nothing")
                            //{
                            //    noofTab = 7;
                            //    objclsfunopics.startprocess(764, 161, 100, 20, 2000, "Tab", "");
                            //}
                            //else
                            //{
                            //    noofTab = 6;
                            //}
                            for (int j = 0; j < noofTab; j++)
                            {
                                objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Tab", "");
                            }
                            objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Space", "");                                                        
                            objclsfunopics.startprocess(203, 337, 100, 20, 1000, "Passvalue", shortName);
                            objclsfunopics.startprocess(764, 161, 100, 20, 2000, "Cut", "");
                            objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Tab", "");
                            
                            Query = @"V:\ARC\" + reconName + "\\";
                            objclsfunopics.startprocess(203, 337, 100, 20, 2000, "Passvalue", Query);
                            Query = "";                            
                            objclsfunopics.startprocess(146, 126, 100, 20, 1000, "Enter", "");
                            for (int j = 0; j < noofTab; j++)
                            {
                                objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Tab", "");
                            }
                            Thread.Sleep(2000);
                            objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Space", "");
                            objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Paste", "");
                            for (int m = 0; m < 10; m++)
                            {
                                Thread.Sleep(5000);
                            }
                            for (int y = 0; y < 4; y++)
                            {
                                objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Tab", "");
                            }
                            objclsfunopics.startprocess(146, 126, 100, 20, 1000, "Enter", "");
                            objclsfunopics.startprocess(20, 30, 100, 20, 4000, "Alt+Q", "");
                            objclsfunopics.startprocess(37, 32, 100, 20, 4000, "Lclick", "");
                            objclsfunopics.startprocess(71, 73, 100, 20, 4000, "Lclick", "");
                        }
                        else if (i > 0)
                        {                            
                            objclsfunopics.startprocess(130, 80, 100, 20, 4000, "Lclick", "");
                            objclsfunopics.startprocess(321, 193, 100, 20, 4000, "Lclick", "");
                            Query = dt.Rows[i]["Query"].ToString();
                            if (Query.Contains(":ReconDate"))
                            {
                                Query = Query.Replace(":ReconDate", Date);
                            }
                            objclsfunopics.startprocess(321, 193, 100, 20, 4000, "Passvalue", Query);
                            Query = "";
                            objclsfunopics.startprocess(48, 79, 100, 20, 12000, "Lclick", "");
                            if (FileName.Contains("US_FMO_TXN"))
                            {
                                Thread.Sleep(15000);
                            }
                            objclsfunopics.startprocess(14, 56, 100, 20, 5000, "Alt+Space+X", "");                            
                            objclsfunopics.startprocess(764, 161, 100, 20, 7000, "Alt+X+E", "");
                            if (noofTab == 6)
                            {
                                Query = FileName;
                            }
                            else
                            {
                                Query = FileName;
                                //if (Region == "OpicsPlus" || Region == "OpicsReg")
                                //{
                                //    Query = @"D:\opxcom\" + userid + "\\" + FileName;
                                //}
                                //else if (Region == "OpicsPVB")
                                //{
                                //    Query = @"C:\opxcom\" + userid + "\\" + FileName;
                                //}
                            }
                            objclsfunopics.startprocess(203, 337, 100, 20, 7000, "Passvalue", Query);
                            Query = "";                                                                                    
                            objclsfunopics.startprocess(203, 337, 100, 20, 10000, "2Tab+Enter", "");
                            
                            for (int j = 0; j < 10; j++)
                            {
                                if (IsExcelCreated(FileName))
                                {                                    
                                    break;                                    
                                }
                                Thread.Sleep(10000);
                            }
                            objclsfunopics.startprocess(650, 28, 100, 20, 4000, "Lclick", "");                            
                            objclsfunopics.startprocess(650, 28, 100, 20, 4000, "Alt+F+X+N", "");

                            objclsfunopics.startprocess(764, 161, 100, 20, 7000, "Alt+X+E", "");
                            //int noofTab = 0;
                            //Clipboard.SetText("Nothing");
                            //for (int j = 0; j< 7; j++)
                            //{
                            //    objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Tab", "");
                            //}
                            //objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Copy", "");

                            //if (Clipboard.GetText() == "Nothing")
                            //{
                            //    noofTab = 7;
                            //    objclsfunopics.startprocess(764, 161, 100, 20, 2000, "Tab", "");
                            //}
                            //else
                            //{
                            //    noofTab = 6;
                            //}
                            for (int j = 0; j < noofTab; j++)
                            {
                                objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Tab", "");
                            }
                            objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Space", "");                                                        
                            objclsfunopics.startprocess(203, 337, 100, 20, 1000, "Passvalue", shortName);
                            objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Cut", "");
                            objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Tab", "");
                            
                            Query = @"V:\ARC\" + reconName + "\\";
                            objclsfunopics.startprocess(203, 337, 100, 20, 2000, "Passvalue", Query);
                            Query = "";                            
                            objclsfunopics.startprocess(146, 126, 100, 20, 3000, "Enter", "");                                                        
                            for (int j = 0; j < noofTab; j++)
                            {
                                objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Tab", "");
                            }
                            Thread.Sleep(2000);
                            objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Space", "");
                            objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Paste", "");
                            for (int m = 0; m < 10; m++)
                            {
                                Thread.Sleep(5000);
                            }
                            for (int y = 0; y < 4; y++)
                            {
                                objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Tab", "");
                            }
                            objclsfunopics.startprocess(146, 126, 100, 20, 1000, "Enter", "");
                            objclsfunopics.startprocess(20, 30, 100, 20, 4000, "Alt+Q", "");
                        }
                    }
                    //                
                    string dtime = DateTime.Now.ToString("dd-MMM-yyyy");
                    Downloadpath = Downloadpath + dtime + "_Files" + "\\Input\\" + Region + "\\";
                    //MessageBox.Show(Region);
                    transferfile_opics(@"C:\ARC\" + reconName + "\\", Downloadpath, reconName);
                }
                result = true;
            }
            catch (Exception ex)
            {
                ErrorMsg = ex.ToString();
            }
            changeResolution(Org_screenWidth, Org_screenHeight);
            return result;

        }
        public string getBranchNo(string country)
        {
            string BranchNo = string.Empty;            
            switch (country)
            {
                case "Zimbabwe":
                    BranchNo = "33";
                    break;
                case "Zambia":
                    BranchNo = "52";
                    break;
                case "UGANDA":
                    BranchNo = "51";
                    break;
                case "TANZANIA":
                    BranchNo = "50";
                    break;
                case "SIERRA LEONE":
                    BranchNo = "81";
                    break;
                case "NIGERIA":
                    BranchNo = "82";
                    break;
                case "Kenya":
                    BranchNo = "39";
                    break;
                case "Ghana":
                    BranchNo = "35";
                    break;
                case "GAMBIA":
                    BranchNo = "80";
                    break;
                case "Cote Divore":
                    BranchNo = "36";
                    break;
                case "CAMEROON":
                    BranchNo = "83";
                    break;
                case "Botswana":
                    BranchNo = "53";
                    break;
                case "ANGOLA":
                    BranchNo = "76";
                    break;
                case "IRAQ":
                    BranchNo = "74";
                    break;
                case "Srilanka":
                    BranchNo = "84";
                    break;
                case "DIFC":
                    BranchNo = "45";
                    break;
                case "JORDAN":
                    BranchNo = "96";
                    break;
                case "OMAN":
                    BranchNo = "50";
                    break;
                case "QATAR":
                    BranchNo = "54";
                    break;
                case "UAE":
                    BranchNo = "51";
                    break;
                case "BAHRAINDBU":
                    BranchNo = "55";
                    break;
                case "BAHRAINOBU":
                    BranchNo = "56";
                    break;

            }
            return BranchNo;
        }
        public bool opics_Recons_FX(int tabcount_in, string con, string reconName, string opicsRegion, string Country, string Date, string Downloadpath, string userid, out int tabcount_out, out string ErrorMsg)
        {
            bool result = false;
            ErrorMsg = string.Empty;
            string strQuery = string.Empty;
            string FileName = string.Empty;
            string Region = string.Empty;
            string SDate = string.Empty;
            string EDate = string.Empty;
            string BranchNo = string.Empty;
            tabcount_out = 0;
            if (DateTime.Now.ToString("ddd").ToLower() == "mon" || DateTime.Now.ToString("ddd").ToLower() == "tue" || DateTime.Now.ToString("ddd").ToLower() == "wed")
            {
                SDate = DateTime.Now.AddDays(-5).ToString("ddMMMyyyy");
            }            
            else
            {
                SDate = DateTime.Now.AddDays(-3).ToString("ddMMMyyyy");
            }

            if (DateTime.Now.ToString("ddd").ToLower() == "fri" || DateTime.Now.ToString("ddd").ToLower() == "thu" || DateTime.Now.ToString("ddd").ToLower() == "wed")
            {
                EDate = DateTime.Now.AddDays(5).ToString("ddMMMyyyy");
            }
            else
            {
                EDate = DateTime.Now.AddDays(3).ToString("ddMMMyyyy");
            }

            BranchNo = getBranchNo(Country);

            //changeResolution(1024, 768);
            Create_Directory(@"C:\ARC\");
            Create_Directory(@"C:\ARC\" + reconName);
            Create_Directory(@"C:\ARC\" + reconName + "_ScreenShots");
            deleteFiles(@"C:\ARC\" + reconName);
            try
            {
                int chck = FindNoOfOpenWindow();
                if (chck == 1)
                {
                    SqlConnection conn = new SqlConnection(con);
                    SqlCommand com = new SqlCommand();
                    conn.Open();
                    strQuery = "select * from  Arc_opics_query where recon='" + reconName + "' and opics_Region = '" + opicsRegion + "'";
                    com = new SqlCommand(strQuery, conn);
                    SqlDataAdapter da = new SqlDataAdapter(com);
                    System.Data.DataTable dt = new System.Data.DataTable();
                    da.Fill(dt);
                    conn.Close();
                    string shortName = "";
                    string Query = string.Empty;
                    int noofTab = 0;
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        FileName = dt.Rows[i]["File_Name"].ToString();
                        FileName = "prn_" + FileName;
                        Region = dt.Rows[i]["Opics_Region"].ToString();
                        if (reconName == "Structured Finance Position Monthly")
                        {
                            string MMM = Convert.ToDateTime(Date).ToString("MMM");
                            string YYYY = Convert.ToDateTime(Date).ToString("yyyy");
                            FileName = FileName.Replace("MMM", MMM);
                            FileName = FileName.Replace("YYYY", YYYY);
                        }
                        else
                        {
                            string dtimefrm1 = Convert.ToDateTime(Date).ToString("ddMMyyyy");
                            FileName = FileName.Replace("DDMMYYYY", dtimefrm1);
                        }

                        shortName = FileName.Substring(0, 2);
                        if (i == 0)
                        {
                            Thread.Sleep(10000);
                            objclsfunopics.startprocess(14, 56, 100, 20, 5000, "Alt+Space+X", "");
                            objclsfunopics.startprocess(25, 56, 100, 20, 2000, "Lclick", "");
                            Query = "GRSS";
                            objclsfunopics.startprocess(25, 56, 100, 20, 7000, "Passvalue", Query);
                            Query = "";
                            objclsfunopics.startprocess(110, 57, 100, 20, 4000, "Lclick", "");
                            objclsfunopics.startprocess(14, 56, 100, 20, 5000, "Alt+Space+X", "");
                            objclsfunopics.startprocess(130, 80, 100, 20, 4000, "Lclick", "");                            
                            Query = dt.Rows[i]["Query"].ToString();
                            if (Query.Contains(":SReconDate") || Query.Contains(":EReconDate") || Query.Contains(":BRANCH"))
                            {
                                Query = Query.Replace(":SReconDate", SDate);
                                Query = Query.Replace(":EReconDate", EDate);
                                Query = Query.Replace(":BRANCH", BranchNo);
                            }
                            objclsfunopics.startprocess(14, 56, 100, 20, 3000, "Alt+T+N", "");                            
                            objclsfunopics.startprocess(321, 193, 100, 20, 4000, "Passvalue", Query);                            
                            objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Select", "");
                            objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Copy", "");
                            objclsfunopics.startprocess(14, 56, 100, 20, 3000, "Alt+F+X+N", "");  
                            Query = "";
                            objclsfunopics.startprocess(321, 193, 100, 20, 4000, "Lclick", "");
                            objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Paste", "");
                            objclsfunopics.startprocess(48, 79, 100, 20, 12000, "Lclick", "");
                            objclsfunopics.startprocess(14, 56, 100, 20, 5000, "Alt+Space+X", "");
                            if (tabcount_in == 0)
                            {
                                //
                                objclsfunopics.startprocess(764, 161, 100, 20, 7000, "Alt+X+E", "");
                                noofTab = 6;
                                tabcount_out = 6;
                                objclsfunopics.startprocess(203, 337, 100, 20, 7000, "Passvalue", "Dummyexcel");
                                Query = "";
                                for (int j = 0; j < 10; j++)
                                {
                                    objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Tab", "");
                                }
                                objclsfunopics.startprocess(146, 126, 100, 20, 2000, "Enter", "");
                                for (int j = 0; j < 10; j++)
                                {
                                    if (IsExcelCreated("Dummyexcel"))
                                    {
                                        //newly added
                                        objclsfunopics.startprocess(14, 56, 100, 20, 5000, "Alt+Space+X", "");
                                        noofTab = 7;
                                        tabcount_out = 7;
                                        break;
                                    }
                                    Thread.Sleep(5000);
                                }
                                objclsfunopics.startprocess(650, 28, 100, 20, 4000, "Lclick", "");
                                objclsfunopics.startprocess(650, 28, 100, 20, 4000, "Alt+F+X+N", "");
                                //
                            }
                            else
                            {
                                noofTab = tabcount_in;
                                tabcount_out = tabcount_in;
                            }
                            objclsfunopics.startprocess(764, 161, 100, 20, 7000, "Alt+X+E", "");
                            if (noofTab == 6)
                            {
                                Query = FileName;
                            }
                            else
                            {
                                Query = FileName;
                                //if (Region == "OpicsPlus" || Region == "OpicsReg")
                                //{
                                //    Query = @"D:\opxcom\" + userid + "\\" + FileName;
                                //}
                                //else if (Region == "OpicsPVB")
                                //{
                                //    Query = @"C:\opxcom\" + userid + "\\" + FileName;
                                //}
                            }
                            objclsfunopics.startprocess(203, 337, 100, 20, 7000, "Passvalue", Query);
                            Query = "";
                            objclsfunopics.startprocess(203, 337, 100, 20, 10000, "2Tab+Enter", "");

                            for (int j = 0; j < 10; j++)
                            {
                                if (IsExcelCreated(FileName))
                                {
                                    objclsfunopics.startprocess(14, 56, 100, 20, 5000, "Alt+Space+X", "");
                                    break;
                                }
                                Thread.Sleep(5000);
                            }
                            objclsfunopics.startprocess(650, 28, 100, 20, 4000, "Lclick", "");
                            objclsfunopics.startprocess(650, 28, 100, 20, 4000, "Alt+F+X+N", "");

                            objclsfunopics.startprocess(764, 161, 100, 20, 7000, "Alt+X+E", "");
                            //int noofTab = 0;
                            //Clipboard.SetText("Nothing");
                            //for (int j = 0; j< 7; j++)
                            //{
                            //    objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Tab", "");
                            //}
                            //objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Copy", "");

                            //if (Clipboard.GetText() == "Nothing")
                            //{
                            //    noofTab = 7;
                            //    objclsfunopics.startprocess(764, 161, 100, 20, 2000, "Tab", "");
                            //}
                            //else
                            //{
                            //    noofTab = 6;
                            //}                            
                            for (int j = 0; j < noofTab; j++)
                            {
                                objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Tab", "");
                            }
                            objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Space", "");
                            objclsfunopics.startprocess(203, 337, 100, 20, 1000, "Passvalue", shortName);
                            objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Cut", "");
                            objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Tab", "");

                            Query = @"V:\ARC\" + reconName + "\\";
                            objclsfunopics.startprocess(203, 337, 100, 20, 2000, "Passvalue", Query);
                            Query = "";
                            objclsfunopics.startprocess(146, 126, 100, 20, 1000, "Enter", "");
                            for (int j = 0; j < noofTab; j++)
                            {
                                objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Tab", "");
                            }
                            Thread.Sleep(2000);
                            objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Space", "");
                            objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Paste", "");
                            for (int m = 0; m < 10; m++)
                            {
                                Thread.Sleep(3000);
                            }
                            for (int y = 0; y < 4; y++)
                            {
                                objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Tab", "");
                            }
                            objclsfunopics.startprocess(146, 126, 100, 20, 1000, "Enter", "");
                            objclsfunopics.startprocess(20, 30, 100, 20, 4000, "Alt+Q", "");
                            if (dt.Rows.Count == 1)
                            {
                                objclsfunopics.startprocess(37, 32, 100, 20, 4000, "Lclick", "");
                                objclsfunopics.startprocess(71, 73, 100, 20, 4000, "Lclick", "");
                            }
                        }
                        else if (i == dt.Rows.Count - 1)
                        {
                            objclsfunopics.startprocess(130, 80, 100, 20, 4000, "Lclick", "");
                            Query = dt.Rows[i]["Query"].ToString();
                            if (Query.Contains(":SReconDate") || Query.Contains(":EReconDate") || Query.Contains(":BRANCH"))
                            {
                                Query = Query.Replace(":SReconDate", SDate);
                                Query = Query.Replace(":EReconDate", EDate);
                                Query = Query.Replace(":BRANCH", BranchNo);
                            }
                            objclsfunopics.startprocess(14, 56, 100, 20, 3000, "Alt+T+N", "");
                            objclsfunopics.startprocess(321, 193, 100, 20, 4000, "Passvalue", Query);
                            objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Select", "");
                            objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Copy", "");
                            objclsfunopics.startprocess(14, 56, 100, 20, 3000, "Alt+F+X+N", "");
                            Query = "";
                            objclsfunopics.startprocess(321, 193, 100, 20, 4000, "Lclick", "");
                            objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Paste", "");
                            objclsfunopics.startprocess(48, 79, 100, 20, 12000, "Lclick", "");
                            objclsfunopics.startprocess(14, 56, 100, 20, 5000, "Alt+Space+X", "");
                            objclsfunopics.startprocess(764, 161, 100, 20, 7000, "Alt+X+E", "");
                            if (noofTab == 6)
                            {
                                Query = FileName;
                            }
                            else
                            {
                                Query = FileName;
                                //if (Region == "OpicsPlus" || Region == "OpicsReg")
                                //{
                                //    Query = @"D:\opxcom\" + userid + "\\" + FileName;
                                //}
                                //else if (Region == "OpicsPVB")
                                //{
                                //    Query = @"C:\opxcom\" + userid + "\\" + FileName;
                                //}
                            }
                            objclsfunopics.startprocess(203, 337, 100, 20, 7000, "Passvalue", Query);
                            Query = "";
                            objclsfunopics.startprocess(203, 337, 100, 20, 10000, "2Tab+Enter", "");

                            for (int j = 0; j < 10; j++)
                            {
                                if (IsExcelCreated(FileName))
                                {
                                    break;
                                }
                                Thread.Sleep(5000);
                            }
                            objclsfunopics.startprocess(650, 28, 100, 20, 4000, "Lclick", "");
                            objclsfunopics.startprocess(650, 28, 100, 20, 4000, "Alt+F+X+N", "");

                            objclsfunopics.startprocess(764, 161, 100, 20, 7000, "Alt+X+E", "");
                            //int noofTab = 0;
                            //Clipboard.SetText("Nothing");
                            //for (int j = 0; j< 7; j++)
                            //{
                            //    objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Tab", "");
                            //}
                            //objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Copy", "");

                            //if (Clipboard.GetText() == "Nothing")
                            //{
                            //    noofTab = 7;
                            //    objclsfunopics.startprocess(764, 161, 100, 20, 2000, "Tab", "");
                            //}
                            //else
                            //{
                            //    noofTab = 6;
                            //}
                            for (int j = 0; j < noofTab; j++)
                            {
                                objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Tab", "");
                            }
                            objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Space", "");
                            objclsfunopics.startprocess(203, 337, 100, 20, 1000, "Passvalue", shortName);
                            objclsfunopics.startprocess(764, 161, 100, 20, 2000, "Cut", "");
                            objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Tab", "");

                            Query = @"V:\ARC\" + reconName + "\\";
                            objclsfunopics.startprocess(203, 337, 100, 20, 2000, "Passvalue", Query);
                            Query = "";
                            objclsfunopics.startprocess(146, 126, 100, 20, 1000, "Enter", "");
                            for (int j = 0; j < noofTab; j++)
                            {
                                objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Tab", "");
                            }
                            Thread.Sleep(2000);
                            objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Space", "");
                            objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Paste", "");
                            for (int m = 0; m < 10; m++)
                            {
                                Thread.Sleep(3000);
                            }
                            for (int y = 0; y < 4; y++)
                            {
                                objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Tab", "");
                            }
                            objclsfunopics.startprocess(146, 126, 100, 20, 1000, "Enter", "");
                            objclsfunopics.startprocess(20, 30, 100, 20, 4000, "Alt+Q", "");
                            objclsfunopics.startprocess(37, 32, 100, 20, 4000, "Lclick", "");
                            objclsfunopics.startprocess(71, 73, 100, 20, 4000, "Lclick", "");
                        }
                        else if (i > 0)
                        {
                            objclsfunopics.startprocess(130, 80, 100, 20, 4000, "Lclick", "");
                            Query = dt.Rows[i]["Query"].ToString();
                            if (Query.Contains(":SReconDate") || Query.Contains(":EReconDate") || Query.Contains(":BRANCH"))
                            {
                                Query = Query.Replace(":SReconDate", SDate);
                                Query = Query.Replace(":EReconDate", EDate);
                                Query = Query.Replace(":BRANCH", BranchNo);
                            }
                            objclsfunopics.startprocess(14, 56, 100, 20, 3000, "Alt+T+N", "");
                            objclsfunopics.startprocess(321, 193, 100, 20, 4000, "Passvalue", Query);
                            objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Select", "");
                            objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Copy", "");
                            objclsfunopics.startprocess(14, 56, 100, 20, 3000, "Alt+F+X+N", "");
                            Query = "";
                            objclsfunopics.startprocess(321, 193, 100, 20, 4000, "Lclick", "");
                            objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Paste", "");
                            objclsfunopics.startprocess(48, 79, 100, 20, 12000, "Lclick", "");
                            objclsfunopics.startprocess(14, 56, 100, 20, 5000, "Alt+Space+X", "");
                            objclsfunopics.startprocess(764, 161, 100, 20, 7000, "Alt+X+E", "");
                            if (noofTab == 6)
                            {
                                Query = FileName;
                            }
                            else
                            {
                                Query = FileName;
                                //if (Region == "OpicsPlus" || Region == "OpicsReg")
                                //{
                                //    Query = @"D:\opxcom\" + userid + "\\" + FileName;
                                //}
                                //else if (Region == "OpicsPVB")
                                //{
                                //    Query = @"C:\opxcom\" + userid + "\\" + FileName;
                                //}
                            }
                            objclsfunopics.startprocess(203, 337, 100, 20, 7000, "Passvalue", Query);
                            Query = "";
                            objclsfunopics.startprocess(203, 337, 100, 20, 10000, "2Tab+Enter", "");

                            for (int j = 0; j < 10; j++)
                            {
                                if (IsExcelCreated(FileName))
                                {
                                    break;
                                }
                                Thread.Sleep(5000);
                            }
                            objclsfunopics.startprocess(650, 28, 100, 20, 4000, "Lclick", "");
                            objclsfunopics.startprocess(650, 28, 100, 20, 4000, "Alt+F+X+N", "");

                            objclsfunopics.startprocess(764, 161, 100, 20, 7000, "Alt+X+E", "");
                            //int noofTab = 0;
                            //Clipboard.SetText("Nothing");
                            //for (int j = 0; j< 7; j++)
                            //{
                            //    objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Tab", "");
                            //}
                            //objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Copy", "");

                            //if (Clipboard.GetText() == "Nothing")
                            //{
                            //    noofTab = 7;
                            //    objclsfunopics.startprocess(764, 161, 100, 20, 2000, "Tab", "");
                            //}
                            //else
                            //{
                            //    noofTab = 6;
                            //}
                            for (int j = 0; j < noofTab; j++)
                            {
                                objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Tab", "");
                            }
                            objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Space", "");
                            objclsfunopics.startprocess(203, 337, 100, 20, 1000, "Passvalue", shortName);
                            objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Cut", "");
                            objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Tab", "");

                            Query = @"V:\ARC\" + reconName + "\\";
                            objclsfunopics.startprocess(203, 337, 100, 20, 2000, "Passvalue", Query);
                            Query = "";
                            objclsfunopics.startprocess(146, 126, 100, 20, 3000, "Enter", "");
                            for (int j = 0; j < noofTab; j++)
                            {
                                objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Tab", "");
                            }
                            Thread.Sleep(2000);
                            objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Space", "");
                            objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Paste", "");
                            for (int m = 0; m < 10; m++)
                            {
                                Thread.Sleep(3000);
                            }
                            for (int y = 0; y < 4; y++)
                            {
                                objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Tab", "");
                            }
                            objclsfunopics.startprocess(146, 126, 100, 20, 1000, "Enter", "");
                            objclsfunopics.startprocess(20, 30, 100, 20, 4000, "Alt+Q", "");
                        }
                    }
                    //                
                    string dtime = DateTime.Now.ToString("dd-MMM-yyyy");
                    Downloadpath = Downloadpath + dtime + "_Files" + "\\Input\\" + Region + "_"+ Country + "\\";
                    //MessageBox.Show(Region);
                    transferfile_opics_prn(@"C:\ARC\" + reconName + "\\", Downloadpath, reconName);
                }
                result = true;
            }
            catch (Exception ex)
            {
                ErrorMsg = ex.ToString();
            }
            //changeResolution(Org_screenWidth, Org_screenHeight);
            return result;

        }
        public bool opics_Recons_Excel(string con, string reconName, string opicsRegion, string Country, string Date, string Downloadpath, string userid, out string ErrorMsg)
        {
            bool result = false;
            ErrorMsg = string.Empty;
            string strQuery = string.Empty;
            string FileName = string.Empty;
            string Region = string.Empty;
            int Org_screenWidth = Screen.PrimaryScreen.Bounds.Width;
            int Org_screenHeight = Screen.PrimaryScreen.Bounds.Height;
            //changeResolution(1024, 768);
            Create_Directory(@"C:\ARC\");
            Create_Directory(@"C:\ARC\" + reconName);
            Create_Directory(@"C:\ARC\" + reconName + "_ScreenShots");
            deleteFiles(@"C:\ARC\" + reconName);
            try
            {
                int chck = FindNoOfOpenWindow();
                if (chck == 1 || opicsRegion.ToUpper()=="OPICSPVB")
                {
                    SqlConnection conn = new SqlConnection(con);
                    SqlCommand com = new SqlCommand();
                    conn.Open();
                    strQuery = "select * from  Arc_opics_query where recon='" + reconName + "' and opics_Region = '" + opicsRegion + "'";
                    com = new SqlCommand(strQuery, conn);
                    SqlDataAdapter da = new SqlDataAdapter(com);
                    System.Data.DataTable dt = new System.Data.DataTable();
                    da.Fill(dt);
                    conn.Close();
                    string shortName = "";
                    string Query = string.Empty;                    
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        FileName = dt.Rows[i]["File_Name"].ToString();
                        Region = dt.Rows[i]["Opics_Region"].ToString();
                        if (reconName == "Structured Finance Position Monthly")
                        {
                            string MMM = Convert.ToDateTime(Date).ToString("MMM");
                            string YYYY = Convert.ToDateTime(Date).ToString("yyyy");
                            FileName = FileName.Replace("MMM", MMM);
                            FileName = FileName.Replace("YYYY", YYYY);
                        }
                        else
                        {
                            string dtimefrm1 = Convert.ToDateTime(Date).ToString("ddMMyyyy");
                            FileName = FileName.Replace("DDMMYYYY", dtimefrm1);
                        }

                        shortName = FileName.Substring(0, 2);
                        if (i == 0)
                        {
                            Thread.Sleep(10000);
                            objclsfunopics.startprocess(14, 56, 100, 20, 5000, "Alt+Space+X", "");
                            objclsfunopics.startprocess(25, 56, 100, 20, 2000, "Lclick", "");
                            Query = "GRSS";
                            objclsfunopics.startprocess(25, 56, 100, 20, 7000, "Passvalue", Query);
                            Query = "";
                            objclsfunopics.startprocess(110, 57, 100, 20, 4000, "Lclick", "");
                            objclsfunopics.startprocess(14, 56, 100, 20, 5000, "Alt+Space+X", "");
                            objclsfunopics.startprocess(130, 80, 100, 20, 4000, "Lclick", "");
                            objclsfunopics.startprocess(321, 193, 100, 20, 4000, "Lclick", "");
                            Query = dt.Rows[i]["Query"].ToString();
                            if (Query.Contains(":ReconDate"))
                            {
                                Query = Query.Replace(":ReconDate", Date);
                            }
                            objclsfunopics.startprocess(321, 193, 100, 20, 4000, "Passvalue", Query);
                            Query = "";
                            objclsfunopics.startprocess(48, 79, 100, 20, 12000, "Lclick", "");
                            objclsfunopics.startprocess(14, 56, 100, 20, 5000, "Alt+Space+X", "");
                            //
                            objclsfunopics.startprocess(764, 161, 100, 20, 7000, "Alt+X+E", "");
                            Query = FileName;
                            objclsfunopics.startprocess(203, 337, 100, 20, 7000, "Passvalue", Query);
                            Query = "";
                            objclsfunopics.startprocess(203, 337, 100, 20, 10000, "2Tab+Enter", "");
                            for (int j = 0; j < 10; j++)
                            {
                                if (IsExcelCreated(FileName))
                                {
                                    objclsfunopics.startprocess(14, 56, 100, 20, 5000, "Alt+Space+X", "");
                                    break;
                                }
                                Thread.Sleep(5000);
                            }

                            objclsfunopics.startprocess(14, 56, 100, 20, 5000, "Select", "");
                            objclsfunopics.startprocess(14, 56, 100, 20, 5000, "Copy", "");                            
                            CreateExcel_Opics("C:\\ARC\\" + reconName + "\\" + FileName + ".xls", 7000, reconName, FileName, out ErrorMsg);
                            
                            objclsfunopics.startprocess(650, 28, 100, 20, 4000, "Lclick", "");
                            objclsfunopics.startprocess(650, 28, 100, 20, 4000, "Alt+F+X+N+N", "");                            
                            objclsfunopics.startprocess(20, 30, 100, 20, 4000, "Alt+Q", "");
                            if (dt.Rows.Count == 1)
                            {
                                objclsfunopics.startprocess(37, 32, 100, 20, 4000, "Lclick", "");
                                objclsfunopics.startprocess(71, 73, 100, 20, 4000, "Lclick", "");
                            }
                        }
                        else if (i == dt.Rows.Count - 1)
                        {
                            objclsfunopics.startprocess(130, 80, 100, 20, 4000, "Lclick", "");
                            objclsfunopics.startprocess(321, 193, 100, 20, 4000, "Lclick", "");
                            Query = dt.Rows[i]["Query"].ToString();
                            if (Query.Contains(":ReconDate"))
                            {
                                Query = Query.Replace(":ReconDate", Date);
                            }
                            objclsfunopics.startprocess(321, 193, 100, 20, 4000, "Passvalue", Query);
                            Query = "";
                            objclsfunopics.startprocess(48, 79, 100, 20, 12000, "Lclick", "");
                            objclsfunopics.startprocess(14, 56, 100, 20, 5000, "Alt+Space+X", "");
                            //
                            objclsfunopics.startprocess(764, 161, 100, 20, 7000, "Alt+X+E", "");
                            Query = FileName;
                            objclsfunopics.startprocess(203, 337, 100, 20, 7000, "Passvalue", Query);
                            Query = "";
                            objclsfunopics.startprocess(203, 337, 100, 20, 10000, "2Tab+Enter", "");
                            for (int j = 0; j < 10; j++)
                            {
                                if (IsExcelCreated(FileName))
                                {
                                    objclsfunopics.startprocess(14, 56, 100, 20, 5000, "Alt+Space+X", "");
                                    break;
                                }
                                Thread.Sleep(10000);
                            }

                            objclsfunopics.startprocess(14, 56, 100, 20, 5000, "Select", "");
                            objclsfunopics.startprocess(14, 56, 100, 20, 5000, "Copy", "");
                            //StreamWriter sw = new StreamWriter("C:\\ARC\\" + reconName + "\\" + FileName + ".txt");
                            //Process.Start("C:\\ARC\\" + reconName + "\\" + FileName + ".txt");
                            //objclsfunopics.startprocess(14, 56, 100, 20, 3000, "Alt+Space+X", "");
                            //objclsfunopics.startprocess(14, 56, 100, 20, 5000, "Paste", "");
                            //for (int k = 0; k < 20; k++)
                            //{
                            //    Thread.Sleep(7000);
                            //    if (isExcelPasted())
                            //    {
                            //        break;
                            //    }
                            //}
                            //objclsfunopics.startprocess(14, 56, 100, 20, 5000, "Select", "");
                            //objclsfunopics.startprocess(14, 56, 100, 20, 5000, "Copy", "");
                            CreateExcel_Opics("C:\\ARC\\" + reconName + "\\" + FileName + ".xls", 7000, reconName, FileName, out ErrorMsg);

                            objclsfunopics.startprocess(650, 28, 100, 20, 4000, "Lclick", "");
                            objclsfunopics.startprocess(650, 28, 100, 20, 4000, "Alt+F+X+N+N", "");
                            objclsfunopics.startprocess(20, 30, 100, 20, 4000, "Alt+Q", "");
                            objclsfunopics.startprocess(37, 32, 100, 20, 4000, "Lclick", "");
                            objclsfunopics.startprocess(71, 73, 100, 20, 4000, "Lclick", "");
                        }
                        else if (i > 0)
                        {
                            objclsfunopics.startprocess(130, 80, 100, 20, 4000, "Lclick", "");
                            objclsfunopics.startprocess(321, 193, 100, 20, 4000, "Lclick", "");
                            Query = dt.Rows[i]["Query"].ToString();
                            if (Query.Contains(":ReconDate"))
                            {
                                Query = Query.Replace(":ReconDate", Date);
                            }
                            objclsfunopics.startprocess(321, 193, 100, 20, 4000, "Passvalue", Query);
                            Query = "";
                            objclsfunopics.startprocess(48, 79, 100, 20, 12000, "Lclick", "");
                            objclsfunopics.startprocess(14, 56, 100, 20, 5000, "Alt+Space+X", "");
                            //
                            objclsfunopics.startprocess(764, 161, 100, 20, 7000, "Alt+X+E", "");
                            Query = FileName;
                            objclsfunopics.startprocess(203, 337, 100, 20, 7000, "Passvalue", Query);
                            Query = "";
                            objclsfunopics.startprocess(203, 337, 100, 20, 10000, "2Tab+Enter", "");
                            for (int j = 0; j < 10; j++)
                            {
                                if (IsExcelCreated(FileName))
                                {
                                    objclsfunopics.startprocess(14, 56, 100, 20, 5000, "Alt+Space+X", "");
                                    break;
                                }
                                Thread.Sleep(10000);
                            }

                            objclsfunopics.startprocess(14, 56, 100, 20, 5000, "Select", "");
                            objclsfunopics.startprocess(14, 56, 100, 20, 5000, "Copy", "");
                            //StreamWriter sw = new StreamWriter("C:\\ARC\\" + reconName + "\\" + FileName + ".txt");
                            //Process.Start("C:\\ARC\\" + reconName + "\\" + FileName + ".txt");
                            //objclsfunopics.startprocess(14, 56, 100, 20, 3000, "Alt+Space+X", "");
                            //objclsfunopics.startprocess(14, 56, 100, 20, 5000, "Paste", "");
                            //for (int k = 0; k < 20; k++)
                            //{
                            //    Thread.Sleep(7000);
                            //    if (isExcelPasted())
                            //    {
                            //        break;
                            //    }                                
                            //}
                            //objclsfunopics.startprocess(14, 56, 100, 20, 5000, "Select", "");
                            //objclsfunopics.startprocess(14, 56, 100, 20, 5000, "Copy", "");
                            CreateExcel_Opics("C:\\ARC\\" + reconName + "\\" + FileName + ".xls", 7000, reconName, FileName, out ErrorMsg);

                            objclsfunopics.startprocess(650, 28, 100, 20, 4000, "Lclick", "");
                            objclsfunopics.startprocess(650, 28, 100, 20, 4000, "Alt+F+X+N+N", "");                            
                            objclsfunopics.startprocess(20, 30, 100, 20, 4000, "Alt+Q", "");
                        }
                    }
                    //                
                    string dtime = DateTime.Now.ToString("dd-MMM-yyyy");
                    Downloadpath = Downloadpath + dtime + "_Files" + "\\Input\\" + Region + "\\";
                    //MessageBox.Show(Region);
                    transferfile_opics(@"C:\ARC\" + reconName + "\\", Downloadpath, reconName);
                }
                result = true;
            }
            catch (Exception ex)
            {
                ErrorMsg = ex.ToString();
            }
            //changeResolution(Org_screenWidth, Org_screenHeight);
            return result;
        }
        public bool opics_StructureFunding(string con, string reconName, string opicsRegion, string Country, string Date, string Downloadpath, string userid, out string ErrorMsg)
        {
            bool result = false;
            ErrorMsg = string.Empty;
            string strQuery = string.Empty;
            string FileName = string.Empty;
            string Region = string.Empty;
            int Org_screenWidth = Screen.PrimaryScreen.Bounds.Width;
            int Org_screenHeight = Screen.PrimaryScreen.Bounds.Height;
            //changeResolution(1024, 768);
            Create_Directory(@"C:\ARC\");
            Create_Directory(@"C:\ARC\" + reconName);
            Create_Directory(@"C:\ARC\" + reconName + "_ScreenShots");
            deleteFiles(@"C:\ARC\" + reconName);
            try
            {
                int chck = FindNoOfOpenWindow();
                if (chck == 1)
                {
                    SqlConnection conn = new SqlConnection(con);
                    SqlCommand com = new SqlCommand();
                    conn.Open();
                    strQuery = "select * from  Arc_opics_query where recon='" + reconName + "' and opics_Region = '" + opicsRegion + "'";
                    com = new SqlCommand(strQuery, conn);
                    SqlDataAdapter da = new SqlDataAdapter(com);
                    System.Data.DataTable dt = new System.Data.DataTable();
                    da.Fill(dt);
                    conn.Close();
                    string shortName = "";
                    string Query = string.Empty;
                    int noofTab = 0;
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        FileName = dt.Rows[i]["File_Name"].ToString();
                        Region = dt.Rows[i]["Opics_Region"].ToString();
                        string dtimefrm1 = Convert.ToDateTime(Date).ToString("ddMMyy");
                        FileName = FileName.Replace("DDMMYY", dtimefrm1);
                        shortName = FileName.Substring(0, 2);                        
                        if (i == 0)
                        {
                            Thread.Sleep(10000);
                            objclsfunopics.startprocess(14, 56, 100, 20, 5000, "Alt+Space+X", "");
                            objclsfunopics.startprocess(25, 56, 100, 20, 2000, "Lclick", "");
                            Query = "DLIQ";
                            objclsfunopics.startprocess(25, 56, 100, 20, 7000, "Passvalue", Query);
                            Query = "";
                            objclsfunopics.startprocess(110, 57, 100, 20, 12000, "Lclick", "");

                            objclsfunopics.startprocess(20, 30, 100, 20, 4000, "Alt+D+D", "");
                            Query = (dt.Rows[i]["Query"].ToString()).Split(',').First();
                            objclsfunopics.startprocess(25, 56, 100, 20, 7000, "Passvalue", Query);
                            Query = "";
                            for (int y = 0; y < 2; y++)
                            {
                                objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Tab", "");
                            }
                            Query = (dt.Rows[i]["Query"].ToString()).Split(',').Last();
                            objclsfunopics.startprocess(25, 56, 100, 20, 2000, "Passvalue", Query);
                            Query = "";
                            objclsfunopics.startprocess(14, 56, 100, 20, 6000, "Alt+R", "");
                            objclsfunopics.startprocess(14, 56, 100, 20, 2000, "Alt+Space+X", "");
                            //To find No of Tab
                            objclsfunopics.startprocess(764, 161, 100, 20, 7000, "Alt+X+E", "");
                            noofTab = 6;
                            objclsfunopics.startprocess(203, 337, 100, 20, 7000, "Passvalue", "Dummyexcel");                            
                            for (int j = 0; j < 10; j++)
                            {
                                objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Tab", "");
                            }
                            objclsfunopics.startprocess(146, 126, 100, 20, 2000, "Enter", "");
                            for (int j = 0; j < 10; j++)
                            {
                                if (IsExcelCreated("Dummyexcel"))
                                {
                                    noofTab = 7;
                                    break;
                                }
                                Thread.Sleep(10000);
                            }
                            objclsfunopics.startprocess(650, 28, 100, 20, 4000, "Lclick", "");
                            objclsfunopics.startprocess(650, 28, 100, 20, 4000, "Alt+F+X+N", "");
                            //                            
                            objclsfunopics.startprocess(764, 161, 100, 20, 7000, "Alt+X+E", "");
                            if (noofTab == 6)
                            {
                                Query = FileName;
                            }
                            else
                            {
                                Query = FileName;
                            }
                            objclsfunopics.startprocess(203, 337, 100, 20, 7000, "Passvalue", Query);
                            Query = "";
                            objclsfunopics.startprocess(203, 337, 100, 20, 10000, "2Tab+Enter", "");

                            for (int j = 0; j < 10; j++)
                            {
                                if (IsExcelCreated(FileName))
                                {
                                    break;
                                }
                                Thread.Sleep(10000);
                            }
                            objclsfunopics.startprocess(650, 28, 100, 20, 4000, "Lclick", "");
                            objclsfunopics.startprocess(650, 28, 100, 20, 4000, "Alt+F+X+N", "");

                            objclsfunopics.startprocess(764, 161, 100, 20, 7000, "Alt+X+E", "");
                                                        
                            for (int j = 0; j < noofTab; j++)
                            {
                                objclsfunopics.startprocess(764, 161, 100, 20, 2000, "Tab", "");
                            }
                            objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Space", "");
                            objclsfunopics.startprocess(203, 337, 100, 20, 1000, "Passvalue", shortName);
                            objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Cut", "");
                            objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Tab", "");

                            Query = @"V:\ARC\" + reconName + "\\";
                            objclsfunopics.startprocess(203, 337, 100, 20, 2000, "Passvalue", Query);
                            Query = "";
                            objclsfunopics.startprocess(146, 126, 100, 20, 1000, "Enter", "");
                            for (int j = 0; j < noofTab; j++)
                            {
                                objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Tab", "");
                            }
                            Thread.Sleep(2000);
                            objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Space", "");
                            objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Paste", "");
                            for (int m = 0; m < 10; m++)
                            {
                                Thread.Sleep(5000);
                            }
                            for (int y = 0; y < 4; y++)
                            {
                                objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Tab", "");
                            }
                            objclsfunopics.startprocess(146, 126, 100, 20, 1000, "Enter", "");
                            objclsfunopics.startprocess(20, 30, 100, 20, 4000, "Alt+Q", "");

                            if (dt.Rows.Count == 1)
                            {
                                objclsfunopics.startprocess(20, 30, 100, 20, 3000, "AltQ", "");
                                //objclsfunopics.startprocess(20, 30, 100, 20, 3000, "Alt+Q", "");
                                //objclsfunopics.startprocess(146, 126, 100, 20, 2000, "Enter", "");
                                objclsfunopics.startprocess(14, 56, 100, 20, 2000, "Alt+Space+X+C", ""); 
                            }
                        }
                        else if (i == dt.Rows.Count - 1)
                        {
                            Query = (dt.Rows[i]["Query"].ToString()).Split(',').First();
                            objclsfunopics.startprocess(25, 56, 100, 20, 7000, "Passvalue", Query);
                            Query = "";
                            for (int y = 0; y < 2; y++)
                            {
                                objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Tab", "");
                            }
                            Query = (dt.Rows[i]["Query"].ToString()).Split(',').Last();
                            objclsfunopics.startprocess(25, 56, 100, 20, 2000, "Passvalue", Query);
                            Query = "";
                            objclsfunopics.startprocess(14, 56, 100, 20, 5000, "Alt+R", "");
                            objclsfunopics.startprocess(14, 56, 100, 20, 2000, "Alt+Space+X", "");
                                                    
                            objclsfunopics.startprocess(764, 161, 100, 20, 7000, "Alt+X+E", "");
                            if (noofTab == 6)
                            {
                                Query = FileName;
                            }
                            else
                            {
                                Query = FileName;
                            }
                            objclsfunopics.startprocess(203, 337, 100, 20, 7000, "Passvalue", Query);
                            Query = "";
                            objclsfunopics.startprocess(203, 337, 100, 20, 10000, "2Tab+Enter", "");

                            for (int j = 0; j < 10; j++)
                            {
                                if (IsExcelCreated(FileName))
                                {
                                    break;
                                }
                                Thread.Sleep(10000);
                            }
                            objclsfunopics.startprocess(650, 28, 100, 20, 4000, "Lclick", "");
                            objclsfunopics.startprocess(650, 28, 100, 20, 4000, "Alt+F+X+N", "");

                            objclsfunopics.startprocess(764, 161, 100, 20, 7000, "Alt+X+E", "");

                            for (int j = 0; j < noofTab; j++)
                            {
                                objclsfunopics.startprocess(764, 161, 100, 20, 2000, "Tab", "");
                            }
                            objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Space", "");
                            objclsfunopics.startprocess(203, 337, 100, 20, 1000, "Passvalue", shortName);
                            objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Cut", "");
                            objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Tab", "");

                            Query = @"V:\ARC\" + reconName + "\\";
                            objclsfunopics.startprocess(203, 337, 100, 20, 2000, "Passvalue", Query);
                            Query = "";
                            objclsfunopics.startprocess(146, 126, 100, 20, 1000, "Enter", "");
                            for (int j = 0; j < noofTab; j++)
                            {
                                objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Tab", "");
                            }
                            Thread.Sleep(2000);
                            objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Space", "");
                            objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Paste", "");
                            for (int m = 0; m < 10; m++)
                            {
                                Thread.Sleep(5000);
                            }
                            for (int y = 0; y < 4; y++)
                            {
                                objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Tab", "");
                            }
                            objclsfunopics.startprocess(146, 126, 100, 20, 1000, "Enter", "");
                            objclsfunopics.startprocess(20, 30, 100, 20, 4000, "Alt+Q", "");

                            objclsfunopics.startprocess(20, 30, 100, 20, 3000, "AltQ", "");
                            //objclsfunopics.startprocess(20, 30, 100, 20, 3000, "Alt+Q", "");
                            objclsfunopics.startprocess(14, 56, 100, 20, 2000, "Alt+Space+X+C", ""); 
                            //objclsfunopics.startprocess(146, 126, 100, 20, 2000, "Enter", "");
                        }
                        else if (i > 0)
                        {
                            Query = (dt.Rows[i]["Query"].ToString()).Split(',').First();
                            objclsfunopics.startprocess(25, 56, 100, 20, 7000, "Passvalue", Query);
                            Query = "";
                            for (int y = 0; y < 2; y++)
                            {
                                objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Tab", "");
                            }
                            Query = (dt.Rows[i]["Query"].ToString()).Split(',').Last();
                            objclsfunopics.startprocess(25, 56, 100, 20, 2000, "Passvalue", Query);
                            Query = "";
                            objclsfunopics.startprocess(14, 56, 100, 20, 5000, "Alt+R", "");
                            objclsfunopics.startprocess(14, 56, 100, 20, 2000, "Alt+Space+X", "");

                            objclsfunopics.startprocess(764, 161, 100, 20, 7000, "Alt+X+E", "");
                            if (noofTab == 6)
                            {
                                Query = FileName;
                            }
                            else
                            {
                                Query = FileName;
                            }
                            objclsfunopics.startprocess(203, 337, 100, 20, 7000, "Passvalue", Query);
                            Query = "";
                            objclsfunopics.startprocess(203, 337, 100, 20, 10000, "2Tab+Enter", "");

                            for (int j = 0; j < 10; j++)
                            {
                                if (IsExcelCreated(FileName))
                                {
                                    break;
                                }
                                Thread.Sleep(10000);
                            }
                            objclsfunopics.startprocess(650, 28, 100, 20, 4000, "Lclick", "");
                            objclsfunopics.startprocess(650, 28, 100, 20, 4000, "Alt+F+X+N", "");

                            objclsfunopics.startprocess(764, 161, 100, 20, 7000, "Alt+X+E", "");

                            for (int j = 0; j < noofTab; j++)
                            {
                                objclsfunopics.startprocess(764, 161, 100, 20, 2000, "Tab", "");
                            }
                            objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Space", "");
                            objclsfunopics.startprocess(203, 337, 100, 20, 1000, "Passvalue", shortName);
                            objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Cut", "");
                            objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Tab", "");

                            Query = @"V:\ARC\" + reconName + "\\";
                            objclsfunopics.startprocess(203, 337, 100, 20, 2000, "Passvalue", Query);
                            Query = "";
                            objclsfunopics.startprocess(146, 126, 100, 20, 1000, "Enter", "");
                            for (int j = 0; j < noofTab; j++)
                            {
                                objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Tab", "");
                            }
                            Thread.Sleep(2000);
                            objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Space", "");
                            objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Paste", "");
                            for (int m = 0; m < 10; m++)
                            {
                                Thread.Sleep(5000);
                            }
                            for (int y = 0; y < 4; y++)
                            {
                                objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Tab", "");
                            }
                            objclsfunopics.startprocess(146, 126, 100, 20, 1000, "Enter", "");
                            objclsfunopics.startprocess(20, 30, 100, 20, 4000, "Alt+Q", "");
                        }
                    }
                    //                
                    string dtime = DateTime.Now.ToString("dd-MMM-yyyy");
                    string Downloadpath_in = Downloadpath;
                    Downloadpath = Downloadpath + dtime + "_Files" + "\\Input\\" + Region + "\\";
                    //MessageBox.Show(Region);
                    transferfile_opics(@"C:\ARC\" + reconName + "\\", Downloadpath, reconName);
                    prnConvertorSF(Date, Downloadpath_in);
                }
                result = true;
            }
            catch (Exception ex)
            {
                ErrorMsg = ex.ToString();
            }
            changeResolution(Org_screenWidth, Org_screenHeight);
            return result;

        }
        public bool opics_FXIQ(string con, string reconName, string opicsRegion, string Country, string Date, string Downloadpath, string userid, int tabval, out string ErrorMsg)
        {
            //objclsfunopics.startprocess(99, 33, 102, 34, 2000, "Lclick", "");
            //objclsfunopics.startprocess(14, 56, 100, 20, 2000, "Alt+Space+X+C", "");  
            bool result = false;
            ErrorMsg = string.Empty;
            string strQuery = string.Empty;
            string FileName = string.Empty;
            string Region = string.Empty;
            string Branch = string.Empty;
            int Org_screenWidth = Screen.PrimaryScreen.Bounds.Width;
            int Org_screenHeight = Screen.PrimaryScreen.Bounds.Height;
            //changeResolution(1024, 768);
            Create_Directory(@"C:\ARC\");
            Create_Directory(@"C:\ARC\" + reconName);
            Create_Directory(@"C:\ARC\" + reconName + "_ScreenShots");
            deleteFiles(@"C:\ARC\" + reconName);

            switch (reconName)
            {
                case "DIFC FX Recon - Advised-DIFC Adjustment Report":
                    Branch = "45";
                    FileName = "aefrwd";
                    break;
                case "OMAN FX Recon - Advised-OMAN Adjustment Report":
                    Branch = "50";
                    FileName = "frwd";
                    break;
                case "UAE FX Recon - Advised_UAE Adjustment Report":
                    Branch = "51";
                    FileName = "aefrwd";
                    break;
                case "Qatar - FX Recon Adjustments_Qatar FX Recon":
                    Branch = "54";
                    FileName = "frwd";
                    break;
                case "BAHRAIN DBU FX Recon - Advised-BAHRAIN DBU Adjustment Report":
                    Branch = "55";
                    FileName = "DBU forward";
                    break;
                case "BAHRAIN OBU FX Recon - Advised-BAHRAIN OBU Adjustment Report":
                    Branch = "56";
                    FileName = "OBU forward";
                    break;
                case "Jordan FX Recon - Advised_Jordan Adjustment Report":
                    Branch = "96";
                    FileName = "FORWARDDEAL";
                    break;                
                case "Srilanka - Fx Recon_Srilanka - FXR Adjustments":                    
                    Branch = "84";
                    FileName = "Frwddeal";
                    break;
            }            
            try
            {
                int chck = FindNoOfOpenWindow();
                
                if (chck == 1)
                {
                    
                    string shortName = "";
                    string Query = string.Empty;
                    int noofTab = 0;
                    Region = "opics";
                    string dtimefrm1 = Convert.ToDateTime(Date).ToString("ddMMyy");
                    FileName = FileName.Replace("DDMMYY", dtimefrm1);
                    shortName = FileName.Substring(0, 2);
                    Thread.Sleep(10000);
                    objclsfunopics.startprocess(14, 56, 100, 20, 5000, "Alt+Space+X", "");
                    if (reconName == "Jordan FX Recon - Advised_Jordan Adjustment Report" || reconName == "Srilanka - Fx Recon_Srilanka - FXR Adjustments")
                    {
                        objclsfunopics.startprocess(99, 33, 102, 34, 2000, "Lclick", "");
                        objclsfunopics.startprocess(142, 110, 102, 34, 2000, "Lclick", "");
                        objclsfunopics.startprocess(14, 56, 100, 20, 5000, "Alt+Space+X", "");
                        //objclsfunopics.startprocess(20, 30, 100, 20, 2000, "Alt+T+G", "");
                        Query = Branch;
                        objclsfunopics.startprocess(25, 56, 100, 20, 3000, "Passvalue", Query);
                        Query = "";
                        objclsfunopics.startprocess(20, 30, 100, 20, 10000, "Enter", "");                        
                        //objclsfunopics.startprocess(20, 30, 100, 20, 2000, "AltO", "");
                        objclsfunopics.startprocess(20, 30, 100, 20, 2000, "Enter", "");
                        objclsfunopics.startprocess(20, 30, 100, 20, 2000, "AltC", "");
                        objclsfunopics.startprocess(20, 30, 100, 20, 2000, "Enter", "");
                        objclsfunopics.startprocess(444, 328, 100, 20, 2000, "Lclick", "");                       
                    }
                    objclsfunopics.startprocess(25, 56, 100, 20, 2000, "Lclick", "");
                    Query = "FXIQ";
                    objclsfunopics.startprocess(25, 56, 100, 20, 7000, "Passvalue", Query);
                    Query = "";
                    objclsfunopics.startprocess(110, 57, 100, 20, 12000, "Lclick", "");

                    objclsfunopics.startprocess(20, 30, 100, 20, 2000, "Alt+D+F+F", "");
                    objclsfunopics.startprocess(20, 30, 100, 20, 7000, "Enter", "");
                    if (reconName == "Jordan FX Recon - Advised_Jordan Adjustment Report" || reconName == "Srilanka - Fx Recon_Srilanka - FXR Adjustments")
                    {
                        for (int y = 0; y < 16; y++)
                        {
                            objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Tab", "");
                        }
                    }
                    else
                    {
                        Query = Branch;
                        objclsfunopics.startprocess(25, 56, 100, 20, 7000, "Passvalue", Query);
                        Query = "";
                        for (int y = 0; y < 16; y++)
                        {
                            objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Tab", "");
                        }
                    }
                    Query = Date;
                    objclsfunopics.startprocess(25, 56, 100, 20, 2000, "Passvalue", Query);
                    Query = "";
                    objclsfunopics.startprocess(14, 56, 100, 20, 10000, "Alt+R", "");
                    objclsfunopics.startprocess(14, 56, 100, 20, 2000, "Alt+Space+X", "");
                    noofTab = Convert.ToInt32(tabval);
                    //To find No of Tab
                    //objclsfunopics.startprocess(764, 161, 100, 20, 7000, "Alt+X+E", "");
                    //noofTab = 6;
                    //objclsfunopics.startprocess(203, 337, 100, 20, 7000, "Passvalue", "Dummyexcel");
                    //for (int j = 0; j < 10; j++)
                    //{
                    //    objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Tab", "");
                    //}
                    //objclsfunopics.startprocess(146, 126, 100, 20, 2000, "Enter", "");
                    //for (int j = 0; j < 18; j++)
                    //{
                    //    if (IsExcelCreated("Dummyexcel"))
                    //    {
                    //        noofTab = 7;
                    //        break;
                    //    }
                    //    Thread.Sleep(10000);
                    //}
                    //objclsfunopics.startprocess(650, 28, 100, 20, 4000, "Lclick", "");
                    //objclsfunopics.startprocess(650, 28, 100, 20, 4000, "Alt+F+X+N", "");
                    //                            
                    objclsfunopics.startprocess(764, 161, 100, 20, 7000, "Alt+X+E", "");
                    if (noofTab == 6)
                    {
                        Query = FileName;
                    }
                    else
                    {
                        Query = FileName;
                        //Query = @"D:\opxcom\" + userid + "\\" + FileName;
                    }
                    objclsfunopics.startprocess(203, 337, 100, 20, 7000, "Passvalue", Query);
                    Query = "";
                    objclsfunopics.startprocess(203, 337, 100, 20, 10000, "2Tab+Enter", "");

                    for (int j = 0; j < 18; j++)
                    {
                        if (IsExcelCreated(FileName))
                        {
                            break;
                        }
                        Thread.Sleep(10000);
                    }
                    objclsfunopics.startprocess(650, 28, 100, 20, 4000, "Lclick", "");
                    objclsfunopics.startprocess(650, 28, 100, 20, 4000, "Alt+F+X+N", "");

                    objclsfunopics.startprocess(764, 161, 100, 20, 7000, "Alt+X+E", "");

                    for (int j = 0; j < noofTab; j++)
                    {
                        objclsfunopics.startprocess(764, 161, 100, 20, 2000, "Tab", "");
                    }
                    objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Space", "");
                    objclsfunopics.startprocess(203, 337, 100, 20, 1000, "Passvalue", shortName);
                    objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Cut", "");
                    objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Tab", "");

                    Query = @"V:\ARC\" + reconName + "\\";
                    objclsfunopics.startprocess(203, 337, 100, 20, 2000, "Passvalue", Query);
                    Query = "";
                    objclsfunopics.startprocess(146, 126, 100, 20, 1000, "Enter", "");
                    for (int j = 0; j < noofTab; j++)
                    {
                        objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Tab", "");
                    }
                    Thread.Sleep(2000);
                    objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Space", "");
                    objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Paste", "");
                    for (int m = 0; m < 10; m++)
                    {
                        Thread.Sleep(5000);
                    }
                    for (int y = 0; y < 4; y++)
                    {
                        objclsfunopics.startprocess(764, 161, 100, 20, 1000, "Tab", "");
                    }
                    objclsfunopics.startprocess(146, 126, 100, 20, 1000, "Enter", "");
                    objclsfunopics.startprocess(20, 30, 100, 20, 4000, "Alt+Q", "");

                    objclsfunopics.startprocess(20, 30, 100, 20, 3000, "AltQ", "");
                    //if (reconName == "Jordan FX Recon - Advised_Jordan Adjustment Report" || reconName == "Srilanka - Fx Recon_Srilanka - FXR Adjustments")
                    //{
                    objclsfunopics.startprocess(14, 56, 100, 20, 2000, "Alt+Space+X+C", "");                        
                    //}
                    //else
                    //{                        
                    //    objclsfunopics.startprocess(20, 30, 100, 20, 3000, "Alt+Q", "");
                    //    objclsfunopics.startprocess(146, 126, 100, 20, 2000, "Enter", "");
                    //}           
                    string dtime = DateTime.Now.ToString("dd-MMM-yyyy");
                    Downloadpath = Downloadpath + dtime + "_Files" + "\\Input\\" + Region+"_"+Country+ "\\";
                    //MessageBox.Show(Region);
                    transferfile_opics_prn(@"C:\ARC\" + reconName + "\\", Downloadpath, reconName);
                }
                result = true;
            }
            catch (Exception ex)
            {
                ErrorMsg = ex.ToString();
            }
            changeResolution(Org_screenWidth, Org_screenHeight);
            return result;

        }
        public bool opics_CHBR(string Branch)
        {
            bool result = true;
            try
            {
                objclsfunopics.startprocess(25, 56, 100, 20, 7000, "Lclick", "");
                objclsfunopics.startprocess(25, 56, 100, 20, 7000, "Passvalue", "CHBR");
                objclsfunopics.startprocess(25, 56, 100, 20, 1000, "Tab", "");
                objclsfunopics.startprocess(25, 56, 100, 20, 1000, "Tab", "");
                objclsfunopics.startprocess(25, 56, 100, 20, 2000, "Enter", "");
                objclsfunopics.startprocess(14, 56, 100, 20, 2000, "Alt+Space+X", "");
                objclsfunopics.startprocess(25, 56, 100, 20, 3000, "Passvalue", Branch);
                objclsfunopics.startprocess(20, 30, 100, 20, 10000, "Enter", "");
                objclsfunopics.startprocess(20, 30, 100, 20, 2000, "Enter", "");
                objclsfunopics.startprocess(20, 30, 100, 20, 2000, "AltC", "");
                objclsfunopics.startprocess(20, 30, 100, 20, 2000, "Enter", "");
                objclsfunopics.startprocess(444, 328, 100, 20, 2000, "Lclick", "");
                objclsfunopics.startprocess(25, 56, 100, 20, 2000, "Lclick", "");
            }
            catch (Exception ex)
            {
                result = false;
            }
            return result;
        }
        public bool SrilankaBTSDaily(string con, string reconName, string ApplicationName, string OpicsName, string BranchNo, string Date, string outputPath, string filename, string xmlPath, out string ErrorMsg)
        {
            bool result = false;
            ErrorMsg = string.Empty;
            Hashtable hat = new Hashtable();
            string strQuery = string.Empty;
            Create_Directory(@"C:\ARC\");
            Create_Directory(@"C:\ARC\ZIRC");
            Create_Directory(@"C:\zirc");

            try
            {
                int chck = FindNoOfOpenWindow();
                if (chck == 1)
                {
                    opics_CHBR("84");
                    //1st time process
                    objclsfunopics.startprocess(14, 56, 100, 20, 3000, "Alt+Space+X", "");
                    objclsfunopics.startprocess(25, 56, 100, 20, 2000, "Lclick", "");
                    objclsfunopics.startprocess(25, 56, 100, 20, 7000, "Passvalue", "ZDRP");
                    objclsfunopics.startprocess(110, 57, 100, 20, 2500, "Lclick", "");
                    objclsfunopics.startprocess(14, 56, 100, 20, 3000, "Alt+Space+X", "");
                    //objclsfunopics.startprocess(158, 143, 100, 20, 2500, "Lclick", "");
                    //objclsfunopics.startprocess(158, 143, 100, 20, 2500, "Passvalue", "84");
                    objclsfunopics.startprocess(350, 141, 20, 100, 2500, "Lclick", "");
                    objclsfunopics.startprocess(350, 141, 20, 100, 2500, "Passvalue", Date);
                    objclsfunopics.startprocess(156, 173, 100, 20, 2500, "Lclick", "");
                    objclsfunopics.startprocess(156, 173, 100, 20, 2500, "Passvalue", "RPT");
                    objclsfunopics.startprocess(157, 216, 100, 20, 2500, "Lclick", "");
                    objclsfunopics.startprocess(157, 216, 100, 20, 2500, "Passvalue", @"V:\zirc");
                    //1st time process

                    objclsfunopics.startprocess(114, 79, 100, 20, 2500, "Lclick", "");//Get

                    //objclsfunopics.startprocess(505, 254, 100, 20, 2500, "Rclick", "");//Scroll Bar Option
                    //objclsfunopics.startprocess(541, 313, 100, 20, 2500, "Lclick", "");//Go To Bottom of the Grid

                    System.Data.DataTable dtx = new System.Data.DataTable();//To get ZIRC and ZNOR Position
                    string indexs = "1";//dummy Parameter for OCR screenshots (not in use currently)
                    for (int i = 0; i < 30; i++)
                    {
                        findposition("start", out dtx, indexs, reconName, "84");
                        if (dtx.Rows.Count > 0)
                        {
                            break;
                        }
                        else
                        {
                            objclsfunopics.startprocess(505, 254, 100, 20, 2500, "Rclick", "");//Scroll Bar Option
                            objclsfunopics.startprocess(540, 358, 100, 20, 2500, "Lclick", "");//Click page UP
                        }
                    }
                    for (int c = 0; c < dtx.Rows.Count; c++)
                    {
                        objclsfunopics.startprocess(190, Convert.ToInt32(dtx.Rows[c]["position"]), 100, 20, 2500, "Lclick", "");
                    }
                    objclsfunopics.startprocess(41, 80, 100, 20, 9000, "Lclick", "");//Copy
                    objclsfunopics.startprocess(39, 31, 100, 20, 2500, "Lclick", ""); //if count is one we are closing the process
                    objclsfunopics.startprocess(76, 71, 100, 20, 2500, "Lclick", ""); //Quit        

                    opics_CHBR("85");
                    //
                    objclsfunopics.startprocess(25, 56, 100, 20, 2000, "Lclick", "");
                    objclsfunopics.startprocess(25, 56, 100, 20, 7000, "Passvalue", "GRSS");
                    objclsfunopics.startprocess(110, 57, 100, 20, 2500, "Lclick", "");
                    objclsfunopics.startprocess(14, 56, 100, 20, 3000, "Alt+Space+X", "");
                    objclsfunopics.startprocess(25, 56, 100, 20, 1000, "Tab", "");
                    objclsfunopics.startprocess(14, 56, 100, 20, 2500, "Passvalue", "11");
                    Thread.Sleep(2000);
                    objclsfunopics.startprocess(14, 56, 100, 20, 2500, "Passvalue", "B85FIREC");
                    Thread.Sleep(2000);
                    objclsfunopics.startprocess(48, 79, 100, 20, 6000, "Lclick", "");
                    objclsfunopics.startprocess(39, 31, 100, 20, 2500, "Lclick", ""); //we are closing the process
                    objclsfunopics.startprocess(76, 71, 100, 20, 2500, "Lclick", "");
                    //2nd time process                    
                    objclsfunopics.startprocess(25, 56, 100, 20, 2000, "Lclick", "");
                    objclsfunopics.startprocess(25, 56, 100, 20, 7000, "Passvalue", "ZDRP");
                    objclsfunopics.startprocess(110, 57, 100, 20, 2500, "Lclick", "");
                    objclsfunopics.startprocess(14, 56, 100, 20, 3000, "Alt+Space+X", "");
                    //objclsfunopics.startprocess(158, 143, 100, 20, 2500, "Lclick", "");
                    //objclsfunopics.startprocess(158, 143, 100, 20, 2500, "Passvalue", "84");
                    //objclsfunopics.startprocess(350, 141, 20, 100, 2500, "Lclick", "");
                    //objclsfunopics.startprocess(350, 141, 20, 100, 2500, "Passvalue", Date);
                    objclsfunopics.startprocess(156, 173, 100, 20, 2500, "Lclick", "");
                    objclsfunopics.startprocess(156, 173, 100, 20, 2500, "Passvalue", "RPT");
                    objclsfunopics.startprocess(157, 216, 100, 20, 2500, "Lclick", "");
                    objclsfunopics.startprocess(157, 216, 100, 20, 2500, "Passvalue", @"V:\zirc");

                    objclsfunopics.startprocess(114, 79, 100, 20, 2500, "Lclick", "");//Get

                    //objclsfunopics.startprocess(505, 254, 100, 20, 2500, "Rclick", "");//Scroll Bar Option
                    //objclsfunopics.startprocess(541, 313, 100, 20, 2500, "Lclick", "");//Go To Bottom of the Grid

                    System.Data.DataTable dtx1 = new System.Data.DataTable();//To get ZIRC and ZNOR Position
                    string indexs1 = "1";//dummy Parameter for OCR screenshots (not in use currently)
                    for (int i = 0; i < 30; i++)
                    {
                        findposition("start", out dtx1, indexs1, reconName, "85");
                        if (dtx1.Rows.Count > 0)
                        {
                            break;
                        }
                        else
                        {
                            objclsfunopics.startprocess(505, 254, 100, 20, 2500, "Rclick", "");//Scroll Bar Option
                            objclsfunopics.startprocess(540, 358, 100, 20, 2500, "Lclick", "");//Click page UP
                        }
                    }
                    for (int c = 0; c < dtx1.Rows.Count; c++)
                    {
                        objclsfunopics.startprocess(190, Convert.ToInt32(dtx1.Rows[c]["position"]), 100, 20, 2500, "Lclick", "");
                    }
                    objclsfunopics.startprocess(41, 80, 100, 20, 9000, "Lclick", "");//Copy
                    objclsfunopics.startprocess(39, 31, 100, 20, 2500, "Lclick", ""); //if count is one we are closing the process
                    objclsfunopics.startprocess(76, 71, 100, 20, 2500, "Lclick", ""); //Quit     
                }
                result = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            return result;
        } 
        public bool opics_QueryRecons_MXPB(string con, string reconName, string opicsRegion, string Country, string Date, string Downloadpath, out string ErrorMsg)
        {
            bool result = false;
            ErrorMsg = string.Empty;
            string strQuery = string.Empty;
            string FileName = string.Empty;
            string Region = string.Empty;
            int Org_screenWidth = Screen.PrimaryScreen.Bounds.Width;
            int Org_screenHeight = Screen.PrimaryScreen.Bounds.Height;
            changeResolution(1024, 768);
            Create_Directory(@"C:\ARC\");
            Create_Directory(@"C:\ARC\" + reconName);
            Create_Directory(@"C:\ARC\" + reconName + "_ScreenShots");
            deleteFiles(@"C:\ARC\" + reconName);
            try
            {
                SqlConnection conn = new SqlConnection(con);
                SqlCommand com = new SqlCommand();
                conn.Open();
                strQuery = "select * from  Arc_opics_query where recon='" + reconName + "' and opics_Region = '" + opicsRegion + "'";
                com = new SqlCommand(strQuery, conn);
                SqlDataAdapter da = new SqlDataAdapter(com);
                System.Data.DataTable dt = new System.Data.DataTable();
                da.Fill(dt);
                conn.Close();
                string Query = string.Empty;
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    FileName = dt.Rows[i]["File_Name"].ToString();
                    Region = dt.Rows[i]["Opics_Region"].ToString();
                    if (reconName == "FX Cash Position reconciliation - FEDS vs Opics")
                    {
                        string dtimefrm = Convert.ToDateTime(Date).ToString("dd.MM.yyyy");
                        FileName = FileName.Replace("DD.MM.YYYY", dtimefrm);                        
                    }
                    else
                    {
                        string dtimefrm1 = Convert.ToDateTime(Date).ToString("ddMMyyyy");
                        FileName = FileName.Replace("DDMMYYYY", dtimefrm1);
                    }
                    if (i == 0)
                    {
                        //---1
                        Thread.Sleep(10000);
                        //objclsfunopics.startprocess(14, 56, 100, 20, 3000, "Alt+Space+x", "");
                        //ScreenCapture(@"C:\" + reconName + "_ScreenShots\\SS_1.jpeg");
                        //if (!(check_text(1, reconName)))
                        //{
                        //    ErrorMsg = "Page not Found";
                        //    return false;
                        //}
                        objclsfunopics.startprocess(25, 56, 100, 20, 2000, "Lclick", "");
                        Query = "GRSS";
                        objclsfunopics.startprocess(25, 56, 100, 20, 7000, "Passvalue", Query);
                        //MessageBox.Show(Query);
                        Query = "";
                        objclsfunopics.startprocess(110, 57, 100, 20, 4000, "Lclick", "");
                        objclsfunopics.startprocess(14, 56, 100, 20, 5000, "Alt+Space+X", "");
                        //---2
                        //ScreenCapture(@"C:\" + reconName + "_ScreenShots\\SS_2.jpeg");
                        //if (!(check_text(2, reconName)))
                        //{
                        //    ErrorMsg = "Page not Found";
                        //    return false;
                        //}
                        objclsfunopics.startprocess(130, 80, 100, 20, 4000, "Lclick", "");
                        objclsfunopics.startprocess(321, 193, 100, 20, 4000, "Lclick", "");
                        Query = dt.Rows[i]["Query"].ToString();
                        if (Query.Contains(":ReconDate"))
                        {
                            Query = Query.Replace(":ReconDate", Date);
                        }
                        objclsfunopics.startprocess(321, 193, 100, 20, 4000, "Passvalue", Query);
                        Query = "";
                        if (FileName.Contains("US_FMO_TXN"))
                        {
                            objclsfunopics.startprocess(48, 79, 100, 20, 20000, "Lclick", "");
                        }
                        else if (FileName.Contains("INDO_ONL"))
                        {
                            objclsfunopics.startprocess(48, 79, 100, 20, 20000, "Lclick", "");
                        }
                        else
                        {
                            objclsfunopics.startprocess(48, 79, 100, 20, 6000, "Lclick", "");
                        }
                        //ScreenCapture(@"C:\" + reconName + "_ScreenShots\\SS_3.jpeg");
                        //if (!(check_text(3, reconName)))
                        //{
                        //    ErrorMsg = "Page not Found";
                        //    return false;
                        //}
                        if (FileName.Contains("US_FMO_TXN"))
                        {
                            objclsfunopics.startprocess(764, 161, 100, 20, 30000, "Alt+X+E", "");
                        }
                        else
                        {
                            objclsfunopics.startprocess(764, 161, 100, 20, 7000, "Alt+X+E", "");
                        }
                        Query = @"V:\ARC\" + reconName + "\\" + FileName;
                        objclsfunopics.startprocess(203, 337, 100, 20, 7000, "Passvalue", Query);
                        Query = "";
                        objclsfunopics.startprocess(203, 337, 100, 20, 90000, "2Tab+Enter", "");
                        objclsfunopics.startprocess(650, 28, 100, 20, 4000, "Lclick", "");
                        //ScreenCapture(@"C:\" + reconName + "_ScreenShots\\SS_4.jpeg");
                        //if (!(check_text(4, reconName)))
                        //{
                        //    ErrorMsg = "Page not Found";
                        //    return false;
                        //}
                        objclsfunopics.startprocess(650, 28, 100, 20, 4000, "Alt+F+X+N", "");
                        objclsfunopics.startprocess(20, 30, 100, 20, 4000, "Alt+Q", "");
                        if (dt.Rows.Count == 1)
                        {
                            objclsfunopics.startprocess(37, 32, 100, 20, 4000, "Lclick", "");
                            objclsfunopics.startprocess(71, 73, 100, 20, 4000, "Lclick", "");
                        }
                    }
                    else if (i == dt.Rows.Count - 1)
                    {
                        //---2
                        //ScreenCapture(@"C:\" + reconName + "_ScreenShots\\SS_2.jpeg");
                        //if (!(check_text(2, reconName)))
                        //{
                        //    ErrorMsg = "Page not Found";
                        //    return false;
                        //}
                        objclsfunopics.startprocess(130, 80, 100, 20, 4000, "Lclick", "");
                        objclsfunopics.startprocess(321, 193, 100, 20, 4000, "Lclick", "");
                        Query = dt.Rows[i]["Query"].ToString();
                        if (Query.Contains(":ReconDate"))
                        {
                            Query = Query.Replace(":ReconDate", Date);
                        }
                        objclsfunopics.startprocess(321, 193, 100, 20, 4000, "Passvalue", Query);
                        Query = "";
                        if (FileName.Contains("US_FMO_TXN"))
                        {
                            objclsfunopics.startprocess(48, 79, 100, 20, 20000, "Lclick", "");
                        }
                        else if (FileName.Contains("INDO_ONL"))
                        {
                            objclsfunopics.startprocess(48, 79, 100, 20, 20000, "Lclick", "");
                        }
                        else
                        {
                            objclsfunopics.startprocess(48, 79, 100, 20, 6000, "Lclick", "");
                        }
                        //ScreenCapture(@"C:\" + reconName + "_ScreenShots\\SS_3.jpeg");
                        //if (!(check_text(3, reconName)))
                        //{
                        //    ErrorMsg = "Page not Found";
                        //    return false;
                        //}
                        if (FileName.Contains("US_FMO_TXN"))
                        {
                            objclsfunopics.startprocess(764, 161, 100, 20, 30000, "Alt+X+E", "");
                        }
                        else
                        {
                            objclsfunopics.startprocess(764, 161, 100, 20, 7000, "Alt+X+E", "");
                        }
                        Query = @"V:\ARC\" + reconName + "\\" + FileName;
                        objclsfunopics.startprocess(203, 337, 100, 20, 7000, "Passvalue", Query);
                        Query = "";
                        objclsfunopics.startprocess(203, 337, 100, 20, 90000, "2Tab+Enter", "");
                        objclsfunopics.startprocess(650, 28, 100, 20, 4000, "Lclick", "");
                        //ScreenCapture(@"C:\" + reconName + "_ScreenShots\\SS_4.jpeg");
                        //if (!(check_text(4, reconName)))
                        //{
                        //    ErrorMsg = "Page not Found";
                        //    return false;
                        //}
                        objclsfunopics.startprocess(650, 28, 100, 20, 4000, "Alt+F+X+N", "");
                        objclsfunopics.startprocess(20, 30, 100, 20, 4000, "Alt+Q", "");
                        objclsfunopics.startprocess(37, 32, 100, 20, 4000, "Lclick", "");
                        objclsfunopics.startprocess(71, 73, 100, 20, 4000, "Lclick", "");
                    }
                    else if (i > 0)
                    {
                        //---2
                        //ScreenCapture(@"C:\" + reconName + "_ScreenShots\\SS_2.jpeg");
                        //if (!(check_text(2, reconName)))
                        //{
                        //    ErrorMsg = "Page not Found";
                        //    return false;
                        //}
                        objclsfunopics.startprocess(130, 80, 100, 20, 4000, "Lclick", "");
                        objclsfunopics.startprocess(321, 193, 100, 20, 4000, "Lclick", "");
                        Query = dt.Rows[i]["Query"].ToString();
                        if (Query.Contains(":ReconDate"))
                        {
                            Query = Query.Replace(":ReconDate", Date);
                        }
                        objclsfunopics.startprocess(321, 193, 100, 20, 4000, "Passvalue", Query);
                        Query = "";
                        if (FileName.Contains("US_FMO_TXN"))
                        {
                            objclsfunopics.startprocess(48, 79, 100, 20, 20000, "Lclick", "");
                        }
                        else if (FileName.Contains("INDO_ONL"))
                        {
                            objclsfunopics.startprocess(48, 79, 100, 20, 20000, "Lclick", "");
                        }
                        else
                        {
                            objclsfunopics.startprocess(48, 79, 100, 20, 6000, "Lclick", "");
                        }
                        //ScreenCapture(@"C:\" + reconName + "_ScreenShots\\SS_3.jpeg");
                        //if (!(check_text(3, reconName)))
                        //{
                        //    ErrorMsg = "Page not Found";
                        //    return false;
                        //}
                        if (FileName.Contains("US_FMO_TXN"))
                        {
                            objclsfunopics.startprocess(764, 161, 100, 20, 30000, "Alt+X+E", "");
                        }
                        else
                        {
                            objclsfunopics.startprocess(764, 161, 100, 20, 7000, "Alt+X+E", "");
                        }
                        Query = @"V:\ARC\" + reconName + "\\" + FileName;
                        objclsfunopics.startprocess(203, 337, 100, 20, 7000, "Passvalue", Query);
                        Query = "";
                        objclsfunopics.startprocess(203, 337, 100, 20, 90000, "2Tab+Enter", "");
                        objclsfunopics.startprocess(650, 28, 100, 20, 4000, "Lclick", "");
                        //ScreenCapture(@"C:\" + reconName + "_ScreenShots\\SS_4.jpeg");
                        //if (!(check_text(4, reconName)))
                        //{
                        //    ErrorMsg = "Page not Found";
                        //    return false;
                        //}
                        objclsfunopics.startprocess(650, 28, 100, 20, 4000, "Alt+F+X+N", "");
                        objclsfunopics.startprocess(20, 30, 100, 20, 4000, "Alt+Q", "");
                    }
                }
                //                
                string dtime = DateTime.Now.ToString("dd-MMM-yyyy");
                Downloadpath = Downloadpath + dtime + "_Files" + "\\Input\\" + Region + "\\";
                //MessageBox.Show(Region);
                transferfile_opics(@"C:\ARC\" + reconName + "\\", Downloadpath, reconName);
                result = true;
            }
            catch (Exception ex)
            {
                ErrorMsg = ex.ToString();
            }
            changeResolution(Org_screenWidth, Org_screenHeight);
            return result;

        }
        public bool opics_Sophis(string con, string reconName, string opicsRegion, string Country, string Date, string Downloadpath, string FileName, out string ErrorMsg)
        {
            bool result = false;
            ErrorMsg = string.Empty;
            string strQuery = string.Empty;            
            string Region = string.Empty;
            int Org_screenWidth = Screen.PrimaryScreen.Bounds.Width;
            int Org_screenHeight = Screen.PrimaryScreen.Bounds.Height;
            //changeResolution(1024, 768);
            Create_Directory(@"C:\ARC\");
            Create_Directory(@"C:\ARC\" + reconName);
            Create_Directory(@"C:\ARC\" + reconName + "_ScreenShots");
            string screenShotPath = @"C:\ARC\" + reconName + "_ScreenShots\\";
            deleteFiles(@"C:\ARC\" + reconName);
            string LocalPath = @"V:\ARC\" + reconName+"\\";            
            try
            {
                string dtimefrm1 = Convert.ToDateTime(Date).ToString("ddMMyyyy");
                FileName = FileName.Replace("DDMMYYYY", dtimefrm1);
                //Thread.Sleep(7000);
                objclsfunopics.startprocess(283, 233, 100, 20, 5000, "Lclick", "");
                objclsfunopics.startprocess(146, 126, 100, 20, 1000, "Tab", "");//Focus OK buttom
                objclsfunopics.startprocess(146, 126, 100, 20, 1000, "Enter", "");//Click Ok button    
                //objclsfunopics.startprocess(57, 34, 100, 20, 1000, "Lclick", "");
                objclsfunopics.startprocess(146, 126, 100, 20, 1000, "Alt+E+Q", "");//Open SqlQuery Window
                objclsfunopics.startprocess(146, 126, 100, 20, 5000, "Lclick", "");//Click Open Query in SqlQuery Window
                objclsfunopics.startprocess(146, 126, 100, 20, 1000, "Tab", "");//Focus Edit buttton in EditQuery Window
                objclsfunopics.startprocess(146, 126, 100, 20, 3000, "Enter", "");//Click Edit button in EditQuery Window
                objclsfunopics.startprocess(223, 125, 100, 20, 1000, "Lclick", "");//Click Run in SqlQuery Window
                //OCR      
                int isGridLoaded = 0;
                for (int i = 0; i < 6; i++)
                {
                    if (i == 0)
                    {
                        for (int k = 0; k < 10; k++)
                        {
                            Thread.Sleep(6000);
                        }
                    }
                    else
                    {
                        for (int k = 0; k < 10; k++)
                        {
                            Thread.Sleep(2000);
                        }
                    }
                    ScreenCapture(screenShotPath + "SS_Sophis.jpg");
                    objclsImgCmp.CropImage(30, 282, 63, 15, screenShotPath + "SS_Sophis.jpg", screenShotPath + "Crp_Sophis.jpg");
                    convertGrayImages(screenShotPath + "Crp_Sophis.jpg", screenShotPath + "IColor_Sophis.jpg");
                    Bitmap bmp1 = new Bitmap(screenShotPath + "IColor_Sophis.jpg");
                    string val = "";
                    for (int y = 2; y <= 7; y++)
                    {
                        for (int x = 3; x <= 10; x++)
                        {
                            int x1 = 0;
                            if (bmp1.GetPixel(y, x).Name == "ff000000")
                            {
                                x1 = 1;
                            }
                            val = val + x1.ToString();
                        }
                    }
                    if (val == "011000101001000110010001100010011000100101000110")
                    {
                        isGridLoaded = 1;
                        break;
                    }
                }
                //OCR
                if (isGridLoaded == 1)
                {
                    objclsfunopics.startprocess(247, 127, 100, 20, 5000, "Lclick", "");//Click Export in SqlQuery Window
                    objclsfunopics.startprocess(247, 127, 100, 20, 1000, "Passvalue", FileName);//Pass FileName in Save PopUp Window
                    objclsfunopics.startprocess(146, 126, 100, 20, 1000, "Tab", "");//Start --> For Choosing Save Button
                    objclsfunopics.startprocess(146, 126, 100, 20, 1000, "Tab", "");//Next --> For Choosing Save Button
                    objclsfunopics.startprocess(146, 126, 100, 20, 10000, "Enter", "");//End --> For Choosing Save Button
                    objclsfunopics.startprocess(247, 127, 100, 20, 5000, "Lclick", "");//Click Export in SqlQuery Window again
                    for (int i = 0; i < 6; i++)
                    {
                        objclsfunopics.startprocess(146, 126, 100, 20, 1000, "Tab", "");//Start --> Select the File in Opics Path
                    }
                    objclsfunopics.startprocess(146, 126, 100, 20, 1000, "Space+S+S", "");//End --> Select the File in Opics Path
                    objclsfunopics.startprocess(146, 126, 100, 20, 1000, "Cut", "");//Cut the Selected file
                    objclsfunopics.startprocess(146, 126, 100, 20, 1000, "Tab", "");//Choose the textbox in Save PopUp Window
                    objclsfunopics.startprocess(247, 127, 100, 20, 1000, "Passvalue", LocalPath);//Pass Our Local Path
                    objclsfunopics.startprocess(146, 126, 100, 20, 3000, "Enter", "");//To get the Local window Explorer path
                    for (int i = 0; i < 6; i++)
                    {
                        objclsfunopics.startprocess(146, 126, 100, 20, 1000, "Tab", "");
                    }
                    objclsfunopics.startprocess(146, 126, 100, 20, 1000, "Space", "");
                    objclsfunopics.startprocess(146, 126, 100, 20, 90000, "Paste", "");
                    for (int i = 0; i < 4; i++)
                    {
                        objclsfunopics.startprocess(146, 126, 100, 20, 1000, "Tab", "");
                    }
                    objclsfunopics.startprocess(146, 126, 100, 20, 2000, "Enter", "");
                    objclsfunopics.startprocess(1030, 89, 100, 20, 2000, "Lclick", "");
                    objclsfunopics.startprocess(1030, 89, 100, 20, 2000, "Alt+F+Q", "");
                    objclsfunopics.startprocess(146, 126, 100, 20, 1000, "Tab", "");
                    objclsfunopics.startprocess(146, 126, 100, 20, 3000, "Enter", "");
                    string dtime = DateTime.Now.ToString("dd-MMM-yyyy");
                    Downloadpath = Downloadpath + dtime + "_Files" + "\\Input\\" + opicsRegion+"_"+Country + "\\";
                    
                    transferfile_opics(@"C:\ARC\" + reconName + "\\", Downloadpath, reconName);
                    result = true;
                }
                else
                {
                    ErrorMsg = "grid not Loaded";
                    result = false;
                }
            }
            catch (Exception ex)
            {
                ErrorMsg = ex.ToString();
            }            
            return result;
        }
        public bool opics_x()
        {
            bool result = false;            
            string strQuery = string.Empty;
            int Org_screenWidth = Screen.PrimaryScreen.Bounds.Width;
            int Org_screenHeight = Screen.PrimaryScreen.Bounds.Height;
            //changeResolution(Org_screenWidth, Org_screenHeight);
            //set common Resolution -- Start
            //changeResolution(1024, 768);
            //set common Resolution -- End
            MessageBox.Show(Clipboard.GetText());
            Thread.Sleep(5000);
            objclsfunopics.startprocess(764, 161, 100, 20, 2000, "Tab", "");
            
            objclsfunopics.startprocess(764, 161, 100, 20, 2000, "shift+tab", "");         
            //objclsfunopics.startprocess(321, 193, 100, 20, 4000, "Lclick", "");
            //objclsfunopics.startprocess(415, 294, 100, 20, 5000, "Up_Click", "");
            //objclsfunopics.startprocess(415, 294, 100, 20, 5000, "Up_Click", "");
            //objclsfunopics.startprocess(415, 294, 100, 20, 5000, "Up_Click", "");
            //objclsfunopics.startprocess(415, 294, 100, 20, 5000, "Down_Click", "");
            //objclsfunopics.startprocess(415, 294, 100, 20, 5000, "Down_Click", "");
            //objclsfunopics.startprocess(415, 294, 100, 20, 5000, "Down_Click", "");
            //objclsfunopics.startprocess(415, 294, 100, 20, 5000, "Down_Click", "");  

            //Changing Default Resolution -- Start
            MessageBox.Show("Completed");
            //Changing Default Resolution -- End
            return result;
        }
        public bool opics_Zdrp(string con, string reconName, string ApplicationName, string OpicsName, string BranchNo, string Date, string outputPath, string filename, string xmlPath, out string ErrorMsg)
        {
            bool result = false;
            ErrorMsg = string.Empty;
            Hashtable hat = new Hashtable();
            string strQuery = string.Empty;
            int Org_screenWidth = Screen.PrimaryScreen.Bounds.Width;
            int Org_screenHeight = Screen.PrimaryScreen.Bounds.Height;

            //set common Resolution -- Start
            changeResolution(1024, 768);
            //set common Resolution -- End
       
            try
            {
                SqlConnection conn = new SqlConnection(con);
                string strQuery_Pos = "";                
                string strQuery_Exec = "";
                if (ApplicationName == "OpicsAfrica")
                {
                    strQuery_Pos = "select * from ARC_Opics_ZdrpPosition_Africa";
                    strQuery_Exec = "select * from  ARC_Opics_Zdrp_Branch where opics_name='" + OpicsName + "'";
                }
                else 
                {
                    strQuery_Pos = "select * from ARC_Opics_ZdrpPosition";
                    strQuery_Exec = "select * from  ARC_Opics_Zdrp_Branch where opics_name='" + OpicsName + "'";
                }

                //Fetching
                conn.Open();
                SqlCommand com = new SqlCommand(strQuery_Exec, conn);
                SqlDataAdapter da = new SqlDataAdapter(com);
                System.Data.DataTable dt = new System.Data.DataTable();
                da.Fill(dt);
                conn.Close();

                //Fetching Position1 - Strart
                conn.Open();
                com = new SqlCommand(strQuery_Pos, conn);
                SqlDataAdapter da1 = new SqlDataAdapter(com);
                System.Data.DataTable temp = new System.Data.DataTable();
                da1.Fill(temp);
                conn.Close();
                //Fetching Position1 - End                

                string Query = "";

                int passcnt = 0;
                System.Data.DataTable dt_pos = new System.Data.DataTable();                    
                for (int j = 0; j < dt.Rows.Count; j++)
                {                    
                    passcnt = 0;
                    if (ApplicationName != "OpicsAfrica")
                    {
                        if (j == 0)
                        {
                            DataRow[] dr = temp.Select("id not in ('21','22')");
                            dt_pos = dr.CopyToDataTable();
                        }
                        else if (j == 1)
                        {
                            DataRow[] dr = temp.Select("id not in ('1','2','3','4','6','7','8','9','21','22')");
                            dt_pos = dr.CopyToDataTable();
                        }
                        else if (j == dt.Rows.Count - 1)
                        {
                            DataRow[] dr = temp.Select("id not in ('1','2','3','4','6','7','8','9')");
                            dt_pos = dr.CopyToDataTable();
                        }
                    }
                    else
                    {
                        if (j == 0)
                        {
                            DataRow[] dr = temp.Select("id not in ('23','24')");
                            dt_pos = dr.CopyToDataTable();
                        }
                        else if (j == 1)
                        {
                            DataRow[] dr = temp.Select("id not in ('1','2','3','4','6','7','8','9','23','24')");
                            dt_pos = dr.CopyToDataTable();
                        }
                        else if (j == dt.Rows.Count - 1)
                        {
                            DataRow[] dr = temp.Select("id not in ('1','2','3','4','6','7','8','9')");
                            dt_pos = dr.CopyToDataTable();
                        }
                    }
                    for (int i = 0; i < dt_pos.Rows.Count; i++)
                    {
                        if (i == 0)
                        {
                            Thread.Sleep(4000);
                        }

                        int x_axis = Convert.ToInt32(dt_pos.Rows[i][1].ToString());
                        int y_axis = Convert.ToInt32(dt_pos.Rows[i][2].ToString());
                        int ht = Convert.ToInt32(dt_pos.Rows[i][3].ToString());
                        int wd = Convert.ToInt32(dt_pos.Rows[i][4].ToString());
                        int wait = Convert.ToInt32(dt_pos.Rows[i][8].ToString());

                        string Values = dt_pos.Rows[i][9].ToString();
                        string Action = dt_pos.Rows[i][7].ToString();

                        if (Action == "Passvalue" && Values.Contains("Pass zdrp Value"))//passcnt == 0 )
                        {
                            Query = "ZDRP";
                            passcnt++;
                        }
                        else if (Action == "Passvalue" && Values.Contains("Pass the Branch Value to Get"))
                        {
                            //for (int j = passcnt; j < dt.Rows.Count - 1; j++)
                            {                                
                              Query = dt.Rows[j][4].ToString();                                
                            }
                            passcnt++;
                        }
                        else if (Action == "Passvalue" && Values.Contains("Pass the Download path of the file"))
                        {
                            Query = @"V:\zirc";

                            passcnt++;
                        }
                        else if (Action == "Passvalue" && Values.Contains("Pass the value Type location"))
                        {
                            Query = "RPT";

                            passcnt++;
                        }

                        objclsfunopics.startprocess(x_axis, y_axis, ht, wd, wait, Action, Query);
                        if (dt.Rows[j][4].ToString() == "84" && Values.Contains("Pass the Branch Value to Get"))
                        {
                            Query = "";
                            objclsfunopics.startprocess(350, 141, 20, 100, 4000, "Lclick", Query);                            
                            Query = Date;
                            objclsfunopics.startprocess(350, 141, 20, 100, 2000, "Passvalue", Query);
                        }
                        Query = "";
                    }                    
                }
                changeResolution(Org_screenWidth, Org_screenHeight);
                result = true;                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            return result;
        }
        public bool opics_Branch_Recon(string con, string reconName, string ApplicationName, string OpicsName, string BranchNo, string Date, string outputPath, string filename, string xmlPath, out string ErrorMsg)
        {
            bool result = false;
            ErrorMsg = string.Empty;
            Hashtable hat = new Hashtable();
            string strQuery = string.Empty;
            int Org_screenWidth = Screen.PrimaryScreen.Bounds.Width;
            int Org_screenHeight = Screen.PrimaryScreen.Bounds.Height;
            Create_Directory(@"C:\ARC\");
            Create_Directory(@"C:\ARC\ZIRC");
            //set common Resolution -- Start
            //changeResolution(1360, 768);
            //set common Resolution -- End
            Create_Directory(@"C:\zirc");
            try
            {
                int chck = FindNoOfOpenWindow();
                if (chck == 1)
                {
                    SqlConnection conn = new SqlConnection(con);
                    string strQuery_Exec = "";
                    if (reconName == "TRBC")
                    {
                        strQuery_Exec = "select * from  ARC_Opics_Zdrp_Branch where opics_name='" + OpicsName + "' and Branch_No in ('22','24','62','63','66','67','69','72')";
                    }
                    else if (reconName == "OPICS Sentry Position Daily" && ApplicationName == "OpicsPlus")
                    {
                        strQuery_Exec = "select * from  ARC_Opics_Zdrp_Branch where opics_name='" + OpicsName + "' and Branch_No in ('02','28','29','40','51','60','73','66','22',18) order by Branch_No";
                    }
                    else if (reconName == "OPICS Sentry Position Daily" && ApplicationName == "OpicsAfrica")
                    {
                        strQuery_Exec = "select * from  ARC_Opics_Zdrp_Branch where opics_name='" + OpicsName + "' and Branch_No in ('54')";
                    }
                    else
                    {
                        strQuery_Exec = "select * from  ARC_Opics_Zdrp_Branch where opics_name='" + OpicsName + "'";
                    }

                    //Fetching
                    conn.Open();
                    SqlCommand com = new SqlCommand(strQuery_Exec, conn);
                    SqlDataAdapter da = new SqlDataAdapter(com);
                    System.Data.DataTable dt = new System.Data.DataTable();
                    da.Fill(dt);
                    conn.Close();
                    int passcnt = 0;
                    for (int j = 0; j < dt.Rows.Count; j++)
                    {
                        passcnt = 0;
                        Thread.Sleep(4000);
                        if (ApplicationName != "OpicsAfrica")
                        {
                            if (j == 0)
                            {
                                objclsfunopics.startprocess(14, 56, 100, 20, 3000, "Alt+Space+X", "");
                                objclsfunopics.startprocess(25, 56, 100, 20, 2000, "Lclick", "");
                                objclsfunopics.startprocess(25, 56, 100, 20, 7000, "Passvalue", "ZDRP");
                                objclsfunopics.startprocess(110, 57, 100, 20, 2500, "Lclick", "");
                                objclsfunopics.startprocess(14, 56, 100, 20, 3000, "Alt+Space+X", "");
                                objclsfunopics.startprocess(158, 143, 100, 20, 2500, "Lclick", "");
                                objclsfunopics.startprocess(158, 143, 100, 20, 2500, "Passvalue", dt.Rows[j][4].ToString());
                                objclsfunopics.startprocess(156, 173, 100, 20, 2500, "Lclick", "");
                                objclsfunopics.startprocess(156, 173, 100, 20, 2500, "Passvalue", "RPT");
                                objclsfunopics.startprocess(157, 216, 100, 20, 2500, "Lclick", "");
                                objclsfunopics.startprocess(157, 216, 100, 20, 2500, "Passvalue", @"V:\zirc");
                                objclsfunopics.startprocess(114, 79, 100, 20, 2500, "Lclick", "");
                                if (reconName != "OPICS Sentry Position Daily")
                                {
                                    objclsfunopics.startprocess(502, 254, 100, 20, 2500, "Rclick", "");
                                    objclsfunopics.startprocess(547, 316, 100, 20, 2500, "Lclick", "");
                                }
                                //need to write logic
                                System.Data.DataTable dtx = new System.Data.DataTable();
                                string indexs = j.ToString();
                                findposition("start", out dtx, indexs, reconName, dt.Rows[j][4].ToString());
                                for (int c = 0; c < dtx.Rows.Count; c++)
                                {
                                    objclsfunopics.startprocess(190, Convert.ToInt32(dtx.Rows[c]["position"]), 100, 20, 2500, "Lclick", "");
                                }
                                objclsfunopics.startprocess(41, 80, 100, 20, 9000, "Lclick", "");
                                if (dt.Rows.Count == 1)
                                {
                                    objclsfunopics.startprocess(39, 31, 100, 20, 2500, "Lclick", "");
                                    objclsfunopics.startprocess(76, 71, 100, 20, 2500, "Lclick", "");
                                }
                            }
                            else if (j == dt.Rows.Count - 1)
                            {
                                objclsfunopics.startprocess(158, 143, 100, 20, 2500, "Passvalue", dt.Rows[j][4].ToString());
                                objclsfunopics.startprocess(114, 79, 100, 20, 2500, "Lclick", "");

                                if (reconName != "OPICS Sentry Position Daily")
                                {
                                    objclsfunopics.startprocess(502, 254, 100, 20, 2500, "Rclick", "");
                                    objclsfunopics.startprocess(547, 316, 100, 20, 2500, "Lclick", "");
                                    System.Data.DataTable dtx = new System.Data.DataTable();
                                    string indexs = j.ToString();
                                    findposition("start", out dtx, indexs, reconName, dt.Rows[j][4].ToString());
                                    for (int c = 0; c < dtx.Rows.Count; c++)
                                    {
                                        objclsfunopics.startprocess(190, Convert.ToInt32(dtx.Rows[c]["position"]), 100, 20, 2500, "Lclick", "");
                                    }
                                }
                                else
                                {
                                    System.Data.DataTable dtx = new System.Data.DataTable();
                                    string indexs = j.ToString();
                                    findposition("start", out dtx, indexs, reconName, dt.Rows[j][4].ToString());
                                    if (dtx.Rows.Count == 0)
                                    {
                                        objclsfunopics.startprocess(502, 254, 100, 20, 2500, "Rclick", "");
                                        objclsfunopics.startprocess(552, 358, 100, 20, 2500, "Lclick", "");
                                        findposition("start", out dtx, indexs, reconName, dt.Rows[j][4].ToString());
                                        if (dtx.Rows.Count == 0)
                                        {
                                            objclsfunopics.startprocess(502, 254, 100, 20, 2500, "Rclick", "");
                                            objclsfunopics.startprocess(552, 358, 100, 20, 2500, "Lclick", "");
                                            findposition("start", out dtx, indexs, reconName, dt.Rows[j][4].ToString());
                                            for (int c = 0; c < dtx.Rows.Count; c++)
                                            {
                                                objclsfunopics.startprocess(190, Convert.ToInt32(dtx.Rows[c]["position"]), 100, 20, 2500, "Lclick", "");
                                            }
                                        }
                                        else
                                        {
                                            for (int c = 0; c < dtx.Rows.Count; c++)
                                            {
                                                objclsfunopics.startprocess(190, Convert.ToInt32(dtx.Rows[c]["position"]), 100, 20, 2500, "Lclick", "");
                                            }
                                        }
                                    }
                                    else
                                    {
                                        for (int c = 0; c < dtx.Rows.Count; c++)
                                        {
                                            objclsfunopics.startprocess(190, Convert.ToInt32(dtx.Rows[c]["position"]), 100, 20, 2500, "Lclick", "");
                                        }
                                    }

                                }
                                //need to write logic

                                if (dt.Rows[j][4].ToString() == "84")
                                {
                                    objclsfunopics.startprocess(350, 141, 20, 100, 2500, "Lclick", "");
                                    objclsfunopics.startprocess(350, 141, 20, 100, 2500, "Passvalue", Date);
                                }
                                objclsfunopics.startprocess(41, 80, 100, 20, 9000, "Lclick", "");
                                objclsfunopics.startprocess(39, 31, 100, 20, 2500, "Lclick", "");
                                objclsfunopics.startprocess(76, 71, 100, 20, 2500, "Lclick", "");
                            }
                            else if (j > 0)
                            {
                                objclsfunopics.startprocess(158, 143, 100, 20, 2500, "Passvalue", dt.Rows[j][4].ToString());
                                objclsfunopics.startprocess(114, 79, 100, 20, 2500, "Lclick", "");
                                if (reconName != "OPICS Sentry Position Daily")
                                {
                                    objclsfunopics.startprocess(502, 254, 100, 20, 2500, "Rclick", "");
                                    objclsfunopics.startprocess(547, 316, 100, 20, 2500, "Lclick", "");
                                    System.Data.DataTable dtx = new System.Data.DataTable();
                                    string indexs = j.ToString();
                                    findposition("start", out dtx, indexs, reconName, dt.Rows[j][4].ToString());
                                    for (int c = 0; c < dtx.Rows.Count; c++)
                                    {
                                        objclsfunopics.startprocess(190, Convert.ToInt32(dtx.Rows[c]["position"]), 100, 20, 2500, "Lclick", "");
                                    }
                                }
                                else
                                {
                                    System.Data.DataTable dtx = new System.Data.DataTable();
                                    string indexs = j.ToString();
                                    findposition("start", out dtx, indexs, reconName, dt.Rows[j][4].ToString());
                                    if (dtx.Rows.Count == 0)
                                    {
                                        objclsfunopics.startprocess(502, 254, 100, 20, 2500, "Rclick", "");
                                        objclsfunopics.startprocess(552, 358, 100, 20, 2500, "Lclick", "");
                                        findposition("start", out dtx, indexs, reconName, dt.Rows[j][4].ToString());
                                        if (dtx.Rows.Count == 0)
                                        {
                                            objclsfunopics.startprocess(502, 254, 100, 20, 2500, "Rclick", "");
                                            objclsfunopics.startprocess(552, 358, 100, 20, 2500, "Lclick", "");
                                            findposition("start", out dtx, indexs, reconName, dt.Rows[j][4].ToString());
                                            for (int c = 0; c < dtx.Rows.Count; c++)
                                            {
                                                objclsfunopics.startprocess(190, Convert.ToInt32(dtx.Rows[c]["position"]), 100, 20, 2500, "Lclick", "");
                                            }
                                        }
                                        else
                                        {
                                            for (int c = 0; c < dtx.Rows.Count; c++)
                                            {
                                                objclsfunopics.startprocess(190, Convert.ToInt32(dtx.Rows[c]["position"]), 100, 20, 2500, "Lclick", "");
                                            }
                                        }
                                    }
                                    else
                                    {
                                        for (int c = 0; c < dtx.Rows.Count; c++)
                                        {
                                            objclsfunopics.startprocess(190, Convert.ToInt32(dtx.Rows[c]["position"]), 100, 20, 2500, "Lclick", "");
                                        }
                                    }

                                }
                                objclsfunopics.startprocess(41, 80, 100, 20, 9000, "Lclick", "");
                            }
                        }
                        else
                        {
                            if (j == 0)
                            {
                                objclsfunopics.startprocess(25, 56, 100, 20, 2000, "Lclick", "");
                                objclsfunopics.startprocess(25, 56, 100, 20, 7000, "Passvalue", "ZDRP");
                                objclsfunopics.startprocess(110, 57, 100, 20, 2500, "Lclick", "");
                                objclsfunopics.startprocess(14, 56, 100, 20, 5000, "Alt+Space+X", "");
                                objclsfunopics.startprocess(158, 143, 100, 20, 2500, "Lclick", "");
                                objclsfunopics.startprocess(158, 143, 100, 20, 2500, "Passvalue", dt.Rows[j][4].ToString());
                                objclsfunopics.startprocess(156, 173, 100, 20, 2500, "Lclick", "");
                                objclsfunopics.startprocess(156, 173, 100, 20, 2500, "Passvalue", "RPT");
                                objclsfunopics.startprocess(157, 216, 100, 20, 2500, "Lclick", "");
                                objclsfunopics.startprocess(157, 216, 100, 20, 2500, "Passvalue", @"V:\zirc");
                                objclsfunopics.startprocess(114, 79, 100, 20, 2500, "Lclick", "");
                                if (reconName != "OPICS Sentry Position Daily")
                                {
                                    objclsfunopics.startprocess(502, 254, 100, 20, 2500, "Rclick", "");
                                    objclsfunopics.startprocess(547, 316, 100, 20, 2500, "Lclick", "");
                                    objclsfunopics.startprocess(502, 254, 100, 20, 2500, "Rclick", "");
                                    objclsfunopics.startprocess(546, 339, 100, 20, 2500, "Lclick", "");
                                    //need to write logic
                                    System.Data.DataTable dtx = new System.Data.DataTable();
                                    string indexs = j.ToString();
                                    findposition("start", out dtx, indexs, reconName, dt.Rows[j][4].ToString());
                                    for (int c = 0; c < dtx.Rows.Count; c++)
                                    {
                                        objclsfunopics.startprocess(190, Convert.ToInt32(dtx.Rows[c]["position"]), 100, 20, 2500, "Lclick", "");
                                    }
                                }
                                else
                                {
                                    System.Data.DataTable dtx = new System.Data.DataTable();
                                    string indexs = j.ToString();
                                    findposition("start", out dtx, indexs, reconName, dt.Rows[j][4].ToString());
                                    if (dtx.Rows.Count == 0)
                                    {
                                        objclsfunopics.startprocess(502, 254, 100, 20, 2500, "Rclick", "");
                                        objclsfunopics.startprocess(552, 358, 100, 20, 2500, "Lclick", "");
                                        findposition("start", out dtx, indexs, reconName, dt.Rows[j][4].ToString());
                                        if (dtx.Rows.Count == 0)
                                        {
                                            objclsfunopics.startprocess(502, 254, 100, 20, 2500, "Rclick", "");
                                            objclsfunopics.startprocess(552, 358, 100, 20, 2500, "Lclick", "");
                                            findposition("start", out dtx, indexs, reconName, dt.Rows[j][4].ToString());
                                            if (dtx.Rows.Count == 0)
                                            {
                                                objclsfunopics.startprocess(502, 254, 100, 20, 2500, "Rclick", "");
                                                objclsfunopics.startprocess(552, 358, 100, 20, 2500, "Lclick", "");
                                                findposition("start", out dtx, indexs, reconName, dt.Rows[j][4].ToString());
                                                for (int c = 0; c < dtx.Rows.Count; c++)
                                                {
                                                    objclsfunopics.startprocess(190, Convert.ToInt32(dtx.Rows[c]["position"]), 100, 20, 2500, "Lclick", "");
                                                }
                                            }
                                            else
                                            {
                                                for (int c = 0; c < dtx.Rows.Count; c++)
                                                {
                                                    objclsfunopics.startprocess(190, Convert.ToInt32(dtx.Rows[c]["position"]), 100, 20, 2500, "Lclick", "");
                                                }
                                            }
                                        }
                                        else
                                        {
                                            for (int c = 0; c < dtx.Rows.Count; c++)
                                            {
                                                objclsfunopics.startprocess(190, Convert.ToInt32(dtx.Rows[c]["position"]), 100, 20, 2500, "Lclick", "");
                                            }
                                        }
                                    }
                                    else
                                    {
                                        for (int c = 0; c < dtx.Rows.Count; c++)
                                        {
                                            objclsfunopics.startprocess(190, Convert.ToInt32(dtx.Rows[c]["position"]), 100, 20, 2500, "Lclick", "");
                                        }
                                    }
                                }
                                objclsfunopics.startprocess(41, 80, 100, 20, 30000, "Lclick", "");
                                if (dt.Rows.Count == 1)
                                {
                                    objclsfunopics.startprocess(39, 31, 100, 20, 2500, "Lclick", "");
                                    objclsfunopics.startprocess(76, 71, 100, 20, 2500, "Lclick", "");
                                }
                            }
                            else if (j == dt.Rows.Count - 1)
                            {
                                objclsfunopics.startprocess(158, 143, 100, 20, 2500, "Passvalue", dt.Rows[j][4].ToString());
                                objclsfunopics.startprocess(114, 79, 100, 20, 2500, "Lclick", "");
                                objclsfunopics.startprocess(502, 254, 100, 20, 2500, "Rclick", "");
                                objclsfunopics.startprocess(547, 316, 100, 20, 2500, "Lclick", "");
                                objclsfunopics.startprocess(502, 254, 100, 20, 2500, "Rclick", "");
                                objclsfunopics.startprocess(546, 339, 100, 20, 2500, "Lclick", "");
                                //need to write logic  
                                System.Data.DataTable dtx = new System.Data.DataTable();
                                string indexs = j.ToString();
                                findposition("start", out dtx, indexs, reconName, dt.Rows[j][4].ToString());
                                for (int c = 0; c < dtx.Rows.Count; c++)
                                {
                                    objclsfunopics.startprocess(190, Convert.ToInt32(dtx.Rows[c]["position"]), 100, 20, 2500, "Lclick", "");
                                }
                                objclsfunopics.startprocess(41, 80, 100, 20, 30000, "Lclick", "");
                                objclsfunopics.startprocess(39, 31, 100, 20, 2500, "Lclick", "");
                                objclsfunopics.startprocess(76, 71, 100, 20, 2500, "Lclick", "");
                            }
                            else if (j > 0)
                            {
                                objclsfunopics.startprocess(158, 143, 100, 20, 2500, "Passvalue", dt.Rows[j][4].ToString());
                                objclsfunopics.startprocess(114, 79, 100, 20, 2500, "Lclick", "");
                                objclsfunopics.startprocess(502, 254, 100, 20, 2500, "Rclick", "");
                                objclsfunopics.startprocess(547, 316, 100, 20, 2500, "Lclick", "");
                                objclsfunopics.startprocess(502, 254, 100, 20, 2500, "Rclick", "");
                                objclsfunopics.startprocess(546, 339, 100, 20, 2500, "Lclick", "");
                                //need to write logic
                                System.Data.DataTable dtx = new System.Data.DataTable();
                                string indexs = j.ToString();
                                findposition("start", out dtx, indexs, reconName, dt.Rows[j][4].ToString());
                                for (int c = 0; c < dtx.Rows.Count; c++)
                                {
                                    objclsfunopics.startprocess(190, Convert.ToInt32(dtx.Rows[c]["position"]), 100, 20, 2500, "Lclick", "");
                                }
                                objclsfunopics.startprocess(41, 80, 100, 20, 30000, "Lclick", "");
                            }
                        }
                    }
                }                
                //changeResolution(Org_screenWidth, Org_screenHeight);
                result = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            return result;
        }
        public bool ZIRC_ZNOR(string con, string reconName, string ApplicationName, string OpicsName, string BranchNo, string Date, string outputPath, string filename, string xmlPath, out string ErrorMsg)
        {
            bool result = false;
            ErrorMsg = string.Empty;
            Hashtable hat = new Hashtable();
            string strQuery = string.Empty;
            int Org_screenWidth = Screen.PrimaryScreen.Bounds.Width;
            int Org_screenHeight = Screen.PrimaryScreen.Bounds.Height;
            Create_Directory(@"C:\ARC\");
            Create_Directory(@"C:\ARC\ZIRC");            
            Create_Directory(@"C:\zirc");
            
            try
            {
                int chck = FindNoOfOpenWindow();
                if (chck == 1)
                {
                    SqlConnection conn = new SqlConnection(con);
                    string strQuery_Exec = "";
                    if (reconName == "Opics ZNOR-ZIRC")
                    {
                        strQuery_Exec = "select * from  ARC_Opics_Zdrp_Branch where opics_name='" + OpicsName + "' order by id";
                    }
                    else if (reconName == "Structured Finance Position Monthly")
                    {
                        strQuery_Exec = "select * from  ARC_Opics_Zdrp_Branch where opics_name='" + OpicsName + "' and Branch_No in ('02','08','60','20','21') order by id";
                    }
                    conn.Open();
                    SqlCommand com = new SqlCommand(strQuery_Exec, conn);
                    SqlDataAdapter da = new SqlDataAdapter(com);
                    System.Data.DataTable dt = new System.Data.DataTable();
                    da.Fill(dt);
                    conn.Close();
                    for (int j = 0; j < dt.Rows.Count; j++)
                    {
                        Thread.Sleep(4000);
                        //
                        if (j == 0)
                        {
                            //1st time process
                            objclsfunopics.startprocess(14, 56, 100, 20, 3000, "Alt+Space+X", "");
                            objclsfunopics.startprocess(25, 56, 100, 20, 2000, "Lclick", "");
                            objclsfunopics.startprocess(25, 56, 100, 20, 7000, "Passvalue", "ZDRP");
                            objclsfunopics.startprocess(110, 57, 100, 20, 2500, "Lclick", "");
                            objclsfunopics.startprocess(14, 56, 100, 20, 3000, "Alt+Space+X", "");
                            objclsfunopics.startprocess(158, 143, 100, 20, 2500, "Lclick", "");
                            objclsfunopics.startprocess(158, 143, 100, 20, 2500, "Passvalue", dt.Rows[j][4].ToString());
                            objclsfunopics.startprocess(156, 173, 100, 20, 2500, "Lclick", "");
                            objclsfunopics.startprocess(156, 173, 100, 20, 2500, "Passvalue", "RPT");
                            objclsfunopics.startprocess(157, 216, 100, 20, 2500, "Lclick", "");
                            objclsfunopics.startprocess(157, 216, 100, 20, 2500, "Passvalue", @"V:\zirc");
                            //1st time process

                            objclsfunopics.startprocess(114, 79, 100, 20, 2500, "Lclick", "");//Get

                            objclsfunopics.startprocess(505, 254, 100, 20, 2500, "Rclick", "");//Scroll Bar Option
                            objclsfunopics.startprocess(541, 313, 100, 20, 2500, "Lclick", "");//Go To Bottom of the Grid

                            System.Data.DataTable dtx = new System.Data.DataTable();//To get ZIRC and ZNOR Position
                            string indexs = j.ToString();//dummy Parameter for OCR screenshots (not in use currently)
                            for (int i = 0; i < 30; i++)
                            {
                                findposition("start", out dtx, indexs, reconName, dt.Rows[j][4].ToString());
                                if (dtx.Rows.Count > 0)
                                {
                                    break;
                                }
                                else
                                {
                                    objclsfunopics.startprocess(505, 254, 100, 20, 2500, "Rclick", "");//Scroll Bar Option
                                    objclsfunopics.startprocess(540, 340, 100, 20, 2500, "Lclick", "");//Click page UP
                                }
                            }
                            for (int c = 0; c < dtx.Rows.Count; c++)
                            {
                                objclsfunopics.startprocess(190, Convert.ToInt32(dtx.Rows[c]["position"]), 100, 20, 2500, "Lclick", "");
                            }

                            objclsfunopics.startprocess(41, 80, 100, 20, 9000, "Lclick", "");//Copy
                            if (dt.Rows[j][4].ToString() == "02" || dt.Rows[j][4].ToString() == "21" || dt.Rows[j][4].ToString() == "82" || dt.Rows[j][4].ToString() == "80")
                            {
                                Thread.Sleep(6000);
                            }
                            if (dt.Rows.Count == 1)
                            {
                                objclsfunopics.startprocess(39, 31, 100, 20, 2500, "Lclick", ""); //if count is one we are closing the process
                                objclsfunopics.startprocess(76, 71, 100, 20, 2500, "Lclick", ""); //Quit
                            }
                        }
                        else if (j == dt.Rows.Count - 1)
                        {
                            objclsfunopics.startprocess(158, 143, 100, 20, 2500, "Passvalue", dt.Rows[j][4].ToString());
                            objclsfunopics.startprocess(114, 79, 100, 20, 2500, "Lclick", ""); //Get

                            objclsfunopics.startprocess(505, 254, 100, 20, 2500, "Rclick", "");//Scroll Bar Option
                            objclsfunopics.startprocess(541, 313, 100, 20, 2500, "Lclick", "");//Go To Bottom of the Grid

                            System.Data.DataTable dtx = new System.Data.DataTable();//To get ZIRC and ZNOR Position
                            string indexs = j.ToString();//dummy Parameter for OCR screenshots 
                            for (int i = 0; i < 30; i++)
                            {
                                findposition("start", out dtx, indexs, reconName, dt.Rows[j][4].ToString());
                                if (dtx.Rows.Count > 0)
                                {
                                    break;
                                }
                                else
                                {
                                    objclsfunopics.startprocess(505, 254, 100, 20, 2500, "Rclick", "");//Scroll Bar Option
                                    objclsfunopics.startprocess(540, 340, 100, 20, 2500, "Lclick", "");//Click page UP
                                }
                            }
                            for (int c = 0; c < dtx.Rows.Count; c++)
                            {
                                objclsfunopics.startprocess(190, Convert.ToInt32(dtx.Rows[c]["position"]), 100, 20, 2500, "Lclick", "");
                            }
                            objclsfunopics.startprocess(41, 80, 100, 20, 9000, "Lclick", "");
                            if (dt.Rows[j][4].ToString() == "02" || dt.Rows[j][4].ToString() == "21" || dt.Rows[j][4].ToString() == "82" || dt.Rows[j][4].ToString() == "80")
                            {
                                Thread.Sleep(6000);
                            }
                            objclsfunopics.startprocess(39, 31, 100, 20, 2500, "Lclick", "");
                            objclsfunopics.startprocess(76, 71, 100, 20, 2500, "Lclick", "");
                        }
                        else if (j > 0)
                        {
                            objclsfunopics.startprocess(158, 143, 100, 20, 2500, "Passvalue", dt.Rows[j][4].ToString());

                            if (dt.Rows[j][4].ToString() == "84")//Recon Date for Branch 84 and 85
                            {
                                objclsfunopics.startprocess(350, 141, 20, 100, 2500, "Lclick", "");
                                objclsfunopics.startprocess(350, 141, 20, 100, 2500, "Passvalue", Date);
                            }

                            objclsfunopics.startprocess(114, 79, 100, 20, 2500, "Lclick", "");//Get

                            objclsfunopics.startprocess(505, 254, 100, 20, 2500, "Rclick", "");//Scroll Bar Option
                            objclsfunopics.startprocess(541, 313, 100, 20, 2500, "Lclick", "");//Go To Bottom of the Grid

                            System.Data.DataTable dtx = new System.Data.DataTable();//To get ZIRC and ZNOR Position
                            string indexs = j.ToString();//dummy Parameter for OCR screenshots (not in use currently)
                            for (int i = 0; i < 30; i++)
                            {
                                findposition("start", out dtx, indexs, reconName, dt.Rows[j][4].ToString());
                                if (dtx.Rows.Count > 0)
                                {
                                    break;
                                }
                                else
                                {
                                    objclsfunopics.startprocess(505, 254, 100, 20, 2500, "Rclick", "");//Scroll Bar Option
                                    objclsfunopics.startprocess(540, 340, 100, 20, 2500, "Lclick", "");//Click page UP
                                }
                            }
                            for (int c = 0; c < dtx.Rows.Count; c++)
                            {
                                objclsfunopics.startprocess(190, Convert.ToInt32(dtx.Rows[c]["position"]), 100, 20, 2500, "Lclick", "");
                            }
                            objclsfunopics.startprocess(41, 80, 100, 20, 9000, "Lclick", "");
                            if (dt.Rows[j][4].ToString() == "02" || dt.Rows[j][4].ToString() == "21" || dt.Rows[j][4].ToString() == "82" || dt.Rows[j][4].ToString() == "80")
                            {
                                Thread.Sleep(6000);
                            }
                        }
                    }
                }                                               
                result = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            return result;
        }        
        
        //public void deleteAll(string path)
        //{
        //    try
        //    {
        //        Process process = Process.GetProcessesByName("Crp_ZDRP");
        //        process.Kill();
        //        //string[] filePaths = Directory.GetFiles(path);
        //        //foreach (string filePath in filePaths)
        //        //{
        //        //    FileStream fs = System.IO.File.Open(filePath, FileMode.OpenOrCreate, FileAccess.Read, FileShare.None);
        //        //    fs.Close();
        //        //    File.Delete(filePath);
        //        //}
        //    }
        //    catch (Exception ex)
        //    {
        //        MessageBox.Show(ex.ToString());
        //    }
            
        //}
        public System.Data.DataTable XmlTodt(string Path)
        {            
            System.Data.DataTable dt = new System.Data.DataTable();
            DataSet ds = new DataSet();
            ds.ReadXml(Path);
            dt = ds.Tables[0];
            return dt;
        }
        public void Create_Directory(string pathString)
        {
            if(!(System.IO.Directory.Exists(pathString)))
            {
                System.IO.Directory.CreateDirectory(pathString);
            }
        }        
        #region prnToxlsConvertor
        public bool prnTOxlsConvertor(string InputPRNPath, string InputXLpath, string OutputFilePath, string sheetName, string ReconName, out string ErrorMsg)
        {
            System.Data.DataTable dt = new System.Data.DataTable();
            object misValue = Type.Missing;
            int maxCount = 0;
            bool result = false;
            ErrorMsg = string.Empty;
            try
            {
                if (File.Exists(InputXLpath))
                {
                    File.Delete(InputXLpath);
                }
                if (File.Exists(OutputFilePath))
                {
                    File.Delete(OutputFilePath);
                }
                File.Copy(InputPRNPath, InputXLpath, false);


                Microsoft.Office.Interop.Excel.Application app = new Microsoft.Office.Interop.Excel.Application();
                Excel.Workbook xlWorkbook = app.Workbooks.Open(InputXLpath, Type.Missing, false, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                Excel.Worksheet xlWorksheet = (Excel.Worksheet)xlWorkbook.Worksheets.get_Item(1);

                app.DisplayAlerts = false;
                app.Visible = false;

                Excel.Range rng = xlWorksheet.UsedRange;

                dt.Columns.Add();
                for (int i = 1; i <= rng.Rows.Count; i++)
                {
                    dt.Rows.Add();
                    for (int j = 1; j <= rng.Columns.Count; j++)
                    {
                        //object xval = ((Excel.Range)xlWorksheet.Cells[i, j]).Value2;
                        dt.Rows[i - 1][j - 1] = ((Excel.Range)xlWorksheet.Cells[i, j]).Value2.ToString();
                    }
                }

                int cntdt = dt.Rows.Count;
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    int count = dt.Rows[0][0].ToString().Split(new string[] { ",\"" }, StringSplitOptions.None).Length - 1;
                    if (count > maxCount)
                        maxCount = count;
                }
                int noColumns = maxCount + 1;

                System.Data.DataTable dt_final = new System.Data.DataTable();

                for (int i = 0; i < noColumns; i++)
                {
                    dt_final.Columns.Add(i.ToString());
                }

                dt_final.Rows.Add();

                if ((ReconName == "Malaysia Failed Trade") || (ReconName == "India Failed Trade" && sheetName.Contains("IndiaFailTrade0")) || (ReconName == "India Failed Trade" && sheetName.Contains("IndiaFailTrade1")) || (ReconName == "FX Cash Position reconciliation - FEDS vs Opics") || (ReconName == "Structured Finance Position Monthly") || (ReconName == "US FMO Suspense" && sheetName.Contains("US_FMO_Balance")) || (ReconName == "UK FMO Suspense") || (ReconName == "Indonesia Failed Trade"))
                {
                    if (dt_final.Columns.Count != 5)
                    {
                        if ((ReconName == "Malaysia Failed Trade") || (ReconName == "FX Cash Position reconciliation - FEDS vs Opics") || (ReconName == "Structured Finance Position Monthly") || (ReconName == "US FMO Suspense" && sheetName.Contains("US_FMO_Balance")) || (ReconName == "UK FMO Suspense") || (ReconName == "Indonesia Failed Trade"))
                        {
                            ErrorMsg = "Column Count does not matched in" + ReconName + " Recon";
                            return result;
                        }
                        else
                        {
                            ErrorMsg = "Column Count does not matched in India Fail Trade Working0or1 of India Fail Trade Recon";
                            return result;
                        }
                    }
                }
                else if ((ReconName == "Indonesia Failed Trade online" && sheetName.Contains("INDO_ONL_ALL")))
                {
                    if (dt_final.Columns.Count != 36)
                    {
                        ErrorMsg = "Column Count does not matched in INDO_ONL_ALL of Indonesia Failed Trade online";
                        return result;
                    }
                }
                else if ((ReconName == "Indonesia Failed Trade online" && sheetName.Contains("INDO_ONL_HLD")))
                {
                    if (dt_final.Columns.Count != 18)
                    {
                        ErrorMsg = "Column Count does not matched in INDO_ONL_HLD of Indonesia Failed Trade online";
                        return result;
                    }
                }
                else if ((ReconName == "Indonesia Failed Trade online" && sheetName.Contains("INDO_ONL_NEW")))
                {
                    if (dt_final.Columns.Count != 14)
                    {
                        ErrorMsg = "Column Count does not matched in INDO_ONL_NEW of Indonesia Failed Trade online";
                        return result;
                    }
                }
                else if ((ReconName == "Indonesia Failed Trade online" && sheetName.Contains("INDO_ONL_REV")))
                {
                    if (dt_final.Columns.Count != 18)
                    {
                        ErrorMsg = "Column Count does not matched in INDO_ONL_REV of Indonesia Failed Trade online";
                        return result;
                    }
                }
                else if ((ReconName == "India Failed Trade" && sheetName.Contains("IndiaFailTrade2")))
                {
                    if (dt_final.Columns.Count != 18)
                    {
                        ErrorMsg = "Column Count does not matched in India Fail Trade Working2 of India Failed Trade Recon";
                        return result;
                    }
                }
                else if ((ReconName == "India Failed Trade" && sheetName.Contains("IndiaFailTrade3")))
                {
                    if (dt_final.Columns.Count != 14)
                    {
                        ErrorMsg = "Column Count does not matched in" + ReconName + "Recon";
                        return result;
                    }
                }
                else if ((ReconName == "India Failed Trade" && sheetName.Contains("IndiaFailTrade4")))
                {
                    if (dt_final.Columns.Count != 12)
                    {
                        ErrorMsg = "Column Count does not matched in India Fail Trade Working4 of India Failed Trade Recon";
                        return result;
                    }
                }
                else if ((ReconName == "India Failed Trade" && sheetName.Contains("IndiaFailTrade5")))
                {
                    if (dt_final.Columns.Count != 18)
                    {
                        ErrorMsg = "Column Count does not matched in" + ReconName + " Recon";
                        return result;
                    }
                }
                else if ((ReconName == "India Failed Trade" && sheetName.Contains("IndiaFailTrade6")))
                {
                    if (dt_final.Columns.Count != 36)
                    {
                        ErrorMsg = "Column Count does not matched in India Fail Trade Working6 of India Failed Trade Recon";
                        return result;
                    }
                }
                else if (ReconName == "Malaysia Failed Trade Online")
                {
                    if (sheetName.Contains("Malaysia_NEW_DEALS"))
                    {
                        if (dt_final.Columns.Count != 17)
                        {
                            ErrorMsg = "Column Count does not matched in Malaysia_NEW_DEALS of Malaysia Failed Trade Online";
                            return result;
                        }
                    }
                    else if (sheetName.Contains("Malaysia_REVERSAL"))
                    {
                        if (dt_final.Columns.Count != 14)
                        {
                            ErrorMsg = "Column Count does not matched in Malaysia_REVERSAL of Malaysia Failed Trade Online";
                            return result;
                        }
                    }
                    else if (sheetName.Contains("Malaysia_NEW_FORMAT"))
                    {
                        if (dt_final.Columns.Count != 12)
                        {
                            ErrorMsg = "Column Count does not matched in Malaysia_NEW_FORMAT of Malaysia Failed Trade Online";
                            return result;
                        }
                    }
                    else if (sheetName.Contains("Malaysia_ALL_QUERY"))
                    {
                        if (dt_final.Columns.Count != 36)
                        {
                            ErrorMsg = "Column Count does not matched in Malaysia_ALL_QUERY of Malaysia Failed Trade Online";
                            return result;
                        }
                    }
                    
                }
                else if (ReconName == "MXPB file")
                {
                    if (dt_final.Columns.Count != 36)
                    {
                        ErrorMsg = "Column Count does not matched in MXPB file Recon";
                        return result;
                    }
                }
                else if (ReconName == "Srilanka - Position Balancing")
                {
                    if (dt_final.Columns.Count != 7)
                    {
                        ErrorMsg = "Column Count does not matched in Srilanka - Position Balancing Recon";
                        return result;
                    }
                }
                else if ((ReconName == "US FMO Suspense" && sheetName.Contains("US_FMO_TXN")))
                {
                    if (dt_final.Columns.Count != 11)
                    {
                        ErrorMsg = "Column Count does not matched in US_FMO_TXN";
                        return result;
                    }

                }
                else if (ReconName == "Structured Funding  - BTS VS Custody")
                {
                    if (dt_final.Columns.Count != 23)
                    {
                        ErrorMsg = "Column Count does not matched in Structured Funding  - BTS VS Custody Recon";
                        return result;
                    }
                }
                if ((ReconName == "Malaysia Failed Trade") || (ReconName == "Structured Finance Position Monthly") ||(ReconName == "India Failed Trade" && sheetName.Contains("IndiaFailTrade0")) || (ReconName == "India Failed Trade" && sheetName.Contains("IndiaFailTrade1")) || (ReconName == "FX Cash Position reconciliation - FEDS vs Opics") || (ReconName == "US FMO Suspense" && sheetName.Contains("US_FMO_Balance")) || (ReconName == "UK FMO Suspense") || (ReconName == "Indonesia Failed Trade"))
                {
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        string[] data = dt.Rows[i][0].ToString().Split(new string[] { ",\"" }, StringSplitOptions.None);
                        DataRow dr_final = dt_final.NewRow();
                        for (int j = 0; j < data.Length; j++)
                        {
                            data[j] = data[j].Replace('"', ' ');
                            if (j == data.Length - 1)
                            {
                                dr_final[j] = (Convert.ToDecimal(data[j]).ToString("#,##0.##").Trim().Contains(".")) ? Convert.ToDecimal(data[j]).ToString("#,##0.##").Trim() : (Convert.ToDecimal(data[j]).ToString("#,##0.##").Trim() + ".00"); // .ToString("#,##0.##");                              
                            }
                            else
                            {
                                dr_final[j] = data[j].Trim();
                            }

                        }

                        dt_final.Rows.Add(dr_final);
                    }
                }
                else if (ReconName == "Malaysia Failed Trade Online")
                {
                    if (sheetName.Contains("Malaysia_NEW_DEALS"))
                    {
                        for (int i = 0; i < dt.Rows.Count; i++)
                        {
                            string[] data = dt.Rows[i][0].ToString().Split(new string[] { ",\"" }, StringSplitOptions.None);
                            DataRow dr_final = dt_final.NewRow();
                            for (int j = 0; j < data.Length; j++)
                            {
                                data[j] = data[j].Replace('"', ' ');
                                if (j == 4||j==5||j==7)
                                {
                                    dr_final[j] = (Convert.ToDecimal(data[j]).ToString("#,##0.##").Trim().Contains(".")) ? Convert.ToDecimal(data[j]).ToString("#,##0.##").Trim() : (Convert.ToDecimal(data[j]).ToString("#,##0.##").Trim() + ".00"); // .ToString("#,##0.##");                              
                                }
                                else
                                {
                                    dr_final[j] = data[j].Trim();
                                }

                            }

                            dt_final.Rows.Add(dr_final);
                        }
                    }
                    else if (sheetName.Contains("Malaysia_REVERSAL"))
                    {
                        for (int i = 0; i < dt.Rows.Count; i++)
                        {
                            string[] data = dt.Rows[i][0].ToString().Split(new string[] { ",\"" }, StringSplitOptions.None);
                            DataRow dr_final = dt_final.NewRow();
                            for (int j = 0; j < data.Length; j++)
                            {
                                data[j] = data[j].Replace('"', ' ');
                                if (j == 4 || j == 7)
                                {
                                    dr_final[j] = (Convert.ToDecimal(data[j]).ToString("#,##0.##").Trim().Contains(".")) ? Convert.ToDecimal(data[j]).ToString("#,##0.##").Trim() : (Convert.ToDecimal(data[j]).ToString("#,##0.##").Trim() + ".00"); // .ToString("#,##0.##");                              
                                }
                                else
                                {
                                    dr_final[j] = data[j].Trim();
                                }

                            }

                            dt_final.Rows.Add(dr_final);
                        }
                    }
                    else if (sheetName.Contains("Malaysia_NEW_FORMAT"))
                    {
                        for (int i = 0; i < dt.Rows.Count; i++)
                        {
                            string[] data = dt.Rows[i][0].ToString().Split(new string[] { ",\"" }, StringSplitOptions.None);
                            DataRow dr_final = dt_final.NewRow();
                            for (int j = 0; j < data.Length; j++)
                            {
                                data[j] = data[j].Replace('"', ' ');
                                dr_final[j] = data[j].Trim();
                            }

                            dt_final.Rows.Add(dr_final);
                        }
                    }
                    else if (sheetName.Contains("Malaysia_ALL_QUERY"))
                    {
                        for (int i = 0; i < dt.Rows.Count; i++)
                        {
                            string[] data = dt.Rows[i][0].ToString().Split(new string[] { ",\"" }, StringSplitOptions.None);
                            DataRow dr_final = dt_final.NewRow();
                            for (int j = 0; j < data.Length; j++)
                            {
                                data[j] = data[j].Replace('"', ' ');
                                if (j == 12 || j == 14)
                                {
                                    dr_final[j] = (Convert.ToDecimal(data[j]).ToString("#,##0.##").Trim().Contains(".")) ? Convert.ToDecimal(data[j]).ToString("#,##0.##").Trim() : (Convert.ToDecimal(data[j]).ToString("#,##0.##").Trim() + ".00"); // .ToString("#,##0.##");                              
                                }
                                else
                                {
                                    dr_final[j] = data[j].Trim();
                                }

                            }

                            dt_final.Rows.Add(dr_final);
                        }
                    }

                }
                else if (ReconName == "Structured Funding  - BTS VS Custody")
                {
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        string[] data = dt.Rows[i][0].ToString().Split(new string[] { ",\"" }, StringSplitOptions.None);
                        DataRow dr_final = dt_final.NewRow();
                        for (int j = 0; j < data.Length; j++)
                        {
                            data[j] = data[j].Replace('"', ' ');
                            if (j == 5)
                            {
                                dr_final[j] = (Convert.ToDecimal(data[j]).ToString("#,##0.##").Trim().Contains(".")) ? Convert.ToDecimal(data[j]).ToString("#,##0.##").Trim() : (Convert.ToDecimal(data[j]).ToString("#,##0.##").Trim() + ".00"); // .ToString("#,##0.##");                              
                            }
                            else
                            {
                                dr_final[j] = data[j].Trim();
                            }
                        }
                        dt_final.Rows.Add(dr_final);
                    }
                }
                else if ((ReconName == "Indonesia Failed Trade online" && sheetName.Contains("INDO_ONL_ALL")))
                {
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        string[] data = dt.Rows[i][0].ToString().Split(new string[] { ",\"" }, StringSplitOptions.None);
                        DataRow dr_final = dt_final.NewRow();
                        for (int j = 0; j < data.Length; j++)
                        {
                            data[j] = data[j].Replace('"', ' ');
                            if (j == 12 || j == 14 || j == 15)
                            {
                                dr_final[j] = (Convert.ToDecimal(data[j]).ToString("#,##0.##").Trim().Contains(".")) ? Convert.ToDecimal(data[j]).ToString("#,##0.##").Trim() : (Convert.ToDecimal(data[j]).ToString("#,##0.##").Trim() + ".00"); // .ToString("#,##0.##");                              
                            }
                            else if (j == 15)
                            {
                                dr_final[j] = (Convert.ToDecimal(data[j]).ToString("#,##0.########").Trim().Contains(".")) ? Convert.ToDecimal(data[j]).ToString("#,##0.##").Trim() : (Convert.ToDecimal(data[j]).ToString("#,##0.##").Trim() + ".00"); // .ToString("#,##0.##");                              
                            }
                            else
                            {
                                dr_final[j] = data[j].Trim();
                            }

                        }

                        dt_final.Rows.Add(dr_final);
                    }
                }
                else if ((ReconName == "Indonesia Failed Trade online" && sheetName.Contains("INDO_ONL_HLD")))
                {
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        string[] data = dt.Rows[i][0].ToString().Split(new string[] { ",\"" }, StringSplitOptions.None);
                        DataRow dr_final = dt_final.NewRow();
                        for (int j = 0; j < data.Length; j++)
                        {
                            data[j] = data[j].Replace('"', ' ');
                            if (j == 4 || j == 6 || j == 7 || j == 15)
                            {
                                dr_final[j] = (Convert.ToDecimal(data[j]).ToString("#,##0.##").Trim().Contains(".")) ? Convert.ToDecimal(data[j]).ToString("#,##0.##").Trim() : (Convert.ToDecimal(data[j]).ToString("#,##0.##").Trim() + ".00"); // .ToString("#,##0.##");                              
                            }
                            else if (j == 7)
                            {
                                dr_final[j] = (Convert.ToDecimal(data[j]).ToString("#,##0.########").Trim().Contains(".")) ? Convert.ToDecimal(data[j]).ToString("#,##0.##").Trim() : (Convert.ToDecimal(data[j]).ToString("#,##0.##").Trim() + ".00"); // .ToString("#,##0.##");                              
                            }
                            else
                            {
                                dr_final[j] = data[j].Trim();
                            }

                        }

                        dt_final.Rows.Add(dr_final);
                    }
                }
                else if ((ReconName == "Indonesia Failed Trade online" && sheetName.Contains("INDO_ONL_NEW")))
                {
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        string[] data = dt.Rows[i][0].ToString().Split(new string[] { ",\"" }, StringSplitOptions.None);
                        DataRow dr_final = dt_final.NewRow();
                        for (int j = 0; j < data.Length; j++)
                        {
                            data[j] = data[j].Replace('"', ' ');
                            if (j == 4 || j == 7)
                            {
                                dr_final[j] = (Convert.ToDecimal(data[j]).ToString("#,##0.##").Trim().Contains(".")) ? Convert.ToDecimal(data[j]).ToString("#,##0.##").Trim() : (Convert.ToDecimal(data[j]).ToString("#,##0.##").Trim() + ".00"); // .ToString("#,##0.##");                              
                            }
                            else if (j == 0)
                            {
                                dr_final[j] = (Convert.ToDecimal(data[j]).ToString("#,##0.########").Trim().Contains(".")) ? Convert.ToDecimal(data[j]).ToString("#,##0.##").Trim() : (Convert.ToDecimal(data[j]).ToString("#,##0.##").Trim() + ".00"); // .ToString("#,##0.##");                              
                            }
                            else
                            {
                                dr_final[j] = data[j].Trim();
                            }

                        }

                        dt_final.Rows.Add(dr_final);
                    }
                }
                else if ((ReconName == "Indonesia Failed Trade online" && sheetName.Contains("INDO_ONL_REV")))
                {
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        string[] data = dt.Rows[i][0].ToString().Split(new string[] { ",\"" }, StringSplitOptions.None);
                        DataRow dr_final = dt_final.NewRow();
                        for (int j = 0; j < data.Length; j++)
                        {
                            data[j] = data[j].Replace('"', ' ');
                            if (j == 4 || j == 7 || j == 16)
                            {
                                dr_final[j] = (Convert.ToDecimal(data[j]).ToString("#,##0.##").Trim().Contains(".")) ? Convert.ToDecimal(data[j]).ToString("#,##0.##").Trim() : (Convert.ToDecimal(data[j]).ToString("#,##0.##").Trim() + ".00"); // .ToString("#,##0.##");                              
                            }
                            else if (j == 9)
                            {
                                dr_final[j] = (Convert.ToDecimal(data[j]).ToString("#,##0.########").Trim().Contains(".")) ? Convert.ToDecimal(data[j]).ToString("#,##0.##").Trim() : (Convert.ToDecimal(data[j]).ToString("#,##0.##").Trim() + ".00"); // .ToString("#,##0.##");                              
                            }
                            else
                            {
                                dr_final[j] = data[j].Trim();
                            }

                        }

                        dt_final.Rows.Add(dr_final);
                    }
                }
                    //
                else if ((ReconName == "India Failed Trade" && sheetName.Contains("IndiaFailTrade2")))
                {
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        string[] data = dt.Rows[i][0].ToString().Split(new string[] { ",\"" }, StringSplitOptions.None);
                        DataRow dr_final = dt_final.NewRow();
                        for (int j = 0; j < data.Length; j++)
                        {
                            data[j] = data[j].Replace('"', ' ');
                            if (j == 4 || j == 7 || j == 16)
                            {
                                dr_final[j] = (Convert.ToDecimal(data[j]).ToString("#,##0.##").Trim().Contains(".")) ? Convert.ToDecimal(data[j]).ToString("#,##0.##").Trim() : (Convert.ToDecimal(data[j]).ToString("#,##0.##").Trim() + ".00"); // .ToString("#,##0.##");                              
                            }
                            else
                            {
                                dr_final[j] = data[j].Trim();
                            }

                        }

                        dt_final.Rows.Add(dr_final);
                    }
                }
                else if ((ReconName == "India Failed Trade" && sheetName.Contains("IndiaFailTrade3")))
                {
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        string[] data = dt.Rows[i][0].ToString().Split(new string[] { ",\"" }, StringSplitOptions.None);
                        DataRow dr_final = dt_final.NewRow();
                        for (int j = 0; j < data.Length; j++)
                        {
                            data[j] = data[j].Replace('"', ' ');
                            if (j == 4 || j == 7)
                            {
                                dr_final[j] = (Convert.ToDecimal(data[j]).ToString("#,##0.##").Trim().Contains(".")) ? Convert.ToDecimal(data[j]).ToString("#,##0.##").Trim() : (Convert.ToDecimal(data[j]).ToString("#,##0.##").Trim() + ".00"); // .ToString("#,##0.##");                              
                            }
                            else
                            {
                                dr_final[j] = data[j].Trim();
                            }

                        }

                        dt_final.Rows.Add(dr_final);
                    }
                }
                else if ((ReconName == "India Failed Trade" && sheetName.Contains("IndiaFailTrade4")))
                {
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        string[] data = dt.Rows[i][0].ToString().Split(new string[] { ",\"" }, StringSplitOptions.None);
                        DataRow dr_final = dt_final.NewRow();
                        for (int j = 0; j < data.Length; j++)
                        {
                            data[j] = data[j].Replace('"', ' ');
                            dr_final[j] = data[j].Trim();
                        }
                        dt_final.Rows.Add(dr_final);
                    }
                }
                else if ((ReconName == "India Failed Trade" && sheetName.Contains("IndiaFailTrade5")))
                {
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        string[] data = dt.Rows[i][0].ToString().Split(new string[] { ",\"" }, StringSplitOptions.None);
                        DataRow dr_final = dt_final.NewRow();
                        for (int j = 0; j < data.Length; j++)
                        {
                            data[j] = data[j].Replace('"', ' ');
                            if (j == 4 || j == 6 || j == 15)
                            {
                                dr_final[j] = (Convert.ToDecimal(data[j]).ToString("#,##0.##").Trim().Contains(".")) ? Convert.ToDecimal(data[j]).ToString("#,##0.##").Trim() : (Convert.ToDecimal(data[j]).ToString("#,##0.##").Trim() + ".00"); // .ToString("#,##0.##");                              
                            }
                            else
                            {
                                dr_final[j] = data[j].Trim();
                            }

                        }

                        dt_final.Rows.Add(dr_final);
                    }
                }
                else if ((ReconName == "India Failed Trade" && sheetName.Contains("IndiaFailTrade6")))
                {
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        string[] data = dt.Rows[i][0].ToString().Split(new string[] { ",\"" }, StringSplitOptions.None);
                        DataRow dr_final = dt_final.NewRow();
                        for (int j = 0; j < data.Length; j++)
                        {
                            data[j] = data[j].Replace('"', ' ');
                            if (j == 12 || j == 14)
                            {
                                dr_final[j] = (Convert.ToDecimal(data[j]).ToString("#,##0.##").Trim().Contains(".")) ? Convert.ToDecimal(data[j]).ToString("#,##0.##").Trim() : (Convert.ToDecimal(data[j]).ToString("#,##0.##").Trim() + ".00"); // .ToString("#,##0.##");                              
                            }
                            else
                            {
                                dr_final[j] = data[j].Trim();
                            }
                        }
                        dt_final.Rows.Add(dr_final);
                    }
                }
                else if (ReconName == "MXPB file")
                {
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        string[] data = dt.Rows[i][0].ToString().Split(new string[] { ",\"" }, StringSplitOptions.None);
                        DataRow dr_final = dt_final.NewRow();
                        for (int j = 0; j < data.Length; j++)
                        {
                            data[j] = data[j].Replace('"', ' ');
                            if (j == 21 || j == 23)
                            {
                                dr_final[j] = (Convert.ToDecimal(data[j]).ToString("#,##0.##").Trim().Contains(".")) ? Convert.ToDecimal(data[j]).ToString("#,##0.##").Trim() : (Convert.ToDecimal(data[j]).ToString("#,##0.##").Trim() + ".00"); // .ToString("#,##0.##");                              
                            }
                            else
                            {
                                dr_final[j] = data[j].Trim();
                            }
                        }
                        dt_final.Rows.Add(dr_final);
                    }
                }
                else if (ReconName == "Srilanka - Position Balancing")
                {
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        string[] data = dt.Rows[i][0].ToString().Split(new string[] { ",\"" }, StringSplitOptions.None);
                        DataRow dr_final = dt_final.NewRow();
                        for (int j = 0; j < data.Length; j++)
                        {
                            data[j] = data[j].Replace('"', ' ');
                            if (j == 5)
                            {
                                dr_final[j] = (Convert.ToDecimal(data[j]).ToString("#,##0.##").Trim().Contains(".")) ? Convert.ToDecimal(data[j]).ToString("#,##0.##").Trim() : (Convert.ToDecimal(data[j]).ToString("#,##0.##").Trim() + ".00"); // .ToString("#,##0.##");                              
                            }
                            else
                            {
                                dr_final[j] = data[j].Trim();
                            }
                        }
                        dt_final.Rows.Add(dr_final);
                    }
                }
                else if ((ReconName == "US FMO Suspense" && sheetName.Contains("US_FMO_TXN")))
                {

                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        string[] data = dt.Rows[i][0].ToString().Split(new string[] { ",\"" }, StringSplitOptions.None);
                        DataRow dr_final = dt_final.NewRow();
                        for (int j = 0; j < data.Length; j++)
                        {
                            data[j] = data[j].Replace('"', ' ');
                            if (j == 7)
                            {
                                dr_final[j] = (Convert.ToDecimal(data[j]).ToString("#,##0.##").Trim().Contains(".")) ? Convert.ToDecimal(data[j]).ToString("#,##0.##").Trim() : (Convert.ToDecimal(data[j]).ToString("#,##0.##").Trim() + ".00"); // .ToString("#,##0.##");                              
                            }
                            else
                            {
                                dr_final[j] = data[j].Trim();
                            }
                        }
                        dt_final.Rows.Add(dr_final);
                    }

                }
                else if ((ReconName == "INDO_ONL_NEW"))
                {
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        string[] data = dt.Rows[i][0].ToString().Split(new string[] { ",\"" }, StringSplitOptions.None);
                        DataRow dr_final = dt_final.NewRow();
                        for (int j = 0; j < data.Length; j++)
                        {
                            data[j] = data[j].Replace('"', ' ');
                            if (j == 4 || j == 7 || j == 9)
                            {
                                dr_final[j] = (Convert.ToDecimal(data[j]).ToString("#,##0.##").Trim().Contains(".")) ? Convert.ToDecimal(data[j]).ToString("#,##0.##").Trim() : (Convert.ToDecimal(data[j]).ToString("#,##0.##").Trim() + ".00"); // .ToString("#,##0.##");                              
                            }
                            else
                            {
                                dr_final[j] = data[j].Trim();
                            }
                        }
                        dt_final.Rows.Add(dr_final);
                    }

                }
                else if (ReconName == "INDO_ONL_REV")
                {
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        string[] data = dt.Rows[i][0].ToString().Split(new string[] { ",\"" }, StringSplitOptions.None);
                        DataRow dr_final = dt_final.NewRow();
                        for (int j = 0; j < data.Length; j++)
                        {
                            data[j] = data[j].Replace('"', ' ');
                            if (j == 4 || j == 7 || j == 9 || j == 16)
                            {
                                dr_final[j] = (Convert.ToDecimal(data[j]).ToString("#,##0.##").Trim().Contains(".")) ? Convert.ToDecimal(data[j]).ToString("#,##0.##").Trim() : (Convert.ToDecimal(data[j]).ToString("#,##0.##").Trim() + ".00"); // .ToString("#,##0.##");                              
                            }
                            else
                            {
                                dr_final[j] = data[j].Trim();
                            }
                        }
                        dt_final.Rows.Add(dr_final);
                    }
                }
                // //
                int cnt = dt_final.Rows.Count;
                xlWorkbook.Close(false, misValue, misValue);
                app.Quit();
                Marshal.ReleaseComObject(xlWorksheet);
                Marshal.ReleaseComObject(xlWorkbook);
                Marshal.ReleaseComObject(app);

                Microsoft.Office.Interop.Excel.Application excel;
                Microsoft.Office.Interop.Excel.Workbook workbook;
                Microsoft.Office.Interop.Excel.Worksheet worksheet;

                excel = new Microsoft.Office.Interop.Excel.Application();
                excel.Visible = false;
                excel.DisplayAlerts = false;
                workbook = excel.Workbooks.Add(Type.Missing);
                worksheet = (Microsoft.Office.Interop.Excel.Worksheet)workbook.ActiveSheet;
                worksheet.Name = sheetName.Replace(".Prn","");

                if ((ReconName == "Malaysia Failed Trade") || (ReconName == "India Failed Trade" && sheetName.Contains("IndiaFailTrade0")) || (ReconName == "India Failed Trade" && sheetName.Contains("IndiaFailTrade1")) || (ReconName == "Indonesia Failed Trade"))
                {
                    worksheet.Cells[1, 1] = "BR";
                    worksheet.Cells[1, 2] = "GLNO";
                    worksheet.Cells[1, 3] = "COSTCENT";
                    worksheet.Cells[1, 4] = "CCY";
                    worksheet.Cells[1, 5] = "AMCLSG";
                }
                else if (ReconName == "Malaysia Failed Trade Online")
                {
                    if (sheetName.Contains("Malaysia_NEW_DEALS"))
                    {
                        worksheet.Cells[1, 1] = "BR";
                        worksheet.Cells[1, 2] = "DEALNO";
                        worksheet.Cells[1, 3] = "SN";
                        worksheet.Cells[1, 4] = "CCY";
                        worksheet.Cells[1, 5] = "CCYAMT";
                        worksheet.Cells[1, 6] = "";
                        worksheet.Cells[1, 7] = "CTRCCY";
                        worksheet.Cells[1, 8] = "CTRAMT";
                        worksheet.Cells[1, 9] = "CCYRATE_8";
                        worksheet.Cells[1, 10] = "DEALDATE";
                        worksheet.Cells[1, 11] = "VDATE";
                        worksheet.Cells[1, 12] = "TRAD";
                        worksheet.Cells[1, 13] = "COST";
                        worksheet.Cells[1, 14] = "DEALTEXT";
                        worksheet.Cells[1, 15] = "CNO";
                        worksheet.Cells[1, 16] = "CCYSMEANS";
                        worksheet.Cells[1, 17] = "CTRSMEANS";
                    }
                    else if (sheetName.Contains("Malaysia_REVERSAL"))
                    {
                        worksheet.Cells[1, 1] = "BR";
                        worksheet.Cells[1, 2] = "DEALNO";
                        worksheet.Cells[1, 3] = "SN";
                        worksheet.Cells[1, 4] = "CCY";
                        worksheet.Cells[1, 5] = "CCYAMT";
                        worksheet.Cells[1, 6] = "CCYSMEANS";
                        worksheet.Cells[1, 7] = "CTRCCY";
                        worksheet.Cells[1, 8] = "CTRAMT";
                        worksheet.Cells[1, 9] = "CTRSMEANS";
                        worksheet.Cells[1, 10] = "CCYRATE_8";
                        worksheet.Cells[1, 11] = "COST";
                        worksheet.Cells[1, 12] = "DEALDATE";
                        worksheet.Cells[1, 13] = "VDATE";
                        worksheet.Cells[1, 14] = "SPOTTRAD";
                        
                    }
                    else if (sheetName.Contains("Malaysia_NEW_FORMAT"))
                    {                        
                        worksheet.Cells[1, 1] = "DEALNO";
                        worksheet.Cells[1, 2] = "SN";
                        worksheet.Cells[1, 3] = "";
                        worksheet.Cells[1, 4] = "";
                        worksheet.Cells[1, 5] = "BRNAME";
                        worksheet.Cells[1, 6] = "";
                        worksheet.Cells[1, 7] = "CNO";
                        worksheet.Cells[1, 8] = "CFN1";
                        worksheet.Cells[1, 9] = "CCODE";
                        worksheet.Cells[1, 10] = "";
                        worksheet.Cells[1, 11] = "ACCTRELMGR";
                        worksheet.Cells[1, 12] = "INTERFACEDEALNO";                        
                    }
                    else if (sheetName.Contains("Malaysia_ALL_QUERY"))
                    {                        
                        worksheet.Cells[1, 1] = "STATUS";
                        worksheet.Cells[1, 2] = "AGE_DAYS";
                        worksheet.Cells[1, 3] = "DEAL_TYPE";
                        worksheet.Cells[1, 4] = "PRODTYPE";
                        worksheet.Cells[1, 5] = "BRNAME";
                        worksheet.Cells[1, 6] = "TRADE_TYPE";
                        worksheet.Cells[1, 7] = "DEALNO";
                        worksheet.Cells[1, 8] = "CUST";
                        worksheet.Cells[1, 9] = "SN";
                        worksheet.Cells[1, 10] = "CFN1";
                        worksheet.Cells[1, 11] = "CCODE";
                        worksheet.Cells[1, 12] = "CCY";
                        worksheet.Cells[1, 13] = "CCYAMT";
                        worksheet.Cells[1, 14] = "CTRCCY";
                        worksheet.Cells[1, 15] = "CTRAMT";
                        worksheet.Cells[1, 16] = "CCYRATE_8";
                        worksheet.Cells[1, 17] = "CCYSMEANS";
                        worksheet.Cells[1, 18] = "CTRSMEANS";
                        worksheet.Cells[1, 19] = "INPUTDATE";
                        worksheet.Cells[1, 20] = "DEALDATE";
                        worksheet.Cells[1, 21] = "VDATE";
                        worksheet.Cells[1, 22] = "PAYAUTHDTE";
                        worksheet.Cells[1, 23] = "RECAUTHDTE";
                        worksheet.Cells[1, 24] = "DEALTEXT";
                        worksheet.Cells[1, 25] = "PORTFOLIO";
                        worksheet.Cells[1, 26] = "TRAD";
                        worksheet.Cells[1, 27] = "TRADNAME";
                        worksheet.Cells[1, 28] = "INTERFACEDEALNO";
                        worksheet.Cells[1, 29] = "ACCTRELMGR";
                        worksheet.Cells[1, 30] = "CCISNO";
                        worksheet.Cells[1, 31] = "SPOTTRAD";
                        worksheet.Cells[1, 32] = "COST";
                        worksheet.Cells[1, 33] = "AGE_WORKING_DAYS";
                        worksheet.Cells[1, 34] = "BRANCH_CLASSIFICATION";
                        worksheet.Cells[1, 35] = "DEALER_TYPE";
                        worksheet.Cells[1, 36] = "CCY_PAIR";
                    }

                }
                else if (ReconName == "Structured Funding  - BTS VS Custody")
                {
                    worksheet.Cells[1, 1] = "DEAL NO";
                    worksheet.Cells[1, 2] = "PRODUCT";
                    worksheet.Cells[1, 3] = "TYPE";
                    worksheet.Cells[1, 4] = "CUSTOMER";
                    worksheet.Cells[1, 5] = "CCY";
                    worksheet.Cells[1, 6] = "CCY AMOUNT";
                    worksheet.Cells[1, 7] = "RATE CODE";
                    worksheet.Cells[1, 8] = "INTEREST RATE";
                    worksheet.Cells[1, 9] = "MAT. DATE";
                    worksheet.Cells[1, 10] = "REVERSAL DATE";
                    worksheet.Cells[1, 11] = "REVERSAL REASON";
                    worksheet.Cells[1, 12] = "NEW DEAL NO";
                    worksheet.Cells[1, 13] = "VALUE DATE";
                    worksheet.Cells[1, 14] = "PORTFOLIO";
                    worksheet.Cells[1, 15] = "LINKED DEAL NO.";
                    worksheet.Cells[1, 16] = "STRATEGY";
                    worksheet.Cells[1, 17] = "FUNDING RATE";
                    worksheet.Cells[1, 18] = "FUND CENTER";
                    worksheet.Cells[1, 19] = "COST CENTER";
                    worksheet.Cells[1, 20] = "TRADER";
                    worksheet.Cells[1, 21] = "CORPORATE TRADER";
                    worksheet.Cells[1, 22] = "CORPORATE PORTFOLIO";
                    worksheet.Cells[1, 23] = "FRONT END DEAL NUMBER";
                }
                else if ((ReconName == "Indonesia Failed Trade online" && sheetName.Contains("INDO_ONL_ALL")))
                {
                    worksheet.Cells[1, 1] = "STATUS";
                    worksheet.Cells[1, 2] = "AGE_DAYS";
                    worksheet.Cells[1, 3] = "DEAL_TYPE";
                    worksheet.Cells[1, 4] = "PRODTYPE";
                    worksheet.Cells[1, 5] = "BRNAME";
                    worksheet.Cells[1, 6] = "TRADE_TYPE";
                    worksheet.Cells[1, 7] = "DEALNO";
                    worksheet.Cells[1, 8] = "CUST";
                    worksheet.Cells[1, 9] = "SN";
                    worksheet.Cells[1, 10] = "CFN1";
                    worksheet.Cells[1, 11] = "CCODE";
                    worksheet.Cells[1, 12] = "CCY";
                    worksheet.Cells[1, 13] = "CCYAMT";
                    worksheet.Cells[1, 14] = "CTRCCY";
                    worksheet.Cells[1, 15] = "CTRAMT";
                    worksheet.Cells[1, 16] = "CCYRATE_8";
                    worksheet.Cells[1, 17] = "CCYSMEANS";
                    worksheet.Cells[1, 18] = "CTRSMEANS";
                    worksheet.Cells[1, 19] = "INPUTDATE";
                    worksheet.Cells[1, 20] = "DEALDATE";
                    worksheet.Cells[1, 21] = "VDATE";
                    worksheet.Cells[1, 22] = "PAYAUTHDTE";
                    worksheet.Cells[1, 23] = "RECAUTHDTE";
                    worksheet.Cells[1, 24] = "DEALTEXT";
                    worksheet.Cells[1, 25] = "PORTFOLIO";
                    worksheet.Cells[1, 26] = "TRAD";
                    worksheet.Cells[1, 27] = "TRADNAME";
                    worksheet.Cells[1, 28] = "INTERFACEDEALNO";
                    worksheet.Cells[1, 29] = "ACCTRELMGR";
                    worksheet.Cells[1, 30] = "CCISNO";
                    worksheet.Cells[1, 31] = "SPOTTRAD";
                    worksheet.Cells[1, 32] = "COST";
                    worksheet.Cells[1, 33] = "AGE_WORKING_DAYS";
                    worksheet.Cells[1, 34] = "BRANCH_CLASSIFICATION";
                    worksheet.Cells[1, 35] = "DEALER_TYPE";
                    worksheet.Cells[1, 36] = "CCY_PAIR";
                }
                else if ((ReconName == "Indonesia Failed Trade online" && sheetName.Contains("INDO_ONL_HLD")))
                {
                    worksheet.Cells[1, 1] = "BR";
                    worksheet.Cells[1, 2] = "DEALNO";
                    worksheet.Cells[1, 3] = "SN";
                    worksheet.Cells[1, 4] = "CCY";
                    worksheet.Cells[1, 5] = "CCYAMT";
                    worksheet.Cells[1, 6] = "CTRCCY";
                    worksheet.Cells[1, 7] = "CTRAMT";
                    worksheet.Cells[1, 8] = "CCYRATE_8";
                    worksheet.Cells[1, 9] = "COST";
                    worksheet.Cells[1, 10] = "VDATE";
                    worksheet.Cells[1, 11] = "DEALDATE";
                    worksheet.Cells[1, 12] = "TRAD";
                    worksheet.Cells[1, 13] = "INTERFACEDEALNO";
                    worksheet.Cells[1, 14] = "CCYSMEANS";
                    worksheet.Cells[1, 15] = "CTRSMEANS";
                    worksheet.Cells[1, 16] = "CCYBAMT";
                    worksheet.Cells[1, 17] = "ACCTRELMGR";
                    worksheet.Cells[1, 18] = "CNO";
                }
                else if ((ReconName == "Indonesia Failed Trade online" && sheetName.Contains("INDO_ONL_NEW")))
                {
                    worksheet.Cells[1, 1] = "BR";
                    worksheet.Cells[1, 2] = "DEALNO";
                    worksheet.Cells[1, 3] = "SN";
                    worksheet.Cells[1, 4] = "CCY";
                    worksheet.Cells[1, 5] = "CCYAMT";
                    worksheet.Cells[1, 6] = "CCYSMEANS";
                    worksheet.Cells[1, 7] = "CTRCCY";
                    worksheet.Cells[1, 8] = "CTRAMT";
                    worksheet.Cells[1, 9] = "CTRSMEANS";
                    worksheet.Cells[1, 10] = "CCYRATE_8";
                    worksheet.Cells[1, 11] = "COST";
                    worksheet.Cells[1, 12] = "DEALDATE";
                    worksheet.Cells[1, 13] = "VDATE";
                    worksheet.Cells[1, 14] = "SPOTTRAD";                    
                }
                else if ((ReconName == "Indonesia Failed Trade online" && sheetName.Contains("INDO_ONL_REV")))
                {
                    worksheet.Cells[1, 1] = "BR";
                    worksheet.Cells[1, 2] = "DEALNO";
                    worksheet.Cells[1, 3] = "SN";
                    worksheet.Cells[1, 4] = "CCY";
                    worksheet.Cells[1, 5] = "CCYAMT";
                    worksheet.Cells[1, 6] = "CCYSMEANS";
                    worksheet.Cells[1, 7] = "CTRCCY";
                    worksheet.Cells[1, 8] = "CTRAMT";
                    worksheet.Cells[1, 9] = "CTRSMEANS";
                    worksheet.Cells[1, 10] = "CCYRATE_8";
                    worksheet.Cells[1, 11] = "COST";
                    worksheet.Cells[1, 12] = "SPOTTRAD";
                    worksheet.Cells[1, 13] = "DEALDATE";
                    worksheet.Cells[1, 14] = "INTERFACEDEALNO";
                    worksheet.Cells[1, 15] = "VDATE";
                    worksheet.Cells[1, 16] = "TRAD";
                    worksheet.Cells[1, 17] = "";
                    worksheet.Cells[1, 18] = "CNO";
                }
                    //
                else if (ReconName == "India Failed Trade" && sheetName.Contains("IndiaFailTrade2"))
                {
                    worksheet.Cells[1, 1] = "BR";
                    worksheet.Cells[1, 2] = "DEALNO";
                    worksheet.Cells[1, 3] = "SN";
                    worksheet.Cells[1, 4] = "CCY";
                    worksheet.Cells[1, 5] = "CCYAMT";
                    worksheet.Cells[1, 6] = "CCYSMEANS";
                    worksheet.Cells[1, 7] = "CTRCCY";
                    worksheet.Cells[1, 8] = "CTRAMT";
                    worksheet.Cells[1, 9] = "CTRSMEANS";
                    worksheet.Cells[1, 10] = "CCYRATE_8";
                    worksheet.Cells[1, 11] = "COST";
                    worksheet.Cells[1, 12] = "SPOTTRAD";
                    worksheet.Cells[1, 13] = "DEALDATE";
                    worksheet.Cells[1, 14] = "INTERFACEDEALNO";
                    worksheet.Cells[1, 15] = "VDATE";
                    worksheet.Cells[1, 16] = "TRAD";
                    worksheet.Cells[1, 17] = "";
                    worksheet.Cells[1, 18] = "CNO";
                }
                else if ((ReconName == "India Failed Trade" && sheetName.Contains("IndiaFailTrade3")))
                {
                    worksheet.Cells[1, 1] = "BR";
                    worksheet.Cells[1, 2] = "DEALNO";
                    worksheet.Cells[1, 3] = "SN";
                    worksheet.Cells[1, 4] = "CCY";
                    worksheet.Cells[1, 5] = "CCYAMT";
                    worksheet.Cells[1, 6] = "CCYSMEANS";
                    worksheet.Cells[1, 7] = "CTRCCY";
                    worksheet.Cells[1, 8] = "CTRAMT";
                    worksheet.Cells[1, 9] = "CTRSMEANS";
                    worksheet.Cells[1, 10] = "CCYRATE_8";
                    worksheet.Cells[1, 11] = "COST";
                    worksheet.Cells[1, 12] = "DEALDATE";
                    worksheet.Cells[1, 13] = "VDATE";
                    worksheet.Cells[1, 14] = "SPOTTRAD";
                }
                else if (ReconName == "India Failed Trade" && sheetName.Contains("IndiaFailTrade4"))
                {
                    worksheet.Cells[1, 1] = "DEALNO";
                    worksheet.Cells[1, 2] = "SN";
                    worksheet.Cells[1, 3] = "";
                    worksheet.Cells[1, 4] = "PRODTYPE";
                    worksheet.Cells[1, 5] = "BRNAME";
                    worksheet.Cells[1, 6] = "TRADE_TYPE";
                    worksheet.Cells[1, 7] = "CNO";
                    worksheet.Cells[1, 8] = "CFN1";
                    worksheet.Cells[1, 9] = "CCODE";
                    worksheet.Cells[1, 10] = "";
                    worksheet.Cells[1, 11] = "ACCTRELMGR";
                    worksheet.Cells[1, 12] = "INTERFACEDEALNO";
                }
                else if (ReconName == "India Failed Trade" && sheetName.Contains("IndiaFailTrade5"))
                {
                    worksheet.Cells[1, 1] = "BR";
                    worksheet.Cells[1, 2] = "DEALNO";
                    worksheet.Cells[1, 3] = "SN";
                    worksheet.Cells[1, 4] = "CCY";
                    worksheet.Cells[1, 5] = "CCYAMT";
                    worksheet.Cells[1, 6] = "CTRCCY";
                    worksheet.Cells[1, 7] = "CTRAMT";
                    worksheet.Cells[1, 8] = "CCYRATE_8";
                    worksheet.Cells[1, 9] = "COST";
                    worksheet.Cells[1, 10] = "VDATE";
                    worksheet.Cells[1, 11] = "DEALDATE";
                    worksheet.Cells[1, 12] = "TRAD";
                    worksheet.Cells[1, 13] = "INTERFACEDEALNO";
                    worksheet.Cells[1, 14] = "CCYSMEANS";
                    worksheet.Cells[1, 15] = "CTRSMEANS";
                    worksheet.Cells[1, 16] = "CCYBAMT";
                    worksheet.Cells[1, 17] = "ACCTRELMGR";
                    worksheet.Cells[1, 18] = "CNO";
                }

                else if (ReconName == "India Failed Trade" && sheetName.Contains("IndiaFailTrade6"))
                {
                    worksheet.Cells[1, 1] = "STATUS";
                    worksheet.Cells[1, 2] = "AGE_DAYS";
                    worksheet.Cells[1, 3] = "DEAL_TYPE";
                    worksheet.Cells[1, 4] = "PRODTYPE";
                    worksheet.Cells[1, 5] = "BRNAME";
                    worksheet.Cells[1, 6] = "TRADE_TYPE";
                    worksheet.Cells[1, 7] = "DEALNO";
                    worksheet.Cells[1, 8] = "CUST";
                    worksheet.Cells[1, 9] = "SN";
                    worksheet.Cells[1, 10] = "CFN1";
                    worksheet.Cells[1, 11] = "CCODE";
                    worksheet.Cells[1, 12] = "CCY";
                    worksheet.Cells[1, 13] = "CCYAMT";
                    worksheet.Cells[1, 14] = "CTRCCY";
                    worksheet.Cells[1, 15] = "CTRAMT";
                    worksheet.Cells[1, 16] = "CCYRATE_8";
                    worksheet.Cells[1, 17] = "CCYSMEANS";
                    worksheet.Cells[1, 18] = "CTRSMEANS";
                    worksheet.Cells[1, 19] = "INPUTDATE";
                    worksheet.Cells[1, 20] = "DEALDATE";
                    worksheet.Cells[1, 21] = "VDATE";
                    worksheet.Cells[1, 22] = "PAYAUTHDTE";
                    worksheet.Cells[1, 23] = "RECAUTHDTE";
                    worksheet.Cells[1, 24] = "DEALTEXT";
                    worksheet.Cells[1, 25] = "PORTFOLIO";
                    worksheet.Cells[1, 26] = "TRAD";
                    worksheet.Cells[1, 27] = "TRADNAME";
                    worksheet.Cells[1, 28] = "INTERFACEDEALNO";
                    worksheet.Cells[1, 29] = "ACCTRELMGR";
                    worksheet.Cells[1, 30] = "CCISNO";
                    worksheet.Cells[1, 31] = "SPOTTRAD";
                    worksheet.Cells[1, 32] = "COST";
                    worksheet.Cells[1, 33] = "AGE_WORKING_DAYS";
                    worksheet.Cells[1, 34] = "BRANCH_CLASSIFICATION";
                    worksheet.Cells[1, 35] = "DEALER_TYPE";
                    worksheet.Cells[1, 36] = "CCY_PAIR";
                }
                else if (ReconName == "MXPB file")
                {
                    worksheet.Cells[1, 1] = "AMENDDATE";
                    worksheet.Cells[1, 2] = "BR";
                    worksheet.Cells[1, 3] = "DEALNO";
                    worksheet.Cells[1, 4] = "SEQ";
                    worksheet.Cells[1, 5] = "VDATE";
                    worksheet.Cells[1, 6] = "CUST";
                    worksheet.Cells[1, 7] = "CMNE";
                    worksheet.Cells[1, 8] = "SN";
                    worksheet.Cells[1, 9] = "PORT";
                    worksheet.Cells[1, 10] = "COST";
                    worksheet.Cells[1, 11] = "DEALDATE";
                    worksheet.Cells[1, 12] = "DEALTIME";
                    worksheet.Cells[1, 13] = "DEALTEXT";
                    worksheet.Cells[1, 14] = "PRODCODE";
                    worksheet.Cells[1, 15] = "SWAPDEAL";
                    worksheet.Cells[1, 16] = "FARNEARIND";
                    worksheet.Cells[1, 17] = "SWAPVDATE";
                    worksheet.Cells[1, 18] = "INPUTDATE";
                    worksheet.Cells[1, 19] = "INPUTTIME";
                    worksheet.Cells[1, 20] = "LSTMNTDATE";
                    worksheet.Cells[1, 21] = "CCY";
                    worksheet.Cells[1, 22] = "CCYAMT";
                    worksheet.Cells[1, 23] = "CTRCCY";
                    worksheet.Cells[1, 24] = "CTRAMT";
                    worksheet.Cells[1, 25] = "CCYRATE_8";
                    worksheet.Cells[1, 26] = "BRPRCINDTE";
                    worksheet.Cells[1, 27] = "REVDATE";
                    worksheet.Cells[1, 28] = "REVREASON";
                    worksheet.Cells[1, 29] = "PRODTYPE";
                    worksheet.Cells[1, 30] = "BRCOST";
                    worksheet.Cells[1, 31] = "LINKDEALNO";
                    worksheet.Cells[1, 32] = "PS";
                    worksheet.Cells[1, 33] = "TRAD";
                    worksheet.Cells[1, 34] = "INTERFACEDEALNO";
                    worksheet.Cells[1, 35] = "";
                    worksheet.Cells[1, 36] = "";
                }
                else if (ReconName == "Srilanka - Position Balancing")
                {
                    worksheet.Cells[1, 1] = "BR";
                    worksheet.Cells[1, 2] = "GLNO";
                    worksheet.Cells[1, 3] = "DESCR";
                    worksheet.Cells[1, 4] = "COSTCENT";
                    worksheet.Cells[1, 5] = "CCY";
                    worksheet.Cells[1, 6] = "AMCLSG";
                    worksheet.Cells[1, 7] = "EXTACCT";
                }
                //SA 1577308
                else if ((ReconName == "FX Cash Position reconciliation - FEDS vs Opics") || (ReconName == "Structured Finance Position Monthly") || (ReconName == "US FMO Suspense" && sheetName.Contains("US_FMO_Balance")) || (ReconName == "UK FMO Suspense") || (ReconName == "Structured Finance Position Monthly"))
                {
                    worksheet.Cells[1, 1] = "BR";
                    worksheet.Cells[1, 2] = "GLNO";
                    worksheet.Cells[1, 3] = "COSTCENT";
                    worksheet.Cells[1, 4] = "CCY";
                    worksheet.Cells[1, 5] = "AMCLSG";

                }
                else if ((ReconName == "US FMO Suspense" && sheetName.Contains("US_FMO_TXN")))
                {
                    worksheet.Cells[1, 1] = "EFFDATE";
                    worksheet.Cells[1, 2] = "POSTDATE";
                    worksheet.Cells[1, 3] = "BR";
                    worksheet.Cells[1, 4] = "PRODUCT";
                    worksheet.Cells[1, 5] = "GLNO";
                    worksheet.Cells[1, 6] = "COSTCENT";
                    worksheet.Cells[1, 7] = "CCY";
                    worksheet.Cells[1, 8] = "AMOUNT";
                    worksheet.Cells[1, 9] = "DRCRIND";
                    worksheet.Cells[1, 10] = "DEALNO";
                    worksheet.Cells[1, 11] = "CMNE";

                }                
                //EA 1577308
                if (dt_final.Columns.Count > 0)
                {
                    Microsoft.Office.Interop.Excel.Range formatrangeS1;
                    string colS1 = "F" + (dt_final.Rows.Count + 1).ToString();
                    formatrangeS1 = worksheet.get_Range("F1", colS1);
                    formatrangeS1.NumberFormat = "@";
                    Microsoft.Office.Interop.Excel.Range formatrangeS2;
                    string colS2 = "L" + (dt_final.Rows.Count + 1).ToString();
                    formatrangeS2 = worksheet.get_Range("L1", colS2);
                    formatrangeS2.NumberFormat = "@";
                    for (int C = 0; C < dt_final.Columns.Count; C++)
                    {
                        for (int r = 0; r < dt_final.Rows.Count; r++)
                        {
                            worksheet.Cells[r + 2, C + 1] = dt_final.Rows[r][C].ToString();
                        }
                    }
                }
                workbook.SaveAs(OutputFilePath, Microsoft.Office.Interop.Excel.XlFileFormat.xlWorkbookDefault, misValue, misValue, misValue, misValue, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);
                workbook.Close(false, misValue, misValue);
                excel.Quit();
                Marshal.ReleaseComObject(worksheet);
                Marshal.ReleaseComObject(worksheet);
                Marshal.ReleaseComObject(excel);
                result = true;
            }
            catch (Exception ex)
            {
                ErrorMsg = ex.ToString();
            }
            return result;
        }
        #endregion #region prnToxlsConvertor
        public void call_prnxlsConvertor(string ReconDate, string DownloadPath)
        {
            string dtimefrm = DateTime.Now.ToString("dd-MMM-yyyy");
            string Dwnpath = "";
            string InputPRNPath = "";
            string InputXLpath = "";
            string OutputFilePath = "";
            string OutputPRNPath = "";
            string ErrorMsg = "";
            string reconName = "";
            for(int j=0;j<3;j++)
            {
                if(j==0)
                {
                    Dwnpath = DownloadPath + dtimefrm + "_Files" + "\\Input\\OpicsPlus\\";
                    if (!(System.IO.Directory.Exists(Dwnpath + "PrnFiles\\")))
                    {
                        System.IO.Directory.CreateDirectory(Dwnpath + "PrnFiles\\");
                    }
                    string[] CrystalFilePaths = Directory.GetFiles(Dwnpath, @"*.Prn");
                    foreach (var filePath in CrystalFilePaths)
                    {
                        reconName = "";
                        var FileName = Path.GetFileName(filePath);
                        InputPRNPath = Dwnpath + FileName;
                        OutputPRNPath = Dwnpath + "PrnFiles\\" + FileName;
                        InputXLpath = InputPRNPath.Replace(".Prn", "_UN.xls");
                        OutputFilePath = InputXLpath.Replace("_UN", "");
                        
                        if (FileName.Contains("IndiaFailTrade"))
                        {
                            reconName = "India Failed Trade";
                        }
                        else if (FileName.Contains("INDO_ONL"))
                        {
                            reconName = "Indonesia Failed Trade online";
                        }
                        else if (FileName.Contains("OPICS_IDN"))
                        {
                            reconName = "Indonesia Failed Trade";
                        }
                        else if (FileName.Contains("MYS_TRIAL"))
                        {
                            reconName = "Malaysia Failed Trade";
                        }
                        else if (FileName.Contains("OPICS_TH") || FileName.Contains("OPICS_TW"))
                        {
                            reconName = "FX Cash Position reconciliation - FEDS vs Opics";
                        }
                        else if (FileName.Contains("US_FMO"))
                        {
                            reconName = "US FMO Suspense";
                        }
                        else if (FileName.Contains("UK_FMO"))
                        {
                            reconName = "UK FMO Suspense";
                        }
                        else if (FileName.Contains("Malaysia"))
                        {
                            reconName = "Malaysia Failed Trade Online";
                        }
                        else if (FileName.Contains("Structured_FIN"))
                        {
                            reconName = "Structured Finance Position Monthly";
                        }
                        else if (FileName.Contains("STRUCT_OPICS"))
                        {
                            reconName = "Structured Funding  - BTS VS Custody";
                        }
                        bool x = prnTOxlsConvertor(InputPRNPath, InputXLpath, OutputFilePath, FileName, reconName, out ErrorMsg);
                        if (reconName == "Structured Funding  - BTS VS Custody")
                        {                            
                            string f_path1 = Dwnpath + "STRUCT_OPICS_1_" + Convert.ToDateTime(ReconDate).ToString("ddMMyy")+".xls";
                            string f_path1_UN = Dwnpath + "STRUCT_OPICS_1_" + Convert.ToDateTime(ReconDate).ToString("ddMMyy")+"_UN"+".xls";
                            string f_path1_Prn = Dwnpath + "STRUCT_OPICS_1_" + Convert.ToDateTime(ReconDate).ToString("ddMMyy") +".Prn";
                            string f_path1_OutPrn = Dwnpath + "PrnFiles\\" + "STRUCT_OPICS_1_" + Convert.ToDateTime(ReconDate).ToString("ddMMyy") + ".Prn";
                            string sheet1 = "STRUCT_OPICS_1_" + Convert.ToDateTime(ReconDate).ToString("ddMMyy")+"$";
                            string f_path2 = Dwnpath + "STRUCT_OPICS_2_" + Convert.ToDateTime(ReconDate).ToString("ddMMyy") + ".xls";                            
                            string f_path2_UN = Dwnpath + "STRUCT_OPICS_2_" + Convert.ToDateTime(ReconDate).ToString("ddMMyy")+"_UN" + ".xls";
                            string f_path2_Prn = Dwnpath + "STRUCT_OPICS_2_" + Convert.ToDateTime(ReconDate).ToString("ddMMyy") + ".Prn";
                            string f_path2_OutPrn = Dwnpath + "PrnFiles\\" + "STRUCT_OPICS_2_" + Convert.ToDateTime(ReconDate).ToString("ddMMyy") + ".Prn";
                            string sheet2 = "STRUCT_OPICS_2_" + Convert.ToDateTime(ReconDate).ToString("ddMMyy") + "$";
                            string f_path = f_path1.Replace("1_","");
                            string sheet = sheet1.Replace("1_", "");                            
                            if (File.Exists(f_path1))
                            {
                                if (File.Exists(f_path2))
                                {
                                    System.Data.DataTable Dt_input1 = new System.Data.DataTable();
                                    System.Data.DataTable Dt_input2 = new System.Data.DataTable();
                                    System.Data.DataTable Dt_out = new System.Data.DataTable();
                                    OleDbConnection connection;
                                    OleDbDataAdapter Command;
                                    connection = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + f_path1 + @";Extended Properties=""Excel 8.0;IMEX=1;HDR=NO;TypeGuessRows=0;ImportMixedTypes=Text""");
                                    connection.Open();
                                    System.Data.DataTable schemaTable = connection.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, new object[] { null, null, null, "TABLE" });
                                    System.Data.DataRow schemaRow = schemaTable.Rows[0];                                    
                                    Command = new OleDbDataAdapter("select * from [" + sheet1 + "]", connection);
                                    Command.Fill(Dt_input1);
                                    connection.Close();

                                    connection = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + f_path2 + @";Extended Properties=""Excel 8.0;IMEX=1;HDR=NO;TypeGuessRows=0;ImportMixedTypes=Text""");
                                    connection.Open();
                                    schemaTable = connection.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, new object[] { null, null, null, "TABLE" });
                                    schemaRow = schemaTable.Rows[0];
                                    Command = new OleDbDataAdapter("select * from [" + sheet2 + "]", connection);
                                    Command.Fill(Dt_input2);
                                    connection.Close();
                                    Dt_input2.Rows.RemoveAt(0);
                                    Dt_input2.Rows.RemoveAt(0);
                                    Dt_input1.Merge(Dt_input2);

                                    Microsoft.Office.Interop.Excel.Application app = new Microsoft.Office.Interop.Excel.Application();
                                    app.DisplayAlerts = false;
                                    app.Visible = false;
                                    Microsoft.Office.Interop.Excel.Workbook WBO = (Microsoft.Office.Interop.Excel.Workbook)(app.Workbooks.Add(""));
                                    Microsoft.Office.Interop.Excel.Worksheet WBS = (Microsoft.Office.Interop.Excel.Worksheet)app.ActiveSheet;
                                    for (int l = 0; l < Dt_input1.Rows.Count; l++)
                                    {
                                        for (int k = 0; k < Dt_input1.Columns.Count; k++)
                                        {
                                            WBS.Cells[l + 1, k + 1] = Dt_input1.Rows[l].ItemArray[k].ToString();
                                        }
                                    }
                                    WBS.Columns.AutoFit();
                                    Excel.Range Fcol = (Excel.Range)WBS.get_Range("F1").EntireColumn;
                                    Fcol.NumberFormat = "#,##0.00";
                                    WBO.SaveAs(f_path);
                                    WBO.Close();
                                    app.Quit();
                                    ReleaseComObject(WBS);
                                    ReleaseComObject(WBO);
                                    ReleaseComObject(app);
                                    if (File.Exists(f_path1))
                                    {
                                        File.Delete(f_path1);
                                    }
                                    if (File.Exists(f_path2))
                                    {
                                        File.Delete(f_path2);
                                    }
                                    if (File.Exists(f_path1_UN))
                                    {
                                        File.Delete(f_path1_UN);
                                    }
                                    if (File.Exists(f_path2_UN))
                                    {
                                        File.Delete(f_path2_UN);
                                    }
                                    if (File.Exists(f_path1_Prn))
                                    {
                                        File.Move(f_path1_Prn, f_path1_OutPrn);
                                    }
                                    if (File.Exists(f_path2_Prn))
                                    {
                                        File.Move(f_path2_Prn, f_path2_OutPrn);
                                    }
                                }
                            }                            
                        }
                        if (reconName != "Structured Funding  - BTS VS Custody")
                        {
                            if (File.Exists(InputXLpath))
                            {
                                File.Delete(InputXLpath);
                            }
                            if (File.Exists(InputPRNPath))
                            {
                                File.Move(InputPRNPath, OutputPRNPath);
                            }
                        }
                    }
                    
                    //string Downloadpath = @"\\10.132.5.214\TempFiles\SAHIL\DEV_RUNTIME\25-Jan-2018_Files\Input\OpicsPlus\";
                }
                else if(j==1)
                {
                    Dwnpath = DownloadPath + dtimefrm + "_Files" + "\\Input\\OpicsPVB\\";
                    if (!(System.IO.Directory.Exists(Dwnpath + "PrnFiles\\")))
                    {
                        System.IO.Directory.CreateDirectory(Dwnpath + "PrnFiles\\");
                    }
                    string[] CrystalFilePaths = Directory.GetFiles(Dwnpath, @"*.Prn");
                    foreach (var filePath in CrystalFilePaths)
                    {
                        reconName = "";
                        var FileName = Path.GetFileName(filePath);
                        InputPRNPath = Dwnpath + FileName;
                        InputXLpath = InputPRNPath.Replace(".Prn", "_UN.xls");
                        OutputPRNPath = Dwnpath + "PrnFiles\\" + FileName;
                        OutputFilePath = InputXLpath.Replace("_UN", "");
                        if (FileName.Contains("MXPB"))
                        {
                            reconName = "MXPB file";
                        }
                        else if (FileName.Contains("UK_FMO"))
                        {
                            reconName = "UK FMO Suspense";
                        }                        
                        bool x = prnTOxlsConvertor(InputPRNPath, InputXLpath, OutputFilePath, FileName, reconName, out ErrorMsg);

                        if (File.Exists(InputXLpath))
                        {
                            File.Delete(InputXLpath);
                        }
                        if (File.Exists(InputPRNPath))
                        {
                            File.Move(InputPRNPath, OutputPRNPath);
                        }
                    }
                }
                else if(j==2)
                {
                    Dwnpath = "";
                    Dwnpath = DownloadPath + dtimefrm + "_Files" + "\\Input\\OpicsReg\\";
                    if (!(System.IO.Directory.Exists(Dwnpath + "PrnFiles\\")))
                    {
                        System.IO.Directory.CreateDirectory(Dwnpath + "PrnFiles\\");
                    }
                    string[] CrystalFilePaths = Directory.GetFiles(Dwnpath, @"*.Prn");
                    foreach (var filePath in CrystalFilePaths)
                    {
                        reconName = "";
                        var FileName = Path.GetFileName(filePath);
                        InputPRNPath = Dwnpath + FileName;
                        InputXLpath = InputPRNPath.Replace(".Prn", "_UN.xls");
                        OutputPRNPath = Dwnpath + "PrnFiles\\" + FileName;
                        OutputFilePath = InputXLpath.Replace("_UN", "");
                        if (FileName.Contains("OPICS_POSITIONING"))
                        {
                            reconName = "Srilanka - Position Balancing";
                        }                        
                        bool x = prnTOxlsConvertor(InputPRNPath, InputXLpath, OutputFilePath, FileName, reconName, out ErrorMsg);
                        if (File.Exists(InputXLpath))
                        {
                            File.Delete(InputXLpath);
                        }
                        if (File.Exists(InputPRNPath))
                        {
                            File.Move(InputPRNPath, OutputPRNPath);
                        }
                    }
                }                
            }                        
        }
        public void prnConvertorSF(string ReconDate, string DownloadPath)
        {
            string dtimefrm = DateTime.Now.ToString("dd-MMM-yyyy");
            string Dwnpath = "";
            string InputPRNPath = "";
            string InputXLpath = "";
            string OutputFilePath = "";
            string OutputPRNPath = "";
            string ErrorMsg = "";
            string reconName = "";
            Dwnpath = DownloadPath + dtimefrm + "_Files" + "\\Input\\OpicsPlus\\";
            if (!(System.IO.Directory.Exists(Dwnpath + "PrnFiles\\")))
            {
                System.IO.Directory.CreateDirectory(Dwnpath + "PrnFiles\\");
            }
            string[] CrystalFilePaths = Directory.GetFiles(Dwnpath, @"*.Prn");
            int lcnt = 0;
            foreach (var filePath in CrystalFilePaths)
            {
                reconName = "";
                var FileName = Path.GetFileName(filePath);
                InputPRNPath = Dwnpath + FileName;
                OutputPRNPath = Dwnpath + "PrnFiles\\" + FileName;
                InputXLpath = InputPRNPath.Replace(".Prn", "_UN.xls");
                OutputFilePath = InputXLpath.Replace("_UN", "");
                if (FileName.Contains("STRUCT_OPICS"))
                {
                    reconName = "Structured Funding  - BTS VS Custody";
                    bool x = prnTOxlsConvertor(InputPRNPath, InputXLpath, OutputFilePath, FileName, reconName, out ErrorMsg);
                }
                if (reconName == "Structured Funding  - BTS VS Custody")
                {
                    lcnt++;
                    string f_path1 = Dwnpath + "STRUCT_OPICS_1_" + Convert.ToDateTime(ReconDate).ToString("ddMMyy") + ".xls";
                    string f_path1_UN = Dwnpath + "STRUCT_OPICS_1_" + Convert.ToDateTime(ReconDate).ToString("ddMMyy") + "_UN" + ".xls";
                    string f_path1_Prn = Dwnpath + "STRUCT_OPICS_1_" + Convert.ToDateTime(ReconDate).ToString("ddMMyy") + ".Prn";
                    string f_path1_OutPrn = Dwnpath + "PrnFiles\\" + "STRUCT_OPICS_1_" + Convert.ToDateTime(ReconDate).ToString("ddMMyy") + ".Prn";
                    string sheet1 = "STRUCT_OPICS_1_" + Convert.ToDateTime(ReconDate).ToString("ddMMyy") + "$";
                    string f_path2 = Dwnpath + "STRUCT_OPICS_2_" + Convert.ToDateTime(ReconDate).ToString("ddMMyy") + ".xls";
                    string f_path2_UN = Dwnpath + "STRUCT_OPICS_2_" + Convert.ToDateTime(ReconDate).ToString("ddMMyy") + "_UN" + ".xls";
                    string f_path2_Prn = Dwnpath + "STRUCT_OPICS_2_" + Convert.ToDateTime(ReconDate).ToString("ddMMyy") + ".Prn";
                    string f_path2_OutPrn = Dwnpath + "PrnFiles\\" + "STRUCT_OPICS_2_" + Convert.ToDateTime(ReconDate).ToString("ddMMyy") + ".Prn";
                    string sheet2 = "STRUCT_OPICS_2_" + Convert.ToDateTime(ReconDate).ToString("ddMMyy") + "$";
                    string f_path = f_path1.Replace("1_", "");
                    string sheet = sheet1.Replace("1_", "");
                    if (File.Exists(f_path1))
                    {
                        if (File.Exists(f_path2))
                        {
                            System.Data.DataTable Dt_input1 = new System.Data.DataTable();
                            System.Data.DataTable Dt_input2 = new System.Data.DataTable();
                            System.Data.DataTable Dt_out = new System.Data.DataTable();
                            OleDbConnection connection;
                            OleDbDataAdapter Command;
                            connection = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + f_path1 + @";Extended Properties=""Excel 8.0;IMEX=1;HDR=NO;TypeGuessRows=0;ImportMixedTypes=Text""");
                            connection.Open();
                            System.Data.DataTable schemaTable = connection.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, new object[] { null, null, null, "TABLE" });
                            System.Data.DataRow schemaRow = schemaTable.Rows[0];
                            Command = new OleDbDataAdapter("select * from [" + sheet1 + "]", connection);
                            Command.Fill(Dt_input1);
                            connection.Close();

                            connection = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + f_path2 + @";Extended Properties=""Excel 8.0;IMEX=1;HDR=NO;TypeGuessRows=0;ImportMixedTypes=Text""");
                            connection.Open();
                            schemaTable = connection.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, new object[] { null, null, null, "TABLE" });
                            schemaRow = schemaTable.Rows[0];
                            Command = new OleDbDataAdapter("select * from [" + sheet2 + "]", connection);
                            Command.Fill(Dt_input2);
                            connection.Close();
                            Dt_input2.Rows.RemoveAt(0);
                            Dt_input2.Rows.RemoveAt(0);
                            Dt_input1.Merge(Dt_input2);

                            Microsoft.Office.Interop.Excel.Application app = new Microsoft.Office.Interop.Excel.Application();
                            app.DisplayAlerts = false;
                            app.Visible = false;
                            Microsoft.Office.Interop.Excel.Workbook WBO = (Microsoft.Office.Interop.Excel.Workbook)(app.Workbooks.Add(""));
                            Microsoft.Office.Interop.Excel.Worksheet WBS = (Microsoft.Office.Interop.Excel.Worksheet)app.ActiveSheet;
                            for (int l = 0; l < Dt_input1.Rows.Count; l++)
                            {
                                for (int k = 0; k < Dt_input1.Columns.Count; k++)
                                {
                                    WBS.Cells[l + 1, k + 1] = Dt_input1.Rows[l].ItemArray[k].ToString();
                                }
                            }
                            WBS.Columns.AutoFit();
                            Excel.Range Fcol = (Excel.Range)WBS.get_Range("F1").EntireColumn;
                            Fcol.NumberFormat = "#,##0.00";
                            WBO.SaveAs(f_path);
                            WBO.Close();
                            app.Quit();
                            ReleaseComObject(WBS);
                            ReleaseComObject(WBO);
                            ReleaseComObject(app);
                            if (File.Exists(f_path1))
                            {
                                File.Delete(f_path1);
                            }
                            if (File.Exists(f_path2))
                            {
                                File.Delete(f_path2);
                            }
                            if (File.Exists(f_path1_UN))
                            {
                                File.Delete(f_path1_UN);
                            }
                            if (File.Exists(f_path2_UN))
                            {
                                File.Delete(f_path2_UN);
                            }
                            if (File.Exists(f_path1_Prn))
                            {
                                File.Move(f_path1_Prn, f_path1_OutPrn);
                            }
                            if (File.Exists(f_path2_Prn))
                            {
                                File.Move(f_path2_Prn, f_path2_OutPrn);
                            }
                        }
                    }
                }
            }
        }        
        public string textidentifier(string val)
        {
            string outchar = "";
            if (val == "011100010111110011100010001100010001100010001100010001110011111010001110")
            {
                outchar = "S";
            }
            else if (val == "100000000111111100111111111100011111100011111111111111111111100100000000")
            {
                outchar = "V";
            }
            else if (val == "100000001111111111111111111100010001100111001100111000110000000110000000")
            {
                outchar = "F";
            }
            else if (val == "000000000010000011110000111100001101100011001111110001011100001000000000")
            {
                outchar = "2";
            }
            else if (val == "110000000110000000100000001111111111111111111100000001110000000110000000")
            {
                outchar = "T";
            }
            //
            else if (val == "000000001000001111100111111111110101111110101000111111000001111000000001")
            {
                outchar = "A";
            }
            else if (val == "100000001111111111111111111100010001100010001100010000111110000011100000")
            {
                outchar = "P";
            }
            else if (val == "001111100011111110110000011100000001100000001100000001110000011010000010")
            {
                outchar = "C";
            }
            else if (val == "100000001111111111111111111100000001100000001110000011011111110001111100")
            {
                outchar = "D";
            }
            else if (val == "001111100011111110110000011100000001100001001100001001110001111010001110")
            {
                outchar = "G";
            }
            else if (val == "100000001111111111111111111100010001100111001100111001110000011110000011")
            {
                outchar = "E";
            }
            else if (val == "100000001111111111111111111001110001100011100111111111111111111100000000")
            {
                outchar = "N";
            }
            else if (val == "100000001111111111111111111100010001100011100100011111111110011011100001")
            {
                outchar = "R";
            }
            else if (val == "100000001111111111111111111100010001100010001100010001111111111011101110")
            {
                outchar = "B";
            }
            else if (val == "100000000111111110111111111100000001100000001111111111111111110100000000")
            {
                outchar = "U";
            }
            else if (val == "100000001111111111111111111100010001100111001100111000110000000110000000")
            {
                outchar = "F";
            }
            else if (val == "100000001110000011111101111101111101101111101111101111110000011100000001")
            {
                outchar = "X";
            }
            else if (val == "100000001111111111111111111100010001100010001111111111111111111100000001")
            {
                outchar = "H";
            }
            else if (val == "100000001100000001111111111111111111100000001100000001000000011000000011")
            {
                outchar = "L";
            }
            else if (val == "110000001110000011100001111100011101101110001111100001110000011100000011")
            {
                outchar = "Z";
            }
            else if (val == "001111100011111110110000011100000001100000001110000011011111110001111100")
            {
                outchar = "O";
            }
            else if (val == "000000000100000001100000001111111111111111111100000001100000001000000000")
            {
                outchar = "I";
            }
            else if (val == "100000001111111111111111111001110001100011100111111111111111111100000000")
            {
                outchar = "N";
            }
            else if (val == "000000000010000010110000011100010001100010001111111111011101110000000000")
            {
                outchar = "3";
            }
            return outchar;
        }
        public void convertGrayImages(string path, string index)
        {
            try
            {
                Bitmap bmp1 = new Bitmap(path);
                Bitmap bmp2 = new Bitmap(bmp1.Width, bmp1.Height);
                for (int i = 0; i < bmp1.Width; i++)
                {
                    for (int j = 0; j < bmp1.Height; j++)
                    {
                        Color c = bmp1.GetPixel(i, j);
                        int average = ((c.R + c.B + c.G) / 3);
                        if (average < 200)
                        {
                            bmp2.SetPixel(i, j, Color.Black);
                        }
                        else
                        {
                            bmp2.SetPixel(i, j, Color.White);
                        }
                    }
                }
                bmp2.Save(index);
                bmp1.Dispose();
                bmp2.Dispose();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
        public void convertGrayImages_FX(string path, string index, string num)
        {
            try
            {
                Bitmap bmp1 = new Bitmap(path);
                Bitmap bmp2 = new Bitmap(bmp1.Width, bmp1.Height);
                for (int i = 0; i < bmp1.Width; i++)
                {
                    for (int j = 0; j < bmp1.Height; j++)
                    {
                        Color c = bmp1.GetPixel(i, j);
                        int average = ((c.R + c.B + c.G) / 3);
                        if (average < 200)
                        {
                            bmp2.SetPixel(i, j, Color.Black);
                        }
                        else
                        {
                            bmp2.SetPixel(i, j, Color.White);
                        }
                    }
                }
                bmp2.Save(index);
                bmp1.Dispose();
                bmp2.Dispose();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
        public void findposition(string value, out System.Data.DataTable dtpos, string xval, string ReconName, string Branch)
        {
            dtpos = new System.Data.DataTable();            
            try
            {
                //deleteAll(@"C:\ARC\ZIRC\");
                xval = "1";
                ScreenCapture(@"C:\ARC\ZIRC\SS_ZDRP"+xval+".jpg");
                objclsImgCmp.CropImage(183, 246, 84, 194, @"C:\ARC\ZIRC\SS_ZDRP" + xval + ".jpg", @"C:\ARC\ZIRC\Crp_ZDRP" + xval + ".jpg");
                convertGrayImages(@"C:\ARC\ZIRC\Crp_ZDRP" + xval + ".jpg", @"C:\ARC\ZIRC\IColor_ZDRP" + xval + ".jpg");
                Bitmap bmp1 = new Bitmap(@"C:\ARC\ZIRC\IColor_ZDRP" + xval + ".jpg");                
                string[] text = new string[15];
                string tempval = "";
                string val = "";
                int n = 0;
                int n1 = 2;
                int n3 = 0;
                for (int j = 0; j < 15; j++)
                {                    
                    int m = 0;
                    if (j == 0)
                    {
                        n3 = n1;
                    }
                    else
                    {
                        n = n + 13;
                        n3 = n1 + n;
                    }
                    for (int i = 0; i < 4; i++)
                    {
                        m = m + 9;
                        for (int y = m + 1; y < m + 1 + 8; y++)
                        {                                                        
                            for (int x = n3; x < n3+9; x++)
                            {
                                int x1 = 0;
                                if (bmp1.GetPixel(y, x).Name == "ff000000")
                                {
                                    x1 = 1;
                                }                                 
                                val = val + x1.ToString();
                            }                           
                        }
                        tempval = tempval + textidentifier(val);
                        val = "";
                    }
                    text[j] = tempval;
                    tempval = "";
                }                
                int p = 13;
                int height = 0;
                dtpos.Columns.Add("value");
                dtpos.Columns.Add("position");
                for (int k = 0; k < text.Length; k++)
                {
                    //190,252                         
                    height = 252 + (k * 13);
                    if (ReconName == "TRBC"||ReconName=="Structured Finance Position Monthly")
                    {
                        if (text[k] == "TRBC")
                        {
                            dtpos.Rows.Add();
                            dtpos.Rows[dtpos.Rows.Count - 1]["value"] = text[k];
                            dtpos.Rows[dtpos.Rows.Count - 1]["position"] = height;
                        }
                    }
                    else if (ReconName == "OPICS Sentry Position Daily")
                    {
                        if (Branch == "02")
                        {
                            if (text[k] == "APRG" || text[k] == "AIEG")
                            {
                                dtpos.Rows.Add();
                                dtpos.Rows[dtpos.Rows.Count - 1]["value"] = text[k];
                                dtpos.Rows[dtpos.Rows.Count - 1]["position"] = height;
                            }
                        }
                        else
                        {
                            if (text[k] == "APRG")
                            {
                                dtpos.Rows.Add();
                                dtpos.Rows[dtpos.Rows.Count - 1]["value"] = text[k];
                                dtpos.Rows[dtpos.Rows.Count - 1]["position"] = height;
                            }
                        }
                    }
                    else if (ReconName == "Opics ZNOR-ZIRC")
                    {
                        var values = new String[] { "01", "02", "03", "04", "05", "06", "07", "08", "10", "11", "12", "24", "25", "93" };

                        if (values.Any(v => Branch.Contains(v)))
                        {
                            if (text[k] == "ZIRC" || text[k] == "ZNOR")
                            {
                                dtpos.Rows.Add();
                                dtpos.Rows[dtpos.Rows.Count - 1]["value"] = text[k];
                                dtpos.Rows[dtpos.Rows.Count - 1]["position"] = height;
                            }
                        }
                        else
                        {
                            if (text[k] == "ZIRC")
                            {
                                dtpos.Rows.Add();
                                dtpos.Rows[dtpos.Rows.Count - 1]["value"] = text[k];
                                dtpos.Rows[dtpos.Rows.Count - 1]["position"] = height;
                            }
                        }
                    }
                    else if (ReconName == "Srilanka-Bts-Daily")
                    {
                        if (text[k] == "IREC")
                        {
                            dtpos.Rows.Add();
                            dtpos.Rows[dtpos.Rows.Count - 1]["value"] = text[k];
                            dtpos.Rows[dtpos.Rows.Count - 1]["position"] = height;
                        }
                    }
                }
                bmp1.Dispose();
                //val = "";
                //Thread.Sleep(10000);
                
            }
            catch (Exception ex)
            {                
                MessageBox.Show(ex.ToString());
            }
        }
        public void WrodReaderDocx()
        {
            Microsoft.Office.Interop.Word.Application word = new Microsoft.Office.Interop.Word.Application();
            //Document document = application.Documents.Open(@"C:\ARC\3.7\Algos\Hong_Kong_CMU\CMUD5101.docx");
            Document doc = new Document();

            object fileName = @"C:\ARC\3.7\Algos\Hong_Kong_CMU\CMUD5101.docx";
            // Define an object to pass to the API for missing parameters
            object missing = System.Type.Missing;
            doc = word.Documents.Open(ref fileName,
                    ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing);

            String read = string.Empty;
            List<string> data = new List<string>();
            foreach (Range tmpRange in doc.StoryRanges)
            {
                //read += tmpRange.Text + "<br>";
                data.Add(tmpRange.Text);
            }
            ((_Document)doc).Close();
            ((_Application)word).Quit();

            
        }
        public System.Data.DataTable PDFConvertor_HK_CMU(string path)
        {
            string ss = string.Empty;
            string s = string.Empty;
            string urlFileName1 = path;

            PdfReader pdr = new PdfReader(urlFileName1);
            StringBuilder text = new StringBuilder();
            string docFilePath = urlFileName1.Substring(0, urlFileName1.Length - 3) + "docx";
            string xml_filename = docFilePath.Substring(0, docFilePath.Length - 4) + "xml";
            string xmlFileName = "";
            if (File.Exists(xml_filename))
            {
                File.Delete(xml_filename);
            }
            xmlFileName = SaveAsWordToXML(docFilePath);
            string input = ReadXmlFile(xml_filename).ToString();

            for (int i = 1; i <= pdr.NumberOfPages; i++)
            {
                ss = ss + PdfTextExtractor.GetTextFromPage(pdr, i);

                ITextExtractionStrategy its = new iTextSharp.text.pdf.parser.SimpleTextExtractionStrategy();
                s = s + PdfTextExtractor.GetTextFromPage(pdr, i, its);
            }

            string[] x = ss.Split('\n');
            System.Data.DataTable dt = new System.Data.DataTable();
            bool isvalpresent = false;
            int findtype = 0;
            dt.Columns.Add("");
            dt.Columns.Add("");
            dt.Columns.Add("");
            dt.Columns.Add("");
            dt.Columns.Add("");
            dt.Columns.Add("");
            dt.Columns.Add("");
            dt.Columns.Add("");
            dt.Columns.Add("");
            dt.Columns.Add("");
            dt.Columns.Add("");
            int cnt = 0;
            for (int i = 0; i < x.Length; i++)
            {
                if (x[i] != "")
                {
                    dt.Rows.Add();
                    if (i != 0)
                    {
                        if (isvalpresent == true && findtype == 1 && (!x[i - 1].StartsWith("Issue No.")) && (!x[i].Contains("--")))
                        {
                            string[] y = x[i].Split(' ');
                            if (x[i] == "CMU" || (x[i] == "SHC") && (x[i - 1].Contains("-")) || x[i] == "CDC")
                            {
                                dt.Rows[dt.Rows.Count - 1][0] = x[i].ToString();
                            }
                            else
                            {
                                if (y.Length == 10)
                                {
                                    dt.Rows[dt.Rows.Count - 1][0] = y[0];
                                    dt.Rows[dt.Rows.Count - 1][1] = y[1];
                                    dt.Rows[dt.Rows.Count - 1][2] = y[2];
                                    dt.Rows[dt.Rows.Count - 1][3] = y[3];
                                    dt.Rows[dt.Rows.Count - 1][4] = y[4];
                                    dt.Rows[dt.Rows.Count - 1][5] = y[5];
                                    dt.Rows[dt.Rows.Count - 1][6] = y[6];
                                    dt.Rows[dt.Rows.Count - 1][7] = y[7];
                                    dt.Rows[dt.Rows.Count - 1][8] = y[8];
                                    dt.Rows[dt.Rows.Count - 1][9] = y[9];
                                }
                                if (y.Length == 9)
                                {
                                    if (y[3].Length == 3)
                                    {
                                        dt.Rows[dt.Rows.Count - 1][0] = y[0];
                                        dt.Rows[dt.Rows.Count - 1][1] = y[1];
                                        //dt.Rows[dt.Rows.Count - 1][2] = y[2];
                                        dt.Rows[dt.Rows.Count - 1][3] = y[2];
                                        dt.Rows[dt.Rows.Count - 1][4] = y[3];
                                        dt.Rows[dt.Rows.Count - 1][5] = y[4];
                                        dt.Rows[dt.Rows.Count - 1][6] = y[5];
                                        dt.Rows[dt.Rows.Count - 1][7] = y[6];
                                        dt.Rows[dt.Rows.Count - 1][8] = y[7];
                                        dt.Rows[dt.Rows.Count - 1][9] = y[8];
                                    }
                                }
                                if (y.Length == 8)
                                {
                                    if (y[2].Length == 3)
                                    {
                                        dt.Rows[dt.Rows.Count - 1][0] = y[0];
                                        if (y[1].Contains("-"))
                                        {
                                            dt.Rows[dt.Rows.Count - 1][3] = y[1];
                                        }
                                        else
                                        {
                                            dt.Rows[dt.Rows.Count - 1][1] = y[1];
                                        }
                                        //dt.Rows[dt.Rows.Count - 1][2] = y[2];
                                        //dt.Rows[dt.Rows.Count - 1][3] = y[3];
                                        dt.Rows[dt.Rows.Count - 1][4] = y[2];
                                        dt.Rows[dt.Rows.Count - 1][5] = y[3];
                                        dt.Rows[dt.Rows.Count - 1][6] = y[4];
                                        dt.Rows[dt.Rows.Count - 1][7] = y[5];
                                        dt.Rows[dt.Rows.Count - 1][8] = y[6];
                                        dt.Rows[dt.Rows.Count - 1][9] = y[7];
                                    }
                                }
                                if ((y.Length != 10 && y.Length != 9 && y.Length != 8) || x[i + 1].Contains(":") || x[i + 1].Length < 15)
                                {
                                    isvalpresent = false;
                                    findtype = 0;
                                }
                            }
                        }
                        else if (isvalpresent == true && findtype == 2 && (!x[i - 1].StartsWith("Issue No.")))
                        {
                            string[] y = x[i].Trim().Split(' ');
                            if (x[i] == "CMU" || ((x[i] == "SHC") && (x[i - 1].Contains("-"))) || x[i] == "CDC")
                            {
                                dt.Rows[dt.Rows.Count - 1][0] = x[i].ToString();
                            }
                            else
                            {
                                if (y.Length == 9)
                                {
                                    dt.Rows[dt.Rows.Count - 1][0] = y[0];
                                    dt.Rows[dt.Rows.Count - 1][1] = y[1];
                                    dt.Rows[dt.Rows.Count - 1][2] = y[2];
                                    dt.Rows[dt.Rows.Count - 1][3] = y[3];
                                    dt.Rows[dt.Rows.Count - 1][4] = y[4];
                                    dt.Rows[dt.Rows.Count - 1][5] = y[5];
                                    dt.Rows[dt.Rows.Count - 1][6] = y[6];
                                    dt.Rows[dt.Rows.Count - 1][7] = y[7];
                                    dt.Rows[dt.Rows.Count - 1][8] = y[8];
                                }
                                if (y.Length == 8)
                                {
                                    if (y[3].Length == 3)
                                    {
                                        dt.Rows[dt.Rows.Count - 1][0] = y[0];
                                        dt.Rows[dt.Rows.Count - 1][1] = y[1];
                                        //dt.Rows[dt.Rows.Count - 1][2] = y[2];
                                        dt.Rows[dt.Rows.Count - 1][3] = y[2];
                                        dt.Rows[dt.Rows.Count - 1][4] = y[3];
                                        dt.Rows[dt.Rows.Count - 1][5] = y[4];
                                        dt.Rows[dt.Rows.Count - 1][6] = y[5];
                                        dt.Rows[dt.Rows.Count - 1][7] = y[6];
                                        dt.Rows[dt.Rows.Count - 1][8] = y[7];
                                    }
                                }
                                if (y.Length == 7)
                                {
                                    if (y[2].Length == 3)
                                    {
                                        dt.Rows[dt.Rows.Count - 1][0] = y[0];
                                        if (y[1].Contains("-"))
                                        {
                                            dt.Rows[dt.Rows.Count - 1][3] = y[1];
                                        }
                                        else
                                        {
                                            dt.Rows[dt.Rows.Count - 1][1] = y[1];
                                        }
                                        //dt.Rows[dt.Rows.Count - 1][2] = y[2];
                                        //dt.Rows[dt.Rows.Count - 1][3] = y[3];
                                        dt.Rows[dt.Rows.Count - 1][4] = y[2];
                                        dt.Rows[dt.Rows.Count - 1][5] = y[3];
                                        dt.Rows[dt.Rows.Count - 1][6] = y[4];
                                        dt.Rows[dt.Rows.Count - 1][7] = y[5];
                                        dt.Rows[dt.Rows.Count - 1][8] = y[6];
                                    }
                                }
                                if ((y.Length != 9 && y.Length != 8 && y.Length != 7) || x[i + 1].Contains(":") || x[i + 1].Length < 15)
                                {
                                    isvalpresent = false;
                                    findtype = 0;
                                }
                            }

                        }
                        else if ((x[i] == "SHC") && (!(x[i - 1].Contains("-"))))
                        {
                            dt.Rows[dt.Rows.Count - 1][0] = x[i].ToString();
                            isvalpresent = true;
                            findtype = 2;
                        }
                        else if (x[i - 1].StartsWith("Issue No."))
                        {
                            if (x[i] == "----------- --------- ------------ ---------- --------------------------- ---------------------- ---------------------- ----------------------" && x[i + 1] == "------------------")
                            {
                                dt.Rows[dt.Rows.Count - 1][0] = "Issue No.";
                                dt.Rows[dt.Rows.Count - 1][1] = "Common Code";
                                dt.Rows[dt.Rows.Count - 1][2] = "ISIN";
                                dt.Rows[dt.Rows.Count - 1][3] = "Maturity Date";
                                dt.Rows[dt.Rows.Count - 1][4] = " ";
                                dt.Rows[dt.Rows.Count - 1][5] = "Quantity";
                                dt.Rows[dt.Rows.Count - 1][6] = "Collateral In Quantity";
                                dt.Rows[dt.Rows.Count - 1][7] = "Collateral Out Quantity";
                                dt.Rows[dt.Rows.Count - 1][8] = "Quantity Blocked";
                                dt.Rows[dt.Rows.Count - 1][9] = "Quantity Under Securities Repo";
                                isvalpresent = true;
                                findtype = 1;
                            }
                            else if (x[i] == "----------- --------- ------------ ---------- --------------------------- ---------------------- ---------------------- ----------------------" && x[i + 1] != "------------------")
                            {
                                dt.Rows[dt.Rows.Count - 1][0] = "Issue No.";
                                dt.Rows[dt.Rows.Count - 1][1] = "Common Code";
                                dt.Rows[dt.Rows.Count - 1][2] = "ISIN";
                                dt.Rows[dt.Rows.Count - 1][3] = "Maturity Date";
                                dt.Rows[dt.Rows.Count - 1][4] = " ";
                                dt.Rows[dt.Rows.Count - 1][5] = "Quantity";
                                dt.Rows[dt.Rows.Count - 1][6] = "Collateral In Quantity";
                                dt.Rows[dt.Rows.Count - 1][7] = "Collateral Out Quantity";
                                dt.Rows[dt.Rows.Count - 1][8] = "Quantity Blocked";
                                isvalpresent = true;
                                findtype = 2;
                            }
                        }
                        else if (x[i] == "------------------")
                        {
                            dt.Rows[dt.Rows.Count - 1][0] = x[i].ToString();
                        }
                        else
                        {
                            dt.Rows[dt.Rows.Count - 1][0] = x[i].ToString();
                            isvalpresent = false;
                            findtype = 0;
                        }
                    }
                    cnt++;
                }
            }

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                if (dt.Rows[i][4] != null)
                {
                    if (dt.Rows[i][4].ToString() != "")
                    {
                        if (dt.Rows[i][4].ToString() == "HKD" || dt.Rows[i][4].ToString() == "CNY" || dt.Rows[i][4].ToString() == "USD")
                        {
                            if (dt.Rows[i][3].ToString() == "")
                            {
                                dt.Rows.Remove(dt.Rows[i]);
                            }
                        }
                    }
                }

            }

            return dt;
        }
        public string ReadXmlFile(string xmlFileName)
        {
            StringBuilder stringBuilder = new StringBuilder();
            string _result = new StreamReader(xmlFileName).ReadToEnd();
            return _result;
        }
        public string SaveAsWordToXML(string fileName)
        {
            string xmlFileName = string.Empty;
            Microsoft.Office.Interop.Word._Application newApp = new Microsoft.Office.Interop.Word.Application();
            object Source = fileName;
            object target = fileName.Substring(0, fileName.Length - 4) + "xml";
            xmlFileName = target.ToString();
            if (!File.Exists(xmlFileName))
            {
                object Unknown = Type.Missing;
                newApp.Documents.Open(ref Source, ref Unknown,
                    ref Unknown, ref Unknown, ref Unknown,
                    ref Unknown, ref Unknown, ref Unknown,
                    ref Unknown, ref Unknown, ref Unknown,
                    ref Unknown, ref Unknown, ref Unknown, ref Unknown);
                object format = Microsoft.Office.Interop.Word.WdSaveFormat.wdFormatXML;

                newApp.ActiveDocument.SaveAs(ref target, ref format,
                     ref Unknown, ref Unknown, ref Unknown,
                     ref Unknown, ref Unknown, ref Unknown,
                     ref Unknown, ref Unknown, ref Unknown,
                     ref Unknown, ref Unknown, ref Unknown,
                     ref Unknown, ref Unknown);
                newApp.Documents.Close(true, Type.Missing, Type.Missing);
                newApp.Quit(ref Unknown, ref Unknown, ref Unknown);
            }
            return xmlFileName;
        }
        public void ConvertdtTocsv(string Savepath, System.Data.DataTable dt)
        {
            StringBuilder sb = new StringBuilder();

            foreach (DataColumn col in dt.Columns)
            {
                sb.Append(col.ColumnName + ',');
            }

            sb.Remove(sb.Length - 1, 1);
            sb.Append(Environment.NewLine);

            foreach (DataRow row in dt.Rows)
            {
                for (int i = 0; i < dt.Columns.Count; i++)
                {
                    sb.Append(row[i].ToString() + ",");
                }

                sb.Append(Environment.NewLine);
            }

            File.WriteAllText(Savepath, sb.ToString());
        }
        public bool IndiaClearing_Recons(string Con, string path, string Recon_name, out string ErrorMsg)
        {
            ErrorMsg = "";
            bool result = false;
            //Formating_3_2(@"Data Source=UKWVIDSQL01I2.ZONE1.SCBDEV.NET\UAT_CL01_IN01,10502;Initial Catalog=CRC_QMT;User ID=CRCQMTUser;Password=eeSmd6fEu;", @"\\10.132.5.214\TempFiles\SAHIL\UAT_Runtimes\ARCRuntime\");
            try
            {
                objIndiaClearing.Formating_3_2(Con, path, Recon_name);
                result = true;
            }
            catch (Exception ex)
            {
                ErrorMsg = ex.ToString();
            }
            return result;
        }
        public void num_lock()
        {
            objAvoidLock.avoidlock();
        }
        public bool CreateExcel(string path, int sleeptime, out string ErrorMsg)
        {
            ErrorMsg = "";
            bool result = false;
            try
            {
                if (File.Exists(path))
                {
                    File.Delete(path);
                }
                var app = new Microsoft.Office.Interop.Excel.Application();
                var wb = app.Workbooks.Add();
                wb.SaveAs(path);
                wb.Close();
                
                app.Visible = true;
                app.DisplayAlerts = false;
                wb = app.Workbooks.Open(path);                
                Thread.Sleep(sleeptime);                                                
                objclsfunopics.startprocess(14, 56, 100, 20, 5000, "LocalPaste", "");
                wb.SaveAs(path);
                wb.Close();
                app.Quit();
                releaseObject(wb);
                releaseObject(app);
                result = true;
            }
            catch (Exception ex)
            {
                ErrorMsg = ex.ToString();
            }
            return result;
        }
        public bool CreateExcel_Opics(string path, int sleeptime, string Recon_Name, string FileName, out string ErrorMsg)
        {
            ErrorMsg = "";
            bool result = false;
            try
            {
                if (File.Exists(path))
                {
                    File.Delete(path);
                }
                var app = new Microsoft.Office.Interop.Excel.Application();
                var wb = app.Workbooks.Add();                
                wb.SaveAs(path);
                wb.Close();

                app.Visible = true;
                app.DisplayAlerts = false;
                wb = app.Workbooks.Open(path);
                Thread.Sleep(sleeptime);                
                objclsfunopics.startprocess(14, 56, 100, 20, 5000, "LocalPaste", "");                
                for (int i = 0; i < 20; i++)
                {
                    Thread.Sleep(7000);
                    if (isExcelPasted())
                    {
                        break;
                    }
                    else if (i == 15)
                    {
                        objclsfunopics.startprocess(14, 56, 100, 20, 5000, "LocalPaste", "");                                        
                    }
                }
                wb.SaveAs(path);
                wb.Close();
                app.Quit();
                releaseObject(wb);
                releaseObject(app);
                result = true;
            }
            catch (Exception ex)
            {
                ErrorMsg = ex.ToString();
            }
            return result;
        }
        private static void releaseObject(object obj)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                obj = null;
            }
            catch
            {

            }
            finally
            {
                GC.Collect();
            }
        }
        public bool isExcelPasted()
        {
            bool result = false;
            ARC_Opics_DLL.Cls_ImgCmp objclsImgCmp = new ARC_Opics_DLL.Cls_ImgCmp();
            ScreenCapture(@"C:\ARC\ZIRC\SS_ZDRP.jpg");
            objclsImgCmp.CropImage(30, 252, 17, 14, @"C:\ARC\ZIRC\SS_ZDRP.jpg", @"C:\ARC\ZIRC\Crp_ZDRP.jpg");
            convertGrayImages(@"C:\ARC\ZIRC\Crp_ZDRP.jpg", @"C:\ARC\ZIRC\IColor_ZDRP.jpg");            
            Bitmap bmp1 = new Bitmap(@"C:\ARC\ZIRC\IColor_ZDRP.jpg");            
            for (int y = 0; y < 9; y++)
            {
                for (int x = 0; x < 12; x++)
                {
                    if (bmp1.GetPixel(y, x).Name == "ff000000")
                    {
                        result = true;
                    }
                }
            }
            bmp1.Dispose();
            return result;
        }
        public int FindNoOfOpenWindow()
        {
            int i = 0;
            int j = 0;
            int chck = 0;
            string[] arryWindowTitle = new string[20];
            Process[] processes = Process.GetProcesses();
            foreach (Process p in processes)
            {
                if (!String.IsNullOrEmpty(p.MainWindowTitle))
                {
                    arryWindowTitle[i] = p.MainWindowTitle.ToString();
                    if (p.MainWindowTitle.ToString() == "OpicsPlus - \\\\Remote" || p.MainWindowTitle.ToString() == "LOGR - \\\\Remote" || p.MainWindowTitle.ToString() == "Opics Plus - \\\\Remote")
                    {
                        SwitchToThisWindow(processes[j].MainWindowHandle, true);
                        chck = 1;
                        break;
                    }
                    i++;
                }
                j++;
            }
            return chck;
        }
        public static void ReleaseComObject(object ob)
        {
            try
            {                
                while (System.Runtime.InteropServices.Marshal.ReleaseComObject(ob) != 0) { }

                ob = null;
            }
            catch
            {
                ob = null;
            }
            finally
            {
                GC.Collect(GC.MaxGeneration);
                GC.WaitForPendingFinalizers();
            }
        }
        public bool getModifyDate(string FilePath, string Pre_DMD)
        {
            bool result = false;
            DateTime lastModified = System.IO.File.GetLastWriteTime(FilePath);
            string DMD = lastModified.ToString("dd/MM/yy HH:mm:ss");
            if (DMD == Pre_DMD)
            {
                result = true;
            }            
            Thread.Sleep(1000);
            return result;
        }
        public void pressfFifteen(string val)
        {
            //SendKeys.Send("{F15}");
            if (val == "F15")
            {
                objclsfunopics.startprocess(14, 25, 0, 0, 2000, "F15", "");
            }
            else if (val == "Pscreen")
            {
                objclsfunopics.startprocess(0, 0, 0, 0, 2000, "Pscreen", "");
            }
            else if (val == "NUMLock")
            {
                objclsfunopics.startprocess(0, 0, 0, 0, 2000, "NUMLock", "");
            }

        }
        public bool IfSaveNotMatched(string input, out string ErrorMsg)
        {
            bool result = false;
            ErrorMsg = "";
            try
            {
                
                objclsfunopics.startprocess(321, 193, 100, 20, 4000, "Passvalue", input);
                //for (int i = 0; i < 3; i++)
                //{
                //    objclsfunopics.startprocess(146, 126, 100, 20, 2000, "Tab_Win", "");
                //}
                //objclsfunopics.startprocess(146, 126, 100, 20, 2000, "Enter_Win", "");
                result = true;
            }
            catch(Exception ex)
            {
                ErrorMsg = ex.ToString();
            }
            return result;
        }
        public bool IfSaveNotMatched_test(string input, out string ErrorMsg)
        {
            bool result = false;
            ErrorMsg = "";
            try
            {
                Thread.Sleep(3000);
                objclsfunopics.startprocess(321, 193, 100, 20, 4000, "Passvalue", input);
                Thread.Sleep(3000);
                objclsfunopics.startprocess(146, 126, 100, 20, 2000, "Enter_Win", "");
                Thread.Sleep(3000);
                result = true;
            }
            catch (Exception ex)
            {
                ErrorMsg = ex.ToString();
            }
            return result;
        }
        #region Email SD
        public void Create_Directory_Chk(string conStr, string Main_DIR_SharePath)
        {
            try
            {
                if (!Directory.Exists(Main_DIR_SharePath))
                {
                    Directory.CreateDirectory(Main_DIR_SharePath);
                }
                string filePath = Main_DIR_SharePath + "MailFoldersCreate_Info.txt";
                bool IsRunning = IsExeRunning(filePath);
                if (IsRunning == false)
                {
                    System.Data.DataTable Share_Folder = new System.Data.DataTable();
                    Share_Folder = QueryValues_FolderCreation(conStr);
                    string Folderpath = string.Empty;
                    DataRow[] dr = Share_Folder.Select();
                    foreach (DataRow d in dr)
                    {
                        //string Email_Shared_Path = Convert.ToString(d["Email_Shared_Path"]);
                        string Email_Shared_Path = @"\\10.132.5.78\DataManagement\rpa\Country_Shared Drive\";
                        //string Email_Shared_Path = @"C:\10.132.5.214\Country_Shared Drive\";
                        string Country_Name = Convert.ToString(d["Country_Name"]) + "_Country Sharedrive";
                        if (Email_Shared_Path != "")
                        {
                            if (!Directory.Exists(Email_Shared_Path))
                            {
                                Directory.CreateDirectory(Email_Shared_Path);
                            }
                            if (DateTime.Today.DayOfWeek.ToString() != "Friday")
                            {
                                if (!Directory.Exists(Email_Shared_Path + "\\" + Country_Name + "\\" + DateTime.Today.AddDays(-1).ToString("dd-MMM-yyyy")))
                                {
                                    Directory.CreateDirectory(Email_Shared_Path + "\\" + Country_Name + "\\" + DateTime.Today.AddDays(-1).ToString("dd-MMM-yyyy"));
                                }
                                if (!Directory.Exists(Email_Shared_Path + "\\" + Country_Name + "\\" + DateTime.Today.ToString("dd-MMM-yyyy")))
                                {
                                    Directory.CreateDirectory(Email_Shared_Path + "\\" + Country_Name + "\\" + DateTime.Today.ToString("dd-MMM-yyyy"));
                                }
                                if (!Directory.Exists(Email_Shared_Path + "\\" + Country_Name + "\\" + DateTime.Today.AddDays(+1).ToString("dd-MMM-yyyy")))
                                {
                                    Directory.CreateDirectory(Email_Shared_Path + "\\" + Country_Name + "\\" + DateTime.Today.AddDays(+1).ToString("dd-MMM-yyyy"));
                                }

                            }
                            else
                            {
                                if (!Directory.Exists(Email_Shared_Path + "\\" + Country_Name + "\\" + DateTime.Today.ToString("dd-MMM-yyyy")))
                                {
                                    Directory.CreateDirectory(Email_Shared_Path + "\\" + Country_Name + "\\" + DateTime.Today.ToString("dd-MMM-yyyy"));
                                }
                                if (!Directory.Exists(Email_Shared_Path + "\\" + Country_Name + "\\" + DateTime.Today.AddDays(+1).ToString("dd-MMM-yyyy")))
                                {
                                    Directory.CreateDirectory(Email_Shared_Path + "\\" + Country_Name + "\\" + DateTime.Today.AddDays(+1).ToString("dd-MMM-yyyy"));
                                }
                                if (!Directory.Exists(Email_Shared_Path + "\\" + Country_Name + "\\" + DateTime.Today.AddDays(+2).ToString("dd-MMM-yyyy")))
                                {
                                    Directory.CreateDirectory(Email_Shared_Path + "\\" + Country_Name + "\\" + DateTime.Today.AddDays(+2).ToString("dd-MMM-yyyy"));
                                }
                                if (!Directory.Exists(Email_Shared_Path + "\\" + Country_Name + "\\" + DateTime.Today.AddDays(+3).ToString("dd-MMM-yyyy")))
                                {
                                    Directory.CreateDirectory(Email_Shared_Path + "\\" + Country_Name + "\\" + DateTime.Today.AddDays(+3).ToString("dd-MMM-yyyy"));
                                }
                            }
                        }
                    }
                }
            }
            catch
            {

            }
        }
        public void Folder_Movement_ChkRecon(string conString, string Main_DIR_SharePath, string strDirectory)
        {
            aTimer.Stop();

            string Country_Path = string.Empty;
            string InputFolder_Path = string.Empty;
            string[] mul = null;

            //SA1001
            try
            {
                System.Data.DataTable dt_Recon = new System.Data.DataTable();
                SqlConnection con = new SqlConnection(conString);
                SqlCommand cmd = new SqlCommand();
                //Individual Recons
                //SqlDataAdapter ad = new SqlDataAdapter("select * from ARC_Recon_Master where Recon_Name = 'Vietnam ACB'", con);

                //All Recons
                SqlDataAdapter ad = new SqlDataAdapter("select * from ARC_Recon_Master where Is_Recon_Completed = 0 and Is_Active = 1 and isMailDownloadComplete=0 and Is_Holiday_Logic = 0 order by Receipt_Time ASC", con);

                con.Open();
                ad.Fill(dt_Recon);
                DataRow[] drr = dt_Recon.Select();

                con.Close();
                for (int i = 0; i < dt_Recon.Rows.Count; i++)
                {

                    int files_moved_count = 0;
                    System.Data.DataTable Share_Folder = new System.Data.DataTable();
                    Share_Folder = QueryValues_ChkRecons(conString);

                    DataRow[] dr = Share_Folder.Select();

                    foreach (DataRow d in dr)
                    {
                        string Country = Convert.ToString(d["Country_Name"]);
                        string File_Name = Convert.ToString(d["Report_Source_File_Name"]);
                        string IsFormatting = Convert.ToString(d["Format_Direct_Upload"]);
                        string Source_App = Convert.ToString(d["Source_Application"]);
                        string File_Ext = Convert.ToString(d["File_Format"]);
                        string Receipt_Time = Convert.ToString(d["Receipt_Time"]);
                        string Email_Shared_Path = Convert.ToString(d["Email_Shared_Path"]);
                        string Recon = Convert.ToString(d["Recon"]);
                        string Email_Subject = Convert.ToString(d["Email_Subject"]);
                        string Email_ID = Convert.ToString(d["Email_ID"]);
                        string product_id = Convert.ToString(d["product_id"]);
                        int Recon_Id = Convert.ToInt32(d["Recon_ID"]);
                        bool foldermovement_complete = Convert.ToBoolean(d["foldermovement_complete"]);
                        bool isMailFunctionalityRequired = Convert.ToBoolean(d["isMailFunctionalityRequired"]);
                        var time = TimeSpan.Parse(Receipt_Time);
                        var dateTime = DateTime.Today.Add(time);

                        var diff = dateTime.Subtract(DateTime.Now);

                        double Hour = Convert.ToDouble(diff.Hours);
                        double Min = Convert.ToDouble(diff.Minutes);
                        double Sec = Convert.ToDouble(diff.Seconds);
                        //var res = String.Format("{0}:{1}:{2}", diff.Hours,diff.Minutes,diff.Seconds));

                        double converter = Hour * 60 + Min + (Sec / 60);
                        System.Data.DataTable dtt = new System.Data.DataTable();
                        SqlDataAdapter ad1 = new SqlDataAdapter("select count(*) from ARC_scope_baseline where source_application = 'Email' and foldermovement_complete=0 and Recon_id in (select Recon_id from ARC_recon_master where isMailDownloadComplete=0 and Recon_id='" + Recon_Id + "')", con);
                        con.Open();
                        ad1.Fill(dtt);
                        con.Close();
                        if (File_Name.Contains("YYYY_MM_DD"))
                        {
                            File_Name = File_Name.Replace("YYYY_MM_DD", "");
                        }
                        else if (File_Name.Contains("YYYY_MM_DD"))
                        {
                            File_Name = File_Name.Replace("YYYY_MM_DD", "");
                        }
                        else if (File_Name.Contains("DD-MMM YYYY"))
                        {
                            File_Name = File_Name.Replace("DD-MMM YYYY", "").Trim();
                        }
                        else if (File_Name.Contains("DD-MMM"))
                        {
                            File_Name = File_Name.Replace("DD-MMM", "");
                        }
                        else if (File_Name.Contains("DD-MM"))
                        {
                            File_Name = File_Name.Replace("DD-MM", "");
                        }
                        else if (File_Name.Contains("DD.MM.YYYY"))
                        {
                            File_Name = File_Name.Replace("DD.MM.YYYY", "");
                        }
                        else if (File_Name.Contains("DD_MM_YYYY"))
                        {
                            File_Name = File_Name.Replace("DD_MM_YYYY", "");
                        }
                        else if (File_Name.Contains("DD-MM-YYYY"))
                        {
                            File_Name = File_Name.Replace("DD-MM-YYYY", "");
                        }
                        else if (File_Name.Contains("MM.DD.YYYY"))
                        {
                            File_Name = File_Name.Replace("MM.DD.YYYY", "");
                        }
                        else if (File_Name.Contains("DDMMYYYY"))
                        {
                            File_Name = File_Name.Replace("DDMMYYYY", "");
                        }
                        else if (File_Name.Contains("DDMMYY"))
                        {
                            File_Name = File_Name.Replace("DDMMYY", "");
                        }
                        else if (File_Name.Contains("YYYYMMDD"))
                        {
                            File_Name = File_Name.Replace("YYYYMMDD", "");
                        }
                        else if (File_Name.Contains("YYYY-MM-DD"))
                        {
                            File_Name = File_Name.Replace("YYYY-MM-DD", "");
                        }
                        else if (File_Name.Contains("DD MMM YY"))
                        {
                            File_Name = File_Name.Replace("DD MMM YY", "");
                        }
                        else if (File_Name.Contains("DD MM YY"))
                        {
                            File_Name = File_Name.Replace("DD MM YY", "");
                        }
                        else if (File_Name.Contains("DD_MM"))
                        {
                            File_Name = File_Name.Replace("DD_MM", "");
                        }
                        else if (File_Name.Contains("YYDDMM"))
                        {
                            File_Name = File_Name.Replace("YYDDMM", "");
                        }
                        else if (File_Name.Contains("YYYY-MM"))
                        {
                            File_Name = File_Name.Replace("YYYY-MM", "");
                        }
                        else if (File_Name.Contains("DD.MM.YY"))
                        {
                            File_Name = File_Name.Replace("DD.MM.YY", "");
                        }
                        else if (File_Name.Contains("DDMM-DDMM"))
                        {
                            File_Name = File_Name.Replace("DDMM-DDMM", "");
                        }

                        //File_Name = GetFileName_ChkRecMulfiles(Email_Shared_Path + Country + "_Country Sharedrive\\" + DateTime.Today.ToString("dd-MMM-yyyy") + "\\", File_Name);
                        File_Name = GetFileName_ChkRecMulfiles(@"\\10.132.5.78\DataManagement\RPA\Country_Shared Drive\" + Country + "_Country Sharedrive\\" + DateTime.Today.ToString("dd-MMM-yyyy") + "\\", File_Name);
                        if (File_Name.Contains(','))
                        {
                            mul = File_Name.Split(',');
                            if (mul.Length > 2)
                            {
                                for (int x = 0; x <= mul.Length - 1; x++)
                                {
                                    if (mul[x].ToString() != "")
                                    {
                                        InputFolder_Path = Main_DIR_SharePath + "\\Input\\Emails\\" + mul[x].ToString().Trim() + "." + File_Ext;
                                        Country_Path = Email_Shared_Path + Country + "_Country Sharedrive\\" + DateTime.Today.ToString("dd-MMM-yyyy") + "\\" + mul[x].ToString().Trim() + "." + File_Ext;

                                        if (foldermovement_complete == false && File.Exists(Country_Path))
                                        {
                                            if (File.Exists(InputFolder_Path))
                                            {
                                                File.Delete(InputFolder_Path);
                                            }

                                            File.Copy(Country_Path, InputFolder_Path);
                                            files_moved_count = files_moved_count + 1;

                                        }
                                    }
                                    string query1 = "Update ARC_scope_baseline set Foldermovement_Complete = 1 where Recon_ID = '" + Recon_Id + "'";

                                    SqlConnection con1 = new SqlConnection(conString);
                                    SqlCommand cmd1 = new SqlCommand(query1, con1);
                                    if (con1.State == ConnectionState.Closed)
                                    {
                                        con1.Open();
                                    }
                                    cmd1.ExecuteNonQuery();
                                    if (con1.State == ConnectionState.Open)
                                    {
                                        con1.Close();
                                    }
                                    if (dt_Recon.Rows[i]["MailFilesReq"].ToString().Trim() != "")
                                    {
                                        if (files_moved_count == Convert.ToInt32(mul.Length - 1) * Convert.ToInt32(dt_Recon.Rows[i]["MailFilesReq"].ToString()))
                                        {

                                            SqlConnection conn = new SqlConnection(conString);
                                            SqlCommand Updt_cmd2 = new SqlCommand("update ARC_Recon_Master set IsMailDownloadComplete=1 where Recon_Id = " + Recon_Id + "", conn);
                                            conn.Open();
                                            Updt_cmd2.ExecuteNonQuery();
                                            conn.Close();

                                        }
                                    }
                                }
                            }
                        }

                        if (mul == null)
                        {
                            FileCopyUpdate(conString, File_Name, @"\\10.132.5.78\DataManagement\RPA\Country_Shared Drive\", Country, InputFolder_Path, Country_Path, File_Ext, Share_Folder, Recon, Email_ID, isMailFunctionalityRequired, foldermovement_complete, converter, files_moved_count, i, Recon_Id, dt_Recon, product_id, Main_DIR_SharePath, strDirectory);
                        }
                        else if (mul != null)
                        {
                            if (mul.Length <= 2)
                            {
                                FileCopyUpdate(conString, File_Name, @"\\10.132.5.78\DataManagement\RPA\Country_Shared Drive\", Country, InputFolder_Path, Country_Path, File_Ext, Share_Folder, Recon, Email_ID, isMailFunctionalityRequired, foldermovement_complete, converter, files_moved_count, i, Recon_Id, dt_Recon, product_id, Main_DIR_SharePath, strDirectory);
                            }
                        }


                        //SourcePath = StrDirectory + "Input\\" + Source_Application + "_" + Country_Name + "\\";

                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
        }
        public void Folder_Movement_ChkReconMail(string conString, string Main_DIR_SharePath, string strDirectory)
        {
            aTimer.Stop();

            string Country_Path = string.Empty;
            string InputFolder_Path = string.Empty;
            string[] mul = null;

            //SA1001
            try
            {
                System.Data.DataTable dt_Recon = new System.Data.DataTable();
                SqlConnection con = new SqlConnection(conString);
                SqlCommand cmd = new SqlCommand();
                //Individual Recons
                //SqlDataAdapter ad = new SqlDataAdapter("select * from ARC_Recon_Master where Recon_Name = 'Vietnam ACB'", con);

                //All Recons
                SqlDataAdapter ad = new SqlDataAdapter("select * from ARC_Recon_Master where Is_Recon_Completed = 0 and Is_Active = 1 and isMailDownloadComplete=0 and IsEmailRequired = 1 and Is_Holiday_Logic = 0 order by Receipt_Time ASC", con);

                con.Open();
                ad.Fill(dt_Recon);
                DataRow[] drr = dt_Recon.Select();

                con.Close();
                for (int i = 0; i < dt_Recon.Rows.Count; i++)
                {

                    int files_moved_count = 0;
                    System.Data.DataTable Share_Folder = new System.Data.DataTable();
                    Share_Folder = QueryValues_ChkReconsMail(conString);

                    DataRow[] dr = Share_Folder.Select();

                    foreach (DataRow d in dr)
                    {
                        string Country = Convert.ToString(d["Country_Name"]);
                        string File_Name = Convert.ToString(d["Report_Source_File_Name"]);
                        string IsFormatting = Convert.ToString(d["Format_Direct_Upload"]);
                        string Source_App = Convert.ToString(d["Source_Application"]);
                        string File_Ext = Convert.ToString(d["File_Format"]);
                        string Receipt_Time = Convert.ToString(d["Receipt_Time"]);
                        string Email_Shared_Path = Convert.ToString(d["Email_Shared_Path"]);
                        string Recon = Convert.ToString(d["Recon"]);
                        string Email_Subject = Convert.ToString(d["Email_Subject"]);
                        string Email_ID = Convert.ToString(d["Email_ID"]);
                        string product_id = Convert.ToString(d["product_id"]);
                        int Recon_Id = Convert.ToInt32(d["Recon_ID"]);
                        bool foldermovement_complete = Convert.ToBoolean(d["foldermovement_complete"]);
                        bool isMailFunctionalityRequired = Convert.ToBoolean(d["isMailFunctionalityRequired"]);
                        var time = TimeSpan.Parse(Receipt_Time);
                        var dateTime = DateTime.Today.Add(time);

                        var diff = dateTime.Subtract(DateTime.Now);

                        double Hour = Convert.ToDouble(diff.Hours);
                        double Min = Convert.ToDouble(diff.Minutes);
                        double Sec = Convert.ToDouble(diff.Seconds);
                        //var res = String.Format("{0}:{1}:{2}", diff.Hours,diff.Minutes,diff.Seconds));

                        double converter = Hour * 60 + Min + (Sec / 60);
                        System.Data.DataTable dtt = new System.Data.DataTable();
                        SqlDataAdapter ad1 = new SqlDataAdapter("select count(*) from ARC_scope_baseline where source_application = 'Email' and foldermovement_complete=0 and Recon_id in (select Recon_id from ARC_recon_master where isMailDownloadComplete=0 and Recon_id='" + Recon_Id + "')", con);
                        con.Open();
                        ad1.Fill(dtt);
                        con.Close();
                        if (File_Name.Contains("YYYY_MM_DD"))
                        {
                            File_Name = File_Name.Replace("YYYY_MM_DD", "");
                        }
                        else if (File_Name.Contains("YYYY_MM_DD"))
                        {
                            File_Name = File_Name.Replace("YYYY_MM_DD", "");
                        }
                        else if (File_Name.Contains("DD-MMM YYYY"))
                        {
                            File_Name = File_Name.Replace("DD-MMM YYYY", "").Trim();
                        }
                        else if (File_Name.Contains("DD-MMM"))
                        {
                            File_Name = File_Name.Replace("DD-MMM", "");
                        }
                        else if (File_Name.Contains("DD-MM"))
                        {
                            File_Name = File_Name.Replace("DD-MM", "");
                        }
                        else if (File_Name.Contains("DD.MM.YYYY"))
                        {
                            File_Name = File_Name.Replace("DD.MM.YYYY", "");
                        }
                        else if (File_Name.Contains("DD_MM_YYYY"))
                        {
                            File_Name = File_Name.Replace("DD_MM_YYYY", "");
                        }
                        else if (File_Name.Contains("DD-MM-YYYY"))
                        {
                            File_Name = File_Name.Replace("DD-MM-YYYY", "");
                        }
                        else if (File_Name.Contains("MM.DD.YYYY"))
                        {
                            File_Name = File_Name.Replace("MM.DD.YYYY", "");
                        }
                        else if (File_Name.Contains("DDMMYYYY"))
                        {
                            File_Name = File_Name.Replace("DDMMYYYY", "");
                        }
                        else if (File_Name.Contains("DDMMYY"))
                        {
                            File_Name = File_Name.Replace("DDMMYY", "");
                        }
                        else if (File_Name.Contains("YYYYMMDD"))
                        {
                            File_Name = File_Name.Replace("YYYYMMDD", "");
                        }
                        else if (File_Name.Contains("YYYY-MM-DD"))
                        {
                            File_Name = File_Name.Replace("YYYY-MM-DD", "");
                        }
                        else if (File_Name.Contains("DD MMM YY"))
                        {
                            File_Name = File_Name.Replace("DD MMM YY", "");
                        }
                        else if (File_Name.Contains("DD MM YY"))
                        {
                            File_Name = File_Name.Replace("DD MM YY", "");
                        }
                        else if (File_Name.Contains("DD_MM"))
                        {
                            File_Name = File_Name.Replace("DD_MM", "");
                        }
                        else if (File_Name.Contains("YYDDMM"))
                        {
                            File_Name = File_Name.Replace("YYDDMM", "");
                        }
                        else if (File_Name.Contains("YYYY-MM"))
                        {
                            File_Name = File_Name.Replace("YYYY-MM", "");
                        }
                        else if (File_Name.Contains("DD.MM.YY"))
                        {
                            File_Name = File_Name.Replace("DD.MM.YY", "");
                        }
                        else if (File_Name.Contains("DDMM-DDMM"))
                        {
                            File_Name = File_Name.Replace("DDMM-DDMM", "");
                        }

                        //File_Name = GetFileName_ChkRecMulfiles(Email_Shared_Path + Country + "_Country Sharedrive\\" + DateTime.Today.ToString("dd-MMM-yyyy") + "\\", File_Name);
                        File_Name = GetFileName_ChkRecMulfiles(@"\\10.132.5.78\DataManagement\RPA\Country_Shared Drive\" + Country + "_Country Sharedrive\\" + DateTime.Today.ToString("dd-MMM-yyyy") + "\\", File_Name);
                        if (File_Name.Contains(','))
                        {
                            mul = File_Name.Split(',');
                            if (mul.Length > 2)
                            {
                                for (int x = 0; x <= mul.Length - 1; x++)
                                {
                                    if (mul[x].ToString() != "")
                                    {
                                        InputFolder_Path = Main_DIR_SharePath + "\\Input\\Emails\\" + mul[x].ToString().Trim() + "." + File_Ext;
                                        Country_Path = Email_Shared_Path + Country + "_Country Sharedrive\\" + DateTime.Today.ToString("dd-MMM-yyyy") + "\\" + mul[x].ToString().Trim() + "." + File_Ext;
                                        if (foldermovement_complete == false && isMailFunctionalityRequired == true && !File.Exists(Country_Path))
                                        {
                                            Microsoft.Office.Interop.Outlook.Application app = new Microsoft.Office.Interop.Outlook.Application();
                                            Microsoft.Office.Interop.Outlook.MailItem mailItem = (Microsoft.Office.Interop.Outlook.MailItem)app.CreateItem(Microsoft.Office.Interop.Outlook.OlItemType.olMailItem);
                                            mailItem.Subject = "Remainder-- Files Required for Recon: " + Recon;
                                            if (product_id == "5")
                                            {
                                                mailItem.SentOnBehalfOfName = "GRU.DataUpload-Nostro@sc.com";
                                                //mailItem.SentOnBehalfOfName = "kiran.h@sc.com";
                                                mailItem.CC = "GRU.DataUpload-Nostro@sc.com";
                                            }
                                            else if (product_id == "1")
                                            {
                                                mailItem.SentOnBehalfOfName = "GRU.DataUpload-Retail@sc.com";
                                                //mailItem.SentOnBehalfOfName = "kiran.h@sc.com";
                                                mailItem.CC = "GRU.DataUpload-Retail@sc.com";
                                            }
                                            else if (product_id == "2" || product_id == "3" || product_id == "4" || product_id == "6")
                                            {
                                                mailItem.SentOnBehalfOfName = "GRU.DataUpload-FX-SS@sc.com";
                                                //mailItem.SentOnBehalfOfName = "kiran.h@sc.com";
                                                mailItem.CC = "GRU.DataUpload-FX-SS@sc.com";
                                            }
                                            mailItem.To = Email_ID;
                                            mailItem.Body = "Dear all, \n"
                                                         + "\n"
                                                         + "We are nearing our SLA to commence the reconciliation for" + Recon + "\n"
                                                         + "\n"
                                                         + "Can you please place the input file " + File_Name + " in respective country shared folder without any further delay." + " \n"
                                                         + "\n"
                                                         + "This is a Auto generated email \n"
                                                         + "\nIf you have any further query on this, respond to the generic email ID - "
                                                         + mailItem.CC.ToString() + "\n"
                                                         + "\nThanks"
                                                         + "\n\n"
                                                         + "DataUpload Team";

                                            mailItem.Importance = Microsoft.Office.Interop.Outlook.OlImportance.olImportanceHigh;
                                            mailItem.Display(false);
                                            mailItem.Send();
                                        }

                                    }

                                }
                            }
                        }

                        if (mul == null)
                        {
                            FileCopyUpdateMail(conString, File_Name, @"\\10.132.5.78\DataManagement\RPA\Country_Shared Drive\", Country, InputFolder_Path, Country_Path, File_Ext, Share_Folder, Recon, Email_ID, isMailFunctionalityRequired, foldermovement_complete, converter, files_moved_count, i, Recon_Id, dt_Recon, product_id, Main_DIR_SharePath, strDirectory);
                        }
                        else if (mul != null)
                        {
                            if (mul.Length <= 2)
                            {
                                FileCopyUpdateMail(conString, File_Name, @"\\10.132.5.78\DataManagement\RPA\Country_Shared Drive\", Country, InputFolder_Path, Country_Path, File_Ext, Share_Folder, Recon, Email_ID, isMailFunctionalityRequired, foldermovement_complete, converter, files_moved_count, i, Recon_Id, dt_Recon, product_id, Main_DIR_SharePath, strDirectory);
                            }
                        }


                        //SourcePath = StrDirectory + "Input\\" + Source_Application + "_" + Country_Name + "\\";

                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
        }
        public void Folder_Movement_Formatting3_2(string Main_DIR_SharePath, string conString, string strDirectory)
        {
            aTimer.Stop();

            string Country_Path = string.Empty;
            string InputFolder_Path = string.Empty;


            //SA1001
            try
            {
                DAccess das = new DAccess();
                Hashtable hat = new Hashtable();

                string sDirectory = Main_DIR_SharePath + DateTime.Now.ToString("dd-MMM-yyyy") + "_Files\\";

                //Indidvidual recons
                //string strquery = "select distinct recon_name,recon_id,total_files,MailFilesReq from Arc_Recon_Master_Holiday_Date_Logic where  recon_name='SCB IRAQ Account Balance Report' order by recon_name";

                //All Recons
                string strquery = "select distinct recon_name,recon_id,total_files,recon_date,MailFilesReq,receipt_time from Arc_Recon_Master_Holiday_Date_Logic where Is_Recon_Completed = 0 and Is_Active = 1 and recon_id in (select recon_id from arc_recon_master where Is_Recon_Completed = 0 and Is_Active = 1 and isMailDownloadComplete=0 and Is_Holiday_Logic = 1 and recon_name != 'India Clearing' and recon_name != 'India Clearing Inward' and recon_name != 'India Clearing Outward') order by receipt_time";


                System.Data.DataTable dtReconMaster = das.Select_Table(strquery, hat, "Text", conString);

                string strIInputFileName = string.Empty;
                string strOutPutFileName = string.Empty;
                string SourcePath = string.Empty;
                string Foramtted_Recon_Date = string.Empty;
                string strReconName = string.Empty;
                string Desti_Path = string.Empty;
                string Output_Path = string.Empty;
                string Recon_Date = string.Empty;
                string db_Ext = string.Empty;
                string Recon_name = string.Empty;

                int c = 0;

                for (int i = 0; i < dtReconMaster.Rows.Count; i++)
                {
                    bool flag = true;
                    int files_moved_count = 0;
                    int total_files_tobepresent = 0;
                    Recon_name = Convert.ToString(dtReconMaster.Rows[i]["recon_name"]);
                    Recon_Date = Convert.ToString(dtReconMaster.Rows[i]["Recon_Date"]);

                    strquery = "select count(recon_date) as count from Arc_Recon_Master_Holiday_Date_Logic where recon_name='" + Recon_name + "'";
                    System.Data.DataTable dtcount = das.Select_Table(strquery, hat, "Text", conString);

                    if (dtcount.Rows[0]["count"].ToString().Trim() != "" && dtReconMaster.Rows[i]["MailFilesReq"].ToString().Trim() != "")
                    {
                        total_files_tobepresent = Convert.ToInt32(dtcount.Rows[0]["count"].ToString()) * Convert.ToInt32(dtReconMaster.Rows[i]["MailFilesReq"].ToString());
                    }
                    else
                    {
                        total_files_tobepresent = 0;
                    }

                    int Recon_Id = Convert.ToInt32(dtReconMaster.Rows[i]["recon_id"]);
                    int File_Count = Convert.ToInt32(dtReconMaster.Rows[i]["total_files"]);
                    //DateTime dtRecondate = Convert.ToDateTime(dtReconMaster.Rows[i]["recon_date"]);
                    //Recon_Date = Convert.ToString(dtReconMaster.Rows[i]["Recon_date"]);
                    string selquery1 = "select distinct Recon_Date,Is_Recon_Completed,MailFilesReq from Arc_Recon_Master_Holiday_Date_Logic where recon_name ='" + Recon_name + "' order by Recon_date";
                    System.Data.DataTable dtsel1 = das.Select_Table(selquery1, hat, "Text", conString);
                    for (int j = 0; j < dtsel1.Rows.Count; j++)
                    {
                        DateTime dt_Recondate = Convert.ToDateTime(dtsel1.Rows[j]["Recon_Date"]);
                        //EA1001                        
                        ///Added by Prakash - For checking the Least Recon Date file is processed or not, if not skip that recon and go for next recon
                        //string selquery = "select top(1) Report_Source_File_Name,Recon_Date,IsProcessed,automationStatus from arc_scope_baseline_logic where recon ='" + Recon_name + "' order by Recon_date";
                        // DataTable dtsel = das.Select_Table(selquery, hat, "Text");


                        //Indidvidual recons
                        //strquery = "select Team, Country_Name, Recon, Report_Source_File_Name,FTP_File_Format_Name, Recon_date from ARC_Scope_Baseline_Logic where recon='SCB IRAQ Account Balance Report' and recon_date='" + dt_Recondate.ToString("MM/dd/yyyy") + "' ";


                        //All Recons-15-02-18
                        strquery = "select * from ARC_scope_baseline_logic a inner join ARC_scope_baseline b on a.recon_id=b.recon_id where source_application = 'Email' and foldermovement_complete=0 and (SLA_Time>='" + DateTime.Now.ToString("HH:mm:ss.fff") + "' and Receipt_Time<='" + DateTime.Now.ToString("HH:mm:ss.fff") + "') and a.Recon_id in (select recon_id from ARC_recon_master where IsEmailRequired = 1 and Is_Holiday_Logic = 1) order by Receipt_Time asc";
                        System.Data.DataTable dtBaseHoliday = das.Select_Table(strquery, hat, "Text", conString);


                        System.Data.DataTable dt = new System.Data.DataTable();
                        SqlConnection con = new SqlConnection(conString);

                        strquery = "select * from ARC_scope_baseline where source_application = 'Email' and (SLA_Time>='" + DateTime.Now.ToString("HH:mm:ss.fff") + "' and Receipt_Time<='" + DateTime.Now.ToString("HH:mm:ss.fff") + "') and foldermovement_complete=0 and Recon_id in (select recon_id from ARC_recon_master where Is_Holiday_Logic = 1 and Recon_id='" + Recon_Id + "')order by Receipt_Time asc";
                        System.Data.DataTable dtScopeBaseline = das.Select_Table(strquery, hat, "Text", conString);

                        DataRow[] dr = dtScopeBaseline.Select();
                        //DataTable dtt = new DataTable();
                        //////SqlDataAdapter ad1 = new SqlDataAdapter("select count(*) from ARC_scope_baseline_logic where Recon_id in ('" + Recon_Id + "')", con);
                        //SqlDataAdapter ad1 = new SqlDataAdapter("select count(distinct B.Report_Source_File_Name) from ARC_scope_baseline_logic A, ARC_scope_baseline B where A.Recon_id='" + Recon_Id + "' and B.Recon_id='" + Recon_Id + "' and B.Source_Application='Email'", con);
                        //con.Open();
                        //ad1.Fill(dtt);
                        if (Convert.ToInt32(dtcount.Rows[0]["count"].ToString()) > 1)
                        {
                            foreach (DataRow d in dr)
                            {
                                string Country = Convert.ToString(d["Country_Name"]);
                                string File_Name = Convert.ToString(d["Report_Source_File_Name"]);
                                string IsFormatting = Convert.ToString(d["Format_Direct_Upload"]);
                                string Source_App = Convert.ToString(d["Source_Application"]);
                                string File_Ext = Convert.ToString(d["File_Format"]);
                                string Receipt_Time = Convert.ToString(d["Receipt_Time"]);
                                string Email_Shared_Path = Convert.ToString(d["Email_Shared_Path"]);
                                string Recon = Convert.ToString(d["Recon"]);
                                string Email_Subject = Convert.ToString(d["Email_Subject"]);
                                string Email_ID = Convert.ToString(d["Email_ID"]);
                                string product_id = Convert.ToString(d["product_id"]);
                                bool foldermovement_complete = Convert.ToBoolean(d["foldermovement_complete"]);
                                bool isMailFunctionalityRequired = Convert.ToBoolean(d["isMailFunctionalityRequired"]);
                                var time = TimeSpan.Parse(Receipt_Time);
                                var dateTime = DateTime.Today.Add(time);

                                var diff = dateTime.Subtract(DateTime.Now);

                                double Hour = Convert.ToDouble(diff.Hours);
                                double Min = Convert.ToDouble(diff.Minutes);
                                double Sec = Convert.ToDouble(diff.Seconds);
                                //var res = String.Format("{0}:{1}:{2}", diff.Hours,diff.Minutes,diff.Seconds));

                                double converter = Hour * 60 + Min + (Sec / 60);

                                if (File_Name.Contains("YYYY_MM_DD"))
                                {
                                    Recon_Date = dt_Recondate.ToString("yyyy_MM_dd");
                                    File_Name = File_Name.Replace("YYYY_MM_DD", Recon_Date);
                                }
                                else if (File_Name.Contains("DD-MMM"))
                                {
                                    Recon_Date = dt_Recondate.ToString("dd-MMM");
                                    File_Name = File_Name.Replace("DD-MMM", Recon_Date);
                                }
                                else if (File_Name.Contains("DD-MM"))
                                {
                                    Recon_Date = dt_Recondate.ToString("dd-MM");
                                    File_Name = File_Name.Replace("DD-MM", Recon_Date);
                                }
                                else if (File_Name.Contains("DD.MM.YYYY"))
                                {
                                    Recon_Date = dt_Recondate.ToString("dd.MM.yyyy");

                                    File_Name = File_Name.Replace("DD.MM.YYYY", Recon_Date);
                                }
                                else if (File_Name.Contains("DD_MM_YYYY"))
                                {
                                    Recon_Date = dt_Recondate.ToString("dd_MM_yyyy");

                                    File_Name = File_Name.Replace("DD_MM_YYYY", Recon_Date);
                                }
                                else if (File_Name.Contains("DD-MM-YYYY"))
                                {
                                    Recon_Date = dt_Recondate.ToString("dd-MM-yyyy");
                                    File_Name = File_Name.Replace("DD-MM-YYYY", Recon_Date);
                                }
                                else if (File_Name.Contains("MM.DD.YYYY"))
                                {
                                    Recon_Date = dt_Recondate.ToString("MM.dd.yyyy");
                                    File_Name = File_Name.Replace("MM.DD.YYYY", Recon_Date);
                                }
                                else if (File_Name.Contains("DDMMYYYY"))
                                {
                                    Recon_Date = dt_Recondate.ToString("ddMMyyyy");
                                    File_Name = File_Name.Replace("DDMMYYYY", Recon_Date);
                                }
                                else if (File_Name.Contains("DD-MMM YYYY"))
                                {
                                    Recon_Date = dt_Recondate.ToString("dd-MMM yyyy");
                                    File_Name = File_Name.Replace("DD-MMM YYYY", Recon_Date);
                                }
                                else if (File_Name.Contains("DDMMYY"))
                                {
                                    Recon_Date = dt_Recondate.ToString("ddMMyy");
                                    File_Name = File_Name.Replace("DDMMYY", Recon_Date);
                                }
                                else if (File_Name.Contains("YYYYMMDD"))
                                {
                                    Recon_Date = dt_Recondate.ToString("yyyyMMdd");
                                    File_Name = File_Name.Replace("YYYYMMDD", Recon_Date);
                                }
                                else if (File_Name.Contains("YYYY-MM-DD"))
                                {
                                    Recon_Date = dt_Recondate.ToString("yyyy-MM-dd");
                                    File_Name = File_Name.Replace("YYYY-MM-DD", Recon_Date);
                                }
                                else if (File_Name.Contains("DD MMM YY"))
                                {
                                    Recon_Date = dt_Recondate.ToString("dd MMM yy");
                                    File_Name = File_Name.Replace("DD MMM YY", Recon_Date);
                                }
                                else if (File_Name.Contains("DD MM YY"))
                                {
                                    Recon_Date = dt_Recondate.ToString("dd MM yy");
                                    File_Name = File_Name.Replace("DD MM YY", Recon_Date);
                                }
                                else if (File_Name.Contains("DD_MM"))
                                {
                                    Recon_Date = dt_Recondate.ToString("dd_MM");
                                    File_Name = File_Name.Replace("DD_MM", Recon_Date);
                                }
                                else if (File_Name.Contains("YYDDMM"))
                                {
                                    Recon_Date = dt_Recondate.ToString("yyddMM");
                                    File_Name = File_Name.Replace("YYDDMM", Recon_Date);
                                }
                                else if (File_Name.Contains("YYYY-MM"))
                                {
                                    Recon_Date = dt_Recondate.ToString("yyyy-MM");
                                    File_Name = File_Name.Replace("YYYY-MM", Recon_Date);
                                }
                                else if (File_Name.Contains("DD.MM.YY"))
                                {
                                    Recon_Date = dt_Recondate.ToString("dd.MM.yy");
                                    File_Name = File_Name.Replace("DD.MM.YY", Recon_Date);
                                }
                                ////if multiple folders for multiple days
                                ////DateTime myDate = DateTime.ParseExact(ReconDate.ToString(), "yyyy-MM-dd", System.Globalization.CultureInfo.InvariantCulture);

                                //if (File_Name != "")
                                //{
                                File_Name = GetFileName_3_2(Email_Shared_Path + Country + "_Country Sharedrive\\" + DateTime.Now.ToString("dd-MMM-yyyy") + "\\", File_Name, Recon_Date);
                                // }

                                InputFolder_Path = Main_DIR_SharePath + strDirectory + "\\Input\\Emails\\" + File_Name + "." + File_Ext;
                                Country_Path = Email_Shared_Path + Country + "_Country Sharedrive\\" + DateTime.Now.ToString("dd-MMM-yyyy") + "\\" + File_Name + "." + File_Ext;
                                if (File.Exists(Country_Path))
                                {
                                    c++;
                                }
                                else
                                {

                                }
                            }
                        }
                    }

                    if (Convert.ToInt32(dtcount.Rows[0]["count"].ToString()) > 1)
                    {
                        if (c == total_files_tobepresent)
                        {
                            flag = true;
                        }
                        else
                        {
                            flag = false;
                        }
                    }


                    if (flag == true)
                    {
                        System.Data.DataTable dt = new System.Data.DataTable();
                        SqlConnection con = new SqlConnection(conString);

                        strquery = "select * from ARC_scope_baseline where source_application = 'Email' and (SLA_Time>='" + DateTime.Now.ToString("HH:mm:ss.fff") + "' and Receipt_Time<='" + DateTime.Now.ToString("HH:mm:ss.fff") + "') and foldermovement_complete=0 and Recon_id in (select recon_id from ARC_recon_master where IsEmailRequired = 1 and Recon_id='" + Recon_Id + "')";
                        System.Data.DataTable dtScopeBaseline = das.Select_Table(strquery, hat, "Text", conString);
                        string sysFormat = System.Globalization.CultureInfo.CurrentCulture.DateTimeFormat.ShortDatePattern + " hh:mm:ss tt";
                        DateTime myDate = DateTime.ParseExact(Recon_Date, sysFormat, System.Globalization.CultureInfo.InvariantCulture);
                        DataRow[] dr = dtScopeBaseline.Select();

                        if (dtScopeBaseline.Rows.Count > 0)
                        {
                            foreach (DataRow d in dr)
                            {
                                string Country = Convert.ToString(d["Country_Name"]);
                                string File_Name = Convert.ToString(d["Report_Source_File_Name"]);
                                string File_Ext = Convert.ToString(d["File_Format"]);
                                string Receipt_Time = Convert.ToString(d["Receipt_Time"]);
                                string Email_Shared_Path = Convert.ToString(d["Email_Shared_Path"]);
                                string Recon = Convert.ToString(d["Recon"]);
                                string Email_Subject = Convert.ToString(d["Email_Subject"]);
                                string Email_ID = Convert.ToString(d["Email_ID"]);
                                string product_id = Convert.ToString(d["product_id"]);
                                bool foldermovement_complete = Convert.ToBoolean(d["foldermovement_complete"]);
                                bool isMailFunctionalityRequired = Convert.ToBoolean(d["isMailFunctionalityRequired"]);
                                var time = TimeSpan.Parse(Receipt_Time);
                                var dateTime = DateTime.Today.Add(time);

                                var diff = dateTime.Subtract(DateTime.Now);

                                double Hour = Convert.ToDouble(diff.Hours);
                                double Min = Convert.ToDouble(diff.Minutes);
                                double Sec = Convert.ToDouble(diff.Seconds);
                                //var res = String.Format("{0}:{1}:{2}", diff.Hours,diff.Minutes,diff.Seconds));
                                double converter = Hour * 60 + Min + (Sec / 60);
                                for (int j = 0; j < dtsel1.Rows.Count; j++)
                                {
                                    File_Name = Convert.ToString(d["Report_Source_File_Name"]);

                                    if (File_Name.Contains("YYYY_MM_DD"))
                                    {
                                        Recon_Date = myDate.ToString("yyyy_MM-dd");
                                        File_Name = File_Name.Replace("YYYY_MM_DD", "");
                                    }
                                    //
                                    else if (File_Name.Contains("DD-MMM YYYY") && File_Name.Contains("DD-MMM-YYYY"))
                                    {
                                        Recon_Date = myDate.ToString("dd-MMM-yyyy");
                                        File_Name = File_Name.Replace("DD-MMM YYYY", "");
                                        File_Name = File_Name.Replace("DD-MMM-YYYY", "");
                                        File_Name = File_Name.Substring(0, File_Name.Length - 20);
                                    }
                                    else if (File_Name.Contains("DD-MMM YYYY"))
                                    {
                                        Recon_Date = myDate.ToString("yyyy_MM-dd");
                                        File_Name = File_Name.Replace("DD-MMM YYYY", "");
                                    }
                                    else if (File_Name.Contains("DD-MMM-YYYY"))
                                    {
                                        Recon_Date = myDate.ToString("yyyy_MM-dd");
                                        File_Name = File_Name.Replace("DD-MMM-YYYY", "");
                                    }
                                    else if (File_Name.Contains("DD-MMM"))
                                    {
                                        Recon_Date = myDate.ToString("yyyy_MM-dd");
                                        File_Name = File_Name.Replace("DD-MMM", "");
                                    }
                                    else if (File_Name.Contains("DD-MM"))
                                    {
                                        Recon_Date = myDate.ToString("yyyy_MM-dd");
                                        File_Name = File_Name.Replace("DD-MM", "");
                                    }
                                    else if (File_Name.Contains("DD.MM.YYYY"))
                                    {
                                        Recon_Date = myDate.ToString("yyyy_MM-dd");
                                        File_Name = File_Name.Replace("DD.MM.YYYY", "");
                                    }
                                    else if (File_Name.Contains("DD_MM_YYYY"))
                                    {
                                        Recon_Date = myDate.ToString("dd_MM_yyyy");
                                        File_Name = File_Name.Replace("DD_MM_YYYY", "");
                                    }
                                    else if (File_Name.Contains("DD-MM-YYYY"))
                                    {
                                        Recon_Date = myDate.ToString("dd-MM-yyyy");
                                        File_Name = File_Name.Replace("DD-MM-YYYY", "");
                                    }
                                    else if (File_Name.Contains("MM.DD.YYYY"))
                                    {
                                        Recon_Date = myDate.ToString("MM.dd.yyyy");
                                        File_Name = File_Name.Replace("MM.DD.YYYY", "");
                                    }
                                    else if (File_Name.Contains("DDMMYYYY"))
                                    {
                                        Recon_Date = myDate.ToString("ddMMyyyy");
                                        File_Name = File_Name.Replace("DDMMYYYY", "");
                                    }
                                    else if (File_Name.Contains("DD-MMM YYYY"))
                                    {
                                        Recon_Date = myDate.ToString("dd-MMM yyyy");
                                        File_Name = File_Name.Replace("DD-MMM YYYY", "");
                                    }
                                    else if (File_Name.Contains("DDMMYY"))
                                    {
                                        Recon_Date = myDate.ToString("ddMMyy");
                                        File_Name = File_Name.Replace("DDMMYY", "");
                                    }
                                    else if (File_Name.Contains("YYYYMMDD"))
                                    {
                                        Recon_Date = myDate.ToString("yyyyMMdd");
                                        File_Name = File_Name.Replace("YYYYMMDD", "");
                                    }
                                    else if (File_Name.Contains("YYYY-MM-DD"))
                                    {
                                        Recon_Date = myDate.ToString("yyyy-MM-dd");
                                        File_Name = File_Name.Replace("YYYY-MM-DD", "");
                                    }
                                    else if (File_Name.Contains("DD MMM YY"))
                                    {
                                        Recon_Date = myDate.ToString("dd MMM yy");
                                        File_Name = File_Name.Replace("DD MMM YY", "");
                                    }
                                    else if (File_Name.Contains("DD MM YY"))
                                    {
                                        Recon_Date = myDate.ToString("dd MM yy");
                                        File_Name = File_Name.Replace("DD MM YY", "");
                                    }
                                    else if (File_Name.Contains("DD_MM"))
                                    {
                                        Recon_Date = myDate.ToString("dd_MM");
                                        File_Name = File_Name.Replace("DD_MM", "");
                                    }
                                    else if (File_Name.Contains("YYDDMM"))
                                    {
                                        Recon_Date = myDate.ToString("yyddMM");
                                        File_Name = File_Name.Replace("YYDDMM", "");
                                    }
                                    else if (File_Name.Contains("YYYY-MM"))
                                    {
                                        Recon_Date = myDate.ToString("yyyy-MM");
                                        File_Name = File_Name.Replace("YYYY-MM", "");
                                    }
                                    else if (File_Name.Contains("DD.MM.YY"))
                                    {
                                        Recon_Date = myDate.ToString("dd.MM.yy");
                                        File_Name = File_Name.Replace("DD.MM.YY", "");
                                    }
                                    ////if multiple folders for multiple days
                                    ////DateTime myDate = DateTime.ParseExact(ReconDate.ToString(), "yyyy-MM-dd", System.Globalization.CultureInfo.InvariantCulture);

                                    //if (File_Name != "")
                                    //{
                                    File_Name = GetFileName_3_2(Email_Shared_Path + Country + "_Country Sharedrive\\" + DateTime.Now.ToString("dd-MMM-yyyy") + "\\", File_Name, Recon_Date);
                                    // }

                                    InputFolder_Path = Main_DIR_SharePath + strDirectory + "\\Input\\Emails\\" + File_Name + "." + File_Ext;
                                    Country_Path = Email_Shared_Path + Country + "_Country Sharedrive\\" + DateTime.Now.ToString("dd-MMM-yyyy") + "\\" + File_Name + "." + File_Ext;
                                    if (File_Name != "")
                                    {
                                        if (foldermovement_complete == false && File.Exists(Country_Path))
                                        {
                                            if (File.Exists(InputFolder_Path))
                                            {
                                                File.Delete(InputFolder_Path);
                                            }

                                            File.Copy(Country_Path, InputFolder_Path);

                                            files_moved_count = files_moved_count + 1;
                                        }

                                    }

                                }
                            }
                        }
                    }
                }
            }

            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
        }
        public void Folder_Movement_Formatting3_2Mail(string Main_DIR_SharePath, string conString, string strDirectory)
        {
            aTimer.Stop();

            string Country_Path = string.Empty;
            string InputFolder_Path = string.Empty;


            //SA1001
            try
            {
                DAccess das = new DAccess();
                Hashtable hat = new Hashtable();

                string sDirectory = Main_DIR_SharePath + DateTime.Now.ToString("dd-MMM-yyyy") + "_Files\\";

                //Indidvidual recons
                //string strquery = "select distinct recon_name,recon_id,total_files,MailFilesReq from Arc_Recon_Master_Holiday_Date_Logic where  recon_name='SCB IRAQ Account Balance Report' order by recon_name";

                //All Recons
                string strquery = "select distinct recon_name,recon_id,total_files,recon_date,MailFilesReq,receipt_time from Arc_Recon_Master_Holiday_Date_Logic where Is_Recon_Completed = 0 and Is_Active = 1 and recon_id in (select recon_id from arc_recon_master where Is_Recon_Completed = 0 and Is_Active = 1 and isMailDownloadComplete=0 and IsEmailRequired = 1 and Is_Holiday_Logic = 1 and recon_name != 'India Clearing' and recon_name != 'India Clearing Inward' and recon_name != 'India Clearing Outward') order by receipt_time";


                System.Data.DataTable dtReconMaster = das.Select_Table(strquery, hat, "Text", conString);

                string strIInputFileName = string.Empty;
                string strOutPutFileName = string.Empty;
                string SourcePath = string.Empty;
                string Foramtted_Recon_Date = string.Empty;
                string strReconName = string.Empty;
                string Desti_Path = string.Empty;
                string Output_Path = string.Empty;
                string Recon_Date = string.Empty;
                string db_Ext = string.Empty;
                string Recon_name = string.Empty;

                int c = 0;

                for (int i = 0; i < dtReconMaster.Rows.Count; i++)
                {
                    bool flag = true;
                    int files_moved_count = 0;
                    int total_files_tobepresent = 0;
                    Recon_name = Convert.ToString(dtReconMaster.Rows[i]["recon_name"]);
                    Recon_Date = Convert.ToString(dtReconMaster.Rows[i]["Recon_Date"]);

                    strquery = "select count(recon_date) as count from Arc_Recon_Master_Holiday_Date_Logic where recon_name='" + Recon_name + "'";
                    System.Data.DataTable dtcount = das.Select_Table(strquery, hat, "Text", conString);

                    if (dtcount.Rows[0]["count"].ToString().Trim() != "" && dtReconMaster.Rows[i]["MailFilesReq"].ToString().Trim() != "")
                    {
                        total_files_tobepresent = Convert.ToInt32(dtcount.Rows[0]["count"].ToString()) * Convert.ToInt32(dtReconMaster.Rows[i]["MailFilesReq"].ToString());
                    }
                    else
                    {
                        total_files_tobepresent = 0;
                    }

                    int Recon_Id = Convert.ToInt32(dtReconMaster.Rows[i]["recon_id"]);
                    int File_Count = Convert.ToInt32(dtReconMaster.Rows[i]["total_files"]);
                    //DateTime dtRecondate = Convert.ToDateTime(dtReconMaster.Rows[i]["recon_date"]);
                    //Recon_Date = Convert.ToString(dtReconMaster.Rows[i]["Recon_date"]);
                    string selquery1 = "select distinct Recon_Date,Is_Recon_Completed,MailFilesReq from Arc_Recon_Master_Holiday_Date_Logic where recon_name ='" + Recon_name + "' order by Recon_date";
                    System.Data.DataTable dtsel1 = das.Select_Table(selquery1, hat, "Text", conString);
                    for (int j = 0; j < dtsel1.Rows.Count; j++)
                    {
                        DateTime dt_Recondate = Convert.ToDateTime(dtsel1.Rows[j]["Recon_Date"]);
                        //EA1001                        
                        ///Added by Prakash - For checking the Least Recon Date file is processed or not, if not skip that recon and go for next recon
                        //string selquery = "select top(1) Report_Source_File_Name,Recon_Date,IsProcessed,automationStatus from arc_scope_baseline_logic where recon ='" + Recon_name + "' order by Recon_date";
                        // DataTable dtsel = das.Select_Table(selquery, hat, "Text");


                        //Indidvidual recons
                        //strquery = "select Team, Country_Name, Recon, Report_Source_File_Name,FTP_File_Format_Name, Recon_date from ARC_Scope_Baseline_Logic where recon='SCB IRAQ Account Balance Report' and recon_date='" + dt_Recondate.ToString("MM/dd/yyyy") + "' ";


                        //All Recons-15-02-18
                        strquery = "select * from ARC_scope_baseline_logic a inner join ARC_scope_baseline b on a.recon_id=b.recon_id where source_application = 'Email' and foldermovement_complete=0 and (SLA_Time>='" + DateTime.Now.ToString("HH:mm:ss.fff") + "' and Receipt_Time<='" + DateTime.Now.ToString("HH:mm:ss.fff") + "') and a.Recon_id in (select recon_id from ARC_recon_master where IsEmailRequired = 1 and Is_Holiday_Logic = 1) order by Receipt_Time asc";
                        System.Data.DataTable dtBaseHoliday = das.Select_Table(strquery, hat, "Text", conString);


                        System.Data.DataTable dt = new System.Data.DataTable();
                        SqlConnection con = new SqlConnection(conString);

                        strquery = "select * from ARC_scope_baseline where source_application = 'Email' and (SLA_Time>='" + DateTime.Now.ToString("HH:mm:ss.fff") + "' and Receipt_Time<='" + DateTime.Now.ToString("HH:mm:ss.fff") + "') and foldermovement_complete=0 and Recon_id in (select recon_id from ARC_recon_master where IsEmailRequired = 1 and Is_Holiday_Logic = 1 and Recon_id='" + Recon_Id + "')order by Receipt_Time asc";
                        System.Data.DataTable dtScopeBaseline = das.Select_Table(strquery, hat, "Text", conString);

                        DataRow[] dr = dtScopeBaseline.Select();
                        //DataTable dtt = new DataTable();
                        //////SqlDataAdapter ad1 = new SqlDataAdapter("select count(*) from ARC_scope_baseline_logic where Recon_id in ('" + Recon_Id + "')", con);
                        //SqlDataAdapter ad1 = new SqlDataAdapter("select count(distinct B.Report_Source_File_Name) from ARC_scope_baseline_logic A, ARC_scope_baseline B where A.Recon_id='" + Recon_Id + "' and B.Recon_id='" + Recon_Id + "' and B.Source_Application='Email'", con);
                        //con.Open();
                        //ad1.Fill(dtt);
                        if (Convert.ToInt32(dtcount.Rows[0]["count"].ToString()) > 1)
                        {
                            foreach (DataRow d in dr)
                            {
                                string Country = Convert.ToString(d["Country_Name"]);
                                string File_Name = Convert.ToString(d["Report_Source_File_Name"]);
                                string IsFormatting = Convert.ToString(d["Format_Direct_Upload"]);
                                string Source_App = Convert.ToString(d["Source_Application"]);
                                string File_Ext = Convert.ToString(d["File_Format"]);
                                string Receipt_Time = Convert.ToString(d["Receipt_Time"]);
                                string Email_Shared_Path = Convert.ToString(d["Email_Shared_Path"]);
                                string Recon = Convert.ToString(d["Recon"]);
                                string Email_Subject = Convert.ToString(d["Email_Subject"]);
                                string Email_ID = Convert.ToString(d["Email_ID"]);
                                string product_id = Convert.ToString(d["product_id"]);
                                bool foldermovement_complete = Convert.ToBoolean(d["foldermovement_complete"]);
                                bool isMailFunctionalityRequired = Convert.ToBoolean(d["isMailFunctionalityRequired"]);
                                var time = TimeSpan.Parse(Receipt_Time);
                                var dateTime = DateTime.Today.Add(time);

                                var diff = dateTime.Subtract(DateTime.Now);

                                double Hour = Convert.ToDouble(diff.Hours);
                                double Min = Convert.ToDouble(diff.Minutes);
                                double Sec = Convert.ToDouble(diff.Seconds);
                                //var res = String.Format("{0}:{1}:{2}", diff.Hours,diff.Minutes,diff.Seconds));

                                double converter = Hour * 60 + Min + (Sec / 60);

                                if (File_Name.Contains("YYYY_MM_DD"))
                                {
                                    Recon_Date = dt_Recondate.ToString("yyyy_MM_dd");
                                    File_Name = File_Name.Replace("YYYY_MM_DD", Recon_Date);
                                }
                                else if (File_Name.Contains("DD-MMM"))
                                {
                                    Recon_Date = dt_Recondate.ToString("dd-MMM");
                                    File_Name = File_Name.Replace("DD-MMM", Recon_Date);
                                }
                                else if (File_Name.Contains("DD-MM"))
                                {
                                    Recon_Date = dt_Recondate.ToString("dd-MM");
                                    File_Name = File_Name.Replace("DD-MM", Recon_Date);
                                }
                                else if (File_Name.Contains("DD.MM.YYYY"))
                                {
                                    Recon_Date = dt_Recondate.ToString("dd.MM.yyyy");

                                    File_Name = File_Name.Replace("DD.MM.YYYY", Recon_Date);
                                }
                                else if (File_Name.Contains("DD_MM_YYYY"))
                                {
                                    Recon_Date = dt_Recondate.ToString("dd_MM_yyyy");

                                    File_Name = File_Name.Replace("DD_MM_YYYY", Recon_Date);
                                }
                                else if (File_Name.Contains("DD-MM-YYYY"))
                                {
                                    Recon_Date = dt_Recondate.ToString("dd-MM-yyyy");
                                    File_Name = File_Name.Replace("DD-MM-YYYY", Recon_Date);
                                }
                                else if (File_Name.Contains("MM.DD.YYYY"))
                                {
                                    Recon_Date = dt_Recondate.ToString("MM.dd.yyyy");
                                    File_Name = File_Name.Replace("MM.DD.YYYY", Recon_Date);
                                }
                                else if (File_Name.Contains("DDMMYYYY"))
                                {
                                    Recon_Date = dt_Recondate.ToString("ddMMyyyy");
                                    File_Name = File_Name.Replace("DDMMYYYY", Recon_Date);
                                }
                                else if (File_Name.Contains("DD-MMM YYYY"))
                                {
                                    Recon_Date = dt_Recondate.ToString("dd-MMM yyyy");
                                    File_Name = File_Name.Replace("DD-MMM YYYY", Recon_Date);
                                }
                                else if (File_Name.Contains("DDMMYY"))
                                {
                                    Recon_Date = dt_Recondate.ToString("ddMMyy");
                                    File_Name = File_Name.Replace("DDMMYY", Recon_Date);
                                }
                                else if (File_Name.Contains("YYYYMMDD"))
                                {
                                    Recon_Date = dt_Recondate.ToString("yyyyMMdd");
                                    File_Name = File_Name.Replace("YYYYMMDD", Recon_Date);
                                }
                                else if (File_Name.Contains("YYYY-MM-DD"))
                                {
                                    Recon_Date = dt_Recondate.ToString("yyyy-MM-dd");
                                    File_Name = File_Name.Replace("YYYY-MM-DD", Recon_Date);
                                }
                                else if (File_Name.Contains("DD MMM YY"))
                                {
                                    Recon_Date = dt_Recondate.ToString("dd MMM yy");
                                    File_Name = File_Name.Replace("DD MMM YY", Recon_Date);
                                }
                                else if (File_Name.Contains("DD MM YY"))
                                {
                                    Recon_Date = dt_Recondate.ToString("dd MM yy");
                                    File_Name = File_Name.Replace("DD MM YY", Recon_Date);
                                }
                                else if (File_Name.Contains("DD_MM"))
                                {
                                    Recon_Date = dt_Recondate.ToString("dd_MM");
                                    File_Name = File_Name.Replace("DD_MM", Recon_Date);
                                }
                                else if (File_Name.Contains("YYDDMM"))
                                {
                                    Recon_Date = dt_Recondate.ToString("yyddMM");
                                    File_Name = File_Name.Replace("YYDDMM", Recon_Date);
                                }
                                else if (File_Name.Contains("YYYY-MM"))
                                {
                                    Recon_Date = dt_Recondate.ToString("yyyy-MM");
                                    File_Name = File_Name.Replace("YYYY-MM", Recon_Date);
                                }
                                else if (File_Name.Contains("DD.MM.YY"))
                                {
                                    Recon_Date = dt_Recondate.ToString("dd.MM.yy");
                                    File_Name = File_Name.Replace("DD.MM.YY", Recon_Date);
                                }
                                ////if multiple folders for multiple days
                                ////DateTime myDate = DateTime.ParseExact(ReconDate.ToString(), "yyyy-MM-dd", System.Globalization.CultureInfo.InvariantCulture);

                                //if (File_Name != "")
                                //{
                                File_Name = GetFileName_3_2(Email_Shared_Path + Country + "_Country Sharedrive\\" + DateTime.Now.ToString("dd-MMM-yyyy") + "\\", File_Name, Recon_Date);
                                // }

                                InputFolder_Path = Main_DIR_SharePath + strDirectory + "\\Input\\Emails\\" + File_Name + "." + File_Ext;
                                Country_Path = Email_Shared_Path + Country + "_Country Sharedrive\\" + DateTime.Now.ToString("dd-MMM-yyyy") + "\\" + File_Name + "." + File_Ext;
                                if (File.Exists(Country_Path))
                                {
                                    c++;
                                }
                                else
                                {

                                }
                            }
                        }
                    }

                    if (Convert.ToInt32(dtcount.Rows[0]["count"].ToString()) > 1)
                    {
                        if (c == total_files_tobepresent)
                        {
                            flag = true;
                        }
                        else
                        {
                            flag = false;
                        }
                    }


                    if (flag == true)
                    {
                        System.Data.DataTable dt = new System.Data.DataTable();
                        SqlConnection con = new SqlConnection(conString);

                        strquery = "select * from ARC_scope_baseline where source_application = 'Email' and (SLA_Time>='" + DateTime.Now.ToString("HH:mm:ss.fff") + "' and Receipt_Time<='" + DateTime.Now.ToString("HH:mm:ss.fff") + "') and foldermovement_complete=0 and Recon_id in (select recon_id from ARC_recon_master where IsEmailRequired = 1 and Is_Holiday_Logic = 1 and Recon_id='" + Recon_Id + "')";
                        System.Data.DataTable dtScopeBaseline = das.Select_Table(strquery, hat, "Text", conString);
                        string sysFormat = System.Globalization.CultureInfo.CurrentCulture.DateTimeFormat.ShortDatePattern + " hh:mm:ss tt";
                        DateTime myDate = DateTime.ParseExact(Recon_Date, sysFormat, System.Globalization.CultureInfo.InvariantCulture);
                        DataRow[] dr = dtScopeBaseline.Select();

                        if (dtScopeBaseline.Rows.Count > 0)
                        {
                            foreach (DataRow d in dr)
                            {
                                string Country = Convert.ToString(d["Country_Name"]);
                                string File_Name = Convert.ToString(d["Report_Source_File_Name"]);
                                string File_Ext = Convert.ToString(d["File_Format"]);
                                string Receipt_Time = Convert.ToString(d["Receipt_Time"]);
                                string Email_Shared_Path = Convert.ToString(d["Email_Shared_Path"]);
                                string Recon = Convert.ToString(d["Recon"]);
                                string Email_Subject = Convert.ToString(d["Email_Subject"]);
                                string Email_ID = Convert.ToString(d["Email_ID"]);
                                string product_id = Convert.ToString(d["product_id"]);
                                bool foldermovement_complete = Convert.ToBoolean(d["foldermovement_complete"]);
                                bool isMailFunctionalityRequired = Convert.ToBoolean(d["isMailFunctionalityRequired"]);
                                var time = TimeSpan.Parse(Receipt_Time);
                                var dateTime = DateTime.Today.Add(time);

                                var diff = dateTime.Subtract(DateTime.Now);

                                double Hour = Convert.ToDouble(diff.Hours);
                                double Min = Convert.ToDouble(diff.Minutes);
                                double Sec = Convert.ToDouble(diff.Seconds);
                                //var res = String.Format("{0}:{1}:{2}", diff.Hours,diff.Minutes,diff.Seconds));
                                double converter = Hour * 60 + Min + (Sec / 60);
                                for (int j = 0; j < dtsel1.Rows.Count; j++)
                                {
                                    File_Name = Convert.ToString(d["Report_Source_File_Name"]);

                                    if (File_Name.Contains("YYYY_MM_DD"))
                                    {
                                        Recon_Date = myDate.ToString("yyyy_MM-dd");
                                        File_Name = File_Name.Replace("YYYY_MM_DD", "");
                                    }
                                    //
                                    else if (File_Name.Contains("DD-MMM YYYY") && File_Name.Contains("DD-MMM-YYYY"))
                                    {
                                        Recon_Date = myDate.ToString("dd-MMM-yyyy");
                                        File_Name = File_Name.Replace("DD-MMM YYYY", "");
                                        File_Name = File_Name.Replace("DD-MMM-YYYY", "");
                                        File_Name = File_Name.Substring(0, File_Name.Length - 20);
                                    }
                                    else if (File_Name.Contains("DD-MMM YYYY"))
                                    {
                                        Recon_Date = myDate.ToString("yyyy_MM-dd");
                                        File_Name = File_Name.Replace("DD-MMM YYYY", "");
                                    }
                                    else if (File_Name.Contains("DD-MMM-YYYY"))
                                    {
                                        Recon_Date = myDate.ToString("yyyy_MM-dd");
                                        File_Name = File_Name.Replace("DD-MMM-YYYY", "");
                                    }
                                    else if (File_Name.Contains("DD-MMM"))
                                    {
                                        Recon_Date = myDate.ToString("yyyy_MM-dd");
                                        File_Name = File_Name.Replace("DD-MMM", "");
                                    }
                                    else if (File_Name.Contains("DD-MM"))
                                    {
                                        Recon_Date = myDate.ToString("yyyy_MM-dd");
                                        File_Name = File_Name.Replace("DD-MM", "");
                                    }
                                    else if (File_Name.Contains("DD.MM.YYYY"))
                                    {
                                        Recon_Date = myDate.ToString("yyyy_MM-dd");
                                        File_Name = File_Name.Replace("DD.MM.YYYY", "");
                                    }
                                    else if (File_Name.Contains("DD_MM_YYYY"))
                                    {
                                        Recon_Date = myDate.ToString("dd_MM_yyyy");
                                        File_Name = File_Name.Replace("DD_MM_YYYY", "");
                                    }
                                    else if (File_Name.Contains("DD-MM-YYYY"))
                                    {
                                        Recon_Date = myDate.ToString("dd-MM-yyyy");
                                        File_Name = File_Name.Replace("DD-MM-YYYY", "");
                                    }
                                    else if (File_Name.Contains("MM.DD.YYYY"))
                                    {
                                        Recon_Date = myDate.ToString("MM.dd.yyyy");
                                        File_Name = File_Name.Replace("MM.DD.YYYY", "");
                                    }
                                    else if (File_Name.Contains("DDMMYYYY"))
                                    {
                                        Recon_Date = myDate.ToString("ddMMyyyy");
                                        File_Name = File_Name.Replace("DDMMYYYY", "");
                                    }
                                    else if (File_Name.Contains("DD-MMM YYYY"))
                                    {
                                        Recon_Date = myDate.ToString("dd-MMM yyyy");
                                        File_Name = File_Name.Replace("DD-MMM YYYY", "");
                                    }
                                    else if (File_Name.Contains("DDMMYY"))
                                    {
                                        Recon_Date = myDate.ToString("ddMMyy");
                                        File_Name = File_Name.Replace("DDMMYY", "");
                                    }
                                    else if (File_Name.Contains("YYYYMMDD"))
                                    {
                                        Recon_Date = myDate.ToString("yyyyMMdd");
                                        File_Name = File_Name.Replace("YYYYMMDD", "");
                                    }
                                    else if (File_Name.Contains("YYYY-MM-DD"))
                                    {
                                        Recon_Date = myDate.ToString("yyyy-MM-dd");
                                        File_Name = File_Name.Replace("YYYY-MM-DD", "");
                                    }
                                    else if (File_Name.Contains("DD MMM YY"))
                                    {
                                        Recon_Date = myDate.ToString("dd MMM yy");
                                        File_Name = File_Name.Replace("DD MMM YY", "");
                                    }
                                    else if (File_Name.Contains("DD MM YY"))
                                    {
                                        Recon_Date = myDate.ToString("dd MM yy");
                                        File_Name = File_Name.Replace("DD MM YY", "");
                                    }
                                    else if (File_Name.Contains("DD_MM"))
                                    {
                                        Recon_Date = myDate.ToString("dd_MM");
                                        File_Name = File_Name.Replace("DD_MM", "");
                                    }
                                    else if (File_Name.Contains("YYDDMM"))
                                    {
                                        Recon_Date = myDate.ToString("yyddMM");
                                        File_Name = File_Name.Replace("YYDDMM", "");
                                    }
                                    else if (File_Name.Contains("YYYY-MM"))
                                    {
                                        Recon_Date = myDate.ToString("yyyy-MM");
                                        File_Name = File_Name.Replace("YYYY-MM", "");
                                    }
                                    else if (File_Name.Contains("DD.MM.YY"))
                                    {
                                        Recon_Date = myDate.ToString("dd.MM.yy");
                                        File_Name = File_Name.Replace("DD.MM.YY", "");
                                    }
                                    ////if multiple folders for multiple days
                                    ////DateTime myDate = DateTime.ParseExact(ReconDate.ToString(), "yyyy-MM-dd", System.Globalization.CultureInfo.InvariantCulture);

                                    //if (File_Name != "")
                                    //{
                                    File_Name = GetFileName_3_2(Email_Shared_Path + Country + "_Country Sharedrive\\" + DateTime.Now.ToString("dd-MMM-yyyy") + "\\", File_Name, Recon_Date);
                                    // }

                                    InputFolder_Path = Main_DIR_SharePath + strDirectory + "\\Input\\Emails\\" + File_Name + "." + File_Ext;
                                    Country_Path = Email_Shared_Path + Country + "_Country Sharedrive\\" + DateTime.Now.ToString("dd-MMM-yyyy") + "\\" + File_Name + "." + File_Ext;
                                    if (File_Name != "")
                                    {
                                        if (foldermovement_complete == false && isMailFunctionalityRequired == true && !File.Exists(Country_Path))
                                        {
                                            Microsoft.Office.Interop.Outlook.Application app = new Microsoft.Office.Interop.Outlook.Application();
                                            Microsoft.Office.Interop.Outlook.MailItem mailItem = (Microsoft.Office.Interop.Outlook.MailItem)app.CreateItem(Microsoft.Office.Interop.Outlook.OlItemType.olMailItem);
                                            mailItem.Subject = "Remainder-- Files Required for Recon: " + Recon;
                                            if (product_id == "5")
                                            {
                                                mailItem.SentOnBehalfOfName = "GRU.DataUpload-Nostro@sc.com";
                                                //mailItem.SentOnBehalfOfName = "kiran.h@sc.com";
                                                mailItem.CC = "GRU.DataUpload-Nostro@sc.com";
                                            }
                                            else if (product_id == "1")
                                            {
                                                mailItem.SentOnBehalfOfName = "GRU.DataUpload-Retail@sc.com";
                                                //mailItem.SentOnBehalfOfName = "kiran.h@sc.com";
                                                mailItem.CC = "GRU.DataUpload-Retail@sc.com";
                                            }
                                            else if (product_id == "2" || product_id == "3" || product_id == "4" || product_id == "6")
                                            {
                                                mailItem.SentOnBehalfOfName = "GRU.DataUpload-FX-SS@sc.com";
                                                //mailItem.SentOnBehalfOfName = "kiran.h@sc.com";
                                                mailItem.CC = "GRU.DataUpload-FX-SS@sc.com";
                                            }
                                            mailItem.To = Email_ID;
                                            mailItem.Body = "Dear all, \n"
                                                        + "\n"
                                                        + "This is a Auto generated email\n"
                                                        + "\n"
                                                        + "We are nearing our SLA to commence the reconciliation for " + Recon + "\n"
                                                        + "\n"
                                                        + "Can you please place the input file " + File_Name + " in respective country shared folder without any further delay." + " \n"                                                        
                                                        + "\nIf you have any further query on this, respond to the generic email ID - "
                                                        + mailItem.CC.ToString() + "\n"
                                                        + "\nThanks"
                                                        + "\n\n"
                                                        + "DataUpload Team";

                                            mailItem.Importance = Microsoft.Office.Interop.Outlook.OlImportance.olImportanceHigh;
                                            mailItem.Display(false);
                                            mailItem.Send();
                                        }


                                    }
                                }
                            }
                        }
                    }
                }
            }

            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
        }
        public static System.Data.DataTable QueryValues_ChkRecons(string conString)
        {
            System.Data.DataTable dt = new System.Data.DataTable();
            System.Data.DataTable dt1 = new System.Data.DataTable();
            SqlConnection con = new SqlConnection(conString);
            SqlCommand cmd = new SqlCommand();
            //Individual Recons
            //SqlDataAdapter ad = new SqlDataAdapter("select * from ARC_scope_baseline where source_application = 'Email' and foldermovement_complete=0 and recon='Vietnam ACB'", con);
            con.Open();
            //ad.Fill(dt1);
            //con.Close();
            //All Recons
            SqlDataAdapter ad = new SqlDataAdapter("select * from ARC_scope_baseline where source_application = 'Email' and (SLA_Time>='" + DateTime.Now.ToString("HH:mm:ss.fff") + "' and Receipt_Time<='" + DateTime.Now.ToString("HH:mm:ss.fff") + "') and foldermovement_complete=0 and Recon_id in (select recon_id from ARC_recon_master where Is_Holiday_Logic = 0) order by Receipt_Time ASC", con);
            ad.Fill(dt1);
            return dt1;
        }
        public static System.Data.DataTable QueryValues_ChkReconsMail(string conString)
        {
            System.Data.DataTable dt = new System.Data.DataTable();
            System.Data.DataTable dt1 = new System.Data.DataTable();
            SqlConnection con = new SqlConnection(conString);
            SqlCommand cmd = new SqlCommand();
            //Individual Recons
            //SqlDataAdapter ad = new SqlDataAdapter("select * from ARC_scope_baseline where source_application = 'Email' and foldermovement_complete=0 and recon='Vietnam ACB'", con);
            con.Open();
            //ad.Fill(dt1);
            //con.Close();
            //All Recons
            SqlDataAdapter ad = new SqlDataAdapter("select * from ARC_scope_baseline where source_application = 'Email' and (SLA_Time>='" + DateTime.Now.ToString("HH:mm:ss.fff") + "' and Receipt_Time<='" + DateTime.Now.ToString("HH:mm:ss.fff") + "') and foldermovement_complete=0 and Recon_id in (select recon_id from ARC_recon_master where IsEmailRequired = 1 and Is_Holiday_Logic = 0) order by Receipt_Time ASC", con);
            ad.Fill(dt1);
            return dt1;
        }
        public static System.Data.DataTable QueryValues_FolderCreation(string conString)
        {
            System.Data.DataTable dt = new System.Data.DataTable();
            System.Data.DataTable dt1 = new System.Data.DataTable();
            SqlConnection con = new SqlConnection(conString);
            SqlCommand cmd = new SqlCommand();
            //Individual Recons
            //SqlDataAdapter ad = new SqlDataAdapter("select * from ARC_scope_baseline where source_application = 'Email' and foldermovement_complete=0 and recon='Singapore SEC RPR'", con);
            con.Open();
            //ad.Fill(dt1);
            //con.Close();
            //All Recons
            SqlDataAdapter ad = new SqlDataAdapter("select distinct country_name from ARC_Scope_Baseline where source_application = 'Email'", con);
            ad.Fill(dt1);
            return dt1;
        }
        public void FileCopyUpdate(string conString, string File_Name, string Email_Shared_Path, string Country, string InputFolder_Path, string Country_Path, string File_Ext, System.Data.DataTable Share_Folder, string Recon, string Email_ID, bool isMailFunctionalityRequired, bool foldermovement_complete, double converter, int files_moved_count, int i, int Recon_Id, System.Data.DataTable dt_Recon, string product_id, string Main_DIR_SharePath, string strDirectory)
        {
            if (File_Name != "")
            {
                File_Name = GetFileName_ChkRec(Email_Shared_Path + Country + "_Country Sharedrive\\" + DateTime.Today.ToString("dd-MMM-yyyy") + "\\", File_Name);
            }

            InputFolder_Path = strDirectory + "\\Input\\Emails\\" + File_Name.Replace(",", "") + "." + File_Ext;
            Country_Path = Email_Shared_Path + Country + "_Country Sharedrive\\" + DateTime.Today.ToString("dd-MMM-yyyy") + "\\" + File_Name.Replace(",", "") + "." + File_Ext;
            if (Share_Folder.Rows[i]["Email_ID"].ToString().Trim() == "" || Share_Folder.Rows[i]["Email_ID"].ToString().Trim() == string.Empty)
            {
                Console.WriteLine("Email ID Not Configured for " + Recon + " Recon for " + File_Name + " Files");
                Console.WriteLine();
            }
            if (Email_ID != "")
            {

                if (foldermovement_complete == false && File.Exists(Country_Path))
                {
                    if (File.Exists(InputFolder_Path))
                    {
                        File.Delete(InputFolder_Path);
                    }

                    File.Copy(Country_Path, InputFolder_Path);
                    files_moved_count = files_moved_count + 1;
                    string query1 = "Update ARC_scope_baseline set Foldermovement_Complete = 1 where Report_Source_File_Name like '%" + File_Name.Replace(",", "") + "%' and Recon_ID = '" + Recon_Id + "'";

                    SqlConnection con1 = new SqlConnection(conString);
                    SqlCommand cmd1 = new SqlCommand(query1, con1);
                    if (con1.State == ConnectionState.Closed)
                    {
                        con1.Open();
                    }
                    cmd1.ExecuteNonQuery();
                    if (con1.State == ConnectionState.Open)
                    {
                        con1.Close();
                    }
                }
            }
            if (dt_Recon.Rows[i]["MailFilesReq"].ToString().Trim() != "")
            {

                if (files_moved_count == Convert.ToInt32(dt_Recon.Rows[i]["MailFilesReq"].ToString()))
                {
                    SqlConnection con = new SqlConnection(conString);
                    SqlCommand Updt_cmd2 = new SqlCommand("update ARC_Recon_Master set IsMailDownloadComplete=1 where Recon_Id = " + Recon_Id + "", con);
                    con.Open();
                    Updt_cmd2.ExecuteNonQuery();
                    con.Close();
                }
            }
        }
        public void FileCopyUpdateMail(string conString, string File_Name, string Email_Shared_Path, string Country, string InputFolder_Path, string Country_Path, string File_Ext, System.Data.DataTable Share_Folder, string Recon, string Email_ID, bool isMailFunctionalityRequired, bool foldermovement_complete, double converter, int files_moved_count, int i, int Recon_Id, System.Data.DataTable dt_Recon, string product_id, string Main_DIR_SharePath, string strDirectory)
        {
            if (File_Name != "")
            {
                File_Name = GetFileName_ChkRec(Email_Shared_Path + Country + "_Country Sharedrive\\" + DateTime.Today.ToString("dd-MMM-yyyy") + "\\", File_Name);
            }

            InputFolder_Path = strDirectory + "\\Input\\Emails\\" + File_Name.Replace(",", "") + "." + File_Ext;
            Country_Path = Email_Shared_Path + Country + "_Country Sharedrive\\" + DateTime.Today.ToString("dd-MMM-yyyy") + "\\" + File_Name.Replace(",", "") + "." + File_Ext;
            if (Share_Folder.Rows[i]["Email_ID"].ToString().Trim() == "" || Share_Folder.Rows[i]["Email_ID"].ToString().Trim() == string.Empty)
            {
                Console.WriteLine("Email ID Not Configured for " + Recon + " Recon for " + File_Name + " Files");
                Console.WriteLine();
            }
            if (Email_ID != "")
            {
                if (foldermovement_complete == false && isMailFunctionalityRequired == true && !File.Exists(Country_Path))
                {
                    Microsoft.Office.Interop.Outlook.Application app = new Microsoft.Office.Interop.Outlook.Application();
                    Microsoft.Office.Interop.Outlook.MailItem mailItem = (Microsoft.Office.Interop.Outlook.MailItem)app.CreateItem(Microsoft.Office.Interop.Outlook.OlItemType.olMailItem);
                    mailItem.Subject = "Remainder-- Files Required for Recon: " + Recon;
                    if (product_id == "5")
                    {
                        mailItem.SentOnBehalfOfName = "GRU.DataUpload-Nostro@sc.com";
                        //mailItem.SentOnBehalfOfName = "kiran.h@sc.com";
                        mailItem.CC = "GRU.DataUpload-Nostro@sc.com";
                    }
                    else if (product_id == "1")
                    {
                        mailItem.SentOnBehalfOfName = "GRU.DataUpload-Retail@sc.com";
                        //mailItem.SentOnBehalfOfName = "kiran.h@sc.com";
                        mailItem.CC = "GRU.DataUpload-Retail@sc.com";
                    }
                    else if (product_id == "2" || product_id == "3" || product_id == "4" || product_id == "6")
                    {
                        mailItem.SentOnBehalfOfName = "GRU.DataUpload-FX-SS@sc.com";
                        //mailItem.SentOnBehalfOfName = "kiran.h@sc.com";
                        mailItem.CC = "GRU.DataUpload-FX-SS@sc.com";
                    }
                    mailItem.To = Email_ID;

                    mailItem.Body = "Dear all, \n"
                                    + "\n"
                                    + "This is a Auto generated email\n"
                                    + "\n"
                                    + "We are nearing our SLA to commence the reconciliation for " + Recon + "\n"
                                    + "\n"
                                    + "Can you please place the input file " + File_Name + " in respective country shared folder without any further delay." + " \n"
                                    + "\nIf you have any further query on this, respond to the generic email ID - "
                                    + mailItem.CC.ToString() + "\n"
                                    + "\nThanks"
                                    + "\n\n"
                                    + "DataUpload Team";

                    mailItem.Importance = Microsoft.Office.Interop.Outlook.OlImportance.olImportanceHigh;
                    mailItem.Display(false);
                    mailItem.Send();
                }


            }

        }
        public string GetFileName_ChkRec(string s, string Name)
        {
            string[] files1 = Directory.GetFiles(s);
            string actfile = "";
            for (int i = 0; i < files1.Length; i++)
            {
                files1[i] = Path.GetFileNameWithoutExtension(files1[i]);
                if (files1[i].ToString().Trim().ToUpper().Contains(Name.ToUpper()))
                {
                    actfile = files1[i];
                }
            }
            if (actfile != "")
            {
                return actfile;
            }
            else
            {
                return Name;
            }
        }
        public string GetFileName_ChkRecMulfiles(string s, string Name)
        {
            string[] files1 = Directory.GetFiles(s);
            string actfile = "";
            for (int i = 0; i < files1.Length; i++)
            {
                files1[i] = Path.GetFileNameWithoutExtension(files1[i]);
                if (files1[i].ToString().Trim().ToUpper().Contains(Name.ToUpper()))
                {
                    actfile = actfile + "," + files1[i];
                }
            }
            if (actfile != "")
            {
                return actfile;
            }
            else
            {
                return Name;
            }
        }
        public string GetFileName_3_2(string s, string Name, string Recon_Date)
        {
            string[] files1 = Directory.GetFiles(s);
            string actfile = "";
            for (int i = 0; i < files1.Length; i++)
            {
                files1[i] = Path.GetFileNameWithoutExtension(files1[i]);
                if (files1[i].ToString().Trim().ToUpper().Contains(Name.ToUpper()) && files1[i].ToString().Trim().ToUpper().Contains(Recon_Date.ToUpper().Trim()))
                {
                    actfile = files1[i];
                    break;
                }
            }
            if (actfile != "")
            {
                return actfile;
            }
            else
                return Name;
        }
        public static bool IsExeRunning(string filePath)
        {

            if (!File.Exists(filePath))
            {
                FileStream aFile = new FileStream(filePath, FileMode.CreateNew, FileAccess.Write);
                StreamWriter sw = new StreamWriter(aFile);
                sw.Write("User Id: " + Environment.UserName);
                sw.Write(Environment.NewLine);
                sw.Write("Start Time: " + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
                sw.Write(Environment.NewLine);
                sw.Write("--------------------------------------------------");
                sw.Close();
                aFile.Close();
                return false;
            }
            else
            {
                return true;
            }
        }
        #endregion Email SD


    }
}
