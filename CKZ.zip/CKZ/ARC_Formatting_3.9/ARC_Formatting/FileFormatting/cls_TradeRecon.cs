﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.OleDb;
using System.IO;
using Microsoft.Office.Interop.Excel;

namespace ARC_Formatting.FileFormatting
{
    public class cls_TradeRecon
    {
        public void TradingRecon(string Soure_Path, string Recon_Date, string Desti_Path, string Recon_name, string Output_Path, string Formatted_File_Name, string ext)
        {
            OleDbConnection objConn = null;
            System.Data.DataTable dt = null;

            try
            {
                // Trading sheet
                string excelFile = Soure_Path;

                Microsoft.Office.Interop.Excel.Application oExcel = new Microsoft.Office.Interop.Excel.Application();

                oExcel.Visible = false;
                oExcel.DisplayAlerts = false;
                Microsoft.Office.Interop.Excel.Workbook WB = oExcel.Workbooks.Open(excelFile, Type.Missing, false);
                System.Data.DataTable dt1 = new System.Data.DataTable();
                dt1.Columns.Add("Sheets");
                int a = 0;
                foreach (Worksheet worksheet in WB.Worksheets)
                {
                    dt1.Rows.Add();
                    dt1.Rows[a][0] = worksheet.Name.ToString();
                    a++;
                }

                System.Data.DataTable dtt0 = new System.Data.DataTable();
                System.Data.DataTable dtt1 = new System.Data.DataTable();
                System.Data.DataTable dtt2 = new System.Data.DataTable();
                System.Data.DataTable dtt3 = new System.Data.DataTable();
                System.Data.DataTable dtt4 = new System.Data.DataTable();
                System.Data.DataTable dtt5 = new System.Data.DataTable();
                System.Data.DataTable dtt6 = new System.Data.DataTable();
                System.Data.DataTable dtt7 = new System.Data.DataTable();
                System.Data.DataTable dtt8 = new System.Data.DataTable();
                System.Data.DataTable dtt9 = new System.Data.DataTable();
                System.Data.DataTable dtt10 = new System.Data.DataTable();
                for (int j = 0; j <= dt1.Rows.Count - 1; j++)
                {
                    string name = "";

                    name = dt1.Rows[j][0].ToString().Replace("'", "");
                    if (j == 0)
                    {
                        dtt0 = ExcelGetDataTable(excelFile, name);
                    }
                    if (j == 1)
                    {
                        dtt1 = ExcelGetDataTable(excelFile, name);
                    }
                    if (j == 2)
                    {
                        dtt2 = ExcelGetDataTable(excelFile, name);
                    }
                    if (j == 3)
                    {
                        dtt3 = ExcelGetDataTable(excelFile, name);
                    }
                    if (j == 4)
                    {
                        dtt4 = ExcelGetDataTable(excelFile, name);
                    }
                    if (j == 5)
                    {
                        dtt5 = ExcelGetDataTable(excelFile, name);
                    }
                    if (j == 6)
                    {
                        dtt6 = ExcelGetDataTable(excelFile, name);
                    }
                    if (j == 7)
                    {
                        dtt7 = ExcelGetDataTable(excelFile, name);
                    }
                    if (j == 8)
                    {
                        dtt8 = ExcelGetDataTable(excelFile, name);
                    }
                    if (j == 9)
                    {
                        dtt9 = ExcelGetDataTable(excelFile, name);
                    }
                    if (j == 10)
                    {
                        dtt10 = ExcelGetDataTable(excelFile, name);
                    }
                }
                dtt0.Merge(dtt1);
                dtt0.Merge(dtt2);
                dtt0.Merge(dtt3);
                dtt0.Merge(dtt4);
                dtt0.Merge(dtt5);
                dtt0.Merge(dtt6);
                dtt0.Merge(dtt7);
                dtt0.Merge(dtt8);
                dtt0.Merge(dtt9);
                dtt0.Merge(dtt10);

                string strConn;
                string paths = Soure_Path.Substring(0, Soure_Path.LastIndexOf("\\")) + "\\";
                string[] files1 = Directory.GetFiles(paths);
                string actfile = "";
                for (int i = 0; i < files1.Length; i++)
                {
                    files1[i] = Path.GetFileName(files1[i]);
                    if (files1[i].Contains("Consolidate Account List for Custody"))
                    {
                        actfile = files1[i];
                        break;
                    }

                }
                string flPath = paths + actfile;
                strConn = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + flPath + ";Extended Properties=\"Excel 12.0;HDR=Yes;IMEX=1\"";

                System.Data.DataTable dtexcel = new System.Data.DataTable();
                OleDbConnection conn = new OleDbConnection(strConn);

                conn.Open();

                string sheet = "VN Account-Security Reference$";
                string query = "SELECT  * FROM [" + sheet + "]";
                OleDbDataAdapter daexcel = new OleDbDataAdapter(query, conn);
                dtexcel.Locale = System.Globalization.CultureInfo.CurrentCulture;
                daexcel.Fill(dtexcel);
                int m = 0;
                System.Data.DataTable d1 = new System.Data.DataTable();
                d1.Columns.Add("SL no");
                d1.Columns.Add("Investor name");
                d1.Columns.Add("VSD' SCA");
                d1.Columns.Add("Local stock code");
                d1.Columns.Add("X");
                d1.Columns.Add("QTY");
                d1.Columns.Add("PMS number");
                d1.Columns.Add("CON");

                for (int i = 0; i <= dtt0.Rows.Count - 1; i++)
                {
                    d1.Rows.Add();
                    d1.Rows[m][0] = "";
                    d1.Rows[m][1] = dtt0.Rows[i][1];
                    d1.Rows[m][2] = dtt0.Rows[i][2];
                    d1.Rows[m][3] = dtt0.Rows[i][4];
                    d1.Rows[m][4] = dtt0.Rows[i][5];
                    d1.Rows[m][5] = "'" + dtt0.Rows[i][11];//9 old
                    d1.Rows[m][6] = "";
                    d1.Rows[m][7] = "";

                    m++;
                }
                int n = 0;
                for (int i = 0; i <= d1.Rows.Count - 1; i++)
                {
                    for (int k = 0; k <= dtexcel.Rows.Count - 1; k++)
                    {
                        if (dtexcel.Rows[k][0].ToString().Trim().ToUpper() == d1.Rows[i][1].ToString().Trim().ToUpper() && d1.Rows.Count - 1 >= n)
                        {

                            //double dd1 = Convert.ToDouble(d1.Rows[k][5].ToString().Trim());
                            d1.Rows[n][6] = "'" + dtexcel.Rows[k][2].ToString().Trim();
                            d1.Rows[n][7] = "'" + dtexcel.Rows[k][2].ToString().Trim() + d1.Rows[i][3].ToString().Trim();
                            n++;
                        }
                    }
                }

                for (int i = 0; i <= d1.Rows.Count - 1; i++)
                {
                    for (int j = 0; j <= dtexcel.Rows.Count - 1; j++)
                    {
                        if (d1.Rows[i][1].ToString().Trim().ToUpper() == dtexcel.Rows[j][0].ToString().Trim().ToUpper())
                        {
                            d1.Rows[i][6] = "'" + dtexcel.Rows[j][3];
                            break;
                        }
                        else
                        {
                            d1.Rows[i][6] = "";
                        }
                    }
                }
                for (int i = 0; i <= d1.Rows.Count - 1; i++)
                {
                    if (d1.Rows[i][6].ToString() == "")
                    {
                        for (int j = 0; j <= dtexcel.Rows.Count - 1; j++)
                        {
                            if (d1.Rows[i][1].ToString().ToLower() == dtexcel.Rows[j][0].ToString().ToLower())
                            {
                                d1.Rows[i][6] = "'" + dtexcel.Rows[j][3];
                            }
                        }
                    }
                }
                for (int i = d1.Rows.Count - 1; i >= 0; i--)
                {
                    d1.Rows[i][7] = "";
                }
                for (int i = 0; i <= d1.Rows.Count - 1; i++)
                {
                    d1.Rows[i][7] = d1.Rows[i][6].ToString() + d1.Rows[i][3];
                }
                int a1 = 0;
                for (int i = 0; i <= d1.Rows.Count - 1; i++)
                {
                    a1 = i + 1;
                    d1.Rows[i][0] = a1.ToString();
                }
                //for (int i = 0; i <= d1.Rows.Count - 1; i++)
                //{
                //    if (d1.Rows[i][6].ToString() == "")
                //    {
                //        for (int k = 0; k <= dtexcel.Rows.Count - 1; k++)
                //        {
                //            if (dtexcel.Rows[k][4].ToString().Trim().ToUpper() == d1.Rows[i][2].ToString().Trim().ToUpper())
                //            {
                //                //double dd1 = Convert.ToDouble(d1.Rows[k][5].ToString().Trim());
                //                d1.Rows[i][6] = "'" + dtexcel.Rows[k][3].ToString().Trim();
                //                d1.Rows[i][7] = "'" + dtexcel.Rows[k][3].ToString().Trim() + d1.Rows[i][3].ToString().Trim();
                //                //n++;
                //                break;
                //            }
                //        }
                //    }
                //}

                ReleaseComObject(WB);
                ReleaseComObject(oExcel);
                ExportToExcel_Common(d1, Output_Path + Formatted_File_Name);
            }
            catch
            {

            }
            finally
            {
                // Clean up.
                if (objConn != null)
                {
                    objConn.Close();
                    objConn.Dispose();
                }
                if (dt != null)
                {
                    dt.Dispose();
                }
            }
        }

        public void ReleaseComObject(object ob)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(ob);
                ob = null;
            }
            catch
            {
                ob = null;
            }
            finally
            {
                GC.Collect(GC.MaxGeneration);
                GC.WaitForPendingFinalizers();
            }
        }
        public void ExportToExcel_Common(System.Data.DataTable dt, string Save_File_Path)
        {
            var excelApp = new Microsoft.Office.Interop.Excel.Application();

            Microsoft.Office.Interop.Excel.Workbook workBook = null;
            workBook = excelApp.Workbooks.Add(Type.Missing);                // single worksheet
            Microsoft.Office.Interop.Excel._Worksheet workSheet = (Microsoft.Office.Interop.Excel.Worksheet)workBook.Worksheets.Add(Type.Missing);
            Microsoft.Office.Interop.Excel.Range excelCellrange = null;
            Microsoft.Office.Interop.Excel.Range excelCellrange2 = null;
            excelApp.DisplayAlerts = false;
            excelApp.Visible = false;

            //Here column will be created
            if (Save_File_Path.Contains("CLG_AED_") || Save_File_Path.Contains("SCB_QAR_CLG_") || Save_File_Path.Contains("CUS_ID_CUS_FTP") || Save_File_Path.Contains("SCB_PHP_CLG_INWARD_EBS") || Save_File_Path.Contains("SCB_BAH_CLG_") || Save_File_Path.Contains("SCB_OMAN_CLG_INWARD_CBR_") || Save_File_Path.Contains("SCB_OMAN_CLG_OUTWARDRETN_CBR_") || Save_File_Path.Contains("SCB_OMAN_CLG_OUTWARD_CBR_") || Save_File_Path.Contains("SCB_OMAN_CLG_INWARDRETN_CBR_") || Save_File_Path.Contains("SCB_OMAN_CLG_OUTWARD_") || Save_File_Path.Contains("SCB_OMAN_CLG_INWARDRETN_") || Save_File_Path.Contains("CLG_JOD_") || Save_File_Path.Contains("TRI_CUS") || Save_File_Path.Contains("OWNCUSTODY1_") || Save_File_Path.Contains("OWNCUSTODY2_") || Save_File_Path.Contains("GMI_CASH"))
            {

            }
            else if (Save_File_Path.Contains("SCB_IBN_TOP_UP") || Save_File_Path.Contains("SCB_VPN_TOPUP_DATED"))
            {
                for (int i = 0; i < dt.Columns.Count; i++)
                {
                    if (dt.Columns[i].ColumnName == "S#no")
                    {
                        workSheet.Cells[1, i + 1] = "S.no";
                    }
                    else
                    {
                        workSheet.Cells[1, i + 1] = dt.Columns[i].ColumnName;
                    }
                }

            }
            else if (Save_File_Path.Contains("SCB_IBN_DATED"))
            {
                for (int i = 0; i < dt.Columns.Count; i++)
                {
                    if (dt.Columns[i].ColumnName == "Num")
                    {
                        workSheet.Cells[1, i + 1] = "";
                    }
                    else
                    {
                        workSheet.Cells[1, i + 1] = dt.Columns[i].ColumnName;
                    }
                }

            }
            else if (Save_File_Path.Contains("SCB_VISA_SWCH_DATED_"))
            {
                for (int i = 0; i < dt.Columns.Count; i++)
                {
                    if (dt.Columns[i].ColumnName == "Card Acceptor Term# Location")
                    {
                        workSheet.Cells[1, i + 1] = "Card Acceptor Term. Location";
                    }
                    else
                    {
                        workSheet.Cells[1, i + 1] = dt.Columns[i].ColumnName;
                    }
                }

            }
            else if (Save_File_Path.Contains("LOCALBANK_STMT_TB_VN_SBV"))
            {
                for (int i = 0; i < dt.Columns.Count; i++)
                {
                    if (dt.Columns[i].ColumnName == "F2" || dt.Columns[i].ColumnName == "F3" || dt.Columns[i].ColumnName == "F4" || dt.Columns[i].ColumnName == "F5" || dt.Columns[i].ColumnName == "F6" || dt.Columns[i].ColumnName == "F7")
                    {
                        workSheet.Cells[1, i + 1] = "";
                    }
                    else
                    {
                        workSheet.Cells[1, i + 1] = dt.Columns[i].ColumnName;
                    }
                }

            }
            else if (Save_File_Path.Contains("SCB_JAPAN_BOJ_CENTRAL_BANK_"))
            {
                for (int i = 0; i < dt.Columns.Count; i++)
                {
                    //if (dt.Columns[i].ColumnName.Contains("F") == "F2" || dt.Columns[i].ColumnName == "F3" || dt.Columns[i].ColumnName == "F4" || dt.Columns[i].ColumnName == "F5" || dt.Columns[i].ColumnName == "F6" || dt.Columns[i].ColumnName == "F7" || dt.Columns[i].ColumnName == "F1" || dt.Columns[i].ColumnName == "F8" || dt.Columns[i].ColumnName == "F9" || dt.Columns[i].ColumnName == "F10" || dt.Columns[i].ColumnName == "F11")
                    if (dt.Columns[i].ColumnName.Contains("F"))
                    {

                        workSheet.Cells[1, i + 1] = "";
                    }
                    else if (dt.Columns[i].ColumnName != "")
                    {
                        string Date = dt.Columns[i].ColumnName;
                        workSheet.Cells[1, i + 1] = Convert.ToDateTime(Date).ToString("dd-MMM-yyyy");
                    }
                }

            }
            else
            {
                for (int i = 0; i < dt.Columns.Count; i++)
                {
                    workSheet.Cells[1, i + 1] = dt.Columns[i].ColumnName;
                }
            }


            //Here Rows will be created
            for (int j = 0; j < dt.Rows.Count; j++)
            {
                for (int k = 0; k < dt.Columns.Count; k++)
                {
                    workSheet.Cells[j + 2, k + 1] = dt.Rows[j].ItemArray[k].ToString();
                }
            }
            if (Save_File_Path.Contains("SCB_PHP_CLG_INWARD_EBS") || Save_File_Path.Contains("SCB_BAH_CLG_") || Save_File_Path.Contains("SCB_OMAN_CLG_INWARD_CBR_") || Save_File_Path.Contains("SCB_OMAN_CLG_OUTWARDRETN_CBR_") || Save_File_Path.Contains("SCB_OMAN_CLG_OUTWARD_CBR_") || Save_File_Path.Contains("SCB_OMAN_CLG_INWARDRETN_CBR_") || Save_File_Path.Contains("SCB_OMAN_CLG_OUTWARD_") || Save_File_Path.Contains("SCB_OMAN_CLG_INWARDRETN_") || Save_File_Path.Contains("SCB_QAR_CLG_INRTN_EBBS_") || Save_File_Path.Contains("SCB_QAR_CLG_OUTRTN_CBR_") || Save_File_Path.Contains("SCB_QAR_CLG_INRTN_CBR_") || Save_File_Path.Contains("SCB_QAR_CLG_OUT_CBR_") || Save_File_Path.Contains("SCB_QAR_CLG_IN_CBR_") || Save_File_Path.Contains("SCB_OMAN_CLG_INWARD"))
            {
                workSheet = (Microsoft.Office.Interop.Excel.Worksheet)workBook.Worksheets.get_Item(1);
                Microsoft.Office.Interop.Excel.Range range;
                range = (Microsoft.Office.Interop.Excel.Range)workSheet.Application.Rows[1, Type.Missing];
                range.Select();
                range.Delete(Microsoft.Office.Interop.Excel.XlDirection.xlUp);
            }
            if (Save_File_Path.Contains("SCB_QAR_CLG_") && !Save_File_Path.Contains("SCB_QAR_CLG_INRTN_EBBS_") && !Save_File_Path.Contains("SCB_QAR_CLG_OUTRTN_CBR_") && !Save_File_Path.Contains("SCB_QAR_CLG_INRTN_CBR_") && !Save_File_Path.Contains("SCB_QAR_CLG_OUT_CBR_") && !Save_File_Path.Contains("SCB_QAR_CLG_IN_CBR_"))
            {

                workSheet = (Microsoft.Office.Interop.Excel.Worksheet)workBook.Worksheets.get_Item(1);
                Microsoft.Office.Interop.Excel.Range range;
                range = (Microsoft.Office.Interop.Excel.Range)workSheet.Application.Rows[1, Type.Missing];
                range = (Microsoft.Office.Interop.Excel.Range)workSheet.Application.Rows[2, Type.Missing];
                range.Select();
                range.Delete(Microsoft.Office.Interop.Excel.XlDirection.xlUp);

            }


            //workSheet.Cells[1, 1].EntireRow.Font.Bold = true;
            //string Patern1 = string.Format("0")
            if (Save_File_Path.Contains("CLG_AED_"))
            {
                workSheet.Range["D:D"].NumberFormat = "#.000";
            }
            if (Save_File_Path.Contains("SCB_PHP_CLG_INWARD_") || Save_File_Path.Contains("CURSE_AS_OF_"))
            {
                workSheet.Range["D:D"].NumberFormat = "#,###.00";
            }
            if (Save_File_Path.Contains("SCB_OMAN_CLG_INWARD_CBR_"))
            {
                workSheet.Range["D:D"].NumberFormat = "@";
                workSheet.Range["L:L"].NumberFormat = "@";
            }
            workSheet.Columns.AutoFit();
            excelCellrange = workSheet.UsedRange;
            excelCellrange2 = excelCellrange.get_Range("A1", Type.Missing);
            excelCellrange2.EntireRow.Font.Bold = true;
            Microsoft.Office.Interop.Excel.Borders border = excelCellrange.Borders;
            border.LineStyle = Microsoft.Office.Interop.Excel.XlLineStyle.xlContinuous;
            border.Weight = 2d;
            // check file path
            if (!string.IsNullOrEmpty(Save_File_Path))
            {
                try
                {
                    if (Save_File_Path.Contains("India - RBI Main Account") || Save_File_Path.Contains("India - RBI RTGS Account"))
                    {
                        excelCellrange2 = workSheet.get_Range("A1", Type.Missing);
                        excelCellrange2.EntireRow.Delete(Type.Missing);
                        workBook.SaveCopyAs(Save_File_Path);
                        workBook.Close();
                        excelApp.Quit();
                    }
                    else if (Save_File_Path.Contains("Beharin_loan"))
                    {
                        excelCellrange2 = workSheet.get_Range("A1", Type.Missing);
                        excelCellrange2.EntireRow.Delete(Type.Missing);
                        excelCellrange = workSheet.Rows[1];
                        excelCellrange.Insert();
                        workSheet.Cells[1, 1] = "ID NUMBER";
                        workSheet.Cells[1, 2] = "LOAN A/C NUMBER";
                        dynamic allDataRange = workSheet.UsedRange;
                        allDataRange.Sort(allDataRange.Columns[2], Microsoft.Office.Interop.Excel.XlSortOrder.xlDescending);
                        workBook.SaveCopyAs(Save_File_Path);
                        workBook.Close();
                        excelApp.Quit();
                        File.Move(Save_File_Path, Path.ChangeExtension(Save_File_Path, ".csv"));

                    }
                    else if (Save_File_Path.Contains("MISC CASH PYT_RECEIPT ACCOUNT") || Save_File_Path.Contains("Co_Disposal") || Save_File_Path.Contains("CCMS") || Save_File_Path.Contains("Web") || Save_File_Path.Contains("MY SUSPENS ACCOUNT") || Save_File_Path.Contains("FED_FILE"))
                    {
                        workBook.SaveCopyAs(Save_File_Path);
                        workBook.Close();
                        excelApp.Quit();
                        File.Move(Save_File_Path, Path.ChangeExtension(Save_File_Path, ".csv"));
                    }
                    else if (Save_File_Path.Contains("CBINDONESIA") || Save_File_Path.Contains("TBILL"))
                    {
                        excelCellrange2 = workSheet.get_Range("A1", Type.Missing);
                        excelCellrange2.EntireRow.Delete(Type.Missing);
                        workBook.SaveAs(Save_File_Path, Microsoft.Office.Interop.Excel.XlFileFormat.xlCSVWindows, Type.Missing, Type.Missing, false, false, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlExclusive, Microsoft.Office.Interop.Excel.XlSaveConflictResolution.xlLocalSessionChanges, false, Type.Missing, Type.Missing, Type.Missing);
                        workBook.Close();
                        excelApp.Quit();
                        // File.Move(Save_File_Path, Path.ChangeExtension(Save_File_Path, ".csv"));
                    }
                    //else if (Save_File_Path.Contains("SCB_JAPAN_BOJ_CENTRAL BANK_"))
                    //{
                    //    excelCellrange2 = workSheet.get_Range("A1:A2", Type.Missing);
                    //    excelCellrange2.EntireRow.Delete(Type.Missing);
                    //    workBook.SaveAs(Save_File_Path, Microsoft.Office.Interop.Excel.XlFileFormat.xlCSVWindows, Type.Missing, Type.Missing, false, false, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlExclusive, Microsoft.Office.Interop.Excel.XlSaveConflictResolution.xlLocalSessionChanges, false, Type.Missing, Type.Missing, Type.Missing);
                    //    workBook.Close();
                    //    excelApp.Quit();
                    //}
                    else if (Save_File_Path.Contains("CHQ") || Save_File_Path.Contains("S2B") || Save_File_Path.Contains("LOCALBANK_STMT_TB_VN_SBV") || Save_File_Path.Contains("SCB_JAPAN_BOJ_CENTRAL_BANK_"))
                    {
                        workBook.SaveAs(Save_File_Path, Microsoft.Office.Interop.Excel.XlFileFormat.xlCSVWindows, Type.Missing, Type.Missing, false, false, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlExclusive, Microsoft.Office.Interop.Excel.XlSaveConflictResolution.xlLocalSessionChanges, false, Type.Missing, Type.Missing, Type.Missing);
                        workBook.Close();
                        excelApp.Quit();

                    }
                    else
                    {
                        workBook.SaveCopyAs(Save_File_Path);
                        workBook.Close();
                        excelApp.Quit();
                    }
                    ReleaseComObject(workSheet);
                    ReleaseComObject(workBook);
                    ReleaseComObject(excelApp);
                }
                catch
                {
                    workBook.SaveCopyAs(Save_File_Path);
                    workBook.Close();
                    excelApp.Quit();

                    ReleaseComObject(workSheet);
                    ReleaseComObject(workBook);
                    ReleaseComObject(excelApp);
                }
            }

        }
        public static System.Data.DataTable ExcelGetDataTable(string Soure_Path, string sheetname)
        {
            string strConn = "";
            strConn = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + Soure_Path + ";Extended Properties=\"Excel 12.0;HDR=Yes;IMEX=1\"";



            System.Data.DataTable dtexcel = new System.Data.DataTable();
            OleDbConnection conn = new OleDbConnection(strConn);

            conn.Open();


            string sheet = sheetname + "$";

            string query = "SELECT  * FROM [" + sheet + "]";
            OleDbDataAdapter daexcel = new OleDbDataAdapter(query, conn);
            dtexcel.Locale = System.Globalization.CultureInfo.CurrentCulture;
            daexcel.Fill(dtexcel);
            System.Data.DataTable dt = new System.Data.DataTable();
            for (int i = 0; i <= 24; i++)
            {
                dt.Columns.Add(i.ToString());
            }
            int x = 0;

            for (int i = 0; i <= dtexcel.Rows.Count - 1; i++)
            {
                // if (dtexcel.Rows[i][1].ToString().Trim() != "" && dtexcel.Rows[i][9].ToString().Trim().Any(char.IsDigit) && dtexcel.Rows[i][7].ToString().Trim() == "0" && dtexcel.Rows[i][8].ToString().Trim() == "0")
                if (dtexcel.Rows[i][1].ToString().Trim() != "" && dtexcel.Rows[i][11].ToString().Trim().Any(char.IsDigit) && (dtexcel.Rows[i][9].ToString().Trim() == "0" || dtexcel.Rows[i][9].ToString().Trim() == "-" || dtexcel.Rows[i][9].ToString().Trim() == "") && (dtexcel.Rows[i][10].ToString().Trim() == "0" || dtexcel.Rows[i][10].ToString().Trim() == "-" || dtexcel.Rows[i][10].ToString().Trim() == ""))
                {
                    dt.Rows.Add();
                    dt.Rows[x][0] = dtexcel.Rows[i][0];
                    dt.Rows[x][1] = dtexcel.Rows[i][1];
                    dt.Rows[x][2] = dtexcel.Rows[i][2];
                    dt.Rows[x][3] = dtexcel.Rows[i][3];
                    dt.Rows[x][4] = dtexcel.Rows[i][4];
                    dt.Rows[x][5] = dtexcel.Rows[i][5];
                    dt.Rows[x][6] = dtexcel.Rows[i][6];
                    dt.Rows[x][7] = dtexcel.Rows[i][7];
                    dt.Rows[x][8] = dtexcel.Rows[i][8];
                    dt.Rows[x][9] = dtexcel.Rows[i][9];
                    dt.Rows[x][10] = dtexcel.Rows[i][10];
                    dt.Rows[x][11] = dtexcel.Rows[i][11];
                    dt.Rows[x][12] = dtexcel.Rows[i][12];
                    dt.Rows[x][13] = dtexcel.Rows[i][13];
                    dt.Rows[x][14] = dtexcel.Rows[i][14];
                    dt.Rows[x][15] = dtexcel.Rows[i][15];
                    dt.Rows[x][16] = dtexcel.Rows[i][16];
                    dt.Rows[x][17] = dtexcel.Rows[i][17];


                    x++;
                }
            }
            if (dt.Columns.Count <= 23)
            {
                dt.Columns.Add("24");
            }
            return dt;
        }
    }
}
