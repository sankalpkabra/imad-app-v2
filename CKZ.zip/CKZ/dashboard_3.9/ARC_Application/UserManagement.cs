﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ARC_Application
{
    public partial class UserManagement : Form
    {
        public UserManagement()
        {
            InitializeComponent();
           // IsBetween();
        }

        DateTime time =  DateTime.Today;

        private void Btn_Search_Click(object sender, EventArgs e)
        {

        }
        //int hr = time.Hour;

       // string s = time.ToString();
             

        
        //TimeSpan.Compare(startTime.TimeOfDay,endTime.TimeOfDay);
        //public bool IsBetween()
        //{
        //    if (time.TimeOfDay == startTime.TimeOfDay) return true;
        //    if (time.TimeOfDay == endTime.TimeOfDay) return true;

        //    if (startTime.TimeOfDay <= endTime.TimeOfDay)
        //        return (time.TimeOfDay >= startTime.TimeOfDay && time.TimeOfDay <= endTime.TimeOfDay);
        //    else
        //        return !(time.TimeOfDay >= endTime.TimeOfDay && time.TimeOfDay <= startTime.TimeOfDay);
        //}

    }
}
