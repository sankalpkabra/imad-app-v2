﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;
using System.Runtime.InteropServices;

namespace ARC_Opics_DLL
{
    public class clsWindows
    {
        [DllImport("User32.dll", SetLastError = true)]
        static extern void SwitchToThisWindow(IntPtr hWnd, bool fAltTab);

        public void FindNoOfOpenWindow()
        {
            int i = 0;
            int j = 0;
            int chck = 0;
            string[] arryWindowTitle = new string[20];
            Process[] processes = Process.GetProcesses();
            foreach (Process p in processes)
            {                
                if (!String.IsNullOrEmpty(p.MainWindowTitle))
                {
                    arryWindowTitle[i] = p.MainWindowTitle.ToString();                    
                    if (p.MainWindowTitle.ToString() == "OpicsPlus - \\\\Remote" || p.MainWindowTitle.ToString() == "LOGR - \\\\Remote")
                    {
                        SwitchToThisWindow(processes[j].MainWindowHandle, true);
                        chck = 1;
                        break;                        
                    }                    
                    i++;                   
                }
                j++;
            }
            
        }
    }
}
