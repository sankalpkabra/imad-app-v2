﻿using System;
using System.Data;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using System.Drawing;
using System.Data.OleDb;
using System.Globalization;
using System.Configuration;
using System.Xml;
using System.Collections;
using Ionic.Zip;
//using Microsoft.Office.Interop.Excel;
namespace ARC_Application
{

    public partial class Dashboard : Form
    {
        Formatting_Logics obj = new Formatting_Logics();
        Hong_Trade_RPR obj2 = new Hong_Trade_RPR();
        DAccesss.Program das = new DAccesss.Program();
        DataTable dt_Final = new DataTable();
        string conString = ConfigurationManager.ConnectionStrings["ARC_conStr"].ConnectionString;
        static string Main_DIR_SharePath = ConfigurationManager.ConnectionStrings["Share_Path"].ToString();
        string date = string.Empty;
        int Flag = 0;
        string selectedProduct;
        string selectedcountry;
        string selectedRecon;
        string selectedApplication;
        int i;
        int j;
        int k;
        DataTable dt = new DataTable();
        string _selectedTab = "";
        DataTable dtHolidayRecords = new DataTable();


        ///
        /// Method  Btn_Srch_Click_1 commented - Aneesh
        //Need to uncomment Imp code
        //Image i1 = Image.FromFile(@"\\10.132.5.214\TempFiles\SAHIL\UAT_Runtimes\ARCRuntime\Images\Completed.jpg");//green
        //Image i2 = Image.FromFile(@"\\10.132.5.214\TempFiles\SAHIL\UAT_Runtimes\ARCRuntime\Images\Error.jpg");//Red
        //Image i3 = Image.FromFile(@"\\10.132.5.214\TempFiles\SAHIL\UAT_Runtimes\ARCRuntime\Images\InProgress.png");//Amber



        int Total;
        int Completed;
        int File_Count = 0;
        //int Folder_File_Count = 0;
        int Non_For_Counter = 0;
        int For_Counter = 0;
        public bool isexec = false;
        string destFile = string.Empty;
        SQLEncryption ecp = new SQLEncryption();
        string Directory = Main_DIR_SharePath + DateTime.Now.ToString("dd-MMM-yyyy") + "_Files\\";
        SqlCommand cmd;
        SqlDataAdapter da;
        string sla;
        string _reconName = string.Empty;
        string _reconDate = string.Empty;
        string temprecon = string.Empty;


        public Dashboard()
        {

            InitializeComponent();
            dtHolidayRecords = Get_Recon_Date_New("dd-MMM-yyyy");
            //obj.Create_Directory(conString, Directory);
            //GetShareDriveFiles(conString);

            if (!conString.StartsWith("Data"))
            {
                conString = ecp.Decrypt(conString);
            }
            cmb_cntry.DropDownStyle = ComboBoxStyle.DropDownList;
            cmb_Prdt.DropDownStyle = ComboBoxStyle.DropDownList;
            cmb_Recon.DropDownStyle = ComboBoxStyle.DropDownList;
            cmb_Application.DropDownStyle = ComboBoxStyle.DropDownList;
            refreshdata();
            File_ViewRecords();
            Recon_ViewRecord();
            tab_TLM();
            //refreshdata();
            //dateTimePicker1.MaxDate = DateTime.Now.AddDays(-1);
            //dateTimePicker1.CustomFormat = "dd/MM/yyyy";
            date = DateTime.Now.ToString("hh:mm");
            Timer timer = new Timer();
            //timer.Interval = (100 * 4500); // 7 min. 30 sec.
            timer.Interval = (100 * 2500);
            timer.Tick += new EventHandler(timer1_Tick);
            timer.Start();

            //Timer timer2 = new Timer();
            //timer2.Interval = (60000);
            //timer2.Tick += new EventHandler(timer2_Tick);
            //timer2.Start();
        }

        public void refreshdata()
        {
            try
            {
                DataTable dt_Final = new DataTable();
                dt_Final.Columns.Add("Country_Id");
                dt_Final.Columns.Add("Country_Name");
                dt_Final.Rows.Add("0", "--SELECT LIST--");
                SqlConnection con = new SqlConnection(conString);
                con.Open();
                SqlCommand cmd = new SqlCommand("select Country_Id,Country_Name from dbo.ARC_Country_Details order by Country_Name", con);
                cmd.CommandType = CommandType.Text;
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                sda.Fill(dt);

                foreach (DataRow d in dt.Rows)
                {
                    dt_Final.ImportRow(d);
                }

                cmb_cntry.SelectedIndexChanged -= new EventHandler(cmb_cntry_SelectedIndexChanged_1);
                cmb_cntry.ValueMember = "Country_Id";
                cmb_cntry.DisplayMember = "Country_Name";
                cmb_cntry.DataSource = dt_Final;
                cmb_cntry.SelectedIndexChanged += new EventHandler(cmb_cntry_SelectedIndexChanged_1);

                DataTable dt_Final1 = new DataTable();
                dt_Final1.Columns.Add("Product_ID");
                dt_Final1.Columns.Add("Product_name");
                dt_Final1.Rows.Add("0", "--SELECT LIST--");
                cmd = new SqlCommand("SELECT Product_ID,Product_name FROM dbo.ARC_Product_Details order by product_name", con);
                cmd.CommandType = CommandType.Text;
                sda = new SqlDataAdapter(cmd);
                dt = new DataTable();
                sda.Fill(dt);
                foreach (DataRow d in dt.Rows)
                {
                    dt_Final1.ImportRow(d);
                }

                cmb_Prdt.SelectedIndexChanged -= new EventHandler(cmb_Prdt_SelectedIndexChanged_1);
                cmb_Prdt.ValueMember = "Product_ID";
                cmb_Prdt.DisplayMember = "Product_name";
                cmb_Prdt.DataSource = dt_Final1;
                cmb_Prdt.SelectedIndexChanged += new EventHandler(cmb_Prdt_SelectedIndexChanged_1);

                DataTable dt_Final2 = new DataTable();
                dt_Final2.Columns.Add("Recon_ID");
                dt_Final2.Columns.Add("Recon_Name");
                dt_Final2.Rows.Add("0", "--SELECT LIST--");
                cmd = new SqlCommand("select * from arc_recon_master where is_active =1 order by recon_name", con);
                cmd.CommandType = CommandType.Text;
                sda = new SqlDataAdapter(cmd);
                dt = new DataTable();
                sda.Fill(dt);
                foreach (DataRow d in dt.Rows)
                {
                    dt_Final2.ImportRow(d);
                }

                cmb_Recon.SelectedIndexChanged -= new EventHandler(cmb_Recon_SelectedIndexChanged);
                cmb_Recon.ValueMember = "Recon_ID";
                cmb_Recon.DisplayMember = "Recon_Name";
                cmb_Recon.DataSource = dt_Final2;
                cmb_Recon.SelectedIndexChanged += new EventHandler(cmb_Recon_SelectedIndexChanged);

                DataTable dt_Final3 = new DataTable();
                dt_Final3.Columns.Add("App_ID");
                dt_Final3.Columns.Add("App_Name");
                dt_Final3.Rows.Add("0", "--SELECT LIST--");
                cmd = new SqlCommand("select distinct source_application as App_ID,source_application as App_Name from arc_scope_baseline where isnull(source_application,'')<>'' order by source_application", con);
                cmd.CommandType = CommandType.Text;
                sda = new SqlDataAdapter(cmd);
                dt = new DataTable();
                sda.Fill(dt_Final3);
                //foreach (DataRow d in dt.Rows)
                //{
                //    dt_Final3.ImportRow(d);
                //}

                cmb_Application.SelectedIndexChanged -= new EventHandler(cmb_Application_SelectedIndexChanged);
                cmb_Application.ValueMember = "App_ID";
                cmb_Application.DisplayMember = "App_Name";
                cmb_Application.DataSource = dt_Final3;
                cmb_Application.SelectedIndexChanged += new EventHandler(cmb_Application_SelectedIndexChanged);

                con.Close();
            }
            catch
            {

            }

        }

        public void File_ViewRecords_Old()
        {
            try
            {
                SqlConnection con = new SqlConnection(conString);
                date = DateTime.Now.ToString("hh:mm");
                con.Open();
                SqlCommand cmd = new SqlCommand("Select Scope_Id as [S No],Team,Country_Name,Recon,CONVERT(VARCHAR(8), SLA_Time, 108) as SLA_Time,CONVERT(VARCHAR(8), Receipt_Time, 108) as Receipt_Time,Report_Source_File_Name as [Input File Name],FTP_File_Format_Name as [Output File Name],Source_Application,IsProcessed,AutomationStartTime,AutomationEndTime,AutomationStatus FROM ARC_Scope_BaseLine where In_Scope_For_ARC='yes'", con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                int c = 1;
                for (int idx = 0; idx < dt.Rows.Count; idx++)
                {
                    dt.Rows[idx][0] = c;
                    c++;
                }
                int ReconCompleted = 0;
                int ReconCount = 0;
                dt.Columns.Add("Download Status");
                if (dt.Columns.Contains("Download Status"))
                {
                    for (int indx = 0; indx < dt.Rows.Count; indx++)
                    {
                        ReconCount++;
                        DateTime d = Convert.ToDateTime(dt.Rows[indx][4]);
                        DateTime d1 = Convert.ToDateTime(date);

                        if (string.IsNullOrEmpty(dt.Rows[indx]["AutomationStartTime"].ToString()) && string.IsNullOrEmpty(dt.Rows[indx]["AutomationEndTime"].ToString()))
                        {
                            dt.Rows[indx]["Download Status"] = "Yet To Start";
                        }
                        else if (!string.IsNullOrEmpty(dt.Rows[indx]["AutomationStartTime"].ToString()) && string.IsNullOrEmpty(dt.Rows[indx]["AutomationEndTime"].ToString()))
                        {
                            dt.Rows[indx]["Download Status"] = "In Progress";
                        }
                        else if (!string.IsNullOrEmpty(dt.Rows[indx]["AutomationStartTime"].ToString()) && Convert.ToBoolean(dt.Rows[indx]["IsProcessed"]) == true)
                        {
                            dt.Rows[indx]["Download Status"] = "Completed";
                            ReconCompleted++;
                        }
                        else if (!string.IsNullOrEmpty(dt.Rows[indx]["AutomationStartTime"].ToString()) && !string.IsNullOrEmpty(dt.Rows[indx]["AutomationEndTime"].ToString()) && Convert.ToBoolean(dt.Rows[indx]["IsProcessed"]) == false)
                        {
                            dt.Rows[indx]["Download Status"] = "Error";
                        }
                        else
                        {
                            dt.Rows[indx]["Download Status"] = "Yet To Start";
                        }
                    }
                }


                dt.Columns.Remove("AutomationStartTime");
                dt.Columns.Remove("AutomationEndTime");
                dt.Columns.Remove("IsProcessed");
                dt.Columns.Remove("AutomationStatus");


                DGV_Data.DataSource = dt;
                //DGV_Data.Columns[0].Visible = false;

                foreach (DataGridViewColumn dc in DGV_Data.Columns)
                {
                    dc.SortMode = DataGridViewColumnSortMode.NotSortable;
                    if (dc.HeaderText == "Select")
                    {
                        dc.ReadOnly = false;
                    }
                    else
                    {
                        dc.ReadOnly = true;
                    }
                }

                //Download Status - Color variant
                foreach (DataGridViewRow row in DGV_Data.Rows)
                {
                    foreach (DataGridViewColumn col in DGV_Data.Columns)
                    {
                        if (DGV_Data["Download Status", row.Index].Value == "Yet To Start")
                        {
                            DGV_Data["Download Status", row.Index].Style.BackColor = Color.SkyBlue;
                        }

                        if (DGV_Data["Download Status", row.Index].Value == "In Progress")
                        {
                            DGV_Data["Download Status", row.Index].Style.BackColor = Color.Orange;
                        }

                        if (DGV_Data["Download Status", row.Index].Value == "Completed")
                        {
                            DGV_Data["Download Status", row.Index].Style.BackColor = Color.LimeGreen;
                        }

                        if (DGV_Data["Download Status", row.Index].Value == "Error")
                        {
                            DGV_Data["Download Status", row.Index].Style.BackColor = Color.Firebrick;
                        }
                    }
                }

                con.Close();
                //Total_count();
                lbl_cnt.Text = ReconCount.ToString();
                lbl_com_cnt.Text = ReconCompleted.ToString();
                lbl_pen_cnt.Text = (ReconCount - ReconCompleted).ToString();
            }
            catch
            {

            }
        }

        public void File_ViewRecords()
        {
            try
            {
                // Modified by 1554580 07 Sep 2017
                // SqlConnection con = new SqlConnection(conString);
                date = DateTime.Now.ToString("hh:mm");
                // con.Open();
                //SqlCommand cmd = new SqlCommand("Select Scope_Id as [S No],Team,Country_Name,Recon,CONVERT(VARCHAR(8), SLA_Time, 108) as SLA_Time,CONVERT(VARCHAR(8), Receipt_Time, 108) as Receipt_Time,Report_Source_File_Name as [Input File Name],FTP_File_Format_Name as [Output File Name],Source_Application,IsProcessed,AutomationStartTime,AutomationEndTime,AutomationStatus FROM ARC_Scope_BaseLine where In_Scope_For_ARC='yes'", con);
                //SqlCommand cmd = new SqlCommand(strSelectQuery, con);
                //SqlDataAdapter da = new SqlDataAdapter(cmd);
                //DataTable dt = new DataTable();
                //da.Fill(dt);

                Hashtable hat = new Hashtable();
                i = cmb_cntry.SelectedIndex;
                j = cmb_Prdt.SelectedIndex;
                k = cmb_Application.SelectedIndex;
                selectedcountry = this.cmb_cntry.GetItemText(this.cmb_cntry.SelectedItem);
                selectedProduct = this.cmb_Prdt.GetItemText(this.cmb_Prdt.SelectedItem);
                selectedApplication = this.cmb_Application.GetItemText(this.cmb_Application.SelectedItem);

                string strProduct = "";
                string strCountry = "";
                string strApplication = "";

                if (i > 0)
                {
                    strCountry = " and a.Country_Name='" + selectedcountry + "'";
                }
                if (j > 0)
                {
                    strProduct = " and a.Team='" + selectedProduct + "'";
                }
                if (k > 0)
                {
                    strApplication = " and a.Source_Application='" + selectedApplication + "'";
                }

                //string strSelectQuery = "Select row_Number () over(order by Team,Country_name,Recon,Report_Source_File_Name) [S No],Team,Country_Name,Recon,CONVERT(VARCHAR(8), SLA_Time, 108) as SLA_Time,CONVERT(VARCHAR(8), Receipt_Time, 108) as Receipt_Time,Report_Source_File_Name+'.'+isnull(File_Format,'') as [Input File Name],FTP_File_Format_Name as [Output File Name],Source_Application,Frequency,Manual_FTP,IsProcessed,AutomationStartTime,AutomationEndTime,AutomationStatus,Convert(nvarchar(15),'NA') as [Recon date],'0' as is_holiday_logic FROM ARC_Scope_BaseLine a where In_Scope_For_ARC='yes' " + strCountry + " " + strProduct + " " + strApplication + "";
                //strSelectQuery = strSelectQuery + " and recon in(select recon_name from arc_Recon_master where Is_Active=1 and isnull(is_holiday_logic,'0')=0  )";
                //strSelectQuery = strSelectQuery + " union select row_Number () over(order by a.Team,a.Country_name,a.Recon,a.Report_Source_File_Name)[S No],a.Team,a.Country_Name,a.Recon,CONVERT(VARCHAR(8), a.SLA_Time, 108) as SLA_Time,CONVERT(VARCHAR(8), a.Receipt_Time, 108) as Receipt_Time,a.Report_Source_File_Name+'.'+isnull(a.File_Format,'') as [Input File Name],a.FTP_File_Format_Name as [Output File Name],a.Source_Application,a.Frequency,a.Manual_FTP,b.IsProcessed,b.AutomationStartTime,b.AutomationEndTime,b.AutomationStatus,Convert(nvarchar(15),b.[Recon_date],103) as [Recon Date],'1' as is_holiday_logic from arc_scope_baseline a,ARC_Scope_Baseline_Logic b where a.Country_id=b.Country_id and a.product_id=b.product_id and a.Recon_Id=b.Recon_Id and a.Country_Name=b.Country_Name and a.Report_Source_File_Name=b.Report_Source_File_Name and isnull(a.FTP_File_Format_Name,'')=isnull(b.FTP_File_Format_Name,'')   " + strCountry + " " + strProduct + " " + strApplication + " ";
                //strSelectQuery = strSelectQuery + "  and a.recon in(select recon_name from arc_Recon_master where Is_Active=1 and isnull(is_holiday_logic,'0')=1) order by Team,Country_name,Recon";//,Report_Source_File_Name";

                string strSelectQuery = "Select row_Number () over(order by Team,Country_name,Recon,Report_Source_File_Name) [S No],Team,Country_Name,Recon,CONVERT(VARCHAR(8), SLA_Time, 108) as SLA_Time,CONVERT(VARCHAR(8), Receipt_Time, 108) as Receipt_Time,Report_Source_File_Name+'.'+isnull(File_Format,'') as [Input File Name],FTP_File_Format_Name as [Output File Name],Source_Application,Frequency,Manual_FTP,IsProcessed,AutomationStartTime,AutomationEndTime,Remarks,FTP_Status,AutomationStatus,Convert(nvarchar(15),'NA') as [Recon date],'0' as is_holiday_logic FROM ARC_Scope_BaseLine a where In_Scope_For_ARC='yes' " + strCountry + " " + strProduct + " " + strApplication + "";
                strSelectQuery = strSelectQuery + " and recon in(select recon_name from arc_Recon_master where Is_Active=1 and isnull(is_holiday_logic,'0')=0  )";
                strSelectQuery = strSelectQuery + " union select row_Number () over(order by a.Team,a.Country_name,a.Recon,a.Report_Source_File_Name)[S No],a.Team,a.Country_Name,a.Recon,CONVERT(VARCHAR(8), a.SLA_Time, 108) as SLA_Time,CONVERT(VARCHAR(8), a.Receipt_Time, 108) as Receipt_Time,a.Report_Source_File_Name+'.'+isnull(a.File_Format,'') as [Input File Name],a.FTP_File_Format_Name as [Output File Name],a.Source_Application,a.Frequency,a.Manual_FTP,b.IsProcessed,b.AutomationStartTime,b.AutomationEndTime,a.FTP_Status,b.remarks,b.AutomationStatus,Convert(nvarchar(15),b.[Recon_date],103) as [Recon Date],'1' as is_holiday_logic from arc_scope_baseline a,ARC_Scope_Baseline_Logic b where a.Country_id=b.Country_id and a.product_id=b.product_id and a.Recon_Id=b.Recon_Id and a.Country_Name=b.Country_Name and a.Report_Source_File_Name=b.Report_Source_File_Name and isnull(a.FTP_File_Format_Name,'')=isnull(b.FTP_File_Format_Name,'')   " + strCountry + " " + strProduct + " " + strApplication + " ";
                strSelectQuery = strSelectQuery + "  and a.recon in(select recon_name from arc_Recon_master where Is_Active=1 and isnull(is_holiday_logic,'0')=1) order by Team,Country_name,Recon";//,Report_Source_File_Name";
                

                DataTable dt = das.Select_Table(strSelectQuery, hat, "text");

                int c = 1;
                for (int idx = 0; idx < dt.Rows.Count; idx++)
                {
                    dt.Rows[idx][0] = c;
                    c++;
                }
                dt.Columns.Add("Download Status");

                int FilesCount = 0;
                int FilesCompleted = 0;
                if (dt.Columns.Contains("Download Status"))
                {
                    for (int indx = 0; indx < dt.Rows.Count; indx++)
                    {
                        FilesCount++;

                        // DateTime d = Convert.ToDateTime(dt.Rows[indx][4]);
                        //DateTime d1 = Convert.ToDateTime(date);

                        ///Prakash Changed
                        //if (dt.Rows[indx]["is_holiday_logic"].ToString().Equals("0"))
                        //{
                        //    DataTable dtHoliday = Get_Recon_Date(Convert.ToString(dt.Rows[indx]["Country_name"]), "yyyy-MM-dd");
                        //    ////var holiday = dtHoliday.AsEnumerable().Where(x => x.Field<DateTime>("date") == DateTime.Today).Any();
                        //    //if (dtHoliday.Rows.Count > 0)
                        //    //{
                        //    //var holiday = from m in dtHoliday.AsEnumerable()
                        //    //              where m.Field<string>("date") == DateTime.Today.ToString("MM/dd/yyyy")
                        //    //              select m.Field<string>("date").FirstOrDefault();
                        //    //var holiday1 = dtHoliday.AsEnumerable()
                        //    //      .Where(x => Convert.ToDateTime(x.Field<DateTime>("date")) == DateTime.Today)
                        //    //      .Select(x => x.Field<string>("date")).Any();
                        //    //if (holiday1)
                        //    //{
                        //    //    dt.Rows[indx]["Download Status"] = "Holiday";
                        //    //}

                        //    foreach (DataRow drHol in dtHoliday.Rows)
                        //    {
                        //        DateTime dateHol;
                        //        bool IsValidDate;
                        //        IsValidDate = DateTime.TryParse(Convert.ToString(drHol["date"]), out dateHol);

                        //        if (IsValidDate && dateHol == DateTime.Today)
                        //        {
                        //            dt.Rows[indx]["Download Status"] = "Holiday";
                        //            break;
                        //        }
                        //        else
                        //        {
                        //            dt.Rows[indx]["Download Status"] = "Yet To Start";
                        //        }
                        //    }

                        //    // }
                        //}

                        //else 
                        ///Prakash Changed
                        ///

                        if (dt.Rows[indx]["is_holiday_logic"].ToString().Equals("0"))
                        {
                            //var drView = dtHolidayRecords.AsEnumerable()
                            //    .Where(x => x.Field<string>("Country_Name") == Convert.ToString(dt.Rows[indx]["Country_Name"]) && x.Field<DateTime>("Holiday_Date") == DateTime.Today)
                            //        .Select(y => y).Any();

                            DataRow[] dr = dtHolidayRecords.Select("Country_Name ='" + Convert.ToString(dt.Rows[indx]["Country_Name"]) + "' and Holiday_Date = '" + DateTime.Today + "'");

                            //string countryName = (from m in dtHolidayRecords.AsEnumerable()
                            //                            where m.Field<string>("Country_Name") == Convert.ToString(dt.Rows[indx]["Country_Name"])
                            //                            //&& m.Field<DateTime>("Holiday_Date") == DateTime.Today
                            //                            select m.Field<string>("Country_Name")).ToList().FirstOrDefault();

                            if (dr.Count() > 0)
                            // if(!string.IsNullOrEmpty(countryName))
                            {
                                dt.Rows[indx]["Download Status"] = "Holiday";

                            }
                            else
                            {
                                dt.Rows[indx]["Download Status"] = "Yet To Start";
                            }


                        }

                        else if (Convert.ToBoolean(dt.Rows[indx]["IsProcessed"]) == true && (dt.Rows[indx]["AutomationStatus"].ToString().ToLower() == "completed"))
                        {
                            dt.Rows[indx]["Download Status"] = "Completed";
                            FilesCompleted++;
                        }
                        else if (string.IsNullOrEmpty(dt.Rows[indx]["AutomationStartTime"].ToString()) && string.IsNullOrEmpty(dt.Rows[indx]["AutomationEndTime"].ToString()))
                        {
                            dt.Rows[indx]["Download Status"] = "Yet To Start";
                        }
                        else if (!string.IsNullOrEmpty(dt.Rows[indx]["AutomationStartTime"].ToString()) && string.IsNullOrEmpty(dt.Rows[indx]["AutomationEndTime"].ToString()))
                        {
                            dt.Rows[indx]["Download Status"] = "In Progress";
                        }
                        else if (!string.IsNullOrEmpty(dt.Rows[indx]["AutomationStartTime"].ToString()) && Convert.ToBoolean(dt.Rows[indx]["IsProcessed"]) == true)
                        {
                            dt.Rows[indx]["Download Status"] = "Completed";
                            FilesCompleted++;
                        }
                        else if (!string.IsNullOrEmpty(dt.Rows[indx]["AutomationStartTime"].ToString()) && !string.IsNullOrEmpty(dt.Rows[indx]["AutomationEndTime"].ToString()) && Convert.ToBoolean(dt.Rows[indx]["IsProcessed"]) == false)
                        {
                            dt.Rows[indx]["Download Status"] = "Error";
                        }
                        else
                        {
                            dt.Rows[indx]["Download Status"] = "Yet To Start";
                        }
                    }
                }
                dt.Columns.Add("FTP Status");
                //string strSelectQuery1 = "select ftp_Status from arc_Scope_baseline order by Team,Country_name,Recon";
                int FilesCount1 = 0;
                int FilesCompleted1 = 0;
                if (dt.Columns.Contains("FTP Status"))
                {
                    for (int indx = 0; indx < dt.Rows.Count; indx++)
                    {
                        FilesCount1++;

                        if (dt.Rows[indx]["is_holiday_logic"].ToString().Equals("0"))
                        {
                            if ((dt.Rows[indx]["FTP_Status"].ToString() == "UPLOADED") || (dt.Rows[indx]["FTP_Status"].ToString() == "FILE ALREADY UPLOADED"))
                            {
                                dt.Rows[indx]["FTP Status"] = "UPLOADED";
                                FilesCompleted1++;
                            }
                        }
                        else if (dt.Rows[indx]["is_holiday_logic"].ToString().Equals("1"))
                        {
                            if ((dt.Rows[indx]["FTP_Status"].ToString() == "UPLOADED") || (dt.Rows[indx]["FTP_Status"].ToString() == "FILE ALREADY UPLOADED"))
                            {
                                dt.Rows[indx]["FTP Status"] = "UPLOADED";
                                FilesCompleted1++;
                            }
                        }
                     
                    }
                }

                dt.Columns.Remove("AutomationStartTime");
                dt.Columns.Remove("AutomationEndTime");
                dt.Columns.Remove("IsProcessed");
                dt.Columns.Remove("FTP_Status");
                dt.Columns.Remove("Remarks");
                dt.Columns.Remove("AutomationStatus");

                dt.Columns.Remove("is_holiday_logic");

                DGV_Data.DataSource = dt;
                foreach (DataGridViewColumn dc in DGV_Data.Columns)
                {
                    // dc.SortMode = DataGridViewColumnSortMode.NotSortable;
                    if (dc.HeaderText == "Select")
                    {
                        dc.ReadOnly = false;
                    }
                    else
                    {
                        dc.ReadOnly = true;
                    }
                }
                //Download Status - Color variant
                foreach (DataGridViewRow row in DGV_Data.Rows)
                {
                    foreach (DataGridViewColumn col in DGV_Data.Columns)
                    {
                        if (DGV_Data["Download Status", row.Index].Value.ToString().ToLower() == "yet to start")
                        {
                            DGV_Data["Download Status", row.Index].Style.BackColor = Color.SkyBlue;
                        }

                        if (DGV_Data["Download Status", row.Index].Value.ToString().ToLower() == "in progress")
                        {
                            DGV_Data["Download Status", row.Index].Style.BackColor = Color.Orange;
                        }

                        if (DGV_Data["Download Status", row.Index].Value.ToString().ToLower() == "completed")
                        {
                            DGV_Data["Download Status", row.Index].Style.BackColor = Color.LimeGreen;
                        }

                        if (DGV_Data["Download Status", row.Index].Value.ToString().ToLower() == "error")
                        {
                            DGV_Data["Download Status", row.Index].Style.BackColor = Color.Firebrick;
                        }
                    }
                }

                // con.Close();
                //Total_count();
                _selectedTab = this.tabControl1.SelectedTab.Text;
                if (_selectedTab == "File")
                {
                    lbl_com_cnt.Visible = false;
                    lbl_cnt.Visible = false;
                    lbl_pen_cnt.Visible = false;
                    lbl_rec.Visible = false;
                    lbl_com.Visible = false;
                    lbl_pen.Visible = false;
                    lbl_Files.Visible = true;
                    lbl_FlsCMP.Visible = true;
                    lbl_FlsPND.Visible = true;
                    lbl_FilcntVw.Visible = true;
                    lbl_FlsCMPVW.Visible = true;
                    lbl_FlsPNDVW.Visible = true;
                    lbl_FilcntVw.Text = FilesCount.ToString();
                    lbl_FlsCMPVW.Text = FilesCompleted.ToString();
                    lbl_FlsPNDVW.Text = (FilesCount - FilesCompleted).ToString();
                }
            }
            catch
            {
            }
            finally
            {

            }

        }

        public void Recon_ViewRecord()
        {
            date = DateTime.Now.ToString("HH:MM");
            try
            {
                //SqlConnection con = new SqlConnection(conString);
                //con.Open();
                //cmd = new SqlCommand("ARC_SP_TotalProcessedReconCount", con);
                //cmd.CommandType = CommandType.StoredProcedure;
                //cmd.Parameters.AddWithValue("@Action", "All");
                //da = new SqlDataAdapter(cmd);
                //// DataTable dt1 = new DataTable();
                //da.Fill(dt);

                //Modified by 1554580 27 Sep 2017
                dt = new DataTable();
                Hashtable hat = new Hashtable();
                i = cmb_cntry.SelectedIndex;
                j = cmb_Prdt.SelectedIndex;
                selectedcountry = this.cmb_cntry.GetItemText(this.cmb_cntry.SelectedItem);
                selectedProduct = this.cmb_Prdt.GetItemText(this.cmb_Prdt.SelectedItem);

                string strProduct = "";
                string strCountry = "";
                if (i > 0)
                {
                    strCountry = " and Country='" + selectedcountry + "'";
                }
                if (j > 0)
                {
                    strProduct = " and Team='" + selectedProduct + "'";
                }
                string strquery = "select Recon_ID as [S No],Team,Country,Recon_Name,Total_Files,CONVERT(varchar(5),convert(TIME, convert(DATETIME, SLA_Time, 120)))as SLA_Time, CONVERT(varchar(5),convert(TIME, convert(DATETIME, Receipt_Time, 120)))as Receipt_Time,Is_Recon_Completed, AutomationStartTime, AutomationEndTime,Convert(Nvarchar(50),'NA') Recon_date  from dbo.ARC_Recon_Master where Is_Active=1 " + strCountry + " " + strProduct + "";
                //strquery = strquery + "  and recon_name not in('MXG - sabre','Kenya - VISA Electron ATM Suspense AC recon and outstanding Report','Singapore - Prepaid','Bony and Clearstream','VIETNAM VND OPEN ITEMS (CITAD)','JAPAN - Account Balance report Nostro','Hong Kong - BOCI','VN Stock Reconciliation Report','Indonesia -TRADE & LPU RECON','BRUNEI - BCC Borrowing','Indonesia OCC','India sundry and suspense, ebbs and IDBI report','Visa Base II – Trial Balance Preparation – TOTAL','Mobile Recharge Transaction - Reconciliation-Total','Indonesia - STS Report','Issuer - EBBS Internal Account Reconciliation ATM','CLS-MLS Recon','India - Phantom Nostro','OWN Recon','SUSPENSE OPEN ITEMS(CUP)','Nepal - ATM CUP INTERNATIONAL Recon','Nepal -Retail Banking ATM CARD RECON','Thailand  CMS 4121(STS) SNS (Manual)','Nepal SOM Nostro','FED Reserve MOC')";
                strquery = strquery + "  and isnull(is_holiday_logic,'0')=0 ";
                strquery = strquery + "  union select Recon_ID as [S No],Team,Country,Recon_Name,Total_Files,CONVERT(varchar(5),convert(TIME, convert(DATETIME, SLA_Time, 120)))as SLA_Time, CONVERT(varchar(5),convert(TIME, convert(DATETIME, Receipt_Time, 120)))as Receipt_Time,Is_Recon_Completed, AutomationStartTime, AutomationEndTime,Convert(nvarchar(15),Recon_date,103) Recon_Date  from ARC_Recon_Master_Holiday_date_Logic where Is_Active=1 " + strCountry + " " + strProduct + "";
                strquery = strquery + "  and recon_name in(select recon_name from arc_Recon_master where Is_Active=1 and isnull(is_holiday_logic,'0')=1) order by Team,Country,Recon_name,recon_date";
                dt = das.Select_Table(strquery, hat, "text");

                //dt.Columns.Add("Time To SLA");
                dt.Columns.Add("Output Status");
                dt.Columns.Add("TLM FTP Status");

                int c = 1;
                for (int idx = 0; idx < dt.Rows.Count; idx++)
                {
                    dt.Rows[idx][0] = c;
                    c++;
                }

                int ReconCount = 0;
                int ReconCompleted = 0;
                if (dt.Columns.Contains("Output Status"))
                {
                    for (int indx = 0; indx < dt.Rows.Count; indx++)
                    {
                        ReconCount++;
                        string sd1 = dt.Rows[indx][4].ToString();
                        string sd2 = date.ToString();
                        DateTime d = Convert.ToDateTime(dt.Rows[indx][5]);
                        DateTime d1 = Convert.ToDateTime(date);
                        sla = (d - d1).ToString();
                        //if (Convert.ToBoolean(dt.Rows[indx][7]) == true && d.TimeOfDay < d1.TimeOfDay)
                        //{
                        //    dt.Rows[indx][8] = "0.00";
                        //    //dt.Rows[indx][9] = imageToByteArray(i1);
                        //}
                        //else if (Convert.ToBoolean(dt.Rows[indx][7]) == false && d.TimeOfDay > d1.TimeOfDay)
                        //{
                        //    dt.Rows[indx][8] = sla;
                        //    //dt.Rows[indx][9] = imageToByteArray(i3);
                        //}
                        //else if (Convert.ToBoolean(dt.Rows[indx][7]) == false && d.TimeOfDay < d1.TimeOfDay)
                        //{
                        //    dt.Rows[indx][8] = sla;
                        //    //dt.Rows[indx][9] = imageToByteArray(i2);
                        //}
                        //else if (Convert.ToBoolean(dt.Rows[indx][7]) == true && d.TimeOfDay > d1.TimeOfDay)
                        //{
                        //    dt.Rows[indx][8] = "0.00";
                        //    //dt.Rows[indx][9] = imageToByteArray(i1);
                        //}


                        if (string.IsNullOrEmpty(dt.Rows[indx]["AutomationStartTime"].ToString()) && string.IsNullOrEmpty(dt.Rows[indx]["AutomationEndTime"].ToString()))
                        {
                            dt.Rows[indx]["Output Status"] = "Yet To Start";
                        }
                        else if (!string.IsNullOrEmpty(dt.Rows[indx]["AutomationStartTime"].ToString()) && string.IsNullOrEmpty(dt.Rows[indx]["AutomationEndTime"].ToString()))
                        {
                            dt.Rows[indx]["Output Status"] = "In Progress";
                        }
                        else if (!string.IsNullOrEmpty(dt.Rows[indx]["AutomationStartTime"].ToString()) && Convert.ToBoolean(dt.Rows[indx]["Is_Recon_Completed"]) == true)
                        {
                            dt.Rows[indx]["Output Status"] = "Completed";
                            ReconCompleted++;
                        }
                        else if (!string.IsNullOrEmpty(dt.Rows[indx]["AutomationStartTime"].ToString()) && !string.IsNullOrEmpty(dt.Rows[indx]["AutomationEndTime"].ToString()) && Convert.ToBoolean(dt.Rows[indx]["Is_Recon_Completed"]) == false)
                        {
                            dt.Rows[indx]["Output Status"] = "Error";
                        }
                        else
                        {
                            dt.Rows[indx]["Output Status"] = "Yet To Start";
                        }
                    }
                }

                dt.Columns.Remove("AutomationStartTime");
                dt.Columns.Remove("AutomationEndTime");
                dt.Columns.Remove("Is_Recon_Completed");


                dataGridView1.DataSource = dt;


                ///Select Checkbox disabled - Prakash
                dataGridView1.Columns[0].Visible = false;

                //dataGridView1.Columns["dataGridViewCheckBoxColumn1"].DisplayIndex = dataGridView1.Columns.Count - 1;

                //foreach (DataGridViewColumn dc in dataGridView1.Columns)
                //{
                //    dc.SortMode = DataGridViewColumnSortMode.NotSortable;
                //    if (dc.HeaderText == "Select")
                //    {
                //        dc.ReadOnly = false;
                //    }
                //    else
                //    {
                //        dc.ReadOnly = true;
                //    }
                //}

                //Download Status - Color variant
                foreach (DataGridViewRow row in dataGridView1.Rows)
                {
                    foreach (DataGridViewColumn col in dataGridView1.Columns)
                    {
                        if (dataGridView1["Output Status", row.Index].Value == "Yet To Start")
                        {
                            dataGridView1["Output Status", row.Index].Style.BackColor = Color.SkyBlue;
                        }

                        if (dataGridView1["Output Status", row.Index].Value == "In Progress")
                        {
                            dataGridView1["Output Status", row.Index].Style.BackColor = Color.Orange;
                        }

                        if (dataGridView1["Output Status", row.Index].Value == "Completed")
                        {
                            dataGridView1["Output Status", row.Index].Style.BackColor = Color.LimeGreen;
                        }

                        if (dataGridView1["Output Status", row.Index].Value == "Error")
                        {
                            dataGridView1["Output Status", row.Index].Style.BackColor = Color.Firebrick;
                        }
                    }
                }

                //con.Close();
                //Total_count(); lbl_com_cnt.Visible = true;
                _selectedTab = this.tabControl1.SelectedTab.Text;

                if (_selectedTab != "File")
                {
                    lbl_cnt.Visible = true;
                    lbl_pen_cnt.Visible = true;
                    lbl_com_cnt.Visible = true;
                    lbl_rec.Visible = true;
                    lbl_com.Visible = true;
                    lbl_pen.Visible = true;
                    lbl_Files.Visible = false;
                    lbl_FlsCMP.Visible = false;
                    lbl_FlsPND.Visible = false;
                    lbl_FilcntVw.Visible = false;
                    lbl_FlsCMPVW.Visible = false;
                    lbl_FlsPNDVW.Visible = false;
                    lbl_cnt.Text = ReconCount.ToString();
                    string Recon_comple = ReconCompleted.ToString();
                    if (Recon_comple == "0")
                    {
                        lbl_com_cnt.Text = "0";
                    }
                    else
                    {
                        lbl_com_cnt.Text = ReconCompleted.ToString();
                    }


                    lbl_pen_cnt.Text = (ReconCount - ReconCompleted).ToString();
                }

            }
            catch
            {

            }
        }
        //For Recon Files
        public void File_ViewRecons()
        {
            try
            {
                date = DateTime.Now.ToString("hh:mm");
                Hashtable hat = new Hashtable();
                i = cmb_Recon.SelectedIndex;
                selectedRecon = this.cmb_Recon.GetItemText(this.cmb_Recon.SelectedItem);


                string strRecon = "";
                if (i > 0)
                {
                    strRecon = " and a.Recon='" + selectedRecon + "'";
                }

                string strSelectQuery = "Select row_Number () over(order by Team,Country_name,Recon,Report_Source_File_Name) [S No],Team,Country_Name,Recon,CONVERT(VARCHAR(8), SLA_Time, 108) as SLA_Time,CONVERT(VARCHAR(8), Receipt_Time, 108) as Receipt_Time,Report_Source_File_Name+'.'+isnull(File_Format,'') as [Input File Name],FTP_File_Format_Name as [Output File Name],Source_Application,Frequency,Manual_FTP,IsProcessed,AutomationStartTime,AutomationEndTime,AutomationStatus,Convert(nvarchar(15),'NA') as [Recon date],'0' as is_holiday_logic FROM ARC_Scope_BaseLine a where In_Scope_For_ARC='yes' " + strRecon + "";
                strSelectQuery = strSelectQuery + " and recon in(select recon_name from arc_Recon_master where Is_Active=1 and isnull(is_holiday_logic,'0')=0  )";
                strSelectQuery = strSelectQuery + " union select row_Number () over(order by a.Team,a.Country_name,a.Recon,a.Report_Source_File_Name)[S No],a.Team,a.Country_Name,a.Recon,CONVERT(VARCHAR(8), a.SLA_Time, 108) as SLA_Time,CONVERT(VARCHAR(8), a.Receipt_Time, 108) as Receipt_Time,a.Report_Source_File_Name+'.'+isnull(a.File_Format,'') as [Input File Name],a.FTP_File_Format_Name as [Output File Name],a.Source_Application,a.Frequency,a.Manual_FTP,b.IsProcessed,b.AutomationStartTime,b.AutomationEndTime,b.AutomationStatus,Convert(nvarchar(15),b.[Recon_date],103) as [Recon Date],'1' as is_holiday_logic from arc_scope_baseline a,ARC_Scope_Baseline_Logic b where a.Country_id=b.Country_id and a.product_id=b.product_id and a.Recon_Id=b.Recon_Id and a.Country_Name=b.Country_Name and a.Report_Source_File_Name=b.Report_Source_File_Name and isnull(a.FTP_File_Format_Name,'')=isnull(b.FTP_File_Format_Name,'')   " + strRecon + "";
                strSelectQuery = strSelectQuery + "  and a.recon in(select recon_name from arc_Recon_master where Is_Active=1 and isnull(is_holiday_logic,'0')=1) order by Team,Country_name,Recon";//,Report_Source_File_Name";
                DataTable dt = das.Select_Table(strSelectQuery, hat, "text");

                int c = 1;
                for (int idx = 0; idx < dt.Rows.Count; idx++)
                {
                    dt.Rows[idx][0] = c;
                    c++;
                }
                dt.Columns.Add("Download Status");

                int FilesCount = 0;
                int FilesCompleted = 0;
                if (dt.Columns.Contains("Download Status"))
                {
                    for (int indx = 0; indx < dt.Rows.Count; indx++)
                    {
                        FilesCount++;

                        // DateTime d = Convert.ToDateTime(dt.Rows[indx][4]);
                        //DateTime d1 = Convert.ToDateTime(date);
                        if (dt.Rows[indx]["is_holiday_logic"].ToString().Equals("0"))
                        {
                            //var drView = dtHolidayRecords.AsEnumerable()
                            //    .Where(x => x.Field<string>("Country_Name") == Convert.ToString(dt.Rows[indx]["Country_Name"]) && x.Field<DateTime>("Holiday_Date") == DateTime.Today)
                            //        .Select(y => y).FirstOrDefault().Any();

                            //List<string> countryName = (from m in dtHolidayRecords.AsEnumerable()
                            //                            where m.Field<string>("Country_Name") == Convert.ToString(dt.Rows[indx]["Country_Name"]) &&
                            //                            m.Field<DateTime>("Holiday_Date") == DateTime.Today
                            //                            select m.Field<string>("Country_Name")).ToList();

                            DataRow[] dr = dtHolidayRecords.Select("Country_Name ='" + Convert.ToString(dt.Rows[indx]["Country_Name"]) + "' and Holiday_Date = '" + DateTime.Today + "'");

                            if (dr.Count() > 0)
                            // if (countryName.Any())
                            {
                                dt.Rows[indx]["Download Status"] = "Holiday";

                            }
                            else
                            {
                                dt.Rows[indx]["Download Status"] = "Yet To Start";
                            }


                        }
                        else if (Convert.ToBoolean(dt.Rows[indx]["IsProcessed"]) == true && (dt.Rows[indx]["AutomationStatus"].ToString().ToLower() == "completed"))
                        {
                            dt.Rows[indx]["Download Status"] = "Completed";
                            FilesCompleted++;
                        }
                        else if (string.IsNullOrEmpty(dt.Rows[indx]["AutomationStartTime"].ToString()) && string.IsNullOrEmpty(dt.Rows[indx]["AutomationEndTime"].ToString()))
                        {
                            dt.Rows[indx]["Download Status"] = "Yet To Start";
                        }
                        else if (!string.IsNullOrEmpty(dt.Rows[indx]["AutomationStartTime"].ToString()) && string.IsNullOrEmpty(dt.Rows[indx]["AutomationEndTime"].ToString()))
                        {
                            dt.Rows[indx]["Download Status"] = "In Progress";
                        }
                        else if (!string.IsNullOrEmpty(dt.Rows[indx]["AutomationStartTime"].ToString()) && Convert.ToBoolean(dt.Rows[indx]["IsProcessed"]) == true)
                        {
                            dt.Rows[indx]["Download Status"] = "Completed";
                            FilesCompleted++;
                        }
                        else if (!string.IsNullOrEmpty(dt.Rows[indx]["AutomationStartTime"].ToString()) && !string.IsNullOrEmpty(dt.Rows[indx]["AutomationEndTime"].ToString()) && Convert.ToBoolean(dt.Rows[indx]["IsProcessed"]) == false)
                        {
                            dt.Rows[indx]["Download Status"] = "Error";
                        }
                        else
                        {
                            dt.Rows[indx]["Download Status"] = "Yet To Start";
                        }
                    }
                }


                dt.Columns.Remove("AutomationStartTime");
                dt.Columns.Remove("AutomationEndTime");
                dt.Columns.Remove("IsProcessed");
                dt.Columns.Remove("AutomationStatus");
                dt.Columns.Remove("is_holiday_logic");



                DGV_Data.DataSource = dt;
                //DGV_Data.Columns[0].Visible = false;
                // Added by 1554580 07 Sep 2017
                //DGV_Data.Width = 1120;
                //DGV_Data.Height = 420;
                foreach (DataGridViewColumn dc in DGV_Data.Columns)
                {
                    // dc.SortMode = DataGridViewColumnSortMode.NotSortable;
                    if (dc.HeaderText == "Select")
                    {
                        dc.ReadOnly = false;
                    }
                    else
                    {
                        dc.ReadOnly = true;
                    }
                }
                //Download Status - Color variant
                foreach (DataGridViewRow row in DGV_Data.Rows)
                {
                    foreach (DataGridViewColumn col in DGV_Data.Columns)
                    {
                        if (DGV_Data["Download Status", row.Index].Value.ToString().ToLower() == "yet to start")
                        {
                            DGV_Data["Download Status", row.Index].Style.BackColor = Color.SkyBlue;
                        }

                        if (DGV_Data["Download Status", row.Index].Value.ToString().ToLower() == "in progress")
                        {
                            DGV_Data["Download Status", row.Index].Style.BackColor = Color.Orange;
                        }

                        if (DGV_Data["Download Status", row.Index].Value.ToString().ToLower() == "completed")
                        {
                            DGV_Data["Download Status", row.Index].Style.BackColor = Color.LimeGreen;
                        }

                        if (DGV_Data["Download Status", row.Index].Value.ToString().ToLower() == "error")
                        {
                            DGV_Data["Download Status", row.Index].Style.BackColor = Color.Firebrick;
                        }
                    }
                }

                // con.Close();
                //Total_count();
                _selectedTab = this.tabControl1.SelectedTab.Text;
                if (_selectedTab == "File")
                {
                    lbl_com_cnt.Visible = false;
                    lbl_cnt.Visible = false;
                    lbl_pen_cnt.Visible = false;
                    lbl_rec.Visible = false;
                    lbl_com.Visible = false;
                    lbl_pen.Visible = false;
                    lbl_Files.Visible = true;
                    lbl_FlsCMP.Visible = true;
                    lbl_FlsPND.Visible = true;
                    lbl_FilcntVw.Visible = true;
                    lbl_FlsCMPVW.Visible = true;
                    lbl_FlsPNDVW.Visible = true;
                    lbl_FilcntVw.Text = FilesCount.ToString();
                    lbl_FlsCMPVW.Text = FilesCompleted.ToString();
                    lbl_FlsPNDVW.Text = (FilesCount - FilesCompleted).ToString();
                }
            }
            catch
            {
            }
        }
        public void Recon_ViewRecons()
        {
            date = DateTime.Now.ToString("HH:MM");
            try
            {
                dt = new DataTable();
                Hashtable hat = new Hashtable();
                i = cmb_Recon.SelectedIndex;

                selectedRecon = this.cmb_Recon.GetItemText(this.cmb_Recon.SelectedItem);


                string strRecon = "";
                if (i > 0)
                {
                    strRecon = " and recon_name='" + selectedRecon + "'";
                }

                string strquery = "select Recon_ID as [S No],Team,Country,Recon_Name,Total_Files,CONVERT(varchar(5),convert(TIME, convert(DATETIME, SLA_Time, 120)))as SLA_Time, CONVERT(varchar(5),convert(TIME, convert(DATETIME, Receipt_Time, 120)))as Receipt_Time,Is_Recon_Completed, AutomationStartTime, AutomationEndTime,Convert(Nvarchar(50),'NA') Recon_date  from dbo.ARC_Recon_Master where Is_Active=1 " + strRecon + "";
                strquery = strquery + "  and isnull(is_holiday_logic,'0')=0 ";
                strquery = strquery + "  union select Recon_ID as [S No],Team,Country,Recon_Name,Total_Files,CONVERT(varchar(5),convert(TIME, convert(DATETIME, SLA_Time, 120)))as SLA_Time, CONVERT(varchar(5),convert(TIME, convert(DATETIME, Receipt_Time, 120)))as Receipt_Time,Is_Recon_Completed, AutomationStartTime, AutomationEndTime,Convert(nvarchar(15),Recon_date,103) Recon_Date  from ARC_Recon_Master_Holiday_date_Logic where Is_Active=1 " + strRecon + "";
                strquery = strquery + "  and recon_name in(select recon_name from arc_Recon_master where Is_Active=1 and isnull(is_holiday_logic,'0')=1) order by Team,Country,Recon_name,recon_date";
                dt = das.Select_Table(strquery, hat, "text");

                //dt.Columns.Add("Time To SLA");
                dt.Columns.Add("Output Status");
                dt.Columns.Add("TLM FTP Status");
                int c = 1;
                for (int idx = 0; idx < dt.Rows.Count; idx++)
                {
                    dt.Rows[idx][0] = c;
                    c++;
                }

                int ReconCount = 0;
                int ReconCompleted = 0;
                if (dt.Columns.Contains("Output Status"))
                {
                    for (int indx = 0; indx < dt.Rows.Count; indx++)
                    {
                        ReconCount++;
                        string sd1 = dt.Rows[indx][4].ToString();
                        string sd2 = date.ToString();
                        DateTime d = Convert.ToDateTime(dt.Rows[indx][5]);
                        DateTime d1 = Convert.ToDateTime(date);
                        sla = (d - d1).ToString();
                        //if (Convert.ToBoolean(dt.Rows[indx][7]) == true && d.TimeOfDay < d1.TimeOfDay)
                        //{
                        //    dt.Rows[indx][8] = "0.00";
                        //    //dt.Rows[indx][9] = imageToByteArray(i1);
                        //}
                        //else if (Convert.ToBoolean(dt.Rows[indx][7]) == false && d.TimeOfDay > d1.TimeOfDay)
                        //{
                        //    dt.Rows[indx][8] = sla;
                        //    //dt.Rows[indx][9] = imageToByteArray(i3);
                        //}
                        //else if (Convert.ToBoolean(dt.Rows[indx][7]) == false && d.TimeOfDay < d1.TimeOfDay)
                        //{
                        //    dt.Rows[indx][8] = sla;
                        //    //dt.Rows[indx][9] = imageToByteArray(i2);
                        //}
                        //else if (Convert.ToBoolean(dt.Rows[indx][7]) == true && d.TimeOfDay > d1.TimeOfDay)
                        //{
                        //    dt.Rows[indx][8] = "0.00";
                        //    //dt.Rows[indx][9] = imageToByteArray(i1);
                        //}


                        if (string.IsNullOrEmpty(dt.Rows[indx]["AutomationStartTime"].ToString()) && string.IsNullOrEmpty(dt.Rows[indx]["AutomationEndTime"].ToString()))
                        {
                            dt.Rows[indx]["Output Status"] = "Yet To Start";
                        }
                        else if (!string.IsNullOrEmpty(dt.Rows[indx]["AutomationStartTime"].ToString()) && string.IsNullOrEmpty(dt.Rows[indx]["AutomationEndTime"].ToString()))
                        {
                            dt.Rows[indx]["Output Status"] = "In Progress";
                        }
                        else if (!string.IsNullOrEmpty(dt.Rows[indx]["AutomationStartTime"].ToString()) && Convert.ToBoolean(dt.Rows[indx]["Is_Recon_Completed"]) == true)
                        {
                            dt.Rows[indx]["Output Status"] = "Completed";
                            ReconCompleted++;
                        }
                        else if (!string.IsNullOrEmpty(dt.Rows[indx]["AutomationStartTime"].ToString()) && !string.IsNullOrEmpty(dt.Rows[indx]["AutomationEndTime"].ToString()) && Convert.ToBoolean(dt.Rows[indx]["Is_Recon_Completed"]) == false)
                        {
                            dt.Rows[indx]["Output Status"] = "Error";
                        }
                        else
                        {
                            dt.Rows[indx]["Output Status"] = "Yet To Start";
                        }
                    }
                }

                dt.Columns.Remove("AutomationStartTime");
                dt.Columns.Remove("AutomationEndTime");
                dt.Columns.Remove("Is_Recon_Completed");


                dataGridView1.DataSource = dt;


                ///Select Checkbox disabled - Prakash
                dataGridView1.Columns[0].Visible = false;

                //dataGridView1.Columns["dataGridViewCheckBoxColumn1"].DisplayIndex = dataGridView1.Columns.Count - 1;

                //foreach (DataGridViewColumn dc in dataGridView1.Columns)
                //{
                //    dc.SortMode = DataGridViewColumnSortMode.NotSortable;
                //    if (dc.HeaderText == "Select")
                //    {
                //        dc.ReadOnly = false;
                //    }
                //    else
                //    {
                //        dc.ReadOnly = true;
                //    }
                //}

                //Download Status - Color variant
                foreach (DataGridViewRow row in dataGridView1.Rows)
                {
                    foreach (DataGridViewColumn col in dataGridView1.Columns)
                    {
                        if (dataGridView1["Output Status", row.Index].Value == "Yet To Start")
                        {
                            dataGridView1["Output Status", row.Index].Style.BackColor = Color.SkyBlue;
                        }

                        if (dataGridView1["Output Status", row.Index].Value == "In Progress")
                        {
                            dataGridView1["Output Status", row.Index].Style.BackColor = Color.Orange;
                        }

                        if (dataGridView1["Output Status", row.Index].Value == "Completed")
                        {
                            dataGridView1["Output Status", row.Index].Style.BackColor = Color.LimeGreen;
                        }

                        if (dataGridView1["Output Status", row.Index].Value == "Error")
                        {
                            dataGridView1["Output Status", row.Index].Style.BackColor = Color.Firebrick;
                        }
                    }
                }

                _selectedTab = this.tabControl1.SelectedTab.Text;

                if (_selectedTab != "File")
                {
                    lbl_cnt.Visible = true;
                    lbl_pen_cnt.Visible = true;
                    lbl_com_cnt.Visible = true;
                    lbl_rec.Visible = true;
                    lbl_com.Visible = true;
                    lbl_pen.Visible = true;
                    lbl_Files.Visible = false;
                    lbl_FlsCMP.Visible = false;
                    lbl_FlsPND.Visible = false;
                    lbl_FilcntVw.Visible = false;
                    lbl_FlsCMPVW.Visible = false;
                    lbl_FlsPNDVW.Visible = false;
                    lbl_cnt.Text = ReconCount.ToString();
                    lbl_com_cnt.Text = ReconCompleted.ToString();
                    lbl_pen_cnt.Text = (ReconCount - ReconCompleted).ToString();
                }
            }
            catch
            {

            }
        }
        //private void Btn_Srch_Click_1(object sender, EventArgs e)//Search Button
        //{
        //    selectedcountry = this.cmb_cntry.GetItemText(this.cmb_cntry.SelectedItem);
        //    selectedProduct = this.cmb_cntry.GetItemText(this.cmb_Prdt.SelectedItem);
        //    i = cmb_cntry.SelectedIndex;
        //    j = cmb_Prdt.SelectedIndex;
        //    string s = cmb_cntry.SelectedValue.ToString();
        //    string FileName = "";// txt_Fil.Text;
        //    try
        //    {
        //        SqlConnection con = new SqlConnection(conString);
        //        if (selectedcountry != "--SELECT LIST--" && selectedProduct != "--SELECT LIST--")
        //        {
        //            con.Open();
        //            SqlCommand cmd = new SqlCommand("ARC_SP_GetFeedsInformation", con);
        //            cmd.CommandType = CommandType.StoredProcedure;
        //            cmd.Parameters.AddWithValue("@Action", "PC");
        //            cmd.Parameters.AddWithValue("@Country_Id", i);
        //            cmd.Parameters.AddWithValue("@Product_ID", j);
        //            cmd.Parameters.AddWithValue("@File_Name", FileName);
        //            SqlDataAdapter da = new SqlDataAdapter(cmd);
        //            DataTable dt = new DataTable();
        //            da.Fill(dt);
        //            int c = 1;
        //            for (int idx = 0; idx < dt.Rows.Count; idx++)
        //            {
        //                dt.Rows[idx][0] = c;
        //                c++;
        //            }
        //            dt.Columns.Add("Actions", typeof(byte[]));
        //            if (dt.Columns.Contains("Actions"))
        //            {
        //                for (int indx = 0; indx < dt.Rows.Count; indx++)
        //                {
        //                    DateTime d = Convert.ToDateTime(dt.Rows[indx][3]);
        //                    DateTime d1 = Convert.ToDateTime(date);
        //                    if (Convert.ToBoolean(dt.Rows[indx][9]) == true && d.TimeOfDay < d1.TimeOfDay)
        //                    {
        //                        dt.Rows[indx][10] = obj.imageToByteArray(i1);
        //                    }
        //                    else if (Convert.ToBoolean(dt.Rows[indx][9]) == false && d.TimeOfDay > d1.TimeOfDay)
        //                    {
        //                        dt.Rows[indx][10] = obj.imageToByteArray(i3);
        //                    }
        //                    else if (Convert.ToBoolean(dt.Rows[indx][9]) == false && d.TimeOfDay < d1.TimeOfDay)
        //                    {
        //                        dt.Rows[indx][10] = obj.imageToByteArray(i2);
        //                    }
        //                    else if (Convert.ToBoolean(dt.Rows[indx][9]) == true && d.TimeOfDay > d1.TimeOfDay)
        //                    {
        //                        dt.Rows[indx][10] = obj.imageToByteArray(i1);
        //                    }
        //                }
        //            }
        //            DGV_Data.DataSource = dt;
        //            con.Close();
        //        }
        //        else
        //        {
        //            con.Open();
        //            SqlCommand cmd = new SqlCommand("Select Scope_Id as [S No],Team,Country_Name,Recon,CONVERT(VARCHAR(8), SLA_Time, 108) as SLA_Time,CONVERT(VARCHAR(8), Receipt_Time, 108) as Receipt_Time,Report_Source_File_Name as [Input File Name],FTP_File_Format_Name as [Output File Name],Source_Application,IsProcessed FROM ARC_Scope_BaseLine", con);
        //            SqlDataAdapter da = new SqlDataAdapter(cmd);
        //            dt = new DataTable();
        //            da.Fill(dt);
        //            dt.Columns.Add("Actions", typeof(byte[]));
        //            if (dt.Columns.Contains("Actions"))
        //            {
        //                for (int indx = 0; indx < dt.Rows.Count; indx++)
        //                {
        //                    DateTime d = Convert.ToDateTime(dt.Rows[indx][3]);
        //                    DateTime d1 = Convert.ToDateTime(date);
        //                    if (Convert.ToBoolean(dt.Rows[indx][9]) == true && d.TimeOfDay < d1.TimeOfDay)
        //                    {
        //                        dt.Rows[indx][10] = obj.imageToByteArray(i1);
        //                    }
        //                    else if (Convert.ToBoolean(dt.Rows[indx][9]) == false && d.TimeOfDay > d1.TimeOfDay)
        //                    {
        //                        dt.Rows[indx][10] = obj.imageToByteArray(i3);
        //                    }
        //                    else if (Convert.ToBoolean(dt.Rows[indx][9]) == false && d.TimeOfDay < d1.TimeOfDay)
        //                    {
        //                        dt.Rows[indx][10] = obj.imageToByteArray(i2);
        //                    }
        //                    else if (Convert.ToBoolean(dt.Rows[indx][9]) == true && d.TimeOfDay > d1.TimeOfDay)
        //                    {
        //                        dt.Rows[indx][10] = obj.imageToByteArray(i1);
        //                    }
        //                }
        //            }
        //            DGV_Data.DataSource = dt;
        //            con.Close();
        //        }
        //    }
        //    catch
        //    {
        //        MessageBox.Show("Please Select Country,Product and FileName......!");
        //    }
        //}

        //Product DropDown
        private void cmb_Prdt_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            cmb_Recon.SelectedIndexChanged -= new EventHandler(cmb_Recon_SelectedIndexChanged);
            cmb_Recon.SelectedIndex = 0;
            cmb_Recon.SelectedIndexChanged += new EventHandler(cmb_Recon_SelectedIndexChanged);

            File_ViewRecords();
            Recon_ViewRecord();
            cmb_Recon.SelectedIndex = 0;
            dataGridView2.Visible = false;
        }
        //Country DropDown
        private void cmb_cntry_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            //selectedRecon = this.cmb_Recon.GetItemText(this.cmb_Recon.SelectedItem);
            //if (selectedRecon != "")
            //{
            //  cmb_Recon.SelectedIndex = 0;
            //}
            cmb_Recon.SelectedIndexChanged -= new EventHandler(cmb_Recon_SelectedIndexChanged);
            cmb_Recon.SelectedIndex = 0;
            cmb_Recon.SelectedIndexChanged += new EventHandler(cmb_Recon_SelectedIndexChanged);

            Recon_ViewRecord();
            File_ViewRecords();
            dataGridView2.Visible = false;
        }
        //Application dropdown
        private void cmb_Application_SelectedIndexChanged(object sender, EventArgs e)
        {
            cmb_Recon.SelectedIndexChanged -= new EventHandler(cmb_Recon_SelectedIndexChanged);
            cmb_Recon.SelectedIndex = 0;
            cmb_Recon.SelectedIndexChanged += new EventHandler(cmb_Recon_SelectedIndexChanged);

            Recon_ViewRecord();
            File_ViewRecords();
            dataGridView2.Visible = false;
        }
        //Recon DropDown
        private void cmb_Recon_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectval = cmb_Recon.Text;
            SqlConnection con = new SqlConnection(conString);
            SqlCommand cmd = null;
            DataTable dt1 = new DataTable();
            cmd = new SqlCommand("select * from ARC_TLM_SETID where ReconName='" + selectval + "'", con);
            SqlDataAdapter da2 = new SqlDataAdapter(cmd);
            da2.Fill(dt1);
            dgv_TLM.DataSource = dt1;

            dgv_TLM.Columns[1].Visible = false;
            dgv_TLM.Columns[6].Visible = false;
            dgv_TLM.Columns[4].Visible = false;
            dgv_TLM.Columns[5].Visible = false;
            dgv_TLM.Columns[8].Visible = false;
            dgv_TLM.Columns[9].Visible = false;
            foreach (DataGridViewRow row in dgv_TLM.Rows)
            {
                if (Convert.ToString(row.Cells["Status"].Value) == "COMPLETED")
                {
                    dgv_TLM["Status", row.Index].Style.BackColor = Color.LimeGreen;
                }
                if (Convert.ToString(row.Cells["Status"].Value) == "Yet To Start" || Convert.ToString(row.Cells["Status"].Value) == "")
                {
                    dgv_TLM["Status", row.Index].Style.BackColor = Color.SkyBlue;
                    dgv_TLM["Status", row.Index].Value = "Yet To Start";
                    //dgv_TLM.Rows[row.Index]["Download Status"] = "Yet To Start";
                }
                if (Convert.ToString(row.Cells["Status"].Value) == "In Progress")
                {
                    dgv_TLM["Status", row.Index].Style.BackColor = Color.Yellow;
                }
                if (Convert.ToString(row.Cells["Status"].Value) == "Data Not Available")
                {
                    dgv_TLM["Status", row.Index].Style.BackColor = Color.Orange;
                }
                if (Convert.ToString(row.Cells["Status"].Value) == "Error")
                {
                    dgv_TLM["Status", row.Index].Style.BackColor = Color.Firebrick;
                }
            }
            cmb_Prdt.SelectedIndexChanged -= new EventHandler(cmb_Prdt_SelectedIndexChanged_1);
            cmb_Prdt.SelectedIndex = 0;
            cmb_Prdt.SelectedIndexChanged += new EventHandler(cmb_Prdt_SelectedIndexChanged_1);

            cmb_cntry.SelectedIndexChanged -= new EventHandler(cmb_cntry_SelectedIndexChanged_1);
            cmb_cntry.SelectedIndex = 0;
            cmb_cntry.SelectedIndexChanged += new EventHandler(cmb_cntry_SelectedIndexChanged_1);

            cmb_Application.SelectedIndexChanged -= new EventHandler(cmb_Application_SelectedIndexChanged);
            cmb_Application.SelectedIndex = 0;
            cmb_Application.SelectedIndexChanged += new EventHandler(cmb_Application_SelectedIndexChanged);

            File_ViewRecons();
            Recon_ViewRecons();
            dataGridView2.Visible = false;

        }
        private void Dashboard_FormClosed(object sender, FormClosedEventArgs e)
        {
            try
            {
                foreach (var p in System.Diagnostics.Process.GetProcessesByName("OpenSpan.Runtime"))
                {
                    p.Kill();
                }
                foreach (var p in System.Diagnostics.Process.GetProcessesByName("ARC_Application"))
                {
                    p.Kill();
                }
            }
            catch
            {

            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (DGV_Data.Rows.Count > 0)
                {
                    Microsoft.Office.Interop.Excel.Application XcelApp = new Microsoft.Office.Interop.Excel.Application();
                    Microsoft.Office.Interop.Excel.Workbook workbook = XcelApp.Workbooks.Add(Type.Missing);
                    Microsoft.Office.Interop.Excel.Worksheet worksheet = (Microsoft.Office.Interop.Excel.Worksheet)XcelApp.Sheets["Sheet1"];
                    XcelApp.DisplayAlerts = false;
                    XcelApp.Visible = false;
                    worksheet.Name = "ExportedFromDatGrid";
                    int counter = 1;
                    for (int i = 1; i < DGV_Data.Columns.Count; i++)
                    {
                        if (DGV_Data.Columns[i].HeaderText != "IsProcessed")
                        {
                            worksheet.Cells[1, counter] = DGV_Data.Columns[i].HeaderText;
                            counter++;
                        }
                    }

                    for (int i = 0; i < DGV_Data.Rows.Count; i++)
                    {
                        for (int j = 0; j < DGV_Data.Columns.Count - 2; j++)
                        {
                            worksheet.Cells[i + 2, j + 1] = DGV_Data.Rows[i].Cells[j + 1].Value.ToString();
                        }
                    }
                    Microsoft.Office.Interop.Excel.Range excelCellrange = worksheet.UsedRange;
                    Microsoft.Office.Interop.Excel.Range excelCellrange2 = excelCellrange.get_Range("A1", Type.Missing);
                    excelCellrange2.EntireRow.Font.Bold = true;
                    excelCellrange2 = excelCellrange.Rows[(1), System.Reflection.Missing.Value] as Microsoft.Office.Interop.Excel.Range;
                    excelCellrange2.Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Yellow);

                    excelCellrange.EntireColumn.AutoFit();
                    excelCellrange.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;
                    Microsoft.Office.Interop.Excel.Borders border = excelCellrange.Borders;
                    border.LineStyle = Microsoft.Office.Interop.Excel.XlLineStyle.xlContinuous;
                    border.Weight = 2d;

                    string folderPath = Directory + "Dashboard_Report\\";
                    SaveFileDialog saveDialog = new SaveFileDialog();
                    saveDialog.Filter = "Excel files (*.xlsx)|*.xlsx|All files (*.*)|*.*";
                    saveDialog.FilterIndex = 2;

                    workbook.SaveAs(folderPath + "Dashboard_Report_" + Environment.UserName + "_" + DateTime.Now.ToString("hh mm tt") + ".xlsx");
                    obj.ReleaseComObject(worksheet);
                    obj.ReleaseComObject(workbook);
                    obj.ReleaseComObject(XcelApp);
                    MessageBox.Show("Exported Successful");
                    //System.Diagnostics.Process.Start(folderPath + "_" + DateTime.Now.ToString("hh:mm tt") + ".xlsx"); ;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }

        }

        private void Btn_Clr_Click_1(object sender, EventArgs e)
        {
            cmb_cntry.SelectedIndex = 0;
            cmb_Prdt.SelectedIndex = 0;
            cmb_Recon.SelectedIndex = 0;
            File_ViewRecords();
            tab_TLM();
        }

        private void lnk_Logout_LinkClicked_1(object sender, LinkLabelLinkClickedEventArgs e)
        {
            foreach (var p in System.Diagnostics.Process.GetProcessesByName("OpenSpan.Runtime"))
            {
                p.Kill();
            }

            foreach (var p in System.Diagnostics.Process.GetProcessesByName("ARC_Application"))
            {
                p.Kill();
            }
            this.Close();
            MessageBox.Show("You Have LogOut Successfully");
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            //Check_Recons();
            File_ViewRecords();
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            File_ViewRecords();
        }

        protected override void WndProc(ref Message m)
        {
            base.WndProc(ref m);


            //if (m.Msg == 0x0112)
            //{
            //    if (m.WParam == new IntPtr(0xF030))
            //    {
            //        lnk_Logout.Location = new Point(1300, 100);
            //        pictureBox1.Location = new Point(1200, -1);
            //        DGV_Data.Width = 1350;
            //        DGV_Data.Height = 340;
            //        DGV_Data.Location = new Point(4, 185);
            //        Btn_Srch.Location = new Point(1200, 131);
            //        Btn_Clr.Location = new Point(1280, 131);
            //        btnShareDrive.Location = new Point(940, 131);
            //        btn_Export.Location = new Point(1280, 530);
            //        btn_Clear_DB.Location = new Point(1150, 530);
            //        //pictureBox4.Visible = false;
            //    }
            //    else if (m.WParam == new IntPtr(0xF120))
            //    {
            //        Dashboard.ActiveForm.Size = new Size(1201, 494);//this.Size = new Size(1201, 494);
            //        Dashboard.ActiveForm.Location = new Point();
            //        Dashboard.ActiveForm.StartPosition = FormStartPosition.CenterScreen;
            //        DGV_Data.Height = 200;
            //        DGV_Data.Width = 1220;
            //        DGV_Data.Location = new Point(4, 185);
            //        pictureBox1.Location = new Point(1080, 25);
            //        pictureBox1.Height = 80;
            //        pictureBox1.Width = 150;
            //        //pictureBox4.Visible = false;
            //        lnk_Logout.Location = new Point(1170, 80);
            //        Btn_Srch.Location = new Point(1070, 130);
            //        Btn_Clr.Location = new Point(1150, 130);
            //        btnShareDrive.Location = new Point(810, 131);
            //        btn_Export.Location = new Point(1150, 412);
            //        btn_Clear_DB.Location = new Point(1020, 412);
            //    }
            //}
        }

        public void Total_count()
        {
            try
            {
                SqlConnection con = new SqlConnection(conString);
                con.Open();
                SqlCommand com = new SqlCommand("select count (*) as Total from ARC_Scope_BaseLine where In_Scope_For_ARC='yes'", con);
                com.CommandType = CommandType.Text;
                SqlDataReader dr = com.ExecuteReader();
                while (dr.Read())
                {
                    if (dr.HasRows == true)
                    {
                        Total = (int)dr["Total"];
                    }
                }
                con.Close();
                con.Open();
                com = new SqlCommand("select count (*) as Completed from ARC_Scope_BaseLine where IsProcessed= 'true' and In_Scope_For_ARC='yes'", con);
                com.CommandType = CommandType.Text;
                dr = com.ExecuteReader();
                while (dr.Read())
                {
                    if (dr.HasRows == true)
                    {
                        Completed = (int)dr["Completed"];
                    }
                }
                con.Close();
                lbl_cnt.Text = Total.ToString();
                lbl_com_cnt.Text = Completed.ToString();
                lbl_pen_cnt.Text = (Total - Completed).ToString();
            }
            catch
            {

            }
        }

        public void Products_count()
        {
            try
            {
                SqlConnection con = new SqlConnection(conString);
                con.Open();
                SqlCommand com = new SqlCommand("select count (*) as Total from ARC_Scope_BaseLine where product_id='" + j + "'", con);
                com.CommandType = CommandType.Text;
                SqlDataReader dr = com.ExecuteReader();
                while (dr.Read())
                {
                    if (dr.HasRows == true)
                    {
                        Total = (int)dr["Total"];
                    }
                }
                con.Close();
                con.Open();
                com = new SqlCommand("select count (*) as Completed from ARC_Scope_BaseLine where IsProcessed= 'true' and product_id='" + j + "'", con);
                com.CommandType = CommandType.Text;
                dr = com.ExecuteReader();
                while (dr.Read())
                {
                    if (dr.HasRows == true)
                    {
                        Completed = (int)dr["Completed"];
                    }
                }
                con.Close();
                lbl_cnt.Text = Total.ToString();
                lbl_com_cnt.Text = Completed.ToString();
                lbl_pen_cnt.Text = (Total - Completed).ToString();
            }
            catch
            {

            }
        }

        public void Countrys_count()
        {
            try
            {
                SqlConnection con = new SqlConnection(conString);
                con.Open();
                SqlCommand com = new SqlCommand("select count (*) as Total from ARC_Scope_BaseLine where Country_Id='" + i + "'", con);
                com.CommandType = CommandType.Text;
                SqlDataReader dr = com.ExecuteReader();
                while (dr.Read())
                {
                    if (dr.HasRows == true)
                    {
                        Total = (int)dr["Total"];
                    }
                }
                con.Close();
                con.Open();
                com = new SqlCommand("select count (*) as Completed from ARC_Scope_BaseLine where IsProcessed= 'true' and Country_Id='" + i + "'", con);
                com.CommandType = CommandType.Text;
                dr = com.ExecuteReader();
                while (dr.Read())
                {
                    if (dr.HasRows == true)
                    {
                        Completed = (int)dr["Completed"];
                    }
                }
                con.Close();
                lbl_cnt.Text = Total.ToString();
                lbl_com_cnt.Text = Completed.ToString();
                lbl_pen_cnt.Text = (Total - Completed).ToString();
            }
            catch
            {

            }
        }

        private void btnShareDrive_Click(object sender, EventArgs e)
        {

        }

        private void Dashboard_Load(object sender, EventArgs e)
        {
            pictureBox1.Location = new Point(1080, 25);
            pictureBox1.Height = 80;
            pictureBox1.Width = 150;


        }

        private void Dashboard_Load_1(object sender, EventArgs e)
        {
            dataGridView2.Visible = false;
            tab_TLM();

        }

        private void DGV_Data_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
        }

        private void btn_Clear_DB_Click(object sender, EventArgs e)
        {
            string _selectedTab = this.tabControl1.SelectedTab.Text;
            ///Prakash RetryLogic
            if (_selectedTab == "File")
            {
                Hashtable hat = new Hashtable();
                SqlConnection con = new SqlConnection(conString);
                SqlCommand cmd = null;
                SqlCommand cmd1 = null;
                SqlCommand cmd2 = null;
                DataGridViewRowCollection Rows = DGV_Data.Rows;
                bool IsCheck = false;
                con.Open();
                foreach (DataGridViewRow row in Rows)
                {
                    if (row.Cells["Select"].Value != null && row.Cells["Select"].Value.ToString() == "True")
                    {
                        IsCheck = true;
                        string recon = row.Cells["Recon"].Value.ToString();
                        string Country = row.Cells["Country_Name"].Value.ToString();
                        string[] File_Name = row.Cells["Input File Name"].Value.ToString().Split('.');
                        string Recon_Date = row.Cells["Recon Date"].Value.ToString();

                        //cmd = new SqlCommand("update ARC_Scope_BaseLine set IsProcessed = 0, AutomationStatus = null, AutomationStartTime = null, AutomationEndTime = null, PSID = null, Retry_Count= Retry_Count+1 where Recon = '" + recon + "' and  Country_Name = '" + Country + "' and Report_Source_File_Name = '" + File_Name + "'", con);
                        string query = "";
                        query = "select count(1) cnt from ARC_SCOPE_BASELINE where automationstarttime Is Not null and PSID  is not null and Recon = '" + recon + "' and  Country_Name = '" + Country + "' and Report_Source_File_Name like '" + File_Name[0] + "%'";
                        DataTable dt = das.Select_Table(query, hat, "Text");

                        int IsDataAvailable = 0;
                        if (dt.Rows.Count > 0)
                        {
                            IsDataAvailable = Convert.ToInt32(dt.Rows[0]["cnt"].ToString());
                        }
                        if (IsDataAvailable == 1)
                        {
                            cmd2 = new SqlCommand("insert into ARC_SCOPE_BASELINE_RETRY select * from ARC_SCOPE_BASELINE where  Recon = '" + recon + "' and  Country_Name = '" + Country + "' and Report_Source_File_Name like '" + File_Name[0] + "%'", con);
                            cmd = new SqlCommand("update ARC_Scope_BaseLine set IsProcessed = 0, AutomationStatus = null, AutomationStartTime = null, AutomationEndTime = null, PSID = null, Retry_Count= Retry_Count+1  where Recon = '" + recon + "' and  Country_Name = '" + Country + "' and Report_Source_File_Name like '" + File_Name[0] + "%'", con);
                        }
                        cmd1 = new SqlCommand("update arc_recon_master set Is_Recon_Completed = 0, PSID = null, Recon_Status = null,AutomationStartTime=Null,AutomationEndTime=null where recon_name = '" + recon + "'", con);
                        if (Recon_Date != null && Recon_Date.Trim().ToUpper() != "NA")
                        {
                            DateTime dtRecon = DateTime.ParseExact(Recon_Date, "dd/MM/yyyy", System.Globalization.CultureInfo.InvariantCulture);
                            int t = 0;

                            string strInsUpdHoliDayFileRetry = "insert into ARC_SCOPE_BASELINE_LOGIC_RETRY select * from ARC_SCOPE_BASELINE_LOGIC where Recon = '" + recon + "' and  Country_Name = '" + Country + "' and Report_Source_File_Name like '" + File_Name[0] + "%' and recon_date='" + dtRecon.ToString("MM/dd/yyyy") + "'";
                            t = das.ins_upd_fun(strInsUpdHoliDayFileRetry, hat, "Text");

                            string strInsUpdHoliDayFile = "update ARC_Scope_BaseLine_Logic set IsProcessed = 0, AutomationStatus = null, AutomationStartTime = null, AutomationEndTime = null, PSID = null,Processed_Date=null, Retry_Count= Retry_Count+1 where Recon = '" + recon + "' and  Country_Name = '" + Country + "' and Report_Source_File_Name like '" + File_Name[0] + "%' and recon_date='" + dtRecon.ToString("MM/dd/yyyy") + "'";
                            t = das.ins_upd_fun(strInsUpdHoliDayFile, hat, "Text");

                            string strInsUpdHoliDayRecon = "update ARC_Recon_Master_Holiday_date_logic set Is_Recon_Completed = 0, PSID = null, Recon_Status = null,AutomationStartTime=Null,AutomationEndTime=null where recon_name = '" + recon + "' and Recon_date='" + dtRecon.ToString("MM/dd/yyyy") + "'";
                            t = das.ins_upd_fun(strInsUpdHoliDayRecon, hat, "Text");
                        }
                        int i = 0;
                        int k = 0;
                        if (IsDataAvailable == 1)
                        {
                            k = cmd2.ExecuteNonQuery();
                            i = cmd.ExecuteNonQuery();
                        }
                        int j = cmd1.ExecuteNonQuery();
                        if (i > 0 || j > 0)
                        {
                            //MessageBox.Show("Sucessful");
                        }
                    }
                }
                int im = cmb_Recon.SelectedIndex;
                selectedRecon = this.cmb_Recon.GetItemText(this.cmb_Recon.SelectedItem);
                if (im > 0)
                {
                    File_ViewRecons();

                }
                else
                {
                    File_ViewRecords();
                }
                con.Close();
                if (IsCheck == false)
                {
                    MessageBox.Show("Please Select check box...!");
                }
            }
            ///Prakash RetryLogic

            //if (_selectedTab == "File")
            //{
            //    Hashtable hat = new Hashtable();
            //    SqlConnection con = new SqlConnection(conString);
            //    SqlCommand cmd = null;
            //    SqlCommand cmd1 = null;
            //    DataGridViewRowCollection Rows = DGV_Data.Rows;
            //    bool IsCheck = false;
            //    con.Open();
            //    foreach (DataGridViewRow row in Rows)
            //    {
            //        if (row.Cells["Select"].Value != null && row.Cells["Select"].Value.ToString() == "True")
            //        {
            //            IsCheck = true;
            //            string recon = row.Cells["Recon"].Value.ToString();
            //            string Country = row.Cells["Country_Name"].Value.ToString();
            //            string[] File_Name = row.Cells["Input File Name"].Value.ToString().Split('.');
            //            string Recon_Date = row.Cells["Recon Date"].Value.ToString();
            //            cmd = new SqlCommand("update ARC_Scope_BaseLine set IsProcessed = 0, AutomationStatus = null, AutomationStartTime = null, AutomationEndTime = null, PSID = null, Retry_Count= Retry_Count+1  where Recon = '" + recon + "' and  Country_Name = '" + Country + "' and Report_Source_File_Name like '" + File_Name[0] + "%'", con);
            //            //cmd = new SqlCommand("update ARC_Scope_BaseLine set IsProcessed = 0, AutomationStatus = null, AutomationStartTime = null, AutomationEndTime = null, PSID = null, Retry_Count= Retry_Count+1 where Recon = '" + recon + "' and  Country_Name = '" + Country + "' and Report_Source_File_Name = '" + File_Name + "'", con);
            //            cmd1 = new SqlCommand("update arc_recon_master set Is_Recon_Completed = 0, PSID = null, Recon_Status = null,AutomationStartTime=Null,AutomationEndTime=null where recon_name = '" + recon + "'", con);
            //            if (Recon_Date != null && Recon_Date.Trim().ToUpper() != "NA")
            //            {
            //                DateTime dtRecon = DateTime.ParseExact(Recon_Date, "dd/MM/yyyy", System.Globalization.CultureInfo.InvariantCulture);

            //                int t = 0;
            //                string strInsUpdHoliDayFile = "update ARC_Scope_BaseLine_Logic set IsProcessed = 0, AutomationStatus = null, AutomationStartTime = null, AutomationEndTime = null, PSID = null,Processed_Date=null where Recon = '" + recon + "' and  Country_Name = '" + Country + "' and Report_Source_File_Name like '" + File_Name[0] + "%' and recon_date='" + dtRecon.ToString("MM/dd/yyyy") + "'";
            //                t = das.ins_upd_fun(strInsUpdHoliDayFile, hat, "Text");

            //                string strInsUpdHoliDayRecon = "update ARC_Recon_Master_Holiday_date_logic set Is_Recon_Completed = 0, PSID = null, Recon_Status = null,AutomationStartTime=Null,AutomationEndTime=null where recon_name = '" + recon + "' and Recon_date='" + dtRecon.ToString("MM/dd/yyyy") + "'";
            //                t = das.ins_upd_fun(strInsUpdHoliDayRecon, hat, "Text");
            //            }
            //            int i = cmd.ExecuteNonQuery();
            //            int j = cmd1.ExecuteNonQuery();
            //            if (i > 0 || j > 0)
            //            {
            //                //MessageBox.Show("Sucessful");
            //            }
            //        }
            //    }
            //    int im = cmb_Recon.SelectedIndex;
            //    selectedRecon = this.cmb_Recon.GetItemText(this.cmb_Recon.SelectedItem);
            //    if (im > 0)
            //    {
            //        File_ViewRecons();

            //    }
            //    else
            //    {
            //        File_ViewRecords();
            //    }
            //    con.Close();
            //    if (IsCheck == false)
            //    {
            //        MessageBox.Show("Please Select check box...!");
            //    }
            //}
            else if (_selectedTab == "TLM")
            {
                string srno = "";
                bool IsCheck = false;
                foreach (DataGridViewRow row in dgv_TLM.Rows)
                {
                    if (Convert.ToString(row.Cells[0].Value) == "True")
                    {
                        IsCheck = true;
                        srno = Convert.ToString(row.Cells[1].Value);
                        SqlConnection con = new SqlConnection(conString);
                        SqlCommand cmd = null;
                        DataTable dt = new DataTable();
                        cmd = new SqlCommand("update ARC_TLM_SETID set IsProcessed = 0, [Status] = NULL where SRNO = '" + srno + "'", con);
                        SqlDataAdapter da2 = new SqlDataAdapter(cmd);
                        con.Open();
                        cmd.ExecuteNonQuery();
                        da2.Fill(dt);
                        con.Close();
                    }
                }
                if (IsCheck == false)
                {
                    MessageBox.Show("Please Select check box...!");
                }
                tab_TLM();
            }
        }

        private void btn_Clear_DB_Click_Old(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(conString);
            SqlCommand cmd = null;
            SqlCommand cmd1 = null;
            DataGridViewRowCollection Rows = DGV_Data.Rows;
            bool IsCheck = false;
            con.Open();
            foreach (DataGridViewRow row in Rows)
            {
                if (row.Cells["Select"].Value != null && row.Cells["Select"].Value.ToString() == "True")
                {
                    IsCheck = true;
                    string recon = row.Cells["Recon"].Value.ToString();
                    string Country = row.Cells["Country_Name"].Value.ToString();
                    string File_Name = row.Cells["Report_Source_File_Name"].Value.ToString();
                    cmd = new SqlCommand("update ARC_Scope_BaseLine set IsProcessed = 0, AutomationStatus = null, AutomationStartTime = null, AutomationEndTime = null, PSID = null where Recon = '" + recon + "' and  Country_Name = '" + Country + "' and Report_Source_File_Name = '" + File_Name + "'", con);
                    cmd1 = new SqlCommand("update arc_recon_master set Is_Recon_Completed = 0, PSID = null, Recon_Status = null where recon_name = '" + recon + "'", con);
                    int i = cmd.ExecuteNonQuery();
                    int j = cmd1.ExecuteNonQuery();
                    if (i > 0 || j > 0)
                    {
                        //MessageBox.Show("Sucessful");
                    }
                }
            }
            con.Close();
            if (IsCheck == false)
            {
                MessageBox.Show("Please Select check box...!");
            }
        }

        private void txt_Fil_TextChanged(object sender, EventArgs e)
        {

        }

        public byte[] imageToByteArray(System.Drawing.Image imageIn)
        {
            MemoryStream ms = new MemoryStream();
            imageIn.Save(ms, System.Drawing.Imaging.ImageFormat.Gif);
            return ms.ToArray();
        }

        public void ViewRecords_DB(string recon_name, string recon_Date)
        {
            string strquery = "";
            try
            {
                Hashtable hat = new Hashtable();
                string[] Rec_Date1;
                if (recon_Date != "" && recon_Date != "NA")
                {
                    DateTime myDate1 = DateTime.ParseExact(recon_Date, "dd/MM/yyyy", System.Globalization.CultureInfo.InvariantCulture);
                    Rec_Date1 = myDate1.ToString("yyyy-MM-dd").Split(' ');
                    strquery = "Select a.Scope_Id as [S No],b.Team,b.Country_Name,b.Recon,CONVERT(VARCHAR(8), a.SLA_Time, 108) as SLA_Time,CONVERT(VARCHAR(8), a.Receipt_Time, 108) as Receipt_Time,b.Report_Source_File_Name+'.'+isnull(a.File_Format,'')  as [Input File Name],b.FTP_File_Format_Name as [Output File Name],a.Source_Application,a.Frequency,b.IsProcessed,b.AutomationStartTime,b.AutomationEndTime,b.Recon_Date,b.AutomationStatus FROM ARC_Scope_BaseLine a,Arc_Scope_Baseline_Logic b where a.Country_name=b.country_name and a.Team=B.Team and a.Report_Source_file_name=b.Report_Source_file_name and a.FTP_File_Format_name=b.Ftp_File_Format_Name and a.In_Scope_For_ARC='yes' and b.Recon ='" + recon_name + "' and b.Recon_Date='" + Rec_Date1[0] + "'  order by b.Report_Source_file_name,b.Recon_Date";
                }
                else
                {
                    strquery = "Select a.Scope_Id as [S No],b.Team,b.Country_Name,b.Recon,CONVERT(VARCHAR(8), a.SLA_Time, 108) as SLA_Time,CONVERT(VARCHAR(8), a.Receipt_Time, 108) as Receipt_Time,b.Report_Source_File_Name+'.'+isnull(a.File_Format,'')  as [Input File Name],b.FTP_File_Format_Name as [Output File Name],a.Source_Application,a.Frequency,b.IsProcessed,b.AutomationStartTime,b.AutomationEndTime,b.Recon_Date,b.AutomationStatus FROM ARC_Scope_BaseLine a,Arc_Scope_Baseline_Logic b where a.Country_name=b.country_name and a.Team=B.Team and a.Report_Source_file_name=b.Report_Source_file_name and a.FTP_File_Format_name=b.Ftp_File_Format_Name and a.In_Scope_For_ARC='yes' and b.Recon ='" + recon_name + "'  order by b.Report_Source_file_name,b.Recon_Date";
                }
                DataTable dt = das.Select_Table(strquery, hat, "Text");
                if (dt.Rows.Count == 0)
                {
                    strquery = "Select Scope_Id as [S No],Team,Country_Name,Recon,CONVERT(VARCHAR(8), SLA_Time, 108) as SLA_Time,CONVERT(VARCHAR(8), Receipt_Time, 108) as Receipt_Time,Report_Source_File_Name+'.'+isnull(File_Format,'')  as [Input File Name],FTP_File_Format_Name as [Output File Name],Source_Application,Frequency,IsProcessed,AutomationStartTime,AutomationEndTime,AutomationStatus FROM ARC_Scope_BaseLine where In_Scope_For_ARC='yes' and Recon ='" + recon_name + "'";
                    dt = das.Select_Table(strquery, hat, "text");
                }

                int c = 1;
                for (int idx = 0; idx < dt.Rows.Count; idx++)
                {
                    dt.Rows[idx][0] = c;
                    c++;
                }
                int ReconCount = 0;
                int ReconCompleted = 0;
                //dt.Columns.Add("Download Status", typeof(byte[]));
                dt.Columns.Add("Download Status");
                if (dt.Columns.Contains("Download Status"))
                {
                    for (int indx = 0; indx < dt.Rows.Count; indx++)
                    {
                        DateTime d = Convert.ToDateTime(dt.Rows[indx][4]);
                        DateTime d1 = Convert.ToDateTime(date);

                        ReconCount++;
                        if (Convert.ToBoolean(dt.Rows[indx]["IsProcessed"]) == true && (dt.Rows[indx]["AutomationStatus"].ToString().ToLower() == "completed"))
                        {
                            dt.Rows[indx]["Download Status"] = "Completed";
                            ReconCompleted++;
                        }
                        else if (string.IsNullOrEmpty(dt.Rows[indx]["AutomationStartTime"].ToString()) && string.IsNullOrEmpty(dt.Rows[indx]["AutomationEndTime"].ToString()))
                        {
                            dt.Rows[indx]["Download Status"] = "Yet To Start";
                        }
                        else if (!string.IsNullOrEmpty(dt.Rows[indx]["AutomationStartTime"].ToString()) && string.IsNullOrEmpty(dt.Rows[indx]["AutomationEndTime"].ToString()))
                        {
                            dt.Rows[indx]["Download Status"] = "In Progress";
                        }
                        else if (!string.IsNullOrEmpty(dt.Rows[indx]["AutomationStartTime"].ToString()) && Convert.ToBoolean(dt.Rows[indx]["IsProcessed"]) == true)
                        {
                            dt.Rows[indx]["Download Status"] = "Completed";
                            ReconCompleted++;
                        }
                        else if (!string.IsNullOrEmpty(dt.Rows[indx]["AutomationStartTime"].ToString()) && !string.IsNullOrEmpty(dt.Rows[indx]["AutomationEndTime"].ToString()) && Convert.ToBoolean(dt.Rows[indx]["IsProcessed"]) == false)
                        {
                            dt.Rows[indx]["Download Status"] = "Error";
                        }
                        else
                        {
                            dt.Rows[indx]["Download Status"] = "Yet To Start";
                        }

                    }
                }

                //Form1 f1 = new Form1(dt);
                //f1.Show();
                //f1.dataGridView1.Columns[10].Visible = false;

                dt.Columns.Remove("AutomationStartTime");
                dt.Columns.Remove("AutomationEndTime");
                dt.Columns.Remove("IsProcessed");
                dt.Columns.Remove("AutomationStatus");

                dataGridView2.DataSource = dt;

                dataGridView2.Columns[0].Visible = false;

                foreach (DataGridViewColumn dc in dataGridView2.Columns)
                {
                    dc.SortMode = DataGridViewColumnSortMode.NotSortable;

                    if (dc.HeaderText == "Select")
                    {
                        dc.ReadOnly = false;
                    }
                    else
                    {
                        dc.ReadOnly = true;
                    }
                }


                //Download Status - Color variant
                foreach (DataGridViewRow row in dataGridView2.Rows)
                {
                    foreach (DataGridViewColumn col in dataGridView2.Columns)
                    {
                        if (dataGridView2["Download Status", row.Index].Value == "Yet To Start")
                        {
                            dataGridView2["Download Status", row.Index].Style.BackColor = Color.SkyBlue;
                        }

                        if (dataGridView2["Download Status", row.Index].Value == "In Progress")
                        {
                            dataGridView2["Download Status", row.Index].Style.BackColor = Color.Orange;
                        }

                        if (dataGridView2["Download Status", row.Index].Value == "Completed")
                        {
                            dataGridView2["Download Status", row.Index].Style.BackColor = Color.LimeGreen;
                        }

                        if (dataGridView2["Download Status", row.Index].Value == "Error")
                        {
                            dataGridView2["Download Status", row.Index].Style.BackColor = Color.Firebrick;
                        }
                    }
                }

                //con.Close();
                Total_count();
                _selectedTab = this.tabControl1.SelectedTab.Text;

                if (_selectedTab != "File")
                {
                    lbl_cnt.Visible = true;
                    lbl_pen_cnt.Visible = true;
                    lbl_rec.Visible = true;
                    lbl_com.Visible = true;
                    lbl_pen.Visible = true;
                    lbl_Files.Visible = false;
                    lbl_FlsCMP.Visible = false;
                    lbl_FlsPND.Visible = false;
                    lbl_FilcntVw.Visible = false;
                    lbl_FlsCMPVW.Visible = false;
                    lbl_FlsPNDVW.Visible = false;
                    lbl_cnt.Text = ReconCount.ToString();
                    lbl_com_cnt.Text = ReconCompleted.ToString();
                    lbl_pen_cnt.Text = (ReconCount - ReconCompleted).ToString();
                }
            }
            catch
            {

            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            SqlConnection con = new SqlConnection(conString);
            DataTable dt_DGV = new DataTable();
            if (e.RowIndex == -1) return;

            if (dataGridView1.CurrentCell.ColumnIndex.Equals(4))
            {
                if (dataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex].Value != null)
                {
                    _reconName = dataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString();
                    _reconDate = dataGridView1.Rows[e.RowIndex].Cells[8].Value.ToString();

                    if (temprecon == _reconName)
                    {
                        if (dataGridView2.Visible == true)
                        {
                            dataGridView2.Visible = false;
                        }
                        else
                        {
                            dataGridView2.Visible = true;
                            ViewRecords_DB(_reconName, _reconDate);
                        }
                    }
                    else
                    {
                        temprecon = _reconName;

                        dataGridView2.Visible = true;
                        ViewRecords_DB(_reconName, _reconDate);
                    }
                }
            }
        }

        private void btn_Chk_Recon_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(conString);
            SqlCommand cmd = null;
            SqlCommand cmd1 = null;
            DataGridViewRowCollection Rows = dataGridView1.Rows;
            int colcnt = dataGridView1.Columns.Count - 1;
            bool IsCheck = false;
            con.Open();
            foreach (DataGridViewRow row in Rows)
            {
                if (row.Cells[0].Value != null && row.Cells[0].Value.ToString() == "True")
                {
                    IsCheck = true;
                    string recon = row.Cells["Recon_Name"].Value.ToString();
                    cmd = new SqlCommand("update arc_recon_master set IS_Active = 0, Is_Recon_Completed = 0, PSID = null, Recon_Status = null where recon_name = '" + recon + "'", con);
                    int i = cmd.ExecuteNonQuery();
                    if (i > 0)
                    {
                        //MessageBox.Show("Sucessful");
                    }
                }
            }
            con.Close();
            if (IsCheck == false)
            {
                MessageBox.Show("Please Select check box...!");
            }
        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            _selectedTab = this.tabControl1.SelectedTab.Text;

            if (_selectedTab == "File")
            {
                cmb_Prdt.Enabled = true;
                cmb_cntry.Enabled = true;
                cmb_Application.Enabled = true;
                btn_Clear_DB.Visible = true;
                if (cmb_Recon.SelectedIndex == 0)
                {
                    File_ViewRecords();
                }
                else
                {
                    File_ViewRecons();
                }
            }
            else if (_selectedTab == "TLM")
            {
                tab_TLM();
                refreshdata();
                btn_Clear_DB.Visible = true;
                cmb_Prdt.Enabled = false;
                cmb_cntry.Enabled = false;
                cmb_Application.Enabled = false;
            }
            else
            {
                cmb_Prdt.Enabled = true;
                cmb_cntry.Enabled = true;
                cmb_Application.SelectedIndex = 0;
                cmb_Application.Enabled = false;
                btn_Clear_DB.Visible = false;
                if (cmb_Recon.SelectedIndex == 0)
                {
                    Recon_ViewRecord();
                }
                else
                {
                    Recon_ViewRecons();
                }
            }
        }

        public void tab_TLM()
        {
            SqlConnection con = new SqlConnection(conString);
            SqlCommand cmd = null;
            DataTable dt1 = new DataTable();
            cmd = new SqlCommand("select * from ARC_TLM_SETID", con);
            SqlDataAdapter da2 = new SqlDataAdapter(cmd);
            da2.Fill(dt1);
            dgv_TLM.DataSource = dt1;

            dgv_TLM.Columns[1].Visible = false;
            dgv_TLM.Columns[3].Visible = false;
            //dgv_TLM.Columns[4].Visible = false;
            dgv_TLM.Columns[5].Visible = false;
            dgv_TLM.Columns[6].Visible = false;
            dgv_TLM.Columns[8].Visible = false;
            dgv_TLM.Columns[9].Visible = false;
            //dgv_TLM.Columns[10].Visible = false;
            //dgv_TLM.Columns[11].Visible = false;

            foreach (DataGridViewRow row in dgv_TLM.Rows)
            {
                if (Convert.ToString(row.Cells["Status"].Value) == "COMPLETED")
                {
                    dgv_TLM["Status", row.Index].Style.BackColor = Color.LimeGreen;
                }
                if (Convert.ToString(row.Cells["Status"].Value) == "Yet To Start" || Convert.ToString(row.Cells["Status"].Value) == "")
                {
                    dgv_TLM["Status", row.Index].Style.BackColor = Color.SkyBlue;
                    dgv_TLM["Status", row.Index].Value = "Yet To Start";
                    //dgv_TLM.Rows[row.Index]["Download Status"] = "Yet To Start";
                }
                if (Convert.ToString(row.Cells["Status"].Value) == "In Progress")
                {
                    dgv_TLM["Status", row.Index].Style.BackColor = Color.Yellow;
                }
                if (Convert.ToString(row.Cells["Status"].Value) == "Data Not Available")
                {
                    dgv_TLM["Status", row.Index].Style.BackColor = Color.Orange;
                }
                if (Convert.ToString(row.Cells["Status"].Value) == "Error")
                {
                    dgv_TLM["Status", row.Index].Style.BackColor = Color.Firebrick;
                }
            }
        }

        public DataTable Get_Recon_Date_New(string Date_Format)
        {
            DAccesss.Program das = new DAccesss.Program();
            Formatting_Logics obj = new Formatting_Logics();
            Hashtable hat = new Hashtable();
            string Final_Date = string.Empty;
            string fmt = CultureInfo.CurrentCulture.DateTimeFormat.ShortDatePattern;

            try
            {
                int day = 0;
                string actd = "";
                int datefound = 0;
                System.Data.DataTable dt = new System.Data.DataTable();
                System.Data.DataTable table = new System.Data.DataTable();
                System.Data.DataTable date = new System.Data.DataTable();
                string Today = DateTime.Now.ToString("dddd");

                date.Columns.Add("Country_ID", typeof(long));
                date.Columns.Add("Country_Name", typeof(string));
                date.Columns.Add("Gulf", typeof(string));
                date.Columns.Add("Holiday_Date", typeof(DateTime));


                hat.Clear();
                table = das.Select_Table("select contry.Country_ID,contry.Country_Name,Gulf,isnull(Holiday_date,'') as Holiday_Date from arc_country_details contry left join arc_holiday_master mast on mast.Country_Id=contry.Country_Id", hat, "text");

                if (table.Rows.Count > 0)
                {
                    for (int a = 0; a < table.Rows.Count; a++)
                    {
                        if (Convert.ToString(table.Rows[0][2]).Trim() == "NonGulf")
                        {
                            int Year = Convert.ToInt32(DateTime.Now.ToString("yyyy"));
                            //DateTime startDate = new DateTime(Year, 1, 1);
                            //DateTime endDate = new DateTime(Year, 12, 31);


                            DateTime startDate = DateTime.Today, endDate = DateTime.Today;

                            //date.Columns.Add("Country_ID", typeof(long));
                            //date.Columns.Add("Country_Name", typeof(string));
                            //date.Columns.Add("Gulf", typeof(string));
                            //date.Columns.Add("Holiday_date", typeof(DateTime));

                            TimeSpan diff = endDate - startDate;
                            int days = diff.Days;
                            for (var i = 0; i <= days; i++)
                            {
                                var testDate = startDate.AddDays(i);
                                try
                                {
                                    switch (testDate.DayOfWeek)
                                    {
                                        case DayOfWeek.Saturday:
                                        case DayOfWeek.Sunday:
                                            date.Rows.Add();
                                            date.Rows.Add(table.Rows[a][0], table.Rows[a][1], table.Rows[a][2], testDate.ToString(fmt));
                                            break;
                                    }

                                }
                                catch
                                {

                                }
                            }
                            date.Merge(table);
                            // obj.ExecRemoveDuplicateRows(date, "date");
                        }
                        else
                        {
                            int Year = Convert.ToInt32(DateTime.Now.ToString("yyyy"));
                            //DateTime startDate = new DateTime(Year, 1, 1);
                            //DateTime endDate = new DateTime(Year, 12, 31);
                            DateTime startDate = DateTime.Today, endDate = DateTime.Today;



                            TimeSpan diff = endDate - startDate;
                            int days = diff.Days;
                            for (var i = 0; i <= days; i++)
                            {
                                var testDate = startDate.AddDays(i);
                                switch (testDate.DayOfWeek)
                                {
                                    case DayOfWeek.Friday:
                                    case DayOfWeek.Saturday:
                                        date.Rows.Add(table.Rows[a][0], table.Rows[a][1], table.Rows[a][2], testDate.ToString(fmt));
                                        break;
                                }
                            }
                            date.Merge(table);
                        }
                    }
                }


                return date;
            }
            catch
            {
                return null;
            }
        }

        public DataTable Get_Recon_Date(string CountryName, string Date_Format)
        {
            DAccesss.Program das = new DAccesss.Program();
            Formatting_Logics obj = new Formatting_Logics();
            Hashtable hat = new Hashtable();
            string Final_Date = string.Empty;
            string fmt = CultureInfo.CurrentCulture.DateTimeFormat.ShortDatePattern;

            try
            {
                int day = 0;
                string actd = "";
                int datefound = 0;
                System.Data.DataTable dt = new System.Data.DataTable();
                System.Data.DataTable table = new System.Data.DataTable();
                System.Data.DataTable date = new System.Data.DataTable();
                string Today = DateTime.Now.ToString("dddd");

                //string date = DateTime.Now.ToString("09/09/2017");
                //*************************************************************************
                //SqlDataAdapter ad = new SqlDataAdapter("dbo.ARC_SP_Get_Holiday_Date", con);
                //ad.SelectCommand.CommandType = CommandType.StoredProcedure;
                //ad.SelectCommand.Parameters.AddWithValue("@Country_Name", CountryName);
                //con.Open();
                //ad.Fill(table);
                //con.Close();

                hat.Clear();
                hat.Add("@Country_Name", CountryName);
                table = das.Select_Table("dbo.ARC_SP_Get_Holiday_Date", hat, "sp");

                if (table.Rows.Count > 0)
                {
                    if (Convert.ToString(table.Rows[0][2]).Trim() == "NonGulf")
                    {
                        int Year = Convert.ToInt32(DateTime.Now.ToString("yyyy"));
                        //DateTime EndOfYear = Convert.ToDateTime("31-12-" + Year + "");
                        DateTime startDate = new DateTime(Year, 1, 1);
                        DateTime endDate = new DateTime(Year, 12, 31);

                        date.Columns.Add("date", typeof(DateTime));
                        date.Columns.Add("Country_Id", typeof(long));
                        date.Columns.Add("Gulf");
                        TimeSpan diff = endDate - startDate;
                        int days = diff.Days;
                        for (var i = 0; i <= days; i++)
                        {
                            var testDate = startDate.AddDays(i);
                            try
                            {
                                switch (testDate.DayOfWeek)
                                {
                                    case DayOfWeek.Saturday:
                                    case DayOfWeek.Sunday:
                                        date.Rows.Add();
                                        date.Rows.Add(testDate.ToString(fmt));
                                        break;
                                }

                            }
                            catch
                            {

                            }
                        }
                        date.Merge(table);
                        obj.ExecRemoveDuplicateRows(date, "date");
                    }
                    else
                    {
                        int Year = Convert.ToInt32(DateTime.Now.ToString("yyyy"));
                        DateTime startDate = new DateTime(Year, 1, 1);
                        DateTime endDate = new DateTime(Year, 12, 31);

                        date.Columns.Add("date", typeof(DateTime));
                        date.Columns.Add("Country_Id", typeof(long));
                        date.Columns.Add("Gulf");
                        TimeSpan diff = endDate - startDate;
                        int days = diff.Days;
                        for (var i = 0; i <= days; i++)
                        {
                            var testDate = startDate.AddDays(i);
                            switch (testDate.DayOfWeek)
                            {
                                case DayOfWeek.Friday:
                                case DayOfWeek.Saturday:
                                    date.Rows.Add(testDate.ToString(fmt));
                                    break;
                            }
                        }
                        date.Merge(table);
                    }
                }
                else
                {
                    //SqlCommand ad1 = new SqlCommand("dbo.ARC_SP_Get_Holiday_Date_NoHoliday", con);
                    //ad1.CommandType = CommandType.StoredProcedure;
                    //ad1.Parameters.AddWithValue("@Country_Name", CountryName);
                    //con.Open();
                    // string Result = Convert.ToString(ad1.ExecuteScalar());

                    // con.Close();

                    hat.Clear();
                    hat.Add("@Country_Name", CountryName);
                    table = das.Select_Table("dbo.ARC_SP_Get_Holiday_Date_NoHoliday", hat, "sp");

                    string Result = "";
                    if (table.Rows.Count > 0)
                    {
                        Result = table.Rows[0][0].ToString();
                    }

                    if (Result == "NonGulf")
                    {
                        int Year = Convert.ToInt32(DateTime.Now.ToString("yyyy"));
                        DateTime startDate = new DateTime(Year, 1, 1);
                        DateTime endDate = new DateTime(Year, 12, 31);

                        date.Columns.Add("date", typeof(DateTime));
                        date.Columns.Add("Country_Id", typeof(long));
                        date.Columns.Add("Gulf");
                        TimeSpan diff = endDate - startDate;
                        int days = diff.Days;
                        for (var i = 0; i <= days; i++)
                        {
                            var testDate = startDate.AddDays(i);
                            switch (testDate.DayOfWeek)
                            {
                                case DayOfWeek.Saturday:
                                case DayOfWeek.Sunday:
                                    date.Rows.Add(testDate.ToString(fmt));
                                    break;
                            }
                        }
                    }
                    else
                    {
                        int Year = Convert.ToInt32(DateTime.Now.ToString("yyyy"));
                        DateTime startDate = new DateTime(Year, 1, 1);
                        DateTime endDate = new DateTime(Year, 12, 31);

                        date.Columns.Add("date");
                        TimeSpan diff = endDate - startDate;
                        int days = diff.Days;
                        for (var i = 0; i <= days; i++)
                        {
                            var testDate = startDate.AddDays(i);
                            switch (testDate.DayOfWeek)
                            {
                                case DayOfWeek.Friday:
                                case DayOfWeek.Saturday:
                                    date.Rows.Add(testDate.ToString(fmt));
                                    break;
                            }
                        }
                    }
                    date.Merge(table);

                }

                return date;
            }
            catch
            {
                return null;
            }
        }
        //************************************************

        //DataView v = date.DefaultView;
        //v.Sort = "Holiday_Date";
        //System.Data.DataTable d = new System.Data.DataTable();
        //d = v.ToTable();
        //try
        //{
        //    for (int i = 0; i <= d.Rows.Count - 1; i++)
        //    {
        //        if (d.Rows[i][0].ToString() != "")
        //        {

        //            string d1 = DateTime.Now.AddDays(-1).ToString("MM/dd/yyyy");
        //            string d2 = DateTime.Now.AddDays(-2).ToString("MM/dd/yyyy");
        //            string d3 = DateTime.Now.AddDays(-3).ToString("MM/dd/yyyy");
        //            string d4 = DateTime.Now.AddDays(-4).ToString("MM/dd/yyyy");
        //            string d5 = DateTime.Now.AddDays(-5).ToString("MM/dd/yyyy");
        //            actd = Convert.ToDateTime(d.Rows[i][0]).ToString("MM/dd/yyyy");
        //            if (d1 == actd)
        //            {
        //                datefound = 1;
        //                day = day + 1;
        //                actd = Convert.ToDateTime(d.Rows[i - 1][0]).ToString("MM/dd/yyyy");
        //                if (d2 == actd)
        //                {
        //                    day = day + 1;
        //                    actd = Convert.ToDateTime(d.Rows[i - 2][0]).ToString("MM/dd/yyyy");
        //                    if (d3 == actd)
        //                    {
        //                        day = day + 1;
        //                        actd = Convert.ToDateTime(d.Rows[i - 3][0]).ToString("MM/dd/yyyy");
        //                        if (d4 == actd)
        //                        {
        //                            day = day + 1;
        //                            actd = Convert.ToDateTime(d.Rows[i - 4][0]).ToString("MM/dd/yyyy");
        //                            if (d5 == actd)
        //                            {
        //                                day = day + 1;
        //                                actd = Convert.ToDateTime(d.Rows[i - 5][0]).ToString("MM/dd/yyyy");
        //                            }
        //                        }
        //                    }
        //                }
        //            }
        //        }


        //    }


        //    if (datefound == 0)
        //    {
        //        ////MessageBox.Show("Pick yesterdays File");
        //        Final_Date = DateTime.Now.AddDays(-1).ToString("MM/dd/yyyy");
        //    }
        //    else
        //    {
        //        //MessageBox.Show("Pick " + (day + 1).ToString() + " Days before File");
        //        int t = 0;
        //        t = t - (day + 1);
        //        Final_Date = DateTime.Now.AddDays(t).ToString("MM/dd/yyyy");

        //    }
        //    }
        //    catch
        //    {
        //        //MessageBox.Show("");
        //    }

        //}
        //catch
        //{
        //    return null;

        //}

        //string[] Date = Final_Date.Split(' ');
        //if (Date[0].ToString().Contains("/"))
        //{
        //    string[] Date_Final = Date[0].Split('/');

        //    Final_Date = "";
        //    if (Date_Final[1].Length == 1 && Date_Final[0].Length == 2)
        //    {
        //        Final_Date = "0" + Date_Final[1] + Date_Final[0] + Date_Final[2];
        //    }
        //    else if (Date_Final[1].Length == 2 && Date_Final[0].Length == 1)
        //    {
        //        Final_Date = Date_Final[1] + "0" + Date_Final[0] + Date_Final[2];
        //    }
        //    else if (Date_Final[1].Length == 1 && Date_Final[0].Length == 1)
        //    {
        //        Final_Date = "0" + Date_Final[1] + "0" + Date_Final[0] + Date_Final[2];
        //    }
        //    else if (Date_Final[1].Length == 2 && Date_Final[0].Length == 2)
        //    {
        //        Final_Date = Date_Final[1] + Date_Final[0] + Date_Final[2];
        //    }
        //}
        //else if (Date[0].ToString().Contains("."))
        //{
        //    string[] Date_Final = Date[0].Split('.');

        //    Final_Date = "";
        //    if (Date_Final[1].Length == 1 && Date_Final[0].Length == 2)
        //    {
        //        Final_Date = "0" + Date_Final[1] + Date_Final[0] + Date_Final[2];
        //    }
        //    else if (Date_Final[1].Length == 2 && Date_Final[0].Length == 1)
        //    {
        //        Final_Date = Date_Final[1] + "0" + Date_Final[0] + Date_Final[2];
        //    }
        //    else if (Date_Final[1].Length == 1 && Date_Final[0].Length == 1)
        //    {
        //        Final_Date = "0" + Date_Final[1] + "0" + Date_Final[0] + Date_Final[2];
        //    }
        //    else if (Date_Final[1].Length == 2 && Date_Final[0].Length == 2)
        //    {
        //        Final_Date = Date_Final[1] + Date_Final[0] + Date_Final[2];
        //    }
        //}
        //else if (Date[0].ToString().Contains("-"))
        //{
        //    string[] Date_Final = Date[0].Split('-');

        //    Final_Date = "";
        //    if (Date_Final[1].Length == 1 && Date_Final[0].Length == 2)
        //    {
        //        Final_Date = "0" + Date_Final[1] + Date_Final[0] + Date_Final[2];
        //    }
        //    else if (Date_Final[1].Length == 2 && Date_Final[0].Length == 1)
        //    {
        //        Final_Date = Date_Final[1] + "0" + Date_Final[0] + Date_Final[2];
        //    }
        //    else if (Date_Final[1].Length == 1 && Date_Final[0].Length == 1)
        //    {
        //        Final_Date = "0" + Date_Final[1] + "0" + Date_Final[0] + Date_Final[2];
        //    }
        //    else if (Date_Final[1].Length == 2 && Date_Final[0].Length == 2)
        //    {
        //        Final_Date = Date_Final[1] + Date_Final[0] + Date_Final[2];
        //    }
        //}
        //DateTime myDate = DateTime.ParseExact(Final_Date, "ddMMyyyy", System.Globalization.CultureInfo.InvariantCulture);
        //Final_Date = myDate.ToString(Date_Format);

        //return Final_Date;




        public System.Data.DataTable ExecRemoveDuplicateRows(System.Data.DataTable table, string DistinctColumn)
        {
            try
            {
                ArrayList UniqueRecords = new ArrayList();
                ArrayList DuplicateRecords = new ArrayList();

                // Check if records is already added to UniqueRecords otherwise,
                // Add the records to DuplicateRecords
                foreach (DataRow dRow in table.Rows)
                {
                    if (UniqueRecords.Contains(dRow[DistinctColumn]))
                        DuplicateRecords.Add(dRow);
                    else
                        UniqueRecords.Add(dRow[DistinctColumn]);
                }

                // Remove duplicate rows from DataTable added to DuplicateRecords
                foreach (DataRow dRow in DuplicateRecords)
                {
                    table.Rows.Remove(dRow);
                }

                // Return the clean DataTable which contains unique records.
                return table;
            }
            catch
            {
                return null;
            }
        }




        public DataTable Select_Table(string strquery, Hashtable hat, string Query_Type)
        {
            DataTable dt = new DataTable();
            SqlConnection con = new SqlConnection(conString);
            SqlCommand cmd = new SqlCommand();

            try
            {
                con.Close();
                con.Open();
                SqlDataAdapter ad = new SqlDataAdapter(strquery, con);

                if (Query_Type.Trim().ToLower() == "sp")
                {
                    ad.SelectCommand.CommandType = CommandType.StoredProcedure;

                    foreach (DictionaryEntry hatval in hat)
                    {
                        ad.SelectCommand.Parameters.AddWithValue(hatval.Key.ToString(), hatval.Value.ToString());
                    }
                }
                else
                {
                    ad.SelectCommand.CommandType = CommandType.Text;
                }

                ad.Fill(dt);
            }
            catch
            {

            }
            finally
            {
                con.Close();
            }
            return dt;
        }
    }

}
