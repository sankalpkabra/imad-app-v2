﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.IO;
using System.Security.Cryptography;
using System.Collections;
using System.Text.RegularExpressions;
using System.Runtime.InteropServices;
using System.Data.OleDb;
using Microsoft.Office.Interop.Excel;

namespace ARC_Opics_DLL
{
    public class clsIndiaClearing
    {
        public System.Data.DataTable Select_Table(string strquery, Hashtable hat, string Query_Type, string conString)
        {
            System.Data.DataTable dt = new System.Data.DataTable();
            SqlConnection con = new SqlConnection(conString);
            SqlCommand cmd = new SqlCommand();

            try
            {
                con.Close();
                con.Open();
                SqlDataAdapter ad = new SqlDataAdapter(strquery, con);

                if (Query_Type.Trim().ToLower() == "sp")
                {
                    ad.SelectCommand.CommandType = CommandType.StoredProcedure;

                    foreach (DictionaryEntry hatval in hat)
                    {
                        ad.SelectCommand.Parameters.AddWithValue(hatval.Key.ToString(), hatval.Value.ToString());
                    }
                }
                else
                {
                    ad.SelectCommand.CommandType = CommandType.Text;
                }

                ad.Fill(dt);
            }
            catch
            {

            }
            finally
            {
                con.Close();
            }
            return dt;
        }
        public int ins_upd_fun(string strquery, Hashtable hat, string Query_type, string conString)
        {
            int insupval = 0;
            SqlConnection con = new SqlConnection(conString);
            SqlCommand cmd = new SqlCommand();

            try
            {
                con.Close();
                con.Open();
                cmd = new SqlCommand(strquery, con);
                if (Query_type == "sp")
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    foreach (DictionaryEntry hatval in hat)
                    {
                        cmd.Parameters.AddWithValue(hatval.Key.ToString(), hatval.Value.ToString());
                    }
                }
                else
                {
                    cmd.CommandType = CommandType.Text;
                }

                insupval = cmd.ExecuteNonQuery();
            }
            catch
            {

            }
            finally
            {
                con.Close();
            }
            return insupval;
        }
        public bool Text_File_Vaules_Checking(string strTextFilePath, int intMyDate, string strCheckingValues)
        {
            bool hasval = false;
            try
            {
                DateTime dtch = new DateTime(DateTime.Now.Year, 1, 1).AddDays(intMyDate - 1);

                if (intMyDate != 0)
                {
                    string date1 = string.Format("{0:MMdd}", dtch);
                    strCheckingValues = strCheckingValues + "~" + date1 + " - " + date1;
                }

                string[] spd = strCheckingValues.Split('~');

                StreamReader objReader = new StreamReader(strTextFilePath);
                string[] lines = System.IO.File.ReadAllLines(strTextFilePath);

                string temp = "";

                for (int i = 0; i <= lines.Length - 1; i++)
                {
                    temp = lines[i].ToString();
                    bool strRowHasValue = true;
                    if (spd.Length > 0)
                    {
                        for (int tsh = 0; tsh < spd.Length; tsh++)
                        {
                            if (spd[tsh].ToString().Trim() != "")
                            {
                                if (!temp.ToUpper().Contains(spd[tsh].ToString().ToUpper()))
                                {
                                    strRowHasValue = false;
                                    tsh = spd.Length + 1;
                                }
                            }
                        }
                    }
                    else
                    {
                        strRowHasValue = false;
                    }
                    if (strRowHasValue == true)
                    {
                        hasval = true;
                        i = lines.Length + 1;
                    }
                }
            }
            catch
            {

            }
            return hasval;
        }
        public static void Exec_Update_SheetNames(string Downloadpath)
        {
            try
            {
                string folderpath = "";                
                for (int i = 0; i < 3; i++)
                {
                    
                    //if (i == 0)
                    //{
                    //    folderpath = Downloadpath + "Input\\EBBS_India\\";
                    //}
                    if (i == 0)
                    {
                        folderpath = Downloadpath + "Input\\CTS-CHENNAI_India\\";
                    }
                    else if (i == 1)
                    {
                        folderpath = Downloadpath + "Input\\CTS-DELHI_India\\";
                    }
                    else if (i == 2)
                    {
                        folderpath = Downloadpath + "Input\\CTS-MUMBAI_India\\";
                    }
                    string[] files1 = Directory.GetFiles(folderpath, "*.xls", SearchOption.TopDirectoryOnly);

                    ArrayList list = new ArrayList();
                    foreach (string s in files1)
                    {
                        string ext = Path.GetExtension(s);
                        if (ext.ToUpper().Trim() != ".XLSX")
                        {
                            list.Add(s);
                        }
                    }
                    foreach (string s in list)
                    {
                        string laPath = s.ToString();

                        object oMissing = System.Reflection.Missing.Value;

                        Microsoft.Office.Interop.Excel.Application xl = new Microsoft.Office.Interop.Excel.Application();

                        Microsoft.Office.Interop.Excel.Workbook xlBook;
                        Microsoft.Office.Interop.Excel.Worksheet xlSheet;

                        xlBook = (Workbook)xl.Workbooks.Open(laPath, oMissing, oMissing, oMissing, oMissing, oMissing, oMissing, oMissing, oMissing, oMissing, oMissing, oMissing, oMissing, oMissing, oMissing);

                        xlSheet = (Worksheet)xlBook.Worksheets.get_Item(1);
                        xlSheet.Name = "India_Clearing";
                        xlBook.Save();
                        xl.Application.Workbooks.Close();
                    }
                }
                

            }
            catch (Exception ex)
            {                
            }
        }


        public void Formating_3_2(string ConnectionString, string StrDirectory, string Recon_name)
        {
            try
            {
                Hashtable hat = new Hashtable();
                int insupdaval = 0;
                string sDirectory = StrDirectory + DateTime.Now.ToString("dd-MMM-yyyy") + "_Files\\";
                if (Recon_name == "India Clearing")
                {
                    Exec_Update_SheetNames(sDirectory);
                }                
                //Recon_name = "India Clearing";
                string strquery = "select recon_name,recon_id,total_files,recon_date from Arc_Recon_Master_Holiday_Date_Logic where Is_Recon_Completed = 0 and Is_Active = 1 and recon_id in (select recon_id from arc_recon_master where Is_Recon_Completed = 0 and Is_Active = 1 and Is_Holiday_Logic = 1 and Recon_name in ('" + Recon_name + "')) order by recon_name,Recon_date";
                //'India Clearing Inward','India Clearing Outward'

                System.Data.DataTable  dtReconMaster = Select_Table(strquery, hat, "Text", ConnectionString);

                string strIInputFileName = string.Empty;
                string strOutPutFileName = string.Empty;
                string SourcePath = string.Empty;
                string Foramtted_Recon_Date = string.Empty;
                string strReconName = string.Empty;
                string Desti_Path = string.Empty;
                string Output_Path = string.Empty;
                string Recon_Date = string.Empty;
                string db_Ext = string.Empty;
                bool Flag_Recon = false;
                System.Data.DataTable  dt_MX1 = new System.Data.DataTable();
                System.Data.DataTable  dt_MX2 = new System.Data.DataTable ();
                System.Data.DataTable  dt_MX3 = new System.Data.DataTable ();
                System.Data.DataTable  dt_MX4 = new System.Data.DataTable ();
                System.Data.DataTable  dt_ken1 = new System.Data.DataTable ();
                System.Data.DataTable  dt_ken2 = new System.Data.DataTable ();
                System.Data.DataTable  dt_ken3 = new System.Data.DataTable ();
                System.Data.DataTable  dt_ken4 = new System.Data.DataTable ();
                System.Data.DataTable  dt_ken5 = new System.Data.DataTable ();
                System.Data.DataTable  dt_ken6 = new System.Data.DataTable ();
                System.Data.DataTable  CIS_LOT = new System.Data.DataTable ();
                System.Data.DataTable  CIS_SCB = new System.Data.DataTable ();
                System.Data.DataTable  CIS_Consol = new System.Data.DataTable ();
                for (int i = 0; i < dtReconMaster.Rows.Count; i++)
                {
                    Recon_name = Convert.ToString(dtReconMaster.Rows[i]["recon_name"]);
                    int Recon_Id = Convert.ToInt32(dtReconMaster.Rows[i]["recon_id"]);
                    int File_Count = Convert.ToInt32(dtReconMaster.Rows[i]["total_files"]);
                    DateTime dtRecondate = Convert.ToDateTime(dtReconMaster.Rows[i]["recon_date"]);

                    string selquery1 = "select distinct Recon_Date,Is_Recon_Completed from Arc_Recon_Master_Holiday_Date_Logic where recon_name ='" + Recon_name + "' order by Recon_date";
                    System.Data.DataTable dtsel1 = Select_Table(selquery1, hat, "Text", ConnectionString);

                    int ProcessedFileCount = 0;

                    if (Recon_name == "India Clearing Outward" || Recon_name == "India Clearing Inward" || Recon_name == "India Clearing")
                    {
                        string selquery = "select top(1) Report_Source_File_Name,Recon_Date,IsProcessed,automationStatus from arc_scope_baseline_logic where recon ='" + Recon_name + "' order by Recon_date";
                        System.Data.DataTable dtsel = Select_Table(selquery, hat, "Text", ConnectionString);

                        if (dtsel.Rows[0]["IsProcessed"].ToString().ToLower() == "false")
                        {
                            if (Recon_name != "India Clearing Outward" && Recon_name != "India Clearing Inward" && Recon_name != "India Clearing")
                            {
                                i++;
                                continue;
                            }
                        }
                        strquery = "select Team, Country_Name, Recon, Report_Source_File_Name,FTP_File_Format_Name, Recon_date from ARC_Scope_Baseline_Logic where recon_id in (select recon_id from arc_recon_master where Is_Recon_Completed = 0 and Is_Active = 1 and Is_Holiday_Logic = 1) and recon_date='" + dtRecondate.ToString("MM/dd/yyyy") + "' ";

                        System.Data.DataTable dtBaseHoliday = Select_Table(strquery, hat, "Text", ConnectionString);

                        strquery = "update Arc_Recon_Master_Holiday_Date_Logic set PSID = '" + Environment.UserName + "',AutomationStartTime='" + DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss") + "' where Recon_Id = " + Recon_Id + " and recon_date='" + dtRecondate.ToString("MM/dd/yyyy") + "'";
                        insupdaval = ins_upd_fun(strquery, hat, "text", ConnectionString);

                        strquery = "select * from Arc_Scope_Baseline where recon='" + Recon_name + "'";
                        System.Data.DataTable dtScopeBaseline = Select_Table(strquery, hat, "Text", ConnectionString);

                        DataRow[] dr = dtScopeBaseline.Select("Format_Direct_Upload <> 'Formatting'");
                        DataRow[] dr2 = dtScopeBaseline.Select("Format_Direct_Upload = 'Formatting'");

                        foreach (DataRow d in dr)
                        {

                            strIInputFileName = "";
                            strOutPutFileName = "";
                            string Country = Convert.ToString(d["Country_Name"]);
                            string File_Name = Convert.ToString(d["Report_Source_File_Name"]);
                            string IsFormatting = Convert.ToString(d["Format_Direct_Upload"]);
                            string Source_App = Convert.ToString(d["Source_Application"]);
                            string File_Ext = Convert.ToString(d["File_Format"]);
                            string Formatted_File_Name = Convert.ToString(d["FTP_File_Format_Name"]);
                            string AutomationStatus = Convert.ToString(d["AutomationStatus"]);
                            strReconName = Convert.ToString(d["recon"]);

                            SourcePath = StrDirectory + "Input\\" + Source_App + "_" + Country + "\\";
                            Desti_Path = StrDirectory + "output\\" + strReconName + "\\";

                            string filerquery = "Country_name='" + Country + "' and recon='" + strReconName + "' and Report_Source_File_Name='" + File_Name + "'";

                            if (Formatted_File_Name != null)
                            {
                                if (Formatted_File_Name.Trim().ToUpper() != "NULL")
                                {
                                    filerquery = filerquery + " and FTP_File_Format_Name='" + Formatted_File_Name + "'";
                                }
                            }

                            if (File_Name.ToUpper().Contains("DDMMYYYY") && !File_Name.ToUpper().Contains("YYYYMMDD"))
                            {
                                Recon_Date = dtRecondate.ToString("ddMMyyyy");
                                File_Name = File_Name.Replace("DDMMYYYY", Recon_Date) + "." + File_Ext;
                                strIInputFileName = File_Name;
                                strOutPutFileName = File_Name;
                            }
                            else if (File_Name.ToUpper().Contains("DD.MM.YYYY"))
                            {
                                Recon_Date = dtRecondate.ToString("dd.MM.yyyy");
                                File_Name = File_Name.Replace("DD.MM.YYYY", Recon_Date) + "." + File_Ext;
                                Formatted_File_Name = Formatted_File_Name.Replace("DD.MM.YYYY", Recon_Date);
                                strIInputFileName = File_Name;
                                strOutPutFileName = Formatted_File_Name;
                            }
                            else if (File_Name.ToUpper().Contains("DD.MM.YY"))
                            {
                                Recon_Date = dtRecondate.ToString("dd.MM.yy");
                                File_Name = File_Name.Replace("DD.MM.YY", Recon_Date) + "." + File_Ext;
                                Formatted_File_Name = Formatted_File_Name.Replace("DD.MM.YY", Recon_Date);
                                strIInputFileName = File_Name;
                                strOutPutFileName = Formatted_File_Name;
                            }
                            else if (File_Name.ToUpper().Contains("YYMMDD") && !File_Name.ToUpper().Contains("YYYYMMDD"))
                            {
                                Recon_Date = dtRecondate.ToString("yyMMdd");
                                File_Name = File_Name.Replace("YYMMDD", Recon_Date) + "." + File_Ext;
                                strIInputFileName = File_Name;
                                strOutPutFileName = File_Name;
                            }
                            else if (File_Name.ToUpper().Contains("DDMMYY") && !File_Name.ToUpper().Contains("YYYYMMDD"))
                            {
                                Recon_Date = dtRecondate.ToString("ddMMyy");
                                File_Name = File_Name.Replace("DDMMYY", Recon_Date) + "." + File_Ext;
                                strIInputFileName = File_Name;
                                strOutPutFileName = File_Name;
                            }
                            else if (File_Name.ToUpper().Contains("YYYYMMDD"))
                            {
                                Recon_Date = dtRecondate.ToString("yyyyMMdd");
                                File_Name = File_Name.Replace("YYYYMMDD", Recon_Date) + "." + File_Ext;
                                strIInputFileName = File_Name;
                                strOutPutFileName = File_Name;
                            }
                            else if (File_Name.ToUpper().Contains("DDMMM"))
                            {
                                Recon_Date = dtRecondate.ToString("ddMMM");
                                File_Name = File_Name.Replace("DDMMM", Recon_Date) + "." + File_Ext;
                                strIInputFileName = File_Name;
                                strOutPutFileName = File_Name;
                            }
                            else if (File_Name.ToUpper().Contains("DD-MM-YYYY"))
                            {
                                Recon_Date = dtRecondate.ToString("dd-MM-yyyy");
                                File_Name = File_Name.Replace("DD-MM-YYYY", Recon_Date) + "." + File_Ext;
                                strIInputFileName = File_Name;
                                strOutPutFileName = File_Name;
                            }
                            if (strIInputFileName.Trim() != "" && strOutPutFileName.Trim() != "")
                            {
                                if (File.Exists(SourcePath + strIInputFileName))
                                {
                                    GC.Collect();
                                    File.Copy(SourcePath + strIInputFileName, Desti_Path + strOutPutFileName, true);
                                    ProcessedFileCount++;
                                }
                            }
                        }
                        /////////////////////////////////////////// Formatting Logic /////////////////////////////////////
                        bool Flag1 = false;
                        bool Flag2 = false;
                        bool Flag3 = false;
                        foreach (DataRow d in dr2)
                        {
                            string Country = Convert.ToString(d[4]);
                            string File_Name = Convert.ToString(d[9]);
                            string IsFormatting = Convert.ToString(d[16]);
                            string Source_App = Convert.ToString(d[11]);
                            string File_Ext = Convert.ToString(d[15]);
                            string Formatted_File_Name = Convert.ToString(d[10]);
                            string intrimpath;


                            SourcePath = StrDirectory + "Input\\" + Source_App + "_" + Country + "\\";
                            Desti_Path = StrDirectory + "output\\" + strReconName + "\\";
                            intrimpath = StrDirectory + "Files_For_Formatting_Or_Non_Formatting" + "\\";

                            if (File_Name.ToUpper().Contains("DDMMM") && !File_Name.ToUpper().Contains("DDMMMYYYY"))
                            {
                                Recon_Date = dtRecondate.ToString("ddMMM");
                                File_Name = File_Name.Replace("DDMMM", Recon_Date);
                                strIInputFileName = File_Name;
                                strOutPutFileName = File_Name;
                            }
                            if (File_Name.ToUpper().Contains("DDMMMYYYY"))
                            {
                                Recon_Date = dtRecondate.ToString("ddMMMyyyy");
                                File_Name = File_Name.Replace("DDMMMYYYY", Recon_Date);
                                strIInputFileName = File_Name;
                                strOutPutFileName = File_Name;
                            }
                            if (File_Name.ToUpper().Contains("DD MM YY"))
                            {
                                Recon_Date = dtRecondate.ToString("dd MM yy");
                                File_Name = File_Name.Replace("DD MM YY", Recon_Date);
                                strIInputFileName = File_Name;
                                strOutPutFileName = Formatted_File_Name;
                            }
                            if (File_Name.ToUpper().Contains("DD MMM YY"))
                            {
                                Recon_Date = dtRecondate.ToString("dd MMM yy");
                                File_Name = File_Name.Replace("DD MMM YY", Recon_Date);
                                strIInputFileName = File_Name;
                                strOutPutFileName = Formatted_File_Name;
                            }
                            else if (File_Name.ToUpper().Contains("DD-MMM"))
                            {
                                Recon_Date = dtRecondate.ToString("dd-MMM");
                                File_Name = File_Name.Replace("DD-MMM", Recon_Date);
                                strIInputFileName = File_Name;
                                strOutPutFileName = File_Name;
                            }
                            else if (File_Name.ToUpper().Contains("DD-MM-YYYY"))
                            {
                                Recon_Date = dtRecondate.ToString("dd-MM-yyyy");
                                File_Name = File_Name.Replace("DD-MM-YYYY", Recon_Date);
                                strIInputFileName = File_Name;
                                strOutPutFileName = File_Name;
                            }
                            else if (File_Name.ToUpper().Contains("DD-MM"))
                            {
                                Recon_Date = dtRecondate.ToString("dd-MM");
                                File_Name = File_Name.Replace("DD-MM", Recon_Date);
                                strIInputFileName = File_Name;
                                strOutPutFileName = File_Name;
                            }
                            else if (File_Name.ToUpper().Contains("MMM.YYYY"))
                            {
                                Recon_Date = dtRecondate.ToString("MMM.yyyy");
                                File_Name = File_Name.Replace("MMM.YYYY", Recon_Date);
                                Formatted_File_Name = Formatted_File_Name.Replace("MMM.YYYY", Recon_Date);
                                strIInputFileName = File_Name;
                                strOutPutFileName = Formatted_File_Name;
                            }
                            else if (File_Name.ToUpper().Contains("DDMMYYYY"))
                            {
                                Recon_Date = dtRecondate.ToString("ddMMyyyy");
                                File_Name = File_Name.Replace("DDMMYYYY", Recon_Date);
                                strIInputFileName = File_Name;
                                strOutPutFileName = File_Name;
                            }
                            else if (File_Name.ToUpper().Contains("DDMMYY"))
                            {
                                Recon_Date = dtRecondate.ToString("ddMMyy");
                                File_Name = File_Name.Replace("DDMMYY", Recon_Date);
                                Formatted_File_Name = Formatted_File_Name.Replace("DDMMYY", Recon_Date);
                                strIInputFileName = File_Name;
                                strOutPutFileName = Formatted_File_Name;

                            }
                            else if (File_Name.ToUpper().Contains("YYYY-MM-DD"))
                            {
                                Recon_Date = dtRecondate.ToString("yyyy-MM-dd");
                                File_Name = File_Name.Replace("YYYY-MM-DD", Recon_Date);
                                Recon_Date = dtRecondate.ToString("ddMMyyyy");
                                Formatted_File_Name = Formatted_File_Name.Replace("DDMMYYYY", Recon_Date);
                                strIInputFileName = File_Name;
                                strOutPutFileName = Formatted_File_Name;
                            }
                            else if (File_Name.ToUpper().Contains("MM-DD-YYYY"))
                            {
                                Recon_Date = dtRecondate.ToString("MM-dd-yyyy");
                                File_Name = File_Name.Replace("MM-DD-YYYY", Recon_Date);
                                strIInputFileName = File_Name;
                                strOutPutFileName = File_Name;
                            }
                            else if (File_Name.ToUpper().Contains("MMDDYYYY"))
                            {
                                Recon_Date = dtRecondate.ToString("MMddyyyy").ToUpper();
                                File_Name = File_Name.Replace("MMDDYYYY", Recon_Date);
                                strIInputFileName = File_Name;
                            }
                            else if (File_Name.ToUpper().Contains("YYYY-MM"))
                            {
                                Recon_Date = dtRecondate.ToString("yyyy-MM").ToUpper();
                                File_Name = File_Name.Replace("YYYY-MM", Recon_Date).Trim();
                                Recon_Date = dtRecondate.ToString("ddMMyyyy").ToUpper();
                                Formatted_File_Name = Formatted_File_Name.Replace("DDMMYYYY", Recon_Date).Trim();
                                strIInputFileName = File_Name.Trim();
                                strOutPutFileName = Formatted_File_Name;
                            }
                            else if (File_Name.ToUpper().Contains("DD_MMM"))
                            {
                                Recon_Date = dtRecondate.ToString("dd_MMM");
                                File_Name = File_Name.Replace("DD_MMM", Recon_Date) + "." + File_Ext;
                            }
                            else if (File_Name.ToUpper().Contains("DD.MM.YYYY"))
                            {
                                Recon_Date = dtRecondate.ToString("dd.MM.yyyy");
                                File_Name = File_Name.Replace("DD.MM.YYYY", Recon_Date);
                            }
                            ///Formatted FileName


                            if (Formatted_File_Name.ToUpper().Contains("DD.MM.YYYY"))
                            {
                                string ext = "";
                                ext = Formatted_File_Name.Substring(Formatted_File_Name.LastIndexOf("."));
                                Formatted_File_Name = Formatted_File_Name.Replace(ext, "");
                                Formatted_File_Name = Formatted_File_Name.Remove(Formatted_File_Name.Length - 10);
                                Foramtted_Recon_Date = dtRecondate.ToString("dd.MM.yyyy");
                                Formatted_File_Name = Formatted_File_Name + Foramtted_Recon_Date + ext;
                            }
                            else if (Formatted_File_Name.ToUpper().Contains("YYYYMMDD"))
                            {
                                string ext = "";
                                ext = Formatted_File_Name.Substring(Formatted_File_Name.LastIndexOf("."));
                                Formatted_File_Name = Formatted_File_Name.Replace(ext, "");
                                Formatted_File_Name = Formatted_File_Name.Remove(Formatted_File_Name.Length - 8);
                                Foramtted_Recon_Date = dtRecondate.ToString("yyyyMMdd");
                                Formatted_File_Name = Formatted_File_Name + Foramtted_Recon_Date + ext;
                            }
                            else if (Formatted_File_Name.ToUpper().Contains("DDMMYYYY"))
                            {
                                string ext = "";
                                ext = Formatted_File_Name.Substring(Formatted_File_Name.LastIndexOf("."));
                                Formatted_File_Name = Formatted_File_Name.Replace(ext, "");
                                Formatted_File_Name = Formatted_File_Name.Remove(Formatted_File_Name.Length - 8);
                                Foramtted_Recon_Date = dtRecondate.ToString("ddMMyyyy");
                                Recon_Date = dtRecondate.ToString("ddMMyyyy");
                                Formatted_File_Name = Formatted_File_Name + Foramtted_Recon_Date + ext;
                            }

                            if (!string.IsNullOrEmpty(File_Ext))
                                SourcePath = sDirectory + "Input\\" + Source_App + "_" + Country + "\\" + "\\" + File_Name + "." + File_Ext;
                            else
                                SourcePath = sDirectory + "Input\\" + Source_App + "_" + Country + "\\" + "\\" + File_Name;


                            Desti_Path = sDirectory + "Files_For_Formatting_Or_Non_Formatting\\" + Recon_name + "\\Formatting\\";
                            Output_Path = sDirectory + "Output\\" + Recon_name + "\\";

                            if (Recon_name == "India Clearing")
                            {
                                if (Flag1 == false)
                                {
                                    India_Clearing_Recon(SourcePath, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, File_Name, File_Ext, StrDirectory, out Flag1);
                                    ProcessedFileCount = ProcessedFileCount + 36;                                    
                                }
                            }
                            else if (Recon_name == "India Clearing Inward")
                            {
                                if (Flag2 == false)
                                {
                                    India_Clearing_Inward(SourcePath, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, File_Name, File_Ext, StrDirectory, out Flag2);
                                    ProcessedFileCount = ProcessedFileCount + 18;                                    
                                }
                            }
                            else if (Recon_name == "India Clearing Outward")
                            {
                                if (Flag3 == false)
                                {
                                    India_Clearing_Outward(SourcePath, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, File_Name, File_Ext, StrDirectory, out Flag3);
                                    ProcessedFileCount = ProcessedFileCount + 12;                                    
                                }
                            }
                        }
                        if (File_Count == ProcessedFileCount)
                        {
                            strquery = "update Arc_Recon_Master_Holiday_Date_Logic set Is_Recon_Completed = 1, Recon_Status = 'COMPLETED', AutomationEndTime='" + DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss") + "' where Recon_Id = " + Recon_Id + " and Recon_date='" + dtRecondate.ToString("MM/dd/yyyy") + "'";
                            insupdaval = ins_upd_fun(strquery, hat, "text", ConnectionString);
                        }
                        else
                        {
                            strquery = "update Arc_Recon_Master_Holiday_Date_Logic set Is_Recon_Completed = 0, Recon_Status = 'File Count Mismatch', AutomationEndTime='" + DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss") + "' where Recon_Id = " + Recon_Id + " and Recon_date='" + dtRecondate.ToString("MM/dd/yyyy") + "'";
                            insupdaval = ins_upd_fun(strquery, hat, "text", ConnectionString);
                        }

                    }

                }
            }
            catch (Exception ex)
            {

            }
        }
        public void India_Clearing_Outward(string filePath1, string Recon_Dt, string DestPath, string Recon_Name, string SharePath, string Formatted_File_Name, string File_Name, string ext, string pt1, out bool Flag)
        {
            DateTime dateTime = DateTime.Now;
            string pt = filePath1.Substring(0, filePath1.LastIndexOf("\\"));
            DateTime myDate = DateTime.ParseExact(Recon_Dt, "ddMMyyyy", System.Globalization.CultureInfo.InvariantCulture);

            DateTime myRecconDate = DateTime.ParseExact(Recon_Dt, "ddMMyyyy", System.Globalization.CultureInfo.InvariantCulture);
            string strRecconDate = myRecconDate.ToString("ddMMyyyy");

            string[] files2 = System.IO.Directory.GetFiles(pt1 + dateTime.ToString("dd-MMM-yyyy") + "_Files\\" + @"Input\CTS-CHENNAI_India\");
            string[] files3 = System.IO.Directory.GetFiles(pt1 + dateTime.ToString("dd-MMM-yyyy") + "_Files\\" + @"Input\CTS-DELHI_India\");
            string[] files4 = System.IO.Directory.GetFiles(pt1 + dateTime.ToString("dd-MMM-yyyy") + "_Files\\" + @"Input\CTS-MUMBAI_India\");
            string[] fname1 = new string[100];
            string[] fname2 = new string[100];
            string[] fname3 = new string[100];
            string[] input_file1 = new string[100];
            string[] input_file2 = new string[100];
            string[] input_file3 = new string[100];
            string[] input_file4 = new string[100];
            string[] input_file5 = new string[100];
            string[] input_file6 = new string[100];

            //cts-chennai
            for (int i = 0; i < files2.Length; i++)
            {
                fname1[i] = Path.GetFileName(files2[i]);
            }

            //cts-mumbai
            for (int i = 0; i < files4.Length; i++)
            {
                fname2[i] = Path.GetFileName(files4[i]);
            }

            //cts - delhi
            for (int i = 0; i < files3.Length; i++)
            {
                fname3[i] = Path.GetFileName(files3[i]);
            }
            //output-chennai-outward
            string CTS_SCB_CHN_CLG_OUTRTN_CB_FTP = SharePath + "SCB_CHN_CLG_OUTRTN_CB_FTP_" + strRecconDate + ".csv";
            string CB_SCB_CHN_CLG_OUT_CB_FTP = SharePath + "SCB_CHN_CLG_OUT_CB_FTP_" + strRecconDate + ".csv";

            //output-mumbai-outward        
            string CB_SCB_MUM_CLG_OUT_CB_FTP = SharePath + "SCB_MUM_CLG_OUT_CB_FTP_" + strRecconDate + ".csv";
            string CTS_SCB_MUM_CLG_OUTRTN_CB_FTP = SharePath + "SCB_MUM_CLG_OUTRTN_CB_FTP_" + strRecconDate + ".csv";

            //output-delhi-outward
            string CB_SCB_DEL_CLG_OUT_CB_FTP = SharePath + "SCB_DEL_CLG_OUT_CB_FTP_" + strRecconDate + ".csv";
            string CTS_SCB_DEL_CLG_OUTRTN_CB_FTP = SharePath + "SCB_DEL_CLG_OUTRTN_CB_FTP_" + strRecconDate + ".csv";
            int j = 0;
            //chennai************
            //CTS_SCB_CHN_CLG_OUTRTN_CB_FTP
            j = 0;
            for (int i = 0; i < files2.Length; i++)
            {
                if ((fname1[i].Contains("CHN_RFReport_") && fname1[i].Contains(myDate.ToString("yyyyMMdd"))) || (fname1[i].Contains("CHN_NCTS_RFReport_") && fname1[i].Contains(myDate.ToString("yyyyMMdd"))))
                {
                    input_file1[j] = files2[i].ToString();
                    j++;
                }


            }
            if (input_file1[0] != null)
            {
                sheetcount(input_file1, CTS_SCB_CHN_CLG_OUTRTN_CB_FTP);
            }
            //CB_SCB_CHN_CLG_OUT_CB_FTP
            j = 0;
            for (int i = 0; i < files2.Length; i++)
            {
                if ((fname1[i].Contains("CHN_OWDETAILReport_1_") && fname1[i].Contains(myDate.ToString("yyyyMMdd"))) || (fname1[i].Contains("CHN_NCTS_OWDETAILReport_11_") && fname1[i].Contains(myDate.ToString("yyyyMMdd"))))
                {

                    input_file2[j] = files2[i].ToString();
                    j++;


                }
            }
            if (input_file2[0] != null)
            {
                sheetcount(input_file2, CB_SCB_CHN_CLG_OUT_CB_FTP);
            }
            // Mumbai************
            ////CTS_SCB_MUM_CLG_OUTRTN_CB_FTP

            j = 0;
            for (int i = 0; i < files4.Length; i++)
            {
                if ((fname2[i].Contains("MUM_RFReport_") && fname2[i].Contains(myDate.ToString("yyyyMMdd"))) || (fname2[i].Contains("MUM_NCTS_RFReport_") && fname2[i].Contains(myDate.ToString("yyyyMMdd"))))
                {

                    input_file3[j] = files4[i].ToString();
                    j++;

                }
            }

            //Array.Sort(input_file20);
            if (input_file3[0] != null)
            {
                sheetcount(input_file3, CTS_SCB_MUM_CLG_OUTRTN_CB_FTP);
            }
            //CB_SCB_MUM_CLG_OUT_CB_FTP
            j = 0;
            for (int i = 0; i < files4.Length; i++)
            {
                if ((fname2[i].Contains("MUM_OWDETAILReport_1_") && fname2[i].Contains(myDate.ToString("yyyyMMdd"))) || (fname2[i].Contains("MUM_NCTS_OWDETAILReport_11_") && fname2[i].Contains(myDate.ToString("yyyyMMdd"))))
                {

                    input_file4[j] = files4[i].ToString();
                    j++;


                }
            }
            if (input_file4[0] != null)
            {
                sheetcount(input_file4, CB_SCB_MUM_CLG_OUT_CB_FTP);
            }
            //Delhi ************

            //CB_SCB_DEL_CLG_OUT_CB_FTP
            j = 0;
            for (int i = 0; i < files3.Length; i++)
            {
                if ((fname3[i].Contains("DEL_OWDETAILReport_1_") && fname3[i].Contains(myDate.ToString("yyyyMMdd"))) || (fname3[i].Contains("DEL_NCTS_OWDETAILReport_11_") && fname3[i].Contains(myDate.ToString("yyyyMMdd"))))
                {

                    input_file5[j] = files3[i].ToString();
                    j++;


                }
            }
            if (input_file5[0] != null)
            {
                sheetcount(input_file5, CB_SCB_DEL_CLG_OUT_CB_FTP);
            }
            // CTS_SCB_DEL_CLG_OUTRTN_CB_FTP
            j = 0;
            for (int i = 0; i < files3.Length; i++)
            {
                if ((fname3[i].Contains("DEL_RFReport_") && fname3[i].Contains(myDate.ToString("yyyyMMdd"))) || (fname3[i].Contains("DEL_NCTS_RFReport_") && fname3[i].Contains(myDate.ToString("yyyyMMdd"))))
                {

                    input_file6[j] = files3[i].ToString();
                    j++;

                }
            }
            if (input_file6[0] != null)
            {
                sheetcount(input_file6, CTS_SCB_DEL_CLG_OUTRTN_CB_FTP);
            }
            Flag = true;
        }
        public void India_Clearing_Inward(string filePath1, string Recon_Dt, string DestPath, string Recon_Name, string SharePath, string Formatted_File_Name, string File_Name, string ext, string pt1, out bool Flag)
        {
            DateTime dateTime = DateTime.Now;
            string pt = filePath1.Substring(0, filePath1.LastIndexOf("\\"));
            DateTime myDate = DateTime.ParseExact(Recon_Dt, "ddMMyyyy", System.Globalization.CultureInfo.InvariantCulture);

            DateTime myRecconDate = DateTime.ParseExact(Recon_Dt, "ddMMyyyy", System.Globalization.CultureInfo.InvariantCulture);
            myRecconDate = myRecconDate.AddDays(1);
            string strRecconDate = myRecconDate.ToString("ddMMyyyy");

            string[] files2 = System.IO.Directory.GetFiles(pt1 + dateTime.ToString("dd-MMM-yyyy") + "_Files\\" + @"Input\CTS-CHENNAI_India\");
            string[] files3 = System.IO.Directory.GetFiles(pt1 + dateTime.ToString("dd-MMM-yyyy") + "_Files\\" + @"Input\CTS-DELHI_India\");
            string[] files4 = System.IO.Directory.GetFiles(pt1 + dateTime.ToString("dd-MMM-yyyy") + "_Files\\" + @"Input\CTS-MUMBAI_India\");
            string[] fname1 = new string[100];
            string[] fname2 = new string[100];
            string[] fname3 = new string[100];
            //cts-chennai
            for (int i = 0; i < files2.Length; i++)
            {
                fname1[i] = Path.GetFileName(files2[i]);
            }

            //cts-mumbai
            for (int i = 0; i < files4.Length; i++)
            {
                fname2[i] = Path.GetFileName(files4[i]);
            }

            //cts - delhi
            for (int i = 0; i < files3.Length; i++)
            {
                fname3[i] = Path.GetFileName(files3[i]);
            }

            string[] input_file1 = new string[100];
            string[] input_file2 = new string[100];
            string[] input_file3 = new string[100];
            string[] input_file4 = new string[100];
            string[] input_file5 = new string[100];
            string[] input_file6 = new string[100];
            string[] input_file7 = new string[100];
            string[] input_file8 = new string[100];
            string[] input_file9 = new string[100];
            // Output chennai - inward :
            string CTS_SCB_CHN_CLG_IN_CB_FTP = SharePath + "SCB_CHN_CLG_IN_CB_FTP_" + strRecconDate + ".csv";
            string CTS_SCB_CHN_CLG_IN_CBDMY_FTP = SharePath + "SCB_CHN_CLG_IN_CBDMY_FTP_" + strRecconDate + ".csv";
            string CTS_SCB_CHN_CLG_INRTN_CB_FTP = SharePath + "SCB_CHN_CLG_INRTN_CB_FTP_" + strRecconDate + ".csv";
            // Output mumbai - inward:
            string CTS_SCB_MUM_CLG_IN_CB_FTP = SharePath + "SCB_MUM_CLG_IN_CB_FTP_" + strRecconDate + ".csv";
            string CTS_SCB_MUM_CLG_IN_CBDMY_FTP = SharePath + "SCB_MUM_CLG_IN_CBDMY_FTP_" + strRecconDate + ".csv";
            string CTS_SCB_MUM_CLG_INRTN_CB_FTP = SharePath + "SCB_MUM_CLG_INRTN_CB_FTP_" + strRecconDate + ".csv";
            //Output delhi-inward:
            string CTS_SCB_DEL_CLG_IN_CB_FTP = SharePath + "SCB_DEL_CLG_IN_CB_FTP_" + strRecconDate + ".csv";
            string CTS_SCB_DEL_CLG_IN_CBDMY_FTP = SharePath + "SCB_DEL_CLG_IN_CBDMY_FTP_" + strRecconDate + ".csv";
            string CTS_SCB_DEL_CLG_INRTN_CB_FTP = SharePath + "SCB_DEL_CLG_INRTN_CB_FTP_" + strRecconDate + ".csv";
            //chennai:*****************
            int j = 0;
            // CTS_SCB_CHN_CLG_IN_CB_FTP
            j = 0;
            for (int i = 0; i < files2.Length; i++)
            {
                if ((fname1[i].Contains("CHN_AUDITReport_1_") && fname1[i].Contains(myDate.ToString("yyyyMMdd"))) || (fname1[i].Contains("CHN_NCTS_AUDITReport_11_") && fname1[i].Contains(myDate.ToString("yyyyMMdd"))))
                {

                    input_file1[j] = files2[i].ToString();
                    j++;

                }
            }
            if (input_file1[0] != null)
            {
                sheetcount(input_file1, CTS_SCB_CHN_CLG_IN_CB_FTP);
            }
            ////CTS_SCB_CHN_CLG_IN_CBDMY_FTP

            j = 0;
            for (int i = 0; i < files2.Length; i++)
            {
                if ((fname1[i].Contains("CHN_RepairedItemReport_600_1_") && fname1[i].Contains(myDate.ToString("yyyyMMdd"))) || (fname1[i].Contains("CHN_NCTS_RepairedItemReport_600_11_") && fname1[i].Contains(myDate.ToString("yyyyMMdd"))))
                {

                    input_file2[j] = files2[i].ToString();
                    j++;


                }
            }
            if (input_file2[0] != null)
            {
                sheetcount(input_file2, CTS_SCB_CHN_CLG_IN_CBDMY_FTP);
                ///CTS_SCB_CHN_CLG_INRTN_CB_FTP
            }
            j = 0;
            for (int i = 0; i < files2.Length; i++)
            {
                if ((fname1[i].Contains("CHN_GW") && fname1[i].Contains(myDate.ToString("yyyyMMdd")) && fname1[i].Contains("_600RRFREQRPT")) || (fname1[i].Contains("CHN_NCTS_GW") && fname1[i].Contains(myDate.ToString("yyyyMMdd")) && fname1[i].Contains("_600RRFREQRPT")))
                {

                    input_file3[j] = files2[i].ToString();
                    j++;


                }
            }
            if (input_file3[0] != null)
            {
                sheetcount(input_file3, CTS_SCB_CHN_CLG_INRTN_CB_FTP);
            }
            //mumbai ********************

            //// CTS_SCB_MUM_CLG_IN_CB_FTP

            j = 0;
            for (int i = 0; i < files4.Length; i++)
            {
                if ((fname2[i].Contains("MUM_AUDITReport_1_") && fname2[i].Contains(myDate.ToString("yyyyMMdd"))) || (fname2[i].Contains("MUM_NCTS_AUDITReport_11_") && fname2[i].Contains(myDate.ToString("yyyyMMdd"))))
                {
                    input_file4[j] = files4[i].ToString();
                    j++;
                }
            }

            if (input_file4[0] != null)
            {
                sheetcount(input_file4, CTS_SCB_MUM_CLG_IN_CB_FTP);
            }
            ////CTS_SCB_MUM_CLG_IN_CBDMY_FTP

            j = 0;
            for (int i = 0; i < files4.Length; i++)
            {
                if ((fname2[i].Contains("MUM_RepairedItemReport_1_") && fname2[i].Contains(myDate.ToString("yyyyMMdd"))) || (fname2[i].Contains("MUM_NCTS_RepairedItemReport_11_") && fname2[i].Contains(myDate.ToString("yyyyMMdd"))))
                {

                    input_file5[j] = files4[i].ToString();
                    j++;

                }
            }
            if (input_file5[0] != null)
            {
                sheetcount(input_file5, CTS_SCB_MUM_CLG_IN_CBDMY_FTP);
            }
            ////CTS_SCB_MUM_CLG_INRTN_CB_FTP


            j = 0;
            for (int i = 0; i < files4.Length; i++)
            {
                if ((fname2[i].Contains("MUM_GW") && fname2[i].Contains(myDate.ToString("yyyyMMdd")) && fname2[i].Contains("RRFREQRPT")) || (fname2[i].Contains("MUM_NCTS_GW") && fname2[i].Contains(myDate.ToString("yyyyMMdd")) && fname2[i].Contains("RRFREQRPT")))
                {

                    input_file6[j] = files4[i].ToString();
                    j++;

                }
            }
            if (input_file6[0] != null)
            {
                sheetcount(input_file6, CTS_SCB_MUM_CLG_INRTN_CB_FTP);
            }
            //delhi********************


            //CTS_SCB_DEL_CLG_IN_CB_FTP

            j = 0;
            for (int i = 0; i < files3.Length; i++)
            {
                if ((fname3[i].Contains("DEL_AUDITReport_1_") && fname3[i].Contains(myDate.ToString("yyyyMMdd"))) || (fname3[i].Contains("DEL_NCTS_AUDITReport_11_") && fname3[i].Contains(myDate.ToString("yyyyMMdd"))))
                {

                    input_file7[j] = files3[i].ToString();
                    j++;

                }
            }
            if (input_file7[0] != null)
            {
                sheetcount(input_file7, CTS_SCB_DEL_CLG_IN_CB_FTP);
            }
            //CTS_SCB_DEL_CLG_IN_CBDMY_FTP
            j = 0;
            for (int i = 0; i < files3.Length; i++)
            {
                if ((fname3[i].Contains("DEL_RepairedItemReport_1_") && fname3[i].Contains(myDate.ToString("yyyyMMdd"))) || (fname3[i].Contains("DEL_NCTS_RepairedItemReport_11_") && fname3[i].Contains(myDate.ToString("yyyyMMdd"))))
                {

                    input_file8[j] = files3[i].ToString();
                    j++;

                }
            }
            if (input_file8[0] != null)
            {
                sheetcount(input_file8, CTS_SCB_DEL_CLG_IN_CBDMY_FTP);
            }
            //// CTS_SCB_DEL_CLG_INRTN_CB_FTP
            j = 0;
            for (int i = 0; i < files3.Length; i++)
            {
                if ((fname3[i].Contains("DEL_GW") && fname3[i].Contains(myDate.ToString("yyyyMMdd")) && fname3[i].Contains("RRFREQRPT")) || (fname3[i].Contains("DEL_NCTS_GW") && fname3[i].Contains(myDate.ToString("yyyyMMdd")) && fname3[i].Contains("RRFREQRPT")))
                {

                    input_file9[j] = files3[i].ToString();
                    j++;

                }
            }
            if (input_file9[0] != null)
            {
                sheetcount(input_file9, CTS_SCB_DEL_CLG_INRTN_CB_FTP);
            }

            Flag = true;
        }
        public void India_Clearing_Recon(string filePath1, string Recon_Dt, string DestPath, string Recon_Name, string SharePath, string Formatted_File_Name, string File_Name, string ext, string pt1, out bool Flag)
        {

            DateTime dateTime = DateTime.Now;

            string pt = filePath1.Substring(0, filePath1.LastIndexOf("\\"));
            DateTime myDate = DateTime.ParseExact(Recon_Dt, "ddMMyy", System.Globalization.CultureInfo.InvariantCulture);

            DateTime myRecconDate = DateTime.ParseExact(Recon_Dt, "ddMMyy", System.Globalization.CultureInfo.InvariantCulture);
            string strRecconDate = myRecconDate.ToString("ddMMyyyy");

            string[] files1 = System.IO.Directory.GetFiles(pt1 + dateTime.ToString("dd-MMM-yyyy") + "_Files\\" + @"Input\EBBS_India\");
            string[] files2 = System.IO.Directory.GetFiles(pt1 + dateTime.ToString("dd-MMM-yyyy") + "_Files\\" + @"Input\CTS-CHENNAI_India\");
            string[] files3 = System.IO.Directory.GetFiles(pt1 + dateTime.ToString("dd-MMM-yyyy") + "_Files\\" + @"Input\CTS-DELHI_India\");
            string[] files4 = System.IO.Directory.GetFiles(pt1 + dateTime.ToString("dd-MMM-yyyy") + "_Files\\" + @"Input\CTS-MUMBAI_India\");

            string[] fname = new string[100];
            string[] fname1 = new string[100];
            string[] fname2 = new string[100];
            string[] fname3 = new string[100];

            string[] input_file = new string[100];
            string[] input_file1 = new string[100];
            string[] input_file2 = new string[100];
            string[] input_file3 = new string[100];
            string[] input_file4 = new string[100];
            string[] input_file5 = new string[100];
            string[] input_file6 = new string[100];
            string[] input_file7 = new string[100];
            string[] input_file8 = new string[100];
            string[] input_file9 = new string[100];
            string[] input_file10 = new string[100];
            string[] input_file11 = new string[100];
            string[] input_file12 = new string[100];
            string[] input_file13 = new string[100];
            string[] input_file14 = new string[100];
            string[] input_file15 = new string[100];
            string[] input_file16 = new string[100];
            string cheque_deposit = SharePath + "SCB_IN_CLG_CHQDEP_FTP_" + strRecconDate + ".csv";
            //chennai            
            string EBBS_SCB_CHN_CLG_IN_EBS_FTP = SharePath + "SCB_CHN_CLG_IN_EBS_FTP_" + strRecconDate + ".csv";
            string EBBS_SCB_CHN_CLG_IN_EBSDMY_FTP = SharePath + "SCB_CHN_CLG_IN_EBSDMY_FTP_" + strRecconDate + ".csv";
            string EBBS_SCB_CHN_CLG_OUT_EBS_FTP = SharePath + "SCB_CHN_CLG_OUT_EBS_FTP_" + strRecconDate + ".csv";
            string EBBS_SCB_CHN_CLG_INRTN_EBS_FTP = SharePath + "SCB_CHN_CLG_INRTN_EBS_FTP_" + strRecconDate + ".csv";
            string EBBS_SCB_CHN_CLG_OUTRTN_EBS_FTP = SharePath + "SCB_CHN_CLG_OUTRTN_EBS_FTP_" + strRecconDate + ".csv";

            //mumbai
            string EBBS_MUM_CLG_IN_EBSDMY_FTP = SharePath + "SCB_MUM_CLG_IN_EBSDMY_FTP_" + strRecconDate + ".csv";
            string EBBS_MUM_CLG_INRTN_EBS_FTP = SharePath + "SCB_MUM_CLG_INRTN_EBS_FTP_" + strRecconDate + ".csv";
            string EBBS_MUM_CLG_OUTRTN_EBS_FTP = SharePath + "SCB_MUM_CLG_OUTRTN_EBS_FTP_" + strRecconDate + ".csv";
            string EBBS_SCB_MUM_CLG_IN_EBS_FTP = SharePath + "SCB_MUM_CLG_IN_EBS_FTP_" + strRecconDate + ".csv";
            string EBBS_SCB_MUM_CLG_OUT_EBS_FTP = SharePath + "SCB_MUM_CLG_OUT_EBS_FTP_" + strRecconDate + ".csv";


            //delhi

            string EBBS_DEL_CLG_IN_EBSDMY_FTP = SharePath + "SCB_DEL_CLG_IN_EBSDMY_FTP_" + strRecconDate + ".csv";
            string EBBS_DEL_CLG_INRTN_EBS_FTP = SharePath + "SCB_DEL_CLG_INRTN_EBS_FTP_" + strRecconDate + ".csv";
            string EBBS_DEL_CLG_OUTRTN_EBS_FTP = SharePath + "SCB_DEL_CLG_OUTRTN_EBS_FTP_" + strRecconDate + ".csv";
            string EBBS_SCB_DEL_CLG_IN_EBS_FTP = SharePath + "SCB_DEL_CLG_IN_EBS_FTP_" + strRecconDate + ".csv";
            string EBBS_SCB_DEL_CLG_OUT_EBS_FTP = SharePath + "SCB_DEL_CLG_OUT_EBS_FTP_" + strRecconDate + ".csv";

            //ebbs file
            for (int i = 0; i < files1.Length; i++)
            {
                fname[i] = Path.GetFileName(files1[i]);
            }


            int j = 0;

            //Cheque_Deposit

            for (int i = 0; i < files1.Length; i++)//one
            {

                if ((fname[i].Contains("CHN_CHQ_DEP_") && fname[i].Contains(myDate.ToString("ddMMyyyy"))) || (fname[i].Contains("DEL_CHQ_DEP_") && fname[i].Contains(myDate.ToString("ddMMyyyy"))) || (fname[i].Contains("MUM_CHQ_DEP_") && fname[i].Contains(myDate.ToString("ddMMyyyy"))))
                {
                    input_file1[j] = files1[i].ToString();
                    j++;
                }
            }
            if (input_file1[0] != null)
            {
                sheetcount(input_file1, cheque_deposit);
            }
            #region chennai

            // EBBS_SCB_CHN_CLG_OUTRTN_EBS_FTP
            j = 0;
            for (int i = 0; i < files1.Length; i++)
            {
                if ((fname[i].Contains("CH_ORCCN_") && fname[i].Contains(Recon_Dt)) || (fname[i].Contains("CH_ORNCN_") && fname[i].Contains(Recon_Dt)) || (fname[i].Contains("CH_RRPCN_") && fname[i].Contains(Recon_Dt)))
                {

                    input_file2[j] = files1[i].ToString();
                    j++;

                }
            }
            if (input_file2[0] != null)
            {
                sheetcount(input_file2, EBBS_SCB_CHN_CLG_OUTRTN_EBS_FTP);
            }
            //EBBS_SCB_CHN_CLG_IN_EBS_FTP
            j = 0;
            for (int i = 0; i < files1.Length; i++)
            {
                if ((fname[i].Contains("CH_IMCTS_") && fname[i].Contains(Recon_Dt)) || (fname[i].Contains("CH_IMNCC_") && fname[i].Contains(Recon_Dt)))
                {

                    input_file3[j] = files1[i].ToString();
                    j++;


                }
            }
            if (input_file3[0] != null)
            {
                sheetcount(input_file3, EBBS_SCB_CHN_CLG_IN_EBS_FTP);
            }
            //////EBBS_SCB_CHN_CLG_OUT_EBS_FTP
            j = 0;
            for (int i = 0; i < files1.Length; i++)
            {
                if ((fname[i].Contains("CH_OMCTS_") && fname[i].Contains(Recon_Dt)) || (fname[i].Contains("CH_OMCCC_") && fname[i].Contains(Recon_Dt)))
                {

                    input_file4[j] = files1[i].ToString();
                    j++;
                }
            }
            if (input_file4[0] != null)
            {
                sheetcount(input_file4, EBBS_SCB_CHN_CLG_OUT_EBS_FTP);
            }
            ////EBBS_SCB_CHN_CLG_IN_EBSDMY_FTP
            j = 0;
            for (int i = 0; i < files1.Length; i++)//three
            {
                if ((fname[i].Contains("CH_IOCHN_") && fname[i].Contains(Recon_Dt)) || (fname[i].Contains("CH_IMCHN_") && fname[i].Contains(Recon_Dt)))
                {

                    input_file5[j] = files1[i].ToString();
                    j++;
                }
            }
            if (input_file5[0] != null)
            {
                sheetcount(input_file5, EBBS_SCB_CHN_CLG_IN_EBSDMY_FTP);
            }
            //////EBBS_SCB_CHN_CLG_INRTN_EBS_FTP

            j = 0;
            for (int i = 0; i < files1.Length; i++)
            {
                if ((fname[i].Contains("CH_IRCCN_") && fname[i].Contains(Recon_Dt)) || (fname[i].Contains("CH_IRNCN_") & fname[i].Contains(Recon_Dt)))
                {

                    input_file6[j] = files1[i].ToString();
                    j++;


                }
            }
            if (input_file6[0] != null)
            {
                sheetcount(input_file6, EBBS_SCB_CHN_CLG_INRTN_EBS_FTP);
            }
            #endregion chennai
            #region mumbai
            ////EBBS_MUM_CLG_IN_EBSDMY_FTP

            j = 0;
            for (int i = 0; i < files1.Length; i++)
            {
                if ((fname[i].Contains("MU_IOMUM_") && fname[i].Contains(Recon_Dt)) || (fname[i].Contains("MU_IMMUM_") && fname[i].Contains(Recon_Dt)))
                {

                    input_file7[j] = files1[i].ToString();
                    j++;


                }
            }
            if (input_file7[0] != null)
            {
                sheetcount(input_file7, EBBS_MUM_CLG_IN_EBSDMY_FTP);
            }

            //////EBBS_MUM_CLG_INRTN_EBS_FTP
            j = 0;
            for (int i = 0; i < files1.Length; i++)
            {
                if ((fname[i].Contains("MU_IRNMM") && fname[i].Contains(Recon_Dt)) || (fname[i].Contains("MU_IRCMM_") && fname[i].Contains(Recon_Dt)))
                {
                    input_file8[j] = files1[i].ToString();
                    j++;
                }
            }
            if (input_file8[0] != null)
            {
                sheetcount(input_file8, EBBS_MUM_CLG_INRTN_EBS_FTP);
            }

            ////////EBBS_MUM_CLG_OUTRTN_EBS_FTP

            j = 0;
            for (int i = 0; i < files1.Length; i++)
            {
                if ((fname[i].Contains("MU_ORCCM_") && fname[i].Contains(Recon_Dt)) || (fname[i].Contains("MU_ORNCM_") && fname[i].Contains(Recon_Dt)) || (fname[i].Contains("MU_RRPMM_") && fname[i].Contains(Recon_Dt)))
                {

                    input_file9[j] = files1[i].ToString();
                    j++;
                }
            }
            if (input_file9[0] != null)
            {
                sheetcount(input_file9, EBBS_MUM_CLG_OUTRTN_EBS_FTP);
            }


            ////////EBBS_SCB_MUM_CLG_IN_EBS_FTP

            j = 0;
            for (int i = 0; i < files1.Length; i++)
            {
                if ((fname[i].Contains("MU_INMUM_") && fname[i].Contains(Recon_Dt)) || (fname[i].Contains("MU_IMNCM_") && fname[i].Contains(Recon_Dt)))
                {

                    input_file10[j] = files1[i].ToString();
                    j++;

                }
            }
            if (input_file10[0] != null)
            {
                sheetcount(input_file10, EBBS_SCB_MUM_CLG_IN_EBS_FTP);
            }
            ////////EBBS_SCB_MUM_CLG_OUT_EBS_FTP

            j = 0;
            for (int i = 0; i < files1.Length; i++)
            {
                if ((fname[i].Contains("MU_OWMUM") && fname[i].Contains(Recon_Dt)) || (fname[i].Contains("MU_OMCCM_") && fname[i].Contains(Recon_Dt)))
                {

                    input_file11[j] = files1[i].ToString();
                    j++;
                }
            }
            if (input_file11[0] != null)
            {
                sheetcount(input_file11, EBBS_SCB_MUM_CLG_OUT_EBS_FTP);
            }
            #endregion mumbai
            #region delhi
            // EBBS_DEL_CLG_IN_EBSDMY_FTP

            j = 0;
            for (int i = 0; i < files1.Length; i++)
            {
                if ((fname[i].Contains("DE_IODEL_") && fname[i].Contains(Recon_Dt)) || (fname[i].Contains("DE_IMDEL_") && fname[i].Contains(Recon_Dt)))
                {

                    input_file12[j] = files1[i].ToString();
                    j++;

                }
            }
            if (input_file12[0] != null)
            {
                sheetcount(input_file12, EBBS_DEL_CLG_IN_EBSDMY_FTP);
            }
            ////// EBBS_DEL_CLG_INRTN_EBS_FTP

            j = 0;
            for (int i = 0; i < files1.Length; i++)
            {
                if ((fname[i].Contains("DE_IRNND_") && fname[i].Contains(Recon_Dt)) || (fname[i].Contains("DE_IRCND_") && fname[i].Contains(Recon_Dt)))
                {

                    input_file13[j] = files1[i].ToString();
                    j++;

                }
            }
            if (input_file13[0] != null)
            {
                sheetcount(input_file13, EBBS_DEL_CLG_INRTN_EBS_FTP);
            }

            ////EBBS_DEL_CLG_OUTRTN_EBS_FTP

            j = 0;
            for (int i = 0; i < files1.Length; i++)//two
            {
                if ((fname[i].Contains("DE_ORCND_") && fname[i].Contains(Recon_Dt)) || (fname[i].Contains("DE_ORNND_") && fname[i].Contains(Recon_Dt)) || (fname[i].Contains("DE_RRPND_") && fname[i].Contains(Recon_Dt)))
                {

                    input_file14[j] = files1[i].ToString();
                    j++;

                }
            }
            if (input_file14[0] != null)
            {
                sheetcount(input_file14, EBBS_DEL_CLG_OUTRTN_EBS_FTP);
            }
            ////// EBBS_SCB_DEL_CLG_IN_EBS_FTP

            j = 0;
            for (int i = 0; i < files1.Length; i++)
            {
                if ((fname[i].Contains("DE_IMNCD_") && fname[i].Contains(Recon_Dt)) || (fname[i].Contains("DE_IMNCP_") && fname[i].Contains(Recon_Dt)))
                {

                    input_file15[j] = files1[i].ToString();
                    j++;

                }
            }
            if (input_file15[0] != null)
            {
                sheetcount(input_file15, EBBS_SCB_DEL_CLG_IN_EBS_FTP);
            }
            ////////EBBS_SCB_DEL_CLG_OUT_EBS_FTP

            j = 0;
            for (int i = 0; i < files1.Length; i++)
            {
                if ((fname[i].Contains("DE_OMCCD_") && fname[i].Contains(Recon_Dt)) || (fname[i].Contains("DE_OMCCP_") && fname[i].Contains(Recon_Dt)))
                {

                    input_file16[j] = files1[i].ToString();
                    j++;
                }
            }
            if (input_file16[0] != null)
            {
                sheetcount(input_file16, EBBS_SCB_DEL_CLG_OUT_EBS_FTP);
            }


            #endregion delhi
            Flag = true;

        }
        public void sheetcount(string[] input, string output)
        {
            int c = 0;

            for (int l = 0; l < input.Length; l++)
            {
                if (input[l] != null)
                {
                    c++;                    
                }
                else
                {
                    break;
                }
            }

            if (c == 1)
            {
                sheet1(input, output);
            }

            else if (c == 2)
            {
                sheet2(input, output);
            }
            else
            {
                sheet3(input, output);
            }

        }
        public void ReleaseComObject(object ob)
        {
            try
            {

                while (System.Runtime.InteropServices.Marshal.ReleaseComObject(ob) != 0) { }

                ob = null;
            }
            catch
            {
                ob = null;
            }
            finally
            {
                GC.Collect(GC.MaxGeneration);
                GC.WaitForPendingFinalizers();
            }
        }
        public void sheet1(string[] input, string output)
        {
            try
            {
                string Conn = "";
                //Microsoft.Office.Interop.Excel.Application app = new Microsoft.Office.Interop.Excel.Application();
                //app.DisplayAlerts = false;
                //app.Visible = false;

                //Microsoft.Office.Interop.Excel.Workbook WBO = (Microsoft.Office.Interop.Excel.Workbook)(app.Workbooks.Add(""));
                //Microsoft.Office.Interop.Excel.Worksheet WBS = (Microsoft.Office.Interop.Excel.Worksheet)app.ActiveSheet;
                System.Data.DataTable Dt_India = new System.Data.DataTable();

                string tempaneer = "";

                tempaneer = input[0].ToString();
                //Conn = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + input[0] + @";Extended Properties=""Excel 8.0;IMEX=1;HDR=NO;TypeGuessRows=0;ImportMixedTypes=Text""";
                //Conn = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + input[0] + ";Extended Properties='Excel 12.0;HDR=YES'";

                OleDbConnection connection = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + input[0] + @";Extended Properties=""Excel 8.0;IMEX=1;HDR=NO;TypeGuessRows=0;ImportMixedTypes=Text""");
                connection.Close();
                connection.Open();
                System.Data.DataTable schemaTable = connection.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, new object[] { null, null, null, "TABLE" });
                DataRow schemaRow = schemaTable.Rows[0];
                string sheet = schemaRow["TABLE_NAME"].ToString();
                OleDbDataAdapter Command = new OleDbDataAdapter("select * from [" + sheet + "]", connection);
                Command.Fill(Dt_India);
                connection.Close();

                if (output.Contains("CLG_IN_EBS_FTP") || output.Contains("IN_EBSDMY_FTP") || output.Contains("CLG_OUT_EBS_FTP") || output.Contains("CLG_INRTN_EBS_FTP") || output.Contains("CLG_OUTRTN_EBS_FTP"))
                {
                    for (int i = 0; i < Dt_India.Rows.Count; i++)
                    {
                        if (Dt_India.Rows[i][1] == null)
                            continue;
                        Dt_India.Rows[i][1].ToString().Trim();
                    }

                    for (int i = 0; i < Dt_India.Rows.Count; i++)
                    {
                        if (Dt_India.Rows[i][2] == null)
                            continue;
                        Dt_India.Rows[i][2].ToString().Trim();
                    }
                }
                if (Dt_India.Rows.Count > 0)
                {
                    System.Data.DataTable dtCloned = Dt_India.Clone();
                    for (int i = 0; i < Dt_India.Columns.Count; i++)
                    {
                        dtCloned.Columns[i].DataType = typeof(String);
                    }

                    foreach (DataRow row in Dt_India.Rows)
                    {
                        dtCloned.ImportRow(row);
                    }

                    StreamWriter sw = new StreamWriter(output, false);

                    int col_count = dtCloned.Columns.Count;

                    //for (int i = 0; i < col_count; i++)
                    //{
                    //    sw.Write(dtCloned.Columns[i]);
                    //    if (i < col_count - 1)
                    //    {
                    //        sw.Write(",");
                    //    }
                    //}
                    //sw.Write(sw.NewLine);
                    var regexItem = new Regex("^[a-zA-Z0-9. ]*$");
                    foreach (DataRow dr in dtCloned.Rows)
                    {
                        for (int i = 0; i < col_count; i++)
                        {
                            if (!Convert.IsDBNull(dr[i]))
                            {
                                string value = dr[i].ToString();
                                if (!(regexItem.IsMatch(value)))
                                {
                                    if (value.Contains("\n") || (value.Contains(",") && value.Contains("&")) || (value.Contains(",") && value.Contains("-")) || (value.Contains(",") && value.Contains(".")) || (value.Contains(",") && value.Contains("/")) || (value.Contains(",") && value.Contains("'"))||(value.Contains(",")))
                                    {
                                        value = String.Format("\"{0}\"", value).Replace("\r","");
                                        sw.Write(value);
                                    }
                                    else if (value.Contains("\r"))
                                    {

                                        value = dr[i].ToString().Replace("\r", "");

                                        sw.Write(value);

                                    }
                                    else
                                    {
                                        value = String.Format("{0}", value);
                                        sw.Write(value);
                                    }
                                }                                
                                else
                                {
                                    if (value.Contains("\n"))
                                    {
                                        value = String.Format("\"{0}\"", value);
                                        sw.Write(value);
                                    }
                                    else if (value.Contains("\r"))
                                    {

                                        value = dr[i].ToString().Replace("\r", "");

                                        sw.Write(value);

                                    }
                                    else
                                    {
                                        sw.Write(dr[i].ToString());
                                    }
                                }
                            }
                            if (i < col_count - 1)
                            {
                                sw.Write(",");
                            }
                        }
                        sw.Write(sw.NewLine);
                    }
                    sw.Close();
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message.ToString());
            }

        }
        public void sheet2(string[] input, string output)
        {
            try
            {
                Microsoft.Office.Interop.Excel.Application app = new Microsoft.Office.Interop.Excel.Application();
                app.DisplayAlerts = false;
                app.Visible = false;
                System.Data.DataTable Dt_input1 = new System.Data.DataTable();
                System.Data.DataTable Dt_input2 = new System.Data.DataTable();
                System.Data.DataTable Dt_All = new System.Data.DataTable();
                OleDbConnection connection;
                OleDbDataAdapter Command;
                connection = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + input[0] + @";Extended Properties=""Excel 8.0;IMEX=1;HDR=NO;TypeGuessRows=0;ImportMixedTypes=Text""");
                connection.Open();
                System.Data.DataTable schemaTable = connection.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, new object[] { null, null, null, "TABLE" });
                DataRow schemaRow = schemaTable.Rows[0];
                string sheet = schemaRow["TABLE_NAME"].ToString();
                Command = new OleDbDataAdapter("select * from [" + sheet + "]", connection);
                Command.Fill(Dt_input1);
                connection.Close();

                connection = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + input[1] + @";Extended Properties=""Excel 8.0;IMEX=1;HDR=NO;TypeGuessRows=0;ImportMixedTypes=Text""");
                connection.Open();
                System.Data.DataTable schemaTable1 = connection.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, new object[] { null, null, null, "TABLE" });
                DataRow schemaRow1 = schemaTable1.Rows[0];
                string sheet1 = schemaRow1["TABLE_NAME"].ToString();
                Command = new OleDbDataAdapter("select * from [" + sheet1 + "]", connection);
                Command.Fill(Dt_input2);
                connection.Close();


                // creating a new excel sheet 
                Microsoft.Office.Interop.Excel.Workbook WBO = (Microsoft.Office.Interop.Excel.Workbook)(app.Workbooks.Add(""));
                Microsoft.Office.Interop.Excel.Worksheet WBS = (Microsoft.Office.Interop.Excel.Worksheet)app.ActiveSheet;
                int x = 1;
                int y = 1;



                //merging a files:
                if (output.Contains("CLG_IN_CB_FTP") || output.Contains("IN_CBDMY_FTP") || output.Contains("CLG_INRTN_CB_FTP") || output.Contains("OUTRTN_CB_FTP") || output.Contains("OUT_CB_FTP"))
                {
                    Regex rx = new Regex(@"[0-9]$");
                    for (int i = 0; i < Dt_input2.Rows.Count; i++)
                    {
                        if (!(rx.IsMatch(Convert.ToString(Dt_input2.Rows[i][0]))))
                        {
                            Dt_input2.Rows[i].Delete();
                        }
                    }
                    Dt_input2.AcceptChanges();
                    Dt_All.Merge(Dt_input1);
                    Dt_All.Merge(Dt_input2);

                }

                if (output.Contains("CLG_IN_CBDMY_FTP"))
                {
                    //var rows = Dt_All.Select("col2 ='Total'");
                    //foreach (var row in rows)
                    //    row.Delete();
                    //Dt_All.AcceptChanges();
                    if (output.Contains("CHN"))
                    {
                        for (int i = 0; i < Dt_All.Rows.Count; i++)
                        {
                            if (Dt_All.Rows[i][11].ToString().Contains("Total"))
                            {
                                Dt_All.Rows[i].Delete();

                            }
                        }
                        Dt_All.AcceptChanges();
                    }
                    else
                    {
                        for (int i = 0; i < Dt_All.Rows.Count; i++)
                        {
                            if (Dt_All.Rows[i][2].ToString().Contains("Total"))
                            {
                                Dt_All.Rows[i].Delete();

                            }
                        }
                        Dt_All.AcceptChanges();
                    }
                }

                if (output.Contains("CLG_INRTN_CB_FTP"))
                {
                    if (output.Contains("CHN"))
                    {
                        for (int i = 0; i < Dt_All.Rows.Count; i++)
                        {

                            if (Dt_All.Rows[i][2].ToString().Contains("RETURN TOTAL"))
                            {
                                Dt_All.Rows[i-1].Delete();
                                Dt_All.Rows[i].Delete();

                            }                            
                        }
                        Dt_All.AcceptChanges();
                    }
                    else
                    {
                        for (int i = 0; i < Dt_All.Rows.Count; i++)
                        {

                            if (Dt_All.Rows[i][4].ToString().Contains("RETURN TOTAL"))
                            {
                                Dt_All.Rows[i - 1].Delete();
                                Dt_All.Rows[i].Delete();

                            }

                        }
                        Dt_All.AcceptChanges();
                    }
                }

                if (output.Contains("CLG_IN_EBS_FTP") || output.Contains("IN_EBSDMY_FTP") || output.Contains("CLG_OUT_EBS_FTP") || output.Contains("CLG_INRTN_EBS_FTP") || output.Contains("CLG_OUTRTN_EBS_FTP"))
                {
                    if (Dt_input2.Rows.Count > 1 && Dt_input1.Rows.Count > 1)
                    {
                        Dt_input2.Rows[1].Delete();
                        Dt_input2.Rows[0].Delete();                        
                        Dt_input2.AcceptChanges();
                        Dt_All.Merge(Dt_input1);
                        Dt_All.Merge(Dt_input2);
                    }
                    else if (Dt_input2.Rows.Count > 1)
                    {
                        Dt_All.Merge(Dt_input2);
                    }
                    else if (Dt_input1.Rows.Count > 1)
                    {
                        Dt_All.Merge(Dt_input1);
                    }

                    for (int i = 0; i < Dt_All.Rows.Count; i++)
                    {
                        if (Dt_All.Rows[i][1] == null)
                            continue;
                        Dt_All.Rows[i][1].ToString().Trim();
                    }
                    for (int i = 0; i < Dt_All.Rows.Count; i++)
                    {
                        if (Dt_All.Rows[i][2] == null)
                            continue;
                        Dt_All.Rows[i][2].ToString().Trim();
                    }
                }

                if (Dt_All.Rows.Count > 0)
                {
                    System.Data.DataTable dtCloned = Dt_All.Clone();
                    for (int i = 0; i < Dt_All.Columns.Count; i++)
                    {
                        dtCloned.Columns[i].DataType = typeof(String);
                    }

                    foreach (DataRow row in Dt_All.Rows)
                    {
                        dtCloned.ImportRow(row);
                    }

                    StreamWriter sw = new StreamWriter(output, false);

                    int col_count = dtCloned.Columns.Count;

                    var regexItem = new Regex("^[a-zA-Z0-9. ]*$");

                    foreach (DataRow dr in dtCloned.Rows)
                    {
                        for (int i = 0; i < col_count; i++)
                        {
                            if (!Convert.IsDBNull(dr[i]))
                            {
                                string value = dr[i].ToString();
                                if (!(regexItem.IsMatch(value)))
                                {
                                    if (value.Contains("\n") || (value.Contains(",") && value.Contains("&")) || (value.Contains(",") && value.Contains("-")) || (value.Contains(",") && value.Contains(".")) || (value.Contains(",") && value.Contains("/")) || (value.Contains(",") && value.Contains("'")) || (value.Contains(",")))
                                    {
                                        value = String.Format("\"{0}\"", value).Replace("\r","");
                                        sw.Write(value);
                                    }
                                    else if (value.Contains("\r"))
                                    {

                                        value = dr[i].ToString().Replace("\r", "");

                                        sw.Write(value);

                                    }
                                    else
                                    {
                                        value = String.Format("{0}", value);
                                        sw.Write(value);
                                    }
                                }
                                else
                                {
                                    if (value.Contains("\n"))
                                    {
                                        value = String.Format("\"{0}\"", value);
                                        sw.Write(value);
                                    }
                                    else if (value.Contains("\r"))
                                    {

                                        value = dr[i].ToString().Replace("\r", "");

                                        sw.Write(value);

                                    }
                                    else
                                    {
                                        sw.Write(dr[i].ToString());
                                    }
                                }
                            }
                            if (i < col_count - 1)
                            {
                                sw.Write(",");
                            }
                        }
                        sw.Write(sw.NewLine);
                    }
                    sw.Close();
                }
            }
            catch (Exception ex)
            {

            }

        }
        public void sheet3(string[] input, string output)
        {
            try
            {

                Microsoft.Office.Interop.Excel.Application app = new Microsoft.Office.Interop.Excel.Application();
                app.DisplayAlerts = false;
                app.Visible = false;

                System.Data.DataTable Dt_input1 = new System.Data.DataTable();
                System.Data.DataTable Dt_input2 = new System.Data.DataTable();
                System.Data.DataTable Dt_input3 = new System.Data.DataTable();
                System.Data.DataTable Dt_All = new System.Data.DataTable();

                OleDbConnection connection;
                OleDbDataAdapter Command;

                if (input[0] != null)
                {
                    connection = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + input[0] + @";Extended Properties=""Excel 8.0;IMEX=1;HDR=NO;TypeGuessRows=0;ImportMixedTypes=Text""");
                    connection.Open();
                    System.Data.DataTable schemaTable = connection.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, new object[] { null, null, null, "TABLE" });
                    DataRow schemaRow = schemaTable.Rows[0];
                    string sheet = schemaRow["TABLE_NAME"].ToString();
                    Command = new OleDbDataAdapter("select * from [" + sheet + "]", connection);
                    Command.Fill(Dt_input1);
                    connection.Close();
                }
                if (input[1] != null)
                {
                    connection = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + input[1] + @";Extended Properties=""Excel 8.0;IMEX=1;HDR=NO;TypeGuessRows=0;ImportMixedTypes=Text""");
                    connection.Open();
                    System.Data.DataTable schemaTable1 = connection.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, new object[] { null, null, null, "TABLE" });
                    DataRow schemaRow1 = schemaTable1.Rows[0];
                    string sheet1 = schemaRow1["TABLE_NAME"].ToString();
                    Command = new OleDbDataAdapter("select * from [" + sheet1 + "]", connection);
                    Command.Fill(Dt_input2);
                    connection.Close();
                }

                if (input[2] != null)
                {
                    connection = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + input[2] + @";Extended Properties=""Excel 8.0;IMEX=1;HDR=NO;TypeGuessRows=0;ImportMixedTypes=Text""");
                    connection.Open();
                    System.Data.DataTable schemaTable2 = connection.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, new object[] { null, null, null, "TABLE" });
                    DataRow schemaRow2 = schemaTable2.Rows[0];
                    string sheet2 = schemaRow2["TABLE_NAME"].ToString();
                    Command = new OleDbDataAdapter("select * from [" + sheet2 + "]", connection);
                    Command.Fill(Dt_input3);
                    connection.Close();
                }

                // creating a new excel sheet 
                Microsoft.Office.Interop.Excel.Workbook WBO = (Microsoft.Office.Interop.Excel.Workbook)(app.Workbooks.Add(""));
                Microsoft.Office.Interop.Excel.Worksheet WBS = (Microsoft.Office.Interop.Excel.Worksheet)app.ActiveSheet;

                if (output.Contains("CLG_OUTRTN_EBS_FTP"))
                {


                    Dt_All.Merge(Dt_input1);
                    for (int i = 0; i < Dt_input2.Rows.Count; i++)
                    {
                        if (Dt_input2.Rows[i][0].ToString().Contains("Account No") || Dt_input2.Rows[i][0].ToString().Contains("Transaction Branch"))
                        {
                            Dt_input2.Rows[i].Delete();


                        }
                    }
                    for (int i = 0; i < Dt_input3.Rows.Count; i++)
                    {
                        if (Dt_input3.Rows[i][0].ToString().Contains("Account No") || Dt_input3.Rows[i][0].ToString().Contains("Transaction Branch"))
                        {
                            Dt_input3.Rows[i].Delete();

                        }
                        // i--;
                    }

                    Dt_input2.AcceptChanges();
                    Dt_input3.AcceptChanges();
                    Dt_All.Merge(Dt_input2);
                    Dt_All.Merge(Dt_input3);

                    for (int i = 0; i < Dt_All.Rows.Count; i++)
                    {
                        if (Dt_All.Rows[i][1] == null)
                            continue;
                        Dt_All.Rows[i][1].ToString().Trim();
                    }
                    for (int i = 0; i < Dt_All.Rows.Count; i++)
                    {
                        if (Dt_All.Rows[i][2] == null)
                            continue;
                        Dt_All.Rows[i][2].ToString().Trim();
                    }

                }
                if (output.Contains("IN_CLG_CHQDEP_FTP"))
                {
                    DataRow newRow = Dt_input1.NewRow();
                    Dt_input1.Rows.InsertAt(newRow, Dt_input1.Rows.Count + 1);
                    DataRow newRow1 = Dt_input2.NewRow();
                    Dt_input2.Rows.InsertAt(newRow1, Dt_input2.Rows.Count + 1);
                    Dt_All.Merge(Dt_input1);
                    Dt_All.Merge(Dt_input2);
                    Dt_All.Merge(Dt_input3);
                }


                if (Dt_All.Columns.Count > 0)
                {
                    System.Data.DataTable dtCloned = Dt_All.Clone();
                    for (int i = 0; i < Dt_All.Columns.Count; i++)
                    {
                        if (i == 3 || i == 5)
                        {
                            if (output.Contains("CLG_OUTRTN_EBS_FTP"))
                            {
                                dtCloned.Columns[i].DataType = typeof(String);
                            }
                            else
                            {
                                dtCloned.Columns[i].DataType = typeof(String);
                            }
                        }
                        else
                        {
                            dtCloned.Columns[0].DataType = typeof(String);
                        }


                    }

                    foreach (DataRow row in Dt_All.Rows)
                    {
                        dtCloned.ImportRow(row);
                    }

                    StreamWriter sw = new StreamWriter(output, false);

                    int col_count = dtCloned.Columns.Count;

                    //for (int i = 0; i < col_count; i++)
                    //{
                    //    sw.Write(dtCloned.Columns[i]);
                    //    if (i < col_count - 1)
                    //    {
                    //        sw.Write(",");
                    //    }
                    //}
                    //sw.Write(sw.NewLine);
                    var regexItem = new Regex("^[a-zA-Z0-9. ]*$");

                    foreach (DataRow dr in dtCloned.Rows)
                    {
                        for (int i = 0; i < col_count; i++)
                        {
                            if (!Convert.IsDBNull(dr[i]))
                            {
                                string value = dr[i].ToString();
                                if (!(regexItem.IsMatch(value)))
                                {
                                    if (value.Contains("\n") || (value.Contains(",") && value.Contains("&")) || (value.Contains(",") && value.Contains("-")) || (value.Contains(",") && value.Contains(".")) || (value.Contains(",") && value.Contains("/")) || (value.Contains(",") && value.Contains("'")) || (value.Contains(",")))
                                    {
                                        value = String.Format("\"{0}\"", value);
                                        sw.Write(value.Replace("\r", ""));
                                    }
                                    else if (value.Contains("\r"))
                                    {

                                        value = dr[i].ToString().Replace("\r", "");

                                        sw.Write(value);

                                    }
                                    else
                                    {
                                        value = String.Format("{0}", value);
                                        sw.Write(value);
                                    }
                                }
                                else
                                {
                                    if (value.Contains("\n"))
                                    {
                                        value = String.Format("\"{0}\"", value);
                                        sw.Write(value);
                                    }
                                    else if (value.Contains("\r"))
                                    {

                                        value = dr[i].ToString().Replace("\r", "");

                                        sw.Write(value);

                                    }
                                    else
                                    {
                                        sw.Write(dr[i].ToString());
                                    }
                                }
                            }
                            if (i < col_count - 1)
                            {
                                sw.Write(",");
                            }
                        }
                        sw.Write(sw.NewLine);
                    }
                    sw.Close();
                }
            }
            catch (Exception ex)
            {
            }
        }
        public void Fileses(string share)
        {
            try
            {
                string str = "";
                if (Directory.Exists(share))
                {
                    string[] files = System.IO.Directory.GetFiles(share);
                    string name = "";

                    for (int i = 0; i <= files.Length - 1; i++)
                    {
                        if (files[i].Contains(".csv"))
                        {
                            str = files[i];
                            string text = File.ReadAllText(str);
                            name = Path.GetFileName(str);
                            string clearing = "";
                            clearing = text.Replace("\"", "");
                            File.WriteAllText(str, clearing);
                            str = "";
                            name = "";
                        }
                    }
                }
                else
                {
                    // MessageBox.Show("Directory does not Exists");
                }
            }
            catch
            {
            }
        }
    }
}
