﻿namespace ARC_Application
{
    partial class Admin_Config
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle21 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle22 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle23 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle24 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.cmbProductName = new System.Windows.Forms.ComboBox();
            this.label25 = new System.Windows.Forms.Label();
            this.ckb_IsMailFunctionalityRequired = new System.Windows.Forms.CheckBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.btnDownloadRecipientList = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnUpdateRecipient = new System.Windows.Forms.Button();
            this.txtEmailID = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.cmbFileName = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.cmbReconName = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.To_Date = new System.Windows.Forms.DateTimePicker();
            this.label5 = new System.Windows.Forms.Label();
            this.btn_GenerateReport = new System.Windows.Forms.Button();
            this.From_Date = new System.Windows.Forms.DateTimePicker();
            this.label4 = new System.Windows.Forms.Label();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.btnEditUser = new System.Windows.Forms.Button();
            this.cmbAccessType = new System.Windows.Forms.ComboBox();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnSearch = new System.Windows.Forms.Button();
            this.dataGridView = new System.Windows.Forms.DataGridView();
            this.btnAddUser = new System.Windows.Forms.Button();
            this.btnDeleteUser = new System.Windows.Forms.Button();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.chklstPageAccess = new System.Windows.Forms.CheckedListBox();
            this.chklstCountries = new System.Windows.Forms.CheckedListBox();
            this.chklstProduct = new System.Windows.Forms.CheckedListBox();
            this.chklstApplication = new System.Windows.Forms.CheckedListBox();
            this.txtLineManager = new System.Windows.Forms.TextBox();
            this.txtUserName = new System.Windows.Forms.TextBox();
            this.txtUserPSID = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.DGV_Holiday = new System.Windows.Forms.DataGridView();
            this.txt_HolidayReson = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.dtPicker_From = new System.Windows.Forms.DateTimePicker();
            this.label21 = new System.Windows.Forms.Label();
            this.btn_DeleteCalendar = new System.Windows.Forms.Button();
            this.btn_AddCalendar = new System.Windows.Forms.Button();
            this.btn_UpdateCalendar = new System.Windows.Forms.Button();
            this.btn_ViewCalendar = new System.Windows.Forms.Button();
            this.label20 = new System.Windows.Forms.Label();
            this.cmb_Holiday = new System.Windows.Forms.ComboBox();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.lbl_cntry = new System.Windows.Forms.Label();
            this.cmb_FTP_cntry = new System.Windows.Forms.ComboBox();
            this.lbl_Prd = new System.Windows.Forms.Label();
            this.cmb_FTP_Prdt = new System.Windows.Forms.ComboBox();
            this.DGV_FTP = new System.Windows.Forms.DataGridView();
            this.btnUpdate_FTP = new System.Windows.Forms.Button();
            this.tabControl1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).BeginInit();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_Holiday)).BeginInit();
            this.tabPage6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_FTP)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage6);
            this.tabControl1.Cursor = System.Windows.Forms.Cursors.Default;
            this.tabControl1.Font = new System.Drawing.Font("Cambria", 9.75F);
            this.tabControl1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.tabControl1.Location = new System.Drawing.Point(1, 1);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1282, 511);
            this.tabControl1.TabIndex = 8;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.cmbProductName);
            this.tabPage2.Controls.Add(this.label25);
            this.tabPage2.Controls.Add(this.ckb_IsMailFunctionalityRequired);
            this.tabPage2.Controls.Add(this.label24);
            this.tabPage2.Controls.Add(this.label23);
            this.tabPage2.Controls.Add(this.label11);
            this.tabPage2.Controls.Add(this.label10);
            this.tabPage2.Controls.Add(this.label9);
            this.tabPage2.Controls.Add(this.btnDownloadRecipientList);
            this.tabPage2.Controls.Add(this.btnCancel);
            this.tabPage2.Controls.Add(this.btnUpdateRecipient);
            this.tabPage2.Controls.Add(this.txtEmailID);
            this.tabPage2.Controls.Add(this.label8);
            this.tabPage2.Controls.Add(this.cmbFileName);
            this.tabPage2.Controls.Add(this.label7);
            this.tabPage2.Controls.Add(this.cmbReconName);
            this.tabPage2.Controls.Add(this.label6);
            this.tabPage2.ImageKey = "Configuration";
            this.tabPage2.Location = new System.Drawing.Point(4, 24);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1274, 483);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Recipient List Management";
            this.tabPage2.ToolTipText = "Configuration Management";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // cmbProductName
            // 
            this.cmbProductName.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbProductName.FormattingEnabled = true;
            this.cmbProductName.Location = new System.Drawing.Point(386, 71);
            this.cmbProductName.Name = "cmbProductName";
            this.cmbProductName.Size = new System.Drawing.Size(350, 23);
            this.cmbProductName.TabIndex = 16;
            this.cmbProductName.SelectedIndexChanged += new System.EventHandler(this.cmbProductName_SelectedIndexChanged);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold);
            this.label25.Location = new System.Drawing.Point(141, 74);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(81, 15);
            this.label25.TabIndex = 15;
            this.label25.Text = "Product Name";
            // 
            // ckb_IsMailFunctionalityRequired
            // 
            this.ckb_IsMailFunctionalityRequired.AutoSize = true;
            this.ckb_IsMailFunctionalityRequired.Location = new System.Drawing.Point(386, 195);
            this.ckb_IsMailFunctionalityRequired.Name = "ckb_IsMailFunctionalityRequired";
            this.ckb_IsMailFunctionalityRequired.Size = new System.Drawing.Size(15, 14);
            this.ckb_IsMailFunctionalityRequired.TabIndex = 14;
            this.ckb_IsMailFunctionalityRequired.UseVisualStyleBackColor = true;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold);
            this.label24.Location = new System.Drawing.Point(141, 194);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(157, 15);
            this.label24.TabIndex = 13;
            this.label24.Text = "Mail Functionality Required";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.label23.Location = new System.Drawing.Point(776, 282);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(150, 15);
            this.label23.TabIndex = 12;
            this.label23.Text = "Below is a sample format.";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.label11.Location = new System.Drawing.Point(776, 297);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(142, 15);
            this.label11.TabIndex = 11;
            this.label11.Text = "abc.d@sc.com;1234XXX;";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.label10.Location = new System.Drawing.Point(776, 267);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(398, 15);
            this.label10.TabIndex = 10;
            this.label10.Text = "Multiple Email ID can be given in comma (,) or semicolon(;) separated.";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Cambria", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.label9.Location = new System.Drawing.Point(776, 240);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(68, 17);
            this.label9.TabIndex = 9;
            this.label9.Text = "Example";
            // 
            // btnDownloadRecipientList
            // 
            this.btnDownloadRecipientList.Location = new System.Drawing.Point(779, 373);
            this.btnDownloadRecipientList.Name = "btnDownloadRecipientList";
            this.btnDownloadRecipientList.Size = new System.Drawing.Size(200, 23);
            this.btnDownloadRecipientList.TabIndex = 8;
            this.btnDownloadRecipientList.Text = "Download Recipient List";
            this.btnDownloadRecipientList.UseVisualStyleBackColor = true;
            this.btnDownloadRecipientList.Click += new System.EventHandler(this.btnDownloadRecipientList_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(615, 373);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(121, 23);
            this.btnCancel.TabIndex = 7;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnUpdateRecipient
            // 
            this.btnUpdateRecipient.Location = new System.Drawing.Point(386, 373);
            this.btnUpdateRecipient.Name = "btnUpdateRecipient";
            this.btnUpdateRecipient.Size = new System.Drawing.Size(121, 23);
            this.btnUpdateRecipient.TabIndex = 6;
            this.btnUpdateRecipient.Text = "Update Recipient";
            this.btnUpdateRecipient.UseVisualStyleBackColor = true;
            this.btnUpdateRecipient.Click += new System.EventHandler(this.btnUpdateRecipient_Click);
            // 
            // txtEmailID
            // 
            this.txtEmailID.Location = new System.Drawing.Point(386, 240);
            this.txtEmailID.Multiline = true;
            this.txtEmailID.Name = "txtEmailID";
            this.txtEmailID.Size = new System.Drawing.Size(350, 79);
            this.txtEmailID.TabIndex = 5;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold);
            this.label8.Location = new System.Drawing.Point(141, 243);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(54, 15);
            this.label8.TabIndex = 4;
            this.label8.Text = "Email ID";
            // 
            // cmbFileName
            // 
            this.cmbFileName.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbFileName.FormattingEnabled = true;
            this.cmbFileName.Location = new System.Drawing.Point(386, 151);
            this.cmbFileName.Name = "cmbFileName";
            this.cmbFileName.Size = new System.Drawing.Size(350, 23);
            this.cmbFileName.TabIndex = 3;
            this.cmbFileName.SelectedIndexChanged += new System.EventHandler(this.cmbFileName_SelectedIndexChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold);
            this.label7.Location = new System.Drawing.Point(141, 151);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(62, 15);
            this.label7.TabIndex = 2;
            this.label7.Text = "File Name";
            // 
            // cmbReconName
            // 
            this.cmbReconName.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbReconName.FormattingEnabled = true;
            this.cmbReconName.Location = new System.Drawing.Point(386, 110);
            this.cmbReconName.Name = "cmbReconName";
            this.cmbReconName.Size = new System.Drawing.Size(350, 23);
            this.cmbReconName.TabIndex = 1;
            this.cmbReconName.SelectedIndexChanged += new System.EventHandler(this.cmbReconName_SelectedIndexChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(141, 113);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(73, 15);
            this.label6.TabIndex = 0;
            this.label6.Text = "Recon Name";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.groupBox1);
            this.tabPage3.ImageKey = "Reports";
            this.tabPage3.Location = new System.Drawing.Point(4, 24);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(1274, 483);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Reports";
            this.tabPage3.ToolTipText = "Reports";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.panel4);
            this.groupBox1.Controls.Add(this.pictureBox5);
            this.groupBox1.Location = new System.Drawing.Point(3, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1167, 298);
            this.groupBox1.TabIndex = 33;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "       Report";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.White;
            this.panel4.Controls.Add(this.pictureBox9);
            this.panel4.Controls.Add(this.pictureBox7);
            this.panel4.Controls.Add(this.pictureBox6);
            this.panel4.Controls.Add(this.label2);
            this.panel4.Controls.Add(this.To_Date);
            this.panel4.Controls.Add(this.label5);
            this.panel4.Controls.Add(this.btn_GenerateReport);
            this.panel4.Controls.Add(this.From_Date);
            this.panel4.Controls.Add(this.label4);
            this.panel4.Location = new System.Drawing.Point(265, 15);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(657, 279);
            this.panel4.TabIndex = 56;
            // 
            // pictureBox9
            // 
            this.pictureBox9.Image = global::ARC_Application.Properties.Resources.View291;
            this.pictureBox9.Location = new System.Drawing.Point(95, 40);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(32, 32);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox9.TabIndex = 69;
            this.pictureBox9.TabStop = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = global::ARC_Application.Properties.Resources.data_chooser_icon;
            this.pictureBox7.Location = new System.Drawing.Point(282, 102);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(24, 24);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox7.TabIndex = 67;
            this.pictureBox7.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global::ARC_Application.Properties.Resources.data_chooser_icon;
            this.pictureBox6.Location = new System.Drawing.Point(282, 49);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(24, 24);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox6.TabIndex = 66;
            this.pictureBox6.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(133, 45);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(104, 15);
            this.label2.TabIndex = 64;
            this.label2.Text = "Monthly Report";
            // 
            // To_Date
            // 
            this.To_Date.CustomFormat = "dd/MM/yyyy";
            this.To_Date.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.To_Date.Location = new System.Drawing.Point(355, 102);
            this.To_Date.Name = "To_Date";
            this.To_Date.Size = new System.Drawing.Size(106, 23);
            this.To_Date.TabIndex = 62;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(306, 107);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(27, 16);
            this.label5.TabIndex = 61;
            this.label5.Text = "To";
            // 
            // btn_GenerateReport
            // 
            this.btn_GenerateReport.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btn_GenerateReport.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_GenerateReport.ForeColor = System.Drawing.Color.White;
            this.btn_GenerateReport.Location = new System.Drawing.Point(260, 157);
            this.btn_GenerateReport.Name = "btn_GenerateReport";
            this.btn_GenerateReport.Size = new System.Drawing.Size(136, 28);
            this.btn_GenerateReport.TabIndex = 60;
            this.btn_GenerateReport.Text = "Generate Report";
            this.btn_GenerateReport.UseVisualStyleBackColor = false;
            this.btn_GenerateReport.Click += new System.EventHandler(this.btn_GenerateReport_Click);
            // 
            // From_Date
            // 
            this.From_Date.CustomFormat = "dd/MM/yyyy";
            this.From_Date.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.From_Date.Location = new System.Drawing.Point(355, 45);
            this.From_Date.Name = "From_Date";
            this.From_Date.Size = new System.Drawing.Size(106, 23);
            this.From_Date.TabIndex = 58;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(306, 49);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(43, 16);
            this.label4.TabIndex = 57;
            this.label4.Text = "From";
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::ARC_Application.Properties.Resources.Report21;
            this.pictureBox5.Location = new System.Drawing.Point(6, -3);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(22, 25);
            this.pictureBox5.TabIndex = 49;
            this.pictureBox5.TabStop = false;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.btnEditUser);
            this.tabPage4.Controls.Add(this.cmbAccessType);
            this.tabPage4.Controls.Add(this.btnClear);
            this.tabPage4.Controls.Add(this.btnSearch);
            this.tabPage4.Controls.Add(this.dataGridView);
            this.tabPage4.Controls.Add(this.btnAddUser);
            this.tabPage4.Controls.Add(this.btnDeleteUser);
            this.tabPage4.Controls.Add(this.label19);
            this.tabPage4.Controls.Add(this.label18);
            this.tabPage4.Controls.Add(this.label17);
            this.tabPage4.Controls.Add(this.label16);
            this.tabPage4.Controls.Add(this.chklstPageAccess);
            this.tabPage4.Controls.Add(this.chklstCountries);
            this.tabPage4.Controls.Add(this.chklstProduct);
            this.tabPage4.Controls.Add(this.chklstApplication);
            this.tabPage4.Controls.Add(this.txtLineManager);
            this.tabPage4.Controls.Add(this.txtUserName);
            this.tabPage4.Controls.Add(this.txtUserPSID);
            this.tabPage4.Controls.Add(this.label15);
            this.tabPage4.Controls.Add(this.label14);
            this.tabPage4.Controls.Add(this.label13);
            this.tabPage4.Controls.Add(this.label12);
            this.tabPage4.ImageKey = "UserMgt";
            this.tabPage4.Location = new System.Drawing.Point(4, 24);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(1274, 483);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "User Management";
            this.tabPage4.ToolTipText = "UserManagement";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // btnEditUser
            // 
            this.btnEditUser.Location = new System.Drawing.Point(672, 267);
            this.btnEditUser.Name = "btnEditUser";
            this.btnEditUser.Size = new System.Drawing.Size(96, 23);
            this.btnEditUser.TabIndex = 138;
            this.btnEditUser.Text = "EDIT USER";
            this.btnEditUser.UseVisualStyleBackColor = true;
            this.btnEditUser.Click += new System.EventHandler(this.btnEditUser_Click);
            // 
            // cmbAccessType
            // 
            this.cmbAccessType.FormattingEnabled = true;
            this.cmbAccessType.Items.AddRange(new object[] {
            "--SELECT--",
            "DataUpload User",
            "DataUpload Admin",
            "DataUpload Admin/DataUpload User"});
            this.cmbAccessType.Location = new System.Drawing.Point(365, 71);
            this.cmbAccessType.Name = "cmbAccessType";
            this.cmbAccessType.Size = new System.Drawing.Size(203, 23);
            this.cmbAccessType.TabIndex = 137;
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(821, 267);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(75, 23);
            this.btnClear.TabIndex = 136;
            this.btnClear.Text = "CLEAR";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(529, 267);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(75, 23);
            this.btnSearch.TabIndex = 135;
            this.btnSearch.Text = "SEARCH";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // dataGridView
            // 
            this.dataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView.GridColor = System.Drawing.Color.Blue;
            this.dataGridView.Location = new System.Drawing.Point(132, 317);
            this.dataGridView.Name = "dataGridView";
            this.dataGridView.Size = new System.Drawing.Size(876, 150);
            this.dataGridView.TabIndex = 134;
            // 
            // btnAddUser
            // 
            this.btnAddUser.Location = new System.Drawing.Point(259, 267);
            this.btnAddUser.Name = "btnAddUser";
            this.btnAddUser.Size = new System.Drawing.Size(75, 23);
            this.btnAddUser.TabIndex = 133;
            this.btnAddUser.Text = "ADD USER";
            this.btnAddUser.UseVisualStyleBackColor = true;
            this.btnAddUser.Click += new System.EventHandler(this.btnAddUser_Click);
            // 
            // btnDeleteUser
            // 
            this.btnDeleteUser.Location = new System.Drawing.Point(383, 267);
            this.btnDeleteUser.Name = "btnDeleteUser";
            this.btnDeleteUser.Size = new System.Drawing.Size(96, 23);
            this.btnDeleteUser.TabIndex = 132;
            this.btnDeleteUser.Text = "DELETE USER";
            this.btnDeleteUser.UseVisualStyleBackColor = true;
            this.btnDeleteUser.Click += new System.EventHandler(this.btnDeleteUser_Click);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(889, 99);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(78, 15);
            this.label19.TabIndex = 131;
            this.label19.Text = "Page Access";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(623, 109);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(65, 15);
            this.label18.TabIndex = 130;
            this.label18.Text = "Countries";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(180, 108);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(61, 15);
            this.label17.TabIndex = 129;
            this.label17.Text = "Products";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(395, 109);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(76, 15);
            this.label16.TabIndex = 128;
            this.label16.Text = "Application";
            // 
            // chklstPageAccess
            // 
            this.chklstPageAccess.FormattingEnabled = true;
            this.chklstPageAccess.Location = new System.Drawing.Point(855, 136);
            this.chklstPageAccess.Name = "chklstPageAccess";
            this.chklstPageAccess.Size = new System.Drawing.Size(153, 112);
            this.chklstPageAccess.TabIndex = 127;
            // 
            // chklstCountries
            // 
            this.chklstCountries.CheckOnClick = true;
            this.chklstCountries.FormattingEnabled = true;
            this.chklstCountries.Location = new System.Drawing.Point(594, 136);
            this.chklstCountries.Name = "chklstCountries";
            this.chklstCountries.Size = new System.Drawing.Size(153, 112);
            this.chklstCountries.TabIndex = 126;
            // 
            // chklstProduct
            // 
            this.chklstProduct.CheckOnClick = true;
            this.chklstProduct.FormattingEnabled = true;
            this.chklstProduct.Location = new System.Drawing.Point(132, 136);
            this.chklstProduct.Name = "chklstProduct";
            this.chklstProduct.Size = new System.Drawing.Size(153, 112);
            this.chklstProduct.TabIndex = 125;
            // 
            // chklstApplication
            // 
            this.chklstApplication.FormattingEnabled = true;
            this.chklstApplication.Location = new System.Drawing.Point(365, 136);
            this.chklstApplication.Name = "chklstApplication";
            this.chklstApplication.Size = new System.Drawing.Size(153, 112);
            this.chklstApplication.TabIndex = 124;
            // 
            // txtLineManager
            // 
            this.txtLineManager.Location = new System.Drawing.Point(821, 71);
            this.txtLineManager.Name = "txtLineManager";
            this.txtLineManager.Size = new System.Drawing.Size(100, 23);
            this.txtLineManager.TabIndex = 123;
            // 
            // txtUserName
            // 
            this.txtUserName.Location = new System.Drawing.Point(825, 19);
            this.txtUserName.Name = "txtUserName";
            this.txtUserName.Size = new System.Drawing.Size(100, 23);
            this.txtUserName.TabIndex = 122;
            // 
            // txtUserPSID
            // 
            this.txtUserPSID.Location = new System.Drawing.Point(365, 11);
            this.txtUserPSID.Name = "txtUserPSID";
            this.txtUserPSID.Size = new System.Drawing.Size(100, 23);
            this.txtUserPSID.TabIndex = 121;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(238, 19);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(33, 15);
            this.label15.TabIndex = 120;
            this.label15.Text = "PSID";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(681, 74);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(110, 15);
            this.label14.TabIndex = 119;
            this.label14.Text = "Line Manager PSID";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(238, 74);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(78, 15);
            this.label13.TabIndex = 118;
            this.label13.Text = "Access_Type";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(681, 19);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(69, 15);
            this.label12.TabIndex = 117;
            this.label12.Text = "User_Name";
            // 
            // tabPage5
            // 
            this.tabPage5.ImageKey = "Recon Details";
            this.tabPage5.Location = new System.Drawing.Point(4, 24);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(1274, 483);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Recon Details";
            this.tabPage5.ToolTipText = "Recon Details";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.DGV_Holiday);
            this.tabPage1.Controls.Add(this.txt_HolidayReson);
            this.tabPage1.Controls.Add(this.label22);
            this.tabPage1.Controls.Add(this.dtPicker_From);
            this.tabPage1.Controls.Add(this.label21);
            this.tabPage1.Controls.Add(this.btn_DeleteCalendar);
            this.tabPage1.Controls.Add(this.btn_AddCalendar);
            this.tabPage1.Controls.Add(this.btn_UpdateCalendar);
            this.tabPage1.Controls.Add(this.btn_ViewCalendar);
            this.tabPage1.Controls.Add(this.label20);
            this.tabPage1.Controls.Add(this.cmb_Holiday);
            this.tabPage1.Location = new System.Drawing.Point(4, 24);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Size = new System.Drawing.Size(1274, 483);
            this.tabPage1.TabIndex = 5;
            this.tabPage1.Text = "Holiday Calendar";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // DGV_Holiday
            // 
            this.DGV_Holiday.AllowUserToAddRows = false;
            this.DGV_Holiday.AllowUserToDeleteRows = false;
            this.DGV_Holiday.AllowUserToResizeRows = false;
            dataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle19.BackColor = System.Drawing.SystemColors.Info;
            dataGridViewCellStyle19.SelectionBackColor = System.Drawing.Color.Transparent;
            dataGridViewCellStyle19.SelectionForeColor = System.Drawing.Color.Black;
            this.DGV_Holiday.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle19;
            this.DGV_Holiday.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DGV_Holiday.BackgroundColor = System.Drawing.Color.White;
            this.DGV_Holiday.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.DGV_Holiday.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Sunken;
            this.DGV_Holiday.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle20.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle20.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle20.Font = new System.Drawing.Font("Cambria", 9.75F);
            dataGridViewCellStyle20.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle20.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle20.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle20.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DGV_Holiday.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle20;
            this.DGV_Holiday.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle21.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle21.BackColor = System.Drawing.Color.MintCream;
            dataGridViewCellStyle21.Font = new System.Drawing.Font("Cambria", 9.75F);
            dataGridViewCellStyle21.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle21.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle21.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle21.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.DGV_Holiday.DefaultCellStyle = dataGridViewCellStyle21;
            this.DGV_Holiday.GridColor = System.Drawing.Color.Blue;
            this.DGV_Holiday.Location = new System.Drawing.Point(22, 105);
            this.DGV_Holiday.Name = "DGV_Holiday";
            this.DGV_Holiday.ReadOnly = true;
            this.DGV_Holiday.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.DGV_Holiday.RowHeadersVisible = false;
            this.DGV_Holiday.RowHeadersWidth = 31;
            this.DGV_Holiday.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.DGV_Holiday.Size = new System.Drawing.Size(979, 329);
            this.DGV_Holiday.TabIndex = 91;
            this.DGV_Holiday.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DGV_Holiday_CellContentClick);
            // 
            // txt_HolidayReson
            // 
            this.txt_HolidayReson.Location = new System.Drawing.Point(319, 61);
            this.txt_HolidayReson.Name = "txt_HolidayReson";
            this.txt_HolidayReson.Size = new System.Drawing.Size(271, 23);
            this.txt_HolidayReson.TabIndex = 90;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(224, 64);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(89, 15);
            this.label22.TabIndex = 89;
            this.label22.Text = "Holiday Reason";
            // 
            // dtPicker_From
            // 
            this.dtPicker_From.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtPicker_From.Location = new System.Drawing.Point(93, 60);
            this.dtPicker_From.Name = "dtPicker_From";
            this.dtPicker_From.Size = new System.Drawing.Size(110, 23);
            this.dtPicker_From.TabIndex = 88;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(19, 64);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(68, 15);
            this.label21.TabIndex = 87;
            this.label21.Text = "Date Range";
            // 
            // btn_DeleteCalendar
            // 
            this.btn_DeleteCalendar.Location = new System.Drawing.Point(876, 60);
            this.btn_DeleteCalendar.Name = "btn_DeleteCalendar";
            this.btn_DeleteCalendar.Size = new System.Drawing.Size(125, 23);
            this.btn_DeleteCalendar.TabIndex = 86;
            this.btn_DeleteCalendar.Text = "Delete Calendar";
            this.btn_DeleteCalendar.UseVisualStyleBackColor = true;
            this.btn_DeleteCalendar.Click += new System.EventHandler(this.btn_DeleteCalendar_Click);
            // 
            // btn_AddCalendar
            // 
            this.btn_AddCalendar.Location = new System.Drawing.Point(745, 60);
            this.btn_AddCalendar.Name = "btn_AddCalendar";
            this.btn_AddCalendar.Size = new System.Drawing.Size(125, 23);
            this.btn_AddCalendar.TabIndex = 85;
            this.btn_AddCalendar.Text = "Add Calendar";
            this.btn_AddCalendar.UseVisualStyleBackColor = true;
            this.btn_AddCalendar.Click += new System.EventHandler(this.btn_AddCalendar_Click);
            // 
            // btn_UpdateCalendar
            // 
            this.btn_UpdateCalendar.Location = new System.Drawing.Point(614, 60);
            this.btn_UpdateCalendar.Name = "btn_UpdateCalendar";
            this.btn_UpdateCalendar.Size = new System.Drawing.Size(125, 23);
            this.btn_UpdateCalendar.TabIndex = 84;
            this.btn_UpdateCalendar.Text = "Update Calendar";
            this.btn_UpdateCalendar.UseVisualStyleBackColor = true;
            this.btn_UpdateCalendar.Click += new System.EventHandler(this.btn_UpdateCalendar_Click);
            // 
            // btn_ViewCalendar
            // 
            this.btn_ViewCalendar.Location = new System.Drawing.Point(363, 17);
            this.btn_ViewCalendar.Name = "btn_ViewCalendar";
            this.btn_ViewCalendar.Size = new System.Drawing.Size(125, 23);
            this.btn_ViewCalendar.TabIndex = 83;
            this.btn_ViewCalendar.Text = "View Calendar";
            this.btn_ViewCalendar.UseVisualStyleBackColor = true;
            this.btn_ViewCalendar.Click += new System.EventHandler(this.btn_ViewCalendar_Click);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(19, 20);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(51, 15);
            this.label20.TabIndex = 82;
            this.label20.Text = "Country";
            // 
            // cmb_Holiday
            // 
            this.cmb_Holiday.FormattingEnabled = true;
            this.cmb_Holiday.Location = new System.Drawing.Point(76, 17);
            this.cmb_Holiday.Name = "cmb_Holiday";
            this.cmb_Holiday.Size = new System.Drawing.Size(237, 23);
            this.cmb_Holiday.TabIndex = 81;
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.lbl_cntry);
            this.tabPage6.Controls.Add(this.cmb_FTP_cntry);
            this.tabPage6.Controls.Add(this.lbl_Prd);
            this.tabPage6.Controls.Add(this.cmb_FTP_Prdt);
            this.tabPage6.Controls.Add(this.DGV_FTP);
            this.tabPage6.Controls.Add(this.btnUpdate_FTP);
            this.tabPage6.Location = new System.Drawing.Point(4, 24);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Size = new System.Drawing.Size(1274, 483);
            this.tabPage6.TabIndex = 6;
            this.tabPage6.Text = "FTP Status";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // lbl_cntry
            // 
            this.lbl_cntry.AutoSize = true;
            this.lbl_cntry.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_cntry.Location = new System.Drawing.Point(265, 22);
            this.lbl_cntry.Name = "lbl_cntry";
            this.lbl_cntry.Size = new System.Drawing.Size(51, 15);
            this.lbl_cntry.TabIndex = 96;
            this.lbl_cntry.Text = "Country";
            // 
            // cmb_FTP_cntry
            // 
            this.cmb_FTP_cntry.FormattingEnabled = true;
            this.cmb_FTP_cntry.Location = new System.Drawing.Point(322, 19);
            this.cmb_FTP_cntry.Name = "cmb_FTP_cntry";
            this.cmb_FTP_cntry.Size = new System.Drawing.Size(121, 23);
            this.cmb_FTP_cntry.TabIndex = 94;
            this.cmb_FTP_cntry.SelectedIndexChanged += new System.EventHandler(this.cmb_FTP_cntry_SelectedIndexChanged);
            // 
            // lbl_Prd
            // 
            this.lbl_Prd.AutoSize = true;
            this.lbl_Prd.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Prd.Location = new System.Drawing.Point(29, 22);
            this.lbl_Prd.Name = "lbl_Prd";
            this.lbl_Prd.Size = new System.Drawing.Size(52, 15);
            this.lbl_Prd.TabIndex = 95;
            this.lbl_Prd.Text = "Products";
            // 
            // cmb_FTP_Prdt
            // 
            this.cmb_FTP_Prdt.FormattingEnabled = true;
            this.cmb_FTP_Prdt.Location = new System.Drawing.Point(87, 18);
            this.cmb_FTP_Prdt.Name = "cmb_FTP_Prdt";
            this.cmb_FTP_Prdt.Size = new System.Drawing.Size(121, 23);
            this.cmb_FTP_Prdt.TabIndex = 93;
            this.cmb_FTP_Prdt.SelectedIndexChanged += new System.EventHandler(this.cmb_FTP_Prdt_SelectedIndexChanged);
            // 
            // DGV_FTP
            // 
            this.DGV_FTP.AllowUserToAddRows = false;
            this.DGV_FTP.AllowUserToDeleteRows = false;
            this.DGV_FTP.AllowUserToResizeRows = false;
            dataGridViewCellStyle22.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle22.BackColor = System.Drawing.SystemColors.Info;
            dataGridViewCellStyle22.SelectionBackColor = System.Drawing.Color.Transparent;
            dataGridViewCellStyle22.SelectionForeColor = System.Drawing.Color.Black;
            this.DGV_FTP.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle22;
            this.DGV_FTP.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DGV_FTP.BackgroundColor = System.Drawing.Color.White;
            this.DGV_FTP.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.DGV_FTP.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Sunken;
            this.DGV_FTP.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle23.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle23.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle23.Font = new System.Drawing.Font("Cambria", 9.75F);
            dataGridViewCellStyle23.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle23.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle23.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle23.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DGV_FTP.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle23;
            this.DGV_FTP.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle24.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle24.BackColor = System.Drawing.Color.MintCream;
            dataGridViewCellStyle24.Font = new System.Drawing.Font("Cambria", 9.75F);
            dataGridViewCellStyle24.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle24.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle24.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle24.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.DGV_FTP.DefaultCellStyle = dataGridViewCellStyle24;
            this.DGV_FTP.GridColor = System.Drawing.Color.Blue;
            this.DGV_FTP.Location = new System.Drawing.Point(22, 47);
            this.DGV_FTP.Name = "DGV_FTP";
            this.DGV_FTP.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.DGV_FTP.RowHeadersVisible = false;
            this.DGV_FTP.RowHeadersWidth = 31;
            this.DGV_FTP.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.DGV_FTP.Size = new System.Drawing.Size(979, 385);
            this.DGV_FTP.TabIndex = 92;
            // 
            // btnUpdate_FTP
            // 
            this.btnUpdate_FTP.Location = new System.Drawing.Point(496, 17);
            this.btnUpdate_FTP.Name = "btnUpdate_FTP";
            this.btnUpdate_FTP.Size = new System.Drawing.Size(125, 23);
            this.btnUpdate_FTP.TabIndex = 85;
            this.btnUpdate_FTP.Text = "Update FTP";
            this.btnUpdate_FTP.UseVisualStyleBackColor = true;
            this.btnUpdate_FTP.Click += new System.EventHandler(this.btnUpdate_FTP_Click);
            // 
            // Admin_Config
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1282, 510);
            this.ControlBox = false;
            this.Controls.Add(this.tabControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Admin_Config";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Admin_Config_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).EndInit();
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_Holiday)).EndInit();
            this.tabPage6.ResumeLayout(false);
            this.tabPage6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_FTP)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DateTimePicker To_Date;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btn_GenerateReport;
        private System.Windows.Forms.DateTimePicker From_Date;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.Button btnEditUser;
        private System.Windows.Forms.ComboBox cmbAccessType;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.Button btnAddUser;
        private System.Windows.Forms.Button btnDeleteUser;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.CheckedListBox chklstPageAccess;
        private System.Windows.Forms.CheckedListBox chklstCountries;
        private System.Windows.Forms.CheckedListBox chklstProduct;
        private System.Windows.Forms.CheckedListBox chklstApplication;
        private System.Windows.Forms.TextBox txtLineManager;
        private System.Windows.Forms.TextBox txtUserName;
        private System.Windows.Forms.TextBox txtUserPSID;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TextBox txt_HolidayReson;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.DateTimePicker dtPicker_From;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Button btn_DeleteCalendar;
        private System.Windows.Forms.Button btn_AddCalendar;
        private System.Windows.Forms.Button btn_UpdateCalendar;
        private System.Windows.Forms.Button btn_ViewCalendar;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.ComboBox cmb_Holiday;
        private System.Windows.Forms.DataGridView DGV_Holiday;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.DataGridView DGV_FTP;
        private System.Windows.Forms.Button btnUpdate_FTP;
        private System.Windows.Forms.Label lbl_cntry;
        private System.Windows.Forms.ComboBox cmb_FTP_cntry;
        private System.Windows.Forms.Label lbl_Prd;
        private System.Windows.Forms.ComboBox cmb_FTP_Prdt;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button btnDownloadRecipientList;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnUpdateRecipient;
        private System.Windows.Forms.TextBox txtEmailID;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox cmbFileName;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox cmbReconName;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.CheckBox ckb_IsMailFunctionalityRequired;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.ComboBox cmbProductName;
        private System.Windows.Forms.DataGridView dataGridView;



    }
}