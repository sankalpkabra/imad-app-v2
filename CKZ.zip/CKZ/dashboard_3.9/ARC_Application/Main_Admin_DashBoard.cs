﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using Microsoft.Office.Interop.Excel;
using System.Globalization;
using System.Configuration;
using System.IO;
using System.Collections;
using System.Security.Cryptography;

namespace ARC_Application
{
    public partial class Main_Admin_DashBoard : Form
    {
        ArrayList arraylist1 = new ArrayList();
        ArrayList arraylist2 = new ArrayList();
        List<System.Data.DataTable> dtArrList = new List<System.Data.DataTable>();
        static string Main_DIR_SharePath = ConfigurationManager.ConnectionStrings["Share_Path"].ToString();
        string Directory = Main_DIR_SharePath + DateTime.Now.ToString("dd-MMM-yyyy") + "_Files\\";
        Formatting_Logics obj = new Formatting_Logics();
        static string conString = ConfigurationManager.ConnectionStrings["ARC_conStr"].ConnectionString;
        SQLEncryption ecp = new SQLEncryption();
        string strAppl = "";
        string strCountr = "";
        string strPrdt = "";
        string date;
        string selectedProduct;
        string selectedcountry;
        int i;
        int j;
        System.Data.DataTable dt = new System.Data.DataTable();
        //Image i1 = Image.FromFile(@"\\10.132.5.214\TempFiles\ARC Main Solutions\ARC_Latest_Solution\Images\index1.jpg");
        //Image i2 = Image.FromFile(@"\\10.132.5.214\TempFiles\ARC Main Solutions\ARC_Latest_Solution\Images\index2.jpg");
        //Image i3 = Image.FromFile(@"\\10.132.5.214\TempFiles\ARC Main Solutions\ARC_Latest_Solution\Images\index3.png");
        int Total;
        int Completed;
        string sla;
        SqlConnection con;
        SqlCommand cmd;
        SqlDataAdapter da;
        int countryID = 0;
        int HolidayID = 0;

        public Main_Admin_DashBoard()
        {
            InitializeComponent();
            ViewRecord();
            refreshdata();
            HolidayData();
            Date_Check();

            // Create_Directory();
            if (!conString.StartsWith("Data"))
            {
                conString = ecp.Decrypt(conString);
            }
            Timer timer = new Timer();
            timer.Interval = (100 * 2000); // 10 secs
            timer.Tick += new EventHandler(timer1_Tick);
            timer.Start();
            tabPage1.AutoScroll = true;
            Acc_Type.SelectedIndex = 0;
        }

        public void Date_Check()
        {
            From_Date.MinDate = DateTime.Now.AddDays(-30);
            From_Date.MaxDate = DateTime.Now;
            To_Date.MinDate = DateTime.Now.AddDays(-30);
            To_Date.MaxDate = DateTime.Now;
        }

        public byte[] imageToByteArray(System.Drawing.Image imageIn)
        {
            MemoryStream ms = new MemoryStream();
            imageIn.Save(ms, System.Drawing.Imaging.ImageFormat.Gif);
            return ms.ToArray();
        }

        protected override void WndProc(ref Message m)
        {
            base.WndProc(ref m);
            if (m.Msg == 0x0112)
            {
                if (m.WParam == new IntPtr(0xF030))
                {
                    Ref.Location = new System.Drawing.Point(1200, 130);
                    lnk_Logout.Location = new System.Drawing.Point(1270, 0);
                    Loading.Location = new System.Drawing.Point(650, 0);
                    Logout.Location = new System.Drawing.Point(1250, 80);
                    DGV_AData.Width = 1300;
                    DGV_AData.Height = 600;
                    DGV_AData.Location = new System.Drawing.Point(4, 185);
                    Btn_Clr.Location = new System.Drawing.Point(1240, 131);
                    tabControl1.Height = 500;
                    tabControl1.Width = 1350;
                    tabPage1.AutoScroll = true;
                }
                else if (m.WParam == new IntPtr(0xF120))
                {

                    //Main_Admin_DashBoard.ActiveForm.Size = new Size(1201, 494);//this.Size = new Size(1201, 494);
                    //Main_Admin_DashBoard.ActiveForm.Location = new System.Drawing.Point();
                    //Main_Admin_DashBoard.ActiveForm.StartPosition = FormStartPosition.CenterScreen;
                    DGV_AData.Height = 241;
                    DGV_AData.Width = 1097;

                    lnk_Logout.Location = new System.Drawing.Point(1192, 82);
                    Btn_Clr.Location = new System.Drawing.Point(1013, 89);
                    tabControl1.Height = 423;
                    tabControl1.Width = 1242;
                    tabPage1.AutoScroll = true;

                }

            }
        }

        public void refreshdata()
        {
            System.Data.DataTable dt_Final = new System.Data.DataTable();
            dt_Final.Columns.Add("Country_Id");
            dt_Final.Columns.Add("Country_Name");
            dt_Final.Rows.Add("0", "--SELECT LIST--");
            SqlConnection con = new SqlConnection(conString);
            con.Open();
            SqlCommand cmd = new SqlCommand("ARC_SP_GetCountries", con);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            System.Data.DataTable dt = new System.Data.DataTable();
            sda.Fill(dt);

            foreach (DataRow d in dt.Rows)
            {
                dt_Final.ImportRow(d);
            }

            cmb_cntry.SelectedIndexChanged -= new EventHandler(cmb_cntry_SelectedIndexChanged);
            cmb_cntry.ValueMember = "Country_Id";
            cmb_cntry.DisplayMember = "Country_Name";
            cmb_cntry.DataSource = dt_Final;
            cmb_cntry.SelectedIndexChanged += new EventHandler(cmb_cntry_SelectedIndexChanged);

            System.Data.DataTable dt_Final1 = new System.Data.DataTable();
            dt_Final1.Columns.Add("Product_ID");
            dt_Final1.Columns.Add("Product_name");
            dt_Final1.Rows.Add("0", "--SELECT LIST--");
            cmd = new SqlCommand("ARC_SP_GetProducts", con);
            cmd.CommandType = CommandType.StoredProcedure;
            sda = new SqlDataAdapter(cmd);
            dt = new System.Data.DataTable();
            sda.Fill(dt);
            foreach (DataRow d in dt.Rows)
            {
                dt_Final1.ImportRow(d);
            }

            cmb_Prdt.SelectedIndexChanged -= new EventHandler(cmb_Prdt_SelectedIndexChanged);
            cmb_Prdt.ValueMember = "Product_ID";
            cmb_Prdt.DisplayMember = "Product_name";
            cmb_Prdt.DataSource = dt_Final1;
            cmb_Prdt.SelectedIndexChanged += new EventHandler(cmb_Prdt_SelectedIndexChanged);

            con.Close();

        }

        public void Total_count()
        {

            SqlConnection con = new SqlConnection(conString);
            con.Open();
            SqlCommand com = new SqlCommand("select count (*) as Total from ARC_Recon_Master", con);
            com.CommandType = CommandType.Text;
            SqlDataReader dr = com.ExecuteReader();
            while (dr.Read())
            {
                if (dr.HasRows == true)
                {
                    Total = (int)dr["Total"];
                }
            }
            con.Close();
            con.Open();
            com = new SqlCommand("select count (*) as Completed from ARC_Recon_Master where Is_Recon_Completed= 'true'", con);
            com.CommandType = CommandType.Text;
            dr = com.ExecuteReader();
            while (dr.Read())
            {
                if (dr.HasRows == true)
                {
                    Completed = (int)dr["Completed"];
                }
            }
            con.Close();
            lbl_cnt.Text = Total.ToString();
            lbl_com_cnt.Text = Completed.ToString();
            lbl_pen_cnt.Text = (Total - Completed).ToString();
        }

        public void Products_count()
        {

            selectedProduct = this.cmb_Prdt.GetItemText(this.cmb_Prdt.SelectedItem);
            SqlConnection con = new SqlConnection(conString);
            con.Open();
            SqlCommand com = new SqlCommand("select count (*) as Total from ARC_Recon_Master where Team='" + selectedProduct + "'", con);
            com.CommandType = CommandType.Text;
            SqlDataReader dr = com.ExecuteReader();
            while (dr.Read())
            {
                if (dr.HasRows == true)
                {
                    Total = (int)dr["Total"];
                }
            }
            con.Close();
            con.Open();
            com = new SqlCommand("select count (*) as Completed from ARC_Recon_Master where Is_Recon_Completed= 'true' and Team='" + selectedProduct + "'", con);
            com.CommandType = CommandType.Text;
            dr = com.ExecuteReader();
            while (dr.Read())
            {
                if (dr.HasRows == true)
                {
                    Completed = (int)dr["Completed"];
                }
            }
            con.Close();
            lbl_cnt.Text = Total.ToString();
            lbl_com_cnt.Text = Completed.ToString();
            lbl_pen_cnt.Text = (Total - Completed).ToString();
        }

        private void Btn_Clr_Click(object sender, EventArgs e)
        {
            cmb_cntry.SelectedIndex = 0;
            cmb_Prdt.SelectedIndex = 0;
            ViewRecord();
        }

        public void ViewRecord()
        {
            date = DateTime.Now.ToString("HH:MM");
            try
            {
                SqlConnection con = new SqlConnection(conString);
                con.Open();
                cmd = new SqlCommand("ARC_SP_TotalProcessedReconCount", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Action", "All");
                da = new SqlDataAdapter(cmd);
                // DataTable dt1 = new DataTable();
                da.Fill(dt);
                //con.Close();
                //con.Open();
                //cmd = new SqlCommand("", con);
                dt.Columns.Add("Time To SLA");
                dt.Columns.Add("Actions", typeof(byte[]));
                if (dt.Columns.Contains("Actions"))
                {
                    for (int indx = 0; indx < dt.Rows.Count; indx++)
                    {
                        string sd1 = dt.Rows[indx][4].ToString();
                        string sd2 = date.ToString();
                        DateTime d = Convert.ToDateTime(dt.Rows[indx][5]);
                        DateTime d1 = Convert.ToDateTime(date);
                        sla = (d - d1).ToString();
                        if (Convert.ToBoolean(dt.Rows[indx][7]) == true && d.TimeOfDay < d1.TimeOfDay)
                        {
                            dt.Rows[indx][8] = "0.00";
                            dt.Rows[indx][9] = imageToByteArray(i1);
                        }
                        else if (Convert.ToBoolean(dt.Rows[indx][7]) == false && d.TimeOfDay > d1.TimeOfDay)
                        {
                            dt.Rows[indx][8] = sla;
                            dt.Rows[indx][9] = imageToByteArray(i3);
                        }
                        else if (Convert.ToBoolean(dt.Rows[indx][7]) == false && d.TimeOfDay < d1.TimeOfDay)
                        {
                            dt.Rows[indx][8] = sla;
                            dt.Rows[indx][9] = imageToByteArray(i2);
                        }
                        else if (Convert.ToBoolean(dt.Rows[indx][7]) == true && d.TimeOfDay > d1.TimeOfDay)
                        {
                            dt.Rows[indx][8] = "0.00";
                            dt.Rows[indx][9] = imageToByteArray(i1);
                        }
                    }
                }
                dt.Columns.Remove("Is_Recon_Completed");
                DGV_AData.DataSource = dt;
                con.Close();
                Total_count();
                DGV_AData.AllowUserToAddRows = false;
            }
            catch (Exception)
            { }
        }

        private void lnk_Logout_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            foreach (var p in System.Diagnostics.Process.GetProcessesByName("OpenSpan.Runtime"))
            {
                p.Kill();
            }
            this.Close();
            MessageBox.Show("You Have LoggedOut Successfully");
        }

        private void cmb_Prdt_SelectedIndexChanged(object sender, EventArgs e)
        {
            j = cmb_Prdt.SelectedIndex;
            selectedProduct = this.cmb_Prdt.GetItemText(this.cmb_Prdt.SelectedItem);
            SqlConnection con = new SqlConnection(conString);
            if (j != 0)
            {
                con.Open();
                dt = new System.Data.DataTable();
                SqlCommand cmd = new SqlCommand("ARC_SP_TotalProcessedReconCount", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Action", "Product");
                cmd.Parameters.AddWithValue("@Product_ID", null);
                cmd.Parameters.AddWithValue("@Country_Id", null);
                cmd.Parameters.AddWithValue("@Country_Name", null);
                cmd.Parameters.AddWithValue("@team", selectedProduct);

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
                if (!dt.Columns.Contains("Actions"))
                {
                    dt.Columns.Add("Time To SLA");
                    dt.Columns.Add("Actions", typeof(byte[]));

                    for (int indx = 0; indx < dt.Rows.Count; indx++)
                    {
                        DateTime d = Convert.ToDateTime(dt.Rows[indx][5]);
                        DateTime d1 = Convert.ToDateTime(date);
                        sla = (d - d1).ToString();
                        if (Convert.ToBoolean(dt.Rows[indx][7]) == true && d.TimeOfDay < d1.TimeOfDay)
                        {
                            dt.Rows[indx][8] = "0.00";
                            dt.Rows[indx][9] = imageToByteArray(i1);
                        }
                        else if (Convert.ToBoolean(dt.Rows[indx][7]) == false && d.TimeOfDay > d1.TimeOfDay)
                        {
                            dt.Rows[indx][8] = sla;
                            dt.Rows[indx][9] = imageToByteArray(i3);
                        }
                        else if (Convert.ToBoolean(dt.Rows[indx][7]) == false && d.TimeOfDay < d1.TimeOfDay)
                        {
                            dt.Rows[indx][8] = sla;
                            dt.Rows[indx][9] = imageToByteArray(i2);
                        }
                        else if (Convert.ToBoolean(dt.Rows[indx][7]) == true && d.TimeOfDay > d1.TimeOfDay)
                        {
                            dt.Rows[indx][8] = "0.00";
                            dt.Rows[indx][9] = imageToByteArray(i1);
                        }
                    }
                }
                else
                {
                    for (int indx = 0; indx < dt.Rows.Count; indx++)
                    {
                        DateTime d = Convert.ToDateTime(dt.Rows[indx][5]);
                        DateTime d1 = Convert.ToDateTime(date);
                        sla = (d - d1).ToString();
                        if (Convert.ToBoolean(dt.Rows[indx][7]) == true && d.TimeOfDay < d1.TimeOfDay)
                        {
                            dt.Rows[indx][8] = "0.00";
                            dt.Rows[indx][9] = imageToByteArray(i1);
                        }
                        else if (Convert.ToBoolean(dt.Rows[indx][7]) == false && d.TimeOfDay > d1.TimeOfDay)
                        {
                            dt.Rows[indx][8] = sla;
                            dt.Rows[indx][9] = imageToByteArray(i3);
                        }
                        else if (Convert.ToBoolean(dt.Rows[indx][7]) == false && d.TimeOfDay < d1.TimeOfDay)
                        {
                            dt.Rows[indx][8] = sla;
                            dt.Rows[indx][9] = imageToByteArray(i2);
                        }
                        else if (Convert.ToBoolean(dt.Rows[indx][7]) == true && d.TimeOfDay > d1.TimeOfDay)
                        {
                            dt.Rows[indx][8] = "0.00";
                            dt.Rows[indx][9] = imageToByteArray(i1);
                        }
                    }
                }
                dt.Columns.Remove("Is_Recon_Completed");
                DGV_AData.DataSource = dt;
                con.Close();
                Products_count();
                DGV_AData.AllowUserToAddRows = false;

            }
        }

        private void cmb_cntry_SelectedIndexChanged(object sender, EventArgs e)
        {

            i = cmb_cntry.SelectedIndex;
            j = cmb_Prdt.SelectedIndex;
            selectedcountry = this.cmb_cntry.GetItemText(this.cmb_cntry.SelectedItem);
            selectedProduct = this.cmb_Prdt.GetItemText(this.cmb_Prdt.SelectedItem);
            if (j != 0)
            {
                SqlConnection con = new SqlConnection(conString);
                if (i != 0)
                {
                    con.Open();
                    dt = new System.Data.DataTable();
                    SqlCommand cmd = new SqlCommand("ARC_SP_TotalProcessedReconCount", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Action", "Country");
                    cmd.Parameters.AddWithValue("@Country_Id", null);
                    cmd.Parameters.AddWithValue("@Country_Name", selectedcountry);
                    cmd.Parameters.AddWithValue("@team", selectedProduct);

                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(dt);
                    if (!dt.Columns.Contains("Actions"))
                    {
                        dt.Columns.Add("Time To SLA");
                        dt.Columns.Add("Actions", typeof(byte[]));

                        for (int indx = 0; indx < dt.Rows.Count; indx++)
                        {
                            DateTime d = Convert.ToDateTime(dt.Rows[indx][5]);
                            DateTime d1 = Convert.ToDateTime(date);
                            sla = (d - d1).ToString();
                            if (Convert.ToBoolean(dt.Rows[indx][7]) == true && d.TimeOfDay < d1.TimeOfDay)
                            {
                                dt.Rows[indx][8] = "0.00";
                                dt.Rows[indx][9] = imageToByteArray(i1);
                            }
                            else if (Convert.ToBoolean(dt.Rows[indx][7]) == false && d.TimeOfDay > d1.TimeOfDay)
                            {
                                dt.Rows[indx][8] = sla;
                                dt.Rows[indx][9] = imageToByteArray(i3);
                            }
                            else if (Convert.ToBoolean(dt.Rows[indx][7]) == false && d.TimeOfDay < d1.TimeOfDay)
                            {
                                dt.Rows[indx][8] = sla;
                                dt.Rows[indx][9] = imageToByteArray(i2);
                            }
                            else if (Convert.ToBoolean(dt.Rows[indx][7]) == true && d.TimeOfDay > d1.TimeOfDay)
                            {
                                dt.Rows[indx][8] = "0.00";
                                dt.Rows[indx][9] = imageToByteArray(i1);
                            }
                        }
                    }
                    else
                    {
                        for (int indx = 0; indx < dt.Rows.Count; indx++)
                        {
                            DateTime d = Convert.ToDateTime(dt.Rows[indx][5]);
                            DateTime d1 = Convert.ToDateTime(date);
                            sla = (d - d1).ToString();
                            if (Convert.ToBoolean(dt.Rows[indx][7]) == true && d.TimeOfDay < d1.TimeOfDay)
                            {
                                dt.Rows[indx][8] = "0.00";
                                dt.Rows[indx][9] = imageToByteArray(i1);
                            }
                            else if (Convert.ToBoolean(dt.Rows[indx][7]) == false && d.TimeOfDay > d1.TimeOfDay)
                            {
                                dt.Rows[indx][8] = sla;
                                dt.Rows[indx][9] = imageToByteArray(i3);
                            }
                            else if (Convert.ToBoolean(dt.Rows[indx][7]) == false && d.TimeOfDay < d1.TimeOfDay)
                            {
                                dt.Rows[indx][8] = sla;
                                dt.Rows[indx][9] = imageToByteArray(i2);
                            }
                            else if (Convert.ToBoolean(dt.Rows[indx][7]) == true && d.TimeOfDay > d1.TimeOfDay)
                            {
                                dt.Rows[indx][8] = "0.00";
                                dt.Rows[indx][9] = imageToByteArray(i1);
                            }
                        }
                    }
                    dt.Columns.Remove("Is_Recon_Completed");
                    DGV_AData.DataSource = dt;
                    con.Close();
                    Countrys_count();
                    DGV_AData.AllowUserToAddRows = false;

                }

            }
            else
            {
                MessageBox.Show("Please select the Product ComboBox First!");
                cmb_cntry.SelectedIndex = 0;
            }
        }

        public void Countrys_count()
        {
            selectedcountry = this.cmb_cntry.GetItemText(this.cmb_cntry.SelectedItem);
            SqlConnection con = new SqlConnection(conString);
            con.Open();
            SqlCommand com = new SqlCommand("select count (*) as Total from ARC_Recon_Master where Country='" + selectedcountry + "'", con);
            com.CommandType = CommandType.Text;
            SqlDataReader dr = com.ExecuteReader();
            while (dr.Read())
            {
                if (dr.HasRows == true)
                {
                    Total = (int)dr["Total"];
                }
            }
            con.Close();
            con.Open();
            com = new SqlCommand("select count (*) as Completed from ARC_Recon_Master where Is_Recon_Completed= 'true' and Country='" + i + "'", con);
            com.CommandType = CommandType.Text;
            dr = com.ExecuteReader();
            while (dr.Read())
            {
                if (dr.HasRows == true)
                {
                    Completed = (int)dr["Completed"];
                }
            }
            con.Close();
            lbl_cnt.Text = Total.ToString();
            lbl_com_cnt.Text = Completed.ToString();
            lbl_pen_cnt.Text = (Total - Completed).ToString();
        }

        private void btn_UserAccessReport_Click(object sender, EventArgs e)
        {
            string excelFilePath = @"C:\ARC\UserInfo_Details.xlsx";
            DataSet ds = new DataSet();
            SqlConnection con = new SqlConnection(conString);
            con.Open();
            SqlCommand com = new SqlCommand("Select AU.User_id,AU.User_Name, AA.App_Id , AA.App_Name From ARC_user_Details AU Outer apply [dbo].[Split](AU.App_Id , ',') s left join ARC_Applicationdetails as AA on AA.App_Id = s.Items inner join dbo.ARC_User_Info on AU.User_id=ARC_User_Info.UserID  where ARc_Lms_ind= 1 ", con);
            com.CommandType = CommandType.Text;
            SqlDataAdapter da = new SqlDataAdapter(com);
            da.Fill(ds);


            System.Data.DataTable dt1 = new System.Data.DataTable();
            dt1.Columns.Add("User_ID");
            dt1.Columns.Add("User_Name");
            dt1.Columns.Add("Application_Name");
            System.Data.DataTable dd = new System.Data.DataTable();
            dd.Columns.Add("User_Id");
            for (int i = 0; i <= ds.Tables[0].Rows.Count - 1; i++)
            {
                dd.Rows.Add();
                dd.Rows[i][0] = ds.Tables[0].Rows[i][0];
            }
            System.Data.DataTable dt2 = new System.Data.DataTable();
            System.Data.DataTable distinctTable = dd.DefaultView.ToTable(true);
            dt2 = ds.Tables[0];
            string appname = "";
            for (i = 0; i <= distinctTable.Rows.Count - 1; i++)
            {

                for (int j = 0; j <= ds.Tables[0].Rows.Count - 1; j++)
                {
                    if (distinctTable.Rows[i][0].ToString().Trim() == dt2.Rows[j][0].ToString().Trim())
                    {
                        dt1.Rows.Add();
                        dt1.Rows[i][0] = dt2.Rows[j][0];
                        dt1.Rows[i][1] = dt2.Rows[j][1];
                        appname = appname + "," + dt2.Rows[j][3];
                    }
                }

                dt1.Rows[i][2] = appname.Substring(1, appname.ToString().Length - 1);
                appname = "";
            }
            for (int i = dt1.Rows.Count - 1; i >= 0; i--)
            {
                if (dt1.Rows[i][0].ToString().Trim() == "")
                {
                    dt1.Rows.RemoveAt(i);
                }
            }

            if (dt1.Rows.Count > 0)
            {
                Microsoft.Office.Interop.Excel.Application XcelApp = new Microsoft.Office.Interop.Excel.Application();
                Microsoft.Office.Interop.Excel.Workbook workbook = XcelApp.Workbooks.Add(Type.Missing);
                Microsoft.Office.Interop.Excel.Worksheet worksheet = (Microsoft.Office.Interop.Excel.Worksheet)XcelApp.Sheets["Sheet1"];
                Microsoft.Office.Interop.Excel.Range excelCellrange = worksheet.UsedRange;

                //xlWorkBook = xlApp.Workbooks.Add(misValue);
                //xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets.get_Item(1);

                object misValue = System.Reflection.Missing.Value;
                string data = null;
                XcelApp.DisplayAlerts = false;
                XcelApp.Visible = false;
                worksheet.Name = "ExportedFromDatGrid";

                for (i = 0; i <= dt1.Rows.Count - 1; i++)
                {
                    for (j = 0; j <= dt1.Columns.Count - 1; j++)
                    {
                        data = dt1.Rows[i].ItemArray[j].ToString();
                        worksheet.Cells[i + 1, j + 1] = data;
                    }
                }
                Range line = (Range)worksheet.Rows[1];
                line.Insert();
                worksheet.Cells[1, 1] = "USER-ID";
                worksheet.Cells[1, 2] = "USER-NAME";
                worksheet.Cells[1, 3] = "APPLICATION-NAME";
                //Microsoft.Office.Interop.Excel.Range excelCellrange2 = excelCellrange.get_Range("A1", Type.Missing);

                // excelCellrange2.EntireRow.Font.Bold = true;


                workbook.SaveAs(excelFilePath);//, Microsoft.Office.Interop.Excel.XlFileFormat.xlWorkbookNormal, misValue, misValue, misValue, misValue, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);
                workbook.Close(true, misValue, misValue);
                XcelApp.Quit();

                obj.ReleaseComObject(worksheet);
                obj.ReleaseComObject(workbook);
                obj.ReleaseComObject(XcelApp);
                MessageBox.Show("User Report Exported Successful");
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            ViewRecord();
        }

        private void btn_GenerateReport_Click(object sender, EventArgs e)
        {

            DateTime fromdummy = From_Date.Value;

            DateTime Todummy = To_Date.Value;

            string[] date1 = fromdummy.ToString().Split(' ');
            string[] date2 = Todummy.ToString().Split(' ');
            string from = GetDate(date1[0]);
            string To = GetDate(date2[0]);

            string query = "SELECT * FROM ARC_Scope_Baseline_History where [current_date] between'" + from + "' and '" + To + "'";
            String connection = @"Data Source=ukwpidsql500i2.gdc-dev.net\UAT_CL01_IN02,10502;Persist Security Info=True;User ID=CRCQMTUser;Password=eeSmd6fEu;";
            string Filename = @"C:\ARC\Dashboard_Report.csv";
            SqlConnection conn = new SqlConnection(connection);
            conn.Open();
            SqlCommand cmd = new SqlCommand(query, conn);
            SqlDataReader dr = cmd.ExecuteReader();

            using (System.IO.StreamWriter fs = new System.IO.StreamWriter(Filename))
            {
                // Loop through the fields and add headers
                for (int i = 0; i < dr.FieldCount; i++)
                {
                    string name = dr.GetName(i);
                    if (name.Contains(","))
                        name = "\"" + name + "\"";

                    fs.Write(name + ",");
                }
                fs.WriteLine();

                // Loop through the rows and output the data
                while (dr.Read())
                {
                    for (int i = 0; i < dr.FieldCount; i++)
                    {
                        string value = dr[i].ToString();
                        if (value.Contains(","))
                            value = "\"" + value + "\"";

                        fs.Write(value + ",");
                    }
                    fs.WriteLine();
                }
                MessageBox.Show("Admin Dashboard Report Exported Successfully");
                fs.Close();
            }
        }

        private string GetDate(string Date)
        {
            string Final_Date = "";
            string fmt = CultureInfo.CurrentCulture.DateTimeFormat.ShortDatePattern;
            if (Date.ToString().Contains("/"))
            {
                string[] Date_Final = Date.Split('/');


                if (Date_Final[0].Length == 1 && Date_Final[0].Length == 2)
                {
                    Final_Date = "0" + Date_Final[0] + Date_Final[1] + Date_Final[2];
                }
                else if (Date_Final[0].Length == 2 && Date_Final[1].Length == 1)
                {
                    Final_Date = Date_Final[0] + "0" + Date_Final[1] + Date_Final[2];
                }
                else if (Date_Final[1].Length == 1 && Date_Final[0].Length == 1)
                {
                    Final_Date = "0" + Date_Final[0] + "0" + Date_Final[1] + Date_Final[2];
                }
                else if (Date_Final[1].Length == 2 && Date_Final[0].Length == 2)
                {
                    Final_Date = Date_Final[0] + Date_Final[1] + Date_Final[2];
                }
            }

            DateTime myDate = DateTime.ParseExact(Final_Date, fmt.Replace("/", ""), System.Globalization.CultureInfo.InvariantCulture);

            Final_Date = myDate.ToString("yyyy-MM-dd");
            return Final_Date;
        }

        private void btn_AuditReport_Click(object sender, EventArgs e)
        {
            Loading.Visible = true;
        }

        private void btn_EODstatus_Click_1(object sender, EventArgs e)
        {
            try
            {
                Loading.Visible = true;
                if (DGV_AData.Rows.Count > 0)
                {
                    Microsoft.Office.Interop.Excel.Application XcelApp = new Microsoft.Office.Interop.Excel.Application();
                    Microsoft.Office.Interop.Excel.Workbook workbook = XcelApp.Workbooks.Add(Type.Missing);
                    Microsoft.Office.Interop.Excel.Worksheet worksheet = (Microsoft.Office.Interop.Excel.Worksheet)XcelApp.Sheets["Sheet1"];
                    XcelApp.DisplayAlerts = false;
                    XcelApp.Visible = false;
                    worksheet.Name = "ExportedFromDatGrid";
                    int counter = 1;
                    for (int i = 1; i < DGV_AData.Columns.Count; i++)
                    {
                        if (DGV_AData.Columns[i].HeaderText != "IsProcessed")
                        {
                            worksheet.Cells[1, counter] = DGV_AData.Columns[i].HeaderText;
                            counter++;
                        }
                    }

                    for (int i = 0; i < DGV_AData.Rows.Count; i++)
                    {
                        for (int j = 0; j < DGV_AData.Columns.Count - 2; j++)
                        {
                            worksheet.Cells[i + 2, j + 1] = DGV_AData.Rows[i].Cells[j + 1].Value.ToString();
                        }
                    }
                    Microsoft.Office.Interop.Excel.Range excelCellrange = worksheet.UsedRange;
                    Microsoft.Office.Interop.Excel.Range excelCellrange2 = excelCellrange.get_Range("A1", Type.Missing);
                    excelCellrange2.EntireRow.Font.Bold = true;
                    excelCellrange2 = excelCellrange.Rows[(1), System.Reflection.Missing.Value] as Microsoft.Office.Interop.Excel.Range;
                    excelCellrange2.Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Yellow);

                    excelCellrange.EntireColumn.AutoFit();
                    excelCellrange.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;
                    Microsoft.Office.Interop.Excel.Borders border = excelCellrange.Borders;
                    border.LineStyle = Microsoft.Office.Interop.Excel.XlLineStyle.xlContinuous;
                    border.Weight = 2d;

                    string folderPath = Directory + "Dashboard_Report\\";
                    SaveFileDialog saveDialog = new SaveFileDialog();
                    saveDialog.Filter = "Excel files (*.xlsx)|*.xlsx|All files (*.*)|*.*";
                    saveDialog.FilterIndex = 2;

                    workbook.SaveAs(folderPath + "Dashboard_Report_" + DateTime.Now.ToString("hh-mm tt") + ".xlsx");
                    obj.ReleaseComObject(worksheet);
                    obj.ReleaseComObject(workbook);
                    obj.ReleaseComObject(XcelApp);
                    Loading.Visible = false;
                    MessageBox.Show("Exported Successful");
                    //System.Diagnostics.Process.Start(folderPath + "_" + DateTime.Now.ToString("hh:mm tt") + ".xlsx"); ;
                }
            }
            catch
            {

            }
        }

        private void btn_GenerateReport_Click_2(object sender, EventArgs e)
        {
            string Rec_Date1 = "";
            string Rec_Date2 = "";
            try
            {
                string From_Dates = From_Date.Text;
                string To_Dates = To_Date.Text;
                DateTime myDate1 = DateTime.ParseExact(From_Dates, "dd/MM/yyyy", System.Globalization.CultureInfo.InvariantCulture);
                Rec_Date1 = myDate1.ToString("yyyy-MM-dd");
                DateTime myDate2 = DateTime.ParseExact(To_Dates, "dd/MM/yyyy", System.Globalization.CultureInfo.InvariantCulture);
                Rec_Date2 = myDate2.ToString("yyyy-MM-dd");
                con = new SqlConnection(conString);
                con.Open();
                cmd = new SqlCommand("select Team,Country_Name,Recon,SLA_Time,Receipt_Time,Report_Source_File_Name,FTP_File_Format_Name,Source_Application,Recon_date,AutomationStatus from arc_scope_baseline_history where [Current_Date] between '" + Rec_Date1 + "' and '" + Rec_Date2 + "' order by team ", con);
                da = new SqlDataAdapter(cmd);
                dt = new System.Data.DataTable();
                da.Fill(dt);
                cmd = new SqlCommand("select Team,Country,Recon_name,SLA_Time,Receipt_Time, Recon_Status from arc_recon_master_history where ( [Current_Date] between '" + Rec_Date1 + "' and '" + Rec_Date2 + "') and Is_active = 1 and Is_Holiday_logic = 0", con);
                da = new SqlDataAdapter(cmd);
                System.Data.DataTable dt1 = new System.Data.DataTable();
                da.Fill(dt1);
                cmd = new SqlCommand(" select Team,Country,Recon_name,SLA_Time,Receipt_Time, Recon_Status, Recon_date from arc_recon_master_holiday_date_logic_history where convert (date, AutomationStartTime) between '" + Rec_Date1 + "' and '" + Rec_Date2 + "'and recon_name in (select recon_name from Arc_Recon_master where Is_active =1 and Is_Holiday_Logic = 1)", con);
                da = new SqlDataAdapter(cmd);
                System.Data.DataTable dt2 = new System.Data.DataTable();
                da.Fill(dt2);
                dt1.Merge(dt2);
                dtArrList.Add(dt);
                dtArrList.Add(dt1);

                ExportToExcel(dtArrList, @"\\10.132.5.214\TempFiles\SAHIL\UAT_Runtimes\ARCRuntime\Report.xlsx");

                con.Close();
                con.Open();
            }
            catch (Exception ex)
            {

            }
        }
        private void ExportToExcel(List<System.Data.DataTable> Tbl, string ExcelFilePath)
        {
            try
            {
                if (Tbl.Count() == 0)
                    throw new Exception("No datatable is found");
                if (Tbl[0] == null || Tbl[0].Columns.Count == 0)
                    throw new Exception("ExportToExcel: Null or empty input table!\n");

                // load excel, and create a new workbook
                Microsoft.Office.Interop.Excel.Application excelApp = new Microsoft.Office.Interop.Excel.Application();
                excelApp.Workbooks.Add();

                // Create File level worksheet
                Microsoft.Office.Interop.Excel._Worksheet workSheet = (Microsoft.Office.Interop.Excel._Worksheet)excelApp.ActiveSheet;
                workSheet.Name = "File Level";
                // column headings
                for (int i = 0; i < Tbl[0].Columns.Count; i++)
                {
                    workSheet.Cells[1, (i + 1)] = Tbl[0].Columns[i].ColumnName;
                }

                // rows
                for (int i = 0; i < Tbl[0].Rows.Count; i++)
                {

                    for (int j = 0; j < Tbl[0].Columns.Count; j++)
                    {
                        workSheet.Cells[(i + 2), (j + 1)] = Tbl[0].Rows[i][j];
                    }
                }
                //Create Recon level worksheet
                excelApp.Worksheets.Add();
                Microsoft.Office.Interop.Excel._Worksheet workSheet1 = (Microsoft.Office.Interop.Excel._Worksheet)excelApp.ActiveSheet;
                workSheet1.Name = "Recon Level";
                for (int i = 0; i < Tbl[1].Columns.Count; i++)
                {
                    workSheet1.Cells[1, (i + 1)] = Tbl[1].Columns[i].ColumnName;
                }

                // rows
                for (int i = 0; i < Tbl[1].Rows.Count; i++)
                {

                    for (int j = 0; j < Tbl[1].Columns.Count; j++)
                    {
                        workSheet1.Cells[(i + 2), (j + 1)] = Tbl[1].Rows[i][j];
                    }
                }

                // check filepath
                if (ExcelFilePath != null && ExcelFilePath != "")
                {
                    try
                    {
                        workSheet.SaveAs(ExcelFilePath);
                        excelApp.Quit();
                        MessageBox.Show("Excel file saved!");
                        System.Runtime.InteropServices.Marshal.ReleaseComObject(workSheet);
                        System.Runtime.InteropServices.Marshal.ReleaseComObject(workSheet1);
                        System.Runtime.InteropServices.Marshal.ReleaseComObject(excelApp);
                    }
                    catch (Exception ex)
                    {
                        // throw new Exception("ExportToExcel: Excel file could not be saved! Check filepath.\n"
                        // + ex.Message);
                        System.Runtime.InteropServices.Marshal.ReleaseComObject(workSheet);
                        System.Runtime.InteropServices.Marshal.ReleaseComObject(workSheet1);
                        System.Runtime.InteropServices.Marshal.ReleaseComObject(excelApp);
                    }
                }
                else    // no filepath is given
                {
                    excelApp.Visible = true;
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(workSheet);
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(workSheet1);
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(excelApp);
                }

            }
            catch (Exception ex)
            {
                //throw new Exception("ExportToExcel: \n" + ex.Message);

            }
        }
        private class CheckedBoxFiller
        {
            public string Text { get; set; }
            public string Value { get; set; }
        }
        private void Main_Admin_DashBoard_Load(object sender, EventArgs e)
        {
            this.BackColor = System.Drawing.Color.White;
            con = new SqlConnection(conString);
            con.Open();
            cmd = new SqlCommand("select App_Id,App_Name from ARC_Applicationdetails", con);
            da = new SqlDataAdapter(cmd);
            dt = new System.Data.DataTable();
            da.Fill(dt);
            Lst_Application_01.DataSource = dt;
            Lst_Application_01.DisplayMember = "App_Name";
            Lst_Application_01.ValueMember = "App_Id";
            if (dt.Rows.Count > 0)
            {
                foreach (DataRow item in dt.Rows)
                {
                    chklstApplication.Items.Add(item["App_Name"].ToString());
                }
            }
            con.Close();
            con.Open();
            cmd = new SqlCommand("select Country_Id,Country_name from ARC_Country_Details", con);
            da = new SqlDataAdapter(cmd);
            dt = new System.Data.DataTable();
            da.Fill(dt);
            Lst_Countries_01.DataSource = dt;
            Lst_Countries_01.DisplayMember = "Country_name";
            Lst_Countries_01.ValueMember = "Country_Id";
            if (dt.Rows.Count > 0)
            {
                foreach (DataRow item in dt.Rows)
                {
                    chklstCountries.Items.Add(item["Country_name"].ToString());
                }
            }
            con.Close();
            con.Open();
            cmd = new SqlCommand("select Product_Id,Product_Name from ARC_Product_Details", con);
            da = new SqlDataAdapter(cmd);
            dt = new System.Data.DataTable();
            da.Fill(dt);
            Lst_Prdt_01.DataSource = dt;
            Lst_Prdt_01.DisplayMember = "Product_Name";
            Lst_Prdt_01.ValueMember = "Product_Id";
            if (dt.Rows.Count > 0)
            {
                foreach (DataRow item in dt.Rows)
                {
                    chklstProduct.Items.Add(item["Product_Name"].ToString());
                }
            }
            con.Close();
            Lst_Application_01.SelectedIndex = -1;
            //Lst_Countries_01.SelectedIndex = -1;
            //Lst_Prdt_01.SelectedIndex = -1;
            chklstPageAccess.Items.Add("Config Management");
            chklstPageAccess.Items.Add("Reports");
            chklstPageAccess.Items.Add("Recon Acccess");

        }

        private void btn_EditUser_Click(object sender, EventArgs e)
        {
            try
            {
                string UserRole = "";
                if (btn_EditUser.Text == "Edit User")
                {
                    btn_EditUser.Text = "Update";
                    SqlConnection con = new SqlConnection(conString);
                    con.Open();
                    SqlCommand com = new SqlCommand("select UserRole from dbo.ARC_user_info where UserID='" + PSID.Text + "'", con);
                    com.CommandType = CommandType.Text;
                    SqlDataReader dr = com.ExecuteReader();
                    while (dr.Read())
                    {
                        if (dr.HasRows == true)
                        {
                            UserRole = (string)dr["UserRole"];
                        }
                    }
                    if (UserRole == "")
                    {
                        btn_EditUser.Text = "Edit User";
                        MessageBox.Show("ARC ID for this PSID does not exist");
                    }
                    else if (UserRole == "--SELECT--")
                    {
                        MessageBox.Show("Please select Access Type");
                    }
                    else
                    {
                        Acc_Type.Items.RemoveAt(0);
                        Acc_Type.SelectedText = UserRole;

                    }
                    con.Close();
                }
                else if (btn_EditUser.Text == "Update")
                {

                    btn_EditUser.Text = "Edit User";


                    SqlConnection con = new SqlConnection(conString);
                    con.Open();

                    SqlCommand com = new SqlCommand("update dbo.ARC_User_Info set UserRole=@UserRole where UserID='" + PSID.Text + "'", con);
                    com.Parameters.AddWithValue("@UserRole", Acc_Type.Text);
                    com.ExecuteNonQuery();
                    MessageBox.Show("User Role Updated Successfully");
                    con.Close();
                    Acc_Type.SelectedIndex = 0;
                    PSID.Text = "";

                }
            }
            catch
            {

            }
            finally
            {
                string Flag = "";
                for (int i = 0; i < Acc_Type.Items.Count; i++)
                {
                    string value = Acc_Type.GetItemText(Acc_Type.Items[i]);
                    if (value == "--SELECT--")
                    {
                        Flag = "True";
                    }

                }
                if (Flag == "True")
                {
                }
                else
                {
                    Acc_Type.Items.Insert(0, "--SELECT--");
                }
            }
        }

        private void btn_AddUser_Click(object sender, EventArgs e)
        {
            //if (PSID.Text == "" || UserName.Text == "" || ManagerID.Text == "" || Acc_Type.SelectedIndex == 0 || Lst_Application_02.Items.Count == 0 || Lst_Countries_02.Items.Count == 0 || Lst_Prdt_02.Items.Count == 0 || Lst_PageAccess_02.Items.Count == 0)
            //{
            //    MessageBox.Show("Please select All the Fields to Continue..!");
            //}
            //else
            if (PSID.Text == "")
            {
                SqlConnection con = new SqlConnection(conString);
                con.Open();
                SqlCommand cmdd = new SqlCommand("select [userid] from ARC_user_info", con);
                da = new SqlDataAdapter(cmdd);
                dt = new System.Data.DataTable();
                da.Fill(dt);
                con.Close();
                bool Flag = false;
                for (int i = 0; i <= dt.Rows.Count - 1; i++)
                {
                    if (PSID.Text == dt.Rows[i][0].ToString().Trim())
                    {
                        Flag = true;
                    }
                }
                if (Flag == true)
                {
                    Loading.Visible = true;

                    for (int i = 0; i < chklstApplication.Items.Count; i++)
                    {
                        string strselecteditems = chklstApplication.Items[i].ToString();
                        con.Open();
                        SqlCommand cmd = new SqlCommand("select App_Id from ARC_Applicationdetails where App_Name='" + strselecteditems + "'", con);
                        da = new SqlDataAdapter(cmd);
                        dt = new System.Data.DataTable();
                        da.Fill(dt);
                        string Applic_ID = dt.Rows[0].ItemArray[0].ToString();
                        con.Close();
                        strAppl = strAppl + "," + Applic_ID;

                    }
                    for (int i = 0; i < chklstCountries.Items.Count; i++)
                    {

                        string strselecteditems = chklstCountries.Items[i].ToString();
                        con.Open();
                        cmd = new SqlCommand("select Country_Id from ARC_Country_Details where Country_name='" + strselecteditems + "'", con);
                        da = new SqlDataAdapter(cmd);
                        dt = new System.Data.DataTable();
                        da.Fill(dt);
                        string Contry_ID = dt.Rows[0].ItemArray[0].ToString();
                        con.Close();
                        strCountr = strCountr + "," + Contry_ID;

                    }
                    for (int i = 0; i < chklstProduct.Items.Count; i++)
                    {

                        string strselecteditems = chklstProduct.Items[i].ToString();
                        con.Open();
                        cmd = new SqlCommand("select Product_Id from dbo.ARC_Product_Details where Product_Name='" + strselecteditems + "'", con);
                        da = new SqlDataAdapter(cmd);
                        dt = new System.Data.DataTable();
                        da.Fill(dt);
                        string Prdt_ID = dt.Rows[0].ItemArray[0].ToString();
                        con.Close();
                        strPrdt = strPrdt + "," + Prdt_ID;

                    }
                    strAppl = strAppl.Substring(1, strAppl.ToString().Length - 1);
                    strCountr = strCountr.Substring(1, strCountr.ToString().Length - 1);
                    strPrdt = strPrdt.Substring(1, strPrdt.ToString().Length - 1);
                    string UserID = PSID.Text;
                    string Psd = "Arc@123";
                    string role = Acc_Type.SelectedItem.ToString().Trim();

                    string LUserId = ManagerID.Text;
                    DateTime date = DateTime.Today;
                    DateTime date1 = DateTime.Today.AddDays(90);
                    con.Open();
                    cmd = new SqlCommand("insert into ARC_User_Info(UserID,Password,UserRole,StartDate,EndDate) values(@UserID,@Password,@UserRole,@StartDate,@EndDate)", con);
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@UserID", UserID);
                    cmd.Parameters.AddWithValue("@Password", Encrypt(Psd.Trim()));
                    cmd.Parameters.AddWithValue("@UserRole", role);
                    cmd.Parameters.AddWithValue("@StartDate", date);
                    cmd.Parameters.AddWithValue("@EndDate", date1);
                    cmd.ExecuteNonQuery();
                    con.Close();

                    int Role_Details_Id = 1;
                    con.Open();
                    cmd = new SqlCommand("insert into ARC_User_Details(User_Id,User_Name,Manager_Id,Role_Details_Id,App_id,Country_Id,Product_Id) values(@User_Id,@User_Name,@Manager_Id,@Role_Details_Id,@App_id,@Country_Id,@Product_Id)", con);
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@User_Id", UserID);
                    cmd.Parameters.AddWithValue("@User_Name", UserName.Text);
                    cmd.Parameters.AddWithValue("@Manager_Id", LUserId);
                    cmd.Parameters.AddWithValue("@Role_Details_Id", Role_Details_Id);
                    cmd.Parameters.AddWithValue("@App_id", strAppl);
                    cmd.Parameters.AddWithValue("@Country_Id", strCountr);
                    cmd.Parameters.AddWithValue("@Product_Id", strPrdt);
                    // cmd.Parameters.AddWithValue("@Page_Access", );
                    cmd.ExecuteNonQuery();
                    con.Close();


                    con.Open();
                    SqlCommand com = new SqlCommand("select Password from dbo.ARC_User_Info where UserID=@UserID", con);
                    com.CommandType = CommandType.Text;
                    com.Parameters.AddWithValue("@UserID", UserID);
                    SqlDataReader dr = com.ExecuteReader();
                    while (dr.Read())
                    {
                        if (dr.HasRows == true)
                        {
                            string Password = (string)dr["Password"];
                            Psd = Decrypt(Password.Trim());
                            Microsoft.Office.Interop.Outlook.Application app = new Microsoft.Office.Interop.Outlook.Application();
                            Microsoft.Office.Interop.Outlook.MailItem mailItem = app.CreateItem(Microsoft.Office.Interop.Outlook.OlItemType.olMailItem);
                            mailItem.Subject = "SCB: Password Reset";
                            mailItem.To = UserID;
                            mailItem.Body = "Dear User.\n \n Your Login Password For ARC Applications is " + Psd + "";
                            mailItem.Importance = Microsoft.Office.Interop.Outlook.OlImportance.olImportanceHigh;
                            mailItem.Send();
                        }
                    }
                    con.Close();
                    Loading.Visible = false;
                }
                else
                {
                    MessageBox.Show("PSID Already Exists.. !");
                }
            }
        }

        private string Encrypt(string clearText)
        {
            try
            {
                string EncryptionKey = "MAKV2SPBNI99212";
                byte[] clearBytes = Encoding.Unicode.GetBytes(clearText);
                using (Aes encryptor = Aes.Create())
                {
                    Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
                    encryptor.Key = pdb.GetBytes(32);
                    encryptor.IV = pdb.GetBytes(16);
                    using (MemoryStream ms = new MemoryStream())
                    {
                        using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateEncryptor(), CryptoStreamMode.Write))
                        {
                            cs.Write(clearBytes, 0, clearBytes.Length);
                            cs.Close();
                        }
                        clearText = Convert.ToBase64String(ms.ToArray());
                    }
                }
                return clearText;
            }
            catch
            {
                return null;
            }
        }

        private string Decrypt(string cipherText)
        {
            try
            {
                string EncryptionKey = "MAKV2SPBNI99212";
                byte[] cipherBytes = Convert.FromBase64String(cipherText);
                using (Aes encryptor = Aes.Create())
                {
                    Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
                    encryptor.Key = pdb.GetBytes(32);
                    encryptor.IV = pdb.GetBytes(16);
                    using (MemoryStream ms = new MemoryStream())
                    {
                        using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateDecryptor(), CryptoStreamMode.Write))
                        {
                            cs.Write(cipherBytes, 0, cipherBytes.Length);
                            cs.Close();
                        }
                        cipherText = Encoding.Unicode.GetString(ms.ToArray());
                    }
                }
                return cipherText;
            }
            catch
            {
                return null;
            }
        }

        private void btn_DeleteUser_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(conString);
            if (PSID.Text != null)
            {
                con.Open();
                SqlCommand com = new SqlCommand("select Manager_Id from dbo.ARC_User_Details where User_ID='" + PSID.Text + "'", con);
                com.CommandType = CommandType.Text;
                com.Parameters.AddWithValue("@User_ID", PSID.Text);
                SqlDataReader dr = com.ExecuteReader();
                while (dr.Read())
                {
                    if (dr.HasRows == true)
                    {
                        int Manager = Convert.ToInt32(dr["Manager_Id"].ToString());
                        // string Psd = ecp.Decrypt(Password.Trim());
                        Microsoft.Office.Interop.Outlook.Application app = new Microsoft.Office.Interop.Outlook.Application();
                        Microsoft.Office.Interop.Outlook.MailItem mailItem = app.CreateItem(Microsoft.Office.Interop.Outlook.OlItemType.olMailItem);
                        mailItem.Subject = "SCB: Removed Allocation";
                        mailItem.To = Manager.ToString();
                        mailItem.Body = "Dear Admin.\n \n We had Removed All the Access For ARC Aplications For the Particular UserID:- " + PSID.Text + "";
                        mailItem.Importance = Microsoft.Office.Interop.Outlook.OlImportance.olImportanceHigh;
                        mailItem.Send();
                    }
                }
                con.Close();
                con.Open();
                cmd = new SqlCommand("Delete from ARC_User_Details where User_Id='" + PSID.Text + "'", con);
                da = new SqlDataAdapter(cmd);
                dt = new System.Data.DataTable();
                da.Fill(dt);
                con.Close();
                con.Open();
                cmd = new SqlCommand("Delete from ARC_User_Info where UserID='" + PSID.Text + "'", con);
                da = new SqlDataAdapter(cmd);
                dt = new System.Data.DataTable();
                da.Fill(dt);
                con.Close();
            }
            else
            {
                MessageBox.Show("Please Select User_Id To remove Details of the User...!");
            }
        }

        private void btn_Clear_Click(object sender, EventArgs e)
        {
            PSID.Text = "";
            UserName.Text = "";
            ManagerID.Text = "";
            Lst_Application_01.SelectedIndex = -1;
            Lst_Countries_01.SelectedIndex = -1;
            Lst_Prdt_01.SelectedIndex = -1;
            Lst_PageAccess_01.SelectedIndex = -1;
            Lst_Application_02.Items.Clear();
            Lst_Countries_02.Items.Clear();
            Lst_Prdt_02.Items.Clear();
            Lst_PageAccess_02.Items.Clear();
        }

        private void MoveListBoxItems(System.Windows.Forms.ListBox source, System.Windows.Forms.ListBox destination)
        {
            System.Windows.Forms.ListBox.SelectedObjectCollection sourceItems = source.SelectedItems;
            foreach (DataRowView item in sourceItems)
            {
                if (!destination.Items.Contains(item[1].ToString()))
                {
                    destination.Items.Add(item[1]);
                }
            }
        }

        private void MoveListBoxesItems(System.Windows.Forms.ListBox source, System.Windows.Forms.ListBox destination)
        {
            System.Windows.Forms.ListBox.SelectedObjectCollection sourceItems = source.SelectedItems;
            foreach (string item in sourceItems)
            {
                if (!destination.Items.Contains(item))
                {
                    destination.Items.Add(item);
                }
            }
        }

        private void Btn_App_Frd01_Click(object sender, EventArgs e)
        {
            MoveListBoxItems(Lst_Application_01, Lst_Application_02);
        }

        private void Btn_App_Rev01_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.ListBox.SelectedObjectCollection selectedItems = new System.Windows.Forms.ListBox.SelectedObjectCollection(Lst_Application_02);
            selectedItems = Lst_Application_02.SelectedItems;

            if (Lst_Application_02.SelectedIndex != -1)
            {
                for (int i = selectedItems.Count - 1; i >= 0; i--)
                    Lst_Application_02.Items.Remove(selectedItems[i]);
            }
        }

        private void Btn_Prdt_Fwd_Click(object sender, EventArgs e)
        {
            MoveListBoxItems(Lst_Prdt_01, Lst_Prdt_02);
        }

        private void Btn_Prdt_Rev_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.ListBox.SelectedObjectCollection selectedItems = new System.Windows.Forms.ListBox.SelectedObjectCollection(Lst_Prdt_02);
            selectedItems = Lst_Prdt_02.SelectedItems;

            if (Lst_Prdt_02.SelectedIndex != -1)
            {
                for (int i = selectedItems.Count - 1; i >= 0; i--)
                    Lst_Prdt_02.Items.Remove(selectedItems[i]);
            }
        }

        private void Btn_PageAccess_Frd_Click(object sender, EventArgs e)
        {
            MoveListBoxesItems(Lst_PageAccess_01, Lst_PageAccess_02);
        }

        private void Btn_PageAccess_Rev_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.ListBox.SelectedObjectCollection selectedItems = new System.Windows.Forms.ListBox.SelectedObjectCollection(Lst_PageAccess_02);
            selectedItems = Lst_PageAccess_02.SelectedItems;

            if (Lst_PageAccess_02.SelectedIndex != -1)
            {
                for (int i = selectedItems.Count - 1; i >= 0; i--)
                    Lst_PageAccess_02.Items.Remove(selectedItems[i]);
            }
        }

        private void Btn_Countr_Frd_Click(object sender, EventArgs e)
        {
            MoveListBoxItems(Lst_Countries_01, Lst_Countries_02);
        }

        private void Btn_Countr_Rev_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.ListBox.SelectedObjectCollection selectedItems = new System.Windows.Forms.ListBox.SelectedObjectCollection(Lst_Countries_02);
            selectedItems = Lst_Countries_02.SelectedItems;

            if (Lst_Countries_02.SelectedIndex != -1)
            {
                for (int i = selectedItems.Count - 1; i >= 0; i--)
                    Lst_Countries_02.Items.Remove(selectedItems[i]);
            }
        }

        private void PSID_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) || PSID.Text.Length >= 7 && e.KeyChar != 8)// || Txt_UserID.Text.Length == 7)
            {
                e.Handled = true;

            }

        }

        private void ManagerID_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) || ManagerID.Text.Length >= 7 && e.KeyChar != 8)// || Txt_UserID.Text.Length == 7)
            {
                e.Handled = true;

            }
        }

        #region User Management
        private void btnAddUser_Click(object sender, EventArgs e)
        {
            try
            {
                strAppl = "";
                strCountr = "";
                strPrdt = "";
                string strselecteditems_01 = "";
                string strselecteditems_02 = "";
                string strselecteditems_03 = "";
                if (txtUserPSID.Text.Trim() == "")
                {
                    MessageBox.Show("Please Enter the PSID..!");
                    return;
                }

                if (txtUserPSID.Text != "")
                {
                    SqlConnection con = new SqlConnection(conString);
                    con.Open();
                    SqlCommand cmdd = new SqlCommand("select [userid] from ARC_user_info where userid='" + txtUserPSID.Text + "'", con);
                    da = new SqlDataAdapter(cmdd);
                    dt = new System.Data.DataTable();
                    da.Fill(dt);
                    con.Close();
                    bool Flag = false;

                    if (dt.Rows.Count > 0)
                    {
                        Flag = true;
                        MessageBox.Show("PSID Already Exists.. !");
                        return;
                    }


                    if (txtUserName.Text.Trim() == "")
                    {
                        MessageBox.Show("Please Enter the User_Name..!");
                        return;
                    }
                    if (txtLineManager.Text.Trim() == "")
                    {
                        MessageBox.Show("Please Enter the Line Manager PSID..!");
                        return;
                    }
                    if (cmbAccessType.SelectedIndex < 1)
                    {
                        MessageBox.Show("Please select the Access Type..!");
                        return;
                    }

                    if (cmbAccessType.SelectedItem == null)
                    {
                        MessageBox.Show("Please select only one item in listbox");
                        return;
                    }

                    if (chklstProduct.CheckedItems.Count == 1)
                    {
                        for (int i = 0; i < chklstProduct.Items.Count; i++)
                        {
                            if (chklstProduct.SelectedItem.ToString() == chklstProduct.Items[i].ToString())
                            {
                                strselecteditems_02 = chklstProduct.Items[i].ToString();
                                con.Open();
                                cmd = new SqlCommand("select Product_Id from dbo.ARC_Product_Details where Product_Name='" + strselecteditems_02 + "'", con);
                                da = new SqlDataAdapter(cmd);
                                dt = new System.Data.DataTable();
                                da.Fill(dt);
                                string Prdt_ID = dt.Rows[0].ItemArray[0].ToString();
                                con.Close();
                                strPrdt = Prdt_ID;
                                i = chklstProduct.Items.Count;
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("Please select only one item in Product");
                        return;
                    }
                    if (chklstApplication.CheckedItems.Count == 1)
                    {
                        for (int i = 0; i < chklstApplication.Items.Count; i++)
                        {
                            if (chklstApplication.SelectedItem.ToString() == chklstApplication.Items[i].ToString())
                            {
                                strselecteditems_01 = chklstApplication.Items[i].ToString();
                                con.Open();
                                SqlCommand cmd = new SqlCommand("select App_Id from ARC_Applicationdetails where App_Name='" + strselecteditems_01 + "'", con);
                                da = new SqlDataAdapter(cmd);
                                dt = new System.Data.DataTable();
                                da.Fill(dt);
                                string Applic_ID = dt.Rows[0].ItemArray[0].ToString();
                                con.Close();
                                i = chklstApplication.Items.Count;
                                strAppl = Applic_ID;
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("Please select only one item in Application");
                        return;
                    }

                    if (chklstCountries.CheckedItems.Count == 1)
                    {
                        for (int i = 0; i < chklstCountries.Items.Count; i++)
                        {
                            if (chklstCountries.SelectedItem.ToString() == chklstCountries.Items[i].ToString())
                            {
                                strselecteditems_03 = chklstCountries.Items[i].ToString();
                                con.Open();
                                cmd = new SqlCommand("select Country_Id from ARC_Country_Details where Country_name='" + strselecteditems_03 + "'", con);
                                da = new SqlDataAdapter(cmd);
                                dt = new System.Data.DataTable();
                                da.Fill(dt);
                                string Contry_ID = dt.Rows[0].ItemArray[0].ToString();
                                con.Close();
                                strCountr = Contry_ID;
                                i = chklstCountries.Items.Count;
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("Please select only one item in Country");
                        return;
                    }

                    string strPageAccess = "";
                    if (chklstPageAccess.CheckedItems.Count == 1)
                    {
                        for (int i = 0; i < chklstPageAccess.Items.Count; i++)
                        {
                            if (chklstPageAccess.SelectedItem.ToString() == chklstPageAccess.Items[i].ToString())
                            {
                                strselecteditems_03 = chklstPageAccess.Items[i].ToString();
                                strPageAccess = strselecteditems_03;
                                i = chklstPageAccess.Items.Count;
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("Please select only one item in Page Access");
                        return;
                    }

                    System.Data.DataTable dt_grid = new System.Data.DataTable();
                    dt_grid.Columns.Add("User_Id");
                    dt_grid.Columns.Add("Products");
                    dt_grid.Columns.Add("Countrys");
                    dt_grid.Columns.Add("Application");

                    for (int i = 0; i < 1; i++)
                    {
                        dt_grid.Rows.Add();
                        dt_grid.Rows[i][0] = txtUserPSID.Text;
                        dt_grid.Rows[i][1] = strselecteditems_01;
                        dt_grid.Rows[i][2] = strselecteditems_02;
                        dt_grid.Rows[i][3] = strselecteditems_03;
                    }
                    dataGridView.DataSource = dt_grid;
                    dataGridView.Visible = true;
                    //strAppl = strAppl.Substring(1, strAppl.ToString().Length - 1);
                    //strCountr = strCountr.Substring(1, strCountr.ToString().Length - 1);
                    //strPrdt = strPrdt.Substring(1, strPrdt.ToString().Length - 1);
                    string UserID = txtUserPSID.Text;
                    string Psd = "Arc@123";
                    string role = cmbAccessType.SelectedItem.ToString().Trim();

                    string LUserId = txtLineManager.Text;
                    DateTime date = DateTime.Today;
                    DateTime date1 = DateTime.Today.AddDays(90);
                    con.Open();
                    cmd = new SqlCommand("insert into ARC_User_Info(UserID,Password,UserRole,StartDate,EndDate) values(@UserID,@Password,@UserRole,@StartDate,@EndDate)", con);
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@UserID", UserID);
                    cmd.Parameters.AddWithValue("@Password", Encrypt(Psd.Trim()));
                    cmd.Parameters.AddWithValue("@UserRole", role);
                    cmd.Parameters.AddWithValue("@StartDate", date);
                    cmd.Parameters.AddWithValue("@EndDate", date1);
                    cmd.ExecuteNonQuery();
                    con.Close();

                    int Role_Details_Id = 1;
                    con.Open();
                    cmd = new SqlCommand("insert into ARC_User_Details(User_Id,User_Name,Manager_Id,Role_Details_Id,App_id,Country_Id,Product_Id,Page_Access) values(@User_Id,@User_Name,@Manager_Id,@Role_Details_Id,@App_id,@Country_Id,@Product_Id,@Page_Access)", con);
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@User_Id", UserID);
                    cmd.Parameters.AddWithValue("@User_Name", txtUserName.Text);
                    cmd.Parameters.AddWithValue("@Manager_Id", LUserId);
                    cmd.Parameters.AddWithValue("@Role_Details_Id", Role_Details_Id);
                    cmd.Parameters.AddWithValue("@App_id", strAppl);
                    cmd.Parameters.AddWithValue("@Country_Id", strCountr);
                    cmd.Parameters.AddWithValue("@Product_Id", strPrdt);
                    cmd.Parameters.AddWithValue("@Page_Access", strPageAccess);
                    cmd.ExecuteNonQuery();
                    con.Close();

                    con.Open();
                    cmd = new SqlCommand("insert into ARC_User_Access_Details(User_Id,App_id,Country_Id,Page_Access) values(@User_Id,@App_id,@Country_Id,@Page_Access)", con);
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@User_Id", UserID);
                    cmd.Parameters.AddWithValue("@App_id", strAppl);
                    cmd.Parameters.AddWithValue("@Country_Id", strCountr);
                    cmd.Parameters.AddWithValue("@Page_Access", strPageAccess);
                    cmd.ExecuteNonQuery();
                    con.Close();

                    con.Open();
                    SqlCommand com = new SqlCommand("select Password from dbo.ARC_User_Info where UserID=@UserID", con);
                    com.CommandType = CommandType.Text;
                    com.Parameters.AddWithValue("@UserID", UserID);
                    SqlDataReader dr = com.ExecuteReader();
                    while (dr.Read())
                    {
                        if (dr.HasRows == true)
                        {
                            string Password = (string)dr["Password"];
                            Psd = Decrypt(Password.Trim());
                            Microsoft.Office.Interop.Outlook.Application app = new Microsoft.Office.Interop.Outlook.Application();
                            Microsoft.Office.Interop.Outlook.MailItem mailItem = app.CreateItem(Microsoft.Office.Interop.Outlook.OlItemType.olMailItem);
                            mailItem.Subject = "SCB: Password Reset";
                            mailItem.To = UserID;
                            mailItem.Body = "Dear User.\n \n Your Login Password For ARC Applications is " + Psd + "";
                            mailItem.Importance = Microsoft.Office.Interop.Outlook.OlImportance.olImportanceHigh;
                            //mailItem.Send();
                        }
                    }
                    con.Close();
                    //Loading.Visible = false;
                    SearchFunction();
                    MessageBox.Show("User Added Successfully.. !");
                    //Clear_Function();

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        public void Clear_Function()
        {
            txtUserPSID.Text = "";
            txtUserName.Text = "";
            cmbAccessType.Text = "";
            txtLineManager.Text = "";
            while (chklstProduct.CheckedIndices.Count > 0)
            {
                chklstProduct.SetItemChecked(chklstProduct.CheckedIndices[0], false);
            }
            while (chklstApplication.CheckedIndices.Count > 0)
            {
                chklstApplication.SetItemChecked(chklstApplication.CheckedIndices[0], false);
            }
            while (chklstCountries.CheckedIndices.Count > 0)
            {
                chklstCountries.SetItemChecked(chklstCountries.CheckedIndices[0], false);
            }
            while (chklstPageAccess.CheckedIndices.Count > 0)
            {
                chklstPageAccess.SetItemChecked(chklstPageAccess.CheckedIndices[0], false);
            }
            chklstProduct.SelectedItems.Clear();
            chklstApplication.SelectedItems.Clear();
            chklstCountries.SelectedItems.Clear();
            chklstPageAccess.SelectedItems.Clear();
            dataGridView.Visible = false;
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            Clear_Function();
        }

        private void btnDeleteUser_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(conString);
                if (txtUserPSID.Text.Trim() != "")
                {
                    con.Open();
                    SqlCommand com = new SqlCommand("select Manager_Id from dbo.ARC_User_Details where User_ID='" + txtUserPSID.Text + "'", con);
                    com.CommandType = CommandType.Text;
                    com.Parameters.AddWithValue("@User_ID", txtUserPSID.Text);
                    SqlDataReader dr = com.ExecuteReader();
                    while (dr.Read())
                    {
                        if (dr.HasRows == true)
                        {
                            int Manager = Convert.ToInt32(dr["Manager_Id"].ToString());
                            // string Psd = ecp.Decrypt(Password.Trim());
                            Microsoft.Office.Interop.Outlook.Application app = new Microsoft.Office.Interop.Outlook.Application();
                            Microsoft.Office.Interop.Outlook.MailItem mailItem = app.CreateItem(Microsoft.Office.Interop.Outlook.OlItemType.olMailItem);
                            mailItem.Subject = "SCB: Removed Allocation";
                            mailItem.To = Manager.ToString();
                            mailItem.Body = "Dear Admin.\n \n We had Removed All the Access For ARC Aplications For the Particular UserID:- " + txtUserPSID.Text + "";
                            mailItem.Importance = Microsoft.Office.Interop.Outlook.OlImportance.olImportanceHigh;
                            //mailItem.Send();
                        }
                    }

                    con.Close();
                    con.Open();
                    cmd = new SqlCommand("Delete from ARC_User_Details where User_Id='" + txtUserPSID.Text + "'", con);
                    cmd.ExecuteNonQuery();
                    con.Close();

                    con.Open();
                    cmd = new SqlCommand("Delete from ARC_User_Info where UserID='" + txtUserPSID.Text + "'", con);
                    cmd.ExecuteNonQuery();
                    con.Close();

                    con.Open();
                    cmd = new SqlCommand("Delete from ARC_User_Access_Details where User_Id='" + txtUserPSID.Text + "'", con);
                    cmd.ExecuteNonQuery();
                    con.Close();

                    MessageBox.Show("User Deleted Successfully...!");
                    Clear_Function();
                }
                else
                {
                    MessageBox.Show("Please Enter the User_Id To remove Details of the User...!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            SearchFunction();
        }
        public void SearchFunction()
        {
            try
            {
                SqlConnection con = new SqlConnection(conString);
                if (txtUserPSID.Text.Trim() != "")
                {
                    string strPSID = txtUserPSID.Text.ToString();
                    string strquery = "select a.user_id,a.user_name,a.manager_id,a.product_id,a.app_id,a.country_id,a.page_access,b.userrole from ARC_User_Details a,ARC_User_Info b where b.userid=a.user_id and a.user_id='" + txtUserPSID.Text + "'; select Product_Id,Product_name from dbo.ARC_Product_Details; select * from ARC_User_Access_Details a,ARC_Country_Details b,ARC_Applicationdetails d where a.Country_Id=b.country_id and a.app_id=d.app_id  and user_id='" + txtUserPSID.Text + "' order by b.Country_Name,d.app_name,a.Page_Access";
                    con.Close();
                    con.Open();
                    SqlDataAdapter da = new SqlDataAdapter(strquery, con);
                    DataSet ds = new DataSet();
                    da.Fill(ds);
                    con.Close();
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        Clear_Function();

                        string username = ds.Tables[0].Rows[0]["user_name"].ToString();
                        string managerid = ds.Tables[0].Rows[0]["manager_id"].ToString();
                        string userrole = ds.Tables[0].Rows[0]["userrole"].ToString();
                        string country = ds.Tables[0].Rows[0]["country_id"].ToString();
                        string product = ds.Tables[0].Rows[0]["product_id"].ToString();
                        string appli = ds.Tables[0].Rows[0]["app_id"].ToString();
                        string pageaccess = ds.Tables[0].Rows[0]["page_access"].ToString();
                        string productname = "";

                        txtUserPSID.Text = strPSID;
                        txtUserName.Text = username;
                        cmbAccessType.SelectedText = userrole;
                        txtLineManager.Text = managerid;

                        string[] produsp = product.Split(',');
                        string[] Pageaccessp = pageaccess.Split(',');

                        for (int i = 0; i < produsp.Length; i++)
                        {
                            string prodid = produsp[i].ToString();
                            if (prodid.Trim() != "")
                            {
                                ds.Tables[1].DefaultView.RowFilter = "Product_Id='" + prodid + "'";
                                DataView dvproduct = ds.Tables[1].DefaultView;
                                if (dvproduct.Count > 0)
                                {
                                    productname = dvproduct[0]["product_name"].ToString();

                                    for (int m = 0; m < chklstProduct.Items.Count; m++)
                                    {
                                        if (productname.Trim().ToUpper() == chklstProduct.Items[m].ToString().Trim().ToUpper())
                                        {
                                            chklstProduct.SetItemCheckState(m, CheckState.Checked);
                                            chklstProduct.SetSelected(m, true);
                                            m = chklstProduct.Items.Count;
                                        }
                                    }
                                }
                            }
                        }

                        for (int i = 0; i < Pageaccessp.Length; i++)
                        {
                            string pagename = Pageaccessp[i].ToString();
                            if (pagename.Trim() != "")
                            {
                                for (int m = 0; m < chklstPageAccess.Items.Count; m++)
                                {
                                    if (pagename.Trim().ToUpper() == chklstPageAccess.Items[m].ToString().Trim().ToUpper())
                                    {
                                        chklstPageAccess.SetItemCheckState(m, CheckState.Checked);
                                        chklstPageAccess.SetSelected(m, true);
                                        m = chklstCountries.Items.Count;
                                    }
                                }
                            }
                        }

                        System.Data.DataTable dt_grid = new System.Data.DataTable();
                        dt_grid.Columns.Add("User_Id");
                        dt_grid.Columns.Add("Products");
                        dt_grid.Columns.Add("Countrys");
                        dt_grid.Columns.Add("Application");
                        //dt_grid.Columns.Add("Page_Access");

                        for (int j = 0; j < ds.Tables[2].Rows.Count; j++)
                        {

                            string appname = ds.Tables[2].Rows[j]["app_name"].ToString();
                            //for (int m = 0; m < chklstApplication.Items.Count; m++)
                            //{
                            //    if (appname.Trim().ToUpper() == chklstApplication.Items[m].ToString().Trim().ToUpper())
                            //    {
                            //        chklstApplication.SetItemCheckState(m, CheckState.Checked);
                            //        chklstApplication.SetSelected(m, true);
                            //        m = chklstApplication.Items.Count;
                            //    }
                            //}

                            string couname = ds.Tables[2].Rows[j]["Country_name"].ToString();
                            //for (int m = 0; m < chklstCountries.Items.Count; m++)
                            //{
                            //    if (couname.Trim().ToUpper() == chklstCountries.Items[m].ToString().Trim().ToUpper())
                            //    {
                            //        chklstCountries.SetItemCheckState(m, CheckState.Checked);
                            //        chklstCountries.SetSelected(m, true);
                            //        m = chklstCountries.Items.Count;
                            //    }
                            //}

                            dt_grid.Rows.Add();
                            dt_grid.Rows[j][0] = txtUserPSID.Text;
                            dt_grid.Rows[j][1] = productname;
                            dt_grid.Rows[j][2] = couname;
                            dt_grid.Rows[j][3] = appname;
                            // dt_grid.Rows[j][4] = pagename;
                        }

                        dataGridView.DataSource = dt_grid;
                        dataGridView.Visible = true;
                    }
                    else
                    {
                        MessageBox.Show("PSID Not Exists ...!");
                    }
                }
                else
                {
                    MessageBox.Show("Please Enter the PSID...!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void btnEditUser_Click(object sender, EventArgs e)
        {
            try
            {
                strAppl = "";
                strCountr = "";
                strPrdt = "";
                string strselecteditems_01 = "";
                string strselecteditems_02 = "";
                string strselecteditems_03 = "";
                if (txtUserPSID.Text.Trim() == "")
                {
                    MessageBox.Show("Please Enter the PSID..!");
                    return;
                }

                if (txtUserPSID.Text != "")
                {
                    DataSet ds = new DataSet();
                    SqlConnection con = new SqlConnection(conString);
                    con.Open();
                    SqlCommand cmdd = new SqlCommand("select * from ARC_user_info b where userid='" + txtUserPSID.Text + "' ;select * from ARC_User_Access_Details where user_id='" + txtUserPSID.Text + "'", con);
                    da = new SqlDataAdapter(cmdd);
                    dt = new System.Data.DataTable();
                    da.Fill(ds);
                    con.Close();
                    bool Flag = false;

                    if (ds.Tables[0].Rows.Count == 0)
                    {
                        Flag = true;
                        MessageBox.Show("PSID Not Exists ...!");
                        return;
                    }


                    if (txtUserName.Text.Trim() == "")
                    {
                        MessageBox.Show("Please Enter the User_Name..!");
                        return;
                    }
                    if (txtLineManager.Text.Trim() == "")
                    {
                        MessageBox.Show("Please Enter the Line Manager PSID..!");
                        return;
                    }

                    if (cmbAccessType.Text == "" && cmbAccessType.Text.ToString().Trim().ToUpper() == "NULL")
                    {
                        MessageBox.Show("Please select the Access Type..!");
                        return;
                    }

                    if (chklstProduct.CheckedItems.Count == 1)
                    {
                        foreach (var row in chklstProduct.CheckedItems)
                        {
                            strselecteditems_02 = row.ToString();
                            con.Open();
                            cmd = new SqlCommand("select Product_Id from dbo.ARC_Product_Details where Product_Name='" + strselecteditems_02 + "'", con);
                            da = new SqlDataAdapter(cmd);
                            dt = new System.Data.DataTable();
                            da.Fill(dt);
                            string Prdt_ID = dt.Rows[0].ItemArray[0].ToString();
                            con.Close();
                            strPrdt = Prdt_ID;
                        }
                    }
                    else
                    {
                        MessageBox.Show("Please select only one item in Product");
                        return;
                    }

                    if (chklstApplication.CheckedItems.Count == 1)
                    {
                        foreach (var row in chklstApplication.CheckedItems)
                        {
                            strselecteditems_01 = row.ToString();
                            con.Open();
                            SqlCommand cmd = new SqlCommand("select App_Id from ARC_Applicationdetails where App_Name='" + strselecteditems_01 + "'", con);
                            da = new SqlDataAdapter(cmd);
                            dt = new System.Data.DataTable();
                            da.Fill(dt);
                            string Applic_ID = dt.Rows[0].ItemArray[0].ToString();
                            con.Close();
                            strAppl = Applic_ID;
                        }
                    }
                    else
                    {
                        MessageBox.Show("Please select the Application");
                        return;
                    }

                    if (chklstCountries.CheckedItems.Count == 1)
                    {
                        foreach (var row in chklstCountries.CheckedItems)
                        {
                            strselecteditems_03 = row.ToString();
                            con.Open();
                            cmd = new SqlCommand("select Country_Id from ARC_Country_Details where Country_name='" + strselecteditems_03 + "'", con);
                            da = new SqlDataAdapter(cmd);
                            dt = new System.Data.DataTable();
                            da.Fill(dt);
                            string Contry_ID = dt.Rows[0].ItemArray[0].ToString();
                            con.Close();
                            strCountr = Contry_ID;
                        }
                    }
                    else
                    {
                        MessageBox.Show("Please select the Country");
                        return;
                    }
                    string strPageAccess = "";
                    if (chklstPageAccess.CheckedItems.Count > 0)
                    {
                        foreach (var row in chklstPageAccess.CheckedItems)
                        {
                            strselecteditems_03 = row.ToString();
                            if (strPageAccess == "")
                            {
                                strPageAccess = strselecteditems_03;
                            }
                            else
                            {
                                strPageAccess = strPageAccess + "," + strselecteditems_03;
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("Please select only one item in Page Access");
                        return;
                    }

                    ds.Tables[1].DefaultView.RowFilter = "Country_Id='" + strCountr + "' and App_id='" + strAppl + "' and  Page_Access='" + strPageAccess + "'";
                    DataView dvcheck = ds.Tables[1].DefaultView;
                    if (dvcheck.Count > 0)
                    {
                        MessageBox.Show("User already having access ...!");
                        return;
                    }

                    string UserID = txtUserPSID.Text;

                    con.Open();
                    cmd = new SqlCommand("insert into ARC_User_Access_Details(User_Id,App_id,Country_Id,Page_Access) values(@User_Id,@App_id,@Country_Id,@Page_Access)", con);
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@User_Id", UserID);
                    cmd.Parameters.AddWithValue("@App_id", strAppl);
                    cmd.Parameters.AddWithValue("@Country_Id", strCountr);
                    cmd.Parameters.AddWithValue("@Page_Access", strPageAccess);
                    cmd.ExecuteNonQuery();
                    con.Close();

                    Hashtable hatcountry = new Hashtable();
                    Hashtable hatapp = new Hashtable();
                    Hashtable hatpage = new Hashtable();

                    hatapp.Add(strAppl, strAppl);
                    hatpage.Add(strPageAccess, strPageAccess);
                    hatcountry.Add(strCountr, strCountr);

                    for (int d = 0; d < ds.Tables[1].Rows.Count; d++)
                    {
                        string strappdet = ds.Tables[1].Rows[i]["App_id"].ToString();
                        string strcountdet = ds.Tables[1].Rows[i]["Country_Id"].ToString();
                        string strpagedet = ds.Tables[1].Rows[i]["Page_Access"].ToString();

                        if (!hatcountry.Contains(strcountdet))
                        {
                            hatcountry.Add(strcountdet, strcountdet);
                            strCountr = strCountr + "," + strcountdet;
                        }

                        if (!hatapp.Contains(strappdet))
                        {
                            hatapp.Add(strappdet, strappdet);
                            strAppl = strAppl + "," + strappdet;
                        }

                        if (!hatpage.Contains(strpagedet))
                        {
                            hatpage.Add(strpagedet, strpagedet);
                            strPageAccess = strPageAccess + "," + strpagedet;
                        }
                    }

                    string Psd = "Arc@123";
                    string role = cmbAccessType.Text.ToString().Trim();

                    string LUserId = txtLineManager.Text;
                    DateTime date = DateTime.Today;
                    DateTime date1 = DateTime.Today.AddDays(90);

                    con.Open();
                    cmd = new SqlCommand("update ARC_User_Info set userrole=@UserRole,StartDate=@StartDate,EndDate=@EndDate where UserID=@UserID", con);
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@UserID", UserID);
                    //cmd.Parameters.AddWithValue("@Password", Encrypt(Psd.Trim()));
                    cmd.Parameters.AddWithValue("@UserRole", role);
                    cmd.Parameters.AddWithValue("@StartDate", date);
                    cmd.Parameters.AddWithValue("@EndDate", date1);
                    cmd.ExecuteNonQuery();
                    con.Close();
                    int Role_Details_Id = 1;

                    con.Open();
                    cmd = new SqlCommand("update ARC_User_Details set User_Name=@User_Name,Manager_Id=@Manager_Id,Role_Details_Id=@Role_Details_Id,App_id=@App_id,Country_Id=@Country_Id,Product_Id=@Product_Id,Page_Access=@Page_Access where User_Id=@User_Id", con);
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@User_Id", UserID);
                    cmd.Parameters.AddWithValue("@User_Name", txtUserName.Text);
                    cmd.Parameters.AddWithValue("@Manager_Id", LUserId);
                    cmd.Parameters.AddWithValue("@Role_Details_Id", Role_Details_Id);
                    cmd.Parameters.AddWithValue("@App_id", strAppl);
                    cmd.Parameters.AddWithValue("@Country_Id", strCountr);
                    cmd.Parameters.AddWithValue("@Product_Id", strPrdt);
                    cmd.Parameters.AddWithValue("@Page_Access", strPageAccess);
                    cmd.ExecuteNonQuery();
                    con.Close();

                    //con.Open();
                    //SqlCommand com = new SqlCommand("select Password from dbo.ARC_User_Info where UserID=@UserID", con);
                    //com.CommandType = CommandType.Text;
                    //com.Parameters.AddWithValue("@UserID", UserID);
                    //SqlDataReader dr = com.ExecuteReader();
                    //while (dr.Read())
                    //{
                    //    if (dr.HasRows == true)
                    //    {
                    //        string Password = (string)dr["Password"];
                    //        Psd = Decrypt(Password.Trim());
                    //        Microsoft.Office.Interop.Outlook.Application app = new Microsoft.Office.Interop.Outlook.Application();
                    //        Microsoft.Office.Interop.Outlook.MailItem mailItem = app.CreateItem(Microsoft.Office.Interop.Outlook.OlItemType.olMailItem);
                    //        mailItem.Subject = "SCB: Password Reset";
                    //        mailItem.To = UserID;
                    //        mailItem.Body = "Dear User.\n \n Your Login Password For ARC Applications is " + Psd + "";
                    //        mailItem.Importance = Microsoft.Office.Interop.Outlook.OlImportance.olImportanceHigh;
                    //        mailItem.Send();
                    //    }
                    //}
                    //con.Close();

                    SearchFunction();
                    MessageBox.Show("User Added Successfully.. !");
                    //Clear_Function();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
        #endregion

        #region Holiday
        public void HolidayData()
        {
            System.Data.DataTable dt_Final = new System.Data.DataTable();
            dt_Final.Columns.Add("Country_Id");
            dt_Final.Columns.Add("Country_Name");
            dt_Final.Rows.Add("0", "--SELECT LIST--");
            SqlConnection con = new SqlConnection(conString);
            con.Open();
            SqlCommand cmd = new SqlCommand("ARC_SP_GetCountries", con);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            System.Data.DataTable dt = new System.Data.DataTable();
            sda.Fill(dt);

            foreach (DataRow d in dt.Rows)
            {
                dt_Final.ImportRow(d);
            }
            cmb_Holiday.ValueMember = "Country_Id";
            cmb_Holiday.DisplayMember = "Country_Name";
            cmb_Holiday.DataSource = dt_Final;


            con.Close();

        }

        private void btn_ViewCalendar_Click(object sender, EventArgs e)
        {
            try
            {
                countryID = cmb_Holiday.SelectedIndex;
                string countryName = this.cmb_Holiday.GetItemText(this.cmb_Holiday.SelectedItem);

                SqlConnection con = new SqlConnection(conString);
                if (countryID != 0)
                {
                    con.Open();
                    System.Data.DataTable dt_Cntry = new System.Data.DataTable();

                    SqlCommand com = new SqlCommand("select Holiday_ID, Holiday_Date, Holiday_Reason from ARC_Holiday_Master where Country_Id ='" + countryID + "'", con);

                    SqlDataAdapter da = new SqlDataAdapter(com);
                    da.Fill(dt_Cntry);

                    DGV_Holiday.DataSource = dt_Cntry;
                    DGV_Holiday.Columns[0].Visible = false;
                    con.Close();
                    DGV_Holiday.AllowUserToAddRows = false;
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        //Display Data in DataGridView  
        private void DisplayData()
        {
            try
            {
                SqlConnection con = new SqlConnection(conString);

                con.Open();
                System.Data.DataTable dt_Cntry = new System.Data.DataTable();

                SqlCommand com = new SqlCommand("select Holiday_ID, Holiday_Date, Holiday_Reason from ARC_Holiday_Master", con);

                SqlDataAdapter da = new SqlDataAdapter(com);
                da.Fill(dt_Cntry);

                //dt_Cntry.Columns.RemoveAt(0);
                DGV_Holiday.Columns[0].Visible = false;

                DGV_Holiday.DataSource = dt_Cntry;
                con.Close();
                DGV_Holiday.AllowUserToAddRows = false;

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        //Clear Data  
        private void ClearData()
        {
            cmb_Holiday.Text = "";
            dtPicker_From.Text = "";
            txt_HolidayReson.Text = "";
            cmb_Holiday.SelectedIndex = 0;
        }

        //Update Record  
        private void btn_EditCalendar_Click(object sender, EventArgs e)
        {
            countryID = cmb_Holiday.SelectedIndex;
            
            string countryName = this.cmb_Holiday.GetItemText(this.cmb_Holiday.SelectedItem);

            if (dtPicker_From.Text != "" && txt_HolidayReson.Text != "" && countryID > 0 && HolidayID > 0)
            {
                cmd = new SqlCommand("update ARC_Holiday_Master set Holiday_Date=@Holiday_Date, Holiday_Reason=@Holiday_Reason, Country_Id = @Country_Id, Last_Updated_By=@PSID, Last_Update_Datetime=@Updated_Datetime where Holiday_ID=@id", con);
                con.Open();
                cmd.Parameters.AddWithValue("@id", HolidayID);
                cmd.Parameters.AddWithValue("@Holiday_Date", dtPicker_From.Text);
                cmd.Parameters.AddWithValue("@Holiday_Reason", txt_HolidayReson.Text);
                cmd.Parameters.AddWithValue("@Country_Id", countryID);
                cmd.Parameters.AddWithValue("@PSID", Environment.UserName);
                cmd.Parameters.AddWithValue("@Updated_Datetime", System.DateTime.Today);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Record Updated Successfully");
                con.Close();
                DisplayData();
                ClearData();
            }
            else
            {
                MessageBox.Show("Please Select Record to Update");
            }
        }

        private void DGV_Holiday_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            HolidayID = Convert.ToInt32(DGV_Holiday.Rows[e.RowIndex].Cells[0].Value);

            cmb_Holiday.SelectedIndex = countryID;
            
            dtPicker_From.Text = DGV_Holiday.Rows[e.RowIndex].Cells[1].Value.ToString();
            txt_HolidayReson.Text = DGV_Holiday.Rows[e.RowIndex].Cells[2].Value.ToString();
        }

        private void btn_AddCalendar_Click(object sender, EventArgs e)
        {
            if (dtPicker_From.Text != "" && txt_HolidayReson.Text != "" && countryID > 0)
            {
                cmd = new SqlCommand("insert into ARC_Holiday_Master(Holiday_Date,Holiday_Reason, Country_Id,Last_Updated_By,Last_Update_Datetime) values(@Holiday_Date,@Holiday_Reason, @Country_Id,@PSID, @Updated_Datetime)", con);
                con.Open();
                cmd.Parameters.AddWithValue("@Holiday_Date", dtPicker_From.Text);
                cmd.Parameters.AddWithValue("@Holiday_Reason", txt_HolidayReson.Text);
                cmd.Parameters.AddWithValue("@Country_Id", countryID);
                cmd.Parameters.AddWithValue("@PSID", Environment.UserName);
                cmd.Parameters.AddWithValue("@Updated_Datetime", System.DateTime.Today);
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Record Inserted Successfully");
                DisplayData();
                ClearData();
            }
            else
            {
                MessageBox.Show("Please Provide Details!");
            }  
        }

        private void btn_DeleteCalendar_Click(object sender, EventArgs e)
        {
            if (HolidayID != 0)
            {
                cmd = new SqlCommand("delete ARC_Holiday_Master where Holiday_ID=@id", con);
                con.Open();
                cmd.Parameters.AddWithValue("@id", HolidayID);
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Record Deleted Successfully!");
                DisplayData();
                ClearData();
            }
            else
            {
                MessageBox.Show("Please Select Record to Delete");
            }  
        }
        #endregion
    }
}
