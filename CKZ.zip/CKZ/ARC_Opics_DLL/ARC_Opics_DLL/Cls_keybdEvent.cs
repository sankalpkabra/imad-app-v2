﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading;
using System.Data;
using System.Windows;
//using System.Drawing;
using System.Windows.Forms;
using System.Drawing.Imaging;
using Microsoft.Office.Interop.Excel;
using Excel = Microsoft.Office.Interop.Excel;
using System.Data.SqlClient;
using System.Collections;
using System.Runtime.InteropServices;

namespace ARC_Opics_DLL
{
    public class cls_KeybdEvents
    {
        public SqlConnection conn;
        public SqlCommand com;
        public int worksheet_Count = 1;
        [DllImport("user32.dll")]
        public static extern int FindWindow(string lpClassName, string lpWindowName);
        [DllImport("user32.dll")]
        private static extern IntPtr SetForegroundWindow(int hWnd);        
        [DllImport("user32.dll", SetLastError = true)]
        static extern void keybd_event(int bVk, int bScan, int dwFlags, int dwExtraInfo);
        [DllImport("User32.dll")]
        public static extern IntPtr GetDC(IntPtr hwnd);
        [DllImport("User32.dll")]
        public static extern void ReleaseDC(IntPtr hwnd, IntPtr dc);
        [DllImport("user32.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
        public static extern void mouse_event(int dwFlags, int dx, int dy, int cButtons, int dwExtraInfo);

        private const int MOUSEEVENTF_LEFTDOWN = 0x02;
        private const int MOUSEEVENTF_LEFTUP = 0x04;
        private const int MOUSEEVENTF_RIGHTDOWN = 0x08;
        private const int MOUSEEVENTF_RIGHTUP = 0x10;
        public const int KEYEVENTF_EXTENDEDKEY = 0x0001; //Key down flag
        public const int KEYEVENTF_KEYUP = 0x0002; //Key up flag
        public const int VK_LCONTROL = 0xA2; //Left Control key code
        public const int MOUSEEVENTF_MIDDLEDOWN = 0x20; //middle button down
        public const int MOUSEEVENTF_MIDDLEUP = 0x40;// middle button up


        public const int A = 0x41;
        public const int C = 0x43;
        public const int VK_SHIFT = 16;        
        public const int VK_TAB = 9;
        public const int VK_MENU = 17;
        public const int varwidth = 100;
        public const int varheight = 20;
        public bool shiftkey;
        public bool ctrkey;
        public bool altkey;
        public int keyval;
      
        public void startprocess(int x_axis, int y_axis, int ht, int wd, int wait, string action, string query)
        {
            int imgresult = 0;

            if ("Passvalue".Equals(action))
            {
                keytest(query);
            }
            else if ("F15".Equals(action) || "Pscreen".Equals(action) || "NUMLock".Equals(action))
            {
                processexecution(action, x_axis, y_axis, wd, "", wait);
            }
            else
            {
                processexecution(action, x_axis, y_axis, wd, "", wait);
            }
        }
        public void processexecution_noncursor(string action, int waittime)
        {
            if ("F15".Equals(action, StringComparison.OrdinalIgnoreCase))
            {
                keybd_event(126, 0, 0, 0);
                keybd_event(126, 0, KEYEVENTF_KEYUP, 0);
                Thread.Sleep(waittime);
            }
            if ("Pscreen".Equals(action, StringComparison.OrdinalIgnoreCase))
            {
                keybd_event(44, 0, 0, 0);
                keybd_event(44, 0, KEYEVENTF_KEYUP, 0);
                Thread.Sleep(waittime);
            }
            if ("NUMLock".Equals(action, StringComparison.OrdinalIgnoreCase))
            {
                keybd_event(0xC5, 45, 0, 0);
                keybd_event(0xC5, 45, KEYEVENTF_KEYUP, 0);
                Thread.Sleep(waittime);
            }
        }

        public void processexecution(string action, int X, int Y, int selwidth, string selfrom, int waittime)
        {
            Cursor.Position = new System.Drawing.Point(X, Y);
            Thread.Sleep(100);

            if ("Lclick".Equals(action, StringComparison.OrdinalIgnoreCase))
            {
                mouse_event(MOUSEEVENTF_LEFTDOWN, X, Y, 0, 0);
                mouse_event(MOUSEEVENTF_LEFTUP, X, Y, 0, 0);
                Thread.Sleep(waittime);
            }
            if ("Rclick".Equals(action, StringComparison.OrdinalIgnoreCase))
            {
                mouse_event(MOUSEEVENTF_RIGHTDOWN, X, Y, 0, 0);
                mouse_event(MOUSEEVENTF_RIGHTUP, X, Y, 0, 0);
                Thread.Sleep(waittime);
            }
            if ("Tab".Equals(action, StringComparison.OrdinalIgnoreCase))
            {
                keybd_event(0x09, 0xf, 0, 0);
                keybd_event(0x09, 0xf, KEYEVENTF_KEYUP, 0);
                Thread.Sleep(waittime);
            }
            if ("F15".Equals(action, StringComparison.OrdinalIgnoreCase))
            {
                keybd_event(126, 0, 0, 0);
                keybd_event(126, 0, KEYEVENTF_KEYUP, 0);
                Thread.Sleep(waittime);
            }
            if ("Pscreen".Equals(action, StringComparison.OrdinalIgnoreCase))
            {
                keybd_event(44, 0, 0, 0);
                keybd_event(44, 0, KEYEVENTF_KEYUP, 0);
                Thread.Sleep(waittime);
            }
            if ("NUMLock".Equals(action, StringComparison.OrdinalIgnoreCase))
            {
                keybd_event(0xC5, 45, 0, 0);
                keybd_event(0xC5, 45, KEYEVENTF_KEYUP, 0);
                Thread.Sleep(waittime);
            }
            if ("3Tab".Equals(action, StringComparison.OrdinalIgnoreCase))
            {
                keybd_event(0x09, 0xf, 0, 0);
                keybd_event(0x09, 0xf, KEYEVENTF_KEYUP, 0);
                Thread.Sleep(1000);
                keybd_event(0x09, 0xf, 0, 0);
                keybd_event(0x09, 0xf, KEYEVENTF_KEYUP, 0);
                Thread.Sleep(1000);
                keybd_event(0x09, 0xf, 0, 0);
                keybd_event(0x09, 0xf, KEYEVENTF_KEYUP, 0);
                Thread.Sleep(1000);
            }
            if ("Alt+F+X+N".Equals(action, StringComparison.OrdinalIgnoreCase))
            {
                keybd_event(0xB8, 0x38, 0, 0);
                keybd_event(0xB8, 0x38, KEYEVENTF_KEYUP, 0);
                Thread.Sleep(100);
                keybd_event(70, 0, 0, 0);
                keybd_event(70, 0, KEYEVENTF_KEYUP, 0);
                Thread.Sleep(100);
                keybd_event(88, 0, 0, 0);
                keybd_event(88, 0, KEYEVENTF_KEYUP, 0);
                Thread.Sleep(2000);
                keybd_event(78, 0, 0, 0);
                keybd_event(78, 0, KEYEVENTF_KEYUP, 0);
                Thread.Sleep(waittime);
            }
            if ("Alt+F+X+N+N".Equals(action, StringComparison.OrdinalIgnoreCase))
            {
                keybd_event(0xB8, 0x38, 0, 0);
                keybd_event(0xB8, 0x38, KEYEVENTF_KEYUP, 0);
                Thread.Sleep(100);
                keybd_event(70, 0, 0, 0);
                keybd_event(70, 0, KEYEVENTF_KEYUP, 0);
                Thread.Sleep(100);
                keybd_event(88, 0, 0, 0);
                keybd_event(88, 0, KEYEVENTF_KEYUP, 0);
                Thread.Sleep(2000);
                keybd_event(78, 0, 0, 0);
                keybd_event(78, 0, KEYEVENTF_KEYUP, 0);
                Thread.Sleep(2000);
                keybd_event(78, 0, 0, 0);
                keybd_event(78, 0, KEYEVENTF_KEYUP, 0);
                Thread.Sleep(waittime);
            }
            if ("2Tab+Enter".Equals(action, StringComparison.OrdinalIgnoreCase))
            {                
                keybd_event(0x09, 0xf, 0, 0);
                keybd_event(0x09, 0xf, KEYEVENTF_KEYUP, 0);
                Thread.Sleep(1000);
                keybd_event(0x09, 0xf, 0, 0);
                keybd_event(0x09, 0xf, KEYEVENTF_KEYUP, 0);
                Thread.Sleep(1000);
                keybd_event(0x9C, 0x1C, 0, 0);
                keybd_event(0x9C, 0x1C, KEYEVENTF_KEYUP, 0);
                Thread.Sleep(waittime);                
            }
            if ("Pass-N".Equals(action, StringComparison.OrdinalIgnoreCase))
            {
                keybd_event(78, 0, 0, 0);
                keybd_event(78, 0, KEYEVENTF_KEYUP, 0);                
                Thread.Sleep(waittime);
            }           
            if ("Copy".Equals(action, StringComparison.OrdinalIgnoreCase))
            {
                keybd_event(0x9D, 0x1D, 0, 0);
                keybd_event(0xAE, 0x2E, 0, 0);
                keybd_event(0x9D, 0x1D, KEYEVENTF_KEYUP, 0);
                keybd_event(0xAE, 0x2E, KEYEVENTF_KEYUP, 0);
                Thread.Sleep(waittime);
            }
            if ("Cut".Equals(action, StringComparison.OrdinalIgnoreCase))
            {
                keybd_event(0x9D, 0x1D, 0, 0);
                keybd_event(0xAD, 0x2D, 0, 0);
                keybd_event(0xAD, 0x2D, KEYEVENTF_KEYUP, 0);
                keybd_event(0x9D, 0x1D, KEYEVENTF_KEYUP, 0);
                Thread.Sleep(waittime);
            }
            if ("Paste".Equals(action, StringComparison.OrdinalIgnoreCase))
            {
                keybd_event(0x9D, 0x1D, 0, 0);
                keybd_event(0xAF, 0x2F, 0, 0);
                keybd_event(0x9D, 0x1D, KEYEVENTF_KEYUP, 0);
                keybd_event(0xAF, 0x2F, KEYEVENTF_KEYUP, 0);
                Thread.Sleep(waittime);
            }
            if ("Paste_Win".Equals(action, StringComparison.OrdinalIgnoreCase))
            {
                keybd_event(0x11, 0, 0, 0);
                keybd_event(86, 0, 0, 0);
                keybd_event(0x11, 0, KEYEVENTF_KEYUP, 0);
                keybd_event(86, 0, KEYEVENTF_KEYUP, 0);
                Thread.Sleep(waittime);
            }
            if ("Select".Equals(action, StringComparison.OrdinalIgnoreCase))
            {             
                keybd_event(0x9D,0x1D, 0, 0);
                keybd_event(0x9e, 0x1e, 0, 0);                
                keybd_event(0x9D, 0x1D, KEYEVENTF_KEYUP, 0);
                keybd_event(0x9e, 0x1e, KEYEVENTF_KEYUP, 0);
                Thread.Sleep(1000);                                               
            }
            if ("Up_Click".Equals(action, StringComparison.OrdinalIgnoreCase))
            {               
                keybd_event(0x26, 0, 0, 0);                
                keybd_event(0x26, 0, KEYEVENTF_KEYUP, 0);
                Thread.Sleep(1000);
            }
            if ("Down_Click".Equals(action, StringComparison.OrdinalIgnoreCase))
            {
                keybd_event(0x40, 0, 0, 0);                
                keybd_event(0x40, 0, KEYEVENTF_KEYUP, 0);
                Thread.Sleep(1000);
            }
            if ("Save+Yes".Equals(action, StringComparison.OrdinalIgnoreCase))
            {                
                keybd_event(0x09, 0xf, 0, 0);
                keybd_event(0x09, 0xf, KEYEVENTF_KEYUP, 0);
                Thread.Sleep(1000);
                keybd_event(77, 0, 0, 0);
                keybd_event(77, 0, KEYEVENTF_KEYUP, 0);
                Thread.Sleep(1000);
                keybd_event(77, 0, 0, 0);
                keybd_event(77, 0, KEYEVENTF_KEYUP, 0);
                Thread.Sleep(1000);
                keybd_event(77, 0, 0, 0);
                keybd_event(77, 0, KEYEVENTF_KEYUP, 0);
                Thread.Sleep(1000);
                keybd_event(0x09, 0xf, 0, 0);
                keybd_event(0x09, 0xf, KEYEVENTF_KEYUP, 0);
                Thread.Sleep(1000);                
                keybd_event(0x9C, 0x1C, 0, 0);
                keybd_event(0x9C, 0x1C, KEYEVENTF_KEYUP, 0);
                Thread.Sleep(waittime);
                keybd_event(89, 0, 0, 0);
                keybd_event(89, 0, KEYEVENTF_KEYUP, 0);
            }
            if ("Tab+Up+Up+Tab+Enter".Equals(action, StringComparison.OrdinalIgnoreCase))
            {
                keybd_event(0x09, 0xf, 0, 0);
                keybd_event(0x09, 0xf, KEYEVENTF_KEYUP, 0);
                Thread.Sleep(1000);
                keybd_event(0xC8, 0x48, 0, 0);
                keybd_event(0xC8, 0x48, KEYEVENTF_KEYUP, 0);
                Thread.Sleep(1000);
                for (int i = 0; i < 7; i++)
                {
                    keybd_event(0xC9, 0x49, 0, 0);
                    keybd_event(0xC9, 0x49, KEYEVENTF_KEYUP, 0);
                    Thread.Sleep(1000);
                }
                keybd_event(0x09, 0xf, 0, 0);
                keybd_event(0x09, 0xf, KEYEVENTF_KEYUP, 0);
                Thread.Sleep(1000);
                keybd_event(0x9C, 0x1C, 0, 0);
                keybd_event(0x9C, 0x1C, KEYEVENTF_KEYUP, 0);
                Thread.Sleep(waittime);
            }
            if ("LocalPaste".Equals(action, StringComparison.OrdinalIgnoreCase))
            {
                keybd_event(0xA2, 0, 0, 0);
                keybd_event(86, 0, 0, 0);
                keybd_event(0xA2, 0, 0x0002, 0);
                keybd_event(86, 0, 0x0002, 0);
                Thread.Sleep(waittime);
            }
            if ("Alt+E+Q".Equals(action, StringComparison.OrdinalIgnoreCase))
            {
                keybd_event(0xB8, 0x38, 0, 0);
                keybd_event(0xB8, 0x38, KEYEVENTF_KEYUP, 0);
                keybd_event(0x92, 0x12, 0, 0);                
                keybd_event(0x92, 0x12, KEYEVENTF_KEYUP, 0);                
                keybd_event(0x90, 0x10, 0, 0);
                keybd_event(0x90, 0x10, KEYEVENTF_KEYUP, 0);
                Thread.Sleep(waittime);
            }
            if ("Alt+F+Q".Equals(action, StringComparison.OrdinalIgnoreCase))
            {
                keybd_event(0xB8, 0x38, 0, 0);
                keybd_event(0xB8, 0x38, KEYEVENTF_KEYUP, 0);
                Thread.Sleep(waittime);
                keybd_event(0xA1, 0x21, 0, 0);
                keybd_event(0xA1, 0x21, KEYEVENTF_KEYUP, 0);
                Thread.Sleep(waittime);
                keybd_event(0x90, 0x10, 0, 0);
                keybd_event(0x90, 0x10, KEYEVENTF_KEYUP, 0);
                Thread.Sleep(waittime);
            }
            if("shift+tab".Equals(action, StringComparison.OrdinalIgnoreCase))
            {
                                
                keybd_event(0xAA, 0x2A, 0, 0);
                Thread.Sleep(waittime);
                keybd_event(0x8f, 0xf, 0, 0);
                keybd_event(0x8f, 0xf, KEYEVENTF_KEYUP, 0);
                Thread.Sleep(waittime);
                keybd_event(0xAA, 0x2A, KEYEVENTF_KEYUP, 0);                
                Thread.Sleep(waittime);                                        
            }            
            if ("Alt+T+N".Equals(action, StringComparison.OrdinalIgnoreCase))
            {
                keybd_event(0xB8, 0x38, 0, 0);
                keybd_event(0xB8, 0x38, KEYEVENTF_KEYUP, 0);
                Thread.Sleep(2000);
                keybd_event(0x94, 0x14, 0, 0);
                keybd_event(0x94, 0x14, KEYEVENTF_KEYUP, 0);
                Thread.Sleep(2000);
                keybd_event(0xB1, 0x31, 0, 0);
                keybd_event(0xB1, 0x31, KEYEVENTF_KEYUP, 0);
                Thread.Sleep(waittime);
            }
            if ("Alt+X+E".Equals(action, StringComparison.OrdinalIgnoreCase))
            {
                keybd_event(0xB8, 0x38, 0, 0);
                keybd_event(0xB8, 0x38, KEYEVENTF_KEYUP, 0);
                Thread.Sleep(2000);
                keybd_event(0xAD, 0x2D, 0, 0);
                keybd_event(0xAD, 0x2D, KEYEVENTF_KEYUP, 0);
                Thread.Sleep(2000);
                keybd_event(0x92, 0x12, 0, 0);
                keybd_event(0x92, 0x12, KEYEVENTF_KEYUP, 0);
                Thread.Sleep(waittime);
            }
            if ("Space+S+S".Equals(action, StringComparison.OrdinalIgnoreCase))
            {                
                keybd_event(32, 0, 0, 0);                
                keybd_event(32, 0, KEYEVENTF_KEYUP, 0);
                Thread.Sleep(waittime);
                keybd_event(83, 0, 0, 0);
                keybd_event(83, 0, KEYEVENTF_KEYUP, 0);
                Thread.Sleep(waittime);
                keybd_event(83, 0, 0, 0);
                keybd_event(83, 0, KEYEVENTF_KEYUP, 0);
                Thread.Sleep(waittime);
            }
            if ("Alt+Space+X".Equals(action, StringComparison.OrdinalIgnoreCase))
            {               
                keybd_event(0xB8, 0x38, 0, 0);                
                keybd_event(32, 0, 0, 0);
                Thread.Sleep(1000);
                keybd_event(88, 0, 0, 0);                
                keybd_event(88, 0, KEYEVENTF_KEYUP, 0); 
                keybd_event(0xB8, 0x38, KEYEVENTF_KEYUP, 0);                                                                  
                keybd_event(32, 0, KEYEVENTF_KEYUP, 0);                
                Thread.Sleep(waittime);
            }
            if ("Alt+Space+X+C".Equals(action, StringComparison.OrdinalIgnoreCase))
            {                
                keybd_event(0xB8, 0x38, 0, 0);
                keybd_event(32, 0, 0, 0);
                Thread.Sleep(1000);
                keybd_event(88, 0, 0, 0);
                keybd_event(88, 0, KEYEVENTF_KEYUP, 0);
                keybd_event(0xB8, 0x38, KEYEVENTF_KEYUP, 0);
                keybd_event(32, 0, KEYEVENTF_KEYUP, 0);
                keybd_event(67, 0, 0, 0);
                keybd_event(67, 0, KEYEVENTF_KEYUP, 0); 
                Thread.Sleep(waittime);
            }
            if ("Alt+F+A".Equals(action, StringComparison.OrdinalIgnoreCase))
            {
                keybd_event(0xB8, 0x38, 0, 0);
                keybd_event(0xB8, 0x38, KEYEVENTF_KEYUP, 0);
                Thread.Sleep(2000);
                keybd_event(70, 0, 0, 0);
                keybd_event(70, 0, KEYEVENTF_KEYUP, 0);
                Thread.Sleep(2000);
                keybd_event(65, 0, 0, 0);
                keybd_event(65, 0, KEYEVENTF_KEYUP, 0);
                Thread.Sleep(waittime);
            }
            if ("AltQ".Equals(action, StringComparison.OrdinalIgnoreCase))
            {
                keybd_event(0xB8, 0x38, 0, 0);
                keybd_event(0x90, 0x10, 0, 0);
                keybd_event(0x90, 0x10, KEYEVENTF_KEYUP, 0);
                keybd_event(0xB8, 0x38, KEYEVENTF_KEYUP, 0);
                Thread.Sleep(waittime);
            }
            if ("Alt+R".Equals(action, StringComparison.OrdinalIgnoreCase))
            {
                keybd_event(0xB8, 0x38, 0, 0);
                keybd_event(0x93, 0x13, 0, 0);
                keybd_event(0x93, 0x13, KEYEVENTF_KEYUP, 0);
                keybd_event(0xB8, 0x38, KEYEVENTF_KEYUP, 0);
                Thread.Sleep(waittime);
            }            
            if ("Alt+D+F+F".Equals(action, StringComparison.OrdinalIgnoreCase))
            {
                keybd_event(0xB8, 0x38, 0, 0);
                keybd_event(0xB8, 0x38, KEYEVENTF_KEYUP, 0);
                Thread.Sleep(2000);
                keybd_event(0xA0, 0x20, 0, 0);
                keybd_event(0xA0, 0x20, KEYEVENTF_KEYUP, 0);
                Thread.Sleep(2000);
                keybd_event(0xA1, 0x21, 0, 0);
                keybd_event(0xA1, 0x21, KEYEVENTF_KEYUP, 0);
                Thread.Sleep(2000);
                keybd_event(0xA1, 0x21, 0, 0);
                keybd_event(0xA1, 0x21, KEYEVENTF_KEYUP, 0);
                Thread.Sleep(waittime);
            }
            if ("Alt+D+D".Equals(action, StringComparison.OrdinalIgnoreCase))
            {
                keybd_event(0xB8, 0x38, 0, 0);
                keybd_event(0xB8, 0x38, KEYEVENTF_KEYUP, 0);
                Thread.Sleep(2000);
                keybd_event(0xA0, 0x20, 0, 0);
                keybd_event(0xA0, 0x20, KEYEVENTF_KEYUP, 0);
                Thread.Sleep(2000);
                keybd_event(0xA0, 0x20, 0, 0);
                keybd_event(0xA0, 0x20, KEYEVENTF_KEYUP, 0);
                Thread.Sleep(waittime);
            }
            if ("AltO".Equals(action, StringComparison.OrdinalIgnoreCase))
            {
                keybd_event(0xB8, 0x38, 0, 0);
                keybd_event(0x98, 0x18, 0, 0);
                keybd_event(0x98, 0x18, KEYEVENTF_KEYUP, 0);
                keybd_event(0xB8, 0x38, KEYEVENTF_KEYUP, 0);
                Thread.Sleep(2000);                
            }
            if ("AltC".Equals(action, StringComparison.OrdinalIgnoreCase))
            {
                keybd_event(0xB8, 0x38, 0, 0);
                keybd_event(0xAE, 0x2E, 0, 0);
                keybd_event(0xAE, 0x2E, KEYEVENTF_KEYUP, 0);
                keybd_event(0xB8, 0x38, KEYEVENTF_KEYUP, 0);
                Thread.Sleep(2000);
            }
            if ("AltQ".Equals(action, StringComparison.OrdinalIgnoreCase))
            {
                keybd_event(0xB8, 0x38, 0, 0);
                keybd_event(0x90, 0x10, 0, 0);
                keybd_event(0x90, 0x10, KEYEVENTF_KEYUP, 0);
                keybd_event(0xB8, 0x38, KEYEVENTF_KEYUP, 0);
                Thread.Sleep(2000);
            }
            if ("Alt+T+G".Equals(action, StringComparison.OrdinalIgnoreCase))
            {
                keybd_event(0xB8, 0x38, 0, 0);
                keybd_event(0xB8, 0x38, KEYEVENTF_KEYUP, 0);
                Thread.Sleep(2000);
                keybd_event(0x94, 0x14, 0, 0);
                keybd_event(0x94, 0x14, KEYEVENTF_KEYUP, 0);
                Thread.Sleep(2000);
                keybd_event(0xA2, 0x22, 0, 0);
                keybd_event(0xA2, 0x22, KEYEVENTF_KEYUP, 0);
                Thread.Sleep(waittime);
            }
            if ("Alt+Q".Equals(action, StringComparison.OrdinalIgnoreCase))
            {
                keybd_event(0xB8, 0x38, 0, 0);
                keybd_event(0xB8, 0x38, KEYEVENTF_KEYUP, 0);
                Thread.Sleep(waittime);                
                keybd_event(81, 0, 0, 0);
                keybd_event(81, 0, KEYEVENTF_KEYUP, 0);
                Thread.Sleep(waittime);
            }
            if ("F2".Equals(action, StringComparison.OrdinalIgnoreCase))
            {
                keybd_event(113, 0, 0, 0);
                keybd_event(113, 0, KEYEVENTF_KEYUP, 0);
                Thread.Sleep(waittime);

            }
            if ("Enter_Win".Equals(action, StringComparison.OrdinalIgnoreCase))
            {
                keybd_event(13, 0, 0, 0);
                keybd_event(13, 0, KEYEVENTF_KEYUP, 0);
                Thread.Sleep(waittime);

            }
            if ("Tab_Win".Equals(action, StringComparison.OrdinalIgnoreCase))
            {
                keybd_event(9, 0, 0, 0);
                keybd_event(9, 0, KEYEVENTF_KEYUP, 0);
                Thread.Sleep(waittime);

            }
            if ("Enter".Equals(action, StringComparison.OrdinalIgnoreCase))
            {
                keybd_event(0x9C, 0x1C, 0, 0);
                keybd_event(0x9C, 0x1C, KEYEVENTF_KEYUP, 0);
                Thread.Sleep(waittime);

            }
            if ("Delete".Equals(action, StringComparison.OrdinalIgnoreCase))
            {
                keybd_event(46, 0, 0, 0);
                keybd_event(46, 0, KEYEVENTF_KEYUP, 0);
                Thread.Sleep(waittime);
            }
            if ("Backspace".Equals(action, StringComparison.OrdinalIgnoreCase))
            {
                keybd_event(8, 0, 0, 0);
                keybd_event(8, 0, KEYEVENTF_KEYUP, 0);
                Thread.Sleep(waittime);
            }

            if ("Space".Equals(action, StringComparison.OrdinalIgnoreCase))
            {
                keybd_event(32, 0, 0, 0);
                keybd_event(32, 0, KEYEVENTF_KEYUP, 0);
                Thread.Sleep(waittime);

            }
            if ("PageDown".Equals(action, StringComparison.OrdinalIgnoreCase))
            {
                keybd_event(34, 0, 0, 0);
                keybd_event(34, 0, KEYEVENTF_KEYUP, 0);
                Thread.Sleep(waittime);

            }
            if ("PageUp".Equals(action, StringComparison.OrdinalIgnoreCase))
            {
                keybd_event(33, 0, 0, 0);
                keybd_event(33, 0, KEYEVENTF_KEYUP, 0);
                Thread.Sleep(waittime);

            }
            if ("End".Equals(action, StringComparison.OrdinalIgnoreCase))
            {
                keybd_event(35, 0, 0, 0);
                keybd_event(35, 0, KEYEVENTF_KEYUP, 0);
                Thread.Sleep(waittime);

            }
            if ("Home".Equals(action, StringComparison.OrdinalIgnoreCase))
            {
                keybd_event(36, 0, 0, 0);
                keybd_event(36, 0, KEYEVENTF_KEYUP, 0);
                Thread.Sleep(waittime);

            }
            if ("UpArrow".Equals(action, StringComparison.OrdinalIgnoreCase))
            {
                keybd_event(38, 0, 0, 0);
                keybd_event(38, 0, KEYEVENTF_KEYUP, 0);
                Thread.Sleep(waittime);

            }
            if ("DownArrow".Equals(action, StringComparison.OrdinalIgnoreCase))
            {
                keybd_event(40, 0, 0, 0);
                keybd_event(40, 0, KEYEVENTF_KEYUP, 0);
                Thread.Sleep(waittime);

            }
            if ("LeftArrow".Equals(action, StringComparison.OrdinalIgnoreCase))
            {
                keybd_event(37, 0, 0, 0);
                keybd_event(37, 0, KEYEVENTF_KEYUP, 0);
                Thread.Sleep(waittime);

            }

            if ("RightArrow".Equals(action, StringComparison.OrdinalIgnoreCase))
            {
                keybd_event(39, 0, 0, 0);
                keybd_event(39, 0, KEYEVENTF_KEYUP, 0);
                Thread.Sleep(waittime);

            }
            if ("SpaceBar".Equals(action, StringComparison.OrdinalIgnoreCase))
            {
                keybd_event(32, 0, 0, 0);
                keybd_event(32, 0, KEYEVENTF_KEYUP, 0);
                Thread.Sleep(waittime);

            }

            if ("Escape".Equals(action, StringComparison.OrdinalIgnoreCase))
            {
                keybd_event(27, 0, 0, 0);
                keybd_event(27, 0, KEYEVENTF_KEYUP, 0);
                Thread.Sleep(waittime);

            }

            if ("Alt + G".Equals(action, StringComparison.OrdinalIgnoreCase))
            {
                keybd_event(27, 0, 0, 0);
                keybd_event(27, 0, KEYEVENTF_KEYUP, 0);
                Thread.Sleep(waittime);

            }
            if ("Alt".Equals(action, StringComparison.OrdinalIgnoreCase))
            {
                keybd_event(0x12, 0xb8, 0, 0);
                keybd_event(0x12, 0xb8, KEYEVENTF_KEYUP, 0);                 
                Thread.Sleep(waittime);
            }
            if ("X".Equals(action, StringComparison.OrdinalIgnoreCase))
            {
                keybd_event(88, 0, 0, 0);
                keybd_event(88, 0, KEYEVENTF_KEYUP, 0);
                Thread.Sleep(waittime);
            }
            if ("ctrlPress".Equals(action, StringComparison.OrdinalIgnoreCase))
            {
                keybd_event(0xA2, 0, 0, 0);               
            }
            if ("ctrlRelease".Equals(action, StringComparison.OrdinalIgnoreCase))
            {
                keybd_event(0xA2, 0, KEYEVENTF_KEYUP, 0);                
            }
            if ("E".Equals(action, StringComparison.OrdinalIgnoreCase))
            {
                keybd_event(69, 0, 0, 0);
                keybd_event(69, 0, KEYEVENTF_KEYUP, 0);
                Thread.Sleep(waittime);
            }
            if ("selectcopy".Equals(action, StringComparison.OrdinalIgnoreCase))
            {
                if ("left".Equals(selfrom, StringComparison.OrdinalIgnoreCase))
                {
                    mouse_event(MOUSEEVENTF_LEFTDOWN, X, Y, 0, 0);
                    mouse_event(MOUSEEVENTF_LEFTUP, X, Y, 0, 0);
                    Thread.Sleep(100);
                    mouse_event(MOUSEEVENTF_LEFTDOWN, X, Y, 0, 0);
                    Cursor.Position = new System.Drawing.Point(X + selwidth, Y);
                    Thread.Sleep(100);
                    mouse_event(MOUSEEVENTF_LEFTUP, X + selwidth, Y, 0, 0);
                    Thread.Sleep(4000);
                    keybd_event(VK_LCONTROL, 157, 0, 0);
                    keybd_event(C, 0, 0, 0);
                    keybd_event(C, 0, KEYEVENTF_KEYUP, 0);
                    keybd_event(VK_LCONTROL, 157, KEYEVENTF_KEYUP, 0);

                }
                else if ("right".Equals(selfrom, StringComparison.OrdinalIgnoreCase))
                {
                    mouse_event(MOUSEEVENTF_LEFTDOWN, X, Y, 0, 0);
                    mouse_event(MOUSEEVENTF_LEFTUP, X, Y, 0, 0);
                    Thread.Sleep(100);
                    mouse_event(MOUSEEVENTF_LEFTDOWN, X, Y, 0, 0);
                    Cursor.Position = new System.Drawing.Point(X - selwidth, Y);
                    Thread.Sleep(100);
                    mouse_event(MOUSEEVENTF_LEFTUP, X - selwidth, Y, 0, 0);
                    Thread.Sleep(4000);
                    keybd_event(VK_LCONTROL, 157, 0, 0);
                    keybd_event(C, 0, 0, 0);
                    keybd_event(C, 0, KEYEVENTF_KEYUP, 0);
                    keybd_event(VK_LCONTROL, 157, KEYEVENTF_KEYUP, 0);

                }

            }
        }
        
        public void keytest(string inputSring)
        {
            char[] array = inputSring.ToCharArray();
            for (int i = 0; i < array.Length; i++)
            {
                shiftkey = false;
                ctrkey = false;
                switch (array[i])
                {
                    case 'A': shiftkey = true; ctrkey = false; keyval = 65; break;
                    case 'B': shiftkey = true; ctrkey = false; keyval = 66; break;
                    case 'C': shiftkey = true; ctrkey = false; keyval = 67; break;
                    case 'D': shiftkey = true; ctrkey = false; keyval = 68; break;
                    case 'E': shiftkey = true; ctrkey = false; keyval = 69; break;
                    case 'F': shiftkey = true; ctrkey = false; keyval = 70; break;
                    case 'G': shiftkey = true; ctrkey = false; keyval = 71; break;
                    case 'H': shiftkey = true; ctrkey = false; keyval = 72; break;
                    case 'I': shiftkey = true; ctrkey = false; keyval = 73; break;
                    case 'J': shiftkey = true; ctrkey = false; keyval = 74; break;
                    case 'K': shiftkey = true; ctrkey = false; keyval = 75; break;
                    case 'L': shiftkey = true; ctrkey = false; keyval = 76; break;
                    case 'M': shiftkey = true; ctrkey = false; keyval = 77; break;
                    case 'N': shiftkey = true; ctrkey = false; keyval = 78; break;
                    case 'O': shiftkey = true; ctrkey = false; keyval = 79; break;
                    case 'P': shiftkey = true; ctrkey = false; keyval = 80; break;
                    case 'Q': shiftkey = true; ctrkey = false; keyval = 81; break;
                    case 'R': shiftkey = true; ctrkey = false; keyval = 82; break;
                    case 'S': shiftkey = true; ctrkey = false; keyval = 83; break;
                    case 'T': shiftkey = true; ctrkey = false; keyval = 84; break;
                    case 'U': shiftkey = true; ctrkey = false; keyval = 85; break;
                    case 'V': shiftkey = true; ctrkey = false; keyval = 86; break;
                    case 'W': shiftkey = true; ctrkey = false; keyval = 87; break;
                    case 'X': shiftkey = true; ctrkey = false; keyval = 88; break;
                    case 'Y': shiftkey = true; ctrkey = false; keyval = 89; break;
                    case 'Z': shiftkey = true; ctrkey = false; keyval = 90; break;
                    case 'a': shiftkey = false; ctrkey = false; keyval = 65; break;
                    case 'b': shiftkey = false; ctrkey = false; keyval = 66; break;
                    case 'c': shiftkey = false; ctrkey = false; keyval = 67; break;
                    case 'd': shiftkey = false; ctrkey = false; keyval = 68; break;
                    case 'e': shiftkey = false; ctrkey = false; keyval = 69; break;
                    case 'f': shiftkey = false; ctrkey = false; keyval = 70; break;
                    case 'g': shiftkey = false; ctrkey = false; keyval = 71; break;
                    case 'h': shiftkey = false; ctrkey = false; keyval = 72; break;
                    case 'i': shiftkey = false; ctrkey = false; keyval = 73; break;
                    case 'j': shiftkey = false; ctrkey = false; keyval = 74; break;
                    case 'k': shiftkey = false; ctrkey = false; keyval = 75; break;
                    case 'l': shiftkey = false; ctrkey = false; keyval = 76; break;
                    case 'm': shiftkey = false; ctrkey = false; keyval = 77; break;
                    case 'n': shiftkey = false; ctrkey = false; keyval = 78; break;
                    case 'o': shiftkey = false; ctrkey = false; keyval = 79; break;
                    case 'p': shiftkey = false; ctrkey = false; keyval = 80; break;
                    case 'q': shiftkey = false; ctrkey = false; keyval = 81; break;
                    case 'r': shiftkey = false; ctrkey = false; keyval = 82; break;
                    case 's': shiftkey = false; ctrkey = false; keyval = 83; break;
                    case 't': shiftkey = false; ctrkey = false; keyval = 84; break;
                    case 'u': shiftkey = false; ctrkey = false; keyval = 85; break;
                    case 'v': shiftkey = false; ctrkey = false; keyval = 86; break;
                    case 'w': shiftkey = false; ctrkey = false; keyval = 87; break;
                    case 'x': shiftkey = false; ctrkey = false; keyval = 88; break;
                    case 'y': shiftkey = false; ctrkey = false; keyval = 89; break;
                    case 'z': shiftkey = false; ctrkey = false; keyval = 90; break;
                    case '0': shiftkey = false; ctrkey = false; keyval = 48; break;
                    case '1': shiftkey = false; ctrkey = false; keyval = 49; break;
                    case '2': shiftkey = false; ctrkey = false; keyval = 50; break;
                    case '3': shiftkey = false; ctrkey = false; keyval = 51; break;
                    case '4': shiftkey = false; ctrkey = false; keyval = 52; break;
                    case '5': shiftkey = false; ctrkey = false; keyval = 53; break;
                    case '6': shiftkey = false; ctrkey = false; keyval = 54; break;
                    case '7': shiftkey = false; ctrkey = false; keyval = 55; break;
                    case '8': shiftkey = false; ctrkey = false; keyval = 56; break;
                    case '9': shiftkey = false; ctrkey = false; keyval = 57; break;
                    case ')': shiftkey = true; ctrkey = false; keyval = 48; break;
                    case '!': shiftkey = true; ctrkey = false; keyval = 49; break;
                    case '@': shiftkey = true; ctrkey = false; keyval = 50; break;
                    case '#': shiftkey = true; ctrkey = false; keyval = 51; break;
                    case '$': shiftkey = true; ctrkey = false; keyval = 52; break;
                    case '%': shiftkey = true; ctrkey = false; keyval = 53; break;
                    case '^': shiftkey = true; ctrkey = false; keyval = 54; break;
                    case '&': shiftkey = true; ctrkey = false; keyval = 55; break;
                    case '*': shiftkey = true; ctrkey = false; keyval = 56; break;
                    case '(': shiftkey = true; ctrkey = false; keyval = 57; break;
                    case ' ': shiftkey = false; ctrkey = false; keyval = 32; break;
                    case '\'': shiftkey = false; ctrkey = false; keyval = 222; break;
                    case '"': shiftkey = true; ctrkey = false; keyval = 222; break;
                    case '<': shiftkey = true; ctrkey = false; keyval = 0xBC; break;
                    case '>': shiftkey = true; ctrkey = false; keyval = 0xBE; break;
                    case '.': shiftkey = false; ctrkey = false; keyval = 0xBE; break;
                    case ',': shiftkey = false; ctrkey = false; keyval = 188; break; //0xBC
                    case '=': shiftkey = false; ctrkey = false; keyval = 187; break;
                    case ':': shiftkey = true; ctrkey = false; keyval = 186; break;
                    case '\\': shiftkey = false; ctrkey = true; keyval = 220; break;
                    case '+': shiftkey = false; ctrkey = true; keyval = 107; break;
                    case '-': shiftkey = false; ctrkey = false; keyval = 189; break;
                    case '_': shiftkey = true; ctrkey = false; keyval = 189; break;
                    default:                        
                        break;
                }
             
                if (shiftkey == true)
                {                    
                    keybd_event(VK_SHIFT, 170, 0, 0);
                    keybd_event(keyval, 0, 0, 0);
                    keybd_event(keyval, 0, KEYEVENTF_KEYUP, 0);
                    keybd_event(VK_SHIFT, 170, KEYEVENTF_KEYUP, 0);
                    Thread.Sleep(10);
                }

                if (shiftkey == false)
                {
                    System.Console.WriteLine("Shift false" + keyval);                    
                    keybd_event(keyval, 0, KEYEVENTF_EXTENDEDKEY, 0);
                    keybd_event(keyval, 0, KEYEVENTF_KEYUP, 0);
                    Thread.Sleep(10);

                }

            }
        }
        public string[] spret { get; set; }        
    }
}
