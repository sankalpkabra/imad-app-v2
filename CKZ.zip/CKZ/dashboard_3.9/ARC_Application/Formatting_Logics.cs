﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;
using System.Data.OleDb;
using System.Globalization;
using System.Diagnostics;
using System.Collections;
using System.Configuration;
using Excel = Microsoft.Office.Interop.Excel;
using System.Reflection;
using Microsoft.Office.Interop.Excel;
using System.Text.RegularExpressions;
using System.Net;
using Ionic.Zip;


namespace ARC_Application
{
    class Formatting_Logics
    {

        static string Main_DIR_SharePath = ConfigurationManager.ConnectionStrings["Share_Path"].ToString();

        Excel.Application excel;
        Excel.Workbook excelworkBook;
        string Directory_Temp = Main_DIR_SharePath + '\\' + DateTime.Now.ToString("dd-MMM-yyyy") + "_Files\\Dashboard_Report\\";

        //**********Formatting_Singapore_Sec_Logic_Codes************************//
        public System.Data.DataTable GetTable_RPRDRO1C(string fileName, int a1)
        {
            try
            {
                string FileNam = Path.GetFileName(fileName);
                System.Data.DataTable dt = new System.Data.DataTable();
                System.Data.DataTable dt1 = new System.Data.DataTable();
                dt1.Columns.Add("Temp");

                dt1.Columns.Add("AACODE");
                dt1.Columns.Add("CUR");
                dt.Columns.Add("AACODE");
                dt.Columns.Add("CURRENCY CODE");
                dt.Columns.Add("TRANS AMOUNT");
                dt.Columns.Add("LOCAL EQUIVALENT");
                dt.Columns.Add("DESCRIPTION1");
                dt.Columns.Add("BRANCH");
                dt.Columns.Add("PURCHASE/SALE");
                string textLine = "";

                if (File.Exists(fileName))
                {
                    StreamReader objReader;
                    objReader = new StreamReader(fileName);

                    int counter = 0;
                    int curcounter = 0;
                    int linectr = 0;
                    int curctr = 0;
                    int st = 0;
                    string line = "";
                    string curline = "";
                    string line1 = "";
                    string tracker = "";
                    string cur = "";

                    do
                    {
                        textLine = objReader.ReadLine();

                        if (textLine.Contains(": CS") || textLine.Contains(": J2"))
                        {
                            if (textLine.Contains(": CS"))
                            {
                                cur = "CS";
                            }
                            else
                            {
                                cur = "J2";
                            }
                            curctr = curcounter - 1;
                            linectr = counter + 5;

                            curline = File.ReadLines(fileName).Skip(curctr).Take(1).First();
                            line1 = curline.Substring(curline.Length - 3, 3);

                            for (int i = 0; i <= 500; i++)
                            {
                                line = File.ReadLines(fileName).Skip(linectr).Take(1).First();
                                // string[] val = System.Text.RegularExpressions.Regex.Split(line.ToString(), @"\s{2,}");
                                if (line.Contains("DR"))
                                {
                                    string[] val = System.Text.RegularExpressions.Regex.Split(line.ToString(), @"\s{2,}");
                                    if (line.Contains("REPORT NO. : RPRDRO1C") || line.Contains("SUB TOTAL :                                       DR"))
                                    {
                                        tracker = tracker + Convert.ToString(st) + "," + line1 + cur + "?";
                                        break;
                                    }
                                    else
                                    {
                                        dt1.Rows.Add(line);

                                        dt1.Rows[i][1] = line1;
                                        line = "";

                                        st = st + 1;
                                        linectr = linectr + 1;
                                    }


                                }
                                else
                                {
                                    dt1.Rows.Add(line);

                                    dt1.Rows[i][1] = line1;
                                    line = "";

                                    st = st + 1;
                                    linectr = linectr + 1;
                                }
                            }
                        }

                        curcounter++;
                        counter++;

                    } while (objReader.Peek() != -1);

                    string[] curlist = tracker.Split('?');
                    int a = 0;
                    System.Data.DataTable data = new System.Data.DataTable();
                    data.Columns.Add("AACODE");
                    data.Columns.Add("CUR");
                    for (int i = 0; i <= curlist.Length - 2; i++)
                    {

                        try
                        {

                            string[] cnt = curlist[i].Split(',');
                            for (int j = a; j <= Convert.ToInt32(cnt[0]) - 1; j++)
                            {
                                data.Rows.Add();
                                data.Rows[j][0] = cnt[1].Substring(cnt[1].Length - 2, 2).Trim();
                                data.Rows[j][1] = cnt[1].Substring(cnt[1].Length - 5, 3).Trim();
                                a = a + 1;
                            }

                        }
                        catch
                        {
                            //throw ex;
                        }
                    }
                    for (int i = 0; i <= dt1.Rows.Count - 1; i++)
                    {
                        string[] val = System.Text.RegularExpressions.Regex.Split(dt1.Rows[i][0].ToString(), @"\s{2,}");

                        string str = val[6].ToString().Substring(6, val[6].Length - 6);

                        dt.Rows.Add();
                        dt.Rows[i][0] = data.Rows[i][0];
                        dt.Rows[i][1] = data.Rows[i][1];
                        string s1 = "";
                        string s2 = "";
                        s1 = val[4].ToString().Remove(val[4].Length - 1);
                        s2 = val[5].ToString().Remove(val[5].Length - 1);
                        if (val[4].ToString().Substring(val[4].Length - 1, 1) == "-")
                        {
                            dt.Rows[i][2] = "-" + s1;
                            dt.Rows[i][3] = "-" + s2;
                        }
                        else
                        {
                            dt.Rows[i][2] = val[4].ToString();
                            dt.Rows[i][3] = val[5].ToString();
                        }
                        if (dt.Rows[i][3].ToString() == "0.00")
                        {
                            dt.Rows[i][4] = val[6].ToString();
                        }
                        else
                        {
                            dt.Rows[i][4] = str.Trim();
                        }

                        if (FileNam == "RPRDRO1C-IN.txt")
                        {
                            dt.Rows[i][5] = "Branch-O1";
                        }
                        else
                        {
                            dt.Rows[i][5] = "Sub-O1";
                        }
                        if (val[4].Contains('-'))
                        {
                            dt.Rows[i][6] = "Sale";
                        }
                        else
                        {
                            dt.Rows[i][6] = "Purchase";
                        }

                    }


                }
                return dt;
            }
            catch
            {
                return null;
            }
        }

        public void GetFileNameVietnam_detail(string s, out string path1, out string path2, out string path3)
        {
            string[] files1 = Directory.GetFiles(s);

            path1 = "";
            path2 = "";
            path3 = "";

            for (int i = 0; i < files1.Length; i++)
            {

                if (files1[i].Contains("DETAIL") && files1[i].Contains(DateTime.Today.AddDays(-1).ToString("ddMM")))
                {
                    path1 = files1[i];
                }
                else if (files1[i].Contains("DETAIL") && files1[i].Contains(DateTime.Today.AddDays(-2).ToString("ddMM")))
                {
                    path2 = files1[i];
                }
                else if (files1[i].Contains("DETAIL") && files1[i].Contains(DateTime.Today.AddDays(-3).ToString("ddMM")))
                {
                    path3 = files1[i];
                }

            }

        }

        public void GetFileNameVietnam_SVNDTAQ(string s, out string path1, out string path2, out string path3)
        {
            string[] files1 = Directory.GetFiles(s);

            path1 = "";
            path2 = "";
            path3 = "";

            for (int i = 0; i < files1.Length; i++)
            {

                if (files1[i].Contains("SVNDTAQ") && files1[i].Contains(DateTime.Today.AddDays(-1).ToString("ddMM")))
                {
                    path1 = files1[i];
                }
                else if (files1[i].Contains("SVNDTAQ") && files1[i].Contains(DateTime.Today.AddDays(-2).ToString("ddMM")))
                {
                    path2 = files1[i];
                }
                else if (files1[i].Contains("SVNDTAQ") && files1[i].Contains(DateTime.Today.AddDays(-3).ToString("ddMM")))
                {
                    path3 = files1[i];
                }

            }

        }

        public void GetFileNameVietnam_IBANKING(string s, out string path1, out string path2, out string path3)
        {
            string[] files1 = Directory.GetFiles(s);

            path1 = "";
            path2 = "";
            path3 = "";

            for (int i = 0; i < files1.Length; i++)
            {

                if (files1[i].Contains("IBANKING") && files1[i].Contains(DateTime.Today.AddDays(-1).ToString("ddMM")))
                {
                    path1 = files1[i];
                }
                else if (files1[i].Contains("IBANKING") && files1[i].Contains(DateTime.Today.AddDays(-2).ToString("ddMM")))
                {
                    path2 = files1[i];
                }
                else if (files1[i].Contains("IBANKING") && files1[i].Contains(DateTime.Today.AddDays(-3).ToString("ddMM")))
                {
                    path3 = files1[i];
                }

            }

        }

        public void GetFileNameVietnam_Purchase(string s, out string path1, out string path2, out string path3)
        {
            string[] files1 = Directory.GetFiles(s);

            path1 = "";
            path2 = "";
            path3 = "";

            for (int i = 0; i < files1.Length; i++)
            {

                if (files1[i].Contains("Purchase") && files1[i].Contains(DateTime.Today.AddDays(-1).ToString("MMdd")))
                {
                    path1 = files1[i];
                }
                else if (files1[i].Contains("Purchase") && files1[i].Contains(DateTime.Today.AddDays(-2).ToString("MMdd")))
                {
                    path2 = files1[i];
                }
                else if (files1[i].Contains("Purchase") && files1[i].Contains(DateTime.Today.AddDays(-3).ToString("MMdd")))
                {
                    path3 = files1[i];
                }

            }

        }

        public void GetFileNameVietnam_VisaACQ(string s, out string path1, out string path2, out string path3)
        {
            string[] files1 = Directory.GetFiles(s);

            path1 = "";
            path2 = "";
            path3 = "";

            for (int i = 0; i < files1.Length; i++)
            {

                if (files1[i].Contains("VISA ACQUIRER") && files1[i].Contains(DateTime.Today.AddDays(-1).ToString("yyyyMMdd")))
                {
                    path1 = files1[i];
                }
                else if (files1[i].Contains("VISA ACQUIRER") && files1[i].Contains(DateTime.Today.AddDays(-2).ToString("yyyyMMdd")))
                {
                    path2 = files1[i];
                }
                else if (files1[i].Contains("VISA ACQUIRER") && files1[i].Contains(DateTime.Today.AddDays(-3).ToString("yyyyMMdd")))
                {
                    path3 = files1[i];
                }

            }

        }

        public void GetFileNameVietnam_inc_scvn(string s, out string path1, out string path2, out string path3)
        {
            string[] files1 = Directory.GetFiles(s);

            path1 = "";
            path2 = "";
            path3 = "";

            for (int i = 0; i < files1.Length; i++)
            {

                if (files1[i].Contains("inc_scvn") && files1[i].Contains(DateTime.Today.AddDays(-1).ToString("yyyyMMdd")))
                {
                    path1 = files1[i];
                }
                else if (files1[i].Contains("inc_scvn") && files1[i].Contains(DateTime.Today.AddDays(-2).ToString("yyyyMMdd")))
                {
                    path2 = files1[i];
                }
                else if (files1[i].Contains("inc_scvn") && files1[i].Contains(DateTime.Today.AddDays(-3).ToString("yyyyMMdd")))
                {
                    path3 = files1[i];
                }

            }

        }

        public System.Data.DataTable GetTable_OPXR029(string filePath, int a1)
        {
            try
            {
                string SubBranch = (a1 == 2 ? "SUB" : "Branch-OPX");
                System.Data.DataTable dtexcel1 = new System.Data.DataTable();
                System.Data.DataTable dtfinal1 = new System.Data.DataTable();
                string strConn1;
                bool hasHeaders1 = true;
                string HDR1 = hasHeaders1 ? "Yes" : "No";

                if (filePath.Substring(filePath.LastIndexOf('.')).ToLower() == ".xlsx")
                    strConn1 = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + filePath + ";Extended Properties='Excel 8.0;HDR=YES'";
                else
                    strConn1 = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + filePath + ";Extended Properties=\"Excel 8.0;HDR=" + HDR1 + ";IMEX=1\"";
                OleDbConnection conn1 = new OleDbConnection(strConn1);
                conn1.Open();
                System.Data.DataTable schemaTable1 = conn1.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, new object[] { null, null, null, "TABLE" });

                DataRow schemaRow = schemaTable1.Rows[0];
                string sheet1 = schemaRow["TABLE_NAME"].ToString();

                OleDbDataAdapter daexcel1 = null;
                if (!sheet1.EndsWith("_"))
                {
                    string query = "SELECT  * FROM [" + sheet1 + "]";
                    daexcel1 = new OleDbDataAdapter(query, conn1);
                    dtexcel1.Locale = CultureInfo.CurrentCulture;
                    daexcel1.Fill(dtexcel1);
                }
                conn1.Close();

                if (dtexcel1.Rows.Count > 0)
                {
                    dtfinal1.Columns.Add("AACODE");
                    dtfinal1.Columns.Add("CURRENCY CODE");
                    dtfinal1.Columns.Add("TRANS AMOUNT");
                    dtfinal1.Columns.Add("LOCAL EQUIVALENT");
                    dtfinal1.Columns.Add("DESCRIPTION1");
                    dtfinal1.Columns.Add("BRANCH");
                    dtfinal1.Columns.Add("PURCHASE/SALE");

                    var _Code = "";
                    int k = -1;

                    for (int i = 0; i <= dtexcel1.Rows.Count - 1; i++)
                    {
                        if (dtexcel1.Rows[i][1].ToString() != null && (dtexcel1.Rows[i][1].ToString().Contains("CS") || dtexcel1.Rows[i][1].ToString().Contains("J2")))
                        {
                            if (dtexcel1.Rows[i][1].ToString() == "CS")
                                _Code = "CS";
                            else if (dtexcel1.Rows[i][1].ToString() == "J2")
                                _Code = "J2";

                            System.Data.DataTable dt = new System.Data.DataTable();
                            dt.Columns.Add("AA Code");
                            dt.Columns.Add("Currency");
                            dt.Columns.Add("Transaction Amount");
                            dt.Columns.Add("Local Equaliant");
                            dt.Columns.Add("Description1");
                            dt.Columns.Add("Mention the (branch or sub file)");
                            dt.Columns.Add("Purchase/Sale");

                            for (int j = i + 1; j <= dtexcel1.Rows.Count - 1; j++)
                            {
                                bool ispur = false;
                                bool issal = false;

                                var _purCur = dtexcel1.Rows[j][4] != null ? dtexcel1.Rows[j][4].ToString() : string.Empty;//Pur Currency
                                var _purAmt = dtexcel1.Rows[j][5] != null ? dtexcel1.Rows[j][5].ToString() : string.Empty;//Pur Amount
                                var _purBaseAmt = dtexcel1.Rows[j][6] != null ? dtexcel1.Rows[j][6].ToString() : string.Empty;//Pur Base Amount
                                var _salCur = dtexcel1.Rows[j][8] != null ? dtexcel1.Rows[j][8].ToString() : string.Empty;//Sale Currency
                                var _salAmt = dtexcel1.Rows[j][9] != null ? dtexcel1.Rows[j][9].ToString() : string.Empty;//Sale Amount
                                var _salBaseAmt = dtexcel1.Rows[j][10] != null ? dtexcel1.Rows[j][10].ToString() : string.Empty;//Sale Base Amount

                                if (!string.IsNullOrWhiteSpace(_purCur) && !string.IsNullOrWhiteSpace(_purAmt) && !string.IsNullOrWhiteSpace(_purBaseAmt))
                                {
                                    ispur = true;
                                }

                                if (!string.IsNullOrWhiteSpace(_salCur) && !string.IsNullOrWhiteSpace(_salAmt) && !string.IsNullOrWhiteSpace(_salBaseAmt))
                                {
                                    issal = true;
                                }

                                if (ispur && issal)
                                {
                                    dt.Rows.Add();
                                    k = k + 1;
                                    //Purchase
                                    dt.Rows[k][0] = _Code;//AA Codes
                                    dt.Rows[k][4] = dtexcel1.Rows[j][1];//Deal No.
                                    dt.Rows[k][1] = _purCur;
                                    dt.Rows[k][2] = _purAmt;
                                    dt.Rows[k][3] = _purBaseAmt;
                                    dt.Rows[k][5] = SubBranch;
                                    dt.Rows[k][6] = "Purchase";

                                    dt.Rows.Add();
                                    k = k + 1;
                                    //Sale
                                    dt.Rows[k][0] = _Code;//AA Codes
                                    dt.Rows[k][4] = dtexcel1.Rows[j][1];//Deal No.
                                    dt.Rows[k][1] = _salCur;
                                    dt.Rows[k][2] = _salAmt;
                                    dt.Rows[k][3] = _salBaseAmt;
                                    dt.Rows[k][5] = SubBranch;
                                    dt.Rows[k][6] = "Sale";
                                }
                                else if (ispur)
                                {
                                    dt.Rows.Add();
                                    k = k + 1;

                                    dt.Rows[k][0] = _Code;//AA Codes
                                    dt.Rows[k][4] = dtexcel1.Rows[j][1];//Deal No.
                                    dt.Rows[k][1] = _purCur;
                                    dt.Rows[k][2] = _purAmt;
                                    dt.Rows[k][3] = _purBaseAmt;
                                    dt.Rows[k][5] = SubBranch;
                                    dt.Rows[k][6] = "Purchase";
                                }
                                else if (issal)
                                {
                                    dt.Rows.Add();
                                    k = k + 1;

                                    dt.Rows[k][0] = _Code;//AA Codes
                                    dt.Rows[k][4] = dtexcel1.Rows[j][1];//Deal No.
                                    dt.Rows[k][1] = _salCur;
                                    dt.Rows[k][2] = _salAmt;
                                    dt.Rows[k][3] = _salBaseAmt;
                                    dt.Rows[k][5] = SubBranch;
                                    dt.Rows[k][6] = "Sale";
                                }

                                if (j == dtexcel1.Rows.Count - 1 || (dtexcel1.Rows[j + 1][0] != null && dtexcel1.Rows[j + 1][0].ToString().Contains("AA Code")))
                                {
                                    DataView dv = new DataView(dt);
                                    dv.Sort = "Purchase/Sale ASC";
                                    dt = dv.ToTable();
                                    foreach (DataRow dr in dt.Rows)
                                    {
                                        dtfinal1.Rows.Add(dr.ItemArray);
                                    }

                                    i = j - 1;
                                    k = -1;
                                    break;
                                }

                            }
                        }

                    }
                }
                else
                {
                }

                return dtfinal1;
            }
            catch
            {
                return null;
            }
        }

        public System.Data.DataTable GetTable_RDR001DS(string fileName, int a1)
        {
            try
            {
                System.Data.DataTable dt = new System.Data.DataTable();
                System.Data.DataTable dt1 = new System.Data.DataTable();
                dt1.Columns.Add("Temp");

                dt1.Columns.Add("AACODE");
                dt1.Columns.Add("CUR");
                dt.Columns.Add("AACODE");
                dt.Columns.Add("CURRENCY CODE");
                dt.Columns.Add("TRANS AMOUNT");
                dt.Columns.Add("LOCAL EQUIVALENT");
                dt.Columns.Add("DESCRIPTION1");
                dt.Columns.Add("BRANCH");
                dt.Columns.Add("PURCHASE/SALE");
                string textLine = "";

                if (File.Exists(fileName))
                {
                    StreamReader objReader;
                    objReader = new StreamReader(fileName);

                    int counter = 0;
                    int curcounter = 0;
                    int linectr = 0;
                    int curctr = 0;
                    int st = 0;
                    string line = "";
                    string curline = "";
                    string line1 = "";
                    string tracker = "";
                    string cur = "";


                    do
                    {
                        textLine = objReader.ReadLine();

                        if (textLine.Contains(": CS") || textLine.Contains(": J2"))
                        {
                            if (textLine.Contains(": CS"))
                            {
                                cur = "CS";

                            }
                            else
                            {
                                cur = "J2";
                            }
                            for (int i = 0; i <= 30; i++)
                            {
                                curctr = curcounter;
                                linectr = counter + 2;
                                curline = File.ReadLines(fileName).Skip(curctr).Take(1).First();
                                if (curline.Contains("CURRENCY :"))
                                {
                                    line1 = curline.Substring(curline.Length - 3, 3);
                                    for (int k = 0; k <= 80; k++)
                                    {
                                        line = File.ReadLines(fileName).Skip(linectr).Take(1).First();
                                        if (line.Contains("TOTALS :"))
                                        {
                                            tracker = tracker + Convert.ToString(st) + "," + line1 + cur + "?";
                                            break;

                                        }
                                        else
                                        {
                                            dt1.Rows.Add(line);

                                            dt1.Rows[k][1] = line1;
                                            line = "";

                                            st = st + 1;
                                            linectr = linectr + 1;
                                        }
                                    }
                                }
                                curcounter++;
                                counter++;
                            }
                        }
                        curcounter++;
                        counter++;

                    } while (objReader.Peek() != -1);

                    string[] curlist = tracker.Split('?');
                    int a = 0;
                    System.Data.DataTable data = new System.Data.DataTable();
                    data.Columns.Add("AACODE");
                    data.Columns.Add("CUR");
                    for (int i = 0; i <= curlist.Length - 2; i++)
                    {
                        string[] cnt = curlist[i].Split(',');
                        //a = 0;
                        for (int j = a; j <= Convert.ToInt32(cnt[0]) - 1; j++)
                        {
                            data.Rows.Add();
                            data.Rows[j][0] = cnt[1].Substring(cnt[1].Length - 2, 2).Trim();
                            data.Rows[j][1] = cnt[1].Substring(cnt[1].Length - 5, 3).Trim();
                            a = a + 1;
                        }


                    }
                    for (int i = 0; i <= dt1.Rows.Count - 1; i++)
                    {
                        string[] val = System.Text.RegularExpressions.Regex.Split(dt1.Rows[i][0].ToString(), @"\s{2,}");

                        string[] valu = System.Text.RegularExpressions.Regex.Split(val[8].ToString(), @"\s{1,}");
                        //int Rstval = Rstval.Substring(0, valu);
                        dt.Rows.Add();
                        dt.Rows[i][0] = data.Rows[i][0];
                        dt.Rows[i][1] = data.Rows[i][1];
                        dt.Rows[i][2] = valu[0];
                        dt.Rows[i][3] = val[9];
                        dt.Rows[i][4] = val[1];
                        if (a1 == 4)
                        {
                            dt.Rows[i][5] = "Branch-RDS";
                        }
                        else
                        {
                            dt.Rows[i][5] = "Sub-RDS";
                        }
                        if (val[8].Contains('S'))
                        {
                            dt.Rows[i][6] = "Sale";
                        }
                        else
                        {
                            dt.Rows[i][6] = "Purchase";
                        }

                    }
                }
                return dt;
            }
            catch
            {
                return null;
            }
        }

        public string ExportToExcel(System.Data.DataTable tbl, ref string excelFilePath, string Recon_Name, string Output_Path, string Share_Path, int Flag)
        {
            string strDirectory = Share_Path;
            excelFilePath = strDirectory + @"Files_For_Formatting_Or_Non_Formatting\" + Recon_Name + @"\Formatting\Final_Output.xls";
            try
            {
                if (tbl == null || tbl.Columns.Count == 0)
                    return null;//throw new Exception("ExportToExcel: Null or empty input table!\n");

                // load excel, and create a new workbook
                var excelApp = new Microsoft.Office.Interop.Excel.Application();

                Microsoft.Office.Interop.Excel.Workbook workBook = null;
                workBook = excelApp.Workbooks.Add(Type.Missing);                // single worksheet
                Microsoft.Office.Interop.Excel._Worksheet workSheet = (Microsoft.Office.Interop.Excel.Worksheet)workBook.Worksheets.Add(Type.Missing);
                excelApp.DisplayAlerts = false;
                excelApp.Visible = false;
                for (var i = 0; i < tbl.Columns.Count; i++)
                {
                    workSheet.Cells[1, i + 1] = tbl.Columns[i].ColumnName;
                }

                // rows
                for (var i = 0; i < tbl.Rows.Count; i++)
                {
                    // to do: format datetime values before printing
                    for (var j = 0; j < tbl.Columns.Count; j++)
                    {
                        workSheet.Cells[i + 2, j + 1] = tbl.Rows[i][j];
                    }
                }
                try
                {
                    Excel.Range usedrange = workSheet.UsedRange;
                    Excel.Range r = usedrange.get_Range("A1", Type.Missing);
                    r.EntireRow.Font.Bold = true;
                    Microsoft.Office.Interop.Excel.Borders border = usedrange.Borders;
                    border.LineStyle = Microsoft.Office.Interop.Excel.XlLineStyle.xlContinuous;
                    border.Weight = 2d;
                    workSheet.Columns.EntireColumn.AutoFit();
                    if (!File.Exists(Output_Path + "Final_Output.xlsx"))
                        workBook.SaveCopyAs(Output_Path + "Final_Output.xlsx");
                    //workBook.SaveCopyAs(@"\\10.132.5.214\TempFiles\SAHIL\UAT_Runtimes\ARCRuntime\22-Mar-2017_Files\Output\Singapore SEC RPR\Final_Output_2.xlsx");
                    else
                        workBook.SaveCopyAs(Output_Path + "Final_Output_2.xlsx");
                    //File.Copy(excelFilePath, (Output_Path + "Final_Output.xls"));
                    excelApp.Quit();
                    //MessageBox.Show("Excel file saved!");
                }
                catch
                {
                    //throw new Exception("ExportToExcel: Excel file could not be saved! Check filepath.\n" + ex.Message);
                }
                ReleaseComObject(workSheet);
                ReleaseComObject(workBook);
                ReleaseComObject(excelApp);
            }
            catch (Exception ex)
            {
                MessageBox.Show("ExportToExcel: \n" + ex.Message);
            }
            return excelFilePath;
        }
        //**********************************************************************//


        //****************Formatting_HongKong_LPU_RPR__Logic_Codes*****************//
        public System.Data.DataTable GetTable_RDR001DS_HK(string fileName, int a1)
        {
            try
            {
                System.Data.DataTable dt = new System.Data.DataTable();
                System.Data.DataTable dt1 = new System.Data.DataTable();
                dt1.Columns.Add("Temp");

                dt1.Columns.Add("AACODE");
                dt1.Columns.Add("CUR");
                dt.Columns.Add("AACODE");
                dt.Columns.Add("CURRENCY CODE");
                dt.Columns.Add("TRANS AMOUNT");
                dt.Columns.Add("LOCAL EQUIVALENT");
                dt.Columns.Add("DESCRIPTION1");
                dt.Columns.Add("BRANCH");
                dt.Columns.Add("PURCHASE/SALE");
                string textLine = "";

                if (File.Exists(fileName))
                {
                    StreamReader objReader;
                    objReader = new StreamReader(fileName);

                    int counter = 0;
                    int curcounter = 0;
                    int linectr = 0;
                    int curctr = 0;
                    int st = 0;
                    string line = "";
                    string curline = "";
                    string line1 = "";
                    string tracker = "";
                    string cur = "";


                    do
                    {
                        textLine = objReader.ReadLine();

                        if (textLine.Contains(": AA"))
                        {
                            if (textLine.Contains(": AA"))
                            {
                                cur = "AA";

                            }
                            //else
                            //{
                            //    cur = "J2";
                            //}
                            for (int i = 0; i <= 30; i++)
                            {
                                curctr = curcounter;
                                linectr = counter + 2;
                                curline = File.ReadLines(fileName).Skip(curctr).Take(1).First();
                                if (curline.Contains("CURRENCY :"))
                                {
                                    line1 = curline.Substring(curline.Length - 3, 3);
                                    for (int k = 0; k <= 80; k++)
                                    {
                                        line = File.ReadLines(fileName).Skip(linectr).Take(1).First();
                                        if (line.Contains("TOTALS :"))
                                        {
                                            tracker = tracker + Convert.ToString(st) + "," + line1 + cur + "?";
                                            break;

                                        }
                                        else
                                        {
                                            dt1.Rows.Add(line);

                                            dt1.Rows[k][1] = line1;
                                            line = "";

                                            st = st + 1;
                                            linectr = linectr + 1;
                                        }
                                    }
                                }
                                curcounter++;
                                counter++;
                            }
                        }
                        curcounter++;
                        counter++;

                    } while (objReader.Peek() != -1);

                    string[] curlist = tracker.Split('?');
                    int a = 0;
                    System.Data.DataTable data = new System.Data.DataTable();
                    data.Columns.Add("AACODE");
                    data.Columns.Add("CUR");
                    for (int i = 0; i <= curlist.Length - 2; i++)
                    {
                        string[] cnt = curlist[i].Split(',');
                        //a = 0;
                        for (int j = a; j <= Convert.ToInt32(cnt[0]) - 1; j++)
                        {
                            data.Rows.Add();
                            data.Rows[j][0] = cnt[1].Substring(cnt[1].Length - 2, 2).Trim();
                            data.Rows[j][1] = cnt[1].Substring(cnt[1].Length - 5, 3).Trim();
                            a = a + 1;
                        }


                    }
                    for (int i = 0; i <= dt1.Rows.Count - 1; i++)
                    {
                        string[] val = System.Text.RegularExpressions.Regex.Split(dt1.Rows[i][0].ToString(), @"\s{2,}");

                        string[] vals = System.Text.RegularExpressions.Regex.Split(dt1.Rows[i][0].ToString(), @"\s{1,}");
                        string[] valu = System.Text.RegularExpressions.Regex.Split(val[8].ToString(), @"\s{1,}");
                        //int Rstval = Rstval.Substring(0, valu);
                        dt.Rows.Add();
                        dt.Rows[i][0] = data.Rows[i][0];
                        dt.Rows[i][1] = data.Rows[i][1];
                        dt.Rows[i][2] = vals[11];
                        dt.Rows[i][3] = vals[13];
                        dt.Rows[i][4] = vals[1] + vals[2];
                        if (a1 == 4)
                        {
                            dt.Rows[i][5] = "Branch-RDS";
                        }
                        else
                        {
                            dt.Rows[i][5] = "Sub-RDS";
                        }
                        if (val[8].Contains('S'))
                        {
                            dt.Rows[i][6] = "Sale";
                        }
                        else
                        {
                            dt.Rows[i][6] = "Purchase";
                        }

                    }
                }
                return dt;
            }
            catch
            {
                return null;
            }
        }

        public System.Data.DataTable GetTable_OPXR029_HK(string filePath, int a1)
        {
            try
            {
                string SubBranch = (a1 == 2 ? "SUB" : "Branch-OPX");
                System.Data.DataTable dtexcel1 = new System.Data.DataTable();
                System.Data.DataTable dtfinal1 = new System.Data.DataTable();
                string strConn1;
                bool hasHeaders1 = true;
                string HDR1 = hasHeaders1 ? "Yes" : "No";

                if (filePath.Substring(filePath.LastIndexOf('.')).ToLower() == ".xlsx")
                    strConn1 = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + filePath + ";Extended Properties='Excel 8.0;HDR=YES'";
                else
                    strConn1 = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + filePath + ";Extended Properties=\"Excel 8.0;HDR=" + HDR1 + ";IMEX=1\"";
                OleDbConnection conn1 = new OleDbConnection(strConn1);
                conn1.Open();
                System.Data.DataTable schemaTable1 = conn1.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, new object[] { null, null, null, "TABLE" });

                DataRow schemaRow = schemaTable1.Rows[0];
                string sheet1 = schemaRow["TABLE_NAME"].ToString();

                OleDbDataAdapter daexcel1 = null;
                if (!sheet1.EndsWith("_"))
                {
                    string query = "SELECT  * FROM [" + sheet1 + "]";
                    daexcel1 = new OleDbDataAdapter(query, conn1);
                    dtexcel1.Locale = CultureInfo.CurrentCulture;
                    daexcel1.Fill(dtexcel1);
                }
                conn1.Close();

                if (dtexcel1.Rows.Count > 0)
                {
                    dtfinal1.Columns.Add("AACODE");
                    dtfinal1.Columns.Add("CURRENCY CODE");
                    dtfinal1.Columns.Add("TRANS AMOUNT");
                    dtfinal1.Columns.Add("LOCAL EQUIVALENT");
                    dtfinal1.Columns.Add("DESCRIPTION1");
                    dtfinal1.Columns.Add("BRANCH");
                    dtfinal1.Columns.Add("PURCHASE/SALE");

                    var _Code = "";
                    int k = -1;

                    for (int i = 0; i <= dtexcel1.Rows.Count - 1; i++)
                    {
                        if (dtexcel1.Rows[i][1].ToString() != null && dtexcel1.Rows[i][1].ToString().Contains("AA"))
                        {
                            if (dtexcel1.Rows[i][1].ToString() == "AA")
                                _Code = "AA";

                            System.Data.DataTable dt = new System.Data.DataTable();
                            dt.Columns.Add("AA Code");
                            dt.Columns.Add("Currency");
                            dt.Columns.Add("Transaction Amount");
                            dt.Columns.Add("Local Equaliant");
                            dt.Columns.Add("Description1");
                            dt.Columns.Add("Mention the (branch or sub file)");
                            dt.Columns.Add("Purchase/Sale");

                            for (int j = i + 1; j <= dtexcel1.Rows.Count - 1; j++)
                            {
                                bool ispur = false;
                                bool issal = false;

                                var _purCur = dtexcel1.Rows[j][4] != null ? dtexcel1.Rows[j][4].ToString() : string.Empty;//Pur Currency
                                var _purAmt = dtexcel1.Rows[j][5] != null ? dtexcel1.Rows[j][5].ToString() : string.Empty;//Pur Amount
                                var _purBaseAmt = dtexcel1.Rows[j][6] != null ? dtexcel1.Rows[j][6].ToString() : string.Empty;//Pur Base Amount
                                var _salCur = dtexcel1.Rows[j][8] != null ? dtexcel1.Rows[j][8].ToString() : string.Empty;//Sale Currency
                                var _salAmt = dtexcel1.Rows[j][9] != null ? dtexcel1.Rows[j][9].ToString() : string.Empty;//Sale Amount
                                var _salBaseAmt = dtexcel1.Rows[j][10] != null ? dtexcel1.Rows[j][10].ToString() : string.Empty;//Sale Base Amount

                                if (!string.IsNullOrWhiteSpace(_purCur) && !string.IsNullOrWhiteSpace(_purAmt) && !string.IsNullOrWhiteSpace(_purBaseAmt))
                                {
                                    ispur = true;
                                }

                                if (!string.IsNullOrWhiteSpace(_salCur) && !string.IsNullOrWhiteSpace(_salAmt) && !string.IsNullOrWhiteSpace(_salBaseAmt))
                                {
                                    issal = true;
                                }

                                if (ispur && issal)
                                {
                                    dt.Rows.Add();
                                    k = k + 1;
                                    //Purchase
                                    dt.Rows[k][0] = _Code;//AA Codes
                                    dt.Rows[k][4] = dtexcel1.Rows[j][1];//Deal No.
                                    dt.Rows[k][1] = _purCur;
                                    dt.Rows[k][2] = _purAmt;
                                    dt.Rows[k][3] = _purBaseAmt;
                                    dt.Rows[k][5] = SubBranch;
                                    dt.Rows[k][6] = "Purchase";

                                    dt.Rows.Add();
                                    k = k + 1;
                                    //Sale
                                    dt.Rows[k][0] = _Code;//AA Codes
                                    dt.Rows[k][4] = dtexcel1.Rows[j][1];//Deal No.
                                    dt.Rows[k][1] = _salCur;
                                    dt.Rows[k][2] = _salAmt;
                                    dt.Rows[k][3] = _salBaseAmt;
                                    dt.Rows[k][5] = SubBranch;
                                    dt.Rows[k][6] = "Sale";
                                }
                                else if (ispur)
                                {
                                    dt.Rows.Add();
                                    k = k + 1;

                                    dt.Rows[k][0] = _Code;//AA Codes
                                    dt.Rows[k][4] = dtexcel1.Rows[j][1];//Deal No.
                                    dt.Rows[k][1] = _purCur;
                                    dt.Rows[k][2] = _purAmt;
                                    dt.Rows[k][3] = _purBaseAmt;
                                    dt.Rows[k][5] = SubBranch;
                                    dt.Rows[k][6] = "Purchase";
                                }
                                else if (issal)
                                {
                                    dt.Rows.Add();
                                    k = k + 1;

                                    dt.Rows[k][0] = _Code;//AA Codes
                                    dt.Rows[k][4] = dtexcel1.Rows[j][1];//Deal No.
                                    dt.Rows[k][1] = _salCur;
                                    dt.Rows[k][2] = _salAmt;
                                    dt.Rows[k][3] = _salBaseAmt;
                                    dt.Rows[k][5] = SubBranch;
                                    dt.Rows[k][6] = "Sale";
                                }

                                if (j == dtexcel1.Rows.Count - 1 || (dtexcel1.Rows[j + 1][0] != null && dtexcel1.Rows[j + 1][0].ToString().Contains("AA Code")))
                                {
                                    DataView dv = new DataView(dt);
                                    dv.Sort = "Purchase/Sale ASC";
                                    dt = dv.ToTable();
                                    foreach (DataRow dr in dt.Rows)
                                    {
                                        dtfinal1.Rows.Add(dr.ItemArray);
                                    }

                                    i = j - 1;
                                    k = -1;
                                    break;
                                }

                            }
                        }

                    }
                }
                else
                {
                }

                return dtfinal1;
            }
            catch
            {
                return null;
            }
        }

        public System.Data.DataTable GetTable_RPRDRO1C_HK(string fileName, int a1)
        {
            try
            {
                string FileNam = Path.GetFileName(fileName);
                System.Data.DataTable dt = new System.Data.DataTable();
                System.Data.DataTable dt1 = new System.Data.DataTable();
                dt1.Columns.Add("Temp");

                dt1.Columns.Add("AACODE");
                dt1.Columns.Add("CUR");
                dt.Columns.Add("AACODE");
                dt.Columns.Add("CURRENCY CODE");
                dt.Columns.Add("TRANS AMOUNT");
                dt.Columns.Add("LOCAL EQUIVALENT");
                dt.Columns.Add("DESCRIPTION1");
                dt.Columns.Add("BRANCH");
                dt.Columns.Add("PURCHASE/SALE");
                string textLine = "";

                if (File.Exists(fileName))
                {
                    StreamReader objReader;
                    objReader = new StreamReader(fileName);

                    int counter = 0;
                    int curcounter = 0;
                    int linectr = 0;
                    int curctr = 0;
                    int st = 0;
                    string line = "";
                    string curline = "";
                    string line1 = "";
                    string tracker = "";
                    string cur = "";

                    do
                    {
                        textLine = objReader.ReadLine();

                        if (textLine.Contains(": AA"))
                        {
                            if (textLine.Contains(": AA"))
                            {
                                cur = "AA";
                            }
                            //else
                            //{
                            //    cur = "J2";
                            //}
                            curctr = curcounter - 1;
                            linectr = counter + 5;

                            curline = File.ReadLines(fileName).Skip(curctr).Take(1).First();
                            line1 = curline.Substring(curline.Length - 3, 3);

                            for (int i = 0; i <= 500; i++)
                            {
                                line = File.ReadLines(fileName).Skip(linectr).Take(1).First();
                                // string[] val = System.Text.RegularExpressions.Regex.Split(line.ToString(), @"\s{2,}");
                                if (line.Contains("DR"))
                                {
                                    string[] val = System.Text.RegularExpressions.Regex.Split(line.ToString(), @"\s{2,}");
                                    if (line.Contains("REPORT NO. : RPRDRO1C") || line.Contains("SUB TOTAL :                                       DR"))
                                    {
                                        tracker = tracker + Convert.ToString(st) + "," + line1 + cur + "?";
                                        break;
                                    }
                                    else
                                    {
                                        dt1.Rows.Add(line);

                                        dt1.Rows[i][1] = line1;
                                        line = "";

                                        st = st + 1;
                                        linectr = linectr + 1;
                                    }


                                }
                                else
                                {
                                    dt1.Rows.Add(line);

                                    dt1.Rows[i][1] = line1;
                                    line = "";

                                    st = st + 1;
                                    linectr = linectr + 1;
                                }
                            }
                        }

                        curcounter++;
                        counter++;

                    } while (objReader.Peek() != -1);

                    string[] curlist = tracker.Split('?');
                    int a = 0;
                    System.Data.DataTable data = new System.Data.DataTable();
                    data.Columns.Add("AACODE");
                    data.Columns.Add("CUR");
                    for (int i = 0; i <= curlist.Length - 2; i++)
                    {

                        try
                        {

                            string[] cnt = curlist[i].Split(',');
                            for (int j = a; j <= Convert.ToInt32(cnt[0]) - 1; j++)
                            {
                                data.Rows.Add();
                                data.Rows[j][0] = cnt[1].Substring(cnt[1].Length - 2, 2).Trim();
                                data.Rows[j][1] = cnt[1].Substring(cnt[1].Length - 5, 3).Trim();
                                a = a + 1;
                            }

                        }
                        catch
                        {
                            //throw ex;
                        }
                    }
                    for (int i = 0; i <= dt1.Rows.Count - 1; i++)
                    {
                        string[] val = System.Text.RegularExpressions.Regex.Split(dt1.Rows[i][0].ToString(), @"\s{2,}");

                        string name = "";
                        string source = "";
                        bool allCharactersInStringAreDigits = val[1].ToString().Any(char.IsDigit);
                        bool allCharactersInStringAreAlpha1 = false;
                        bool allCharactersInStringAreAlpha2 = false;
                        if (allCharactersInStringAreDigits == true)
                        {
                            name = val[1].ToString().Substring(0, val[1].ToString().Length - 3).Trim();
                            source = val[1].ToString().Substring(val[1].ToString().Length - 3, 3);
                        }
                        if (val.Length == 6)
                        {
                            allCharactersInStringAreAlpha1 = val[5].ToString().Any(char.IsLetter);
                        }
                        else if (val.Length == 7)
                        {
                            allCharactersInStringAreAlpha2 = val[6].ToString().Any(char.IsLetter);
                        }
                        string rat = "";
                        string des = "";
                        if (allCharactersInStringAreAlpha1 == true)
                        {
                            string[] sst = val[5].ToString().Split(' ');
                            rat = sst[0].ToString();
                            for (int k = 0; k <= sst.Length - 1; k++)
                            {
                                if (k > 0)
                                {
                                    des = des + sst[k].ToString() + " ";
                                }
                            }
                        }
                        if (allCharactersInStringAreAlpha2 == true)
                        {
                            string[] sst = val[6].ToString().Split(' ');
                            rat = sst[0].ToString();
                            for (int k = 0; k <= sst.Length - 1; k++)
                            {
                                if (k > 0)
                                {
                                    des = des + sst[k].ToString() + " ";
                                }
                            }
                        }

                        dt.Rows.Add();
                        dt.Rows[i][0] = data.Rows[i][0];
                        dt.Rows[i][1] = data.Rows[i][1];
                        string s1 = "";
                        string s2 = "";
                        if (val.Length == 6)
                        {
                            s1 = val[3].ToString();
                            s2 = val[4].ToString();

                        }
                        else if (val.Length == 7)
                        {
                            s1 = val[4].ToString();
                            s2 = val[5].ToString();
                        }
                        if (s1.ToString().Contains("-"))
                        {
                            dt.Rows[i][2] = "-" + s1.Substring(0, s1.Length - 1);
                        }
                        else
                        {
                            dt.Rows[i][2] = s1;
                        }
                        if (s2.ToString().Contains("-"))
                        {
                            dt.Rows[i][3] = "-" + s2.Substring(0, s2.Length - 1);
                        }
                        else
                        {
                            dt.Rows[i][3] = s2;
                        }
                        if (dt.Rows[i][3].ToString() == "0.00")
                        {
                            dt.Rows[i][4] = rat.Trim();
                        }
                        else
                        {
                            dt.Rows[i][4] = des.Trim();
                        }

                        if (FileNam == "RPRDRO01.txt")
                        {
                            dt.Rows[i][5] = "Branch-O1";
                        }
                        else
                        {
                            dt.Rows[i][5] = "Sub-O1";
                        }
                        if (val[4].Contains('-'))
                        {
                            dt.Rows[i][6] = "Sale";
                        }
                        else
                        {
                            dt.Rows[i][6] = "Purchase";
                        }

                    }


                }
                return dt;
            }
            catch
            {
                return null;
            }
        }
        //************************************************************************//

        public byte[] imageToByteArray(System.Drawing.Image imageIn)
        {
            MemoryStream ms = new MemoryStream();
            imageIn.Save(ms, System.Drawing.Imaging.ImageFormat.Gif);
            return ms.ToArray();
        }

        public void Create_Directory(string conStr, string Share_Path)
        {
            try
            {
                string s;
                SqlConnection con = new SqlConnection(conStr);
                con.Open();
                SqlCommand cmd = new SqlCommand("Select distinct (Source_Application) from ARC_Scope_BAseline where Source_Application not in ('Email','s2bx')", con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                System.Data.DataTable dt = new System.Data.DataTable();
                da.Fill(dt);
                for (int indx = 0; indx < dt.Rows.Count; indx++)
                {
                    s = dt.Rows[indx][0].ToString();
                    con.Close();
                    con.Open();
                    SqlCommand cmd1 = new SqlCommand("select Team,Country,Recon_Name from ARC_Recon_Master", con);
                    SqlDataAdapter da1 = new SqlDataAdapter(cmd1);
                    System.Data.DataTable dt1 = new System.Data.DataTable();
                    da1.Fill(dt1);

                    if (!Directory.Exists(Share_Path + "Dashboard_Report"))
                    {
                        Directory.CreateDirectory(Share_Path + "Dashboard_Report");
                    }
                    if (!Directory.Exists(Share_Path + "Input\\Emails\\"))
                    {
                        Directory.CreateDirectory(Share_Path + "Input\\Emails\\");
                    }
                    if (!Directory.Exists(Share_Path + "Input\\s2bx\\"))
                    {
                        Directory.CreateDirectory(Share_Path + "Input\\s2bx\\");
                    }

                    for (int ind = 0; ind < dt1.Rows.Count; ind++)
                    {
                        string s2 = dt1.Rows[ind][1].ToString();
                        string s3 = dt1.Rows[ind][2].ToString();
                        string s4 = dt1.Rows[ind][0].ToString();
                        if (!Directory.Exists(Share_Path + "Input\\" + s + "_" + s2))
                        {
                            Directory.CreateDirectory(Share_Path + "Input\\" + s + "_" + s2);
                        }
                        if (!Directory.Exists(Share_Path + "Input\\Crystal Report\\" + s2))
                        {
                            Directory.CreateDirectory(Share_Path + "Input\\Crystal Report\\" + s2);
                        }
                        if (!Directory.Exists(Share_Path + "Files_For_Formatting_Or_Non_Formatting\\" + s3))
                        {
                            Directory.CreateDirectory(Share_Path + "Files_For_Formatting_Or_Non_Formatting\\" + s3 + "\\Formatting");
                            Directory.CreateDirectory(Share_Path + "Files_For_Formatting_Or_Non_Formatting\\" + s3 + "\\Non_Formatting");
                        }
                        if (!Directory.Exists(Share_Path + "Output\\" + s3))
                        {
                            Directory.CreateDirectory(Share_Path + "Output\\" + s3);
                        }
                    }
                }
                con.Close();
            }
            catch
            {

            }
        }

        public void ReleaseComObject(object ob)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(ob);
                ob = null;
            }
            catch
            {
                ob = null;
            }
            finally
            {
                GC.Collect(GC.MaxGeneration);
                GC.WaitForPendingFinalizers();
            }
        }

        public System.Data.DataTable Formatting_Singapore_SSC(string FileName, string sourceFile)
        {
            if (FileName == "RDR001D/RDRP01CB IN")
            {
                FileName = "RDRP01CB IN";
            }
            if (FileName == "RPRDRO1C-IN")
            {
                System.Data.DataTable dt1 = new System.Data.DataTable();
                dt1 = GetTable_RPRDRO1C(sourceFile, 2);
                return dt1;
            }
            else if (FileName == "RPRDRO1C-SB-IN")
            {
                System.Data.DataTable dt2 = new System.Data.DataTable();
                dt2 = GetTable_RPRDRO1C(sourceFile, 3);
                return dt2;
            }
            else if (FileName == "18opxor029")
            {
                System.Data.DataTable dt3 = new System.Data.DataTable();
                dt3 = GetTable_OPXR029(sourceFile, 2);
                return dt3;
            }
            else if (FileName == "20opxor029")
            {
                System.Data.DataTable dt4 = new System.Data.DataTable();
                dt4 = GetTable_OPXR029(sourceFile, 3);
                return dt4;
            }
            else if (FileName == "RDR001DS-IN")
            {
                System.Data.DataTable dt5 = new System.Data.DataTable();
                dt5 = GetTable_RDR001DS(sourceFile, 4);
                return dt5;
            }
            else if (FileName == "RDRP01CB IN")
            {
                System.Data.DataTable dt6 = new System.Data.DataTable();
                dt6 = GetTable_RDR001DS(sourceFile, 5);
                return dt6;
            }
            else
            {
                return null;
            }
        }

        public System.Data.DataTable Formatting_HongKong_LPU(string FileName, string sourceFile)
        {
            if (FileName == "RPRDRO01")
            {
                System.Data.DataTable dt1 = new System.Data.DataTable();
                dt1 = GetTable_RPRDRO1C_HK(sourceFile, 2);
                return dt1;
            }
            else if (FileName == "60opxor029")
            {
                System.Data.DataTable dt3 = new System.Data.DataTable();
                dt3 = GetTable_OPXR029_HK(sourceFile, 2);
                return dt3;
            }
            else if (FileName == "RDR001D (1)")
            {
                System.Data.DataTable dt6 = new System.Data.DataTable();
                dt6 = GetTable_RDR001DS_HK(sourceFile, 5);
                return dt6;
            }
            else
            {
                System.Data.DataTable dt6 = new System.Data.DataTable();
                return dt6;
            }
        }

        public System.Data.DataTable Get_All_Files_Details(string Recon_Name, int Recon_ID, string conStr)
        {
            try
            {
                System.Data.DataTable dt = new System.Data.DataTable();
                SqlConnection con = new SqlConnection(conStr);
                SqlCommand cmd = new SqlCommand();
                SqlDataAdapter ad = new SqlDataAdapter("Select Team, Country_Name, Report_Source_File_Name, Format_Direct_Upload, Source_Application, File_Format,FTP_File_Format_Name,AutomationStatus from ARC_Scope_BaseLine where Recon_Id = " + Recon_ID + "", con);
                con.Open();
                ad.Fill(dt);
                con.Close();
                return dt;
            }
            catch
            {
                return null;
                //MessageBox.Show("Network Error....! Plz check Lan connection");
            }
        }

        public int Get_All_Files_Count_From_Folders(System.Data.DataTable dt, string Recon_name, string conStr, string Share_Path)
        {
            try
            {
                string Recon_Date = string.Empty;
                string sourceFile = string.Empty;
                int datacrop_indx = 0;
                SqlConnection con = new SqlConnection(conStr);
                SqlCommand cmd = new SqlCommand();
                TimeSpan ts = new TimeSpan();
                int FileCnt = 0;
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    string Country_Name = Convert.ToString(dt.Rows[i][1]);
                    string File_Name = Convert.ToString(dt.Rows[i][2]);
                    string Format_Direct_Upload = Convert.ToString(dt.Rows[i][3]);
                    string Source_Application = Convert.ToString(dt.Rows[i][4]);
                    string File_Format = Convert.ToString(dt.Rows[i][5]);
                    string Formated_FileName = Convert.ToString(dt.Rows[i][6]);
                    string AutomationStatus = Convert.ToString(dt.Rows[i][7]);

                    if (File_Format.Contains("xlsx"))
                    {
                        File_Format = "xlsx";
                    }

                    if (Recon_name == "QATAR - SWITCH RECON")
                    {
                        File_Name = GetSpecificQatar(Share_Path + "Input\\Emails\\");
                    }
                    if (File_Name == "RDR001D/RDRP01CB IN")
                    {
                        File_Name = "RDRP01CB IN";
                    }
                    if (File_Name.Contains("DD-MMM YYYY"))
                    {
                        Recon_Date = Get_Recon_Date(conStr, Country_Name, "dd-MMM yyyy");
                        File_Name = File_Name.Remove(File_Name.Length - 11);
                        datacrop_indx = 11;
                        File_Name = File_Name + Recon_Date;
                    }
                    else if (File_Name.Contains("DD.MM.YYYY"))
                    {

                        if (File_Name.Contains("AB-DETAIL_"))
                        {
                            File_Name = GetSpecificFileNameABDETAIL(Share_Path + "Input\\Emails\\");
                        }
                        else if (File_Name.Contains("S4 POSITION"))
                        {
                            System.DateTime date = System.DateTime.Today;
                            File_Name = File_Name.Replace("DD.MM.YYYY", date.ToString("dd.MM.yyyy"));
                        }
                        else
                        {
                            Recon_Date = Get_Recon_Date(conStr, Country_Name, "dd.MM.yyyy");
                            File_Name = File_Name.Remove(File_Name.Length - 10);
                            datacrop_indx = 10;
                            File_Name = File_Name + Recon_Date;
                        }
                    }
                    else if (File_Name.Contains("yyyyMMdd"))
                    {
                        Recon_Date = Get_Recon_Date(conStr, Country_Name, "yyyyMMdd");
                        File_Name = File_Name.Remove(File_Name.Length - 8);
                        if (File_Name.Contains("TB_OPS_DAILY_TRADE_REPORT-yyyyMMdd"))
                        {
                            datacrop_indx = 17;
                            File_Name = File_Name + Recon_Date + "-0010-GMT";
                        }
                        else if (Recon_name == "Vietnam I-banking" && File_Name.Contains("IBANKING SETTLEMENT"))
                        {
                            DateTime d = DateTime.ParseExact(Recon_Date, "yyyyMMdd", CultureInfo.InvariantCulture);
                        }
                        else
                        {
                            datacrop_indx = 8;
                            File_Name = File_Name + Recon_Date;
                        }
                    }
                    else if (File_Name.Contains("YYYYMMDD"))
                    {
                        Recon_Date = Get_Recon_Date(conStr, Country_Name, "yyyyMMdd");
                        if (File_Name.Contains("BALRES_") || File_Name.Contains("BillPayment_Mobile_TopUp"))
                        {
                            File_Name = File_Name.Substring(0, File_Name.Length - 8) + Recon_Date;
                            datacrop_indx = 8;
                        }
                        else if (File_Name.Contains("_inc_scvn"))
                        {
                            File_Name = Recon_Date + File_Name.Substring(File_Name.Length - 9, 9);
                        }
                        else
                        {
                            File_Name = File_Name.Substring(0, File_Name.Length - 8) + Recon_Date;
                            datacrop_indx = 8;
                        }
                    }
                    else if (File_Name.Contains("YYMMDD"))
                    {
                        Recon_Date = Get_Recon_Date(conStr, Country_Name, "yyMMdd");
                        if (File_Name.Contains("REPATMBX") || File_Name.Contains("REPSCBX"))
                        {
                            File_Name = File_Name.Substring(0, File_Name.Length - 6) + Recon_Date;
                            datacrop_indx = 6;
                        }
                        else if (Recon_name == "South Africa-  Stock open items")
                        {
                            File_Name = File_Name.Substring(0, File_Name.Length - 6) + DateTime.Now.ToString("yyMMdd");
                            datacrop_indx = 6;
                        }
                    }
                    else if (File_Name.Contains("DD-MM-YYYY"))
                    {
                        Recon_Date = Get_Recon_Date(conStr, Country_Name, "dd-MM-yyyy");
                        if (File_Name.Contains("CURSA_AS_OF_") || File_Name.Contains("CURSC_AS_OF_") || File_Name.Contains("CURSE_AS_OF_") || File_Name.Contains("CURSI_AS_OF_") || File_Name.Contains("CURST_AS_OF_"))
                        {
                            File_Name = File_Name.Substring(0, File_Name.Length - 10) + Recon_Date;
                            datacrop_indx = 10;
                        }
                        else
                        {
                            File_Name = File_Name.Substring(0, File_Name.Length - 10) + Recon_Date;
                            datacrop_indx = 10;
                        }
                    }
                    else if (Recon_name == "India - RBI Main Account")
                    {
                        if (File_Name.Contains("_RACSTRBI_"))
                        {
                            File_Name = GetRBIFileName(Share_Path + "Input\\Emails\\");
                        }
                    }

                    else if (File_Name.Contains("DDMMYYYY"))
                    {
                        if ((Recon_name == "Vietnam Billing") || (Recon_name == "Vietnam Smart link") || (Recon_name == "Vietnam I-banking"))  // added on 23 03 2017 for Vietnam billing and Vietnam smart link for T-2 days
                        {
                            if ((Recon_name == "Vietnam Billing"))  // added on 23 03 2017 for Vietnam billing and Vietnam smart link for T-2 days
                            {
                                if (File_Name.Contains("BILLING SETTLEMENT"))
                                {
                                    File_Name = GetSpecificFileName(Share_Path + "Input\\Emails\\");

                                }
                            }
                            else if ((Recon_name == "Vietnam Smart link"))
                            {
                                if (File_Name.Contains("ACQ SETTLEMENT"))
                                {
                                    File_Name = GetSpecificFileNameSmartLink(Share_Path + "Input\\Emails\\", "ACQ");

                                }
                                else if (File_Name.Contains("ISS SETTLEMENT"))
                                {
                                    File_Name = GetSpecificFileNameSmartLink(Share_Path + "Input\\Emails\\", "ISS");
                                }
                            }
                            else if (Recon_name == "Vietnam I-banking" && File_Name.Contains("IBANKING SETTLEMENT"))
                            {
                                int daystot = Get_HolidaysTotal(conStr, Country_Name, "ddMMyy");
                                string Date = "";
                                DateTime dtVietnm = DateTime.ParseExact(Recon_Date, "yyyyMMdd", CultureInfo.InvariantCulture);
                                Date = dtVietnm.AddDays(-daystot).ToString("ddMMyy");
                                File_Name = File_Name.Remove(File_Name.Length - 8);
                                datacrop_indx = 8;
                                File_Name = File_Name + Date;
                            }
                        }
                        else
                        {
                            Recon_Date = Get_Recon_Date(conStr, Country_Name, "ddMMyyyy");
                            File_Name = File_Name.Remove(File_Name.Length - 8);
                            datacrop_indx = 8;
                            File_Name = File_Name + Recon_Date;
                        }
                    }
                    else if (File_Name.Contains("DDMMYY"))
                    {
                        Recon_Date = Get_Recon_Date(conStr, Country_Name, "ddMMyy");
                        File_Name = File_Name.Remove(File_Name.Length - 6);
                        datacrop_indx = 6;
                        if (Recon_name == "Vietnam ACB")
                        {
                            int daystot = Get_HolidaysTotal(conStr, Country_Name, "ddMMyy");
                            string Date = "";
                            DateTime dtVietnm = DateTime.ParseExact(Recon_Date, "ddMMyy", CultureInfo.InvariantCulture);
                            Date = dtVietnm.AddDays(-daystot).ToString("ddMMyy");
                            File_Name = File_Name + Date;
                        }
                        else
                        {
                            File_Name = File_Name + Recon_Date;
                        }
                    }
                    else if (File_Name.Contains("MMDDYYYY"))
                    {
                        Recon_Date = Get_Recon_Date(conStr, Country_Name, "MMddyyyy");
                        File_Name = Recon_Date;
                    }
                    else if (File_Name.Contains("DD-MMM-YYYY") || File_Name.Contains("dd-MMM-yyyy"))
                    {
                        if (Recon_name == "IBROKER  - SG" || Recon_name == "IBROKER  - MY")
                        {
                            Recon_Date = Get_Recon_Date(conStr, Country_Name, "dd-MMM-yyyy");
                            DateTime chkdt = DateTime.ParseExact(Recon_Date, "dd-MMM-yyyy", CultureInfo.InvariantCulture);
                            //if (chkdt.DayOfWeek.ToString() != "Friday")
                            //{
                            //    chkdt = chkdt.AddDays(1);
                            //}
                            //if (File_Name.Contains("DD-MMM-YYYY"))
                            //{
                            //    File_Name = File_Name.Remove(File_Name.Length - 11);
                            //    Recon_Date = chkdt.ToString("dd-MMM-yyyy").ToUpper();
                            //}
                            //else
                            //{
                            //    File_Name = File_Name.Remove(File_Name.Length - 11);
                            //    Recon_Date = chkdt.ToString("dd-MMM-yyyy");
                            //}
                            datacrop_indx = 11;
                            File_Name = File_Name.Remove(File_Name.Length - 11);
                            Recon_Date = DateTime.Today.ToString("dd-MMM-yyyy");
                            File_Name = File_Name + Recon_Date;
                        }
                        else
                        {
                            File_Name = File_Name.Remove(File_Name.Length - 11);
                            datacrop_indx = 11;
                            File_Name = File_Name + Recon_Date;
                        }
                    }
                    else if (File_Name.Contains("YYYY-MM-DD"))
                    {
                        Recon_Date = Get_Recon_Date(conStr, Country_Name, "yyyy-MM-dd");
                        if (Recon_name == "Qatar Stock Recon")
                        {
                            File_Name = File_Name.Substring(0, File_Name.Length - 10);
                            File_Name = File_Name + Recon_Date;
                        }
                    }
                    else if (File_Name.Contains("DDMM-DDMM"))
                    {
                        Recon_Date = Get_Recon_Date(conStr, Country_Name, "ddMM");
                        if (Recon_name == "Vietnam ACB")
                        {
                            int daystot = Get_HolidaysTotal(conStr, Country_Name, "ddMM");
                            DateTime dtVietnm = DateTime.ParseExact(Recon_Date, "ddMM", CultureInfo.InvariantCulture).AddDays(-daystot);
                            string temp = dtVietnm.ToString("ddMM");
                            File_Name = File_Name.Remove(File_Name.Length - 9);
                            datacrop_indx = 9;
                            File_Name = File_Name + temp + "-" + Recon_Date;
                            //File_Name = GetVietnamACB(Share_Path + "Input\\Emails\\");
                        }
                    }
                    else if (File_Name.Contains("MMDD"))
                    {
                        if (Recon_name == "Vietnam Visa TLM open items")
                        {
                            if (File_Name.Contains("Purchase"))
                            {
                                Recon_Date = Get_Recon_Date(conStr, Country_Name, "MMdd");
                                int daystot = Get_HolidaysTotal(conStr, Country_Name, "MMdd");
                                string Date = "";
                                DateTime dtVietnm = DateTime.ParseExact(Recon_Date, "MMdd", CultureInfo.InvariantCulture);
                                Date = dtVietnm.AddDays(-daystot).ToString("MMdd");
                                File_Name = File_Name.Remove(File_Name.Length - 4);
                                datacrop_indx = 4;
                                File_Name = File_Name + Date;
                                //File_Name = GetVietnamVisa(Share_Path + "Input\\Emails\\", "purchase");
                            }
                            else if (File_Name.Contains("SWITCH REPORT-"))
                            {
                                File_Name = GetVietnamVisa(Share_Path + "Input\\Emails\\", "purchase");
                            }
                            else if (File_Name.Contains("VISA ACQUIRER SETTLEMENT-EP745-"))
                            {
                                File_Name = GetVietnamVisa(Share_Path + "Input\\Emails\\", "purchase");
                            }
                        }
                    }
                    else if (File_Name.Contains("MONTH YYYY"))
                    {
                        System.DateTime date = System.DateTime.Today; //AddDays(-1)
                        File_Name = File_Name.Replace("MONTH YYYY", date.ToString("MMMM yyyy").ToUpper());
                    }
                    else if (File_Name.Contains("bis"))
                    {
                        string temp_Soure_Path = Share_Path + "Input\\Emails\\" + File_Name + ".zip";
                        string Soure_Path = Share_Path + "Input\\Emails\\";
                        ZipFile zip = new Ionic.Zip.ZipFile(temp_Soure_Path);
                        foreach (ZipEntry z in zip)
                        {
                            z.Password = "bis4";
                            z.Extract(Soure_Path, Ionic.Zip.ExtractExistingFileAction.OverwriteSilently);
                        }
                    }
                    //DDMM-DDMM
                    //*******************************Monday Logics***************************************//
                    if ((Recon_name == "Zimbabwe FX Recon_Zimbabwe FXR Adjustments") || (Recon_name == "Kenya FX Recon_Kenya FXR Adjustments") ||
                        (Recon_name == "Uganda FX Recon_Uganda FXR Adjustments") || (Recon_name == "TANZANIA FX RECON_TANZANIA FXR Adjustments") ||
                        (Recon_name == "Botswana FX Recon_Botswana FXR Adjustments") || (Recon_name == "DIFC FX Recon - Advised-DIFC Adjustment Report") ||
                        (Recon_name == "UAE FX Recon - Advised_UAE Adjustment Report") || (Recon_name == "BAHRAIN DBU FX Recon - Advised-BAHRAIN DBU Adjustment Report") ||
                        (Recon_name == "BAHRAIN OBU FX Recon - Advised-BAHRAIN OBU Adjustment Report"))
                    {
                        Recon_Date = Get_Recon_Date_For_Monday_Logic(conStr, Country_Name, "MM.dd.yyyy");
                        DateTime myDate = DateTime.ParseExact(Recon_Date, "MM.dd.yyyy", System.Globalization.CultureInfo.InvariantCulture);
                        ts = (DateTime.Today.Date - myDate.Date);
                        if (ts.Days > 1)
                        {
                            File_Name = File_Name + Recon_Date;
                            datacrop_indx = 10;
                        }
                    }
                    //*******************************************************************************//

                    if (Source_Application.ToUpper() == "S2BX")
                    {
                        if (!string.IsNullOrEmpty(File_Format))
                            sourceFile = Share_Path + "Input\\s2bx\\" + File_Name + "." + File_Format;
                        else
                            sourceFile = Share_Path + "Input\\s2bx\\" + File_Name;
                    }
                    else if (Source_Application != "Email")
                    {
                        if (!string.IsNullOrEmpty(File_Format))
                            sourceFile = Share_Path + "Input\\" + Source_Application + "_" + Country_Name + "\\" + File_Name + "." + File_Format;
                        else
                            sourceFile = Share_Path + "Input\\" + Source_Application + "_" + Country_Name + "\\" + File_Name;
                    }
                    else
                    {
                        if (!string.IsNullOrEmpty(File_Format))
                            sourceFile = Share_Path + "Input\\Emails\\" + File_Name + "." + File_Format;
                        else
                            sourceFile = Share_Path + "Input\\Emails\\" + File_Name;
                    }
                    //string sourceFile = Directory + "Input\\" + Source_Application + "_" + Country_Name + "\\" + File_Name + "." + File_Format;

                    if (File.Exists(sourceFile))
                    {
                        if (string.IsNullOrEmpty(AutomationStatus) || AutomationStatus != "COMPLETED")
                        {
                            if (File_Name.Contains(Recon_Date) && !string.IsNullOrEmpty(Recon_Date))
                            {
                                if (Recon_name == "India - CMPC Suspense" || Recon_name == "Qatar Stock Recon")
                                {
                                    File_Name = File_Name.Substring(0, File_Name.Length - 10);
                                    cmd = new SqlCommand("update ARC_Scope_BaseLine set PSID = '" + Environment.UserName + "', IsProcessed = 1, AutomationStatus = 'COMPLETED' where Recon = '" + Recon_name + "' and Report_Source_File_Name like '" + File_Name + "%'", con);
                                }
                                else if (Recon_name == "Vietnam VNPay")
                                {
                                    if (File_Name.Contains("BillPayment_Mobile_TopUp"))
                                    {
                                        File_Name = File_Name.Substring(0, File_Name.Length - 8);
                                        cmd = new SqlCommand("update ARC_Scope_BaseLine set PSID = '" + Environment.UserName + "', IsProcessed = 1, AutomationStatus = 'COMPLETED' where Recon = '" + Recon_name + "' and Report_Source_File_Name like '" + File_Name + "%'", con);
                                    }
                                    else if (File_Name.Contains("_inc_scvn"))
                                    {
                                        File_Name = File_Name.Substring(File_Name.Length - 9, 9);
                                        cmd = new SqlCommand("update ARC_Scope_BaseLine set PSID = '" + Environment.UserName + "', IsProcessed = 1, AutomationStatus = 'COMPLETED' where Recon = '" + Recon_name + "' and Report_Source_File_Name like '%" + File_Name + "%'", con);
                                    }
                                }
                                else if (Recon_name == "Thailand - Custody - Depo Recon")
                                {
                                    File_Name = File_Name.Substring(0, File_Name.Length - 8);
                                    cmd = new SqlCommand("update ARC_Scope_BaseLine set PSID = '" + Environment.UserName + "', IsProcessed = 1, AutomationStatus = 'COMPLETED' where Recon = '" + Recon_name + "' and Report_Source_File_Name like '" + File_Name + "%'", con);
                                }
                                else if (Recon_name == "UAE SWITCH RECON")
                                {
                                    File_Name = "MMDDYYYY";
                                    cmd = new SqlCommand("update ARC_Scope_BaseLine set PSID = '" + Environment.UserName + "', IsProcessed = 1, AutomationStatus = 'COMPLETED' where Recon = '" + Recon_name + "' and Report_Source_File_Name like '" + File_Name + "%'", con);
                                }
                                else if (Recon_name == "Vietnam Visa TLM open items")
                                {
                                    if (File_Name.Contains("Purchase"))
                                    {
                                        File_Name = File_Name.Substring(0, File_Name.Length - 4);
                                        cmd = new SqlCommand("update ARC_Scope_BaseLine set PSID = '" + Environment.UserName + "', IsProcessed = 1, AutomationStatus = 'COMPLETED' where Recon = '" + Recon_name + "' and Report_Source_File_Name like '" + File_Name + "%'", con);
                                    }
                                    else if (File_Name.Contains("SWITCH REPORT-") || File_Name.Contains("VISA ACQUIRER SETTLEMENT-EP745-"))
                                    {
                                        File_Name = File_Name.Substring(0, File_Name.Length - 8);
                                        cmd = new SqlCommand("update ARC_Scope_BaseLine set PSID = '" + Environment.UserName + "', IsProcessed = 1, AutomationStatus = 'COMPLETED' where Recon = '" + Recon_name + "' and Report_Source_File_Name like '" + File_Name + "%'", con);
                                    }
                                }
                                else
                                {
                                    File_Name = File_Name.Remove(File_Name.Length - datacrop_indx);
                                    cmd = new SqlCommand("update ARC_Scope_BaseLine set PSID = '" + Environment.UserName + "', IsProcessed = 1, AutomationStatus = 'COMPLETED' where Recon = '" + Recon_name + "' and Report_Source_File_Name like '" + File_Name + "%'", con);
                                }
                            }
                            else if (File_Name == "RDRP01CB IN")
                            {
                                File_Name = "RDR001D/RDRP01CB IN";
                                cmd = new SqlCommand("update ARC_Scope_BaseLine set PSID = '" + Environment.UserName + "', IsProcessed = 1, AutomationStatus = 'COMPLETED' where Recon = '" + Recon_name + "' and Report_Source_File_Name = '" + File_Name + "'", con);
                            }
                            else if (Recon_name == "India - RBI Main Account")
                            {
                                File_Name = "_RACSTRBI_";
                                cmd = new SqlCommand("update ARC_Scope_BaseLine set PSID = '" + Environment.UserName + "', IsProcessed = 1, AutomationStatus = 'COMPLETED' where Recon = '" + Recon_name + "' and Report_Source_File_Name like '" + File_Name + "%'", con);
                            }

                            else if (File_Name.Contains("AB-DETAIL_"))
                            {
                                File_Name = File_Name.Substring(0, File_Name.Length - 10);
                                cmd = new SqlCommand("update ARC_Scope_BaseLine set PSID = '" + Environment.UserName + "', IsProcessed = 1, AutomationStatus = 'COMPLETED' where Recon = '" + Recon_name + "' and Report_Source_File_Name like '" + File_Name + "%'", con);
                            }
                            else if (File_Name.ToString().ToLower().Contains("detail "))
                            {
                                if (Recon_name == "Vietnam ACB")
                                {
                                    File_Name = File_Name.Substring(0, File_Name.Length - 9);
                                    cmd = new SqlCommand("update ARC_Scope_BaseLine set PSID = '" + Environment.UserName + "', IsProcessed = 1, AutomationStatus = 'COMPLETED' where Recon = '" + Recon_name + "' and Report_Source_File_Name like '" + File_Name + "%'", con);
                                }
                            }
                            else if (File_Name.Contains("ACQ SETTLEMENT") || File_Name.Contains("ISS SETTLEMENT") || File_Name.Contains("BILLING SETTLEMENT") || File_Name.Contains("SWITCH REPORT-") || File_Name.Contains("VISA ACQUIRER SETTLEMENT-EP745-"))
                            {
                                File_Name = File_Name.Substring(0, File_Name.Length - 8);
                                cmd = new SqlCommand("update ARC_Scope_BaseLine set PSID = '" + Environment.UserName + "', IsProcessed = 1, AutomationStatus = 'COMPLETED' where Recon = '" + Recon_name + "' and Report_Source_File_Name like '" + File_Name + "%'", con);
                            }
                            else if (File_Name.Contains("rp09scb") || File_Name.Contains("Purchase"))
                            {
                                File_Name = File_Name.Substring(0, File_Name.Length - 4);
                                cmd = new SqlCommand("update ARC_Scope_BaseLine set PSID = '" + Environment.UserName + "', IsProcessed = 1, AutomationStatus = 'COMPLETED' where Recon = '" + Recon_name + "' and Report_Source_File_Name like '" + File_Name + "%'", con);
                            }
                            else if (File_Name.Contains("CSCS POSITION REPORT"))
                            {
                                File_Name = File_Name.Substring(0, File_Name.Length - 10);
                                cmd = new SqlCommand("update ARC_Scope_BaseLine set PSID = '" + Environment.UserName + "', IsProcessed = 1, AutomationStatus = 'COMPLETED' where Recon = '" + Recon_name + "' and Report_Source_File_Name like '" + File_Name + "%'", con);
                            }
                            else if (File_Name.Contains("S4 POSITION"))
                            {
                                File_Name = File_Name.Substring(0, File_Name.Length - 10);
                                cmd = new SqlCommand("update ARC_Scope_BaseLine set PSID = '" + Environment.UserName + "', IsProcessed = 1, AutomationStatus = 'COMPLETED' where Recon = '" + Recon_name + "' and Report_Source_File_Name like '" + File_Name + "%'", con);
                            }
                            else if (File_Name.Contains("SG_Holding") || File_Name.Contains("MY_Holding"))
                            {
                                File_Name = File_Name.Substring(0, File_Name.Length - 12);
                                cmd = new SqlCommand("update ARC_Scope_BaseLine set PSID = '" + Environment.UserName + "', IsProcessed = 1, AutomationStatus = 'COMPLETED' where Recon = '" + Recon_name + "' and Report_Source_File_Name like '" + File_Name + "%'", con);
                            }
                            else if (Recon_name == "South Africa-  Stock open items")
                            {
                                File_Name = File_Name.Substring(0, File_Name.Length - 6);
                                cmd = new SqlCommand("update ARC_Scope_BaseLine set PSID = '" + Environment.UserName + "', IsProcessed = 1, AutomationStatus = 'COMPLETED' where Recon = '" + Recon_name + "' and Report_Source_File_Name like '" + File_Name + "%'", con);
                            }
                            else
                            {
                                cmd = new SqlCommand("update ARC_Scope_BaseLine set PSID = '" + Environment.UserName + "', IsProcessed = 1, AutomationStatus = 'COMPLETED' where Recon = '" + Recon_name + "' and Report_Source_File_Name = '" + File_Name + "'", con);
                            }
                            con.Open();
                            cmd.ExecuteNonQuery();
                            con.Close();
                        }
                        FileCnt++;
                    }
                }
                return FileCnt;
            }
            catch
            {
                return 0;
            }
        }

        public string GetSettlementDateFromExcel(string filePath2)
        {
            string Date = "";
            try
            {
                string strConn1;

                if (filePath2.Substring(filePath2.LastIndexOf('.')).ToLower() == ".xlsx")
                    strConn1 = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + filePath2 + ";Extended Properties=\"Excel 12.0;HDR=Yes;IMEX=1\"";
                //strConn = "Provider=Microsoft.Jet.OleDb.4.0; Data Source = " + System.IO.Path.GetDirectoryName(ExcelfilePath) + "; Extended Properties = 'text;HDR=YES;IMEX=1v;FMT=Delimited(,)';";
                else
                    strConn1 = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + filePath2 + ";Extended Properties=\"Excel 8.0;HDR=Yes;IMEX=1\"";
                System.Data.DataTable dtexcel1 = new System.Data.DataTable();
                OleDbConnection conn1 = new OleDbConnection(strConn1);
                conn1.Open();
                System.Data.DataTable schemaTable1 = conn1.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, new object[] { null, null, null, "TABLE" });
                //Looping Total Sheet of Xl File
                /*foreach (DataRow schemaRow in schemaTable.Rows)
                {
                }*/
                //Looping a first Sheet of Xl File
                DataRow schemaRow1 = schemaTable1.Rows[0];
                string sheet1 = schemaRow1["TABLE_NAME"].ToString();

                if (!sheet1.EndsWith("_"))
                {
                    try
                    {
                        string query1 = "SELECT  * FROM [" + sheet1 + "]";
                        OleDbDataAdapter daexcel1 = new OleDbDataAdapter(query1, conn1);
                        dtexcel1.Locale = CultureInfo.CurrentCulture;
                        daexcel1.Fill(dtexcel1);
                    }
                    catch
                    {
                        //throw ex;
                    }
                    if (dtexcel1.Rows[dtexcel1.Rows.Count - 2]["CCY"].ToString() != "")
                    {
                        Date = dtexcel1.Rows[dtexcel1.Rows.Count - 2]["Trans date"].ToString();
                        string year = DateTime.Now.Year.ToString();
                        Date = Date.Substring(2, 2) + Date.Substring(0, 2) + year;
                    }
                    else
                    {
                        Date = dtexcel1.Rows[dtexcel1.Rows.Count - 3]["Trans date"].ToString();
                        string year = DateTime.Now.Year.ToString();
                        Date = Date.Substring(2, 2) + Date.Substring(0, 2) + year;
                    }

                }
            }
            catch
            {
                return null;
            }
            return Date;

        }

        public string GetJETCO(string s)
        {
            string[] files1 = Directory.GetFiles(s);

            string actfile = "";

            for (int i = 0; i < files1.Length; i++)
            {
                files1[i] = Path.GetFileNameWithoutExtension(files1[i]);
                if (files1[i].Contains("AB-DETAIL_"))
                {
                    actfile = files1[i];
                    break;
                }

            }
            return actfile;
        }

        public string GetVietnamACB(string s)
        {
            string[] files1 = Directory.GetFiles(s);

            string actfile = "";

            for (int i = 0; i < files1.Length; i++)
            {
                files1[i] = Path.GetFileNameWithoutExtension(files1[i]);

                if (files1[i].ToString().ToLower().Contains("detail "))
                {
                    actfile = files1[i];
                    break;
                }

            }
            return actfile;
        }

        public string GetVietnamVisa(string s, string File)
        {
            string[] files1 = Directory.GetFiles(s);

            string actfile = "";

            for (int i = 0; i < files1.Length; i++)
            {
                files1[i] = Path.GetFileNameWithoutExtension(files1[i]);

                if (files1[i].ToString().ToLower().Contains("purchase") && files1[i].ToString().ToLower().Contains(File))
                {
                    actfile = files1[i];
                    break;
                }
                if (files1[i].ToString().ToLower().Contains("switch report") && files1[i].Contains(File))
                {
                    actfile = files1[i];
                    break;
                }
                if (files1[i].ToString().ToLower().Contains("visa acquirer settlement-ep745-") && files1[i].Contains(File))
                {
                    actfile = files1[i];
                    break;
                }
            }
            return actfile;
        }

        public string GetSpecificFileNameSmartLink(string s, string File)
        {
            string[] files1 = Directory.GetFiles(s);

            string actfile = "";


            for (int i = 0; i < files1.Length; i++)
            {
                files1[i] = Path.GetFileNameWithoutExtension(files1[i]);

                if (files1[i].Contains("ACQ SETTLEMENT") && files1[i].Contains(File))
                {
                    actfile = files1[i];

                }
                if (files1[i].Contains("ISS SETTLEMENT") && files1[i].Contains(File))
                {
                    actfile = files1[i];
                }

            }

            return actfile;
        }

        public string GetSpecificFileNameVietnam_I_Banking(string s, string File)
        {
            string[] files1 = Directory.GetFiles(s);

            string actfile = "";


            for (int i = 0; i < files1.Length; i++)
            {
                files1[i] = Path.GetFileNameWithoutExtension(files1[i]);

                if (files1[i].Contains("IBANKING SETTLEMENT") && files1[i].Contains(File))
                {
                    actfile = files1[i];
                }
            }

            return actfile;
        }

        public string GetSpecificFileName(string s)
        {
            string[] files1 = Directory.GetFiles(s);

            string actfile = "";

            for (int i = 0; i < files1.Length; i++)
            {
                files1[i] = Path.GetFileNameWithoutExtension(files1[i]);
                if (files1[i].Contains("BILLING SETTLEMENT"))
                {
                    actfile = files1[i];
                }

            }
            return actfile;
        }

        public string GetRBIFileName(string s)
        {
            string[] files1 = Directory.GetFiles(s);

            string actfile = "";

            for (int i = 0; i < files1.Length; i++)
            {
                files1[i] = Path.GetFileNameWithoutExtension(files1[i]);
                if (files1[i].Contains("_RACSTRBI_"))
                {
                    actfile = files1[i];
                }

            }
            return actfile;
        }

        public string GetSpecificFileNameABDETAIL(string s)
        {
            string[] files1 = Directory.GetFiles(s);

            string actfile = "";

            for (int i = 0; i < files1.Length; i++)
            {
                files1[i] = Path.GetFileNameWithoutExtension(files1[i]);
                if (files1[i].Contains("AB-DETAIL_"))
                {
                    actfile = files1[i];
                }

            }
            return actfile;
        }

        public string GetSpecificQatar(string s)
        {
            string[] files1 = Directory.GetFiles(s);

            string actfile = "";

            for (int i = 0; i < files1.Length; i++)
            {
                files1[i] = Path.GetFileName(files1[i]);
                if (files1[i].Contains("rp09scb"))
                {
                    actfile = files1[i];
                }

            }
            return actfile;
        }

        public string Get_Recon_DateForJETCO(string s)
        {
            StreamReader objReader;
            objReader = new StreamReader(s);
            string date = "";
            string[] lines = System.IO.File.ReadAllLines(s);
            for (int i = 0; i <= lines.Length - 1; i++)
            {
                if (lines[i].ToString().Contains("DATE:"))
                {
                    string[] ar = lines[i].ToString().Split(':');
                    string[] date1 = ar[ar.Length - 1].ToString().Trim().Split('/');

                    if (date1[1].Length == 1 && date1[0].Length == 2)
                    {
                        date = "0" + date1[1] + "." + date1[0] + "." + "20" + date1[2];
                    }
                    else if (date1[1].Length == 2 && date1[0].Length == 1)
                    {
                        date = date1[1] + "." + "0" + date1[0] + "." + "20" + date1[2];
                    }
                    else if (date1[1].Length == 1 && date1[0].Length == 1)
                    {
                        date = "0" + date1[1] + "." + "0" + date1[0] + "." + "20" + date1[2];
                    }
                    else if (date1[1].Length == 2 && date1[0].Length == 2)
                    {
                        date = date1[1] + "." + date1[0] + "." + "20" + date1[2];
                    }
                    break;

                }
            }
            return date;
        }

        public string Get_Recon_Date(string conStr, string CountryName, string Date_Format)
        {
            string Final_Date = string.Empty;
            string fmt = CultureInfo.CurrentCulture.DateTimeFormat.ShortDatePattern;

            try
            {
                int day = 0;
                string actd = "";
                int datefound = 0;
                System.Data.DataTable dt = new System.Data.DataTable();
                System.Data.DataTable table = new System.Data.DataTable();
                System.Data.DataTable date = new System.Data.DataTable();
                SqlConnection con = new SqlConnection(conStr);
                string Today = DateTime.Now.ToString("dddd");

                //string date = DateTime.Now.ToString("09/09/2017");
                //*************************************************************************
                SqlDataAdapter ad = new SqlDataAdapter("dbo.ARC_SP_Get_Holiday_Date", con);
                ad.SelectCommand.CommandType = CommandType.StoredProcedure;
                ad.SelectCommand.Parameters.AddWithValue("@Country_Name", CountryName);
                con.Open();
                ad.Fill(table);
                con.Close();

                if (table.Rows.Count > 0)
                {
                    if (Convert.ToString(table.Rows[0][2]).Trim() == "NonGulf")
                    {
                        int Year = Convert.ToInt32(DateTime.Now.ToString("yyyy"));
                        //DateTime EndOfYear = Convert.ToDateTime("31-12-" + Year + "");
                        DateTime startDate = new DateTime(Year, 1, 1);
                        DateTime endDate = new DateTime(Year, 12, 31);

                        date.Columns.Add("Holiday_Date", typeof(DateTime));
                        date.Columns.Add("Country_Id", typeof(long));
                        date.Columns.Add("Gulf");
                        TimeSpan diff = endDate - startDate;
                        int days = diff.Days;
                        for (var i = 0; i <= days; i++)
                        {
                            var testDate = startDate.AddDays(i);
                            try
                            {
                                switch (testDate.DayOfWeek)
                                {
                                    case DayOfWeek.Saturday:
                                    case DayOfWeek.Sunday:
                                        date.Rows.Add();
                                        date.Rows.Add(testDate.ToString(fmt));
                                        break;
                                }

                            }
                            catch
                            {

                            }
                        }
                        date.Merge(table);
                        ExecRemoveDuplicateRows(date, "Holiday_Date");
                    }
                    else
                    {
                        int Year = Convert.ToInt32(DateTime.Now.ToString("yyyy"));
                        DateTime startDate = new DateTime(Year, 1, 1);
                        DateTime endDate = new DateTime(Year, 12, 31);

                        date.Columns.Add("Holiday_Date", typeof(DateTime));
                        date.Columns.Add("Country_Id", typeof(long));
                        date.Columns.Add("Gulf");
                        TimeSpan diff = endDate - startDate;
                        int days = diff.Days;
                        for (var i = 0; i <= days; i++)
                        {
                            var testDate = startDate.AddDays(i);
                            switch (testDate.DayOfWeek)
                            {
                                case DayOfWeek.Friday:
                                case DayOfWeek.Saturday:
                                    date.Rows.Add(testDate.ToString(fmt));
                                    break;
                            }
                        }
                        date.Merge(table);
                    }
                }
                else
                {
                    SqlCommand ad1 = new SqlCommand("dbo.ARC_SP_Get_Holiday_Date_NoHoliday", con);
                    ad1.CommandType = CommandType.StoredProcedure;
                    ad1.Parameters.AddWithValue("@Country_Name", CountryName);
                    con.Open();
                    string Result = Convert.ToString(ad1.ExecuteScalar());

                    con.Close();

                    if (Result == "NonGulf")
                    {
                        int Year = Convert.ToInt32(DateTime.Now.ToString("yyyy"));
                        DateTime startDate = new DateTime(Year, 1, 1);
                        DateTime endDate = new DateTime(Year, 12, 31);

                        date.Columns.Add("Holiday_Date", typeof(DateTime));
                        date.Columns.Add("Country_Id", typeof(long));
                        date.Columns.Add("Gulf");
                        TimeSpan diff = endDate - startDate;
                        int days = diff.Days;
                        for (var i = 0; i <= days; i++)
                        {
                            var testDate = startDate.AddDays(i);
                            switch (testDate.DayOfWeek)
                            {
                                case DayOfWeek.Saturday:
                                case DayOfWeek.Sunday:
                                    date.Rows.Add(testDate.ToString(fmt));
                                    break;
                            }
                        }
                    }
                    else
                    {
                        int Year = Convert.ToInt32(DateTime.Now.ToString("yyyy"));
                        DateTime startDate = new DateTime(Year, 1, 1);
                        DateTime endDate = new DateTime(Year, 12, 31);

                        date.Columns.Add("date");
                        TimeSpan diff = endDate - startDate;
                        int days = diff.Days;
                        for (var i = 0; i <= days; i++)
                        {
                            var testDate = startDate.AddDays(i);
                            switch (testDate.DayOfWeek)
                            {
                                case DayOfWeek.Friday:
                                case DayOfWeek.Saturday:
                                    date.Rows.Add(testDate.ToString(fmt));
                                    break;
                            }
                        }
                    }
                    date.Merge(table);

                }
                //************************************************

                DataView v = date.DefaultView;
                v.Sort = "Holiday_Date";
                System.Data.DataTable d = new System.Data.DataTable();
                d = v.ToTable();
                try
                {
                    for (int i = 0; i <= d.Rows.Count - 1; i++)
                    {
                        if (d.Rows[i][0].ToString() != "")
                        {

                            string d1 = DateTime.Now.AddDays(-1).ToString("MM/dd/yyyy");
                            string d2 = DateTime.Now.AddDays(-2).ToString("MM/dd/yyyy");
                            string d3 = DateTime.Now.AddDays(-3).ToString("MM/dd/yyyy");
                            string d4 = DateTime.Now.AddDays(-4).ToString("MM/dd/yyyy");
                            string d5 = DateTime.Now.AddDays(-5).ToString("MM/dd/yyyy");
                            actd = Convert.ToDateTime(d.Rows[i][0]).ToString("MM/dd/yyyy");
                            if (d1 == actd)
                            {
                                datefound = 1;
                                day = day + 1;
                                actd = Convert.ToDateTime(d.Rows[i - 1][0]).ToString("MM/dd/yyyy");
                                if (d2 == actd)
                                {
                                    day = day + 1;
                                    actd = Convert.ToDateTime(d.Rows[i - 2][0]).ToString("MM/dd/yyyy");
                                    if (d3 == actd)
                                    {
                                        day = day + 1;
                                        actd = Convert.ToDateTime(d.Rows[i - 3][0]).ToString("MM/dd/yyyy");
                                        if (d4 == actd)
                                        {
                                            day = day + 1;
                                            actd = Convert.ToDateTime(d.Rows[i - 4][0]).ToString("MM/dd/yyyy");
                                            if (d5 == actd)
                                            {
                                                day = day + 1;
                                                actd = Convert.ToDateTime(d.Rows[i - 5][0]).ToString("MM/dd/yyyy");
                                            }
                                        }
                                    }
                                }
                            }
                        }


                    }


                    if (datefound == 0)
                    {
                        //MessageBox.Show("Pick yesterdays File");
                        Final_Date = DateTime.Now.AddDays(-1).ToString("MM/dd/yyyy");
                    }
                    else
                    {
                        //MessageBox.Show("Pick " + (day + 1).ToString() + " Days before File");
                        int t = 0;
                        t = t - (day + 1);
                        Final_Date = DateTime.Now.AddDays(t).ToString("MM/dd/yyyy");

                    }
                }
                catch
                {
                    MessageBox.Show("");
                }

            }
            catch
            {
                return null;

            }

            string[] Date = Final_Date.Split(' ');
            if (Date[0].ToString().Contains("/"))
            {
                string[] Date_Final = Date[0].Split('/');

                Final_Date = "";
                if (Date_Final[1].Length == 1 && Date_Final[0].Length == 2)
                {
                    Final_Date = "0" + Date_Final[1] + Date_Final[0] + Date_Final[2];
                }
                else if (Date_Final[1].Length == 2 && Date_Final[0].Length == 1)
                {
                    Final_Date = Date_Final[1] + "0" + Date_Final[0] + Date_Final[2];
                }
                else if (Date_Final[1].Length == 1 && Date_Final[0].Length == 1)
                {
                    Final_Date = "0" + Date_Final[1] + "0" + Date_Final[0] + Date_Final[2];
                }
                else if (Date_Final[1].Length == 2 && Date_Final[0].Length == 2)
                {
                    Final_Date = Date_Final[1] + Date_Final[0] + Date_Final[2];
                }
            }
            else if (Date[0].ToString().Contains("."))
            {
                string[] Date_Final = Date[0].Split('.');

                Final_Date = "";
                if (Date_Final[1].Length == 1 && Date_Final[0].Length == 2)
                {
                    Final_Date = "0" + Date_Final[1] + Date_Final[0] + Date_Final[2];
                }
                else if (Date_Final[1].Length == 2 && Date_Final[0].Length == 1)
                {
                    Final_Date = Date_Final[1] + "0" + Date_Final[0] + Date_Final[2];
                }
                else if (Date_Final[1].Length == 1 && Date_Final[0].Length == 1)
                {
                    Final_Date = "0" + Date_Final[1] + "0" + Date_Final[0] + Date_Final[2];
                }
                else if (Date_Final[1].Length == 2 && Date_Final[0].Length == 2)
                {
                    Final_Date = Date_Final[1] + Date_Final[0] + Date_Final[2];
                }
            }
            else if (Date[0].ToString().Contains("-"))
            {
                string[] Date_Final = Date[0].Split('-');

                Final_Date = "";
                if (Date_Final[1].Length == 1 && Date_Final[0].Length == 2)
                {
                    Final_Date = "0" + Date_Final[1] + Date_Final[0] + Date_Final[2];
                }
                else if (Date_Final[1].Length == 2 && Date_Final[0].Length == 1)
                {
                    Final_Date = Date_Final[1] + "0" + Date_Final[0] + Date_Final[2];
                }
                else if (Date_Final[1].Length == 1 && Date_Final[0].Length == 1)
                {
                    Final_Date = "0" + Date_Final[1] + "0" + Date_Final[0] + Date_Final[2];
                }
                else if (Date_Final[1].Length == 2 && Date_Final[0].Length == 2)
                {
                    Final_Date = Date_Final[1] + Date_Final[0] + Date_Final[2];
                }
            }
            DateTime myDate = DateTime.ParseExact(Final_Date, "ddMMyyyy", System.Globalization.CultureInfo.InvariantCulture);

            Final_Date = myDate.ToString(Date_Format);

            return Final_Date;
        }

        public string Get_Recon_Date_For_Monday_Logic(string conStr, string CountryName, string Date_Format)
        {
            string Final_Date = string.Empty;
            string fmt = CultureInfo.CurrentCulture.DateTimeFormat.ShortDatePattern;
            try
            {
                int day = 0;
                string actd = "";
                int datefound = 0;
                System.Data.DataTable dt = new System.Data.DataTable();
                System.Data.DataTable table = new System.Data.DataTable();
                System.Data.DataTable date = new System.Data.DataTable();
                SqlConnection con = new SqlConnection(conStr);
                string Today = DateTime.Now.ToString("dddd");

                //string date = DateTime.Now.ToString("09/09/2017");
                //*************************************************************************
                SqlDataAdapter ad = new SqlDataAdapter("dbo.ARC_SP_Get_Holiday_Date", con);
                ad.SelectCommand.CommandType = CommandType.StoredProcedure;
                ad.SelectCommand.Parameters.AddWithValue("@Country_Name", CountryName);
                con.Open();
                ad.Fill(table);
                con.Close();

                if (table.Rows.Count > 0)
                {
                    if (Convert.ToString(table.Rows[0][2]).Trim() == "NonGulf")
                    {
                        int Year = Convert.ToInt32(DateTime.Now.ToString("yyyy"));
                        //DateTime EndOfYear = Convert.ToDateTime("31-12-" + Year + "");
                        DateTime startDate = new DateTime(Year, 1, 1);
                        DateTime endDate = new DateTime(Year, 12, 31);

                        date.Columns.Add("Holiday_Date", typeof(DateTime));
                        date.Columns.Add("Country_Id", typeof(long));
                        date.Columns.Add("Gulf");
                        TimeSpan diff = endDate - startDate;
                        int days = diff.Days;
                        for (var i = 0; i <= days; i++)
                        {
                            var testDate = startDate.AddDays(i);
                            try
                            {
                                switch (testDate.DayOfWeek)
                                {
                                    case DayOfWeek.Sunday:
                                        date.Rows.Add();
                                        date.Rows.Add(testDate.ToString(fmt));
                                        break;
                                }

                            }
                            catch
                            {

                            }
                        }
                        date.Merge(table);
                        ExecRemoveDuplicateRows(date, "Holiday_Date");
                    }
                }
                else
                {
                    SqlCommand ad1 = new SqlCommand("dbo.ARC_SP_Get_Holiday_Date_NoHoliday", con);
                    ad1.CommandType = CommandType.StoredProcedure;
                    ad1.Parameters.AddWithValue("@Country_Name", CountryName);
                    con.Open();
                    string Result = Convert.ToString(ad1.ExecuteScalar());

                    con.Close();

                    if (Result == "NonGulf")
                    {
                        int Year = Convert.ToInt32(DateTime.Now.ToString("yyyy"));
                        DateTime startDate = new DateTime(Year, 1, 1);
                        DateTime endDate = new DateTime(Year, 12, 31);

                        date.Columns.Add("date");
                        TimeSpan diff = endDate - startDate;
                        int days = diff.Days;
                        for (var i = 0; i <= days; i++)
                        {
                            var testDate = startDate.AddDays(i);
                            switch (testDate.DayOfWeek)
                            {
                                case DayOfWeek.Sunday:
                                    date.Rows.Add(testDate.ToString(fmt));
                                    break;
                            }
                        }
                    }
                    date.Merge(table);

                }
                //************************************************
                DataView v = date.DefaultView;
                v.Sort = "Holiday_Date";
                System.Data.DataTable d = new System.Data.DataTable();
                d = v.ToTable();

                for (int i = 0; i <= d.Rows.Count - 1; i++)
                {
                    if (d.Rows[i][0].ToString() != "")
                    {
                        string d1 = DateTime.Now.AddDays(-1).ToString("MM/dd/yyyy");
                        string d2 = DateTime.Now.AddDays(-2).ToString("MM/dd/yyyy");
                        string d3 = DateTime.Now.AddDays(-3).ToString("MM/dd/yyyy");
                        string d4 = DateTime.Now.AddDays(-4).ToString("MM/dd/yyyy");
                        string d5 = DateTime.Now.AddDays(-5).ToString("MM/dd/yyyy");
                        actd = Convert.ToDateTime(d.Rows[i][0]).ToString("MM/dd/yyyy");
                        if (d1 == actd)
                        {
                            datefound = 1;
                            day = day + 1;
                            actd = Convert.ToDateTime(d.Rows[i - 1][0]).ToString("MM/dd/yyyy");
                            if (d2 == actd)
                            {
                                day = day + 1;
                                actd = Convert.ToDateTime(d.Rows[i - 2][0]).ToString("MM/dd/yyyy");
                                if (d3 == actd)
                                {
                                    day = day + 1;
                                    actd = Convert.ToDateTime(d.Rows[i - 3][0]).ToString("MM/dd/yyyy");
                                    if (d4 == actd)
                                    {
                                        day = day + 1;
                                        actd = Convert.ToDateTime(d.Rows[i - 4][0]).ToString("MM/dd/yyyy");
                                        if (d5 == actd)
                                        {
                                            day = day + 1;
                                            actd = Convert.ToDateTime(d.Rows[i - 5][0]).ToString("MM/dd/yyyy");
                                        }
                                    }
                                }
                            }
                        }
                    }

                }
                if (datefound == 0)
                {
                    //MessageBox.Show("Pick yesterdays File");
                    Final_Date = DateTime.Now.AddDays(-1).ToString("MM/dd/yyyy");
                }
                else
                {
                    //MessageBox.Show("Pick " + (day + 1).ToString() + " Days before File");
                    int t = 0;
                    t = t - (day + 1);
                    Final_Date = DateTime.Now.AddDays(t).ToString("MM/dd/yyyy");
                }

                string[] Date = Final_Date.Split(' ');
                if (Date[0].ToString().Contains("/"))
                {
                    string[] Date_Final = Date[0].Split('/');

                    Final_Date = "";
                    if (Date_Final[1].Length == 1 && Date_Final[0].Length == 2)
                    {
                        Final_Date = "0" + Date_Final[1] + Date_Final[0] + Date_Final[2];
                    }
                    else if (Date_Final[1].Length == 2 && Date_Final[0].Length == 1)
                    {
                        Final_Date = Date_Final[1] + "0" + Date_Final[0] + Date_Final[2];
                    }
                    else if (Date_Final[1].Length == 1 && Date_Final[0].Length == 1)
                    {
                        Final_Date = "0" + Date_Final[1] + "0" + Date_Final[0] + Date_Final[2];
                    }
                    else if (Date_Final[1].Length == 2 && Date_Final[0].Length == 2)
                    {
                        Final_Date = Date_Final[1] + Date_Final[0] + Date_Final[2];
                    }
                }
                else if (Date[0].ToString().Contains("."))
                {
                    string[] Date_Final = Date[0].Split('.');

                    Final_Date = "";
                    if (Date_Final[1].Length == 1 && Date_Final[0].Length == 2)
                    {
                        Final_Date = "0" + Date_Final[1] + Date_Final[0] + Date_Final[2];
                    }
                    else if (Date_Final[1].Length == 2 && Date_Final[0].Length == 1)
                    {
                        Final_Date = Date_Final[1] + "0" + Date_Final[0] + Date_Final[2];
                    }
                    else if (Date_Final[1].Length == 1 && Date_Final[0].Length == 1)
                    {
                        Final_Date = "0" + Date_Final[1] + "0" + Date_Final[0] + Date_Final[2];
                    }
                    else if (Date_Final[1].Length == 2 && Date_Final[0].Length == 2)
                    {
                        Final_Date = Date_Final[1] + Date_Final[0] + Date_Final[2];
                    }
                }
                else if (Date[0].ToString().Contains("-"))
                {
                    string[] Date_Final = Date[0].Split('-');

                    Final_Date = "";
                    if (Date_Final[1].Length == 1 && Date_Final[0].Length == 2)
                    {
                        Final_Date = "0" + Date_Final[1] + Date_Final[0] + Date_Final[2];
                    }
                    else if (Date_Final[1].Length == 2 && Date_Final[0].Length == 1)
                    {
                        Final_Date = Date_Final[1] + "0" + Date_Final[0] + Date_Final[2];
                    }
                    else if (Date_Final[1].Length == 1 && Date_Final[0].Length == 1)
                    {
                        Final_Date = "0" + Date_Final[1] + "0" + Date_Final[0] + Date_Final[2];
                    }
                    else if (Date_Final[1].Length == 2 && Date_Final[0].Length == 2)
                    {
                        Final_Date = Date_Final[1] + Date_Final[0] + Date_Final[2];
                    }
                }
                DateTime myDate = DateTime.ParseExact(Final_Date, "ddMMyyyy", System.Globalization.CultureInfo.InvariantCulture);

                Final_Date = myDate.ToString(Date_Format);


                return Final_Date;
            }
            catch
            {
                //MessageBox.Show(ex.ToString());
                return null;
            }
        }

        public System.Data.DataTable ExecRemoveDuplicateRows(System.Data.DataTable table, string DistinctColumn)
        {
            try
            {
                ArrayList UniqueRecords = new ArrayList();
                ArrayList DuplicateRecords = new ArrayList();

                // Check if records is already added to UniqueRecords otherwise,
                // Add the records to DuplicateRecords
                foreach (DataRow dRow in table.Rows)
                {
                    if (UniqueRecords.Contains(dRow[DistinctColumn]))
                        DuplicateRecords.Add(dRow);
                    else
                        UniqueRecords.Add(dRow[DistinctColumn]);
                }

                // Remove duplicate rows from DataTable added to DuplicateRecords
                foreach (DataRow dRow in DuplicateRecords)
                {
                    table.Rows.Remove(dRow);
                }

                // Return the clean DataTable which contains unique records.
                return table;
            }
            catch
            {
                return null;
            }
        }

        public System.Data.DataTable CC_ONLINE_BILL2(string Source, string DestPath, string Recon_Name, string File_Name, string File_Ext, out double Amnt, string SharePath, int Flag, string ReconDate)
        {
            if (Flag == 0)
            {
                double ddd1 = 0.0f;
                Source = Source + File_Name + "." + File_Ext;
                string strConn1;
                System.Data.DataTable dtexcel1 = new System.Data.DataTable();
                string d = DateTime.Now.ToString("dd-MMM-yyyy");
                string filePath01 = SharePath + @"Files_For_Formatting_Or_Non_Formatting\ONLINE BILLERS\Formatting\ONLINE BILLERS.xls";
                if (filePath01.Substring(filePath01.LastIndexOf('.')).ToLower() == ".xls")
                    strConn1 = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + filePath01 + ";Extended Properties='Excel 8.0;HDR=YES'";
                else
                    strConn1 = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + filePath01 + ";Extended Properties=\"Excel 8.0;HDR=Yes;IMEX=1\"";
                OleDbConnection conn1 = new OleDbConnection(strConn1);
                conn1.Open();
                System.Data.DataTable schemaTable1 = conn1.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, new object[] { null, null, null, "TABLE" });


                try
                {

                    string sheet1 = "Sheet1$";
                    OleDbDataAdapter daexcel1 = null;
                    if (!sheet1.EndsWith("_"))
                    {
                        string query = "SELECT  * FROM [" + sheet1 + "]";
                        daexcel1 = new OleDbDataAdapter(query, conn1);
                        dtexcel1.Locale = CultureInfo.CurrentCulture;
                        daexcel1.Fill(dtexcel1);
                    }
                }
                catch
                {
                    //throw ex;
                }

                conn1.Close();
                int i3 = 0;
                System.Data.DataTable dt2 = new System.Data.DataTable();
                dt2.Columns.Add("Set");
                dt2.Columns.Add("Set Name");
                dt2.Columns.Add("Entry Date");
                dt2.Columns.Add("Value Date");
                dt2.Columns.Add("Message Feed");
                for (int j = 0; j <= dtexcel1.Rows.Count - 1; j++)
                {
                    string asa = dtexcel1.Rows[j][14].ToString();
                    string asb = dtexcel1.Rows[j][10].ToString();
                    if (asa.Contains("MER# 008649 ") && asb.Contains("L CR"))
                    {
                        dt2.Rows.Add();
                        dt2.Rows[i3][0] = dtexcel1.Rows[j][0];
                        dt2.Rows[i3][1] = dtexcel1.Rows[j][8];
                        dt2.Rows[i3][2] = asa;
                        dt2.Rows[i3][3] = dtexcel1.Rows[j][3];
                        dt2.Rows[i3][4] = dtexcel1.Rows[j][2];

                        i3 = i3 + 1;

                    }
                }
                System.Data.DataTable dtt = new System.Data.DataTable();
                dtt = getData(filePath01, dtexcel1.Rows.Count + 1);
                if (File.Exists(Source))
                {
                    System.Data.DataTable dd1 = new System.Data.DataTable();
                    dd1.Columns.Add("Line");
                    System.Data.DataTable dt = new System.Data.DataTable();
                    System.Data.DataTable dt1 = new System.Data.DataTable();
                    dt.Columns.Add("SEQ NUM");
                    dt.Columns.Add("CARD NUMBER");
                    dt.Columns.Add("TXN AMOUNT");
                    dt.Columns.Add("TXN DATE");
                    dt.Columns.Add("MERCHANT NUM");
                    dt.Columns.Add("DESCRIPTION");
                    string[] lines = System.IO.File.ReadAllLines(Source);

                    foreach (string line in lines)
                    {
                        if (line.Contains("CREDIT CARD") || line.Contains("CC ONLINE BILL") || line.Contains("SEQ NUM"))
                        {
                        }
                        else
                        {
                            dd1.Rows.Add(line);
                        }
                    }

                    for (int i = dd1.Rows.Count - 1; i >= 0; i--)
                    {
                        if (dd1.Rows[i][0].ToString().Trim() == "")
                        {
                            dd1.Rows.RemoveAt(i);
                        }
                    }

                    for (int i = 0; i <= dd1.Rows.Count - 2; i++)
                    {
                        dt.Rows.Add();
                        string[] ar = System.Text.RegularExpressions.Regex.Split(dd1.Rows[i][0].ToString(), @"\s{2,}");
                        if (ar.Length >= 6)
                        {

                            if (ar[3].ToString().Trim().Contains("."))
                            {
                                dt.Rows[i]["SEQ NUM"] = ar[1];
                                dt.Rows[i]["CARD NUMBER"] = ar[2];

                                dt.Rows[i]["TXN AMOUNT"] = ar[3];
                                dt.Rows[i]["TXN DATE"] = ar[4];
                                dt.Rows[i]["MERCHANT NUM"] = ar[5];
                                dt.Rows[i]["DESCRIPTION"] = ar[6];
                            }
                            else
                            {
                                MessageBox.Show("Amount Column is not Found");
                                break;
                            }

                        }
                    }

                    dt1.Columns.Add("SEQ NUM");
                    dt1.Columns.Add("CARD NUMBER");
                    dt1.Columns.Add("TXN AMOUNT");
                    dt1.Columns.Add("TXN DATE");
                    dt1.Columns.Add("MERCHANT NUM");
                    dt1.Columns.Add("DESCRIPTION");
                    int x = 0;

                    for (int i = 0; i <= dt.Rows.Count - 2; i++)
                    {
                        string a = dt.Rows[i]["MERCHANT NUM"].ToString().Trim();

                        if (a.Contains("008649"))
                        {
                            dt1.Rows.Add();
                            dt1.Rows[x]["SEQ NUM"] = dt.Rows[i]["SEQ NUM"];
                            dt1.Rows[x]["CARD NUMBER"] = dt.Rows[i]["CARD NUMBER"];
                            ddd1 = ddd1 + Convert.ToDouble(dt.Rows[i]["TXN AMOUNT"].ToString());
                            dt1.Rows[x]["TXN AMOUNT"] = dt.Rows[i]["TXN AMOUNT"];
                            dt1.Rows[x]["TXN DATE"] = dt.Rows[i]["TXN DATE"];
                            dt1.Rows[x]["MERCHANT NUM"] = dt.Rows[i]["MERCHANT NUM"];
                            dt1.Rows[x]["DESCRIPTION"] = dt.Rows[i]["DESCRIPTION"];
                            x++;

                        }
                        else
                        {

                        }
                    }
                    System.Data.DataTable d3 = new System.Data.DataTable();

                    d3.Columns.Add("OPBAL", typeof(double));
                    d3.Columns.Add("OPBALCY");
                    d3.Columns.Add("OPBALDATE");
                    d3.Columns.Add("OPBALTP");
                    d3.Columns.Add("MTYPE");
                    d3.Columns.Add("SIDE");
                    d3.Columns.Add("STMTNO");
                    d3.Columns.Add("STMTPG");
                    d3.Columns.Add("SUBACC");
                    d3.Columns.Add("OURREF");
                    d3.Columns.Add("REFERENCE 4");
                    d3.Columns.Add("AMOUNT");
                    d3.Columns.Add("SIGN");
                    d3.Columns.Add("ENTRY DATE");
                    d3.Columns.Add("REFERENCE 1");
                    d3.Columns.Add("REFERENCE 2", typeof(string));
                    d3.Columns.Add("REFERENCE 3", typeof(string));
                    d3.Columns.Add("TRANSACTION CODE");
                    d3.Columns.Add("VALUE DATE");
                    d3.Columns.Add("CLBAL", typeof(string));
                    d3.Columns.Add("CLBALCY");
                    d3.Columns.Add("CLBALDATE");
                    d3.Columns.Add("CLBALTP");
                    string a11 = ReconDate.ToString().Substring(0, 2) + "/" + ReconDate.ToString().Substring(2, 2) + "/" + ReconDate.ToString().Substring(4, 2);
                    for (int i = 0; i <= dt2.Rows.Count - 1; i++)
                    {
                        dt2.Rows[i][3] = dtt.Rows[i][0];
                    }
                    int i1 = 0;
                    for (int i = 0; i <= dt2.Rows.Count - 1; i++)
                    {
                        string[] cmp1 = dt2.Rows[i][1].ToString().Split('.');
                        string[] cmp2 = ddd1.ToString().Replace(",", "").Split('.');
                        if (cmp1[0].ToString().Trim() == cmp2[0].ToString().Trim())
                        {
                            d3.Rows.Add();
                            string[] daa = dt2.Rows[i][3].ToString().Split(' ');
                            string[] daa1 = daa[0].ToString().Split('/');
                            d3.Rows[i1]["OPBAL"] = dt2.Rows[i][1];
                            d3.Rows[i1]["OPBALCY"] = "MYR";

                            d3.Rows[i1]["OPBALDATE"] = a11; //add recon date

                            if (daa1[0].Length == 1 && daa1[1].Length == 1)
                            {
                                d3.Rows[i1]["ENTRY DATE"] = "0" + daa1[1] + "/" + "0" + daa1[0] + "/" + "20" + daa1[2]; //add recon date
                                d3.Rows[i1]["VALUE DATE"] = "0" + daa1[1] + "/" + "0" + daa1[0] + "/" + "20" + daa1[2];
                            }
                            else if (daa1[1].Length == 1 && daa1[0].Length != 1)
                            {
                                d3.Rows[i1]["ENTRY DATE"] = "0" + daa1[1] + "/" + daa1[0] + "/" + "20" + daa1[2];
                                d3.Rows[i1]["VALUE DATE"] = "0" + daa1[1] + "/" + daa1[0] + "/" + "20" + daa1[2];
                            }
                            else if (daa1[1].Length != 1 && daa1[0].Length == 1)
                            {
                                d3.Rows[i1]["ENTRY DATE"] = daa1[1] + "/" + "0" + daa1[0] + "/" + "20" + daa1[2];
                                d3.Rows[i1]["VALUE DATE"] = daa1[1] + "/" + "0" + daa1[0] + "/" + "20" + daa1[2];
                            }
                            else
                            {
                                d3.Rows[i1]["ENTRY DATE"] = daa1[1] + "/" + daa1[0] + "/" + "20" + daa1[2];
                                d3.Rows[i1]["VALUE DATE"] = daa1[1] + "/" + daa1[0] + "/" + "20" + daa1[2];
                            }


                            d3.Rows[i1]["OPBALTP"] = "F";
                            d3.Rows[i1]["MTYPE"] = "";
                            d3.Rows[i1]["SIDE"] = "L";
                            d3.Rows[i1]["STMTNO"] = "2";
                            d3.Rows[i1]["STMTPG"] = "1";
                            d3.Rows[i1]["SUBACC"] = dt2.Rows[i][4]; //Need to Add
                            d3.Rows[i1]["OURREF"] = "";
                            d3.Rows[i1]["REFERENCE 4"] = "";

                            d3.Rows[i1]["AMOUNT"] = dt2.Rows[i][1];
                            d3.Rows[i1]["SIGN"] = "D";
                            //string[] m1 = dt1.Rows[i][3].ToString().Split('/');

                            d3.Rows[i1]["REFERENCE 1"] = "MST";
                            d3.Rows[i1]["REFERENCE 2"] = "'";
                            d3.Rows[i1]["REFERENCE 3"] = "REVERSAL";


                            d3.Rows[i1]["TRANSACTION CODE"] = "SPLT";

                            d3.Rows[i1]["CLBAL"] = d3.Rows[0][0].ToString();
                            d3.Rows[i1]["CLBALCY"] = "MYR";

                            d3.Rows[i1]["CLBALDATE"] = a11; //add recon date

                            d3.Rows[i1]["CLBALTP"] = "F";
                            i1++;
                        }
                    }
                    System.Data.DataTable d4 = new System.Data.DataTable();
                    d4 = d3.Clone();
                    int i2 = 0;

                    try
                    {
                        for (int i = 0; i <= dt1.Rows.Count - 1; i++)
                        {
                            string[] cmp1 = d3.Rows[0][0].ToString().Split('.');
                            string[] cmp2 = ddd1.ToString().Replace(",", "").Split('.');
                            if (cmp1[0].ToString().Trim() == cmp2[0].ToString().Trim() || dt1.Rows[i][0].ToString().Trim() != "")
                            {
                                d4.Rows.Add();
                                string[] daa = d3.Rows[0][2].ToString().Split(' ');
                                string[] daa1 = daa[0].ToString().Split('/');
                                d4.Rows[i2]["OPBAL"] = d3.Rows[0][0].ToString();
                                d4.Rows[i2]["OPBALCY"] = "MYR";

                                d4.Rows[i2]["OPBALDATE"] = a11; //add recon date

                                if (daa1[0].Length == 1 && daa1[1].Length == 1)
                                {
                                    d4.Rows[i2]["ENTRY DATE"] = "0" + daa1[0] + "/" + "0" + daa1[1] + "/" + "20" + daa1[2]; //add recon date
                                    d4.Rows[i2]["VALUE DATE"] = "0" + daa1[0] + "/" + "0" + daa1[1] + "/" + "20" + daa1[2];
                                }
                                else if (daa1[1].Length == 1 && daa1[0].Length != 1)
                                {
                                    d4.Rows[i2]["ENTRY DATE"] = "0" + daa1[0] + "/" + daa1[1] + "/" + "20" + daa1[2];
                                    d4.Rows[i2]["VALUE DATE"] = "0" + daa1[0] + "/" + daa1[1] + "/" + "20" + daa1[2];
                                }
                                else if (daa1[1].Length != 1 && daa1[0].Length == 1)
                                {
                                    d4.Rows[i2]["ENTRY DATE"] = daa1[0] + "/" + "0" + daa1[1] + "/" + "20" + daa1[2];
                                    d4.Rows[i2]["VALUE DATE"] = daa1[0] + "/" + "0" + daa1[1] + "/" + "20" + daa1[2];
                                }
                                else
                                {
                                    d4.Rows[i2]["ENTRY DATE"] = daa1[0] + "/" + daa1[1] + "/" + "20" + daa1[2];
                                    d4.Rows[i2]["VALUE DATE"] = daa1[0] + "/" + daa1[1] + "/" + "20" + daa1[2];
                                }


                                d4.Rows[i2]["OPBALTP"] = "F";
                                d4.Rows[i2]["MTYPE"] = "";
                                d4.Rows[i2]["SIDE"] = "L";
                                d4.Rows[i2]["STMTNO"] = "2";
                                d4.Rows[i2]["STMTPG"] = "1";
                                d4.Rows[i2]["SUBACC"] = d3.Rows[0][8].ToString(); //Need to Add
                                d4.Rows[i2]["OURREF"] = "";
                                d4.Rows[i2]["REFERENCE 4"] = "";


                                d4.Rows[i2]["AMOUNT"] = dt1.Rows[i]["TXN AMOUNT"];// dt2.Rows[i][1];
                                d4.Rows[i2]["SIGN"] = "C";
                                //string[] m1 = dt1.Rows[i][3].ToString().Split('/');

                                d4.Rows[i2]["REFERENCE 1"] = "MST";
                                d4.Rows[i2]["REFERENCE 2"] = "'" + dt1.Rows[i]["CARD NUMBER"];
                                d4.Rows[i2]["REFERENCE 3"] = dt1.Rows[i]["DESCRIPTION"];


                                d4.Rows[i2]["TRANSACTION CODE"] = "SPLT";

                                d4.Rows[i2]["CLBAL"] = d3.Rows[0][0].ToString();
                                d4.Rows[i2]["CLBALCY"] = "MYR";

                                d4.Rows[i2]["CLBALDATE"] = a11; //add recon date

                                d4.Rows[i2]["CLBALTP"] = "F";
                                i2++;
                            }
                        }
                    }
                    catch
                    {
                        //throw ex;
                    }
                    d3.Merge(d4);

                    ExportToExcel(d3, ref DestPath, Recon_Name, DestPath, SharePath, Flag);
                    FileRename(Directory_Temp, Recon_Name, SharePath, DestPath, ReconDate, File_Name);
                    Amnt = 0;
                    return d3;
                }
                else
                {
                    MessageBox.Show("CC ONL Billers File Not Found");
                    Amnt = 0;
                    return null;
                }
            }
            else if (Flag == 1)
            {
                double doo = 0.0f;
                Source = Source + File_Name + "." + File_Ext;
                //DestPath = DestPath + File_Name + ".xlsx";

                System.Data.DataTable dd1 = new System.Data.DataTable();
                dd1.Columns.Add("Line");
                System.Data.DataTable dt = new System.Data.DataTable();
                System.Data.DataTable dt1 = new System.Data.DataTable();

                dt.Columns.Add("SEQ NUM");
                dt.Columns.Add("CARD NUMBER");
                dt.Columns.Add("TXN AMOUNT");
                dt.Columns.Add("TXN DATE");
                dt.Columns.Add("MERCHANT NUM");
                dt.Columns.Add("DESCRIPTION");
                dt1 = dt.Clone();
                if (File.Exists(Source))
                {
                    string[] lines = System.IO.File.ReadAllLines(Source);

                    foreach (string line in lines)
                    {
                        if (line.Contains("CREDIT CARD") || line.Contains("CC ONLINE BILL") || line.Contains("SEQ NUM"))
                        {
                        }
                        else
                        {
                            dd1.Rows.Add(line);
                        }
                    }

                    for (int i = dd1.Rows.Count - 1; i >= 0; i--)
                    {
                        if (dd1.Rows[i][0].ToString().Trim() == "")
                        {
                            dd1.Rows.RemoveAt(i);
                        }
                    }

                    for (int i = 0; i <= dd1.Rows.Count - 2; i++)
                    {
                        dt.Rows.Add();
                        string[] ar = System.Text.RegularExpressions.Regex.Split(dd1.Rows[i][0].ToString(), @"\s{2,}");
                        if (ar.Length >= 6)
                        {

                            if (ar[3].ToString().Trim().Contains("."))
                            {
                                dt.Rows[i]["SEQ NUM"] = ar[1];
                                dt.Rows[i]["CARD NUMBER"] = ar[2];

                                dt.Rows[i]["TXN AMOUNT"] = ar[3];
                                dt.Rows[i]["TXN DATE"] = ar[4];
                                dt.Rows[i]["MERCHANT NUM"] = ar[5];
                                dt.Rows[i]["DESCRIPTION"] = ar[6];
                            }
                            else
                            {
                                //MessageBox.Show("Amount Column is not Found");
                                break;
                            }

                        }
                    }
                    int x = 0;

                    for (int i = 0; i <= dt.Rows.Count - 2; i++)
                    {
                        string a = dt.Rows[i]["MERCHANT NUM"].ToString().Trim();

                        if (a.Contains("000331"))
                        {

                            dt1.Rows.Add();
                            dt1.Rows[x]["SEQ NUM"] = dt.Rows[i]["SEQ NUM"];
                            dt1.Rows[x]["CARD NUMBER"] = dt.Rows[i]["CARD NUMBER"];
                            doo = doo + Convert.ToDouble(dt.Rows[i]["TXN AMOUNT"]);
                            dt1.Rows[x]["TXN AMOUNT"] = dt.Rows[i]["TXN AMOUNT"];
                            dt1.Rows[x]["TXN DATE"] = dt.Rows[i]["TXN DATE"];
                            dt1.Rows[x]["MERCHANT NUM"] = dt.Rows[i]["MERCHANT NUM"];
                            dt1.Rows[x]["DESCRIPTION"] = dt.Rows[i]["DESCRIPTION"];
                            x++;
                        }
                        else
                        {
                            //Do Nothing  
                        }
                    }
                    if (dt1.Rows.Count > 0)
                    {
                        ExportToExcel(dt1, ref DestPath, Recon_Name, DestPath, SharePath, Flag);
                    }
                    Amnt = doo;
                    return dt1;
                }
                else
                {
                    Amnt = 0;
                    return dt1;
                    //MessageBox.Show("CC ONL Text not in Path");
                }
            }
            else
            {
                Amnt = 0;
                return null;
            }
        }

        public System.Data.DataTable ONLINE_BILLERS_DUMP(out double Amount, string Share_Path, int Flag)
        {

            string filePath2 = Share_Path + "Input\\Emails\\ONLINE BILLERS.xlsx";
            double ddd = 0.0f;
            System.Data.DataTable dump = new System.Data.DataTable();
            try
            {
                if (File.Exists(filePath2))
                {
                    string strConn2;

                    if (filePath2.Substring(filePath2.LastIndexOf('.')).ToLower() == ".xlsx")
                        //strConn = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + filePath1 + ";Password=hrg17;Extended Properties=\"Excel 12.0;HDR=Yes;IMEX=1\"";
                        strConn2 = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + filePath2 + ";Extended Properties=\"Excel 12.0;HDR=Yes;IMEX=1\"";
                    //strConn = "Provider=Microsoft.Jet.OleDb.4.0; Data Source = " + System.IO.Path.GetDirectoryName(ExcelfilePath) + "; Extended Properties = 'text;HDR=YES;IMEX=1v;FMT=Delimited(,)';";
                    else
                        strConn2 = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + filePath2 + ";Extended Properties=\"Excel 8.0;HDR=Yes;IMEX=1\"";
                    System.Data.DataTable dtexcel2 = new System.Data.DataTable();
                    OleDbConnection conn2 = new OleDbConnection(strConn2);
                    try
                    {

                        conn2.Open();
                    }
                    catch
                    {
                        //throw ex;
                    }
                    System.Data.DataTable schemaTable2 = conn2.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, new object[] { null, null, null, "TABLE" });
                    DataRow schemaRow2 = schemaTable2.Rows[0];
                    string sheet2 = schemaRow2["TABLE_NAME"].ToString();
                    if (!sheet2.EndsWith("_"))
                    {
                        string query = "SELECT  * FROM [" + sheet2 + "]";
                        OleDbDataAdapter daexcel2 = new OleDbDataAdapter(query, conn2);
                        dtexcel2.Locale = CultureInfo.CurrentCulture;
                        daexcel2.Fill(dtexcel2);


                    }
                    dump = dtexcel2.Clone();
                    int y = 0;

                    for (int i = 0; i <= dtexcel2.Rows.Count - 1; i++)
                    {
                        if (dtexcel2.Rows[i][0].ToString().Trim() == "CA-MY-COD-MYR-003" && dtexcel2.Rows[i][6].ToString().Trim() == "L CR" && dtexcel2.Rows[i][9].ToString().Trim().Contains("000331"))
                        {
                            dump.Rows.Add();
                            ddd = ddd + Convert.ToDouble(dtexcel2.Rows[i][3]);
                            dump.Rows[y][0] = dtexcel2.Rows[i][0];
                            dump.Rows[y][1] = dtexcel2.Rows[i][1];
                            dump.Rows[y][2] = dtexcel2.Rows[i][2];
                            dump.Rows[y][3] = dtexcel2.Rows[i][3];
                            dump.Rows[y][4] = dtexcel2.Rows[i][4];
                            dump.Rows[y][5] = dtexcel2.Rows[i][5];
                            dump.Rows[y][6] = dtexcel2.Rows[i][6];
                            dump.Rows[y][7] = dtexcel2.Rows[i][7];
                            dump.Rows[y][8] = dtexcel2.Rows[i][8];
                            dump.Rows[y][9] = dtexcel2.Rows[i][9];
                            dump.Rows[y][10] = dtexcel2.Rows[i][10];
                            dump.Rows[y][11] = dtexcel2.Rows[i][11];
                            dump.Rows[y][12] = dtexcel2.Rows[i][12];
                            dump.Rows[y][13] = dtexcel2.Rows[i][13];
                            dump.Rows[y][14] = dtexcel2.Rows[i][14];
                            dump.Rows[y][15] = dtexcel2.Rows[i][15];
                            dump.Rows[y][16] = dtexcel2.Rows[i][16];
                            dump.Rows[y][17] = dtexcel2.Rows[i][17];
                            dump.Rows[y][18] = dtexcel2.Rows[i][18];
                            dump.Rows[y][19] = dtexcel2.Rows[i][19];
                            dump.Rows[y][20] = dtexcel2.Rows[i][20];
                            y++;
                        }
                    }
                }
                else
                {
                    //MessageBox.Show("Online Billers Dump File not in Path");
                }
                dump.Rows.Add(ddd);
                Amount = ddd;
                return dump;
            }
            catch
            {
                Amount = 0;
                return null;
            }
        }

        public void MBF_BILL_PAYMENT_RECON_REPORT(string Source, string DestPath, string Recon_Name, string File_Name, string File_Ext, System.Data.DataTable dump, System.Data.DataTable dt1, string SharePath, int Flag)
        {
            Source = Source + File_Name + "." + File_Ext;
            System.Data.DataTable d2 = new System.Data.DataTable();
            string Flags = string.Empty;
            if (File.Exists(Source))
            {
                //string HDR = hasHeaders ? "Yes" : "No";
                string strConn;

                if (Source.Substring(Source.LastIndexOf('.')).ToLower() == ".xlsx")
                    //strConn = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + filePath1 + ";Password=hrg17;Extended Properties=\"Excel 12.0;HDR=Yes;IMEX=1\"";
                    strConn = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + Source + ";Extended Properties=\"Excel 12.0;HDR=Yes;IMEX=1\"";
                //strConn = "Provider=Microsoft.Jet.OleDb.4.0; Data Source = " + System.IO.Path.GetDirectoryName(ExcelfilePath) + "; Extended Properties = 'text;HDR=YES;IMEX=1v;FMT=Delimited(,)';";
                else
                    strConn = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + Source + ";Extended Properties=\"Excel 8.0;HDR=Yes;IMEX=1\"";
                System.Data.DataTable dtexcel = new System.Data.DataTable();
                OleDbConnection conn = new OleDbConnection(strConn);
                try
                {
                    excel = new Excel.Application();
                    excelworkBook = excel.Workbooks.Open(Source, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                    conn.Open();
                }
                catch
                {
                }
                System.Data.DataTable schemaTable = conn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, new object[] { null, null, null, "TABLE" });

                DataRow schemaRow = schemaTable.Rows[0];
                string sheet = schemaRow["TABLE_NAME"].ToString();
                if (!sheet.EndsWith("_"))
                {
                    string query = "SELECT  * FROM [" + sheet + "]";
                    OleDbDataAdapter daexcel = new OleDbDataAdapter(query, conn);
                    dtexcel.Locale = CultureInfo.CurrentCulture;
                    daexcel.Fill(dtexcel);
                    d2 = dtexcel.Clone();

                }

                for (int i = 0; i <= d2.Rows.Count - 1; i++)
                {
                    d2.Rows.RemoveAt(i);
                }
                for (int i = 0; i <= dtexcel.Rows.Count - 1; i++)
                {
                    string a1 = dtexcel.Rows[i][0].ToString().Trim();
                    string a2 = dtexcel.Rows[i][1].ToString().Trim();
                    if (a1 == "SUSPENSE - CA MALAYSIA - EBS" && a2 == "CA-MY-COD-MYR-003")
                    {
                        d2.Rows.Add();
                        d2.Rows[i][0] = dtexcel.Rows[i][0];
                        d2.Rows[i][1] = dtexcel.Rows[i][1];
                        d2.Rows[i][2] = dtexcel.Rows[i][2];
                        d2.Rows[i][3] = dtexcel.Rows[i][3];
                        d2.Rows[i][4] = dtexcel.Rows[i][4];
                        d2.Rows[i][5] = dtexcel.Rows[i][5];
                        d2.Rows[i][6] = dtexcel.Rows[i][6];
                        DataColumnCollection columns = dtexcel.Columns;
                        if (columns.Contains("Closing Balance"))
                        {
                            d2.Rows[i][7] = dtexcel.Rows[i]["Closing Balance"];
                        }
                        else
                        {
                            Flags = "False";
                            break;
                        }
                        if (columns.Contains("Latest Stmt/Led Date"))
                        {
                            d2.Rows[i][8] = dtexcel.Rows[i]["Latest Stmt/Led Date"];
                        }
                        else
                        {
                            Flags = "False";
                            break;
                        }
                        d2.Rows[i][9] = dtexcel.Rows[i][9];
                        d2.Rows[i][10] = dtexcel.Rows[i][10];
                        d2.Rows[i][11] = dtexcel.Rows[i][11];
                        d2.Rows[i][12] = dtexcel.Rows[i][12];
                        d2.Rows[i][13] = dtexcel.Rows[i][13];
                        d2.Rows[i][14] = dtexcel.Rows[i][14];
                    }
                }
                if (Flags != "False")
                {
                    System.Data.DataTable d3 = new System.Data.DataTable();

                    d3.Columns.Add("OPBAL", typeof(double));
                    d3.Columns.Add("OPBALCY");
                    d3.Columns.Add("OPBALDATE");
                    d3.Columns.Add("OPBALTP");
                    d3.Columns.Add("MTYPE");
                    d3.Columns.Add("SIDE");
                    d3.Columns.Add("STMTNO");
                    d3.Columns.Add("STMTPG");
                    d3.Columns.Add("SUBACC");
                    d3.Columns.Add("AMOUNT");
                    d3.Columns.Add("SIGN");
                    d3.Columns.Add("ENTRY DATE");
                    d3.Columns.Add("REFERENCE 1");
                    d3.Columns.Add("REFERENCE 2", typeof(string));
                    d3.Columns.Add("REFERENCE 3", typeof(string));
                    d3.Columns.Add("TRANSACTION CODE");
                    d3.Columns.Add("VALUE DATE");
                    d3.Columns.Add("CLBAL", typeof(string));
                    d3.Columns.Add("CLBALCY");
                    d3.Columns.Add("CLBALDATE");
                    d3.Columns.Add("CLBALTP");
                    //string a11=GetReconDate();
                    string[] daa = d2.Rows[0][8].ToString().Split('/');

                    for (int i = 0; i <= dt1.Rows.Count - 1; i++)
                    {
                        d3.Rows.Add();


                        d3.Rows[i]["OPBAL"] = d2.Rows[0][7];
                        d3.Rows[i]["OPBALCY"] = "MYR";
                        if (daa[0].Length == 1 && daa[1].Length == 1)
                        {
                            d3.Rows[i]["OPBALDATE"] = "0" + daa[1] + "/" + "0" + daa[0] + "/" + daa[2]; //add recon date
                        }
                        else if (daa[1].Length == 1 && daa[0].Length != 1)
                        {
                            d3.Rows[i]["OPBALDATE"] = "0" + daa[1] + "/" + daa[0] + "/" + daa[2];
                        }
                        else if (daa[1].Length != 1 && daa[0].Length == 1)
                        {
                            d3.Rows[i]["OPBALDATE"] = daa[1] + "/" + "0" + daa[0] + "/" + daa[2];
                        }
                        else
                        {
                            d3.Rows[i]["OPBALDATE"] = daa[1] + "/" + daa[0] + "/" + daa[2];
                        }
                        d3.Rows[i]["OPBALTP"] = "F";
                        d3.Rows[i]["MTYPE"] = "";
                        d3.Rows[i]["SIDE"] = "L";
                        d3.Rows[i]["STMTNO"] = "2";
                        d3.Rows[i]["STMTPG"] = "1";
                        d3.Rows[i]["SUBACC"] = "MY312157063664MYR-EBS";


                        d3.Rows[i]["AMOUNT"] = dt1.Rows[i]["TXN AMOUNT"];
                        d3.Rows[i]["SIGN"] = "C";
                        string[] m1 = dt1.Rows[i]["TXN DATE"].ToString().Split('/');
                        d3.Rows[i]["ENTRY DATE"] = m1[0] + "/" + m1[1] + "/" + "20" + m1[2];
                        d3.Rows[i]["VALUE DATE"] = m1[0] + "/" + m1[1] + "/" + "20" + m1[2];
                        d3.Rows[i]["REFERENCE 1"] = "MST";
                        d3.Rows[i]["REFERENCE 2"] = "'" + dt1.Rows[i]["CARD NUMBER"];
                        d3.Rows[i]["REFERENCE 3"] = dt1.Rows[i]["DESCRIPTION"];


                        d3.Rows[i]["TRANSACTION CODE"] = "SPLT";

                        d3.Rows[i]["CLBAL"] = d2.Rows[0][7];
                        d3.Rows[i]["CLBALCY"] = "MYR";
                        if (daa[0].Length == 1 && daa[1].Length == 1)
                        {
                            d3.Rows[i]["CLBALDATE"] = "0" + daa[1] + "/" + "0" + daa[0] + "/" + daa[2]; //add recon date
                        }
                        else if (daa[1].Length == 1 && daa[0].Length != 1)
                        {
                            d3.Rows[i]["CLBALDATE"] = "0" + daa[1] + "/" + daa[0] + "/" + daa[2];
                        }
                        else if (daa[1].Length != 1 && daa[0].Length == 1)
                        {
                            d3.Rows[i]["CLBALDATE"] = daa[1] + "/" + "0" + daa[0] + "/" + daa[2];
                        }
                        else
                        {
                            d3.Rows[i]["CLBALDATE"] = daa[1] + "/" + daa[0] + "/" + daa[2];
                        }
                        d3.Rows[i]["CLBALTP"] = "F";
                    }
                    System.Data.DataTable d4 = new System.Data.DataTable();
                    d4 = d3.Clone();
                    for (int i = 0; i <= dump.Rows.Count - 2; i++)
                    {
                        d4.Rows.Add();


                        d4.Rows[i]["OPBAL"] = d2.Rows[0][7];
                        d4.Rows[i]["OPBALCY"] = "MYR";
                        if (daa[0].Length == 1 && daa[1].Length == 1)
                        {
                            d4.Rows[i]["OPBALDATE"] = "0" + daa[1] + "/" + "0" + daa[0] + "/" + daa[2]; //add recon date
                        }
                        else if (daa[1].Length == 1 && daa[0].Length != 1)
                        {
                            d4.Rows[i]["OPBALDATE"] = "0" + daa[1] + "/" + daa[0] + "/" + daa[2];
                        }
                        else if (daa[1].Length != 1 && daa[0].Length == 1)
                        {
                            d4.Rows[i]["OPBALDATE"] = daa[1] + "/" + "0" + daa[0] + "/" + daa[2];
                        }
                        else
                        {
                            d4.Rows[i]["OPBALDATE"] = daa[1] + "/" + daa[0] + "/" + daa[2];
                        }
                        d4.Rows[i]["OPBALTP"] = "F";
                        d4.Rows[i]["MTYPE"] = "";
                        d4.Rows[i]["SIDE"] = "L";
                        d4.Rows[i]["STMTNO"] = "2";
                        d4.Rows[i]["STMTPG"] = "1";
                        d4.Rows[i]["SUBACC"] = "MY312157063664MYR-EBS";


                        d4.Rows[i]["AMOUNT"] = dump.Rows[i][3];
                        d4.Rows[i]["SIGN"] = "D";
                        string[] m2 = dump.Rows[i][4].ToString().Split('/');
                        string[] m3 = dump.Rows[i][5].ToString().Split('/');
                        if (m2[0].Length == 1 && m2[1].Length == 1)
                        {
                            d4.Rows[i]["ENTRY DATE"] = "0" + m2[1] + "/" + "0" + m2[0] + "/" + m2[2]; //add recon date
                        }
                        else if (m2[1].Length == 1 && m2[0].Length != 1)
                        {
                            d4.Rows[i]["ENTRY DATE"] = "0" + m2[1] + "/" + m2[0] + "/" + m2[2];
                        }
                        else if (m2[1].Length != 1 && m2[0].Length == 1)
                        {
                            d4.Rows[i]["ENTRY DATE"] = m2[1] + "/" + "0" + m2[0] + "/" + m2[2];
                        }
                        else
                        {
                            d4.Rows[i]["ENTRY DATE"] = m2[1] + "/" + m2[0] + "/" + m2[2];
                        }

                        if (m3[0].Length == 1 && m3[1].Length == 1)
                        {
                            d4.Rows[i]["VALUE DATE"] = "0" + m3[1] + "/" + "0" + m3[0] + "/" + m3[2]; //add recon date
                        }
                        else if (m3[1].Length == 1 && m3[0].Length != 1)
                        {
                            d4.Rows[i]["VALUE DATE"] = "0" + m3[1] + "/" + m3[0] + "/" + m3[2];
                        }
                        else if (m3[1].Length != 1 && m3[0].Length == 1)
                        {
                            d4.Rows[i]["VALUE DATE"] = m3[1] + "/" + "0" + m3[0] + "/" + m3[2];
                        }
                        else
                        {
                            d4.Rows[i]["VALUE DATE"] = m3[1] + "/" + m3[0] + "/" + m3[2];
                        }
                        d4.Rows[i]["REFERENCE 1"] = "MST";
                        d4.Rows[i]["REFERENCE 2"] = "'" + dump.Rows[i][9];
                        d4.Rows[i]["REFERENCE 3"] = "REVERSAL";


                        d4.Rows[i]["TRANSACTION CODE"] = "SPLT";

                        d4.Rows[i]["CLBAL"] = d2.Rows[0][7];
                        d4.Rows[i]["CLBALCY"] = "MYR";
                        if (daa[0].Length == 1 && daa[1].Length == 1)
                        {
                            d4.Rows[i]["CLBALDATE"] = "0" + daa[1] + "/" + "0" + daa[0] + "/" + daa[2]; //add recon date
                        }
                        else if (daa[1].Length == 1 && daa[0].Length != 1)
                        {
                            d4.Rows[i]["CLBALDATE"] = "0" + daa[1] + "/" + daa[0] + "/" + daa[2];
                        }
                        else if (daa[1].Length != 1 && daa[0].Length == 1)
                        {
                            d4.Rows[i]["CLBALDATE"] = daa[1] + "/" + "0" + daa[0] + "/" + daa[2];
                        }
                        else
                        {
                            d4.Rows[i]["CLBALDATE"] = daa[1] + "/" + daa[0] + "/" + daa[2];
                        }
                        d4.Rows[i]["CLBALTP"] = "F";
                    }
                    d3.Merge(d4);
                    if (d3.Rows.Count > 0)
                    {
                        ExportToExcel(d3, ref DestPath, Recon_Name, DestPath, SharePath, Flag);
                    }
                }

            }

            else
            {
                MessageBox.Show("MBF File not in Path");
            }
        }

        public System.Data.DataTable getData(string path, int a)
        {
            Microsoft.Office.Interop.Excel.Application app = new Microsoft.Office.Interop.Excel.Application();
            Microsoft.Office.Interop.Excel.Workbook book = null;
            Microsoft.Office.Interop.Excel.Worksheet sheet = null;

            System.Data.DataTable d1 = new System.Data.DataTable();
            System.Data.DataTable d2 = new System.Data.DataTable();

            try
            {
                app.Visible = false;
                app.ScreenUpdating = false;
                app.DisplayAlerts = false;


                string execPath = Path.GetDirectoryName(Assembly.GetExecutingAssembly().CodeBase);

                book = app.Workbooks.Open(path, Missing.Value, Missing.Value, Missing.Value
                                                  , Missing.Value, Missing.Value, Missing.Value, Missing.Value
                                                 , Missing.Value, Missing.Value, Missing.Value, Missing.Value
                                                , Missing.Value, Missing.Value, Missing.Value);
                sheet = (Microsoft.Office.Interop.Excel.Worksheet)book.Sheets.get_Item("Sheet1");
                sheet = (Excel.Worksheet)book.Sheets.get_Item(1);

                d1.Columns.Add("DATE 1");

                d1.Columns.Add("FLD");
                d1.Columns.Add("FLD2");
                d2.Columns.Add("DATE 1");

                d2.Columns.Add("FLD");
                d2.Columns.Add("FLD2");
                //int a = dt.Rows.Count;
                //range=sheet.get_Range("D1", "E"+ a);
                //Microsoft.Office.Interop.Excel.Range r1 = (Microsoft.Office.Interop.Excel.Range)sheet.get_Range("B1", "C" + a);
                //r1.NumberFormat = "dd/MMM/yyyy";

                Range myRange = sheet.get_Range("D1", "D" + a);

                object excelDate = myRange.get_Value(Type.Missing);

                Range myRange1 = sheet.get_Range("O1", "O" + a);

                object excelDate1 = myRange1.get_Value(Type.Missing);

                Range myRange2 = sheet.get_Range("K1", "K" + a);

                object excelDate2 = myRange2.get_Value(Type.Missing);
                try
                {
                    int m = 0;
                    int n = 0;
                    int p = 0;
                    foreach (object item in (dynamic)excelDate)
                    {
                        d1.Rows.Add();
                        d1.Rows[m][0] = item;
                        m++;
                    }
                    foreach (object item in (dynamic)excelDate1)
                    {
                        d1.Rows[n][1] = item;
                        n++;
                    }
                    foreach (object item in (dynamic)excelDate2)
                    {
                        d1.Rows[p][2] = item;
                        p++;
                    }
                    int o = 0;
                    for (int i = 0; i <= d1.Rows.Count - 1; i++)
                    {
                        if (d1.Rows[i][1].ToString().Contains("MER# 008649") && d1.Rows[i][2].ToString().Contains("L CR"))
                        {
                            d2.Rows.Add();
                            d2.Rows[o][0] = d1.Rows[i][0];
                            d2.Rows[o][1] = d1.Rows[i][1];
                            d2.Rows[o][2] = d1.Rows[i][2];
                            o++;
                        }
                    }

                }
                catch
                {
                    MessageBox.Show("");
                }


            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
            finally
            {
                if (book != null)
                    book.Close(false, Missing.Value, Missing.Value);
                book = null;
                if (app != null)
                    app.Quit();
                app = null;
            }

            return d2;
        }

        public void ExportDTToExcel(System.Data.DataTable dt, string path)
        {
            Microsoft.Office.Interop.Excel.Application app = new Microsoft.Office.Interop.Excel.Application();
            app.Visible = false;
            app.DisplayAlerts = false;
            Microsoft.Office.Interop.Excel.Workbook wb = app.Workbooks.Add(Microsoft.Office.Interop.Excel.XlWBATemplate.xlWBATWorksheet);
            Microsoft.Office.Interop.Excel.Worksheet ws = (Microsoft.Office.Interop.Excel.Worksheet)wb.ActiveSheet;

            string culture = System.Threading.Thread.CurrentThread.CurrentCulture.ToString();//"en-GB";
            CultureInfo ci = new CultureInfo(culture);

            string excelGroupSeparator = app.ThousandsSeparator.ToString();
            string excelDecimalSeparator = app.DecimalSeparator.ToString();
            bool systemseparators = app.UseSystemSeparators;
            if (app.UseSystemSeparators == false)
            {
                app.DecimalSeparator = ci.NumberFormat.NumberDecimalSeparator;
                app.ThousandsSeparator = ci.NumberFormat.NumberGroupSeparator;
            }
            if (path.Contains("SCB_PHP_CLG_INWARD_EBS_"))
            {
                app.UseSystemSeparators = true;
            }
            else
            {
                
            }
            try
            {
                if(path.Contains("SCB_PHP_CLG_INWARD_EBS_"))
                {
                
                }
                else
                {
                for (int i = 0; i < dt.Columns.Count; i++)
                {
                    ws.Cells[1, i + 1] = dt.Columns[i].ColumnName;
                }
                }
                

                for (int j = 0; j < dt.Rows.Count; j++)
                {
                    for (int k = 0; k < dt.Columns.Count; k++)
                    {
                        if (k == 8)
                        {
                            SetCellDate(dt.Rows[j][8].ToString().Trim(), ws, j, 8);
                        }
                        else if (k == 3)
                        {
                            SetCellValue(dt.Rows[j][3].ToString().Trim(), ws, j, 3, path);
                        }
                        else
                        {
                            ws.Cells[j + 2, k + 1] = dt.Rows[j].ItemArray[k].ToString();
                        }
                    }
                }
                
                
                //for (int i = 0; i <= dt.Rows.Count - 1; i++)
                //{
                //    for (int j = 0; j <= dt.Columns.Count - 1; i++)
                //    {
                //        SetCellValue(dt.Rows[i][].ToString().Trim(), ws, i, j);
                //    }

                //}
                wb.SaveAs(path, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, XlSaveAsAccessMode.xlNoChange, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                //wb.SaveAs(path, Microsoft.Office.Interop.Excel.XlFileFormat.xlCSVWindows, Type.Missing, Type.Missing, false, false, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlExclusive, Microsoft.Office.Interop.Excel.XlSaveConflictResolution.xlLocalSessionChanges, false, Type.Missing, Type.Missing, Type.Missing);
                wb.Close(false, Type.Missing, false);
                app.DecimalSeparator = excelDecimalSeparator;
                app.ThousandsSeparator = excelGroupSeparator;
                app.UseSystemSeparators = systemseparators;
                app.Quit();
                ReleaseComObject(app);
                ReleaseComObject(wb);
                ReleaseComObject(ws);
                app = null;
                wb = null;
                ws = null;
            }
            catch
            {
                wb.Close(false, Type.Missing, false);
                app.Quit();
                ReleaseComObject(app);
                ReleaseComObject(wb);
                ReleaseComObject(ws);
            }
        }

        private static void SetCellValue(string data, Microsoft.Office.Interop.Excel.Worksheet ws, int row, int col,string path)
        {
            double val;
            
            try
            {
                val = Convert.ToDouble(data);
                
            }
            catch
            {
                return;
            }

            try
            {
                string s = val.ToString();
                ws.Cells[row + 2, col + 1] = s;
                if (path.Contains("SCB_PHP_CLG_INWARD_EBS_"))
                {
                    ws.Range["A:A", Type.Missing].NumberFormat = "@";
                    ws.Range["D:D", Type.Missing].NumberFormat = "#,###.00";
                    ws.Range["L:L", Type.Missing].NumberFormat = "@";
                }
                else
                { 
                
                }
            }
            catch
            {

            }
        }

        private static void SetCellDate(string data, Microsoft.Office.Interop.Excel.Worksheet ws, int row, int col)
        {
            DateTime val;

            try
            {
                if (data != "")
                {
                    val = Convert.ToDateTime(data);

                    string s = val.ToString("dd/MM/yyyy");
                    ws.Cells[row + 2, col + 1] = s;
                    ws.Range["I:I", Type.Missing].NumberFormat = "dd/MM/yyyy";
                }
            }
            catch
            {

            }
        }


        public void FileRenameForQatar(string path, string Share_Path, string Recon_Name, string Output_Path, string Recon_Date, string Formatted_File_Name)
        {
            string dt = DateTime.Now.ToString("yyyyMMdd");
            String inputDirectoryPat = path;

            string d = DateTime.Now.ToString("dd-MMM-yyyy");
            String inputFileNamePatter = @"*.csv";

            string files = "";
            if (Recon_Name == "Qatar Stock Recon")
            {
                files = Output_Path + Formatted_File_Name + ".csv";
                inputDirectoryPat = Output_Path;
            }

            string[] inputFilePaths = Directory.GetFiles(inputDirectoryPat, inputFileNamePatter);
            foreach (var inputFilePath in inputFilePaths)
            {
                if (Recon_Name == "Qatar Stock Recon" && inputFilePath.Contains("QADEPO_"))
                {
                    DirectoryInfo di = new DirectoryInfo(inputFilePath);

                    Microsoft.Office.Interop.Excel.Application app = new Microsoft.Office.Interop.Excel.Application();
                    Microsoft.Office.Interop.Excel.Workbook wb = app.Workbooks.Open(inputFilePath, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                    app.DisplayAlerts = false;
                    app.Visible = false;
                    // this does not throw exception if file doesnt exist


                    wb.SaveAs(files, Microsoft.Office.Interop.Excel.XlFileFormat.xlCSVWindows, Type.Missing, Type.Missing, false, false, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlExclusive, Microsoft.Office.Interop.Excel.XlSaveConflictResolution.xlLocalSessionChanges, false, Type.Missing, Type.Missing, Type.Missing);
                    wb.Close(false, Type.Missing, Type.Missing);
                    app.Quit();
                    ReleaseComObject(wb);
                    ReleaseComObject(app);

                }
            }
            if (Recon_Name == "Qatar Stock Recon") //DD_MM_YYYY
            {
                File.Move(Output_Path + Formatted_File_Name + ".csv", Path.ChangeExtension(Share_Path + Formatted_File_Name + ".csv", ".txt"));
                File.Delete(Share_Path + Formatted_File_Name + ".dat");
                Fileses(Share_Path, Recon_Name);
                File.Move(Share_Path + Formatted_File_Name + ".tlm", Path.ChangeExtension(Share_Path + Formatted_File_Name + ".tlm", ".dat"));
            }

        }

        // kiran add 6-6-2017
        public void KillSpecificExcelFileProcess(string excelFileName)
        {
            var processes = from p in Process.GetProcessesByName("EXCEL")
                            select p;

            foreach (var process in processes)
            {
                if (process.MainWindowTitle == "Microsoft Excel - " + excelFileName)
                    process.Kill();
            }
        }
        // kiran add 6-6-2017

        public void FileRename(string path, string Share_Path, string Recon_Name, string Output_Path, string Recon_Date, string Formatted_File_Name)
        {
            try
            {
                string dt = DateTime.Now.ToString("yyyyMMdd");
                String inputDirectoryPat = path;

                string d = DateTime.Now.ToString("dd-MMM-yyyy");
                String inputFileNamePatter = @"*.csv";

                string files = "";
                if (Recon_Name == "Thailand - Custody - Depo Recon")
                {
                    files = Output_Path + Formatted_File_Name + ".csv";
                }
                else if (Recon_Name == "India - CMPC Suspense" || Recon_Name == "Bank Indonesia Custody - Opics Position Reconciliation" || Recon_Name == "Jordan Stock recon open items")
                {
                    files = Output_Path + Formatted_File_Name + ".csv";
                    inputDirectoryPat = Share_Path;
                }
                else if (Recon_Name == "Qatar Stock Recon" || Recon_Name == "PHP INWARD CLEARING RECON - EOD")
                {
                    files = Output_Path + Formatted_File_Name + ".csv";
                    inputDirectoryPat = Output_Path;
                }

                string[] inputFilePaths = Directory.GetFiles(inputDirectoryPat, inputFileNamePatter);
                foreach (var inputFilePath in inputFilePaths)
                {
                    if (Recon_Name != "PHP INWARD CLEARING RECON - EOD")
                    {
                        DirectoryInfo di = new DirectoryInfo(inputFilePath);

                        Microsoft.Office.Interop.Excel.Application app = new Microsoft.Office.Interop.Excel.Application();
                        Microsoft.Office.Interop.Excel.Workbook wb = app.Workbooks.Open(inputFilePath, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                        app.DisplayAlerts = false;
                        app.Visible = false;
                        // this does not throw exception if file doesnt exist
                        File.Delete(files);

                        wb.SaveAs(files, Microsoft.Office.Interop.Excel.XlFileFormat.xlCSVWindows, Type.Missing, Type.Missing, false, false, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlExclusive, Microsoft.Office.Interop.Excel.XlSaveConflictResolution.xlLocalSessionChanges, false, Type.Missing, Type.Missing, Type.Missing);
                        wb.Close(false, Type.Missing, Type.Missing);
                        //wb.Close(
                        app.Quit();

                        string path1 = files.Substring(files.LastIndexOf("\\\\"));
                        ReleaseComObject(wb);
                        ReleaseComObject(app);
                        KillSpecificExcelFileProcess(path1);
                    }
                    if (Recon_Name == "Thailand - Custody - Depo Recon") //ddMMyyyy
                    {
                        File.Delete(Share_Path + "PSGL_5381077_PHPCLG_" + Recon_Date.Substring(Recon_Date.Length - 2, 2) + Recon_Date.Substring(Recon_Date.Length - 4, 2) + Recon_Date.Substring(Recon_Date.Length - 8, 4) + ".txt");
                        File.Move(files, Path.ChangeExtension(Share_Path + "PSGL_5381077_PHPCLG_" + Recon_Date + ".csv", ".txt"));
                        Fileses(Share_Path, Recon_Name);
                        break;
                    }
                    else if (Recon_Name == "Bank Indonesia Custody - Opics Position Reconciliation") //DD_MM_YYYY
                    {
                        File.Move(files, Path.ChangeExtension(Share_Path + Formatted_File_Name + ".csv", ".txt"));
                        Fileses(Share_Path, Recon_Name);
                        File.Delete(Share_Path + Formatted_File_Name + ".csv");
                        File.Move(Share_Path + Formatted_File_Name + ".dat", Output_Path + Formatted_File_Name + ".csv");
                        break;
                    }
                    else if (Recon_Name == "Qatar Stock Recon") //DD_MM_YYYY
                    {
                        File.Move(files, Path.ChangeExtension(Share_Path + Formatted_File_Name + ".csv", ".txt"));
                        File.Delete(Share_Path + Formatted_File_Name + ".dat");
                        Fileses(Share_Path, Recon_Name);
                        File.Move(Share_Path + Formatted_File_Name + ".tlm", Path.ChangeExtension(Share_Path + Formatted_File_Name + ".tlm", ".dat"));
                        break;
                    }
                    else if (Recon_Name == "India - CMPC Suspense") //DD_MM_YYYY
                    {
                        
                        File.Delete(Share_Path + Formatted_File_Name + ".csv");
                        File.Move(files, Output_Path + Formatted_File_Name + ".csv");

                    }
                    else if (Recon_Name == "Jordan Stock recon open items") //DD_MM_YYYY
                    {

                        File.Delete(Share_Path + Formatted_File_Name + ".csv");
                        File.Move(files, Path.ChangeExtension(Output_Path + Formatted_File_Name + ".csv", ".txt"));
                        Fileses(Output_Path, Recon_Name);

                    }
                    else if (Recon_Name == "PHP INWARD CLEARING RECON - EOD") //DD_MM_YYYY
                    {
                        File.Move(files, Path.ChangeExtension(Share_Path + Formatted_File_Name + ".csv", ".txt"));
                        File.Delete(Share_Path + Formatted_File_Name + ".dat");
                        Fileses(Share_Path, Recon_Name);
                        break;
                    }
                }
            }
            catch
            {

            }

        }

        public void Fileses(string share, string Recon_Name)
        {
            try
            {
                string str = "";
                if (Directory.Exists(share))
                {
                    string[] files = System.IO.Directory.GetFiles(share);
                    string name = "";

                    for (int i = 0; i <= files.Length - 1; i++)
                    {
                        if (files[i].Contains(".txt"))
                        {
                            str = files[i];

                            name = Path.GetFileName(str);
                            string text = File.ReadAllText(str);
                            text = text.Replace(",", "|");

                            File.WriteAllText(str, text);
                            // File.Copy(str, Path.ChangeExtension(destpath + name, ".tlm"));
                            // For multiple files
                            if (Recon_Name == "India - CMPC Suspense")
                            {
                                if (!File.Exists(share + Path.GetFileNameWithoutExtension(name) + ".tlm"))
                                {
                                    File.Move(str, Path.ChangeExtension(share + name, ".tlm"));
                                }
                            }
                            else if (Recon_Name == "PHP INWARD CLEARING RECON - EOD" || Recon_Name == "Jordan Stock recon open items")
                            {
                                if (str.Contains("SCB_PHP_CLG_INWARD_CB_") || str.Contains("JO_Custody_") || str.Contains("JO_Trading_"))
                                {
                                    File.Move(str, Path.ChangeExtension(share + name, ".dat"));
                                }
                            }
                            else if (Recon_Name == "Nigeria - Daily Bonds   T-BILLS Recon")
                            {
                                if (!File.Exists(share + Path.GetFileNameWithoutExtension(name) + ".dat"))
                                {
                                    File.Move(str, Path.ChangeExtension(share + name, ".dat"));
                                }

                                //Deleting the Input TXT file
                                if (File.Exists(share + Path.GetFileNameWithoutExtension(name) + ".txt"))
                                {
                                    File.Delete(share + Path.GetFileNameWithoutExtension(name) + ".txt");
                                }
                            }
                            else if (Recon_Name == "Bank Indonesia Custody - Opics Position Reconciliation")
                            {
                                if (!File.Exists(share + Path.GetFileNameWithoutExtension(name) + ".dat"))
                                {
                                    File.Move(str, Path.ChangeExtension(share + name, ".dat"));
                                }
                            }
                            else if (Recon_Name == "Nigeria - Daily Equity Position Recon")
                            {
                                if (!File.Exists(share + Path.GetFileNameWithoutExtension(name) + ".dat"))
                                {
                                    File.Move(str, Path.ChangeExtension(share + name, ".dat"));
                                }

                                //Deleting the Input TXT file
                                if (File.Exists(share + Path.GetFileNameWithoutExtension(name) + ".txt"))
                                {
                                    File.Delete(share + Path.GetFileNameWithoutExtension(name) + ".txt");
                                }
                            }
                            else
                            {
                                File.Move(str, Path.ChangeExtension(share + name, ".tlm"));
                            }
                            str = "";
                            name = "";
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Directory does not Exists");
                }
            }
            catch
            {
            }
        }

        //**************Malaysia EOD formattings**********************************//
        public System.Data.DataTable GetITT_Pending(string filePath, string Country)
        {
            System.Data.DataTable dtexcel1 = new System.Data.DataTable();
            System.Data.DataTable dtfinal1 = new System.Data.DataTable();
            string strConn1;
            bool hasHeaders1 = true;
            string HDR1 = hasHeaders1 ? "Yes" : "No";

            if (filePath.Substring(filePath.LastIndexOf('.')).ToLower() == ".xlsx")
                strConn1 = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + filePath + ";Extended Properties='Excel 8.0;HDR=YES'";
            else
                strConn1 = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + filePath + ";Extended Properties=\"Excel 8.0;HDR=" + HDR1 + ";IMEX=1\"";
            OleDbConnection conn1 = new OleDbConnection(strConn1);
            conn1.Open();
            System.Data.DataTable schemaTable1 = conn1.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, new object[] { null, null, null, "TABLE" });

            DataRow schemaRow = schemaTable1.Rows[0];
            string sheet1 = schemaRow["TABLE_NAME"].ToString();

            OleDbDataAdapter daexcel1 = null;
            if (!sheet1.EndsWith("_"))
            {
                string query = "SELECT  * FROM [Sheet1$]";
                daexcel1 = new OleDbDataAdapter(query, conn1);
                dtexcel1.Locale = CultureInfo.CurrentCulture;
                daexcel1.Fill(dtexcel1);
            }
            conn1.Close();

            string date = DateTime.Today.ToString("dd-MMM-yy");

            if (dtexcel1.Rows.Count > 0)
            {
                dtfinal1.Columns.Add("0.00");
                dtfinal1.Columns.Add(date);
                dtfinal1.Columns.Add("a");
                dtfinal1.Columns.Add("b");
                dtfinal1.Columns.Add("c");
                dtfinal1.Columns.Add("d");

                int k = -1;

                dtexcel1.Rows.RemoveAt(0);
                int cnt = dtexcel1.Rows.Count;
                dtexcel1.Rows.RemoveAt(cnt - 2);


                System.Data.DataTable dt = new System.Data.DataTable();
                dt.Columns.Add("0.00");
                dt.Columns.Add(date);
                dt.Columns.Add("a");
                dt.Columns.Add("b");
                dt.Columns.Add("c");
                dt.Columns.Add("d");

                if (Country.ToUpper() == "MALAYSIA")
                {
                    dtexcel1.AsEnumerable().Where(r => r.Field<string>(3) == "MYR").ToList().ForEach(row => row.Delete());
                    dtexcel1.AcceptChanges();
                }
                if (Country.ToUpper() == "PHILIPPINES")
                {
                    dtexcel1.AsEnumerable().Where(r => r.Field<string>(3) == "PHP").ToList().ForEach(row => row.Delete());
                    dtexcel1.AcceptChanges();
                }
                if (Country.ToUpper() == "INDONESIA")
                {
                    dtexcel1.AsEnumerable().Where(r => r.Field<string>(3) == "IDR").ToList().ForEach(row => row.Delete());
                    dtexcel1.AcceptChanges();
                }
                else if (Country.ToUpper() == "VIETNAM")
                {
                    dtexcel1.AsEnumerable().Where(r => r.Field<string>(3) == "VND").ToList().ForEach(row => row.Delete());
                    dtexcel1.AcceptChanges();
                }
                else if (Country.ToUpper() == "SINGAPORE")
                {
                    dtexcel1.AsEnumerable().Where(r => r.Field<string>(4) == "SGD").ToList().ForEach(row => row.Delete());
                    dtexcel1.AcceptChanges();
                }
                else if (Country.ToUpper() == "INDIA")
                {
                    dtexcel1.AsEnumerable().Where(r => r.Field<string>(3) == "INR").ToList().ForEach(row => row.Delete());
                    dtexcel1.AcceptChanges();
                }

                //for (int j = i + 1; j <= dtexcel1.Rows.Count - 1; j++)
                for (int j = 0; j <= dtexcel1.Rows.Count - 1; j++)
                {
                    bool issal = false;
                    var _branchId = string.Empty;
                    var _cur = string.Empty;
                    var _branchCode = string.Empty;
                    var _amt = string.Empty;

                    if (Country.ToUpper() == "MALAYSIA")
                    {
                        _branchId = dtexcel1.Rows[j][1] != null ? dtexcel1.Rows[j][1].ToString() : string.Empty;
                        _cur = dtexcel1.Rows[j][3] != null ? dtexcel1.Rows[j][3].ToString() : string.Empty;
                        _branchCode = dtexcel1.Rows[j][6] != null ? dtexcel1.Rows[j][6].ToString() : string.Empty;
                        _amt = dtexcel1.Rows[j][7] != null ? dtexcel1.Rows[j][7].ToString() : "0.00";
                    }
                    if (Country.ToUpper() == "PHILIPPINES")
                    {
                        _branchId = dtexcel1.Rows[j][1] != null ? dtexcel1.Rows[j][1].ToString() : string.Empty;
                        _cur = dtexcel1.Rows[j][3] != null ? dtexcel1.Rows[j][3].ToString() : string.Empty;
                        _branchCode = dtexcel1.Rows[j][6] != null ? dtexcel1.Rows[j][6].ToString() : string.Empty;
                        _amt = dtexcel1.Rows[j][7] != null ? dtexcel1.Rows[j][7].ToString() : "0.00";
                    }
                    else if (Country.ToUpper() == "INDONESIA")
                    {
                        _branchId = dtexcel1.Rows[j][1] != null ? dtexcel1.Rows[j][1].ToString() : string.Empty;
                        _cur = dtexcel1.Rows[j][3] != null ? dtexcel1.Rows[j][3].ToString() : string.Empty;
                        _branchCode = dtexcel1.Rows[j][6] != null ? dtexcel1.Rows[j][6].ToString() : string.Empty;
                        _amt = dtexcel1.Rows[j][7] != null ? dtexcel1.Rows[j][7].ToString() : "0.00";
                    }
                    else if (Country.ToUpper() == "VIETNAM")
                    {
                        _branchId = dtexcel1.Rows[j][1] != null ? dtexcel1.Rows[j][1].ToString() : string.Empty;
                        _cur = dtexcel1.Rows[j][3] != null ? dtexcel1.Rows[j][3].ToString() : string.Empty;
                        _branchCode = dtexcel1.Rows[j][6] != null ? dtexcel1.Rows[j][6].ToString() : string.Empty;
                        _amt = dtexcel1.Rows[j][7] != null ? dtexcel1.Rows[j][7].ToString() : "0.00";
                    }
                    else if (Country.ToUpper() == "SINGAPORE")
                    {
                        _branchId = dtexcel1.Rows[j][1] != null ? dtexcel1.Rows[j][1].ToString() : string.Empty;
                        _branchCode = dtexcel1.Rows[j][3] != null ? dtexcel1.Rows[j][3].ToString() : string.Empty;
                        _amt = dtexcel1.Rows[j][5] != null ? dtexcel1.Rows[j][5].ToString() : "0.00";
                        _cur = dtexcel1.Rows[j][4] != null ? dtexcel1.Rows[j][4].ToString() : string.Empty;
                    }
                    else if (Country.ToUpper() == "INDIA")
                    {
                        _branchId = dtexcel1.Rows[j][1] != null ? dtexcel1.Rows[j][1].ToString() : string.Empty;
                        _branchCode = dtexcel1.Rows[j][6] != null ? dtexcel1.Rows[j][6].ToString() : string.Empty;
                        _amt = dtexcel1.Rows[j][7] != null ? dtexcel1.Rows[j][7].ToString() : "0.00";
                        _cur = dtexcel1.Rows[j][3] != null ? dtexcel1.Rows[j][3].ToString() : string.Empty;
                    }

                    if (!string.IsNullOrWhiteSpace(_branchId) && !string.IsNullOrWhiteSpace(_branchCode) && !string.IsNullOrWhiteSpace(_cur))
                    {
                        issal = true;
                    }

                    if (issal)
                    {
                        dt.Rows.Add();
                        k = k + 1;

                        dt.Rows[k][0] = (_amt == "0" ? "0.00" : _amt);// String.Format("{0:0,0.00}", _amt);
                        if (Country.ToUpper() == "INDIA")
                        {
                            dt.Rows[k][1] = dtexcel1.Rows[j][8] != null ? Convert.ToDateTime(dtexcel1.Rows[j][8]).ToString("dd-MMM-yy") : string.Empty;
                            dt.Rows[k][2] = dtexcel1.Rows[j][9] != null ? Convert.ToDateTime(dtexcel1.Rows[j][9]).ToString("dd-MMM-yy") : string.Empty;
                        }
                        else
                        {
                            dt.Rows[k][1] = DateTime.Today.ToString("dd-MMM-yy");
                            dt.Rows[k][2] = DateTime.Today.ToString("dd-MMM-yy");
                        }
                        dt.Rows[k][3] = _branchId;
                        dt.Rows[k][4] = _branchCode;
                        dt.Rows[k][5] = _cur;
                    }

                    if (j == dtexcel1.Rows.Count - 1)
                    {
                        DataView dv = new DataView(dt);
                        dv.Sort = "d";
                        dt = dv.ToTable();
                        foreach (DataRow dr in dt.Rows)
                        {
                            dtfinal1.Rows.Add(dr.ItemArray);
                        }

                        //i = j - 1;
                        k = -1;
                        break;
                    }

                }

            }
            else
            {
                MessageBox.Show("Excel data is Empty");
            }

            return dtfinal1;
        }

        public System.Data.DataTable GetITT_Processed(string filePath, string Country)
        {
            System.Data.DataTable dtexcel1 = new System.Data.DataTable();
            System.Data.DataTable dtfinal1 = new System.Data.DataTable();
            string strConn1;
            bool hasHeaders1 = true;
            string HDR1 = hasHeaders1 ? "Yes" : "No";

            if (filePath.Substring(filePath.LastIndexOf('.')).ToLower() == ".xlsx")
                strConn1 = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + filePath + ";Extended Properties='Excel 8.0;HDR=YES'";
            else
                strConn1 = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + filePath + ";Extended Properties=\"Excel 8.0;HDR=" + HDR1 + ";IMEX=1\"";
            OleDbConnection conn1 = new OleDbConnection(strConn1);
            conn1.Open();
            System.Data.DataTable schemaTable1 = conn1.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, new object[] { null, null, null, "TABLE" });

            DataRow schemaRow = schemaTable1.Rows[0];
            string sheet1 = schemaRow["TABLE_NAME"].ToString();

            OleDbDataAdapter daexcel1 = null;
            if (!sheet1.EndsWith("_"))
            {
                string query = "SELECT  * FROM [Sheet1$]";
                daexcel1 = new OleDbDataAdapter(query, conn1);
                dtexcel1.Locale = CultureInfo.CurrentCulture;
                daexcel1.Fill(dtexcel1);
            }
            conn1.Close();

            string date = DateTime.Today.ToString("dd-MMM-yy");

            if (dtexcel1.Rows.Count > 0)
            {
                dtfinal1.Columns.Add("0.00");
                dtfinal1.Columns.Add(date);
                dtfinal1.Columns.Add("a");
                dtfinal1.Columns.Add("b");
                dtfinal1.Columns.Add("c");
                dtfinal1.Columns.Add("d");

                int k = -1;

                dtexcel1.Rows.RemoveAt(0);
                int cnt = dtexcel1.Rows.Count;
                dtexcel1.Rows.RemoveAt(cnt - 1);


                System.Data.DataTable dt = new System.Data.DataTable();
                dt.Columns.Add("0.00");
                dt.Columns.Add(date);
                dt.Columns.Add("a");
                dt.Columns.Add("b");
                dt.Columns.Add("c");
                dt.Columns.Add("d");

                if (Country.ToUpper() == "MALAYSIA")
                {
                    dtexcel1.AsEnumerable().Where(r => r.Field<string>(15) == "MYR").ToList().ForEach(row => row.Delete());
                    dtexcel1.AcceptChanges();
                }
                if (Country.ToUpper() == "PHILIPPINES")
                {
                    dtexcel1.AsEnumerable().Where(r => r.Field<string>(18) == "PHP").ToList().ForEach(row => row.Delete());
                    dtexcel1.AcceptChanges();
                }
                if (Country.ToUpper() == "INDONESIA")
                {
                    dtexcel1.AsEnumerable().Where(r => r.Field<string>(18) == "IDR").ToList().ForEach(row => row.Delete());
                    dtexcel1.AcceptChanges();
                }
                else if (Country.ToUpper() == "VIETNAM")
                {
                    dtexcel1.AsEnumerable().Where(r => r.Field<string>(15) == "VND").ToList().ForEach(row => row.Delete());
                    dtexcel1.AcceptChanges();
                }
                else if (Country.ToUpper() == "SINGAPORE")
                {
                    dtexcel1.AsEnumerable().Where(r => r.Field<string>(2) == "SGD").ToList().ForEach(row => row.Delete());
                    dtexcel1.AcceptChanges();
                }

                //for (int j = i + 1; j <= dtexcel1.Rows.Count - 1; j++)
                for (int j = 0; j <= dtexcel1.Rows.Count - 1; j++)
                {
                    bool issal = false;
                    var _branchId = string.Empty;
                    var _cur = string.Empty;
                    var _branchCode = string.Empty;
                    var _amt = string.Empty;
                    if (Country.ToUpper() == "MALAYSIA")
                    {
                        _branchId = dtexcel1.Rows[j][1] != null ? dtexcel1.Rows[j][1].ToString() : string.Empty;
                        _branchCode = dtexcel1.Rows[j][12] != null ? dtexcel1.Rows[j][12].ToString() : string.Empty;
                        _amt = dtexcel1.Rows[j][16] != null ? dtexcel1.Rows[j][16].ToString() : "0.00";
                        _cur = dtexcel1.Rows[j][15] != null ? dtexcel1.Rows[j][15].ToString() : string.Empty;
                    }
                    else if (Country.ToUpper() == "PHILIPPINES")
                    {
                        _branchId = dtexcel1.Rows[j][0] != null ? dtexcel1.Rows[j][0].ToString() : string.Empty;
                        _branchCode = dtexcel1.Rows[j][13] != null ? dtexcel1.Rows[j][13].ToString() : string.Empty;
                        _amt = dtexcel1.Rows[j][17] != null ? dtexcel1.Rows[j][17].ToString() : "0.00";
                        _cur = dtexcel1.Rows[j][18] != null ? dtexcel1.Rows[j][18].ToString() : string.Empty;
                    }
                    else if (Country.ToUpper() == "INDONESIA")
                    {
                        _branchId = dtexcel1.Rows[j][1] != null ? dtexcel1.Rows[j][1].ToString() : string.Empty;
                        _branchCode = dtexcel1.Rows[j][13] != null ? dtexcel1.Rows[j][13].ToString() : string.Empty;
                        _amt = dtexcel1.Rows[j][17] != null ? dtexcel1.Rows[j][17].ToString() : "0.00";
                        _cur = dtexcel1.Rows[j][18] != null ? dtexcel1.Rows[j][18].ToString() : string.Empty;
                    }
                    else if (Country.ToUpper() == "VIETNAM")
                    {
                        _branchId = dtexcel1.Rows[j][1] != null ? dtexcel1.Rows[j][1].ToString() : string.Empty;
                        _branchCode = dtexcel1.Rows[j][12] != null ? dtexcel1.Rows[j][12].ToString() : string.Empty;
                        _amt = dtexcel1.Rows[j][16] != null ? dtexcel1.Rows[j][16].ToString() : "0.00";
                        _cur = dtexcel1.Rows[j][15] != null ? dtexcel1.Rows[j][15].ToString() : string.Empty;
                    }
                    else if (Country.ToUpper() == "SINGAPORE")
                    {
                        _branchId = dtexcel1.Rows[j][1] != null ? dtexcel1.Rows[j][1].ToString() : string.Empty;
                        _branchCode = dtexcel1.Rows[j][9] != null ? dtexcel1.Rows[j][9].ToString() : string.Empty;
                        _amt = dtexcel1.Rows[j][3] != null ? dtexcel1.Rows[j][3].ToString() : "0.00";
                        _cur = dtexcel1.Rows[j][2] != null ? dtexcel1.Rows[j][2].ToString() : string.Empty;
                    }

                    if (!string.IsNullOrWhiteSpace(_branchId) && !string.IsNullOrWhiteSpace(_branchCode) && !string.IsNullOrWhiteSpace(_cur))
                    {
                        issal = true;
                    }

                    if (issal)
                    {
                        dt.Rows.Add();
                        k = k + 1;

                        dt.Rows[k][0] = (_amt == "0" ? "0.00" : _amt);// String.Format("{0:0,0.00}", _amt);
                        dt.Rows[k][1] = DateTime.Today.ToString("dd-MMM-yy");
                        dt.Rows[k][2] = DateTime.Today.ToString("dd-MMM-yy");
                        dt.Rows[k][3] = _branchId;
                        dt.Rows[k][4] = _branchCode;
                        dt.Rows[k][5] = _cur;
                    }

                    if (j == dtexcel1.Rows.Count - 1)
                    {
                        DataView dv = new DataView(dt);
                        dv.Sort = "d";
                        dt = dv.ToTable();
                        foreach (DataRow dr in dt.Rows)
                        {
                            dtfinal1.Rows.Add(dr.ItemArray);
                        }

                        //i = j - 1;
                        k = -1;
                        break;
                    }

                }

            }
            else
            {
                MessageBox.Show("Excel data is Empty");
            }

            return dtfinal1;
        }

        public void ExportToExcel_MYEOD_Sheet(System.Data.DataTable tbl, string excelOutputFile)
        {
            try
            {
                if (tbl == null || tbl.Columns.Count == 0)
                    return;//throw new Exception("ExportToExcel: Null or empty input table!\n");

                // load excel, and create a new workbook
                var excelApp = new Microsoft.Office.Interop.Excel.Application();

                Microsoft.Office.Interop.Excel.Workbook workBook = null;
                workBook = excelApp.Workbooks.Add(Type.Missing);
                Microsoft.Office.Interop.Excel._Worksheet workSheet = null;
                //Microsoft.Office.Interop.Excel._Worksheet workSheet = workBook.Worksheets.Add(Type.Missing);
                //workSheet.Range["A:A"].NumberFormat = "#,##0.00"; 
                excelApp.DisplayAlerts = false;
                excelApp.Visible = false;
                //Microsoft.Office.Interop.Excel.Range range;

                //Currency checker
                string tempcurr = "";
                List<string> currlst = new List<string>();
                currlst = tbl.AsEnumerable().Select(r => r.Field<string>("d")).ToList();
                currlst = currlst.Distinct().ToList();
                int k = 0;
                double totalValue = 0.00;

                int recCount = 0;

                //var amt = tbl.AsEnumerable().Max(r => r.Field<string>("0.00"));

                for (var i = 0; i < tbl.Rows.Count; i++)
                {
                    string cur = tbl.Rows[i][5].ToString();
                    bool isNewCur = false;



                    if (tempcurr != cur)
                    {
                        if (totalValue != 0.00)
                        {
                            workSheet.Cells[recCount + 2, 1] = totalValue;
                            totalValue = 0.00;
                        }
                        recCount = 0;


                        workSheet = (Excel.Worksheet)workBook.Worksheets.Add(Type.Missing);
                        workSheet.Range["A:A"].NumberFormat = "#,##0.00";
                        workSheet.Range["E:E"].NumberFormat = "@";
                        workSheet.Move(Type.Missing, workBook.Sheets[workBook.Sheets.Count]);


                        isNewCur = true;
                    }

                    tempcurr = cur;

                    if (isNewCur == true)
                        k = 0;

                    // column headings
                    for (var a = 0; a < tbl.Columns.Count; a++)
                    {
                        workSheet.Cells[1, a + 1] = tbl.Columns[a].ColumnName;
                    }

                    // rows
                    int c = 1;
                    for (var j = 0; j < tbl.Columns.Count; j++)
                    {
                        workSheet.Cells[k + 2, j + 1] = tbl.Rows[i][j];

                        if (c == 1)
                        {
                            totalValue += Convert.ToDouble(tbl.Rows[i][0]);
                            recCount++;
                        }
                        c++;
                    }

                    k++;
                    workSheet.Columns.AutoFit();
                }
                workSheet.Cells[recCount + 2, 1] = totalValue; //Final Sheet grand Total is applied here only after for loop. - Prakash
                workSheet.Columns.AutoFit();


                //Worksheet.Delete
                foreach (Microsoft.Office.Interop.Excel._Worksheet sheet in workBook.Worksheets)
                {
                    if (sheet.UsedRange.Count < 2)
                    {
                        sheet.Delete();
                    }
                }

                // check file path
                if (!string.IsNullOrEmpty(excelOutputFile))
                {
                    try
                    {
                        workBook.SaveCopyAs(excelOutputFile);
                        excelApp.Visible = false;
                        Microsoft.Office.Interop.Excel._Worksheet sheet = (Microsoft.Office.Interop.Excel._Worksheet)excelApp.Worksheets[1];
                        sheet.Select(Type.Missing);

                        workBook.Close();
                        excelApp.Quit();
                        ReleaseComObject(workSheet);
                        ReleaseComObject(workBook);
                        ReleaseComObject(excelApp);
                        //MessageBox.Show("Excel file saved!");
                    }
                    catch
                    {
                        workBook.Close();
                        excelApp.Quit();
                        ReleaseComObject(workSheet);
                        ReleaseComObject(workBook);
                        ReleaseComObject(excelApp);
                    }
                }
                else
                { // no file path is given
                    excelApp.Visible = false;
                }
            }
            catch
            {

            }
        }

        public void ExportToExcel_MYEOD(System.Data.DataTable tbl, string excelFilePath, string Country)
        {
            StreamWriter wrtr = null;
            try
            {
                if (tbl == null || tbl.Columns.Count == 0)
                    return;// throw new Exception("ExportToExcel: Null or empty input table!\n");


                string setID = "";

                if (Country.ToUpper() == "SINGAPORE")
                    setID = "21";
                else if (Country.ToUpper() == "INDONESIA")
                    setID = "27";
                else if (Country.ToUpper() == "MALAYSIA")
                    setID = "28";
                else if (Country.ToUpper() == "VIETNAM")
                    setID = "29";
                else if (Country.ToUpper() == "PHILIPPINES")
                    setID = "39";
                else if (Country.ToUpper() == "NIGERIA")
                    setID = "90";
                else if (Country.ToUpper() == "INDIA")
                    setID = "40";

                wrtr = new StreamWriter(excelFilePath);
                List<string> currlst = new List<string>();
                currlst = tbl.AsEnumerable().Select(r => r.Field<string>("d")).ToList();
                currlst = currlst.Distinct().ToList();

                System.Data.DataTable dt = new System.Data.DataTable();
                dt.Columns.Add("OPBAL");
                dt.Columns.Add("OPBALCY");
                dt.Columns.Add("OPBALDATE");
                dt.Columns.Add("OPBALSIGN");
                dt.Columns.Add("OPBALTP");
                dt.Columns.Add("OURREF");
                dt.Columns.Add("SIDE");
                dt.Columns.Add("STMTNO");
                dt.Columns.Add("STMTPG");
                dt.Columns.Add("SUBACC");
                dt.Columns.Add("THEIRREF");
                dt.Columns.Add("ACCOWNRINFO");
                dt.Columns.Add("AMOUNT");
                dt.Columns.Add("DRORCR");
                dt.Columns.Add("ENTRYDATE");
                dt.Columns.Add("REF1");
                dt.Columns.Add("REF2");
                dt.Columns.Add("REF3");
                dt.Columns.Add("TRANCODE");
                dt.Columns.Add("VALUEDATE");
                dt.Columns.Add("BRC");
                dt.Columns.Add("XAMT1");
                dt.Columns.Add("XAMT2");
                dt.Columns.Add("XAMT3");
                dt.Columns.Add("XDATE1");
                dt.Columns.Add("XDATE2");
                dt.Columns.Add("XDATE3");
                dt.Columns.Add("XSTR1");
                dt.Columns.Add("XSTR2");
                dt.Columns.Add("XSTR3");
                dt.Columns.Add("XFLAG1");
                dt.Columns.Add("XFLAG2");
                dt.Columns.Add("XFLAG3");
                dt.Columns.Add("CLBAL");
                dt.Columns.Add("CLBALCY");
                dt.Columns.Add("CLBALDATE");
                dt.Columns.Add("CLBALSIGN");
                dt.Columns.Add("CLBALTP");
                string colString = "";
                for (int y = 0; y < dt.Columns.Count; y++)
                {
                    //rowString += "\"" + dt.Rows[x][y].ToString() + "\","; Original
                    if (dt.Columns.Count - 1 == y)
                    {
                        colString += dt.Columns[y].ToString();
                    }
                    else
                    {
                        colString += dt.Columns[y].ToString() + "|";
                    }
                }
                wrtr.WriteLine(colString);

                System.Data.DataTable dtCloned = tbl.Clone();
                dtCloned.Columns[0].DataType = typeof(decimal);
                foreach (DataRow row in tbl.Rows)
                {
                    dtCloned.ImportRow(row);
                }

                for (var i = 0; i < tbl.Rows.Count; i++)
                {
                    dt.Rows.Add();
                    string amt = tbl.Rows[i][0].ToString();
                    string currdate = tbl.Rows[i][1].ToString();
                    string ref1 = tbl.Rows[i][3].ToString();
                    string ref2 = tbl.Rows[i][4].ToString();
                    string cury = tbl.Rows[i][5].ToString();

                    var tot = dtCloned.AsEnumerable().Where(r => r.Field<string>(5) == cury).Sum(r => r.Field<decimal>(0));

                    dt.Rows[i][0] = "0";
                    dt.Rows[i][1] = cury;
                    if (Country.ToUpper() == "NIGERIA" || Country.ToUpper() == "INDIA")
                        dt.Rows[i][2] = System.DateTime.Today.ToString("dd/MM/yyyy");
                    else
                        dt.Rows[i][2] = Convert.ToDateTime(currdate).ToString("dd/MM/yyyy");

                    dt.Rows[i][3] = "D";
                    dt.Rows[i][4] = "F";
                    dt.Rows[i][5] = "DUMMYTRN";
                    dt.Rows[i][6] = "S";
                    dt.Rows[i][7] = "1";
                    dt.Rows[i][8] = "1";
                    if (Country.ToUpper() == "NIGERIA" || Country.ToUpper() == "INDIA")
                        dt.Rows[i][9] = setID + cury + "01S" + System.DateTime.Today.ToString("ddMMyy") + DateTime.Now.ToString("hhmmss");
                    else
                        dt.Rows[i][9] = setID + cury + "01S" + Convert.ToDateTime(currdate).ToString("ddMMyy") + DateTime.Now.ToString("hhmmss");

                    dt.Rows[i][10] = "CONV";
                    dt.Rows[i][11] = "";
                    dt.Rows[i][12] = amt;
                    dt.Rows[i][13] = "C";
                    dt.Rows[i][14] = Convert.ToDateTime(currdate).ToString("dd/MM/yyyy");
                    dt.Rows[i][15] = ref1;
                    dt.Rows[i][16] = ref2;
                    dt.Rows[i][17] = cury;
                    dt.Rows[i][18] = "";
                    dt.Rows[i][19] = Convert.ToDateTime(currdate).ToString("dd/MM/yyyy");
                    dt.Rows[i][33] = tot;
                    dt.Rows[i][34] = cury;
                    if (Country.ToUpper() == "NIGERIA" || Country.ToUpper() == "INDIA")
                        dt.Rows[i][35] = System.DateTime.Today.ToString("dd/MM/yyyy");
                    else
                        dt.Rows[i][35] = Convert.ToDateTime(currdate).ToString("dd/MM/yyyy");

                    //dt.Rows[i][34] = "0";
                    //dt.Rows[i][35] = "0";
                    dt.Rows[i][36] = "C";
                    dt.Rows[i][37] = "F";

                    string rowString = "";
                    for (int y = 0; y < dt.Columns.Count; y++)
                    {
                        //rowString += "\"" + dt.Rows[x][y].ToString() + "\","; Original
                        if (dt.Columns.Count - 1 == y)
                        {
                            rowString += dt.Rows[i][y].ToString();
                        }
                        else
                        {
                            rowString += dt.Rows[i][y].ToString() + "|";
                        }
                    }
                    rowString = rowString.Replace(",", "");
                    wrtr.WriteLine(rowString);

                }

            }
            catch
            {

            }
            finally
            {
                wrtr.Close();
                wrtr.Dispose();
            }

        }

        public string Get_Recon_DateForNETS(string s)
        {
            string Final_Date = "";
            try
            {
                string Filee = Path.GetFileNameWithoutExtension(s);
                System.Data.DataTable dt = new System.Data.DataTable("CreditCards");
                dt.Columns.Add("File");

                var lines = File.ReadAllLines(s);
                StreamReader objReader;
                objReader = new StreamReader(s);

                // reading rest of the data
                for (int i = 0; i < lines.Count(); i++)
                {
                    //DataRow dr = dt.NewRow();
                    string values = objReader.ReadLine();

                    if (values != null)
                    {
                        dt.Rows.Add();
                        dt.Rows[i][0] = values;
                    }
                }

                DataRow dr = (DataRow)dt.Rows[dt.Rows.Count - 1];
                string Date = dt.Rows[0][0].ToString().Substring(26, 6);
                string YY = Date.ToString().Substring(0, 2);
                string MM = Date.ToString().Substring(2, 2);
                string DD = Date.ToString().Substring(4, 2);
                // string Dates = Date.ToString("MMddyyyy");
                Final_Date = DD + MM + "20" + YY;
            }
            catch
            {

            }
            return Final_Date;
        }

        public string Get_Recon_DateForBahrain(string s)
        {

            StreamReader objReader;
            objReader = new StreamReader(s);
            string[] lines = System.IO.File.ReadAllLines(s);
            string[] ar = lines[5].ToString().Split(',');
            string[] date = ar[1].ToString().Split('-');
            string finaldt = date[0] + date[1] + date[2];

            return finaldt;
        }

        public string Get_Recon_DateForEASVN(string Soure_Path)
        {
            StreamReader objReader;

            objReader = new StreamReader(Soure_Path);
            string dt = "";
            string[] lines = System.IO.File.ReadAllLines(Soure_Path);
            for (int i = 0; i <= lines.Length - 1; i++)
            {
                string[] ar = System.Text.RegularExpressions.Regex.Split(lines[i].ToString(), @"\s{2,}");
                dt = ar[2].ToString().Substring(ar[2].ToString().Length - 8, 2) + ar[2].ToString().Substring(ar[2].ToString().Length - 10, 2) + "20" + ar[2].ToString().Substring(ar[2].ToString().Length - 12, 2);
                break;
            }
            return dt;
        }

        public string Get_Recon_DateForCGB570R1(string Soure_Path)
        {
            StreamReader objReader;
            string date = "";
            objReader = new StreamReader(Soure_Path);
            try
            {
                string[] lines = System.IO.File.ReadAllLines(Soure_Path);

                for (int i = 0; i <= lines.Length - 1; i++)
                {
                    if (lines[i].Contains("DATE"))
                    {
                        string[] ar = lines[i].ToString().Split(':');
                        string[] dt = ar[1].ToString().Trim().Split('/');
                        date = dt[0] + dt[1] + "20" + dt[2];
                        break;
                    }
                }
            }
            catch
            {

            }
            return date;
        }

        public string Get_Recon_DateForDIRECT_DB_CR_TRANS_GENERATION_DIRECT_DB_CR_TRANS_GENERATION(string Soure_Path)
        {
            string strConn1;
            string finaldate = "";
            string filePath2 = Soure_Path;
            if (filePath2.Substring(filePath2.LastIndexOf('.')).ToLower() == ".xlsx")
                strConn1 = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + filePath2 + ";Extended Properties=\"Excel 12.0;HDR=Yes;IMEX=1\"";
            //strConn = "Provider=Microsoft.Jet.OleDb.4.0; Data Source = " + System.IO.Path.GetDirectoryName(ExcelfilePath) + "; Extended Properties = 'text;HDR=YES;IMEX=1v;FMT=Delimited(,)';";
            else
                strConn1 = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + filePath2 + ";Extended Properties=\"Excel 8.0;HDR=Yes;IMEX=1\"";
            Microsoft.Office.Interop.Excel.Application excel = new Microsoft.Office.Interop.Excel.Application();
            excel.Visible = false;
            excel.DisplayAlerts = false;
            Workbook wb = excel.Workbooks.Open(filePath2);
            System.Data.DataTable dtexcel1 = new System.Data.DataTable();
            OleDbConnection conn1 = new OleDbConnection(strConn1);
            conn1.Open();
            System.Data.DataTable schemaTable1 = conn1.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, new object[] { null, null, null, "TABLE" });

            DataRow schemaRow1 = schemaTable1.Rows[0];
            string sheet1 = schemaRow1["TABLE_NAME"].ToString();
            if (!sheet1.EndsWith("_"))
            {
                try
                {
                    string query1 = "SELECT  * FROM [" + sheet1 + "]";
                    OleDbDataAdapter daexcel1 = new OleDbDataAdapter(query1, conn1);
                    dtexcel1.Locale = CultureInfo.CurrentCulture;
                    daexcel1.Fill(dtexcel1);
                    for (int i = 0; i <= dtexcel1.Rows.Count - 1; i++)
                    {
                        if (dtexcel1.Rows[i][0].ToString().Trim().Contains("DATE"))
                        {
                            string[] date = dtexcel1.Rows[i][0].ToString().Trim().Split(':');
                            string[] date1 = date[1].ToString().Trim().Split('/');
                            finaldate = date1[0] + date1[1] + "20" + date1[2];
                            break;
                        }
                    }
                }
                catch
                {

                }
            }
            wb.Close();
            excel.Quit();
            ReleaseComObject(wb);
            ReleaseComObject(excel);
            return finaldate;
        }

        public string GetSettlementDateFromExcel(string filePath2, string Recon_Date)
        {
            string Date = "";
            try
            {
                string strConn1;

                if (filePath2.Substring(filePath2.LastIndexOf('.')).ToLower() == ".xlsx")
                    strConn1 = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + filePath2 + ";Extended Properties=\"Excel 12.0;HDR=Yes;IMEX=1\"";
                else
                    strConn1 = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + filePath2 + ";Extended Properties=\"Excel 8.0;HDR=Yes;IMEX=1\"";
                System.Data.DataTable dtexcel1 = new System.Data.DataTable();
                OleDbConnection conn1 = new OleDbConnection(strConn1);
                conn1.Open();
                System.Data.DataTable schemaTable1 = conn1.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, new object[] { null, null, null, "TABLE" });
                DataRow schemaRow1 = schemaTable1.Rows[0];
                string sheet1 = schemaRow1["TABLE_NAME"].ToString();

                if (!sheet1.EndsWith("_"))
                {
                    try
                    {
                        string query1 = "SELECT  * FROM [" + sheet1 + "]";
                        OleDbDataAdapter daexcel1 = new OleDbDataAdapter(query1, conn1);
                        dtexcel1.Locale = CultureInfo.CurrentCulture;
                        daexcel1.Fill(dtexcel1);
                    }
                    catch
                    {
                        //throw ex;
                    }
                    if (dtexcel1.Rows[dtexcel1.Rows.Count - 2]["CCY"].ToString() != "")
                    {
                        Date = dtexcel1.Rows[dtexcel1.Rows.Count - 2]["Trans date"].ToString();
                        string year = DateTime.Now.Year.ToString();
                        Date = Date.Substring(2, 2) + Date.Substring(0, 2) + year;
                    }
                    else
                    {
                        Date = Recon_Date;
                    }
                }
            }
            catch
            {
                return null;
            }
            return Date;
        }

        public string Get_Qatar_Date(string File_Path)
        {

            StreamReader objReader;
            string date = string.Empty;
            try
            {
                objReader = new StreamReader(File_Path);
                string[] lines = System.IO.File.ReadAllLines(File_Path);
                for (int i = 0; i <= lines.Length - 1; i++)
                {
                    if (lines[i].Contains("DATE"))
                    {
                        string[] ar = lines[i].ToString().Split(':');
                        string[] dt = ar[0].ToString().Trim().Split('/');
                        date = ("20" + dt[0].Substring(dt[0].Length - 2)) + dt[1] + dt[2];
                        break;
                    }
                }
                return date;
            }
            catch
            {
                return null;
            }
        }

        public void CompareDateLogic(string _Recon_Date, string temp_FileName, string Formatted_File_Name, string Foramtted_Recon_Date, string db_Ext, string Output_Path, string Soure_Path, string ConnString, string Input_Country)
        {
            try
            {
                /*string date1 = "";
                if (_Recon_Date.Length == 6)
                {
                    DateTime myDate = DateTime.ParseExact(_Recon_Date, "ddMMyy", System.Globalization.CultureInfo.InvariantCulture);
                    date1 = myDate.ToString("ddMMyyyy");
                }
                else if (_Recon_Date.Length == 8)
                {
                    DateTime myDate = DateTime.ParseExact(_Recon_Date, "ddMMyyyy", System.Globalization.CultureInfo.InvariantCulture);
                    date1 = myDate.ToString("ddMMyyyy");
                }
                else if (_Recon_Date.Length == 10)
                {
                    DateTime myDate = DateTime.ParseExact(_Recon_Date, "MM.dd.yyyy", System.Globalization.CultureInfo.InvariantCulture);
                    date1 = myDate.ToString("ddMMyyyy");
                }
                if (date1 == Foramtted_Recon_Date)
                {
                    temp_FileName = Formatted_File_Name.Substring(0, Formatted_File_Name.LastIndexOf("_"));

                    temp_FileName = temp_FileName + "_" + Foramtted_Recon_Date + db_Ext; //Changed this-Prakash-> temp_FileName = temp_FileName + "_" + Recon_Date + "." + File_Ext; 

                    File.Copy(Soure_Path, Output_Path + temp_FileName, true);
                }
                else
                {
                    DialogResult dialogResult = MessageBox.Show("Are you sure you want to proceed with the Recon date...!", "ARC Alert", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                    if (dialogResult == DialogResult.Yes)
                    {
                        temp_FileName = Formatted_File_Name.Substring(0, Formatted_File_Name.LastIndexOf("_"));
                        Foramtted_Recon_Date = _Recon_Date;
                        temp_FileName = temp_FileName + "_" + Foramtted_Recon_Date + db_Ext;
                        File.Copy(Soure_Path, Output_Path + temp_FileName, true);

                    }
                    else if (dialogResult == DialogResult.No)
                    {

                    }

                }*/

            }
            catch
            {

            }
        }

        public void Formatting_Singapore_IBROKER(string Soure_Path, string Output_Path, string Recon_Date)
        {
            System.Data.DataTable dt = new System.Data.DataTable();
            dt.Columns.Add("Text1");
            dt.Columns.Add("Text2");
            dt.Columns.Add("Text3");
            dt.Columns.Add("Text4");
            dt.Columns.Add("Text5");
            dt.Columns.Add("Text6");
            dt.Columns.Add("Text7");
            dt.Columns.Add("Text8");

            StreamReader objReader;
            objReader = new StreamReader(Soure_Path);

            string[] lines = System.IO.File.ReadAllLines(Soure_Path);

            try
            {
                for (int i = 0; i <= lines.Length - 1; i++)
                {
                    dt.Rows.Add();
                    dt.Rows[i][0] = lines[i];
                    string[] ar = lines[i].ToString().Split('|');
                    if (i > 0)
                    {
                        if (ar[0].ToString().Contains('/'))
                        {
                            string[] ar1 = ar[0].ToString().Split('/');
                            dt.Rows[i][0] = Recon_Date + "|";
                        }
                        else if (ar[0].ToString().Contains('-'))
                        {
                            string[] ar2 = ar[0].ToString().Split('-');
                            dt.Rows[i][0] = Recon_Date + "|";
                        }

                        dt.Rows[i][1] = ar[1] + "|";
                        dt.Rows[i][2] = ar[2] + "|";
                        dt.Rows[i][3] = ar[3] + "|";
                        dt.Rows[i][4] = ar[4] + "|";
                        dt.Rows[i][5] = ar[5] + "|";
                        dt.Rows[i][6] = ar[6] + "|";
                        dt.Rows[i][7] = ar[7];
                    }
                }

            }
            catch
            {
                //throw ex;
            }

            WriteData_IBROKER_ToFile(dt, Output_Path);
        }

        public void Formatting_Malaysia_IBROKER(string Soure_Path, string Output_Path, string Recon_Date)
        {
            System.Data.DataTable dt = new System.Data.DataTable();
            dt.Columns.Add("Text1");
            dt.Columns.Add("Text2");
            dt.Columns.Add("Text3");
            dt.Columns.Add("Text4");
            dt.Columns.Add("Text5");
            dt.Columns.Add("Text6");
            dt.Columns.Add("Text7");
            dt.Columns.Add("Text8");

            StreamReader objReader;
            objReader = new StreamReader(Soure_Path);

            string[] lines = System.IO.File.ReadAllLines(Soure_Path);

            try
            {
                for (int i = 0; i <= lines.Length - 1; i++)
                {
                    dt.Rows.Add();
                    dt.Rows[i][0] = lines[i];
                    string[] ar = lines[i].ToString().Split('|');
                    if (i > 0)
                    {
                        if (ar[0].ToString().Contains('/'))
                        {
                            string[] ar1 = ar[0].ToString().Split('/');
                            dt.Rows[i][0] = Recon_Date + "|";
                        }
                        else if (ar[0].ToString().Contains('-'))
                        {
                            string[] ar2 = ar[0].ToString().Split('-');
                            dt.Rows[i][0] = Recon_Date + "|";
                        }

                        dt.Rows[i][1] = ar[1] + "|";
                        dt.Rows[i][2] = ar[2] + "|";
                        dt.Rows[i][3] = ar[3] + "|";
                        dt.Rows[i][4] = ar[4] + "|";
                        dt.Rows[i][5] = ar[5] + "|";
                        dt.Rows[i][6] = ar[6] + "|";
                        dt.Rows[i][7] = ar[7];
                    }
                }

            }
            catch
            {
                //throw ex;
            }
            WriteData_IBROKER_ToFile(dt, Output_Path);
        }

        public void WriteData_IBROKER_ToFile(System.Data.DataTable submittedDataTable, string submittedFilePath)
        {
            int i = 0;
            StreamWriter sw = null;

            sw = new StreamWriter(submittedFilePath, false);

            foreach (DataRow row in submittedDataTable.Rows)
            {
                object[] array = row.ItemArray;

                for (i = 0; i < array.Length - 1; i++)
                {
                    sw.Write(array[i].ToString());
                }
                sw.Write(array[i].ToString());
                sw.WriteLine();
            }
            sw.Close();
        }

        public void Formatting_India_CMPC_Suspense(string Source_Path, string Output_Path, string Share_Path, string Formatted_File_Name, string temp_FileName, string db_Ext, string Recon_Date, string Recon_Name)
        {
            try
            {
                string tempFilePath = Share_Path + temp_FileName;

                System.Data.DataTable dtexcel = new System.Data.DataTable();
                System.Data.DataTable dtexcel1 = new System.Data.DataTable();

                bool hasHeaders = true;
                string HDR = hasHeaders ? "Yes" : "No";
                string strConn;
                if (Source_Path.Substring(Source_Path.LastIndexOf('.')).ToLower() == ".xlsx")
                    strConn = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + Source_Path + ";Extended Properties=\"Excel 12.0;HDR=" + HDR + ";IMEX=0\"";
                else
                    strConn = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + Source_Path + ";Extended Properties=\"Excel 8.0;HDR=" + HDR + ";IMEX=1\"";
                OleDbConnection conn = new OleDbConnection(strConn);
                conn.Open();
                System.Data.DataTable schemaTable = conn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, new object[] { null, null, null, "TABLE" });

                DataRow schemaRow = schemaTable.Rows[0];
                string sheet = schemaRow["TABLE_NAME"].ToString();
                if (!sheet.EndsWith("_"))
                {
                    string query = "SELECT  * FROM [" + sheet + "]";
                    OleDbDataAdapter daexcel = new OleDbDataAdapter(query, conn);
                    dtexcel.Locale = CultureInfo.CurrentCulture;
                    daexcel.Fill(dtexcel);
                }

                conn.Close();
                System.Data.DataTable dt1 = new System.Data.DataTable();
                dt1 = dtexcel.Clone();

                dt1.Columns[3].DataType = typeof(string);
                dt1.Columns[6].DataType = typeof(string);
                foreach (DataRow row in dtexcel.Rows)
                {
                    dt1.ImportRow(row);
                }
                System.Data.DataTable dt2 = new System.Data.DataTable();
                dt2 = dt1.Clone();

                for (int i = 0; i <= dt1.Rows.Count - 1; i++)
                {
                    dt2.Rows.Add();


                    dt2.Rows[i][0] = Regex.Replace(dt1.Rows[i][0].ToString().Trim(), @"\s+", " ");
                    dt2.Rows[i][1] = Regex.Replace(dt1.Rows[i][1].ToString().Trim(), @"\s+", " ");
                    dt2.Rows[i][2] = Regex.Replace(dt1.Rows[i][2].ToString().Trim(), @"\s+", " ");
                    dt2.Rows[i][3] = Regex.Replace(dt1.Rows[i][3].ToString().Trim(), @"\s+", " ");
                    dt2.Rows[i][4] = dt1.Rows[i][4].ToString();
                    dt2.Rows[i][5] = dt1.Rows[i][5].ToString();
                    dt2.Rows[i][6] = dt1.Rows[i][6].ToString();
                    dt2.Rows[i][7] = dt1.Rows[i][7].ToString();
                    dt2.Rows[i][8] = dt1.Rows[i][8].ToString();
                    dt2.Rows[i][9] = dt1.Rows[i][9].ToString();
                    dt2.Rows[i][10] = dt1.Rows[i][10].ToString();
                    dt2.Rows[i][11] = dt1.Rows[i][11].ToString();
                    dt2.Rows[i][12] = dt1.Rows[i][12].ToString();
                    dt2.Rows[i][13] = dt1.Rows[i][13].ToString();
                    dt2.Rows[i][14] = dt1.Rows[i][14].ToString();
                    dt2.Rows[i][15] = dt1.Rows[i][15].ToString();
                    dt2.Rows[i][16] = dt1.Rows[i][16].ToString();
                    dt2.Rows[i][17] = dt1.Rows[i][17].ToString();
                    dt2.Rows[i][18] = dt1.Rows[i][18].ToString();
                    dt2.Rows[i][19] = dt1.Rows[i][19].ToString();
                    dt2.Rows[i][20] = dt1.Rows[i][20].ToString();
                    dt2.Rows[i][21] = dt1.Rows[i][21].ToString();

                }


                ExportDTToExcel(dt2, Share_Path + Formatted_File_Name + db_Ext);
                FileRename(Directory_Temp, Share_Path, Recon_Name, Output_Path, Recon_Date, Formatted_File_Name);

            }
            catch
            {
                //throw new Exception("ExportToExcel: \n" + ex.Message);
            }

        }

        public void MAURITIUS_Stock_Formatting(string file_Path, string OutPutPath)
        {
            try
            {
                using (StreamReader reader = new StreamReader(file_Path))
                {
                    string All_Text = string.Empty;
                    All_Text = reader.ReadToEnd();
                    string[] arr = All_Text.Split(new string[] { "\r", "\n" }, StringSplitOptions.RemoveEmptyEntries);
                    StringBuilder s = new StringBuilder();
                    for (int i = 0; i < arr.Length; i++)
                    {
                        string Date = arr[i].Substring(0, 11).Trim() + "|";
                        string surname = arr[i].Substring(11, 55).Trim() + "|";
                        string Initials = arr[i].Substring(66, 15).Trim() + "|";
                        string Title = arr[i].Substring(81, 10).Trim() + "|";
                        string other_Name = arr[i].Substring(91, 80).Trim() + "|";
                        string NID_No = arr[i].Substring(171, 14).Trim() + "|";
                        string Participant_Id = arr[i].Substring(185, 3).Trim();
                        string Client_prifx = arr[i].Substring(188, 9).Trim();
                        string Client_Sufx = arr[i].Substring(197, 2).Trim();
                        string Joint_Acc_No = arr[i].Substring(199, 2).Trim();
                        string Compny_Id = arr[i].Substring(201, 4).Trim();
                        string Main_Type = arr[i].Substring(205, 1).Trim() + "|";
                        string Sub_Type = arr[i].Substring(206, 4).Trim() + "|";
                        string Balance = arr[i].Substring(210, 10).Trim();
                        string Purches_In = arr[i].Substring(220, 10).Trim() + "|";
                        string Sales_In = arr[i].Substring(230, 10).Trim() + "|";
                        string Usufruct = arr[i].Substring(240, 10).Trim() + "|";
                        string Price = arr[i].Substring(250, 10).Trim() + "|";
                        string QTY_PLEDGED = arr[i].Substring(260, 11).Trim() + "|";
                        string Last_Trnsction = arr[i].Substring(270, 10).Trim() + "|";
                        string Date_2 = arr[i].Remove(0, 281) + "|";// Need to clear Doudt in length columns
                        //string Date_3 = arr[i].Substring(391, (arr[i].Length-1)).Trim() + "|";
                        Date = Date.Replace("|", "");
                        string Static_Text = "1|MU000116-CUS|S|C|" + Convert.ToDateTime(Date).ToString("d'/'M'/'yyyy") + "|" + Convert.ToDateTime(Date).ToString("d'/'M'/'yyyy") + "||STMT|";

                        //s.AppendLine(Date + surname + Initials + Title + other_Name + NID_No + Participant_Id + Client_prifx + Client_Sufx + Joint_Acc_No + Compny_Id + Main_Type + Sub_Type + Balance + Purches_In + Sales_In + Usufruct + Price + QTY_PLEDGED + Last_Trnsction + Date_2);
                        s.AppendLine(Static_Text + "|" + Date_2 + Date_2 + Convert.ToString(Convert.ToInt64(Balance)) + "||||||||||||" + Compny_Id + " " + Participant_Id + "-" + Convert.ToString(Convert.ToInt64(Client_prifx)) + "-" + Client_Sufx + "-" + Convert.ToString(Convert.ToInt64(Joint_Acc_No)) + "|" + Convert.ToString(Convert.ToInt64(Balance)) + "|");
                    }
                    using (StreamWriter writetext = new StreamWriter(OutPutPath))
                    {
                        bool b = false;
                        if (b == false)
                        {
                            writetext.WriteLine("#PAGENO|SUBACC|SIDE|SIGN|FROMDATE|TODATE|NOOFPARTS|TRANCODE|FUNDSCAID|SECURITY|ISIN|QTY|PPUCY|XAMT1|XAMT2|XAMT3|XAMT15|XDATE1|XSTR1|XSTR2|XSTR3|XSTR4|XSTR5|XSTR6|AVAIAMT|PPUAMT");
                            writetext.Write(s);
                            b = true;
                        }
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }

        }

        public void Bank_Indnesia(string filePath1, string Output_Path, string sDirectory, string Output_Path1, string Recon_Date, string Recon_name, string Formatted_File_Name)
        {
            try
            {
                if (File.Exists(filePath1))
                {
                    string strConn;
                    string File_Name = Path.GetFileName(filePath1);
                    strConn = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + filePath1 + ";Extended Properties=\"Excel 12.0;HDR=Yes;IMEX=1\"";
                    System.Data.DataTable dtexcel = new System.Data.DataTable();
                    OleDbConnection conn = new OleDbConnection(strConn);
                    conn.Open();
                    System.Data.DataTable schemaTable = conn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, new object[] { null, null, null, "TABLE" });
                    DataRow schemaRow = schemaTable.Rows[0];
                    string sheet = "Sheet2$";
                    if (!sheet.EndsWith("_"))
                    {
                        string query = "SELECT  * FROM [" + sheet + "]";
                        OleDbDataAdapter daexcel = new OleDbDataAdapter(query, conn);
                        dtexcel.Locale = CultureInfo.CurrentCulture;
                        daexcel.Fill(dtexcel);

                    }
                    int x = 0;
                    System.Data.DataTable dt = new System.Data.DataTable();
                    dt = dtexcel.Clone();
                    for (int i = 0; i <= dtexcel.Rows.Count - 1; i++)
                    {
                        if (dtexcel.Rows[i][0].ToString().Trim().Length == 3)
                        {

                        }
                        else
                        {
                            string[] ar1 = dtexcel.Rows[i][2].ToString().Replace(",", "").Split('.');
                            string[] ar2 = dtexcel.Rows[i][3].ToString().Replace(",", "").Split('.');
                            string[] ar3 = dtexcel.Rows[i][4].ToString().Replace(",", "").Split('.');
                            string[] ar4 = dtexcel.Rows[i][5].ToString().Replace(",", "").Split('.');
                            string[] ar5 = dtexcel.Rows[i][6].ToString().Replace(",", "").Split('.');
                            string[] ar6 = dtexcel.Rows[i][7].ToString().Replace(",", "").Split('.');
                            dt.Rows.Add();
                            dt.Rows[x][0] = "'" + dtexcel.Rows[i][0];
                            dt.Rows[x][1] = "'" + dtexcel.Rows[i][1];
                            dt.Rows[x][2] = "'" + ar1[0];
                            dt.Rows[x][3] = "'" + ar2[0];
                            dt.Rows[x][4] = "'" + ar3[0];
                            dt.Rows[x][5] = "'" + ar4[0];
                            dt.Rows[x][6] = "'" + ar5[0];
                            dt.Rows[x][7] = "'" + ar6[0];
                            dt.Rows[x][8] = "'" + dtexcel.Rows[i][8];
                            x++;
                        }
                    }
                    DataRow dr;
                    dr = dt.NewRow();
                    dr[0] = "||||||||";
                    dt.Rows.InsertAt(dr, 0);
                    ExportToExcel_Common(dt, Output_Path);
                    FileRename(filePath1, sDirectory, Recon_name, Output_Path1, Recon_Date, Formatted_File_Name);
                }
            }
            catch
            {

            }
        }

        public void ExportToExcel_Common(System.Data.DataTable dt, string Save_File_Path)
        {
            var excelApp = new Microsoft.Office.Interop.Excel.Application();

            Microsoft.Office.Interop.Excel.Workbook workBook = null;
            workBook = excelApp.Workbooks.Add(Type.Missing);
            Microsoft.Office.Interop.Excel._Worksheet workSheet = (Microsoft.Office.Interop.Excel.Worksheet)workBook.Worksheets.Add(Type.Missing);
            Microsoft.Office.Interop.Excel.Range excelCellrange = null;
            Microsoft.Office.Interop.Excel.Range excelCellrange2 = null;
            excelApp.DisplayAlerts = false;
            excelApp.Visible = false;

            //Here column will be created
            if (Save_File_Path.Contains("CUS_ID_CUS_FTP") || Save_File_Path.Contains("SCB_PHP_CLG_INWARD_EBS"))
            {

            }
            else
            {
                for (int i = 0; i < dt.Columns.Count; i++)
                {
                    workSheet.Cells[1, i + 1] = dt.Columns[i].ColumnName;
                }
            }


            //Here Rows will be created
            for (int j = 0; j < dt.Rows.Count; j++)
            {
                for (int k = 0; k < dt.Columns.Count; k++)
                {
                    workSheet.Cells[j + 2, k + 1] = dt.Rows[j].ItemArray[k].ToString();
                }
            }
            if (Save_File_Path.Contains("SCB_PHP_CLG_INWARD_EBS"))
            {
                workSheet = (Microsoft.Office.Interop.Excel.Worksheet)workBook.Worksheets.get_Item(1);
                Microsoft.Office.Interop.Excel.Range range;
                range = (Microsoft.Office.Interop.Excel.Range)workSheet.Application.Rows[1, Type.Missing];
                range.Select();
                range.Delete(Microsoft.Office.Interop.Excel.XlDirection.xlUp);
            }
            //workSheet.Cells[1, 1].EntireRow.Font.Bold = true;
            workSheet.Columns.AutoFit();
            excelCellrange = workSheet.UsedRange;
            excelCellrange2 = excelCellrange.get_Range("A1", Type.Missing);
            excelCellrange2.EntireRow.Font.Bold = true;
            Microsoft.Office.Interop.Excel.Borders border = excelCellrange.Borders;
            border.LineStyle = Microsoft.Office.Interop.Excel.XlLineStyle.xlContinuous;
            border.Weight = 2d;

            // check file path
            if (!string.IsNullOrEmpty(Save_File_Path))
            {
                try
                {
                    if (Save_File_Path.Contains("India - RBI Main Account"))
                    {
                        excelCellrange2 = workSheet.get_Range("A1", Type.Missing);
                        excelCellrange2.EntireRow.Delete(Type.Missing);
                        workBook.SaveCopyAs(Save_File_Path);
                        workBook.Close();
                        excelApp.Quit();
                        ReleaseComObject(workSheet);
                        ReleaseComObject(workBook);
                        ReleaseComObject(excelApp);
                    }
                    else
                    {
                        workBook.SaveCopyAs(Save_File_Path);
                        workBook.Close();
                        excelApp.Quit();
                    }
                    ReleaseComObject(workSheet);
                    ReleaseComObject(workBook);
                    ReleaseComObject(excelApp);
                }
                catch
                {
                    workBook.SaveCopyAs(Save_File_Path);
                    workBook.Close();
                    excelApp.Quit();

                    ReleaseComObject(workSheet);
                    ReleaseComObject(workBook);
                    ReleaseComObject(excelApp);
                }
                finally
                {
                    ReleaseComObject(workSheet);
                    ReleaseComObject(workBook);
                    ReleaseComObject(excelApp);
                }
            }

        }

        public void ExportToExcel_PHP(System.Data.DataTable dt, string Recon_Date, ref string excelFilePath, string Recon_Name, string Output_Path, string Share_Path, string Formatted_File_Name)
        {

            var excelApp = new Microsoft.Office.Interop.Excel.Application();

            Microsoft.Office.Interop.Excel.Workbook workBook = null;
            workBook = excelApp.Workbooks.Add(Type.Missing);
            Microsoft.Office.Interop.Excel._Worksheet workSheet = (Microsoft.Office.Interop.Excel.Worksheet)workBook.Worksheets.Add(Type.Missing);
            excelApp.DisplayAlerts = false;
            excelApp.Visible = false;

            for (var i = 2; i < dt.Rows.Count; i++)
            {
                for (var k = 0; k < dt.Columns.Count; k++)
                {
                    workSheet.Cells[i + 2, k + 1] = dt.Rows[i][k];
                }
            }
            //workSheet.Cells[1, 1].EntireRow.Font.Bold = true;
            workSheet.Columns.AutoFit();
            // check file path
            if (!string.IsNullOrEmpty(excelFilePath))
            {
                try
                {
                    workBook.SaveCopyAs(excelFilePath);
                    excelApp.Quit();

                    ReleaseComObject(workSheet);
                    ReleaseComObject(workBook);
                    ReleaseComObject(excelApp);
                }
                catch
                {
                    //throw ex;
                }
                FileRename(Directory_Temp, Share_Path, Recon_Name, Output_Path, Recon_Date, Formatted_File_Name);
            }

        }

        public void SouthAfrica_Stock_openitems(string Rec_Date, string FileName, string DestPath, string Formatted_FileName, string Extn)
        {
            string filePath1 = @"\\10.210.12.21\cdshldrn\" + FileName;

            if (File.Exists(filePath1))
            {
                // File.Copy(filePath1, Path.ChangeExtension(DestPath + Formatted_FileName + Rec_Date, ".dat"));
            }
        }

        public void QatarStockRecon(string filePath1, string Recon_Date, string DestPath, string Recon_Name, string SharePath, string Formatted_File_Name, string File_Name)
        {
            string path = DestPath + File_Name + ".csv";
            string ExcelfilePath = DestPath + File_Name + ".xlsx";
            if (File.Exists(DestPath + File_Name + ".csv"))
            {
                //File.Move(DestPath + File_Name + ".csv", Path.ChangeExtension(DestPath + File_Name + ".csv", ".xlsx"));

                Microsoft.Office.Interop.Excel.Application app = new Microsoft.Office.Interop.Excel.Application();
                app.DisplayAlerts = false;
                app.Visible = false;
                Workbook wb = app.Workbooks.Open(path, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                wb.SaveAs(ExcelfilePath, XlFileFormat.xlOpenXMLWorkbook, Type.Missing, Type.Missing, Type.Missing, Type.Missing, XlSaveAsAccessMode.xlExclusive, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                wb.Close();
                app.Quit();

                ReleaseComObject(wb);
                ReleaseComObject(app);
            }



            System.Data.DataTable dtexcel1 = new System.Data.DataTable();
            System.Data.DataTable dt1 = new System.Data.DataTable();
            dt1.Columns.Add("");
            string strConn1 = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + ExcelfilePath + ";Extended Properties='Excel 8.0;HDR=YES'";

            OleDbConnection conn1 = new OleDbConnection(strConn1);
            conn1.Open();
            System.Data.DataTable schemaTable1 = conn1.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, new object[] { null, null, null, "TABLE" });

            DataRow schemaRow = schemaTable1.Rows[0];
            string sheet1 = schemaRow["TABLE_NAME"].ToString();

            OleDbDataAdapter daexcel1 = null;
            if (!sheet1.EndsWith("_"))
            {
                string query = "SELECT  * FROM [" + sheet1 + "]";
                daexcel1 = new OleDbDataAdapter(query, conn1);
                dtexcel1.Locale = CultureInfo.CurrentCulture;
                daexcel1.Fill(dtexcel1);
            }
            conn1.Close();
            for (int i = dtexcel1.Rows.Count - 1; i >= 0; i--)
            {
                string ts = "";
                if (dtexcel1.Rows[i][1].ToString().Contains("±"))
                {
                    dtexcel1.Rows[i][1] = "";
                }
                if (dtexcel1.Rows[i][2].ToString().All(char.IsDigit) == true)
                {
                    if (dtexcel1.Rows[i][2].ToString().Length == 1)
                    {
                        ts = "'00" + dtexcel1.Rows[i][2];
                        dtexcel1.Rows[i][2] = ts;
                    }
                    else if (dtexcel1.Rows[i][2].ToString().Length == 2)
                    {
                        ts = "'0" + dtexcel1.Rows[i][2];
                        dtexcel1.Rows[i][2] = ts;
                    }
                    else
                    {
                        ts = "'" + dtexcel1.Rows[i][2];
                        dtexcel1.Rows[i][2] = ts;
                    }
                }
            }
            for (int i = 0; i <= dtexcel1.Rows.Count - 1; i++)
            {
                if (dtexcel1.Rows[i][1].ToString() == "")
                {
                    dtexcel1.Rows[i][1] = "???? ????? ?????? ?????? ?????????";
                }

            }
            ExportToExcel_Common(dtexcel1, DestPath + Formatted_File_Name + ".csv");
            FileRenameForQatar(Directory_Temp, SharePath, Recon_Name, DestPath, Recon_Date, Formatted_File_Name);
        }

        public void ThailandCustodyDepo(string filePath1, string Recon_Date, string DestPath, string Recon_Name, string SharePath, string Formatted_File_Name)
        {

            System.Data.DataTable Final = new System.Data.DataTable();
            Final.Columns.Add("PARTI ID");
            Final.Columns.Add("SEG AC NO");
            Final.Columns.Add("PORT/CLIENT FLAG");
            Final.Columns.Add("MARKET ID");
            Final.Columns.Add("SYMBOL");
            Final.Columns.Add("ISIN");
            Final.Columns.Add("TRADING FLAG");
            Final.Columns.Add("BALANCE STATUS");
            Final.Columns.Add("BALANCE QTY");
            Final.Columns.Add("PENDING WITHDRAW");
            Final.Columns.Add("PENDING DEPOSIT");
            Final.Columns.Add("PENDING DELIVERY");
            Final.Columns.Add("BROKERAGE AC ID");
            if (File.Exists(filePath1))
            {
                StreamReader objReader;
                objReader = new StreamReader(filePath1);
                string[] lines = System.IO.File.ReadAllLines(filePath1);

                for (int i = 0; i <= lines.Length - 1; i++)
                {
                    string[] ar = System.Text.RegularExpressions.Regex.Split(lines[i].ToString(), @"\s{2,}");
                    Final.Rows.Add();

                    Final.Rows[i][0] = ar[0].ToString().Substring(0, 3);
                    Final.Rows[i][1] = Convert.ToInt32(ar[0].ToString().Substring(3, 10));

                    Final.Rows[i][2] = ar[0].ToString().Substring(13, 1);

                    Final.Rows[i][3] = ar[0].ToString().Substring(14, 1);
                    Final.Rows[i][4] = ar[0].ToString().Substring(15, ar[0].ToString().Length - 15);
                    string[] ar1 = ar[1].ToString().Split(' ');

                    Final.Rows[i][5] = ar1[0].ToString().Substring(0, ar1[0].ToString().Length - 2);
                    Final.Rows[i][6] = ar1[0].ToString().Substring(ar1[0].ToString().Length - 2, 1);
                    Final.Rows[i][7] = ar1[0].ToString().Substring(ar1[0].ToString().Length - 1, 1);
                    Final.Rows[i][8] = ar1[1].ToString();

                    Final.Rows[i][9] = ar[2].ToString();
                    Final.Rows[i][10] = ar[3].ToString();
                    Final.Rows[i][11] = ar[4].ToString();
                    Final.Rows[i][12] = ar[5].ToString();

                }
                ExportToExcelForThailandDepo(Final, Recon_Date, ref DestPath, Recon_Name, DestPath, SharePath, Formatted_File_Name);
            }
        }

        public void ExportToExcelForThailandDepo(System.Data.DataTable tbl, string Recon_Date, ref string excelFilePath, string Recon_Name, string Output_Path, string Share_Path, string Formatted_File_Name)
        {
            string strDirectory = Share_Path;

            excelFilePath = strDirectory + @"Files_For_Formatting_Or_Non_Formatting\" + Recon_Name + @"\Formatting\PSGL_5381077_PHPCLG_DDMMYYYY.xls";
            try
            {
                if (tbl == null || tbl.Columns.Count == 0)
                    return;//throw new Exception("ExportToExcel: Null or empty input table!\n");

                // load excel, and create a new workbook
                var excelApp = new Microsoft.Office.Interop.Excel.Application();
                Microsoft.Office.Interop.Excel.Workbook workBook = null;
                workBook = excelApp.Workbooks.Add(Type.Missing);                // single worksheet
                Microsoft.Office.Interop.Excel._Worksheet workSheet = (Microsoft.Office.Interop.Excel.Worksheet)workBook.Worksheets.Add(Type.Missing);
                excelApp.DisplayAlerts = false;
                excelApp.Visible = false;
                for (var i = 0; i < tbl.Columns.Count; i++)
                {
                    workSheet.Cells[1, i + 1] = tbl.Columns[i].ColumnName;
                }

                // rows
                for (var i = 0; i < tbl.Rows.Count; i++)
                {
                    // to do: format datetime values before printing
                    for (var j = 0; j < tbl.Columns.Count; j++)
                    {
                        workSheet.Cells[i + 2, j + 1] = tbl.Rows[i][j];
                    }
                }
                try
                {
                    Excel.Range usedrange = workSheet.UsedRange;
                    Excel.Range r = usedrange.get_Range("A1", Type.Missing);
                    r.EntireRow.Font.Bold = true;
                    Microsoft.Office.Interop.Excel.Borders border = usedrange.Borders;
                    border.LineStyle = Microsoft.Office.Interop.Excel.XlLineStyle.xlContinuous;
                    border.Weight = 2d;
                    workSheet.Columns.EntireColumn.AutoFit();
                    if (!File.Exists(Output_Path + "Final_Output.xlsx"))
                        workBook.SaveCopyAs(Output_Path + "PSGL_5381077_PHPCLG_" + Recon_Date + ".xlsx");
                    //workBook.SaveCopyAs(@"\\10.132.5.214\TempFiles\SAHIL\UAT_Runtimes\ARCRuntime\22-Mar-2017_Files\Output\Singapore SEC RPR\Final_Output_2.xlsx");
                    else
                        workBook.SaveCopyAs(Output_Path + "Final_Output_2.xlsx");
                    //File.Copy(excelFilePath, (Output_Path + "Final_Output.xls"));
                    excelApp.Quit();
                    //MessageBox.Show("Excel file saved!");
                }
                catch
                {
                    //throw new Exception("ExportToExcel: Excel file could not be saved! Check filepath.\n" + ex.Message);
                }
                ReleaseComObject(workSheet);
                ReleaseComObject(workBook);
                ReleaseComObject(excelApp);
            }
            catch
            {
                //MessageBox.Show("ExportToExcel: \n" + ex.Message);
            }
            if (!File.Exists(Directory_Temp + "PSGL_5381077_PHPCLG_" + Recon_Date + ".csv"))
            {
                File.Move(Output_Path + "PSGL_5381077_PHPCLG_" + Recon_Date + ".xlsx", Path.ChangeExtension(Directory_Temp + "PSGL_5381077_PHPCLG_" + Recon_Date + ".xlsx", ".csv"));
            }
            FileRename(Directory_Temp, Share_Path, Recon_Name, Output_Path, Recon_Date, Formatted_File_Name);
        }

        public void VIETNAM_ACB_Formatting(string filePath, string Recon_Date, string Output_Path, int hol)
        {
            try
            {
                if (File.Exists(filePath))
                {
                    string strConn2 = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + filePath + ";Extended Properties=\"Excel 12.0;HDR=Yes;IMEX=1\"";
                    System.Data.DataTable dtexcel2 = new System.Data.DataTable();
                    OleDbConnection conn2 = new OleDbConnection(strConn2);
                    conn2.Open();
                    System.Data.DataTable schemaTable2 = conn2.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, new object[] { null, null, null, "TABLE" });

                    DataRow schemaRow2 = schemaTable2.Rows[0];
                    string sheet2 = schemaRow2["TABLE_NAME"].ToString();
                    if (!sheet2.EndsWith("_"))
                    {
                        string query2 = "SELECT  * FROM [" + sheet2 + "]";
                        OleDbDataAdapter daexcel2 = new OleDbDataAdapter(query2, conn2);
                        dtexcel2.Locale = CultureInfo.CurrentCulture;
                        daexcel2.Fill(dtexcel2);
                    }

                    System.Data.DataTable dt = new System.Data.DataTable();
                    dt.Columns.Add("Date");
                    dt.Columns.Add("Amount");
                    int x = 0;
                    for (int i = 0; i <= dtexcel2.Rows.Count - 1; i++)
                    {
                        if (dtexcel2.Rows[i][9].ToString().Contains("/"))
                        {
                            dt.Rows.Add();
                            dt.Rows[x][0] = dtexcel2.Rows[i][9];
                            x++;
                        }
                        else if (dtexcel2.Rows[i][10].ToString().Contains("/"))
                        {
                            dt.Rows.Add();
                            dt.Rows[x][0] = dtexcel2.Rows[i][10];
                            x++;
                        }
                    }


                    string Date = Recon_Date;
                    DateTime myDate = DateTime.ParseExact(Date, "yyyyMMdd", System.Globalization.CultureInfo.InvariantCulture);

                    Date = myDate.AddDays(-hol).ToString("MM/dd/yyyy");
                    string dm = "";
                    string val = "";
                    for (int i = 0; i <= dt.Rows.Count - 1; i++)
                    {
                        string[] ar2 = dt.Rows[i][0].ToString().Trim().Split('/');
                        if (ar2[1].Length == 1 && ar2[0].Length == 2)
                        {
                            dm = "0" + ar2[1] + "/" + ar2[0] + "/" + ar2[2];
                        }
                        else if (ar2[1].Length == 2 && ar2[0].Length == 1)
                        {
                            dm = ar2[1] + "/" + "0" + ar2[0] + "/" + ar2[2];
                        }
                        else if (ar2[0].Length == 1 && ar2[1].Length == 1)
                        {
                            dm = "0" + ar2[1] + "/" + "0" + ar2[0] + "/" + ar2[2];
                        }
                        else if (ar2[0].Length == 2 && ar2[1].Length == 2)
                        {
                            dm = ar2[1] + "/" + ar2[0] + "/" + ar2[2];
                        }
                        if (dm == Date.Trim() || dm == Date.Replace("/20", "/").Trim())
                        {
                            val = "True";
                        }
                        else
                        {
                            val = "False";
                            break;
                        }
                    }

                    if (val == "True")
                    {
                        DateTime d = DateTime.ParseExact(Recon_Date, "yyyyMMdd", CultureInfo.InvariantCulture);

                        Recon_Date = d.AddDays(-hol).ToString("ddMMyyyy");


                        File.Copy(filePath, Path.ChangeExtension(Output_Path + "SCB_ACBS_ISS_DATED_" + Recon_Date, ".csv"));

                    }
                }
            }
            catch
            {

            }
        }

        public void VIETNAM_Purchase_VISA_ACQUIRER(string filePath, string Recon_Date, string OutPut_Path, string FileName, int hol)
        {
            try
            {
                if (File.Exists(filePath))
                {
                    string strConn2 = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + filePath + ";Extended Properties=\"Excel 12.0;HDR=Yes;IMEX=1\"";
                    System.Data.DataTable dtexcel2 = new System.Data.DataTable();
                    OleDbConnection conn2 = new OleDbConnection(strConn2);
                    conn2.Open();
                    System.Data.DataTable schemaTable2 = conn2.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, new object[] { null, null, null, "TABLE" });
                    DataRow schemaRow2 = schemaTable2.Rows[0];
                    string sheet2 = schemaRow2["TABLE_NAME"].ToString();
                    if (!sheet2.EndsWith("_"))
                    {
                        string query2 = "SELECT  * FROM [" + sheet2 + "]";
                        OleDbDataAdapter daexcel2 = new OleDbDataAdapter(query2, conn2);
                        dtexcel2.Locale = CultureInfo.CurrentCulture;
                        daexcel2.Fill(dtexcel2);

                    }
                    string Date = Recon_Date;
                    DateTime myDate = DateTime.ParseExact(Date, "yyyyMMdd", System.Globalization.CultureInfo.InvariantCulture);


                    Date = myDate.AddDays(-hol).ToString("dd/MM/yyyy");


                    string dt = "";
                    string dt1 = "";
                    string val = "";
                    if (FileName.Contains("Purchase"))
                    {
                        for (int i = 0; i <= dtexcel2.Rows.Count - 1; i++)
                        {
                            if (dtexcel2.Rows[i][6].ToString() != "")
                            {
                                string[] ar = dtexcel2.Rows[i][6].ToString().Trim().Split(' ');

                                string[] br2 = ar[0].ToString().Split('/');

                                if (br2[1].Length == 1 && br2[0].Length == 2)
                                {
                                    dt = "0" + br2[1] + "/" + br2[0] + "/" + br2[2];

                                }
                                else if (br2[1].Length == 2 && br2[0].Length == 1)
                                {
                                    dt = br2[1] + "/" + "0" + br2[0] + "/" + br2[2];

                                }
                                else if (br2[0].Length == 1 && br2[1].Length == 1)
                                {
                                    dt = "0" + br2[1] + "/" + "0" + br2[0] + "/" + br2[2];

                                }
                                else if (br2[0].Length == 2 && br2[1].Length == 2)
                                {
                                    dt = br2[1] + "/" + br2[0] + "/" + br2[2];

                                }

                                if (Date == dt)
                                {
                                    val = "True";
                                }
                                else
                                {
                                    val = "False";
                                    break;
                                }
                            }
                        }

                    }
                    else if (FileName.Contains("VISA ACQUIRER"))
                    {
                        for (int i = 0; i <= dtexcel2.Rows.Count - 1; i++)
                        {

                            string[] ar1 = dtexcel2.Rows[i][0].ToString().Trim().Split(' ');

                            string[] br3 = ar1[0].ToString().Split('/');
                            if (br3[1].Length == 1 && br3[0].Length == 2)
                            {

                                dt1 = "0" + br3[1] + "/" + br3[0] + "/" + br3[2];
                            }
                            else if (br3[1].Length == 2 && br3[0].Length == 1)
                            {

                                dt1 = br3[1] + "/" + "0" + br3[0] + "/" + br3[2];
                            }
                            else if (br3[0].Length == 1 && br3[1].Length == 1)
                            {

                                dt1 = "0" + br3[1] + "/" + "0" + br3[0] + "/" + br3[2];
                            }
                            else if (br3[0].Length == 2 && br3[1].Length == 2)
                            {

                                dt1 = br3[1] + "/" + br3[0] + "/" + br3[2];
                            }




                            if (Date == dt1)
                            {
                                val = "True";
                            }
                            else
                            {
                                val = "False";
                                break;
                            }
                        }

                    }
                    if (val == "True")
                    {

                        if (filePath.Contains("Purchase"))
                        {
                            File.Copy(filePath, Path.ChangeExtension(OutPut_Path + "SCB_VISA_ISS_DATED_" + Date.Replace("/", ""), ".csv"));
                        }
                        else if (filePath.Contains("VISA ACQUIRER SETTLEMENT-EP745-"))
                        {
                            File.Copy(filePath, Path.ChangeExtension(OutPut_Path + "SCB_VISA_ACQ_DATED_" + Date.Replace("/", ""), ".csv"));
                        }
                    }
                }
            }
            catch
            {

            }
        }

        public void SWITCH_REPORT(string filePath, string Recon_Date, string OutPut_Path)
        {
            try
            {
                if (File.Exists(filePath))
                {
                    string strConn2 = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + filePath + ";Extended Properties=\"Excel 12.0;HDR=Yes;IMEX=1\"";
                    System.Data.DataTable dtexcel2 = new System.Data.DataTable();
                    OleDbConnection conn2 = new OleDbConnection(strConn2);
                    conn2.Open();
                    System.Data.DataTable schemaTable2 = conn2.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, new object[] { null, null, null, "TABLE" });

                    DataRow schemaRow2 = schemaTable2.Rows[0];
                    string sheet2 = schemaRow2["TABLE_NAME"].ToString();
                    if (!sheet2.EndsWith("_"))
                    {
                        string query2 = "SELECT  * FROM [" + sheet2 + "]";
                        OleDbDataAdapter daexcel2 = new OleDbDataAdapter(query2, conn2);
                        dtexcel2.Locale = CultureInfo.CurrentCulture;
                        daexcel2.Fill(dtexcel2);

                    }
                    string Flag = "";
                    System.Data.DataTable dt = new System.Data.DataTable();
                    dt.Columns.Add("Response Code");
                    dt.Columns.Add("PAN Number");
                    dt.Columns.Add("Member Number");
                    dt.Columns.Add("Approval Number");
                    dt.Columns.Add("System Trace Audit Number");
                    dt.Columns.Add("Transaction Date");
                    dt.Columns.Add("Transaction Time");
                    dt.Columns.Add("Merchant Category Code");
                    dt.Columns.Add("Card Acceptor Settl Date");
                    dt.Columns.Add("Card Acceptor ID");
                    dt.Columns.Add("Card Acceptor Terminal ID");
                    dt.Columns.Add("Card Acceptor Term. Location");
                    dt.Columns.Add("Aquirer ID");
                    dt.Columns.Add("Transaction Currency Code");
                    dt.Columns.Add("Transaction Amount");
                    dt.Columns.Add("Billing Amount");
                    string Date = "";
                    DateTime myDate = DateTime.ParseExact(Recon_Date, "yyyyMMdd", System.Globalization.CultureInfo.InvariantCulture);
                    Recon_Date = Convert.ToDateTime(myDate).ToString("yyMMdd");
                    if (myDate.AddDays(-1).DayOfWeek.ToString() == "Sunday")
                    {
                        Date = myDate.AddDays(-3).ToString("yyMMdd");
                    }
                    else
                    {
                        Date = myDate.AddDays(-1).ToString("yyMMdd");
                    }


                    for (int i = 0; i <= dtexcel2.Rows.Count - 1; i++)
                    {
                        if (dtexcel2.Rows[i][10].ToString().Trim() == Date)
                        {
                            dt.Rows.Add();
                            dt.Rows[i][0] = dtexcel2.Rows[i][0];
                            dt.Rows[i][1] = dtexcel2.Rows[i][1];
                            dt.Rows[i][2] = dtexcel2.Rows[i][2];
                            dt.Rows[i][3] = dtexcel2.Rows[i][3];
                            dt.Rows[i][4] = dtexcel2.Rows[i][4];
                            dt.Rows[i][5] = dtexcel2.Rows[i][5];
                            dt.Rows[i][6] = dtexcel2.Rows[i][6];
                            dt.Rows[i][7] = dtexcel2.Rows[i][7];
                            dt.Rows[i][8] = dtexcel2.Rows[i][8];
                            dt.Rows[i][9] = dtexcel2.Rows[i][9];
                            dt.Rows[i][10] = dtexcel2.Rows[i][10];
                            dt.Rows[i][11] = dtexcel2.Rows[i][11];
                            dt.Rows[i][12] = dtexcel2.Rows[i][12];
                            dt.Rows[i][13] = dtexcel2.Rows[i][13];
                            dt.Rows[i][14] = dtexcel2.Rows[i][14];
                            dt.Rows[i][15] = dtexcel2.Rows[i][15];
                            Flag = "True";
                        }
                        else if (dtexcel2.Rows[i][10].ToString().Trim() == Recon_Date)
                        {
                            dt.Rows.Add();
                            dt.Rows[i][0] = dtexcel2.Rows[i][0];
                            dt.Rows[i][1] = dtexcel2.Rows[i][1];
                            dt.Rows[i][2] = dtexcel2.Rows[i][2];
                            dt.Rows[i][3] = dtexcel2.Rows[i][3];
                            dt.Rows[i][4] = dtexcel2.Rows[i][4];
                            dt.Rows[i][5] = dtexcel2.Rows[i][5];
                            dt.Rows[i][6] = dtexcel2.Rows[i][6];
                            dt.Rows[i][7] = dtexcel2.Rows[i][7];
                            dt.Rows[i][8] = dtexcel2.Rows[i][8];
                            dt.Rows[i][9] = dtexcel2.Rows[i][9];
                            dt.Rows[i][10] = dtexcel2.Rows[i][10];
                            dt.Rows[i][11] = dtexcel2.Rows[i][11];
                            dt.Rows[i][12] = dtexcel2.Rows[i][12];
                            dt.Rows[i][13] = dtexcel2.Rows[i][13];
                            dt.Rows[i][14] = dtexcel2.Rows[i][14];
                            dt.Rows[i][15] = dtexcel2.Rows[i][15];
                            Flag = "True";
                        }
                        else
                        {
                            Flag = "False";
                            break;
                        }
                    }

                    if (Flag == "True")
                    {
                        DateTime myDate1 = DateTime.ParseExact(Recon_Date, "yyMMdd", System.Globalization.CultureInfo.InvariantCulture);

                        Recon_Date = myDate.ToString("ddMMyyyy");
                        ExportToExcel_Common(dt, OutPut_Path + "SCB_VISA_SWCH_DATED_" + Recon_Date + ".csv");
                    }
                }
            }
            catch
            {

            }
        }

        public void Vietnam_VNPAY_inc_scvn(string filePath, string Recon_Date, string OutPut_Path, string Date, int hol)
        {
            string strConn2 = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + filePath + ";Extended Properties=\"Excel 12.0;HDR=Yes;IMEX=1\"";
            System.Data.DataTable dtexcel2 = new System.Data.DataTable();
            OleDbConnection conn2 = new OleDbConnection(strConn2);
            conn2.Open();
            System.Data.DataTable schemaTable2 = conn2.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, new object[] { null, null, null, "TABLE" });
            DataRow schemaRow2 = schemaTable2.Rows[0];
            string sheet2 = schemaRow2["TABLE_NAME"].ToString();
            if (!sheet2.EndsWith("_"))
            {
                string query2 = "SELECT  * FROM [" + sheet2 + "]";
                OleDbDataAdapter daexcel2 = new OleDbDataAdapter(query2, conn2);
                dtexcel2.Locale = CultureInfo.CurrentCulture;
                daexcel2.Fill(dtexcel2);

            }

            string Date2 = Recon_Date.Substring(0, 5).Replace("/", "");
            string val = "";
            for (int i = 0; i <= dtexcel2.Rows.Count - 1; i++)
            {
                if (Date2.Substring(2, 2) + Date2.Substring(0, 2) == dtexcel2.Rows[i][6].ToString())
                {
                    val = "True";
                }
                else
                {
                    val = "False";
                    break;
                }
            }

            if (val == "True")
            {

                File.Copy(filePath, Path.ChangeExtension(OutPut_Path + "SCB_VPN_DATED_" + Recon_Date.Replace("/", ""), ".csv"));
            }
        }

        public void Vietnam_I_banking_IBANKING_SETTLEMENT(string filePath, string Recon_Date, string OutPut_Path, string FmtFileName, string Ext, int hol)
        {
            string Flag = "";
            try
            {
                string strConn = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + filePath + ";Extended Properties=\"Excel 12.0;HDR=Yes;IMEX=1\"";
                System.Data.DataTable dtexcel = new System.Data.DataTable();
                OleDbConnection conn = new OleDbConnection(strConn);

                //excel = new Excel.Application();
                //excel.Visible = false;
                //excel.DisplayAlerts = false;
                //excelworkBook = excel.Workbooks.Open(filePath, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                conn.Open();
                System.Data.DataTable schemaTable = conn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, new object[] { null, null, null, "TABLE" });
                //Looping Total Sheet of Xl File
                DataRow schemaRow = schemaTable.Rows[0];
                string sheet = schemaRow["TABLE_NAME"].ToString();
                if (!sheet.EndsWith("_"))
                {
                    string query = "SELECT  * FROM [" + sheet + "]";
                    OleDbDataAdapter daexcel = new OleDbDataAdapter(query, conn);
                    dtexcel.Locale = CultureInfo.CurrentCulture;
                    daexcel.Fill(dtexcel);

                }
                System.Data.DataTable dt = new System.Data.DataTable();
                dt.Columns.Add("NUM");
                dt.Columns.Add("STAN");
                dt.Columns.Add("Card number");
                dt.Columns.Add("Processing code");
                dt.Columns.Add("Transaction amount");
                dt.Columns.Add("Trans time");
                dt.Columns.Add("Trans date");
                dt.Columns.Add("Settle date");
                dt.Columns.Add("MCC");
                dt.Columns.Add("FID");
                dt.Columns.Add("Approval code");
                dt.Columns.Add("Terminal ID");
                dt.Columns.Add("CCY");
                dt.Columns.Add("From Acct");
                dt.Columns.Add("To Acct");
                dt.Columns.Add("MTI");
                dt.Columns.Add("Reconciliation code");
                int x = 0;

                string[] Date = Recon_Date.Split('/');
                DateTime d1 = DateTime.ParseExact(Recon_Date, "ddMMyyyy", CultureInfo.InvariantCulture);
                string Date1 = "";

                Date1 = d1.AddDays(-hol).ToString("MMddyyyy");

                for (int i = 0; i <= dtexcel.Rows.Count - 2; i++)
                {
                    if (dtexcel.Rows[i][6].ToString().Trim() != "")
                    {
                        if (dtexcel.Rows[i][6].ToString().Trim() == Date1.Substring(0, 4))
                        {
                            Flag = "True";
                            dt.Rows.Add();
                            dt.Rows[x][0] = dtexcel.Rows[i][0];
                            dt.Rows[x][1] = dtexcel.Rows[i][1];
                            dt.Rows[x][2] = dtexcel.Rows[i][2];
                            dt.Rows[x][3] = dtexcel.Rows[i][3];
                            dt.Rows[x][4] = dtexcel.Rows[i][4];
                            dt.Rows[x][5] = dtexcel.Rows[i][5];
                            dt.Rows[x][6] = dtexcel.Rows[i][6];
                            dt.Rows[x][7] = dtexcel.Rows[i][7];
                            dt.Rows[x][8] = dtexcel.Rows[i][8];
                            dt.Rows[x][9] = dtexcel.Rows[i][9];
                            dt.Rows[x][10] = dtexcel.Rows[i][10];
                            dt.Rows[x][11] = dtexcel.Rows[i][11];
                            dt.Rows[x][12] = dtexcel.Rows[i][12];
                            dt.Rows[x][13] = dtexcel.Rows[i][13];
                            dt.Rows[x][14] = dtexcel.Rows[i][14];
                            dt.Rows[x][15] = dtexcel.Rows[i][15];
                            dt.Rows[x][16] = dtexcel.Rows[i][16];
                            x++;
                        }
                        else
                        {
                            Flag = "False";
                            //MessageBox.Show("Date Does not match With recon Date");
                            break;
                        }
                    }
                }

                if (Flag == "True")
                {
                    DateTime d11 = DateTime.ParseExact(Recon_Date, "ddMMyyyy", CultureInfo.InvariantCulture);
                    string Date11 = d1.AddDays(-hol).ToString("ddMMyyyy");

                    OutPut_Path = OutPut_Path + FmtFileName.Substring(0, FmtFileName.Length - 8) + Date11 + Ext;
                    ExportToExcel_Common(dtexcel, OutPut_Path);
                }
            }
            catch
            {
            }
            finally
            {
                //excelworkBook.Close();
                //excel.Quit();
                //ReleaseComObject(excelworkBook);
                //ReleaseComObject(excel);
            }
        }

        public void VIETNAM_IBANKING(string filePath, string Recon_Date, string OutPut_Path, string FmtFileName, string Ext, int hol)
        {
            try
            {
                string ExcelfilePath = "";
                Microsoft.Office.Interop.Excel.Application app = new Microsoft.Office.Interop.Excel.Application();
                app.DisplayAlerts = false;
                app.Visible = false;
                Workbook wb = app.Workbooks.Open(filePath, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);

                if (filePath.Contains("SWITCH REPORT"))
                {
                    ExcelfilePath = filePath.Substring(0, filePath.Length - 4) + "xlsx";
                }
                else
                {
                    ExcelfilePath = filePath.Substring(0, filePath.Length - 3) + "xlsx";
                }
                wb.SaveAs(ExcelfilePath, XlFileFormat.xlOpenXMLWorkbook, Type.Missing, Type.Missing, Type.Missing, Type.Missing, XlSaveAsAccessMode.xlExclusive, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                wb.Close();
                app.Quit();
                ReleaseComObject(wb);
                ReleaseComObject(app);
                foreach (Process clsProcess in Process.GetProcesses())
                    if (clsProcess.ProcessName.Equals("EXCEL"))  //Process Excel?
                        clsProcess.Kill();

                System.Data.DataTable dt1 = new System.Data.DataTable();
                System.Data.DataTable dt2 = new System.Data.DataTable();
                //strConn = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + filePath + ";Extended Properties=\"Excel 12.0;HDR=Yes;IMEX=1\"";
                string strConn = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + ExcelfilePath + ";Extended Properties=\"Excel 12.0;HDR=Yes;IMEX=1\"";
                //string strConn = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + filePath + "; Extended Properties = Excel 12.0;HDR=YES;IMEX=1";
                System.Data.DataTable dtexcel = new System.Data.DataTable();
                OleDbConnection conn = new OleDbConnection(strConn);

                excel = new Excel.Application();
                excel.DisplayAlerts = false;
                excel.Visible = false;
                excelworkBook = excel.Workbooks.Open(ExcelfilePath, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                conn.Open();
                System.Data.DataTable schemaTable = conn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, new object[] { null, null, null, "TABLE" });
                DataRow schemaRow = schemaTable.Rows[0];
                string sheet = schemaRow["TABLE_NAME"].ToString();
                if (!sheet.EndsWith("_"))
                {
                    string query = "SELECT  * FROM [" + sheet + "]";
                    OleDbDataAdapter daexcel = new OleDbDataAdapter(query, conn);
                    dtexcel.Locale = CultureInfo.CurrentCulture;
                    daexcel.Fill(dtexcel);
                }

                dt1 = dtexcel.Clone();
                dt1.Columns[7].DataType = typeof(string);
                foreach (DataRow row in dtexcel.Rows)
                {
                    dt1.ImportRow(row);
                }

                //dt1 = dtexcel.Clone();
                //dt1.Columns[7].DataType = typeof(string);
                //dt1.Columns[8].DataType = typeof(string);
                //dt1 = dtexcel.Copy();

                excelworkBook.Close();
                excel.Quit();
                ReleaseComObject(excelworkBook);
                ReleaseComObject(excel);

                string ext = Path.GetExtension(ExcelfilePath);
                string temp_FileName = filePath.Substring(filePath.LastIndexOf("\\")).Replace("\\", "");
                if (temp_FileName.Contains("SWITCH REPORT"))
                {
                    temp_FileName = temp_FileName.Substring(0, temp_FileName.Length - (8 + ext.Length));
                }
                else
                {
                    temp_FileName = temp_FileName.Substring(0, temp_FileName.Length - (8 + ext.Length - 1));
                }
                string Date = "";
                DateTime d = DateTime.ParseExact(Recon_Date, "yyyyMMdd", CultureInfo.InvariantCulture);

                Date = d.AddDays(-hol).ToString("yyyyMMdd");

                Recon_Date = d.ToString("yyyyMMdd");
                if (temp_FileName.Contains("SWITCH REPORT"))
                {
                    filePath = filePath.Substring(0, filePath.LastIndexOf("\\")) + "\\" + temp_FileName + Date + ext;
                }
                else
                {
                    if (DateTime.Today.DayOfWeek.ToString() != "Tuesday")
                    {
                        filePath = filePath.Substring(0, filePath.LastIndexOf("\\")) + "\\" + temp_FileName + Date + ext.Substring(0, 4);
                    }
                    else
                    {
                        DateTime d1 = DateTime.ParseExact(Recon_Date, "yyyyMMdd", CultureInfo.InvariantCulture);
                        string Date1 = "";
                        Date1 = d1.AddDays(-3).ToString("yyyyMMdd");
                        filePath = filePath.Substring(0, filePath.LastIndexOf("\\")) + "\\" + temp_FileName + Date1+"-"+Date.Substring(6,2) + ext.Substring(0, 4);
                    }
                }


                //************************************************************************//
                if (File.Exists(filePath))
                {
                    string ExcelfilePath2 = "";
                    Microsoft.Office.Interop.Excel.Application app2 = new Microsoft.Office.Interop.Excel.Application();
                    app2.DisplayAlerts = false;
                    app2.Visible = false;
                    Workbook wb2 = app2.Workbooks.Open(filePath, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                    ExcelfilePath2 = filePath.Substring(0, filePath.Length - 3) + "xlsx";
                    wb2.SaveAs(ExcelfilePath2, XlFileFormat.xlOpenXMLWorkbook, Type.Missing, Type.Missing, Type.Missing, Type.Missing, XlSaveAsAccessMode.xlExclusive, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                    wb2.Close();
                    app2.Quit();
                    ReleaseComObject(wb2);
                    ReleaseComObject(app2);
                    foreach (Process clsProcess in Process.GetProcesses())
                        if (clsProcess.ProcessName.Equals("EXCEL"))  //Process Excel?
                            clsProcess.Kill();

                    string strConn2 = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + ExcelfilePath2 + ";Extended Properties=\"Excel 12.0;HDR=Yes;IMEX=1\"";
                    excel = new Excel.Application();
                    excel.DisplayAlerts = false;
                    excel.Visible = false;
                    excelworkBook = excel.Workbooks.Open(ExcelfilePath2, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                    System.Data.DataTable dtexcel2 = new System.Data.DataTable();
                    OleDbConnection conn2 = new OleDbConnection(strConn2);
                    conn2.Open();
                    System.Data.DataTable schemaTable2 = conn2.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, new object[] { null, null, null, "TABLE" });
                    DataRow schemaRow2 = schemaTable2.Rows[0];
                    string sheet2 = schemaRow2["TABLE_NAME"].ToString();
                    if (!sheet2.EndsWith("_"))
                    {
                        string query2 = "SELECT  * FROM [" + sheet2 + "]";
                        OleDbDataAdapter daexcel2 = new OleDbDataAdapter(query2, conn2);
                        dtexcel2.Locale = CultureInfo.CurrentCulture;
                        daexcel2.Fill(dtexcel2);
                    }
                    dt2 = dtexcel2.Clone();
                    dt2.Columns[7].DataType = typeof(string);
                    foreach (DataRow row in dtexcel2.Rows)
                    {
                        dt2.ImportRow(row);
                    }
                    //dt2 = dtexcel2.Clone();
                    //dt2.Columns[7].DataType = typeof(string);
                    //dt2.Columns[8].DataType = typeof(string);
                    //dt2 = dtexcel2.Copy();
                    dt1.Merge(dt2);

                    DateTime d1 = DateTime.ParseExact(Recon_Date, "yyyyMMdd", CultureInfo.InvariantCulture);
                    string Date1 = "";

                    Date1 = d1.ToString("ddMMyyyy");

                    OutPut_Path = OutPut_Path + FmtFileName.Substring(0, FmtFileName.Length - 8) + Date1 + Ext;
                    ExportToExcel_Common(dt1, OutPut_Path);
                }
            }
            catch
            {
            }
            finally
            {
                excelworkBook.Close();
                excel.Quit();
                ReleaseComObject(excelworkBook);
                ReleaseComObject(excel);
            }
        }

        public void VIETNAM_ACB_SVNDTAQ(string filePath, string Recon_Date, string OutPut_Path, int hol)
        {
            if (File.Exists(filePath))
            {
                StreamReader objReader;
                objReader = new StreamReader(filePath);

                string[] lines = System.IO.File.ReadAllLines(filePath);
                string Date = Recon_Date.Replace("20", "");

                for (int i = 0; i <= lines.Length - 1; i++)
                {
                    if (lines[i].ToString().Contains("DATE"))
                    {
                        string[] ar = lines[i].Trim().Split('-');
                        string[] ar1 = System.Text.RegularExpressions.Regex.Split(ar[1].ToString(), @"\s{2,}");
                        string[] ar2 = ar1[1].ToString().Split('/');
                        string dt = "";

                        if (ar2[1].Length == 1 && ar2[0].Length == 2)
                        {
                            dt = "0" + ar2[1] + "/" + ar2[0] + "/" + ar2[2];
                        }
                        else if (ar2[1].Length == 2 && ar2[0].Length == 1)
                        {
                            dt = ar2[1] + "/" + "0" + ar2[0] + "/" + ar2[2];
                        }
                        else if (ar2[0].Length == 1 && ar2[1].Length == 1)
                        {
                            dt = "0" + ar2[1] + "/" + "0" + ar2[0] + "/" + ar2[2];
                        }
                        else if (ar2[0].Length == 2 && ar2[1].Length == 2)
                        {
                            dt = ar2[1] + "/" + ar2[0] + "/" + ar2[2];
                        }
                        objReader.Close();
                        DateTime d = DateTime.ParseExact(Date, "ddMMyy", CultureInfo.InvariantCulture);

                        Date = d.AddDays(-hol).ToString("ddMMyy");


                        if (Date == dt.Replace("/", ""))
                        {
                            try
                            {
                                DateTime d1 = DateTime.ParseExact(Recon_Date, "MMddyy", CultureInfo.InvariantCulture);
                                string Date1 = "";

                                Date1 = d.AddDays(-hol).ToString("ddMMyyyy");


                                File.Copy(filePath, Path.ChangeExtension(OutPut_Path + "SCB_ACBS_ACQ_DATED_" + Date1, ".txt"));
                                break;
                            }
                            catch
                            {

                            }
                        }
                        else
                        {
                            //MessageBox.Show("Recon date does not match");
                        }
                    }
                }
            }
            else
            {
                //MessageBox.Show("SVNDTAQ File Not Found");
            }
        }

        public void PHP_INWARD_CLEARING_MANILA(string filePath, string Recon_Date, string DestPath, string Recon_Name, string SharePath, string Formatted_File_Name)
        {

            if (File.Exists(filePath))
            {
                string strConn = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + filePath + ";Extended Properties=\"Excel 12.0;HDR=Yes;IMEX=1\"";
                System.Data.DataTable dtexcel = new System.Data.DataTable();
                OleDbConnection conn = new OleDbConnection(strConn);
                conn.Open();
                System.Data.DataTable schemaTable = conn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, new object[] { null, null, null, "TABLE" });
                DataRow schemaRow = schemaTable.Rows[0];
                string sheet = schemaRow["TABLE_NAME"].ToString();
                if (!sheet.EndsWith("_"))
                {
                    string query = "SELECT  * FROM [" + sheet + "]";
                    OleDbDataAdapter daexcel = new OleDbDataAdapter(query, conn);
                    dtexcel.Locale = CultureInfo.CurrentCulture;
                    daexcel.Fill(dtexcel);

                }

                dtexcel.Columns.Add("Tre Adv1").SetOrdinal(3);
                dtexcel.Columns.Add("Product Cd").SetOrdinal(4);
                for (int i = 0; i <= dtexcel.Rows.Count - 1; i++)
                {
                    dtexcel.Rows[i][3] = dtexcel.Rows[i][2].ToString().Trim();
                    dtexcel.Rows[i][4] = dtexcel.Rows[i][5].ToString().Trim();
                }
                dtexcel.Columns.RemoveAt(2);
                dtexcel.Columns.RemoveAt(4);
                System.Data.DataTable dt = new System.Data.DataTable();
                dt = dtexcel.Clone();

                dt.Rows.Add();
                dt.Rows[0][0] = "Credit / Debit";
                dt.Rows[0][1] = "Trn Code";
                dt.Rows[0][2] = "Tre Adv";
                dt.Rows[0][3] = "Product Code";
                dt.Rows[0][4] = "Master Acc NO";

                foreach (DataRow row in dtexcel.Rows)
                {
                    dt.ImportRow(row);
                }
                System.Data.DataTable dd1 = new System.Data.DataTable();
                dd1.Columns.Add("Product Code");
                dd1.Columns.Add("Date");
                int m = 0;
                for (int i = 0; i <= dt.Rows.Count - 1; i++)
                {

                    if (dt.Rows[i][3].ToString().Any(char.IsDigit) == true)
                    {
                        string dat = "";
                        if (dt.Rows[i][8].ToString() != "")
                        {
                            string[] date = dt.Rows[i][8].ToString().Split(' ');
                            string[] date1 = date[0].Split('/');

                            if (date1[1].Length == 1 && date1[0].Length == 2)
                            {
                                dat = "0" + date1[1] + "/" + date1[0] + "/" + date1[2];
                            }
                            else if (date1[1].Length == 2 && date1[0].Length == 1)
                            {
                                dat = date1[1] + "/" + "0" + date1[0] + "/" + date1[2];
                            }
                            else if (date1[1].Length == 1 && date1[0].Length == 1)
                            {
                                dat = "0" + date1[1] + "/" + "0" + date1[0] + "/" + date1[2];
                            }
                            else if (date1[1].Length == 2 && date1[0].Length == 2)
                            {
                                dat = date1[1] + "/" + date1[0] + "/" + date1[2];
                            }
                        }
                        else
                        {
                            dat = "";
                        }
                        string amt = "";
                        if (dt.Rows[i][3].ToString().Contains("."))
                        {
                            string[] split = dt.Rows[i][3].ToString().Split('.');
                            if (split[1].ToString().Length == 2)
                            {
                                amt = dt.Rows[i][3].ToString();
                            }
                            else
                            {
                                amt = dt.Rows[i][3].ToString() + "0";
                            }
                        }
                        else
                        {
                            amt = dt.Rows[i][3].ToString() + ".00";
                        }

                        dd1.Rows.Add();
                        dd1.Rows[m][0] = amt;
                        dd1.Rows[m][1] = dat;
                        m++;
                    }
                    else
                    {
                        dd1.Rows.Add();
                        dd1.Rows[m][0] = dt.Rows[i][3].ToString();
                        dd1.Rows[m][1] = "";
                        m++;
                    }
                }
                dt.Columns.RemoveAt(3);
                dt.Columns.RemoveAt(7);
                dt.Columns.Add("Product Code").SetOrdinal(3);
                dt.Columns.Add("Date").SetOrdinal(8);
                for (int i = 0; i <= dd1.Rows.Count - 1; i++)
                {
                    dt.Rows[i]["Product Code"] = dd1.Rows[i][0];
                    dt.Rows[i]["Date"] = dd1.Rows[i][1];
                }
                System.Data.DataTable dd2 = new System.Data.DataTable();
                dd2 = dt.Clone();
                int x = 0;
                for (int i = dt.Rows.Count - 8; i <= dt.Rows.Count - 1; i++)
                {
                    if (i == dt.Rows.Count - 8)
                    {
                        dd2.Rows.Add();
                        dd2.Rows[x][0] = dt.Rows[i][0];
                        dd2.Rows[x][1] = dt.Rows[i][1];
                        dd2.Rows[x][2] = dt.Rows[i][2];
                        dd2.Rows[x][3] = dt.Rows[i][3];
                        dd2.Rows[x][4] = dt.Rows[i][4];
                        dd2.Rows[x][5] = dt.Rows[i][5];
                        dd2.Rows[x][6] = dt.Rows[i][6];
                        dd2.Rows[x][7] = dt.Rows[i][7];
                        dd2.Rows[x][8] = dt.Rows[i][9];
                        dd2.Rows[x][9] = dt.Rows[i][10];
                        dd2.Rows[x][10] = dt.Rows[i][11];
                        dd2.Rows[x][11] = dt.Rows[i][12];
                        dd2.Rows[x][12] = dt.Rows[i][13];
                        dd2.Rows[x][13] = dt.Rows[i][14];
                        dd2.Rows[x][14] = dt.Rows[i][15];
                        dd2.Rows[x][15] = dt.Rows[i][16];
                        dd2.Rows[x][16] = dt.Rows[i][17];
                        dd2.Rows[x][17] = dt.Rows[i][18];
                        dd2.Rows[x][18] = "";
                        x++;
                    }
                    else
                    {
                        dd2.Rows.Add();
                        dd2.Rows[x][0] = dt.Rows[i][0];
                        dd2.Rows[x][1] = dt.Rows[i][1];
                        dd2.Rows[x][2] = dt.Rows[i][2];
                        dd2.Rows[x][3] = dt.Rows[i][3];
                        dd2.Rows[x][4] = dt.Rows[i][4];
                        dd2.Rows[x][5] = dt.Rows[i][5];
                        dd2.Rows[x][6] = dt.Rows[i][6];
                        dd2.Rows[x][7] = dt.Rows[i][7];
                        dd2.Rows[x][8] = dt.Rows[i][8];
                        dd2.Rows[x][9] = dt.Rows[i][9];
                        dd2.Rows[x][10] = dt.Rows[i][10];
                        dd2.Rows[x][11] = dt.Rows[i][11];
                        dd2.Rows[x][12] = dt.Rows[i][12];
                        dd2.Rows[x][13] = dt.Rows[i][13];
                        dd2.Rows[x][14] = dt.Rows[i][14];
                        dd2.Rows[x][15] = dt.Rows[i][15];
                        dd2.Rows[x][16] = dt.Rows[i][16];
                        dd2.Rows[x][17] = dt.Rows[i][17];
                        dd2.Rows[x][18] = dt.Rows[i][18];
                        x++;
                    }
                }

                for (int i = 8; i >= 1; i--)
                {
                    dt.Rows.RemoveAt(dt.Rows.Count - i);
                }
                dt.Merge(dd2);
                ExportDTToExcel(dt, DestPath + "SCB_PHP_CLG_INWARD_EBS_" + Recon_Date.Substring(6, 2) + Recon_Date.Substring(4, 2) + Recon_Date.Substring(0, 4) + ".xlsx");
                Microsoft.Office.Interop.Excel.Application excel = new Microsoft.Office.Interop.Excel.Application();
                Microsoft.Office.Interop.Excel.Workbook wb = excel.Workbooks.Open(DestPath + "SCB_PHP_CLG_INWARD_EBS_" + Recon_Date.Substring(6, 2) + Recon_Date.Substring(4, 2) + Recon_Date.Substring(0, 4) + ".xlsx", Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                Microsoft.Office.Interop.Excel._Worksheet ws = (Microsoft.Office.Interop.Excel.Worksheet)excel.ActiveSheet;// (Microsoft.Office.Interop.Excel.Worksheet)excel.Sheets["Sheet1"];
                excel.DisplayAlerts = false;
                excel.Visible = false;

                wb.SaveAs(SharePath + "SCB_PHP_CLG_INWARD_EBS_" + Recon_Date.Substring(6, 2) + Recon_Date.Substring(4, 2) + Recon_Date.Substring(0, 4) + ".csv", XlFileFormat.xlCSV, Type.Missing, Type.Missing, Type.Missing, Type.Missing, XlSaveAsAccessMode.xlExclusive, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                excel.Quit();
                ReleaseComObject(ws);
                ReleaseComObject(wb);
                ReleaseComObject(excel);
            }

        }

        public void PHP_INWARD_CLEARING_CB_INWARD(string filePath, string DestPath, string Recon_Name, string SharePath, string Formatted_File_Name, string ext)
        {

            if (File.Exists(filePath))
            {

                File.Copy(filePath, SharePath + Formatted_File_Name + ext);
            }
        }

        public void UAE_SWITCH_RECON(string inputFilePath, string Recon_Date, string OutPut_Path, string temp_FileName, string Formatted_File_Name, string Share_Path, string temp_FileNamehalf, string Output_Dir)
        {
            string inputFileNamePattern1 = @"*.xls";
            string[] inputFilePaths1 = Directory.GetFiles(Output_Dir, inputFileNamePattern1);
            var StatementDate = DateTime.Today;
            foreach (var fileName in inputFilePaths1)
            {
                System.Data.DataTable dtexcel1 = new System.Data.DataTable();
                System.Data.DataTable dt1 = new System.Data.DataTable();

                string strConn1;
                bool hasHeaders1 = true;
                string HDR1 = hasHeaders1 ? "Yes" : "No";

                if (fileName.Substring(fileName.LastIndexOf('.')).ToLower() == ".xlsx" || fileName.Substring(fileName.LastIndexOf('.')).ToLower() == ".xls")
                    strConn1 = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + fileName + ";Extended Properties='Excel 8.0;HDR=YES'";
                else
                    strConn1 = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + fileName + ";Extended Properties=\"Excel 8.0;HDR=" + HDR1 + ";IMEX=1\"";
                OleDbConnection conn1 = new OleDbConnection(strConn1);
                conn1.Open();
                System.Data.DataTable schemaTable1 = conn1.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, new object[] { null, null, null, "TABLE" });

                DataRow schemaRow = schemaTable1.Rows[0];
                string sheet1 = schemaRow["TABLE_NAME"].ToString();

                OleDbDataAdapter daexcel1 = null;
                if (!sheet1.EndsWith("_"))
                {
                    string query = "SELECT  * FROM [" + sheet1 + "]";
                    daexcel1 = new OleDbDataAdapter(query, conn1);
                    dtexcel1.Locale = CultureInfo.CurrentCulture;
                    daexcel1.Fill(dtexcel1);
                }
                conn1.Close();
                dt1.Columns.Add("Set");
                dt1.Columns.Add("date");
                dt1.Columns.Add("Amount");
                dt1.Columns.Add("CR/DR");
                dt1.Columns.Add("Ref01");
                dt1.Columns.Add("Ref02");
                string LeadgerDate = "";


                for (int j = 0; j <= dtexcel1.Rows.Count - 1; j++)
                {
                    string Accnt_Nam = dtexcel1.Rows[j][0].ToString();
                    string asa = dtexcel1.Rows[j][1].ToString();
                    string asb = dtexcel1.Rows[j][3].ToString();
                    if (Accnt_Nam.Contains("CA-AE-SWT-AED-001") && asa.Contains("UAE SWICH RECON"))
                    {
                        if (asb.Contains("S"))
                        {
                            StatementDate = Convert.ToDateTime(dtexcel1.Rows[j][4]);

                        }
                        else if (asb.Contains("L"))
                        {
                            LeadgerDate = dtexcel1.Rows[j][4].ToString();
                        }

                    }

                }
            }
            //***********************************************************************************//
            string inputDirectoryPath = Share_Path + "Input\\Emails\\";
            string inputFileNamePattern = @"*.txt";
            string[] inputFilePaths = Directory.GetFiles(inputDirectoryPath, inputFileNamePattern);
            foreach (var filePath in inputFilePaths)
            {
                try
                {

                    string Filee = Path.GetFileNameWithoutExtension(filePath);
                    var dqt = DateTime.ParseExact(Filee, "MMddyyyy", null);//CultureInfo.InvariantCulture

                    if (dqt > StatementDate)
                    {

                        System.Data.DataTable dt = new System.Data.DataTable("CreditCards");
                        dt.Columns.Add("File");
                        var lines = File.ReadAllLines(filePath);
                        StreamReader objReader = new StreamReader(filePath);

                        // reading rest of the data
                        for (int i = 0; i < lines.Count(); i++)
                        {
                            //DataRow dr = dt.NewRow();
                            string values = objReader.ReadLine();
                            if (values != null)
                            {
                                dt.Rows.Add();
                                dt.Rows[i][0] = values;
                            }
                        }

                        DataRow dr = (DataRow)dt.Rows[dt.Rows.Count - 1];
                        // DateTime Dates = Convert.ToDateTime(dt.Rows[0][0].ToString().Substring(2, 10));
                        // d
                        string Date = dt.Rows[0][0].ToString().Substring(2, 10);
                        string Mon = Date.ToString().Substring(0, 2);
                        string Day = Date.ToString().Substring(3, 2);
                        string Yer = Date.ToString().Substring(6, 4);
                        string Dates = Mon + Day + Yer;//Date.ToString("MMddyyyy");
                        string firstLetter = dr[0].ToString().Substring(0, 1);
                        if (firstLetter.Contains("6"))
                        {
                            if (Filee == Dates)
                            {
                                objReader.Close();
                                File.Move(filePath, Path.ChangeExtension(filePath, ".dat"));
                            }
                        }
                        //ChangeExtension(filePath, OutPut_Path, temp_FileName);
                        ChangeExtension(filePath, OutPut_Path, temp_FileNamehalf + Dates + ".dat");

                    }
                }
                catch
                {

                }
            }
        }

        public void ChangeExtension(string filePath, string excelFilePath, string temp_FileName)
        {
            DateTime day = DateTime.Today;
            string folderPath = filePath.Substring(0, filePath.LastIndexOf("\\"));
            string[] inputFilePaths = Directory.GetFiles(folderPath, @"*.dat");
            foreach (var inputFilePath in inputFilePaths)
            {
                string filenam = Path.GetFileName(inputFilePath);
                File.Move(inputFilePath, Path.Combine(excelFilePath, temp_FileName));


            }
        }

        public void Hong_Kong_CCASS_And_BROKER(string filePath, string Recon_Date, string OutPut_Path)
        {
            string folderPath = filePath.Substring(0, filePath.LastIndexOf("\\"));
            string[] inputFilePaths = Directory.GetFiles(folderPath, "CSESB01_*.txt");

            using (var outputStream = File.Create(OutPut_Path))
            {
                foreach (var inputFilePath in inputFilePaths)
                {
                    DirectoryInfo di = new DirectoryInfo(inputFilePath);
                    if (di.CreationTime.ToShortDateString().Equals(DateTime.Now.ToShortDateString()))
                    {
                        using (var inputStream = File.OpenRead(inputFilePath))
                        {
                            inputStream.CopyTo(outputStream);
                        }
                    }
                }
            }
        }

        public void CASH_PAYMENT_SUSPENSE_CHQ(string filePath, string Recon_Date, string OutPut_Path)
        {
            string filePath2 = @"C:\ARC\Docs\Direct Upload Flow\Samples\Cash_Suspense-Kenya\cashsuspense\Files\Test\CHQ_06032017_1329.xls";
            System.Data.DataTable dtexcel1 = new System.Data.DataTable();
            System.Data.DataTable dtexcel2 = new System.Data.DataTable();
            System.Data.DataTable dt1 = new System.Data.DataTable();

            string strConn1 = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + filePath + ";Extended Properties='Excel 8.0;HDR=YES'";
            OleDbConnection conn1 = new OleDbConnection(strConn1);
            conn1.Open();
            System.Data.DataTable schemaTable1 = conn1.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, new object[] { null, null, null, "TABLE" });

            DataRow schemaRow = schemaTable1.Rows[0];
            string sheet1 = schemaRow["TABLE_NAME"].ToString();

            OleDbDataAdapter daexcel1 = null;
            if (!sheet1.EndsWith("_"))
            {
                string query = "SELECT * FROM [" + sheet1 + "]";
                daexcel1 = new OleDbDataAdapter(query, conn1);
                dtexcel1.Locale = CultureInfo.CurrentCulture;
                daexcel1.Fill(dtexcel1);
            }
            conn1.Close();
            string strConn2 = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + filePath2 + ";Extended Properties='Excel 8.0;HDR=YES'";

            OleDbConnection conn2 = new OleDbConnection(strConn2);
            conn2.Open();
            System.Data.DataTable schemaTable2 = conn2.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, new object[] { null, null, null, "TABLE" });

            DataRow schemaRow2 = schemaTable2.Rows[0];
            string sheet2 = schemaRow2["TABLE_NAME"].ToString();

            OleDbDataAdapter daexcel2 = null;
            if (!sheet1.EndsWith("_"))
            {
                string query = "SELECT  * FROM [" + sheet2 + "]";
                daexcel2 = new OleDbDataAdapter(query, conn2);
                dtexcel2.Locale = CultureInfo.CurrentCulture;
                daexcel2.Fill(dtexcel2);
            }
            conn2.Close();
            dt1.Columns.Add("Amount");
            int j1 = 0;
            double sum = 0;
            for (int j = 0; j <= dtexcel1.Rows.Count - 1; j++)
            {
                string asa = dtexcel1.Rows[j][47].ToString();

                if (asa.Contains("SKE"))
                {
                    dt1.Rows.Add();
                    dt1.Rows[j1][0] = dtexcel1.Rows[j][8].ToString();
                    j1 = j1 + 1;
                    //Date = DateTime.Today.AddDays(-1).ToString("M/d/yyyy");
                }
            }
            for (int j = 0; j <= dtexcel2.Rows.Count - 1; j++)
            {
                // string asa = dtexcel2.Rows[j][47].ToString();

                if (dtexcel2.Rows[j][0].ToString() != null)
                {

                    sum += Convert.ToDouble(dtexcel2.Rows[j][3].ToString());
                }
            }
            for (int j = 0; j <= dt1.Rows.Count - 1; j++)
            {
                double asa = Convert.ToDouble(dt1.Rows[j][0].ToString());

                if (asa.Equals(sum))
                {
                    //ExportToExcel(dtexcel2);
                    ExportToExcel_Common(dtexcel2, OutPut_Path);
                }
            }
        }

        public void CASH_PAYMENT_SUSPENSE_T_BILL(string filePath, string Recon_Date, string OutPut_Path)
        {
            System.Data.DataTable dtexcel1 = new System.Data.DataTable();
            System.Data.DataTable dtfinal1 = new System.Data.DataTable();
            System.Data.DataTable dt1 = new System.Data.DataTable();
            int i = 0;
            string strConn1 = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + filePath + ";Extended Properties='Excel 8.0;HDR=YES'";

            OleDbConnection conn1 = new OleDbConnection(strConn1);
            conn1.Open();
            System.Data.DataTable schemaTable1 = conn1.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, new object[] { null, null, null, "TABLE" });

            DataRow schemaRow = schemaTable1.Rows[0];
            string sheet1 = schemaRow["TABLE_NAME"].ToString();

            OleDbDataAdapter daexcel1 = null;
            if (!sheet1.EndsWith("_"))
            {
                string query = "SELECT  * FROM [" + sheet1 + "]";
                daexcel1 = new OleDbDataAdapter(query, conn1);
                dtexcel1.Locale = CultureInfo.CurrentCulture;
                daexcel1.Fill(dtexcel1);
            }
            conn1.Close();

            System.Data.DataTable dtexcel2 = new System.Data.DataTable();
            System.Data.DataTable dtfinal2 = new System.Data.DataTable();
            string strConn2 = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + filePath + ";Extended Properties='Excel 8.0;HDR=YES'";
            string[] inputFilePaths = Directory.GetFiles("", "");

            foreach (var filePath2 in inputFilePaths)
            {
                string inputFilePath = Path.GetFileNameWithoutExtension(filePath2);

                if (inputFilePath.Contains("S2B"))
                {
                    strConn2 = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + filePath2 + ";Extended Properties='Excel 8.0;HDR=YES'";
                    OleDbConnection conn2 = new OleDbConnection(strConn2);
                    conn2.Open();
                    System.Data.DataTable schemaTable2 = conn2.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, new object[] { null, null, null, "TABLE" });

                    DataRow schemaRow2 = schemaTable2.Rows[0];
                    string sheet2 = schemaRow2["TABLE_NAME"].ToString();

                    OleDbDataAdapter daexcel2 = null;
                    if (!sheet1.EndsWith("_"))
                    {
                        string query = "SELECT  * FROM [" + sheet2 + "]";
                        daexcel2 = new OleDbDataAdapter(query, conn2);
                        dtexcel2.Locale = CultureInfo.CurrentCulture;
                        daexcel2.Fill(dtexcel2);
                    }
                    conn2.Close();

                    dt1.Columns.Add("Amount");
                    int j1 = 0;
                    double sum = 0;
                    for (int j = 0; j <= dtexcel1.Rows.Count - 1; j++)
                    {
                        string asa = dtexcel1.Rows[j][47].ToString();

                        if (asa.Contains("SKE"))
                        {
                            dt1.Rows.Add();
                            dt1.Rows[j1][0] = dtexcel1.Rows[j][8].ToString();
                            j1 = j1 + 1;
                            //Date = DateTime.Today.AddDays(-1).ToString("M/d/yyyy");
                        }
                    }
                    for (int j = 0; j <= dtexcel2.Rows.Count - 1; j++)
                    {
                        // string asa = dtexcel2.Rows[j][47].ToString();

                        if (dtexcel2.Rows[j][5].ToString() != null)
                        {

                            sum += Convert.ToDouble(dtexcel2.Rows[j][6].ToString());
                        }
                    }
                    for (int j = 0; j <= dt1.Rows.Count - 1; j++)
                    {
                        var asa = dt1.Rows[j][0].ToString();
                        //double asa = Convert.ToDouble(dt1.Rows[j][0].ToString());
                        var ress = sum.ToString("F1");
                        if (asa.Equals(ress))
                        {
                            i = i + 1;
                            ExportToExcel_CASH_PAYMENT_SUSPENSE(dtexcel2, i, OutPut_Path);
                            dt1.Clear();
                            dt1.Columns.Clear();
                            sum = 0;
                            dtexcel2.Clear();
                            dtexcel2.Columns.Clear();
                        }

                    }
                }// kept by Aneesh temporary 
            }
        }

        public void ExportToExcel_CASH_PAYMENT_SUSPENSE(System.Data.DataTable tbl, int t, string OutPut_Path)
        {
            string excelFilePath = @"C:\ARC\Docs\Direct Upload Flow\Samples\Cash_Suspense-Kenya\cashsuspense\Files\Test\S2B_" + t + "_1329.xls";
            try
            {
                if (tbl == null || tbl.Columns.Count == 0)
                    return;//throw new Exception("ExportToExcel: Null or empty input table!\n");

                // load excel, and create a new workbook
                var excelApp = new Microsoft.Office.Interop.Excel.Application();
                excelApp.Workbooks.Add();

                // single worksheet
                Microsoft.Office.Interop.Excel._Worksheet workSheet = (Excel.Worksheet)excelApp.ActiveSheet;
                // column headings
                for (var i = 0; i < tbl.Columns.Count; i++)
                {
                    workSheet.Cells[1, i + 1] = tbl.Columns[i].ColumnName;
                }

                // rows
                for (var i = 0; i < tbl.Rows.Count; i++)
                {
                    // to do: format datetime values before printing
                    for (var j = 0; j < tbl.Columns.Count; j++)
                    {
                        workSheet.Cells[i + 2, j + 1] = tbl.Rows[i][j];
                    }
                }

                // check file path
                if (!string.IsNullOrEmpty(excelFilePath))
                {
                    try
                    {
                        //    workSheet.Columns[03].ColumnWidth = 20;
                        //    workSheet.Columns[20].ColumnWidth = 20;
                        //    workSheet.Columns[14].ColumnWidth = 20;
                        //    workSheet.Columns[15].ColumnWidth = 20;
                        workSheet.SaveAs(excelFilePath);
                        excelApp.Quit();
                        MessageBox.Show("Excel file saved!");
                        File.Move(excelFilePath, Path.ChangeExtension(excelFilePath, ".csv"));
                    }
                    catch
                    {
                        //throw new Exception("ExportToExcel: Excel file could not be saved! Check filepath.\n"+ ex.Message);
                    }
                }
                else
                { // no file path is given
                    excelApp.Visible = false;
                }
            }
            catch (Exception ex)
            {
                throw new Exception("ExportToExcel: \n" + ex.Message);
            }
        }

        public void CASH_PAYMENT_SUSPENSE_S2B(string filePath, string Recon_Date, string OutPut_Path)
        {
            string filePath1 = @"C:\ARC\Docs\Direct Upload Flow\Samples\Cash_Suspense-Kenya\cashsuspense\Files\CASHPAYMENT.xlsx";

            System.Data.DataTable dtexcel1 = new System.Data.DataTable();
            System.Data.DataTable dtfinal1 = new System.Data.DataTable();
            System.Data.DataTable dt1 = new System.Data.DataTable();

            string strConn1 = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + filePath1 + ";Extended Properties='Excel 8.0;HDR=YES'";
            OleDbConnection conn1 = new OleDbConnection(strConn1);
            conn1.Open();

            System.Data.DataTable schemaTable1 = conn1.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, new object[] { null, null, null, "TABLE" });
            DataRow schemaRow = schemaTable1.Rows[0];
            string sheet1 = schemaRow["TABLE_NAME"].ToString();

            OleDbDataAdapter daexcel1 = null;
            if (!sheet1.EndsWith("_"))
            {
                string query = "SELECT  * FROM [" + sheet1 + "]";
                daexcel1 = new OleDbDataAdapter(query, conn1);
                dtexcel1.Locale = CultureInfo.CurrentCulture;
                daexcel1.Fill(dtexcel1);
            }
            conn1.Close();

            System.Data.DataTable dtexcel2 = new System.Data.DataTable();
            System.Data.DataTable dtfinal2 = new System.Data.DataTable();
            string strConn2;

            string[] inputFilePaths = Directory.GetFiles("", "");
            int i = 0;
            foreach (var filePath2 in inputFilePaths)
            {
                string inputFilePath = Path.GetFileNameWithoutExtension(filePath2);

                if (inputFilePath.Contains("S2B"))
                {
                    strConn2 = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + filePath2 + ";Extended Properties='Excel 8.0;HDR=YES'";
                    OleDbConnection conn2 = new OleDbConnection(strConn2);
                    conn2.Open();
                    System.Data.DataTable schemaTable2 = conn2.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, new object[] { null, null, null, "TABLE" });

                    DataRow schemaRow2 = schemaTable2.Rows[0];
                    string sheet2 = schemaRow2["TABLE_NAME"].ToString();

                    OleDbDataAdapter daexcel2 = null;
                    if (!sheet1.EndsWith("_"))
                    {
                        string query = "SELECT  * FROM [" + sheet2 + "]";
                        daexcel2 = new OleDbDataAdapter(query, conn2);
                        dtexcel2.Locale = CultureInfo.CurrentCulture;
                        daexcel2.Fill(dtexcel2);
                    }
                    conn2.Close();

                    dt1.Columns.Add("Amount");
                    int j1 = 0;
                    double sum = 0;
                    for (int j = 0; j <= dtexcel1.Rows.Count - 1; j++)
                    {
                        string asa = dtexcel1.Rows[j][47].ToString();

                        if (asa.Contains("SKE"))
                        {
                            dt1.Rows.Add();
                            dt1.Rows[j1][0] = dtexcel1.Rows[j][8].ToString();
                            j1 = j1 + 1;
                            //Date = DateTime.Today.AddDays(-1).ToString("M/d/yyyy");
                        }
                    }
                    for (int j = 0; j <= dtexcel2.Rows.Count - 1; j++)
                    {
                        // string asa = dtexcel2.Rows[j][47].ToString();

                        if (dtexcel2.Rows[j][5].ToString() != null)
                        {

                            sum += Convert.ToDouble(dtexcel2.Rows[j][6].ToString());
                        }
                    }
                    for (int j = 0; j <= dt1.Rows.Count - 1; j++)
                    {
                        var asa = dt1.Rows[j][0].ToString();
                        //double asa = Convert.ToDouble(dt1.Rows[j][0].ToString());
                        var ress = sum.ToString("F1");
                        if (asa.Equals(ress))
                        {
                            i = i + 1;
                            ExportToExcel_CASH_PAYMENT_SUSPENSE(dtexcel2, i, OutPut_Path);
                            dt1.Clear();
                            dt1.Columns.Clear();
                            sum = 0;
                            dtexcel2.Clear();
                            dtexcel2.Columns.Clear();
                        }

                    }
                }
            }
        }

        public void INDONESIA_CARDS_BATCH_REPSCBX_REPATMBX(string inputFilePath, string Recon_Date, string OutPut_Path, string Share_Path, string OutPut_HafPath)
        {
            string inputDirectoryPath = Share_Path + "Input\\Emails\\";
            string inputFileNamePattern = @"*.txt";
            DateTime day = DateTime.Today;
            int Reco = Convert.ToInt32(Recon_Date) - 1;
            int Recoo = Convert.ToInt32(Recon_Date) - 2;
            string[] inputFilePaths = Directory.GetFiles(inputDirectoryPath, inputFileNamePattern);
            foreach (var filePath in inputFilePaths)
            {
                if (filePath.Contains("REPATMBX") || filePath.Contains("REPSCBX"))
                {
                    string filename = Path.GetFileNameWithoutExtension(filePath);
                    StreamReader objReader = new StreamReader(filePath);
                    string[] lines = System.IO.File.ReadAllLines(filePath);
                    // reading rest of the data
                    for (int i = 0; i < lines.Length - 1; i++)
                    {
                        //DataRow dr = dt.NewRow();
                        string[] values = System.Text.RegularExpressions.Regex.Split(lines[i].ToString(), @"\s{2,}");
                        if (i == 1)
                        {
                            string[] arg = values[1].ToString().Split(':');
                            string runDate = arg[1].ToString().Trim();

                            string totalamt = lines[lines.Length - 2];
                            string[] arg1 = totalamt.ToString().Split(':');
                            string succAmt = lines[lines.Length - 3];
                            string[] arg2 = succAmt.ToString().Split(':');
                            string tot = arg1[1].ToString().Trim();
                            string Succ = arg2[1].ToString().Trim();
                            string[] Date1 = runDate.ToString().Split('-');
                            string dtt = "17" + Date1[1].ToString() + Date1[2].ToString();
                            string out_dat = Date1[2].ToString() + Date1[1].ToString() + Date1[0].ToString();
                            if (inputFilePath.Contains("REPATMBX"))
                            {
                                if (tot == Succ && Recon_Date.Equals(dtt) && values[0].Contains("Offus") && filename.Contains("REPATMBX"))
                                {
                                    try
                                    {
                                        objReader.Close();
                                        File.Copy(filePath, OutPut_Path);
                                    }
                                    catch (Exception ex)
                                    {
                                        throw ex;
                                    }
                                }
                                else if (tot == Succ && Reco.ToString().Equals(dtt) && values[0].Contains("Offus") && filename.Contains("REPATMBX") && day.DayOfWeek.ToString() == "Tuesday")
                                {
                                    try
                                    {
                                        objReader.Close();
                                        File.Copy(filePath, OutPut_HafPath + out_dat + ".txt");
                                    }
                                    catch (Exception ex)
                                    {
                                        throw ex;
                                    }
                                }
                                else if (tot == Succ && Recoo.ToString().Equals(dtt) && values[0].Contains("Offus") && filename.Contains("REPATMBX") && day.DayOfWeek.ToString() == "Tuesday")
                                {
                                    try
                                    {
                                        objReader.Close();
                                        File.Copy(filePath, OutPut_HafPath + out_dat + ".txt");
                                    }
                                    catch (Exception ex)
                                    {
                                        throw ex;
                                    }
                                }
                            }
                            else if (inputFilePath.Contains("REPSCBX"))
                            {
                                if (tot == Succ && Recon_Date.Equals(dtt) && values[0].Contains("Onus") && filename.Contains("REPSCBX"))
                                {
                                    try
                                    {
                                        objReader.Close();
                                        File.Copy(filePath, OutPut_Path);
                                    }
                                    catch (Exception ex)
                                    {
                                        throw ex;
                                    }
                                }
                                else if (tot == Succ && Reco.ToString().Equals(dtt) && values[0].Contains("Onus") && filename.Contains("REPSCBX") && day.DayOfWeek.ToString() == "Tuesday")
                                {
                                    try
                                    {
                                        objReader.Close();
                                        File.Copy(filePath, OutPut_HafPath + out_dat + ".txt");
                                    }
                                    catch (Exception ex)
                                    {
                                        throw ex;
                                    }
                                }
                                else if (tot == Succ && Recoo.ToString().Equals(dtt) && values[0].Contains("Onus") && filename.Contains("REPSCBX") && day.DayOfWeek.ToString() == "Tuesday")
                                {
                                    try
                                    {
                                        objReader.Close();
                                        File.Copy(filePath, OutPut_HafPath + out_dat + ".txt");
                                    }
                                    catch (Exception ex)
                                    {
                                        throw ex;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        public void Meps_ATM_Settlement_289282(string filePath, string Recon_Date, string OutPut_Path)
        {
            System.Data.DataTable dt = new System.Data.DataTable();
            dt.Columns.Add("Text");

            if (File.Exists(filePath) == true)
            {
                string[] lines = System.IO.File.ReadAllLines(filePath);
                int x = 0;

                for (int i = 0; i <= lines.Length - 1; i++)
                {
                    if (i == 0 || i == lines.Length - 1)
                    {
                        dt.Rows.Add();
                        dt.Rows[x][0] = lines[i];
                        x++;
                    }
                    if (lines[i].ToString().Contains("."))
                    {
                        dt.Rows.Add();
                        dt.Rows[x][0] = lines[i];
                        x++;
                    }
                }
                System.Data.DataTable Final1 = new System.Data.DataTable();
                Final1.Columns.Add("Text1");
                Final1.Columns.Add("Amount", typeof(double));
                Final1.Columns.Add("Text2");
                Final1.Columns.Add("Text3");
                Final1.Columns.Add("Text4");
                System.Data.DataTable Final2 = new System.Data.DataTable();
                Final2.Columns.Add("Text1");
                Final2.Columns.Add("Amount", typeof(double));
                Final2.Columns.Add("Text2");
                Final2.Columns.Add("Text3");
                Final2.Columns.Add("Text4");
                System.Data.DataTable Final3 = new System.Data.DataTable();
                Final3.Columns.Add("Text1");
                Final3.Columns.Add("Amount", typeof(double));
                Final3.Columns.Add("Text2");
                Final3.Columns.Add("Text3");
                Final3.Columns.Add("Text4");

                int x1 = 0;
                int x2 = 0;
                int x3 = 0;
                for (int i = 0; i <= dt.Rows.Count - 1; i++)
                {
                    string[] ar = System.Text.RegularExpressions.Regex.Split(dt.Rows[i][0].ToString(), @"\s{2,}");


                    if (ar.Length == 3 && ar[0].ToString().Contains("CA"))
                    {
                        string[] ar1 = System.Text.RegularExpressions.Regex.Split(ar[1], @"\s{1,}");
                        Final1.Rows.Add();
                        Final1.Rows[x1][0] = ar[0];
                        if (ar1[0].Contains("-"))
                        {
                            Final1.Rows[x1][1] = "-" + Convert.ToDouble(ar1[0].ToString().Substring(0, ar1[0].ToString().Length - 1));
                        }
                        else
                        {
                            Final1.Rows[x1][1] = Convert.ToDouble(ar1[0].ToString());
                        }
                        if (ar1.Length > 1)
                        {
                            Final1.Rows[x1][2] = " " + ar1[1];
                        }

                        x1++;
                    }

                    else if (ar.Length == 5 && ar[2].ToString().Contains("CA"))
                    {
                        string[] ar1 = System.Text.RegularExpressions.Regex.Split(ar[3], @"\s{1,}");
                        Final1.Rows.Add();
                        Final1.Rows[x1][0] = ar[0] + " " + ar[1] + " " + ar[2];
                        //Final1.Rows[x1][1] = ar1[0];
                        if (ar1.Length > 1)
                        {
                            Final1.Rows[x1][2] = ar1[1];
                        }

                        if (ar1[0].Contains("-"))
                        {
                            Final1.Rows[x1][1] = "-" + Convert.ToDouble(ar1[0].ToString().Substring(0, ar1[0].ToString().Length - 1));
                        }
                        else
                        {
                            Final1.Rows[x1][1] = Convert.ToDouble(ar1[0].ToString());
                        }
                        if (ar1.Length > 1)
                        {
                            Final1.Rows[x1][2] = " " + ar1[1];
                        }
                        x1++;
                    }
                    else if (ar.Length == 3 && ar[0].ToString().Contains("SA"))
                    {
                        string[] ar1 = System.Text.RegularExpressions.Regex.Split(ar[1], @"\s{1,}");
                        Final2.Rows.Add();
                        Final2.Rows[x2][0] = ar[0];
                        // Final2.Rows[x2][1] = ar1[0];
                        Final2.Rows[x2][2] = " " + ar1[1];
                        if (ar1[0].Contains("-"))
                        {
                            Final2.Rows[x2][1] = "-" + Convert.ToDouble(ar1[0].ToString().Substring(0, ar1[0].ToString().Length - 1));
                        }
                        else
                        {
                            Final2.Rows[x2][1] = Convert.ToDouble(ar1[0].ToString());
                        }
                        if (ar1.Length > 1)
                        {
                            Final1.Rows[x2][2] = " " + ar1[1];
                        }
                        x2++;

                    }

                    else if (ar.Length == 5 && ar[2].ToString().Contains("SA"))
                    {
                        string[] ar1 = System.Text.RegularExpressions.Regex.Split(ar[3], @"\s{1,}");

                        Final2.Rows.Add();
                        Final2.Rows[x2][0] = ar[0] + " " + ar[1] + " " + ar[2];
                        // Final2.Rows[x2][1] = ar1[0];
                        if (ar1.Length > 1)
                        {
                            Final2.Rows[x2][2] = ar1[1];
                        }
                        if (ar1[0].Contains("-"))
                        {
                            Final2.Rows[x2][1] = "-" + Convert.ToDouble(ar1[0].ToString().Substring(0, ar1[0].ToString().Length - 1));
                        }
                        else
                        {
                            Final2.Rows[x2][1] = Convert.ToDouble(ar1[0].ToString());
                        }
                        if (ar1.Length > 1)
                        {
                            Final2.Rows[x2][2] = " " + ar1[1];
                        }
                        x2++;
                    }
                    else if (ar.Length == 3 && ar[0].ToString().Contains("FC"))
                    {
                        string[] ar1 = System.Text.RegularExpressions.Regex.Split(ar[1], @"\s{1,}");
                        Final3.Rows.Add();
                        Final3.Rows[x3][0] = ar[0];
                        //Final3.Rows[x3][1] = ar1[0];
                        Final3.Rows[x3][2] = " " + ar1[1];
                        if (ar1[0].Contains("-"))
                        {
                            Final3.Rows[x3][1] = "-" + Convert.ToDouble(ar1[0].ToString().Substring(0, ar1[0].ToString().Length - 1));
                        }
                        else
                        {
                            Final3.Rows[x3][1] = Convert.ToDouble(ar1[0].ToString());
                        }
                        if (ar1.Length > 1)
                        {
                            Final3.Rows[x3][2] = " " + ar1[1];
                        }
                        x3++;
                    }

                    else if (ar.Length == 5 && ar[2].ToString().Contains("FC"))
                    {
                        string[] ar1 = System.Text.RegularExpressions.Regex.Split(ar[3], @"\s{1,}");
                        Final3.Rows.Add();
                        Final3.Rows[x3][0] = ar[0] + " " + ar[1] + " " + ar[2];
                        //Final3.Rows[x3][1] = ar1[0];
                        if (ar1.Length > 1)
                        {
                            Final3.Rows[x3][2] = ar1[1];
                        }
                        if (ar1[0].Contains("-"))
                        {
                            Final3.Rows[x3][1] = "-" + ar1[0].ToString().Substring(0, ar1[0].ToString().Length - 1);
                        }
                        else
                        {
                            Final3.Rows[x3][1] = ar1[0].ToString();
                        }
                        if (ar1.Length > 1)
                        {
                            Final3.Rows[x3][2] = " " + ar1[1];
                        }
                        x3++;
                    }
                }

                System.Data.DataTable sort1 = new System.Data.DataTable();
                DataView dataview = Final1.DefaultView;
                dataview.Sort = "Amount desc";
                sort1 = dataview.ToTable();
                System.Data.DataTable Sorted1 = new System.Data.DataTable();
                Sorted1.Columns.Add("Text1");
                Sorted1.Columns.Add("Amount");
                Sorted1.Columns.Add("Text2");
                Sorted1.Columns.Add("Text3");
                if (Final1.Rows.Count > 0)
                {
                    double max1 = Convert.ToDouble(sort1.Rows[0]["Amount"].ToString());
                    for (int i = 0; i <= sort1.Rows.Count - 1; i++)
                    {
                        Sorted1.Rows.Add();
                        if (max1 == Convert.ToDouble(sort1.Rows[i][1]))
                        {
                            Sorted1.Rows[i][0] = sort1.Rows[i][0].ToString().Substring(0, sort1.Rows[i][0].ToString().Length - 2);
                            Sorted1.Rows[i][1] = "CA" + sort1.Rows[i][1].ToString();
                            Sorted1.Rows[i][2] = sort1.Rows[i][2].ToString();
                            Sorted1.Rows[i][3] = sort1.Rows[i][3].ToString();
                        }
                        else
                        {
                            Sorted1.Rows[i][0] = sort1.Rows[i][0].ToString().Substring(0, sort1.Rows[i][0].ToString().Length - 2) + "CA";
                            Sorted1.Rows[i][1] = sort1.Rows[i][1].ToString();
                            Sorted1.Rows[i][2] = sort1.Rows[i][2].ToString();
                            Sorted1.Rows[i][3] = sort1.Rows[i][3].ToString();
                        }
                    }
                }

                System.Data.DataTable sort2 = new System.Data.DataTable();
                DataView dataview2 = Final2.DefaultView;
                dataview2.Sort = "Amount desc";
                sort2 = dataview2.ToTable();
                System.Data.DataTable Sorted2 = new System.Data.DataTable();
                Sorted2.Columns.Add("Text1");
                Sorted2.Columns.Add("Amount");
                Sorted2.Columns.Add("Text2");
                Sorted2.Columns.Add("Text3");
                if (Final2.Rows.Count > 0)
                {
                    double max2 = Convert.ToDouble(sort2.Rows[0]["Amount"].ToString());
                    for (int i = 0; i <= sort2.Rows.Count - 1; i++)
                    {
                        Sorted2.Rows.Add();
                        if (max2 == Convert.ToDouble(sort2.Rows[i][1]))
                        {
                            Sorted2.Rows[i][0] = sort2.Rows[i][0].ToString().Substring(0, sort2.Rows[i][0].ToString().Length - 2);
                            Sorted2.Rows[i][1] = "SA" + sort1.Rows[i][1].ToString();
                            Sorted2.Rows[i][2] = sort2.Rows[i][2].ToString();
                            Sorted2.Rows[i][3] = sort2.Rows[i][3].ToString();
                        }
                        else
                        {
                            Sorted2.Rows[i][0] = sort2.Rows[i][0].ToString().Substring(0, sort2.Rows[i][0].ToString().Length - 2) + "SA";
                            Sorted2.Rows[i][1] = sort2.Rows[i][1].ToString();
                            Sorted2.Rows[i][2] = sort2.Rows[i][2].ToString();
                            Sorted2.Rows[i][3] = sort2.Rows[i][3].ToString();
                        }
                    }
                }

                System.Data.DataTable sort3 = new System.Data.DataTable();
                DataView dataview3 = Final2.DefaultView;
                dataview3.Sort = "Amount desc";
                sort3 = dataview3.ToTable();
                System.Data.DataTable Sorted3 = new System.Data.DataTable();
                Sorted3.Columns.Add("Text1");
                Sorted3.Columns.Add("Amount");
                Sorted3.Columns.Add("Text2");
                Sorted3.Columns.Add("Text3");
                if (Final3.Rows.Count > 0)
                {
                    double max3 = Convert.ToDouble(sort3.Rows[0]["Amount"].ToString());
                    for (int i = 0; i <= sort3.Rows.Count - 1; i++)
                    {
                        Sorted3.Rows.Add();
                        if (max3 == Convert.ToDouble(sort3.Rows[i][1]))
                        {
                            Sorted3.Rows[i][0] = sort3.Rows[i][0].ToString().Substring(0, sort2.Rows[i][0].ToString().Length - 2);
                            Sorted3.Rows[i][1] = "FC" + sort1.Rows[i][1].ToString();
                            Sorted3.Rows[i][2] = sort3.Rows[i][2].ToString();
                            Sorted3.Rows[i][3] = sort3.Rows[i][3].ToString();
                        }
                        else
                        {
                            Sorted3.Rows[i][0] = sort3.Rows[i][0].ToString().Substring(0, sort3.Rows[i][0].ToString().Length - 2) + "FC";
                            Sorted3.Rows[i][1] = sort3.Rows[i][1].ToString();
                            Sorted3.Rows[i][2] = sort3.Rows[i][2].ToString();
                            Sorted3.Rows[i][3] = sort3.Rows[i][3].ToString();
                        }
                    }
                }

                var result = new StringBuilder();
                Sorted1.Merge(Sorted2);
                Sorted1.Merge(Sorted3);
                Sorted1.Rows.Add();
                DataRow newRow = Sorted1.NewRow();
                newRow[0] = lines[0].ToString();

                foreach (DataRow row in Sorted1.Rows)
                {
                    for (int i = 0; i < Sorted1.Columns.Count; i++)
                    {
                        result.Append(row[i].ToString());
                        result.Append(i == Sorted1.Columns.Count - 1 ? "\n" : " ");
                    }
                    result.AppendLine();
                }
                StreamWriter objWriter = new StreamWriter(filePath, false);
                objWriter.WriteLine(result.ToString());
                objWriter.Close();
            }
        }

        public void India_RBI_Main_Account(string filePath, string Recon_Date, string Country, string OutPut_Path, string OutPut_Pat)
        {
            string[] val = null;
            System.Data.DataTable dtexcel1 = new System.Data.DataTable("dtExcel");
            System.Data.DataTable dtfinal1 = new System.Data.DataTable();

            Microsoft.Office.Interop.Excel.Application oXL;
            Workbook oWB;
            Worksheet oSheet;
            Range oRng;
            //  creat a Application object
            oXL = new Microsoft.Office.Interop.Excel.Application();
            //   get   WorkBook  object
            oXL.Visible = false;
            oXL.DisplayAlerts = false;
            oWB = oXL.Workbooks.Open(filePath, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value,
                    Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value,
                    Missing.Value, Missing.Value);

            try
            {
                //   get   WorkSheet object 
                oSheet = (Microsoft.Office.Interop.Excel.Worksheet)oWB.Sheets[1];
                oSheet.Columns.NumberFormat = "#,##0.00";
                //oSheet.SaveAs(filePath);
                // System.Data.DataTable dt01 = new System.Data.DataTable("dtExcel");
                DataSet ds = new DataSet();
                ds.Tables.Add(dtexcel1);
                DataRow dr;


                StringBuilder sb = new StringBuilder();
                int jValue = oSheet.UsedRange.Cells.Columns.Count;
                int iValue = oSheet.UsedRange.Cells.Rows.Count;
                //  get data columns
                for (int j = 1; j <= jValue; j++)
                {
                    dtexcel1.Columns.Add("column" + j, System.Type.GetType("System.String"));
                }
                for (int i = 1; i <= iValue; i++)
                {
                    dr = ds.Tables["dtExcel"].NewRow();
                    for (int j = 1; j <= jValue; j++)
                    {
                        oRng = (Microsoft.Office.Interop.Excel.Range)oSheet.Cells[i, j];
                        string strValue = oRng.Text.ToString();
                        dr["column" + j] = strValue;
                    }
                    ds.Tables["dtExcel"].Rows.Add(dr);
                }
                dtexcel1.Columns.RemoveAt(0);
                dtexcel1.AcceptChanges();
                for (int i = 0; i <= dtexcel1.Rows.Count - 1; i++)
                {
                    if (dtexcel1.Rows[i][3].ToString().Contains("Opening Balance"))
                    {
                        val = System.Text.RegularExpressions.Regex.Split(dtexcel1.Rows[i][6].ToString(), @"\s{1,}");
                    }
                    if (dtexcel1.Rows[i][2].ToString() == "")
                    {
                        dtexcel1.Rows[i].Delete();
                    }

                }

                dtexcel1.AcceptChanges();
                dtfinal1.Columns.Add("0");
                dtfinal1.Columns.Add("1");
                dtfinal1.Columns.Add("2");
                dtfinal1.Columns.Add("3");
                dtfinal1.Columns.Add("4");
                dtfinal1.Columns.Add("5");
                string asd = "";
                string asd01 = "";
                double sum01 = 0;
                double val01 = 0;
                for (int i = 0; i <= dtexcel1.Rows.Count - 1; i++)
                {

                    if (dtexcel1.Rows[i][0].ToString() != "")
                    {
                        dtfinal1.Rows.Add();
                        dtfinal1.Rows[i][1] = dtexcel1.Rows[i][0];
                        dtfinal1.Rows[i][2] = dtexcel1.Rows[i][0];
                        if (i == 0)
                        {
                            dtfinal1.Rows[i][3] = dtexcel1.Rows[i][3].ToString();
                        }
                        else
                        {
                            if (dtexcel1.Rows[i][4].ToString() != "")
                            {
                                dtfinal1.Rows[i][0] = "-" + Convert.ToDecimal(dtexcel1.Rows[i][4]).ToString("#,##0.00");
                            }
                            else if (dtexcel1.Rows[i][5].ToString() != "")
                            {
                                dtfinal1.Rows[i][0] = Convert.ToDecimal(dtexcel1.Rows[i][5]).ToString("#,##0.00");
                            }
                            asd = dtexcel1.Rows[i][3].ToString();
                            val01 = Convert.ToDouble(dtexcel1.Rows[i][2]);
                            string valll = val01.ToString("0.#");
                            asd01 = dtexcel1.Rows[i][3].ToString() + '-' + valll;
                            Regex rgx = new Regex("[^a-zA-Z0-9 ]");
                            // asd = rgx.Replace(asd, " ");

                            string final_asd = asd01.Substring(asd01.Length - 30).TrimEnd();
                            final_asd = final_asd.Replace("Office Departments", "");
                            final_asd = final_asd.Replace("Office departments", "");
                            final_asd = final_asd.Replace("Regional Office", "");
                            final_asd = final_asd.Replace("Regional office", "");
                            string final_asd01 = final_asd;// +'-' + valll;
                            final_asd01 = rgx.Replace(final_asd01, " ");
                            dtfinal1.Rows[i][3] = final_asd01.TrimStart();
                            dtfinal1.Rows[i][4] = final_asd01;
                            sum01 += Convert.ToDouble(dtfinal1.Rows[i][0]);
                            asd01 = rgx.Replace(asd01, " ");
                        }

                        dtfinal1.Rows[i][5] = asd01;
                    }
                }
                dtfinal1.Rows[0].Delete();
                string Close = "";
                DataRow newRow = dtfinal1.NewRow();
                dtfinal1.Rows.InsertAt(newRow, 0);
                for (int i = 0; i < 1; i++)
                {
                    dtfinal1.Rows.Add();
                    dtfinal1.Rows[i][0] = val[1];
                    dtfinal1.Rows[i][1] = dtfinal1.Rows[2][1];
                    sum01 = sum01 + Convert.ToDouble(dtfinal1.Rows[i][0]);
                }
                if (sum01 != 0.05)
                {
                    Close = String.Format("{0:n}", sum01);
                    dtfinal1.Rows[dtfinal1.Rows.Count - 1][0] = Close;
                }

                oWB.Close();
                oXL.Quit();
                ReleaseComObject(oSheet);
                ReleaseComObject(oWB);
                ReleaseComObject(oXL);
                string excelOutputFile = OutPut_Pat + "Output.xlsx";
                ExportToExcel_Common(dtfinal1, excelOutputFile);

                dtfinal1.Rows[0].Delete();
                ExportToExcel_IndiaRBI(dtfinal1, val[1], Close, OutPut_Path, Country);
            }
            catch
            {
                oWB.Close();
                oXL.Quit();
                ReleaseComObject(oWB);
                ReleaseComObject(oXL);
            }

        }

        public void ExportToExcel_IndiaRBI(System.Data.DataTable tbl, string OpeningAmount, string ClosingAmount, string excelFilePath, string Country)
        {
            //string excelFilePath = @"C:\ARC\Docs\Direct Upload Flow\Samples\India_RBI\Output\GMI_CASH.csv";


            StreamWriter wrtr = null;
            try
            {
                if (tbl == null || tbl.Columns.Count == 0)
                    throw new Exception("ExportToExcel: Null or empty input table!\n");


                string setID = "";
                if (Country == "Singapore")
                    setID = "21";
                else if (Country == "Indonesia")
                    setID = "27";
                else if (Country == "Malaysia")
                    setID = "28";
                else if (Country == "Vietnam")
                    setID = "29";
                else if (Country == "Philippines")
                    setID = "39";
                else if (Country == "Nigeria")
                    setID = "90";
                else if (Country == "India")
                    setID = "40";

                wrtr = new StreamWriter(excelFilePath);
                //List<string> currlst = new List<string>();
                //currlst = tbl.AsEnumerable().Select(r => r.Field<string>("d")).ToList();
                //currlst = currlst.Distinct().ToList();

                System.Data.DataTable dt = new System.Data.DataTable();
                dt.Columns.Add("OPBAL");
                dt.Columns.Add("OPBALCY");
                dt.Columns.Add("OPBALDATE");
                dt.Columns.Add("OPBALSIGN");
                dt.Columns.Add("OPBALTP");
                dt.Columns.Add("OURREF");
                dt.Columns.Add("SIDE");
                dt.Columns.Add("STMTNO");
                dt.Columns.Add("STMTPG");
                dt.Columns.Add("SUBACC");
                dt.Columns.Add("THEIRREF");
                dt.Columns.Add("ACCOWNRINFO");
                dt.Columns.Add("AMOUNT");
                dt.Columns.Add("DRORCR");
                dt.Columns.Add("ENTRYDATE");
                dt.Columns.Add("REF1");
                dt.Columns.Add("REF2");
                dt.Columns.Add("REF3");
                dt.Columns.Add("TRANCODE");
                dt.Columns.Add("VALUEDATE");
                dt.Columns.Add("BRC");
                dt.Columns.Add("XAMT1");
                dt.Columns.Add("XAMT2");
                dt.Columns.Add("XAMT3");
                dt.Columns.Add("XDATE1");
                dt.Columns.Add("XDATE2");
                dt.Columns.Add("XDATE3");
                dt.Columns.Add("XSTR1");
                dt.Columns.Add("XSTR2");
                dt.Columns.Add("XSTR3");
                dt.Columns.Add("XFLAG1");
                dt.Columns.Add("XFLAG2");
                dt.Columns.Add("XFLAG3");
                dt.Columns.Add("CLBAL");
                dt.Columns.Add("CLBALCY");
                dt.Columns.Add("CLBALDATE");
                dt.Columns.Add("CLBALSIGN");
                dt.Columns.Add("CLBALTP");
                string colString = "";
                for (int y = 0; y < dt.Columns.Count; y++)
                {
                    //rowString += "\"" + dt.Rows[x][y].ToString() + "\","; Original
                    if (dt.Columns.Count - 1 == y)
                    {
                        colString += dt.Columns[y].ToString();
                    }
                    else
                    {
                        colString += dt.Columns[y].ToString() + "|";
                    }
                }
                wrtr.WriteLine(colString);

                System.Data.DataTable dtCloned = tbl.Clone();
                dtCloned.Columns[0].DataType = typeof(decimal);
                foreach (DataRow row in tbl.Rows)
                {
                    dtCloned.ImportRow(row);
                }
                string OpenAmt = OpeningAmount.Replace(",", "");
                string CloseAmt = ClosingAmount.Replace(",", "");
                for (var i = 0; i < tbl.Rows.Count; i++)
                {
                    dt.Rows.Add();
                    string amt = tbl.Rows[i][0].ToString();
                    string currdate = tbl.Rows[i][1].ToString();
                    string ref1 = tbl.Rows[i][3].ToString();
                    string ref2 = tbl.Rows[i][4].ToString();
                    string ref3 = tbl.Rows[i][5].ToString();

                    // var tot = dtCloned.AsEnumerable().Where(r => r.Field<string>(5) == cury).Sum(r => r.Field<decimal>(0));
                    if (currdate != "")
                    {
                        dt.Rows[i][0] = OpenAmt;
                        dt.Rows[i][1] = "INR";
                        dt.Rows[i][2] = Convert.ToDateTime(currdate).ToString("dd/MM/yyyy");
                        dt.Rows[i][14] = Convert.ToDateTime(currdate).ToString("dd/MM/yyyy");
                        dt.Rows[i][19] = Convert.ToDateTime(currdate).ToString("dd/MM/yyyy");
                        dt.Rows[i][35] = Convert.ToDateTime(currdate).ToString("dd/MM/yyyy");
                        dt.Rows[i][3] = "C";
                        dt.Rows[i][4] = "F";
                        dt.Rows[i][5] = "DUMMYTRN";
                        dt.Rows[i][6] = "S";
                        dt.Rows[i][7] = "1";
                        dt.Rows[i][8] = "1";
                        dt.Rows[i][9] = setID + "INR" + "03S" + Convert.ToDateTime(currdate).ToString("ddMMyy") + "124063319";
                        dt.Rows[i][10] = "CONV";
                        dt.Rows[i][11] = "";
                        if (amt.StartsWith("-"))
                        {
                            string val01 = amt.Replace("-", "");
                            val01 = val01.Replace(",", "");
                            dt.Rows[i][12] = val01;
                            dt.Rows[i][13] = "D";
                        }
                        if (!amt.StartsWith("-"))
                        {
                            string val02 = amt.Replace(",", "");
                            dt.Rows[i][12] = val02;
                            dt.Rows[i][13] = "C";
                        }
                        //  dt.Rows[i][14] = Convert.ToDateTime(currdate).ToString("dd/MM/yyyy");
                        dt.Rows[i][15] = ref1;
                        dt.Rows[i][16] = ref2;
                        dt.Rows[i][17] = ref3;
                        dt.Rows[i][18] = "";
                        //dt.Rows[i][19] = Convert.ToDateTime(currdate).ToString("dd/MM/yyyy");
                        dt.Rows[i][33] = CloseAmt;
                        dt.Rows[i][34] = "INR";
                        // dt.Rows[i][35] = Convert.ToDateTime(currdate).ToString("dd/MM/yyyy");
                        //dt.Rows[i][34] = "0";
                        //dt.Rows[i][35] = "0";
                        dt.Rows[i][36] = "C";
                        dt.Rows[i][37] = "F";

                        string rowString = "";
                        for (int y = 0; y < dt.Columns.Count; y++)
                        {
                            //rowString += "\"" + dt.Rows[x][y].ToString() + "\","; Original
                            if (dt.Columns.Count - 1 == y)
                            {
                                rowString += dt.Rows[i][y].ToString();
                            }
                            else
                            {
                                rowString += dt.Rows[i][y].ToString() + "|";
                            }
                        }
                        wrtr.WriteLine(rowString);

                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception("ExportToExcel: \n" + ex.Message);
            }
            finally
            {
                wrtr.Close();
                wrtr.Dispose();
            }

        }

        public void Nigeria_DailyBonds_TBILLS(string Country, string Recon_Name, string Application, string Report_Source_File_Name, string Formatted_File_Name, string dbExt, string conStr, string Share_Path, string Desti_Path, string Recon_Date)
        {
            System.DateTime date = System.DateTime.Today; //AddDays(-1)
            //string dt = System.DateTime.Today.ToString("dd"); //AddDays(-1)
            //string mn = System.DateTime.Now.ToString("MM");
            //int year = System.DateTime.Now.Year;
            //string yr = System.DateTime.Now.ToString("yy");
            //string month = System.DateTime.Now.ToString("MMMM");

            string s4_filename = "S4 POSITION " + date.ToString("dd.MM.yyyy") + "a" + ".xls";
            string S4_FilePath = "http://teamsites.sc.com/sites/csnigeria/Document Library/" + s4_filename; //S4 POSITION 19.04.2017a.xls

            SqlConnection con = new SqlConnection(conStr);

            try
            {
                Recon_Date = Get_Recon_Date(conStr, Country, "ddMMyyyy");

                Formatted_File_Name = Path.GetFileNameWithoutExtension(Formatted_File_Name);
                Formatted_File_Name = Formatted_File_Name.Remove(Formatted_File_Name.Length - 8);
                Formatted_File_Name = Formatted_File_Name + Recon_Date; // + dt + mn + year;

                //string targetPath = Share_Path; //For ARC_Main Only -- Prakash
                string targetPath = Share_Path + @"Input\" + Application + "_" + Country + "\\" + Report_Source_File_Name + ".xls"; //For OpenSpan Only -- Prakash
                string FormatPath = Desti_Path + Formatted_File_Name + ".csv";
                string OutputPath = Share_Path + @"Output\" + Recon_Name + "\\";

                WebClient client = new WebClient();
                client.UseDefaultCredentials = true;
                bool isfileExists = false;

                isfileExists = RemoteFileExists(S4_FilePath);

                //if (isfileExists)
                {
                    if (!File.Exists(targetPath))
                    {
                        client.DownloadFile(S4_FilePath, targetPath);
                        client.Dispose();
                    }

                    Microsoft.Office.Interop.Excel.Application excel = new Microsoft.Office.Interop.Excel.Application();
                    Microsoft.Office.Interop.Excel.Workbook wb = excel.Workbooks.Open(targetPath, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                    Microsoft.Office.Interop.Excel._Worksheet ws = (Microsoft.Office.Interop.Excel.Worksheet)excel.ActiveSheet;// (Microsoft.Office.Interop.Excel.Worksheet)excel.Sheets["Sheet1"];
                    excel.DisplayAlerts = false;
                    excel.Visible = false;

                    wb.SaveCopyAs(FormatPath);
                    excel.Quit();

                    System.Runtime.InteropServices.Marshal.ReleaseComObject(ws);
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(wb);
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(excel);

                    string tempOutputPath = OutputPath + Formatted_File_Name + ".csv";

                    string[] inputFilePaths = Directory.GetFiles(Path.GetDirectoryName(FormatPath), @"*.csv");
                    foreach (var inputFilePath in inputFilePaths)
                    {
                        DirectoryInfo di = new DirectoryInfo(inputFilePath);

                        Microsoft.Office.Interop.Excel.Application app = new Microsoft.Office.Interop.Excel.Application();
                        Microsoft.Office.Interop.Excel.Workbook wb1 = app.Workbooks.Open(inputFilePath, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                        app.DisplayAlerts = false;
                        app.Visible = false;
                        // this does not throw exception if file doesnt exist
                        //File.Delete(tempFilePath);

                        wb1.SaveAs(FormatPath, Microsoft.Office.Interop.Excel.XlFileFormat.xlCSVWindows, Type.Missing, Type.Missing, false, false, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlExclusive, Microsoft.Office.Interop.Excel.XlSaveConflictResolution.xlLocalSessionChanges, false, Type.Missing, Type.Missing, Type.Missing);
                        wb1.Close(false, Type.Missing, Type.Missing);
                        app.Quit();

                        //System.Runtime.InteropServices.Marshal.ReleaseComObject(ws);
                        System.Runtime.InteropServices.Marshal.ReleaseComObject(wb1);
                        System.Runtime.InteropServices.Marshal.ReleaseComObject(app);

                        File.Move(FormatPath, Path.ChangeExtension(tempOutputPath, ".txt"));

                    }

                    //string shrePath = Path.GetDirectoryName(tempFilePath) + "//";

                    Fileses(OutputPath, Recon_Name);

                    string finalOutputfile = OutputPath + Formatted_File_Name + dbExt;

                    if (File.Exists(finalOutputfile))
                    {
                        SqlCommand cmd = new SqlCommand("update Arc_Scope_BaseLine set PSID = '" + Environment.UserName + "',AutomationStartTime = '" + DateTime.Now + "',AutomationEndTime = '" + DateTime.Now + "', IsProcessed = 1 , AutomationStatus = 'COMPLETED' where Country_Name = '" + Country + "' and Recon = '" + Recon_Name + "' and Report_Source_File_Name like '" + Report_Source_File_Name + "%'", con);
                        con.Open();
                        cmd.ExecuteNonQuery();
                        con.Close();
                        //Update the DB
                    }

                }
                //else
                //{
                //    MessageBox.Show("Input file S4 POSITION DD.MM.YYYY - yet to come.");
                //}

                string inputfile3 = @"\\10.132.5.78\grh\Grh\Operations\Dataupload_GRU\Nigeria_Strock_custody\";

                //if (Application == "Shared Drive")
                //{
                // List<String> files = new List<String>();

                //if (Report_Source_File_Name.Contains("NG_NCS"))
                //{
                List<string> file2 = new List<string>();
                file2 = Directory.GetFiles(inputfile3, "NG_NCS*.*", SearchOption.AllDirectories).ToList(); //Directory.EnumerateFiles

                foreach (string s in file2)
                {
                    string fileName = System.IO.Path.GetFileName(s);
                    //string file_Nm_ToUpdt_DB = Path.GetFileNameWithoutExtension(fileName);

                    if (fileName.Contains("NG_NCS"))
                    {
                        string temp_File_NM_DB = fileName.Remove(fileName.LastIndexOf("_")).Trim();
                        fileName = Path.GetFileNameWithoutExtension(fileName);
                        fileName = fileName.Substring(0, fileName.Length - 8).Trim();
                        fileName = fileName + Recon_Date + dbExt; // + dt + mn + year + dbExt;
                        string destFile = string.Empty;

                        destFile = System.IO.Path.Combine(OutputPath, fileName);

                        if (!File.Exists(destFile))
                        {
                            System.IO.File.Copy(s, destFile, true);
                            if (File.Exists(destFile))
                            {
                                SqlCommand cmd = new SqlCommand("update Arc_Scope_BaseLine set PSID = '" + Environment.UserName + "',AutomationStartTime = '" + DateTime.Now + "',AutomationEndTime = '" + DateTime.Now + "', IsProcessed = 1 , AutomationStatus = 'COMPLETED' where Country_Name = '" + Country + "' and Recon = '" + Recon_Name + "' and Report_Source_File_Name like '" + temp_File_NM_DB + "%'", con);
                                con.Open();
                                cmd.ExecuteNonQuery();
                                con.Close();
                            }
                        }
                    }
                }
                //}
                //}
            }
            catch
            {

            }

        }

        public void Nigeria_DailyEquity_Position(string Country, string Recon_Name, string Application, string Report_Source_File_Name, string Formatted_File_Name, string dbExt, string conStr, string Share_Path, string Desti_Path, string Recon_Date)
        {

            System.DateTime date = System.DateTime.Today; //AddDays(-1)
            //string dt = System.DateTime.Today.ToString("dd"); //AddDays(-1)
            //string mn = System.DateTime.Now.ToString("MM");
            //int year = System.DateTime.Now.Year;
            //string yr = System.DateTime.Now.ToString("yy");
            //string month = System.DateTime.Now.ToString("MMMM");

            string cscs_filename = "CSCS POSITION " + date.ToString("MMMM yyyy") + ".xls";
            string CSCS_FilePath = "http://teamsites.sc.com/sites/csnigeria/Document Library/" + cscs_filename; //CSCS POSITION APRIL 2017

            SqlConnection con = new SqlConnection(conStr);

            try
            {
                Recon_Date = Get_Recon_Date(conStr, Country, "ddMMyyyy");

                Formatted_File_Name = Path.GetFileNameWithoutExtension(Formatted_File_Name);
                Formatted_File_Name = Formatted_File_Name.Remove(Formatted_File_Name.Length - 8);
                Formatted_File_Name = Formatted_File_Name + Recon_Date; // + dt + mn + year;

                //string targetPath = Share_Path; //For ARC_Main Only -- Prakash
                string targetPath = Share_Path + @"Input\" + Application + "_" + Country + "\\" + Report_Source_File_Name + ".xls"; //For OpenSpan Only -- Prakash
                string FormatPath = Desti_Path + Formatted_File_Name + ".csv";
                string OutputPath = Share_Path + @"Output\" + Recon_Name + "\\";

                WebClient client = new WebClient();
                client.UseDefaultCredentials = true;
                bool isfileExists = false;

                isfileExists = RemoteFileExists(CSCS_FilePath);

                //if (isfileExists)
                {
                    if (!File.Exists(targetPath))
                    {
                        client.DownloadFile(CSCS_FilePath, targetPath);
                        client.Dispose();
                    }

                    Microsoft.Office.Interop.Excel.Application excel = new Microsoft.Office.Interop.Excel.Application();
                    Microsoft.Office.Interop.Excel.Workbook wb = excel.Workbooks.Open(targetPath, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                    Microsoft.Office.Interop.Excel._Worksheet ws = (Microsoft.Office.Interop.Excel.Worksheet)excel.ActiveSheet;// (Microsoft.Office.Interop.Excel.Worksheet)excel.Sheets["Sheet1"];
                    excel.DisplayAlerts = false;
                    excel.Visible = false;

                    wb.SaveCopyAs(FormatPath);
                    excel.Quit();

                    System.Runtime.InteropServices.Marshal.ReleaseComObject(ws);
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(wb);
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(excel);

                    string tempOutputPath = OutputPath + Formatted_File_Name + ".csv";

                    string[] inputFilePaths = Directory.GetFiles(Path.GetDirectoryName(FormatPath), @"*.csv");
                    foreach (var inputFilePath in inputFilePaths)
                    {
                        DirectoryInfo di = new DirectoryInfo(inputFilePath);

                        Microsoft.Office.Interop.Excel.Application app = new Microsoft.Office.Interop.Excel.Application();
                        Microsoft.Office.Interop.Excel.Workbook wb1 = app.Workbooks.Open(inputFilePath, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                        app.DisplayAlerts = false;
                        app.Visible = false;
                        // this does not throw exception if file doesnt exist
                        //File.Delete(tempFilePath);

                        wb1.SaveAs(FormatPath, Microsoft.Office.Interop.Excel.XlFileFormat.xlCSVWindows, Type.Missing, Type.Missing, false, false, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlExclusive, Microsoft.Office.Interop.Excel.XlSaveConflictResolution.xlLocalSessionChanges, false, Type.Missing, Type.Missing, Type.Missing);
                        wb1.Close(false, Type.Missing, Type.Missing);
                        app.Quit();

                        //System.Runtime.InteropServices.Marshal.ReleaseComObject(ws);
                        System.Runtime.InteropServices.Marshal.ReleaseComObject(wb1);
                        System.Runtime.InteropServices.Marshal.ReleaseComObject(app);

                        File.Move(FormatPath, Path.ChangeExtension(tempOutputPath, ".txt"));

                    }

                    //string shrePath = Path.GetDirectoryName(tempFilePath) + "//";

                    Fileses(OutputPath, Recon_Name);

                    string finalOutputfile = OutputPath + Formatted_File_Name + dbExt;

                    if (File.Exists(finalOutputfile))
                    {
                        SqlCommand cmd = new SqlCommand("update Arc_Scope_BaseLine set PSID = '" + Environment.UserName + "',AutomationStartTime = '" + DateTime.Now + "',AutomationEndTime = '" + DateTime.Now + "', IsProcessed = 1 , AutomationStatus = 'COMPLETED' where Country_Name = '" + Country + "' and Recon = '" + Recon_Name + "' and Report_Source_File_Name like '" + Report_Source_File_Name + "%'", con);
                        con.Open();
                        cmd.ExecuteNonQuery();
                        con.Close();
                        //Update the DB
                    }

                }
                //else
                //{
                //    MessageBox.Show("Input file S4 POSITION DD.MM.YYYY - yet to come.");
                //}
            }
            catch
            {

            }

        }

        public bool RemoteFileExists(string url)
        {
            try
            {
                //Creating the HttpWebRequest
                HttpWebRequest request = WebRequest.Create(url) as HttpWebRequest;
                //Setting the Request method HEAD, you can also use GET too.
                request.UseDefaultCredentials = true;
                request.Method = "HEAD";
                //Getting the Web Response.
                HttpWebResponse response = request.GetResponse() as HttpWebResponse;
                //Returns TRUE if the Status code == 200
                response.Close();
                return (response.StatusCode == HttpStatusCode.OK);
            }
            catch
            {
                //Any exception will returns false.
                return false;
            }

        }

        public int Get_HolidaysTotal(string conStr, string CountryName, string Date_Format)
        {
            string Final_Date = string.Empty;
            string fmt = CultureInfo.CurrentCulture.DateTimeFormat.ShortDatePattern;
            int t = 0;
            try
            {
                int day = 0;
                string actd = "";
                int datefound = 0;
                System.Data.DataTable dt = new System.Data.DataTable();
                System.Data.DataTable table = new System.Data.DataTable();
                System.Data.DataTable date = new System.Data.DataTable();
                SqlConnection con = new SqlConnection(conStr);
                string Today = DateTime.Now.ToString("dddd");

                //string date = DateTime.Now.ToString("09/09/2017");
                //*************************************************************************
                SqlDataAdapter ad = new SqlDataAdapter("dbo.ARC_SP_Get_Holiday_Date", con);
                ad.SelectCommand.CommandType = CommandType.StoredProcedure;
                ad.SelectCommand.Parameters.AddWithValue("@Country_Name", CountryName);
                con.Open();
                ad.Fill(table);
                con.Close();

                if (table.Rows.Count > 0)
                {
                    if (Convert.ToString(table.Rows[0][2]).Trim() == "NonGulf")
                    {
                        int Year = Convert.ToInt32(DateTime.Now.ToString("yyyy"));
                        //DateTime EndOfYear = Convert.ToDateTime("31-12-" + Year + "");
                        DateTime startDate = new DateTime(Year, 1, 1);
                        DateTime endDate = new DateTime(Year, 12, 31);

                        date.Columns.Add("Holiday_Date", typeof(DateTime));
                        date.Columns.Add("Country_Id", typeof(long));
                        date.Columns.Add("Gulf");
                        TimeSpan diff = endDate - startDate;
                        int days = diff.Days;
                        for (var i = 0; i <= days; i++)
                        {
                            var testDate = startDate.AddDays(i);
                            try
                            {
                                switch (testDate.DayOfWeek)
                                {
                                    case DayOfWeek.Saturday:
                                    case DayOfWeek.Sunday:
                                        date.Rows.Add();
                                        date.Rows.Add(testDate.ToString(fmt));
                                        break;
                                }

                            }
                            catch
                            {

                            }
                        }
                        date.Merge(table);
                        ExecRemoveDuplicateRows(date, "Holiday_Date");
                    }
                    else
                    {
                        int Year = Convert.ToInt32(DateTime.Now.ToString("yyyy"));
                        DateTime startDate = new DateTime(Year, 1, 1);
                        DateTime endDate = new DateTime(Year, 12, 31);

                        date.Columns.Add("Holiday_Date", typeof(DateTime));
                        date.Columns.Add("Country_Id", typeof(long));
                        date.Columns.Add("Gulf");
                        TimeSpan diff = endDate - startDate;
                        int days = diff.Days;
                        for (var i = 0; i <= days; i++)
                        {
                            var testDate = startDate.AddDays(i);
                            switch (testDate.DayOfWeek)
                            {
                                case DayOfWeek.Friday:
                                case DayOfWeek.Saturday:
                                    date.Rows.Add(testDate.ToString(fmt));
                                    break;
                            }
                        }
                        date.Merge(table);
                    }
                }
                else
                {
                    SqlCommand ad1 = new SqlCommand("dbo.ARC_SP_Get_Holiday_Date_NoHoliday", con);
                    ad1.CommandType = CommandType.StoredProcedure;
                    ad1.Parameters.AddWithValue("@Country_Name", CountryName);
                    con.Open();
                    string Result = Convert.ToString(ad1.ExecuteScalar());

                    con.Close();

                    if (Result == "NonGulf")
                    {
                        int Year = Convert.ToInt32(DateTime.Now.ToString("yyyy"));
                        DateTime startDate = new DateTime(Year, 1, 1);
                        DateTime endDate = new DateTime(Year, 12, 31);

                        date.Columns.Add("Holiday_Date", typeof(DateTime));
                        date.Columns.Add("Country_Id", typeof(long));
                        date.Columns.Add("Gulf");
                        TimeSpan diff = endDate - startDate;
                        int days = diff.Days;
                        for (var i = 0; i <= days; i++)
                        {
                            var testDate = startDate.AddDays(i);
                            switch (testDate.DayOfWeek)
                            {
                                case DayOfWeek.Saturday:
                                case DayOfWeek.Sunday:
                                    date.Rows.Add(testDate.ToString(fmt));
                                    break;
                            }
                        }
                    }
                    else
                    {
                        int Year = Convert.ToInt32(DateTime.Now.ToString("yyyy"));
                        DateTime startDate = new DateTime(Year, 1, 1);
                        DateTime endDate = new DateTime(Year, 12, 31);

                        date.Columns.Add("date");
                        TimeSpan diff = endDate - startDate;
                        int days = diff.Days;
                        for (var i = 0; i <= days; i++)
                        {
                            var testDate = startDate.AddDays(i);
                            switch (testDate.DayOfWeek)
                            {
                                case DayOfWeek.Friday:
                                case DayOfWeek.Saturday:
                                    date.Rows.Add(testDate.ToString(fmt));
                                    break;
                            }
                        }
                    }
                    date.Merge(table);

                }
                //************************************************

                DataView v = date.DefaultView;
                v.Sort = "Holiday_Date";
                System.Data.DataTable d = new System.Data.DataTable();
                d = v.ToTable();
                try
                {
                    for (int i = 0; i <= d.Rows.Count - 1; i++)
                    {
                        if (d.Rows[i][0].ToString() != "")
                        {

                            string d1 = DateTime.Now.AddDays(-2).ToString("MM/dd/yyyy");
                            string d2 = DateTime.Now.AddDays(-3).ToString("MM/dd/yyyy");
                            string d3 = DateTime.Now.AddDays(-4).ToString("MM/dd/yyyy");
                            string d4 = DateTime.Now.AddDays(-5).ToString("MM/dd/yyyy");
                            string d5 = DateTime.Now.AddDays(-6).ToString("MM/dd/yyyy");
                            actd = Convert.ToDateTime(d.Rows[i][0]).ToString("MM/dd/yyyy");
                            if (d1 == actd)
                            {
                                datefound = 1;
                                day = day + 1;
                                actd = Convert.ToDateTime(d.Rows[i - 1][0]).ToString("MM/dd/yyyy");
                                if (d2 == actd)
                                {
                                    day = day + 1;
                                    actd = Convert.ToDateTime(d.Rows[i - 2][0]).ToString("MM/dd/yyyy");
                                    if (d3 == actd)
                                    {
                                        day = day + 1;
                                        actd = Convert.ToDateTime(d.Rows[i - 3][0]).ToString("MM/dd/yyyy");
                                        if (d4 == actd)
                                        {
                                            day = day + 1;
                                            actd = Convert.ToDateTime(d.Rows[i - 4][0]).ToString("MM/dd/yyyy");
                                            if (d5 == actd)
                                            {
                                                day = day + 1;
                                                actd = Convert.ToDateTime(d.Rows[i - 5][0]).ToString("MM/dd/yyyy");
                                            }
                                        }
                                    }
                                }
                            }
                        }


                    }



                    //MessageBox.Show("Pick " + (day + 1).ToString() + " Days before File");
                    if (t == 0)
                    {
                        t = 1;
                    }
                    else
                    {
                        t = day + 1;
                    }


                }
                catch
                {
                    MessageBox.Show("");
                }

            }
            catch
            {

            }

            return t;
        }

        //CTRL_D_DATE_CHECK_GULF_COUNTRYS//
        public bool Check_CTRL_GULF_FILE_DATE(string file_Path, out string File_Date)
        {
            string fileName = file_Path; // "RPRDRO02-SB-IN.txt";
            string textLine = "";
            string settlementdate = "";

            bool isdate = false;
            bool isEOR = false;
            bool isSuccess = false;
            try
            {
                if (File.Exists(fileName) == true)
                {
                    StreamReader objReader = new StreamReader(fileName);
                    do
                    {
                        textLine = objReader.ReadLine();

                        if (isdate == false)
                        {
                            if (textLine.ToUpper().Contains("AS OF "))
                            {
                                string path = textLine;
                                int pos = path.LastIndexOf("AS OF ") + 6;
                                settlementdate = (path.Substring(pos, path.Length - pos));
                                isdate = true;
                            }
                        }

                        if (textLine.Contains("END OF REPORT"))
                        {
                            isEOR = true;
                            break;
                        }

                        bool _ret = objReader.EndOfStream;
                    }
                    while (objReader.Peek() != -1);
                    objReader.Close();

                    if (isdate && isEOR)
                    {
                        isSuccess = true;
                    }
                }
                settlementdate = DateTime.ParseExact(settlementdate, "dd MMM yy", CultureInfo.InvariantCulture).ToString("yyyyMMdd");
                File_Date = settlementdate;
                return isSuccess;
            }
            catch
            {
                File_Date = null;
                return false;
            }
        }

        public string Get_Recon_DateforFxtenta(string s)
        {
            try
            {
                StreamReader objReader;
                objReader = new StreamReader(s);
                string temp = "";
                string temp2 = "";
                string[] lines = System.IO.File.ReadAllLines(s);
                for (int i = 0; i <= lines.Length - 1; i++)
                {

                    temp = lines[0].ToString().Substring(lines[i].ToString().Length - 8, 6);
                    temp2 = "20" + temp.Substring(0, 2) + temp.Substring(2, 2) + temp.Substring(4, 2);
                    break;
                }
                return temp2;
            }
            catch
            {
                return null;
            }
        }

        public string Get_Recon_DateForfxro8(string s)
        {
            try
            {
                StreamReader objReader;
                objReader = new StreamReader(s);
                string temp = "";
                string temp2 = "";
                string[] lines = System.IO.File.ReadAllLines(s);
                for (int i = 0; i <= lines.Length - 1; i++)
                {
                    temp = lines[0].ToString().Substring(lines[i].ToString().Length - 6, 6);
                    temp2 = "20" + temp.Substring(0, 2) + temp.Substring(2, 2) + temp.Substring(4, 2);
                    break;
                }
                return temp2;
            }
            catch
            {
                return null;
            }
        }

        public System.Data.DataTable dubaiAE_Cust(string filepath,string recondate)
        {
            //string frmt = CultureInfo.CurrentUICulture.CultureTypes.ToString();
            bool iSClose = false;
            System.Data.DataTable dt = new System.Data.DataTable();
            string Recondate1 = recondate.ToString().Substring(6, 2) + "/" + recondate.ToString().Substring(4, 2) + "/" + recondate.ToString().Substring(0, 4);
            string folderdate = DateTime.Now.ToString("dd-MMM-yyyy");
            string date = DateTime.Now.AddDays(-1).ToString("yyyyMMdd");
            string filePath = filepath;
            bool hasHeaders = true;
            try
            {
                if (File.Exists(filePath))
                {
                    string HDR = hasHeaders ? "Yes" : "No";
                    string strConn;

                    if ((filePath.Substring(filePath.LastIndexOf('.')).ToLower() == ".xlsx") || (filePath.Substring(filePath.LastIndexOf('.')).ToLower() == ".xls"))
                        strConn = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + filePath + ";Extended Properties=\"Excel 12.0;HDR=" + HDR + ";IMEX=1\"";
                    else
                        strConn = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + filePath + ";Extended Properties=\"Excel 8.0;HDR=" + HDR + ";IMEX=1\"";

                    System.Data.DataTable dtexcel = new System.Data.DataTable();
                    System.Data.DataTable dtfinal = new System.Data.DataTable();

                    OleDbConnection conn = new OleDbConnection(strConn);
                    try
                    {
                        conn.Open();
                    }
                    catch
                    {
                        iSClose = true;
                        excel = new Excel.Application();
                        excel.Visible = false;
                        excel.DisplayAlerts = false;
                        excelworkBook = excel.Workbooks.Open(filePath, false, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                        conn.Open();
                    }
                    System.Data.DataTable schemaTable = conn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, new object[] { null, null, null, "TABLE" });

                    string sheet = string.Empty;
                    foreach (DataRow d in schemaTable.Rows)
                    {
                        if (d["TABLE_NAME"].ToString().EndsWith("#rdl$"))
                        {
                            sheet = d["TABLE_NAME"].ToString();
                            break;
                        }
                    }

                    string query = "SELECT  * FROM [" + sheet + "]";
                    OleDbDataAdapter daexcel = new OleDbDataAdapter(query, conn);
                    dtexcel.Locale = CultureInfo.CurrentCulture;
                    daexcel.Fill(dtexcel);
                    conn.Close();
                    string Securitycode = "";
                    string SecurityName = "";

                    int k = 1;

                    dt.Columns.Add("#PAGENO");
                    dt.Columns.Add("SUBACC");
                    dt.Columns.Add("SIDE");
                    dt.Columns.Add("SIGN");
                    dt.Columns.Add("FROMDATE");
                    dt.Columns.Add("TODATE");
                    dt.Columns.Add("NOOFPARTS");
                    dt.Columns.Add("TRANCODE");
                    dt.Columns.Add("FUNDSCAID");
                    dt.Columns.Add("SECURITY");
                    dt.Columns.Add("ISIN");
                    dt.Columns.Add("QTY");
                    dt.Columns.Add("PPUCY");
                    dt.Columns.Add("XAMT1");
                    dt.Columns.Add("XAMT2");
                    dt.Columns.Add("XAMT3");
                    dt.Columns.Add("XAMT15");
                    dt.Columns.Add("XDATE1");
                    dt.Columns.Add("XSTR1");
                    dt.Columns.Add("XSTR2");
                    dt.Columns.Add("XSTR3");
                    dt.Columns.Add("XSTR4");
                    dt.Columns.Add("XSTR5");
                    dt.Columns.Add("XSTR6");

                    for (int j = 7; j <= dtexcel.Rows.Count - 1; j++)
                    {
                        if (dtexcel.Rows[j][0].ToString() != "")
                        {
                            dt.Rows.Add();
                            dt.Rows.Add();
                            dt.Rows[k][0] = "1" + "|";
                            dt.Rows[k][1] = "AE-STA" + "|";
                            dt.Rows[k][2] = "S" + "|";
                            dt.Rows[k][3] = "C" + "|";
                            dt.Rows[k][4] = Recondate1;
                            //dt.Rows[k][4] = DateTime.Today.AddDays(-1).ToString("dd/MM/yyyy") + "|";
                            dt.Rows[k][5] = Recondate1;
                            //dt.Rows[k][5] = DateTime.Today.AddDays(-1).ToString("dd/MM/yyyy") + "|";
                            dt.Rows[k][6] = "" + "|";
                            dt.Rows[k][7] = "STMT" + "|";

                            dt.Rows[k][8] = dtexcel.Rows[j][2].ToString() + "|";
                            dt.Rows[k][9] = dtexcel.Rows[j][3].ToString() + "|";
                            dt.Rows[k][10] = "" + "|";

                            SecurityName = dtexcel.Rows[j][7].ToString().Replace(",", "");
                            SecurityName = SecurityName.Replace(".00", "");
                            dt.Rows[k][11] = SecurityName + "|";

                            dt.Rows[k][12] = "" + "|";

                            Securitycode = dtexcel.Rows[j][8].ToString().Replace(",", "");
                            Securitycode = Securitycode.Replace(".00", "");
                            dt.Rows[k][13] = Securitycode + "|";

                            //dt.Rows[k][13] = dtexcel.Rows[j][8].ToString().Replace(",","") + "|";

                            dt.Rows[k][14] = "" + "|";
                            dt.Rows[k][15] = "" + "|";
                            dt.Rows[k][16] = "" + "|";
                            dt.Rows[k][17] = "" + "|";
                            dt.Rows[k][18] = "" + "|";
                            dt.Rows[k][19] = "" + "|";
                            dt.Rows[k][20] = "" + "|";
                            dt.Rows[k][21] = dtexcel.Rows[j][5].ToString() + "|";
                            dt.Rows[k][22] = "" + "|";
                            dt.Rows[k][23] = dtexcel.Rows[j][6].ToString();

                            k = k + 1;
                        }
                    }
                }
                if (iSClose == true)
                {
                    excelworkBook.Close();
                    excel.Quit();
                    ReleaseComObject(excelworkBook);
                    ReleaseComObject(excel);
                }
                return dt;
            }
            catch
            {
                return null;
            }
        }

        public System.Data.DataTable dubaiAE_SCB_Position(string crystalpath,string recondate)
        {
            System.Data.DataTable dt1 = new System.Data.DataTable();
            try
            {
                string folderdate = DateTime.Now.ToString("dd-MMM-yyyy");
                string date = DateTime.Now.AddDays(-1).ToString("yyyyMMdd");
                bool hasHeaders = true;
                string Recondate1 = recondate.ToString().Substring(6, 2) + "/" + recondate.ToString().Substring(4, 2) + "/" + recondate.ToString().Substring(0, 4);
                if (File.Exists(crystalpath))
                {
                    string HDR = hasHeaders ? "Yes" : "No";
                    string strConn;
                    if ((crystalpath.Substring(crystalpath.LastIndexOf('.')).ToLower() == ".xlsx") || (crystalpath.Substring(crystalpath.LastIndexOf('.')).ToLower() == ".xls"))
                        strConn = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + crystalpath + ";Extended Properties=\"Excel 12.0;HDR=" + HDR + ";IMEX=1\"";
                    else
                        strConn = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + crystalpath + ";Extended Properties=\"Excel 8.0;HDR=" + HDR + ";IMEX=1\"";

                    System.Data.DataTable dtexcel = new System.Data.DataTable();
                    System.Data.DataTable dtfinal = new System.Data.DataTable();

                    OleDbConnection conn = new OleDbConnection(strConn);
                    conn.Open();
                    System.Data.DataTable schemaTable = conn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, new object[] { null, null, null, "TABLE" });
                    DataRow schemaRow = schemaTable.Rows[0];
                    string sheet = schemaRow["TABLE_NAME"].ToString();
                    string query = "SELECT  * FROM [" + sheet + "]";
                    OleDbDataAdapter daexcel = new OleDbDataAdapter(query, conn);
                    dtexcel.Locale = CultureInfo.CurrentCulture;
                    daexcel.Fill(dtexcel);

                    int k = 1;

                    dt1.Columns.Add("#PAGENO");
                    dt1.Columns.Add("SUBACC");
                    dt1.Columns.Add("SIDE");
                    dt1.Columns.Add("SIGN");
                    dt1.Columns.Add("FROMDATE");
                    dt1.Columns.Add("TODATE");
                    dt1.Columns.Add("NOOFPARTS");
                    dt1.Columns.Add("TRANCODE");
                    dt1.Columns.Add("FUNDSCAID");
                    dt1.Columns.Add("SECURITY");
                    dt1.Columns.Add("ISIN");
                    dt1.Columns.Add("QTY");
                    dt1.Columns.Add("PPUCY");
                    dt1.Columns.Add("XAMT1");
                    dt1.Columns.Add("XAMT2");
                    dt1.Columns.Add("XAMT3");
                    dt1.Columns.Add("XAMT15");
                    dt1.Columns.Add("XDATE1");
                    dt1.Columns.Add("XSTR1");
                    dt1.Columns.Add("XSTR2");
                    dt1.Columns.Add("XSTR3");
                    dt1.Columns.Add("XSTR4");
                    dt1.Columns.Add("XSTR5");
                    dt1.Columns.Add("XSTR6");

                    for (int j = 1; j <= dtexcel.Rows.Count - 1; j++)
                    {
                        if ((dtexcel.Rows[j][0].ToString() != "") && (dtexcel.Rows[j][1].ToString() == "SCB"))
                        {
                            dt1.Rows.Add();
                            dt1.Rows.Add();

                            dt1.Rows[k][0] = "1" + "|";
                            dt1.Rows[k][1] = "AE-STA" + "|";
                            dt1.Rows[k][2] = "S" + "|";
                            dt1.Rows[k][3] = "C" + "|";
                            //dt1.Rows[k][4] = DateTime.Today.AddDays(-1).ToString("dd/MM/yyyy") + "|";
                            dt1.Rows[k][4] = Recondate1;
                            //dt1.Rows[k][5] = DateTime.Today.AddDays(-1).ToString("dd/MM/yyyy") + "|";
                            dt1.Rows[k][5] = Recondate1;
                            dt1.Rows[k][6] = "" + "|";
                            dt1.Rows[k][7] = "STMT" + "|";
                            dt1.Rows[k][8] = dtexcel.Rows[j][3].ToString() + "|";
                            dt1.Rows[k][9] = dtexcel.Rows[j][9].ToString() + "|";
                            dt1.Rows[k][10] = "" + "|";
                            dt1.Rows[k][11] = dtexcel.Rows[j][14].ToString() + "|";
                            dt1.Rows[k][12] = "" + "|";
                            dt1.Rows[k][13] = dtexcel.Rows[j][15].ToString() + "|";
                            dt1.Rows[k][14] = "" + "|";
                            dt1.Rows[k][15] = "" + "|";
                            dt1.Rows[k][16] = "" + "|";
                            dt1.Rows[k][17] = "" + "|";
                            dt1.Rows[k][18] = "" + "|";
                            dt1.Rows[k][19] = "" + "|";
                            dt1.Rows[k][20] = "" + "|";
                            dt1.Rows[k][21] = dtexcel.Rows[j][11].ToString() + "|";
                            dt1.Rows[k][22] = "" + "|";
                            dt1.Rows[k][23] = dtexcel.Rows[j][12].ToString();

                            k = k + 1;
                        }
                    }
                }
                return dt1;
            }
            catch
            {
                return null;
            }
        }

        public void WriteData_dubai_AE(System.Data.DataTable submittedDataTable, string submittedFilePath)
        {
            int i = 0;
            StreamWriter sw = null;
            sw = new StreamWriter(submittedFilePath, false);

            foreach (DataRow row in submittedDataTable.Rows)
            {
                object[] array = row.ItemArray;
                for (i = 0; i < array.Length - 1; i++)
                {
                    if (i == 0)
                    {
                        sw.WriteLine("#PAGENO|SUBACC|SIDE|SIGN|FROMDATE|TODATE|NOOFPARTS|TRANCODE|FUNDSCAID|SECURITY|ISIN|QTY|PPUCY|XAMT1|XAMT2|XAMT3|XAMT15|XDATE1|XSTR1|XSTR2|XSTR3|XSTR4|XSTR5|XSTR6");
                        break;
                    }
                }
                break;
            }

            foreach (DataRow row in submittedDataTable.Rows)
            {
                object[] array = row.ItemArray;
                for (i = 0; i < array.Length - 1; i++)
                {
                    sw.Write(array[i].ToString());
                }
                sw.Write(array[i].ToString());
                sw.WriteLine();
            }
            sw.Close();
        }
    }
}
