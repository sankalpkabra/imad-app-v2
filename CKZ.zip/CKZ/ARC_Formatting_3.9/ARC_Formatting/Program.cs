﻿#region History
//------------------------------------------------------------------------------------------------------------------------------------------
//     ID             |         FunctionName                 |       DeveloperName           |           DateofChange
//------------------------------------------------------------------------------------------------------------------------------------------
//    1001                      Formating_3_2 & CheckRecons           Kiran                         15-03-2018 07.45 P.M 
//    1002                      Formating_3_2 & CheckRecons           Aneesh                        16-03-2018 01.45 P.M
//    1003                      Formating_3_2 & CheckRecons           Aneesh                        16-03-2018 07.45 P.M
//    1004                      Formating_3_2 & CheckRecons           Kiran                         21-03-2018 07.50 P.M
//    1005                      CheckRecons                           Prakash                       Prakash-05/04/2018
//    1006                      Formating_3_2 & CheckRecons           Aneesh                        06-04-2018 09.45 P.M
//    1007                      CheckRecons                           Aneesh                        12-04-2018 08.05 P.M
//    1008                      Formating_3_2 & CheckRecons           Kiran                         16-04-2018 07.45 P.M
//    1009                      Formating_3_2 & CheckRecons           Kiran                         16-04-2018 08.45 P.M
//    1010                      CheckRecons                           Aneesh                        19-04-2018 12.05 P.M
//    1011                      CheckRecons                           Aneesh                        18-05-2018 06.05 P.M
//    1012                      CheckRecons                           Aneesh                        21-05-2018 07.05 P.M
//    1013                      Formating_3_2 & CheckRecons           Prakash                       25-05-2018 03.50 P.M
//------------------------------------------------------------------------------------------------------------------------------------------
#endregion History

using System;
using System.Data;
using System.Threading;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using System.Drawing;
using System.Data.OleDb;
using System.Globalization;
using System.Configuration;
using System.Xml;
using System.Collections;
using Ionic.Zip;
using System.Timers;
using System.Security.Cryptography;
using System.Text;
using ARC_Formatting.FileFormatting;
using System.Runtime.InteropServices;

namespace ARC_Formatting
{
    class Program
    {
        Formatting_Logics obj = new Formatting_Logics();
        static string conString = ConfigurationManager.ConnectionStrings["ARC_conStr"].ConnectionString;
        static string Main_DIR_SharePath = ConfigurationManager.ConnectionStrings["Share_Path"].ToString();
        static System.Timers.Timer aTimer = new System.Timers.Timer();
        int Flag = 0;
        int File_Count = 0;
        int Non_For_Counter = 0;
        int For_Counter = 0;
        int For_Counter1 = 0;
        int For_Counter2 = 0;
        int For_Counter3 = 0;
        DataTable dt_Final = new DataTable();
        DataTable dt_Final1 = new DataTable();
        DataTable dt_Final_nepal = new DataTable();
        string date = string.Empty;
        string destFile = string.Empty;
        static string Directory = Main_DIR_SharePath + DateTime.Now.ToString("dd-MMM-yyyy") + "_Files\\";
        static string StrDirectory = Main_DIR_SharePath + DateTime.Now.ToString("dd-MMM-yyyy") + "_Files\\";


        //SA1003
        static string strReconID = "";
        static string strDateTime = "";
        static ConsoleEventDelegate handler;
        private delegate bool ConsoleEventDelegate(int eventType);
        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern bool SetConsoleCtrlHandler(ConsoleEventDelegate callback, bool add);
        //EA1003

        static void Main(string[] args)
        {
            if (!conString.StartsWith("Data"))
            {
                conString = Decrypt(conString);
            }

            SqlConnection conn = new SqlConnection(conString);
            conn.Open();
            string UserID = System.Environment.UserName;
            string qrry1 = "select Is_FirstTimeLogin from dbo.ARC_User_Info where UserID=@UserID";
            SqlCommand com = new SqlCommand(qrry1, conn);
            com.Parameters.AddWithValue("@UserID", UserID);
            //com.Parameters.AddWithValue("@Password", ecp.Encrypt(Psd.Trim()));
            SqlDataReader dr1 = com.ExecuteReader();// this line show the exception....

            while (dr1.Read())
            {
                //SA1003
                string filePath = Main_DIR_SharePath + "ExeRunning_Info.txt";
                handler = new ConsoleEventDelegate(ConsoleEventCallback);
                SetConsoleCtrlHandler(handler, true);

                bool IsRunning = IsExeRunning(filePath);
                //if (IsRunning == false)
                {
                    //EA1003

                    Program p = new Program();
                   // p.CheckFileRunning();
                    Console.WriteLine("Ver: 3.9.1");// Plz Change the Version Number After deploye the Code
                    Console.WriteLine("Checking folder Directory for " + DateTime.Now.ToString("dd-MMM-yyyy") + "_Files");
                    Console.WriteLine("Please wait...!");
                    Formatting_Logics obj = new Formatting_Logics();
                    //obj.Create_Directory(conString, Directory);
                    Console.WriteLine("Directory Creation Done...!");

                   // p.Holiday_Logics(conString);

                    p.Check_Recons();
                    //p.Formating_3_2(StrDirectory);
                    //Bind_Recon_Holiday_Status();

                    aTimer.Elapsed += new ElapsedEventHandler(OnTimedEvent);
                    aTimer.Interval = (30000);  // 60 sec.
                    aTimer.Enabled = true;
                    aTimer.Start();
                    //Console.WriteLine("Press \'q\' then Press Enter...! to quit the timer.");
                    while (Console.Read() != 'q') ;
                }
            }
            if (dr1.HasRows == false)
            {
                MessageBox.Show("User id doesn't have access");
            }
            conn.Close();
        }

        private static void OnTimedEvent(object source, ElapsedEventArgs e)
        {
            Program p = new Program();
            Console.WriteLine("Formatting Code Start at -->>" + DateTime.Now.ToShortTimeString());
            try
            {
                p.Check_Recons();
                //p.Formating_3_2(StrDirectory);
                aTimer.Start();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                Console.ReadLine();
                aTimer.Start();
            }
            Console.WriteLine("Formatting Code End at -->>" + DateTime.Now.ToShortTimeString());
        }
        //Bala Added for OpicsRecon
        public bool isOpics(string ConStr, string strReconName)
        {
            bool result = false;
            try
            {
                System.Data.DataTable dt = new System.Data.DataTable();
                SqlConnection con = new SqlConnection(ConStr);
                SqlCommand cmd = new SqlCommand("select Count(1) from ARC_SCope_Baseline where Source_Application in ('OpicsPlus','OpicsPVB','OpicsReg','OpicsAfrica') and Recon = '" + strReconName + "'", con);
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                dt.Load(dr);
                if (dt.Rows[0][0].ToString() != "0")
                {
                    result = true;
                }
                con.Close();
            }
            catch (Exception ex)
            {

            }
            return result;
        }

        //Bala Added for OpicsRecon
        //***************************Start Formatting Code*****************************//
        public void Check_Recons()
        {
            aTimer.Stop();
            string Soure_Path = string.Empty;
            string Foramtted_Recon_Date = "";
            string Recon_name = "";
            int Recon_Id = 0;
            //SA1001
            Program.clsReconLog objReconLog = new Program.clsReconLog();
            //EA1001
            try
            {
                string Desti_Path = string.Empty;
                string Output_Path = string.Empty;
                DataTable dt_Recon = new DataTable();
                DataTable dt_BaseLine = new DataTable();
                SqlConnection con = new SqlConnection(conString);
                SqlCommand cmd = new SqlCommand();
                TimeSpan ts = new TimeSpan();
                DataTable dt_HKRPR1 = new DataTable();
                DataTable dt_HKRPR2 = new DataTable();
                //31-08
                DataTable dt_MX1 = new DataTable();
                DataTable dt_MX2 = new DataTable();
                DataTable dt_MX3 = new DataTable();
                DataTable dt_MX4 = new DataTable();
                bool FlagIndiaFT_Recon = false;
                //Individual Recons
                SqlDataAdapter ad = new SqlDataAdapter("select * from ARC_Recon_Master where Recon_Name = 'Hong Kong Trade RPR'", con);

                //All Recons
                //SqlDataAdapter ad = new SqlDataAdapter("select * from ARC_Recon_Master where Is_Recon_Completed = 0 and Is_Active = 1 and Is_Holiday_Logic = 0 order by Recon_Id ASC", con);

                con.Open();
                //MessageBox.Show("Connection opened");
                ad.Fill(dt_Recon);
                con.Close();

                for (int i = 0; i < dt_Recon.Rows.Count; i++)
                {
                    For_Counter = 0;
                    Non_For_Counter = 0;
                    dt_BaseLine = new DataTable();
                    Recon_name = Convert.ToString(dt_Recon.Rows[i][1]);
                    Recon_Id = Convert.ToInt32(dt_Recon.Rows[i][0]);
                    int Fcount = 0;
                    Check_Recon_Files_Count(Recon_name, Recon_Id, dt_Recon, out Fcount);

                    bool isOpicsRecon = false;
                    isOpicsRecon = isOpics(conString, Recon_name);

                    if (isOpicsRecon && Fcount != 0)
                    {
                        File_Count = Convert.ToInt32(dt_Recon.Rows[i][4]); //Fcount;
                    }
                    else
                    {
                        File_Count = Convert.ToInt32(dt_Recon.Rows[i][4]);
                    }

                    SqlDataAdapter ada = new SqlDataAdapter("Select Team, Country_Name, Report_Source_File_Name, Format_Direct_Upload, Source_Application, File_Format,FTP_File_Format_Name,AutomationStatus from ARC_Scope_BaseLine where IsProcessed = 1 and Recon_Id = " + Recon_Id + "", con);
                    con.Open();
                    ada.Fill(dt_BaseLine);
                    con.Close();
                    if (File_Count == dt_BaseLine.Rows.Count || Recon_name == "CO DISPOSAL" || Recon_name == "CCMS OPEN ITEMS")
                    {
                        MessageBox.Show(Recon_name.ToString());
                        //SA1001
                        clearRconLog(objReconLog);
                        objReconLog.ReconID = Recon_Id.ToString();
                        objReconLog.LineNo = "NIL";
                        objReconLog.ErrorMessage = "NIL";
                        objReconLog.Flag = "Start";
                        objReconLog.StartTime = DateTime.Now.ToShortTimeString();
                        objReconLog.EndTime = "NIL";
                        objReconLog.ReconName = Recon_name;
                        objReconLog.UserID = Environment.UserName;
                        objReconLog.DateTime = DateTime.Now.ToString();
                        insertReconLog(objReconLog);
                        //EA1001

                        Console.WriteLine("Start Time -->" + DateTime.Now.ToShortTimeString() + " Recon: " + Recon_name);

                        DataRow[] dr = dt_BaseLine.Select("Format_Direct_Upload <> 'Formatting'");
                        DataRow[] dr2 = dt_BaseLine.Select("Format_Direct_Upload = 'Formatting'");
                        foreach (DataRow d in dr)
                        {
                            string Country = Convert.ToString(d[1]);
                            string File_Name = Convert.ToString(d[2]);
                            string IsFormatting = Convert.ToString(d[3]);
                            string Source_App = Convert.ToString(d[4]);
                            string File_Ext = Convert.ToString(d[5]);
                            string Formatted_File_Name = Convert.ToString(d[6]);
                            string AutomationStatus = Convert.ToString(d[7]);
                            string Recon_Date = string.Empty;
                            string db_Ext = string.Empty;
                            int NameLngth = 0;
                            //********************************************************************


                            if (File_Ext.Contains("xlsx"))
                            {
                                File_Ext = "xlsx";
                            }
                            if (File_Name.Contains("DD-MMM YYYY"))
                            {
                                Recon_Date = obj.Get_Recon_Date(conString, Country, "dd-MMM yyyy");
                                File_Name = File_Name.Remove(File_Name.Length - 11);
                                NameLngth = File_Name.Length;
                                File_Name = File_Name + Recon_Date;
                            }
                            // Ragavendran 10082017
                            else if (File_Name.Contains("YYDDMM"))
                            {
                                if (Recon_name == "Nepal - ATM CUP INTERNATIONAL Recon")
                                {
                                    Recon_Date = obj.Get_Recon_Date(conString, Country, "yyddMM");
                                    File_Name = obj.GetFileNameNepalATM(Directory + "Input\\Shared Drive_" + Country + "\\");
                                    // File_Name = File_Name.Remove(File_Name.Length - 14);
                                }
                                if (Recon_name == "Nepal -Retail Banking ATM CARD RECON" || Recon_name == "JORDAN - ATM RECON")
                                {
                                    if (File_Name.Contains("SMS"))
                                    {
                                        Recon_Date = obj.Get_Recon_Date(conString, Country, "yyddMM");
                                        File_Name = obj.GetFileNameNepalATMCARDSMS(Directory + "Input\\Shared Drive_" + Country + "\\");
                                    }
                                    else if (File_Name.Contains("MDS"))
                                    {
                                        Recon_Date = obj.Get_Recon_Date(conString, Country, "yyddMM");
                                        File_Name = obj.GetFileNameNepalATMCARDMDS(Directory + "Input\\Shared Drive_" + Country + "\\");
                                    }
                                }

                            }
                            // Ragavendran 10082017
                            else if (Recon_name == "India CCS Suspense")
                            {
                                if (File_Name.Contains("Settlement"))
                                {
                                    File_Name = obj.GetSpecificCCSIndia(Directory + "Input\\CCS Link_India\\", "Settlement");
                                }
                                else if (File_Name.Contains("Utilization"))
                                {
                                    File_Name = obj.GetSpecificCCSIndia(Directory + "Input\\CCS Link_India\\", "Utilization");
                                }
                                else if (File_Name.Contains("Post"))
                                {
                                    File_Name = obj.GetSpecificCCSIndia(Directory + "Input\\CCS Link_India\\", "Post");
                                }
                                else if (File_Name.Contains("can Report"))
                                {
                                    File_Name = obj.GetSpecificCCSIndia(Directory + "Input\\CCS Link_India\\", "can Report");
                                }
                                else
                                {
                                    Recon_Date = obj.Get_Recon_Date(conString, Country, "ddMMyyyy");
                                    File_Name = File_Name.Remove(File_Name.Length - 8);
                                    NameLngth = File_Name.Length;
                                    File_Name = File_Name + Recon_Date;
                                }
                            }
                            else if (Recon_name == "170224 Master I-net settlement-288887- Outgoing Interchange-1311 - 1351")
                            {
                                if (File_Name.Contains("YYYY-MM-DD"))
                                {
                                    Recon_Date = obj.Get_Recon_Date(conString, Country, "yyyy-MM-dd");
                                    //Recon_Date = Get_Recon_Date(conString, Country, "yyyy-MM-dd");
                                    File_Name = File_Name.Substring(0, File_Name.Length - 10);
                                    File_Name = File_Name + Recon_Date;
                                }

                            }
                            // Ragavendran 27072017
                            else if (Recon_name == "India - Phantom Nostro")
                            {
                                if (File_Name.Contains("DD_MMM"))
                                {
                                    Recon_Date = obj.Get_Recon_Date(conString, Country, "dd-MMM");
                                    //System.DateTime date = System.DateTime.Today; //AddDays(-1)
                                    File_Name = File_Name.Remove(File_Name.Length - 6);
                                    //File_Name = File_Name.Replace("dd-MMM", date.ToString("dd-MMM").ToUpper());
                                    File_Name = File_Name + Recon_Date;
                                }
                            }
                            // Ragavendran 27072017
                            else if (Recon_name == "289282-Meps ATM Settlement")
                            {
                                if (File_Name.Contains("MMDD"))
                                {
                                    Recon_Date = obj.Get_Recon_Date(conString, Country, "MMdd");
                                    //System.DateTime date = System.DateTime.Today; //AddDays(-1)
                                    File_Name = File_Name.Remove(File_Name.Length - 4);
                                    //File_Name = File_Name.Replace("dd-MMM", date.ToString("dd-MMM").ToUpper());
                                    File_Name = File_Name + Recon_Date;
                                }
                            }
                            else if (File_Name.Contains("YYMMDD") && !File_Name.Contains("YYYYMMDD"))
                            {
                                Recon_Date = obj.Get_Recon_Date(conString, Country, "yyMMdd");
                                if (Recon_name == "South Africa-  Stock open items")
                                {
                                    File_Name = File_Name.Remove(File_Name.Length - 6) + DateTime.Now.ToString("yyMMdd");
                                }
                                else if (Recon_name == "SUSPENSE OPEN ITEMS(CUP)")
                                {
                                    if (File_Name.Contains("01ACOM"))
                                    {
                                        File_Name = obj.GetFileNameIFDCOM(Directory + "Input\\Shared Drive_Malaysia\\");
                                    }
                                    else if (File_Name.Contains("01AERR"))
                                    {
                                        File_Name = obj.GetFileNameIFDAERR(Directory + "Input\\Shared Drive_Malaysia\\");
                                    }
                                }
                                // Ragavendran 28072017
                                // ragav 25 05 2016
                                else if (Recon_name == "Vietnam - Open Item")
                                {
                                    if (File_Name.Contains("Sophu"))
                                    {
                                        File_Name = File_Name.Substring(0, 5);
                                        cmd = new SqlCommand("update ARC_Scope_BaseLine set PSID = '" + Environment.UserName + "', IsProcessed = 1, AutomationStatus = 'COMPLETED' where Recon = '" + Recon_name + "' and Report_Source_File_Name like '" + File_Name + "%'", con);
                                    }
                                    else
                                    {
                                        cmd = new SqlCommand("update ARC_Scope_BaseLine set PSID = '" + Environment.UserName + "', IsProcessed = 1, AutomationStatus = 'COMPLETED' where Recon = '" + Recon_name + "' and Report_Source_File_Name like '" + File_Name + "%'", con);
                                    }
                                }
                                // ragav 25 05 2016

                                else
                                {
                                    Recon_Date = obj.Get_Recon_Date(conString, Country, "yyMMdd");
                                    File_Name = File_Name.Remove(File_Name.Length - 6);
                                    File_Name = File_Name + Recon_Date;
                                }
                            }

                          //25-05 Kiran
                            else if (File_Name.Contains("YYYYMMDD"))
                            {
                                if (File_Name.Contains("BALRES_"))
                                {
                                    Recon_Date = obj.Get_Recon_Date(conString, Country, "yyMMdd");
                                    obj.GetSpecificFileName_Thailand_Custody_DepoRecon(Directory + "Input\\Emails\\", Recon_Date);
                                }
                                else if (File_Name.Contains("STANDCHART SUB-REGISTRY"))
                                {
                                    File_Name = obj.STANDCHART_SUB_REGISTRY(Directory + "Input\\Emails\\", "standchart sub-registry");
                                }
                                //Prakash-10/08/2017
                                else if (File_Name.Contains("ePAY_TRADMP_SCB Internet Credit Card") || File_Name.Contains("ePAY_MRTDSR_SCB Internet Credit Card"))
                                {
                                    Recon_Date = obj.Get_Recon_Date(conString, Country, "yyyyMMdd");
                                    DateTime myDate = DateTime.ParseExact(Recon_Date, "yyyyMMdd", System.Globalization.CultureInfo.InvariantCulture);
                                    Recon_Date = myDate.AddDays(-1).ToString("yyyyMMdd");
                                    File_Name = File_Name.Substring(0, File_Name.Length - 8) + Recon_Date;

                                }
                                else if (Recon_name == "Mobile Recharge Transaction - Reconciliation-Total")
                                {
                                    string ATM_CSV = "ePAY_TRADMP_SCB - Standard Chartered Bank_";
                                    string Online_CSV = "ePAY_TRADMP_SCB Internet Debit Card_";
                                    string ATM_PDF = "ePAY_MRTDSR_Standard Chartered Bank_";
                                    string Online_PDF = "ePAY_MRTDSR_SCB Internet Debit Card_";

                                    //Formatted_File_Name = Formatted_File_Name.Remove(Formatted_File_Name.Length - 12);
                                    //Formatted_File_Name = Formatted_File_Name + Foramtted_Recon_Date;

                                    string FilePath = Directory + "Input\\" + Source_App + "_" + Country + "\\";
                                    Output_Path = Directory + "Output\\" + Recon_name + "\\";
                                    Desti_Path = Directory + "Files_For_Formatting_Or_Non_Formatting\\" + Recon_name + "\\Non_Formatting\\";

                                    if (Non_For_Counter != 4)
                                    {
                                        obj.Mobile_Recharge_Validation(File_Name, FilePath, Output_Path, Recon_Date, Desti_Path);
                                    }

                                    string[] sourcelist = System.IO.Directory.GetFiles(FilePath, "*.csv");
                                    string[] outlist = System.IO.Directory.GetFiles(Output_Path, "*.csv");
                                    if (sourcelist.Count() == outlist.Count())
                                    {
                                        Non_For_Counter = 4;
                                    }
                                }
                                else
                                {
                                    Recon_Date = obj.Get_Recon_Date(conString, Country, "yyyyMMdd");
                                    File_Name = File_Name.Remove(File_Name.Length - 8);
                                    File_Name = File_Name + Recon_Date;
                                }
                            }
                            else if (File_Name.Contains("DD.MM.YYYY"))
                            {
                                if (File_Name.Contains("AB-DETAIL_"))
                                {
                                    File_Name = obj.GetSpecificFileNameABDETAIL(Directory + "Input\\Emails\\");
                                }
                                else if (File_Name.Contains("BILLING SETTLEMENT"))
                                {
                                    File_Name = obj.GetSpecificFileName(Directory + "Input\\Emails\\");
                                }
                                else if (File_Name.Contains("ACQ SETTLEMENT"))
                                {
                                    File_Name = obj.GetSpecificFileNameSmartLink(Directory + "Input\\Emails\\", "ACQ");
                                }
                                else if (File_Name.Contains("ISS SETTLEMENT"))
                                {
                                    File_Name = obj.GetSpecificFileNameSmartLink(Directory + "Input\\Emails\\", "ISS");
                                }
                                else if (File_Name.Contains("Bonds Portfolio as"))
                                {
                                    File_Name = obj.GetSpecificFileNamePortfolioBonds(Directory + "Input\\Emails\\");
                                }
                                else
                                {
                                    Recon_Date = obj.Get_Recon_Date(conString, Country, "dd.MM.yyyy");
                                    File_Name = File_Name.Remove(File_Name.Length - 10);
                                    NameLngth = File_Name.Length;
                                    File_Name = File_Name + Recon_Date;
                                }
                            }
                            else if (File_Name.Contains("DDMMYYYY"))
                            {
                                if ((Recon_name == "Vietnam Billing") || (Recon_name == "Vietnam Smart link"))  // added on 23 03 2017 for Vietnam billing and Vietnam smart link for T-2 days
                                {
                                    if (File_Name.Contains("BILLING SETTLEMENT"))
                                    {
                                        File_Name = obj.GetSpecificFileName(Directory + "Input\\Emails\\");
                                    }
                                    else if (File_Name.Contains("ACQ SETTLEMENT"))
                                    {
                                        File_Name = obj.GetSpecificFileNameSmartLink(Directory + "Input\\Emails\\", "ACQ");
                                    }
                                    else if (File_Name.Contains("ISS SETTLEMENT"))
                                    {
                                        File_Name = obj.GetSpecificFileNameSmartLink(Directory + "Input\\Emails\\", "ISS");
                                    }
                                }
                                //Prakash
                                else if (Recon_name == "MasterCard ATM card Acquiring Chargeback Report")
                                {
                                    string datestr = string.Empty;
                                    System.DateTime date = System.DateTime.Today;
                                    if (date.DayOfWeek == DayOfWeek.Monday)
                                    {
                                        datestr = date.AddDays(-3).ToString("dd.MM.yyyy");
                                    }
                                    else
                                    {
                                        datestr = date.AddDays(-1).ToString("dd.MM.yyyy");
                                    }

                                    //Recon_Date = obj.Get_Recon_Date(conString, Country, "ddMMyyyy")
                                    File_Name = obj.GetSpecificFileName_MasterATM(Directory + "Input\\Master Card\\", datestr);
                                    //File_Name = obj.GetSpecificFileName_MasterATM(Directory + "Input\\Master Card\\", Recon_Date);
                                }
                                //Prakash
                                else if (Recon_name == "UAE ATM RECON")
                                {
                                    if (Formatted_File_Name.Contains("CBUAE_ACQ_MASTER_DCCY_BATCH_1"))  // T-2 File
                                    {
                                        Recon_Date = obj.Get_Recon_Date(conString, Country, "ddMMyyyy");
                                        File_Name = File_Name.Remove(File_Name.Length - 8);
                                        NameLngth = File_Name.Length;
                                        DateTime dt = DateTime.ParseExact(Recon_Date, "ddMMyyyy", CultureInfo.InvariantCulture);
                                        string _reconDate = dt.AddDays(-1).ToString("ddMMyyyy");
                                        File_Name = File_Name + _reconDate;
                                    }
                                    else if (Formatted_File_Name.Contains("CBUAE_ACQ_MASTER_DCCY_BATCH_2"))  // T-1 File
                                    {
                                        Recon_Date = obj.Get_Recon_Date(conString, Country, "ddMMyyyy");
                                        File_Name = File_Name.Remove(File_Name.Length - 8);
                                        NameLngth = File_Name.Length;
                                        File_Name = File_Name + Recon_Date;
                                    }
                                }
                                else if (Recon_name == "Indonesia - STS Report")
                                {
                                    if (File_Name.Contains("30600612012_"))
                                    {
                                        File_Name = obj.Get_IndonesiaSTS_(Directory + "Input\\" + Source_App + "_" + Country + "\\");
                                    }
                                    else
                                    {
                                        File_Name = obj.Get_IndonesiaSTS(Directory + "Input\\" + Source_App + "_" + Country + "\\");
                                    }
                                }

                                else if (Recon_name == "INDONESIA - LOCAL NOSTRO RECON REPORT")
                                {
                                    if (File_Name.Contains("10000122505"))
                                    {
                                        File_Name = obj.GetSpecificFileName_10000122505(Directory + "Input\\" + Source_App + "_" + Country + "\\");
                                    }
                                    else if (File_Name.Contains("10000122496"))
                                    {
                                        File_Name = obj.GetSpecificFileName_10000122496(Directory + "Input\\" + Source_App + "_" + Country + "\\");
                                    }
                                    else if (File_Name.Contains("10000122495"))
                                    {
                                        File_Name = obj.GetSpecificFileName_10000122495(Directory + "Input\\" + Source_App + "_" + Country + "\\");
                                    }
                                    else if (File_Name.Contains("10000122494"))
                                    {
                                        File_Name = obj.GetSpecificFileName_10000122494(Directory + "Input\\" + Source_App + "_" + Country + "\\");
                                    }
                                    else if (File_Name.Contains("10000122493"))
                                    {
                                        File_Name = obj.GetSpecificFileName_10000122493(Directory + "Input\\" + Source_App + "_" + Country + "\\");
                                    }
                                    else if (File_Name.Contains("10000122487"))
                                    {
                                        File_Name = obj.GetSpecificFileName_10000122487(Directory + "Input\\" + Source_App + "_" + Country + "\\");
                                    }
                                    else if (File_Name.Contains("10000122486"))
                                    {
                                        File_Name = obj.GetSpecificFileName_10000122486(Directory + "Input\\" + Source_App + "_" + Country + "\\");
                                    }
                                    else if (File_Name.Contains("10000122485"))
                                    {
                                        File_Name = obj.GetSpecificFileName_10000122485(Directory + "Input\\" + Source_App + "_" + Country + "\\");
                                    }
                                    else if (File_Name.Contains("10000122483"))
                                    {
                                        File_Name = obj.GetSpecificFileName_10000122483(Directory + "Input\\" + Source_App + "_" + Country + "\\");
                                    }
                                }
                                else if (Recon_name == "Indonesia - CSAC report")
                                {
                                    if (File_Name.Contains("CSA"))
                                    {
                                        File_Name = obj.CSA(Directory + "Input\\" + Source_App + "_" + Country + "\\");
                                    }
                                    else if (File_Name.Contains("152-288870-1421-100-800"))
                                    {
                                        File_Name = obj.Indo_1421(Directory + "Input\\" + Source_App + "_" + Country + "\\");
                                    }
                                    else if (File_Name.Contains("152-288870-1422-100-800"))
                                    {
                                        File_Name = obj.Indo_1422(Directory + "Input\\" + Source_App + "_" + Country + "\\");
                                    }
                                    else if (File_Name.Contains("152-288870-4151-100-800"))
                                    {
                                        File_Name = obj.Indo_4151(Directory + "Input\\" + Source_App + "_" + Country + "\\");
                                    }
                                }
                                else if (Recon_name == "PVB HONGKONG - MONTHLY")
                                {
                                    if (File_Name.Contains("Security trade Extract"))
                                    {
                                        File_Name = obj.GetSpecificMCD(Directory + "Input\\R2W_Hong Kong\\", "Security trade Extract");
                                    }
                                    else if (File_Name.Contains("Security_Position_PVB_HK_DDMMYYYY"))
                                    {
                                        File_Name = obj.GetSpecificMCD(Directory + "Input\\R2W_Hong Kong\\", "Security_Position_PVB_HK");
                                    }
                                }
                                else if (Recon_name == "PVB UNITED KINGDOM - MONTHLY")
                                {
                                    if (File_Name.Contains("Security trade Extract"))
                                    {
                                        File_Name = obj.GetSpecificMCD(Directory + "Input\\R2W_United Kingdom\\", "Security trade Extract");
                                    }
                                    else if (File_Name.Contains("Security_Position_PVB_UK"))
                                    {
                                        File_Name = obj.GetSpecificMCD(Directory + "Input\\R2W_United Kingdom\\", "Security_Position_PVB_UK");
                                    }
                                }
                                else if (Recon_name == "PVB SINGAPORE - MONTHLY")
                                {
                                    if (File_Name.Contains("Security trade Extract"))
                                    {
                                        File_Name = obj.GetSpecificMCD(Directory + "Input\\R2W_Singapore\\", "Security trade Extract");
                                    }
                                    else if (File_Name.Contains("Security_Position_PVB_SG"))
                                    {
                                        File_Name = obj.GetSpecificMCD(Directory + "Input\\R2W_Singapore\\", "Security_Position_PVB_SG");
                                    }
                                }
                                else if (Recon_name == "JORDON BONDS")
                                {
                                    if (File_Name.Contains("SS_JO_CUS_"))
                                    {
                                        File_Name = obj.GetSpecificJordonBonds(Directory + "Input\\Seccure_Jordan\\", "SS_JO_CUS_");
                                    }
                                    //else if (File_Name.Contains("Bonds Portfolio as of"))
                                    //{
                                    //    File_Name = obj.GetSpecificJordonBonds(Directory + "Input\\Emails\\", "Bonds Portfolio as of");
                                    //}
                                }
                                else
                                {
                                    Recon_Date = obj.Get_Recon_Date(conString, Country, "ddMMyyyy");
                                    File_Name = File_Name.Remove(File_Name.Length - 8);
                                    NameLngth = File_Name.Length;
                                    File_Name = File_Name + Recon_Date;
                                }

                            }
                            else if (File_Name.Contains("DDMMYY"))
                            {
                                if (Recon_name == "QATAR - BRANCH ATM")
                                {
                                    Recon_Date = obj.Get_Recon_Date(conString, Country, "ddMMyy");
                                    if (File_Name.Contains("eatran")) //eatran_DDMMYY00200X
                                    {
                                        File_Name = File_Name.Replace("DDMMYY", Recon_Date);
                                        File_Name = File_Name.Replace("X", "0");
                                    }
                                }
                                else if (Recon_name == "Kenya - VISA Electron DR.Card Suspense AC Recon KES USD GBP EUR YEN and Outstanding Report")
                                {
                                    if (File_Name.Contains("KES_EBBS"))
                                    {
                                        File_Name = obj.KESEBBS(Directory + "Input\\EBBS_Kenya\\");
                                    }
                                    else if (File_Name.Contains("GBP_EBBS"))
                                    {
                                        File_Name = obj.GBPEBBS(Directory + "Input\\EBBS_Kenya\\");
                                    }
                                    else if (File_Name.Contains("EUR_EBBS"))
                                    {
                                        File_Name = obj.EUREBBS(Directory + "Input\\EBBS_Kenya\\");
                                    }
                                    else if (File_Name.Contains("USD_EBBS"))
                                    {
                                        File_Name = obj.USDEBBS(Directory + "Input\\EBBS_Kenya\\");
                                    }
                                    else if (File_Name.Contains("YEN_EBBS"))
                                    {
                                        File_Name = obj.YENEBBS(Directory + "Input\\EBBS_Kenya\\");
                                    }
                                }
                                //else if (Recon_name == "Hong Kong – SCBNET")
                                //{
                                //    if (File_Name.Contains("MGDAQ_MHK_"))
                                //    {
                                //        Recon_Date = obj.Get_Recon_Date(conString, Country, "ddMMyy");
                                //        File_Name = obj.GetSpecificFileName_HKSCBNET1(Directory + "Input\\Shared Drive_Hong Kong\\", Recon_Date);
                                //    }
                                //    else if (File_Name.Contains("MGDIS_MHK_"))
                                //    {
                                //        Recon_Date = obj.Get_Recon_Date(conString, Country, "ddMMyy");
                                //        File_Name = obj.GetSpecificFileName_HKSCBNET2(Directory + "Input\\Shared Drive_Hong Kong\\", Recon_Date);
                                //    }
                                //    else
                                //    {
                                //        Recon_Date = obj.Get_Recon_Date(conString, Country, "ddMMyyyy");
                                //        File_Name = File_Name.Replace("DDMMYYYY", Recon_Date) + "." + File_Ext;
                                //    }
                                //}
                                else if (Recon_name == "CDSC Stock Recon")
                                {
                                    File_Name = obj.GetSpecificCDSC(Directory + "Input\\Emails\\");
                                }
                                else
                                {
                                    Recon_Date = obj.Get_Recon_Date(conString, Country, "ddMMyy");
                                    File_Name = File_Name.Remove(File_Name.Length - 6);
                                    NameLngth = File_Name.Length;
                                    File_Name = File_Name + Recon_Date;
                                }
                            }
                            else if (Recon_name == "CLS-MLS Recon")
                            {
                                if (File_Name.ToLower().Contains("loan limit"))
                                {
                                    File_Name = obj.LOANLIMIT(Directory + "Input\\" + Source_App + "_" + Country + "\\");
                                }
                                else if (File_Name.Contains("CTB500R1"))
                                {
                                    File_Name = obj.CTB500R1(Directory + "Input\\" + Source_App + "_" + Country + "\\");
                                }
                            }
                            else if (Recon_name == "HongKong Failed Trade Online")
                            {
                                File_Name = obj.GetSpecificMCD(Directory + "Input\\Murex_Hong Kong\\", "HK_Murex Failed Trade Draft");
                            }
                            else if (Recon_name == "Structured Finance Position Monthly")
                            {
                                if (File_Name.Contains("Structured_FIN_"))
                                {
                                    File_Name = obj.Get_MonthlyFileName(Directory + "Input\\OpicsPlus\\", "Structured_FIN_");
                                }
                                else
                                { }

                            }

                            if (Recon_name == "Srilanka Manual Recon") //Prakash-05/04/2018
                            {
                                if (File_Name.Contains("FIN800PA"))
                                {
                                    File_Name = "FIN800PA";
                                    //File_Name = obj.GetSpecificCCSIndia(Directory + "Input\\Shared Drive_Srilanka\\" + DateTime.Now.ToString("ddMMyyyy") + "\\", "FIN800PA");
                                }
                                else if (File_Name.Contains("FIN802PA"))
                                {
                                    File_Name = "FIN802PA";
                                    //File_Name = obj.GetSpecificCCSIndia(Directory + "Input\\Shared Drive_Srilanka\\" + DateTime.Now.ToString("ddMMyyyy") + "\\", "FIN802PA");
                                }
                                else if (File_Name.Contains("FIN802PB"))
                                {
                                    File_Name = "FIN802PB";
                                    //File_Name = obj.GetSpecificCCSIndia(Directory + "Input\\Shared Drive_Srilanka\\" + DateTime.Now.ToString("ddMMyyyy") + "\\", "FIN802PB");
                                }
                                else if (File_Name.Contains("FIN805PA"))
                                {
                                    File_Name = "FIN805PA";
                                    //File_Name = obj.GetSpecificCCSIndia(Directory + "Input\\Shared Drive_Srilanka\\" + DateTime.Now.ToString("ddMMyyyy") + "\\", "FIN805PA");
                                }
                                else if (File_Name.Contains("FIN805PB"))
                                {
                                    File_Name = "FIN805PB";
                                    //File_Name = obj.GetSpecificCCSIndia(Directory + "Input\\Shared Drive_Srilanka\\" + DateTime.Now.ToString("ddMMyyyy") + "\\", "FIN805PB");
                                }
                                else if (File_Name.Contains("FIN806PA"))
                                {
                                    File_Name = "FIN806PA";
                                    //File_Name = obj.GetSpecificCCSIndia(Directory + "Input\\Shared Drive_Srilanka\\" + DateTime.Now.ToString("ddMMyyyy") + "\\", "FIN806PA");
                                }
                            }
                            else if (File_Name.Contains("debit4"))
                            {
                                Recon_Date = obj.Get_Recon_Date(conString, Country, "ddMMyyyy");
                                DateTime myDate = DateTime.ParseExact(Recon_Date, "ddMMyyyy", System.Globalization.CultureInfo.InvariantCulture);

                                string temp_File_name = File_Name.Remove(File_Name.Length - 3);
                                int date1 = myDate.DayOfYear;
                                int date2 = myDate.DayOfYear;
                                int date3 = myDate.DayOfYear;

                                if (DateTime.Today.DayOfWeek == DayOfWeek.Tuesday)
                                {
                                    date1 = myDate.DayOfYear;
                                    date2 = myDate.AddDays(-1).DayOfYear;
                                    date3 = myDate.AddDays(-2).DayOfYear;

                                    string filename1 = temp_File_name + date1;
                                    string filename2 = temp_File_name + date2;
                                    string filename3 = temp_File_name + date3;

                                    File_Name = filename1;
                                }
                                else
                                {
                                    date1 = myDate.DayOfYear;
                                    string filename1 = temp_File_name + date1;
                                    File_Name = filename1;
                                }
                            }
                            else
                            {
                                Recon_Date = obj.Get_Recon_Date(conString, Country, "yyyyMMdd");//yyyyMMdd
                            }
                            //*******************************Monday Logics for FX files***************************************//
                            if ((Recon_name == "Zimbabwe FX Recon_Zimbabwe FXR Adjustments") || (Recon_name == "Kenya FX Recon_Kenya FXR Adjustments") ||
                                (Recon_name == "Uganda FX Recon_Uganda FXR Adjustments") || (Recon_name == "TANZANIA FX RECON_TANZANIA FXR Adjustments") ||
                                (Recon_name == "Botswana FX Recon_Botswana FXR Adjustments") || (Recon_name == "DIFC FX Recon - Advised-DIFC Adjustment Report") ||
                                (Recon_name == "UAE FX Recon - Advised_UAE Adjustment Report") || (Recon_name == "BAHRAIN DBU FX Recon - Advised-BAHRAIN DBU Adjustment Report") ||
                                (Recon_name == "BAHRAIN OBU FX Recon - Advised-BAHRAIN OBU Adjustment Report") || (Recon_name == "NETS & Cash card Topup Settlement") ||
                                (Recon_name == "BAHRAIN SWITCH RECON") || (Recon_name == "VIETNAM - CASH IN ATM"))
                            {
                                Recon_Date = obj.Get_Recon_Date(conString, Country, "MM.dd.yyyy");//5 days working
                                string fmt = CultureInfo.CurrentCulture.DateTimeFormat.ShortDatePattern;
                                string t2 = DateTime.ParseExact(Recon_Date, "MM.dd.yyyy", CultureInfo.InvariantCulture).ToString(fmt);
                                ts = (DateTime.Today.Date - Convert.ToDateTime(t2).Date);
                                if (ts.Days > 1)
                                {
                                    if ((Recon_name == "BAHRAIN SWITCH RECON"))
                                    {
                                        Recon_Date = Convert.ToDateTime(Recon_Date).ToString("ddMMyyyy");
                                        if (File_Name.Length != NameLngth)
                                        {
                                            File_Name = File_Name.Substring(0, NameLngth);
                                        }
                                    }
                                    else if ((Recon_name == "NETS & Cash card Topup Settlement"))
                                    {
                                        Recon_Date = obj.Get_Recon_Date(conString, Country, "ddMMyy");
                                        if (File_Name.Length != NameLngth)
                                        {
                                            File_Name = File_Name.Substring(0, NameLngth);
                                        }
                                    }
                                    else if ((Recon_name == "VIETNAM - CASH IN ATM"))
                                    {
                                        Recon_Date = Convert.ToDateTime(Recon_Date).ToString("ddMMyyyy");
                                        if (File_Name.Length != NameLngth)
                                        {
                                            File_Name = File_Name.Substring(0, NameLngth);
                                        }
                                    }
                                    else if ((Recon_name == "VIETNAM - RLS RECONS"))
                                    {
                                        Recon_Date = Convert.ToDateTime(Recon_Date).ToString("ddMMyyyy");
                                        if (File_Name.Length != NameLngth)
                                        {
                                            File_Name = File_Name.Substring(0, NameLngth);
                                        }
                                    }
                                    else
                                    {
                                        Recon_Date = obj.Get_Recon_Date(conString, Country, "MM.dd.yyyy");
                                    }
                                    File_Name = File_Name + Recon_Date;
                                }
                            }
                            //*******************************************************************************//
                            if (Source_App == "Master Card")
                            {
                                if (!string.IsNullOrEmpty(File_Ext))
                                    Soure_Path = Directory + "Input\\Master Card\\" + File_Name + "." + File_Ext;
                                else
                                    Soure_Path = Directory + "Input\\Master Card\\" + File_Name;
                            }
                            else if (Source_App.ToUpper() == "S2BX")
                            {
                                if (!string.IsNullOrEmpty(File_Ext))
                                    Soure_Path = Directory + "Input\\s2bx\\" + "\\" + File_Name + "." + File_Ext;
                                else
                                    Soure_Path = Directory + "Input\\s2bx\\" + "\\" + File_Name;
                            }
                            else if (Source_App == "OpicsPlus")
                            {
                                if (!string.IsNullOrEmpty(File_Ext))
                                    Soure_Path = Directory + "Input\\" + Source_App + "\\" + File_Name + "." + File_Ext;
                                else
                                    Soure_Path = Directory + "Input\\" + Source_App + "\\" + File_Name;
                                if (Recon_name == "Malaysia Failed Trade" || Recon_name == "India Failed Trade")
                                {
                                    if (!(File.Exists(Soure_Path)))
                                    {
                                        Soure_Path = Soure_Path.Replace(File_Name, File_Name + "_0");
                                    }
                                }

                            }
                            else if (Source_App == "OpicsPVB")
                            {
                                if (!string.IsNullOrEmpty(File_Ext))
                                    Soure_Path = Directory + "Input\\" + Source_App + "\\" + File_Name + "." + File_Ext;
                                else
                                    Soure_Path = Directory + "Input\\" + Source_App + "\\" + File_Name;
                                //if (Recon_name == "MXPB file")
                                //{
                                //    if (!(File.Exists(Soure_Path)))
                                //    {
                                //        Soure_Path = Soure_Path.Replace(File_Name, File_Name + "_0");
                                //    }
                                //}

                            }
                            else if (Source_App == "OpicsReg")
                            {
                                if (!string.IsNullOrEmpty(File_Ext))
                                    Soure_Path = Directory + "Input\\" + Source_App + "\\" + File_Name + "." + File_Ext;
                                else
                                    Soure_Path = Directory + "Input\\" + Source_App + "\\" + File_Name;
                                if (Recon_name == "Srilanka - Position Balancing")
                                {
                                    if (!(File.Exists(Soure_Path)))
                                    {
                                        Soure_Path = Soure_Path.Replace(File_Name, File_Name + "_0");
                                    }
                                }
                            }
                            else if (Source_App == "OpicsAfrica")
                            {
                                if (!string.IsNullOrEmpty(File_Ext))
                                    Soure_Path = Directory + "Input\\" + Source_App + "\\" + File_Name + "." + File_Ext;
                                else
                                    Soure_Path = Directory + "Input\\" + Source_App + "\\" + File_Name;
                            }
                            else if (Source_App == "PDF_Conversion")
                            {
                                if (!string.IsNullOrEmpty(File_Ext))
                                    Soure_Path = StrDirectory + "Input\\PDF_Conversion\\" + "\\" + File_Name + "." + File_Ext;
                                else
                                    Soure_Path = StrDirectory + "Input\\PDF_Conversion\\";
                            }
                            else if (Source_App != "Email")
                            {
                                if (!string.IsNullOrEmpty(File_Ext))
                                    Soure_Path = Directory + "Input\\" + Source_App + "_" + Country + "\\" + "\\" + File_Name + "." + File_Ext;
                                else
                                    Soure_Path = Directory + "Input\\" + Source_App + "_" + Country + "\\" + "\\" + File_Name;
                            }
                            else
                            {
                                if (!string.IsNullOrEmpty(File_Ext))
                                    Soure_Path = Directory + "Input\\Emails\\" + "\\" + File_Name + "." + File_Ext;
                                else
                                    Soure_Path = Directory + "Input\\Emails\\" + "\\" + File_Name;
                            }



                            Desti_Path = Directory + "Files_For_Formatting_Or_Non_Formatting\\" + Recon_name + "\\Non_Formatting\\";
                            Output_Path = Directory + "Output\\" + Recon_name + "\\";
                            string temp_Source_Path = Soure_Path.Remove(Soure_Path.LastIndexOf("\\"));

                            if (Convert.ToString(d[2]) == "RDR001D/RDRP01CB IN")
                            {
                                File_Name = "RDRP01CB IN";
                                Soure_Path = Directory + "Input\\" + Source_App + "_" + Country + "\\" + "\\" + File_Name + "." + File_Ext;
                            }
                            string FileName = Soure_Path.Remove(0, Soure_Path.LastIndexOf("\\")).Replace("\\", "").Trim();

                            if (Recon_name == "QATAR - SWITCH RECON")
                            {
                                FileName = obj.GetSpecificQatar(Directory + "Input\\Emails\\");
                                Soure_Path = Directory + "Input\\Emails\\" + "\\" + FileName + "." + File_Ext;
                            }

                            if (Recon_name == "Srilanka Manual Recon") //Prakash-05/04/2018
                            {
                                if (File_Name.Contains("FIN800PA") || File_Name.Contains("FIN802PA") || File_Name.Contains("FIN802PB") || File_Name.Contains("FIN805PA") || File_Name.Contains("FIN805PB") || File_Name.Contains("FIN806PA"))
                                {
                                    string temp_fileName = "";
                                    Soure_Path = Directory + "Input\\" + Source_App + "_" + Country + "\\";

                                    DirectoryInfo source = new DirectoryInfo(Soure_Path);
                                    DirectoryInfo target = new DirectoryInfo(Output_Path);
                                    foreach (DirectoryInfo dir in source.GetDirectories())
                                    {
                                        source = new DirectoryInfo(Soure_Path);
                                        target = new DirectoryInfo(Output_Path);

                                        target.CreateSubdirectory(dir.Name);

                                        target = new DirectoryInfo(target + dir.Name);
                                        source = new DirectoryInfo(source + dir.Name);

                                        foreach (FileInfo file in source.GetFiles("*" + File_Name + "*.*"))
                                        {
                                            File.Copy(file.FullName, Path.Combine(target.FullName, file.Name), true);
                                            temp_fileName = file.Name;
                                        }

                                        target = null;
                                        source = null;
                                    }

                                    Soure_Path = Directory + "Input\\" + Source_App + "_" + Country + "\\" + DateTime.Now.ToString("ddMMyyyy") + "\\" + temp_fileName;

                                }
                            }

                            if (File.Exists(Soure_Path))
                            {
                                if (string.IsNullOrEmpty(AutomationStatus) && AutomationStatus != "COMPLETED")
                                {
                                    cmd.Dispose();
                                    cmd = new SqlCommand("update ARC_Scope_BaseLine set IsProcessed = 1, AutomationStatus = 'COMPLETED' where Recon = '" + Recon_name + "' and Report_Source_File_Name = '" + File_Name + "'", con);
                                    con.Open();
                                    cmd.ExecuteNonQuery();
                                    con.Close();
                                }
                                File.Copy(Soure_Path, Desti_Path + FileName, true);
                                if (Formatted_File_Name.ToUpper() != "NA" && !string.IsNullOrEmpty(Formatted_File_Name.Trim()))
                                {

                                    db_Ext = System.IO.Path.GetExtension(Formatted_File_Name);
                                    Formatted_File_Name = Path.GetFileNameWithoutExtension(Formatted_File_Name);
                                    if (Formatted_File_Name.Contains("DD-MMM YYYY"))
                                    {
                                        Foramtted_Recon_Date = obj.Get_Recon_Date(conString, Country, "dd-MMM yyyy");
                                        Formatted_File_Name = Formatted_File_Name.Remove(Formatted_File_Name.Length - 11);
                                        Formatted_File_Name = Formatted_File_Name + Foramtted_Recon_Date;
                                    }
                                    else if (Formatted_File_Name.Contains("DD.MM.YYYY"))
                                    {
                                        if (FileName.Contains("AB-DETAIL_"))
                                        {
                                            //Foramtted_Recon_Date = obj.Get_Recon_DateForJETCO(Soure_Path);
                                            Foramtted_Recon_Date = DateTime.Now.ToString("dd.MM.yyyy");//Sankalp
                                        }
                                        else
                                        {
                                            Foramtted_Recon_Date = obj.Get_Recon_Date(conString, Country, "dd.MM.yyyy");
                                        }
                                        Formatted_File_Name = Formatted_File_Name.Remove(Formatted_File_Name.Length - 10);
                                        Formatted_File_Name = Formatted_File_Name + Foramtted_Recon_Date;
                                    }
                                    else if (Formatted_File_Name.Contains("DDMMYYYY"))
                                    {
                                        Recon_Date = obj.Get_Recon_Date(conString, Country, "ddMMyyyy");
                                        if (File_Name.Contains("BILLING SETTLEMENT"))
                                        {
                                            Foramtted_Recon_Date = obj.Get_Recon_Date(conString, Country, "ddMMyyyy"); ;
                                            Foramtted_Recon_Date = obj.GetSettlementDateFromExcel(Soure_Path, Foramtted_Recon_Date);
                                        }
                                        else if (File_Name.Contains("ACQ SETTLEMENT"))
                                        {
                                            Foramtted_Recon_Date = obj.Get_Recon_Date(conString, Country, "ddMMyyyy"); ;
                                            Foramtted_Recon_Date = obj.GetSettlementDateFromExcel(Soure_Path, Recon_Date);
                                        }
                                        else if (File_Name.Contains("ISS SETTLEMENT"))
                                        {
                                            Foramtted_Recon_Date = obj.Get_Recon_Date(conString, Country, "ddMMyyyy"); ;
                                            Foramtted_Recon_Date = obj.GetSettlementDateFromExcel(Soure_Path, Recon_Date);
                                        }
                                        else
                                        {
                                            //25-05 Kiran
                                            if (Recon_name == "UAE-SCBNET Settlement Suspense and CUP Settlement Suspense")
                                            {
                                                Foramtted_Recon_Date = obj.Get_Recon_Date(conString, Country, "ddMMyyyy"); ;
                                            }
                                            else if ((Recon_name == "NETS & Cash card Topup Settlement"))
                                            {
                                                Foramtted_Recon_Date = obj.Get_Recon_DateForNETS(Soure_Path);
                                            }
                                            else if ((Recon_name == "BAHRAIN SWITCH RECON"))
                                            {
                                                Foramtted_Recon_Date = obj.Get_Recon_DateForBahrain(Soure_Path);
                                            }

                                            else if ((Recon_name == "VIETNAM - CASH IN ATM"))
                                            {
                                                //21-07
                                                Foramtted_Recon_Date = obj.Get_Recon_DateForEASVN(Soure_Path);
                                                DateTime myDate = DateTime.ParseExact(Foramtted_Recon_Date, "ddMMyyyy", System.Globalization.CultureInfo.InvariantCulture);
                                                Foramtted_Recon_Date = myDate.ToString("ddMMyyyy");
                                            }

                                            else if (Recon_name == "VIETNAM - RLS RECONS")
                                            {
                                                if (File_Name.Contains("CGB570R1"))
                                                {
                                                    Foramtted_Recon_Date = obj.Get_Recon_DateForCGB570R1(Soure_Path);
                                                }
                                                else if (File_Name.Contains("DIRECT_DB_CR_TRANS_GENERATION_DIRECT_DB_CR_TRANS_GENERATION"))
                                                {
                                                    Foramtted_Recon_Date = obj.Get_Recon_DateForDIRECT_DB_CR_TRANS_GENERATION_DIRECT_DB_CR_TRANS_GENERATION(Soure_Path);
                                                }
                                                else if (File_Name.Contains("DIRECT DB-CR TRANS GENERATION DIRECT DB-CR TRANS GENERATION"))
                                                {
                                                    Foramtted_Recon_Date = obj.Get_Recon_DateForDIRECT_DB_CR_TRANS_GENERATION_DIRECT_DB_CR_TRANS_GENERATION(Soure_Path);
                                                }
                                            }
                                            else if (Recon_name == "Singapore - Holdings Reconciliation")
                                            {
                                                Foramtted_Recon_Date = System.DateTime.Today.ToString("ddMMyyyy");
                                            }
                                            else if (Recon_name == "CDSC Stock Recon")
                                            {
                                                Foramtted_Recon_Date = File_Name.Substring(7, 6);
                                                DateTime myDate = DateTime.ParseExact(Foramtted_Recon_Date, "ddMMyy", System.Globalization.CultureInfo.InvariantCulture);
                                                Foramtted_Recon_Date = myDate.ToString("ddMMyyyy");
                                            }
                                            else
                                            {
                                                Foramtted_Recon_Date = obj.Get_Recon_Date(conString, Country, "ddMMyyyy");
                                            }
                                        }
                                        Formatted_File_Name = Formatted_File_Name.Remove(Formatted_File_Name.Length - 8);
                                        Formatted_File_Name = Formatted_File_Name + Foramtted_Recon_Date;
                                    }
                                    else if (Formatted_File_Name.Contains("DDMMYY"))
                                    {
                                        if (Recon_name == "QATAR - BRANCH ATM")
                                        {
                                            Foramtted_Recon_Date = obj.Get_Recon_Date(conString, Country, "ddMMyy");
                                            if (Formatted_File_Name.Contains("eatran")) //eatran_DDMMYY00200X
                                            {
                                                Formatted_File_Name = Formatted_File_Name.Replace("DDMMYY", Recon_Date);
                                                Formatted_File_Name = Formatted_File_Name.Replace("X", "0");
                                            }
                                        }
                                        else if (Recon_name == "Kenya - VISA Electron DR.Card Suspense AC Recon KES USD GBP EUR YEN and Outstanding Report")
                                        {
                                            string sm = obj.Get_Recon_Date_Monthly(conString, Country, "ddMMyyyy");
                                            Formatted_File_Name = Formatted_File_Name.Substring(0, Formatted_File_Name.Length - 8) + sm + ".xlsx";
                                        }
                                        else
                                        {
                                            Foramtted_Recon_Date = obj.Get_Recon_Date(conString, Country, "ddMMyy");
                                            Formatted_File_Name = Formatted_File_Name.Remove(Formatted_File_Name.Length - 6);
                                            Formatted_File_Name = Formatted_File_Name + Foramtted_Recon_Date;
                                        }
                                    }
                                    else if (Formatted_File_Name.ToUpper().Contains("YYYYMMDD") || Formatted_File_Name.Contains("yyyyMMdd"))
                                    {
                                        if ((Recon_name == "Zimbabwe FX Recon_Zimbabwe FXR Adjustments") || (Recon_name == "Kenya FX Recon_Kenya FXR Adjustments") ||
                                            (Recon_name == "Uganda FX Recon_Uganda FXR Adjustments") || (Recon_name == "TANZANIA FX RECON_TANZANIA FXR Adjustments") ||
                                            (Recon_name == "Botswana FX Recon_Botswana FXR Adjustments") || (Recon_name == "DIFC FX Recon - Advised-DIFC Adjustment Report") ||
                                            (Recon_name == "UAE FX Recon - Advised_UAE Adjustment Report") || (Recon_name == "BAHRAIN DBU FX Recon - Advised-BAHRAIN DBU Adjustment Report") ||
                                            (Recon_name == "BAHRAIN OBU FX Recon - Advised-BAHRAIN OBU Adjustment Report") ||
                                            (Recon_name == "NETS & Cash card Topup Settlement") || (Recon_name == "BAHRAIN SWITCH RECON"))
                                        {
                                            if (ts.Days > 1)
                                            {
                                                if ((Recon_name == "NETS & Cash card Topup Settlement"))
                                                {
                                                    Foramtted_Recon_Date = obj.Get_Recon_DateForNETS(Soure_Path);
                                                }
                                                else if ((Recon_name == "BAHRAIN SWITCH RECON"))
                                                {
                                                    Foramtted_Recon_Date = obj.Get_Recon_DateForBahrain(Soure_Path);
                                                }
                                                else if ((Recon_name == "VIETNAM - CASH IN ATM"))
                                                {
                                                    Foramtted_Recon_Date = obj.Get_Recon_DateForEASVN(Soure_Path);
                                                    DateTime myDate = DateTime.ParseExact(Foramtted_Recon_Date, "yyMMdd", System.Globalization.CultureInfo.InvariantCulture);
                                                    Foramtted_Recon_Date = myDate.ToString("ddMMyyyy");
                                                }
                                                else if (File_Name.Contains("FXR08"))
                                                {
                                                    Foramtted_Recon_Date = obj.Get_Recon_DateForfxro8(Soure_Path);
                                                }
                                                else if (File_Name.Contains("FXRENTA"))
                                                {
                                                    Foramtted_Recon_Date = obj.Get_Recon_DateforFxtenta(Soure_Path);
                                                }
                                                else
                                                {
                                                    Foramtted_Recon_Date = obj.Get_Recon_Date(conString, Country, "yyyyMMdd");
                                                }
                                            }
                                            else
                                            {
                                                if ((Recon_name == "NETS & Cash card Topup Settlement"))
                                                {
                                                    Foramtted_Recon_Date = obj.Get_Recon_DateForNETS(Soure_Path);
                                                }
                                                else if ((Recon_name == "BAHRAIN SWITCH RECON"))
                                                {
                                                    Foramtted_Recon_Date = obj.Get_Recon_DateForBahrain(Soure_Path);
                                                }
                                                else if ((Recon_name == "VIETNAM - CASH IN ATM"))
                                                {
                                                    Foramtted_Recon_Date = obj.Get_Recon_DateForEASVN(Soure_Path);
                                                    DateTime myDate = DateTime.ParseExact(Foramtted_Recon_Date, "yyMMdd", System.Globalization.CultureInfo.InvariantCulture);

                                                    Foramtted_Recon_Date = myDate.ToString("ddMMyyyy");
                                                }
                                                else if (File_Name.Contains("CGB570R1"))
                                                {
                                                    Foramtted_Recon_Date = obj.Get_Recon_DateForCGB570R1(Soure_Path);
                                                }
                                                else if (File_Name.Contains("DIRECT_DB_CR_TRANS_GENERATION_DIRECT_DB_CR_TRANS_GENERATION"))
                                                {
                                                    Foramtted_Recon_Date = obj.Get_Recon_DateForDIRECT_DB_CR_TRANS_GENERATION_DIRECT_DB_CR_TRANS_GENERATION(Soure_Path);
                                                }

                                                else
                                                {
                                                    //*******************************This Code Added by Ragav***********************//
                                                    if (File_Name.Contains("FXR08"))
                                                    {
                                                        Foramtted_Recon_Date = obj.Get_Recon_DateForfxro8(Soure_Path);
                                                    }
                                                    else if (File_Name.Contains("FXRENTA"))
                                                    {
                                                        Foramtted_Recon_Date = obj.Get_Recon_DateforFxtenta(Soure_Path);
                                                    }
                                                    else
                                                    {
                                                        Foramtted_Recon_Date = obj.Get_Recon_Date(conString, Country, "yyyyMMdd"); //commented on 10may2017
                                                    }
                                                    //Foramtted_Recon_Date = obj.Get_Recon_Date(conString, Country, "yyyyMMdd");
                                                }
                                            }
                                        }
                                        else
                                        {
                                            if (Recon_name == "Angola Trade Recon" || Recon_name == "JORDAN IMEX REPORT" || Recon_name == "OMAN TRADE REPORT" ||
                                            Recon_name == "Qatar Trade Accounts" || Recon_name == "DIFC- TRADE IMEX" || Recon_name == "IRAQ Trade Recon" ||
                                            Recon_name == "UAE - TRADE IMEX" || Recon_name == "Bahrain Trade Accounts")
                                            {
                                                bool Is_Recon_Check = obj.Check_CTRL_GULF_FILE_DATE(Soure_Path, out Foramtted_Recon_Date);
                                                if (Is_Recon_Check == false)
                                                {
                                                    continue;
                                                }
                                            }
                                            else if (File_Name.Contains("FXR08"))
                                            {
                                                Foramtted_Recon_Date = obj.Get_Recon_DateForfxro8(Soure_Path);
                                            }
                                            else if (File_Name.Contains("FXRENTA"))
                                            {
                                                Foramtted_Recon_Date = obj.Get_Recon_DateforFxtenta(Soure_Path);
                                            }
                                            else
                                            {
                                                Foramtted_Recon_Date = obj.Get_Recon_Date(conString, Country, "yyyyMMdd");
                                            }
                                        }

                                        Formatted_File_Name = Formatted_File_Name.Remove(Formatted_File_Name.Length - 8);
                                        Formatted_File_Name = Formatted_File_Name + Foramtted_Recon_Date;

                                    }
                                    string temp_FileName = "";

                                    if (Formatted_File_Name.Contains("CBS_BH_I_TR_ISS") || Formatted_File_Name.Contains("CBS_BH_A_TR_ACQ"))
                                    {
                                        temp_FileName = Formatted_File_Name.Substring(0, Formatted_File_Name.Length - 9);
                                        temp_FileName = temp_FileName + Foramtted_Recon_Date + db_Ext;
                                        Formatted_File_Name = temp_FileName;
                                    }
                                    else if (Formatted_File_Name.Contains("CBINDONESIA_ABDETAIL"))
                                    {
                                        temp_FileName = Formatted_File_Name.Substring(0, Formatted_File_Name.Length - 10);
                                        temp_FileName = temp_FileName + DateTime.Now.ToString("dd.MM.yyyy") + db_Ext;//Sankalp
                                        //temp_FileName = temp_FileName + obj.Get_Recon_DateForJETCO(Soure_Path) + db_Ext; //Sankalp
                                        temp_FileName = temp_FileName.Replace(".", "").Substring(0, temp_FileName.Length - 6) + db_Ext;
                                    }
                                    //24-07 Kiran Multi days logic not written
                                    //else if (Formatted_File_Name.Contains("QATAR_SWITCH_"))
                                    //{
                                    //    temp_FileName = Formatted_File_Name.Substring(0, Formatted_File_Name.Length - 8);
                                    //    Foramtted_Recon_Date = obj.Get_Qatar_Date(Soure_Path);
                                    //    temp_FileName = temp_FileName + Foramtted_Recon_Date + db_Ext
                                    //}
                                    else if (Formatted_File_Name.Contains("STOCK_SEDOL_"))
                                    {
                                        temp_FileName = Formatted_File_Name.Substring(0, Formatted_File_Name.Length - 8);
                                        Foramtted_Recon_Date = DateTime.Today.ToString("yyyyMMdd");
                                        temp_FileName = temp_FileName + Foramtted_Recon_Date + db_Ext;

                                    }
                                    else if (Formatted_File_Name.Contains("SCB_VN_ATM_DATED_"))
                                    {
                                        if (DateTime.Today.DayOfWeek.ToString() != "Tuesday")
                                        {
                                            temp_FileName = Formatted_File_Name.Substring(0, Formatted_File_Name.LastIndexOf("_"));
                                            temp_FileName = temp_FileName + "_" + Foramtted_Recon_Date + db_Ext;
                                            File.Copy(Soure_Path, Output_Path + temp_FileName, true);
                                        }
                                        else
                                        {
                                            string path1 = "";
                                            string path2 = "";
                                            string path3 = "";
                                            string Date = "";
                                            int hol = obj.Get_HolidaysTotal(conString, Country, "MM/dd/yyyy");
                                            obj.GetSpecificFileNameVietnamATM(Directory + "Input\\Emails", out path1, out path2, out path3);
                                            DateTime myDate = DateTime.ParseExact(DateTime.Today.ToString("ddMMyyyy"), "ddMMyyyy", System.Globalization.CultureInfo.InvariantCulture);
                                            Date = myDate.AddDays(-1).ToString("ddMMyyyy");
                                            obj.VIETNAM_CashINATM_Formatting(path1, Date, Output_Path, hol, Formatted_File_Name, db_Ext);
                                            Date = myDate.AddDays(-2).ToString("ddMMyyyy");
                                            obj.VIETNAM_CashINATM_Formatting(path2, Date, Output_Path, hol, Formatted_File_Name, db_Ext);
                                            Date = myDate.AddDays(-3).ToString("ddMMyyyy");
                                            obj.VIETNAM_CashINATM_Formatting(path3, Date, Output_Path, hol, Formatted_File_Name, db_Ext);
                                            Non_For_Counter++;
                                        }
                                    }
                                    //Prakash
                                    else if (Recon_name == "MasterCard ATM card Acquiring Chargeback Report" && Formatted_File_Name.Contains("CA_AFRICA_MCS_ACQ"))
                                    {
                                        if (DateTime.Today.DayOfWeek != DayOfWeek.Tuesday)
                                        {
                                            string date1 = string.Empty;
                                            System.DateTime date = System.DateTime.Today;
                                            if (date.DayOfWeek == DayOfWeek.Monday)
                                            {
                                                date1 = date.AddDays(-3).ToString("ddMMyyyy");
                                            }
                                            else
                                            {
                                                date1 = date.AddDays(-1).ToString("ddMMyyyy");
                                            }

                                            Formatted_File_Name = Formatted_File_Name.Substring(0, Formatted_File_Name.LastIndexOf("_"));
                                            Formatted_File_Name = Formatted_File_Name + "_" + date1 + db_Ext;

                                            if (!string.IsNullOrEmpty(Soure_Path) && File.Exists(Soure_Path))
                                            {
                                                File.Copy(Soure_Path, Output_Path + Formatted_File_Name, true);
                                                Non_For_Counter++;
                                            }

                                            //Old Logic
                                            //temp_FileName = Formatted_File_Name.Substring(0, Formatted_File_Name.LastIndexOf("_"));
                                            //temp_FileName = temp_FileName + "_" + Foramtted_Recon_Date + db_Ext;
                                            //File.Copy(Soure_Path, Output_Path + temp_FileName, true);
                                        }
                                        else
                                        {
                                            string path1, path2, path3 = "";
                                            string Date1, Date2, Date3 = "";
                                            obj.GetSpecificFileNameMasterATM(Directory + "Input\\Master Card\\", out path1, out path2, out path3);

                                            System.DateTime myDate = System.DateTime.Today;
                                            Date1 = myDate.AddDays(-1).ToString("ddMMyyyy");
                                            Date2 = myDate.AddDays(-2).ToString("ddMMyyyy");
                                            Date3 = myDate.AddDays(-3).ToString("ddMMyyyy");

                                            if (!string.IsNullOrEmpty(path1) && File.Exists(path1))
                                            {
                                                File.Copy(path1, Output_Path + Formatted_File_Name.Substring(0, Formatted_File_Name.Length - 8) + Date1 + db_Ext, true);
                                            }

                                            if (!string.IsNullOrEmpty(path2) && File.Exists(path2))
                                            {
                                                File.Copy(path2, Output_Path + Formatted_File_Name.Substring(0, Formatted_File_Name.Length - 8) + Date2 + db_Ext, true);
                                            }

                                            if (!string.IsNullOrEmpty(path3) && File.Exists(path3))
                                            {
                                                File.Copy(path3, Output_Path + Formatted_File_Name.Substring(0, Formatted_File_Name.Length - 8) + Date3 + db_Ext, true);
                                            }

                                            Non_For_Counter++;

                                            //temp_FileName = Formatted_File_Name.Substring(0, Formatted_File_Name.LastIndexOf("_"));
                                            //temp_FileName = temp_FileName + "_" + Date1 + db_Ext;
                                        }
                                    }
                                    else if (Formatted_File_Name.Contains("VISA_ATM_KE"))
                                    {

                                        if (DateTime.Today.DayOfWeek == DayOfWeek.Tuesday)
                                        {
                                            temp_FileName = Formatted_File_Name.Substring(0, Formatted_File_Name.LastIndexOf("_"));
                                            temp_FileName = temp_FileName + "_" + Foramtted_Recon_Date + db_Ext;

                                            DateTime myDate = DateTime.ParseExact(Recon_Date, "ddMMyyyy", System.Globalization.CultureInfo.InvariantCulture);
                                            int date1 = myDate.DayOfYear;
                                            int date2 = myDate.AddDays(-1).DayOfYear;
                                            int date3 = myDate.AddDays(-2).DayOfYear;

                                            string filename1 = Soure_Path.Substring(0, Soure_Path.Length - 3) + date1;
                                            string filename2 = Soure_Path.Substring(0, Soure_Path.Length - 3) + date2;
                                            string filename3 = Soure_Path.Substring(0, Soure_Path.Length - 3) + date3;
                                            string temp_FileName1 = Formatted_File_Name.Substring(0, Formatted_File_Name.LastIndexOf("_")) + "_" + myDate.ToString("yyyyMMdd") + db_Ext;
                                            string temp_FileName2 = Formatted_File_Name.Substring(0, Formatted_File_Name.LastIndexOf("_")) + "_" + myDate.AddDays(-1).ToString("yyyyMMdd") + db_Ext;
                                            string temp_FileName3 = Formatted_File_Name.Substring(0, Formatted_File_Name.LastIndexOf("_")) + "_" + myDate.AddDays(-2).ToString("yyyyMMdd") + db_Ext;


                                            bool isValid1 = obj.Get_Recon_Date_Kenya_VISA(filename1, date1);
                                            bool isValid2 = obj.Get_Recon_Date_Kenya_VISA(filename2, date2);
                                            bool isValid3 = obj.Get_Recon_Date_Kenya_VISA(filename3, date3);

                                            if (isValid1)
                                                File.Copy(filename1, Output_Path + temp_FileName1, true);

                                            if (isValid2)
                                                File.Copy(filename2, Output_Path + temp_FileName2, true);

                                            if (isValid3)
                                                File.Copy(filename3, Output_Path + temp_FileName3, true);

                                        }
                                        else
                                        {
                                            temp_FileName = Formatted_File_Name.Substring(0, Formatted_File_Name.LastIndexOf("_"));
                                            temp_FileName = temp_FileName + "_" + Foramtted_Recon_Date + db_Ext;

                                            DateTime myDate = DateTime.ParseExact(Recon_Date, "ddMMyyyy", System.Globalization.CultureInfo.InvariantCulture);
                                            int date1 = myDate.DayOfYear;

                                            bool isValid1 = obj.Get_Recon_Date_Kenya_VISA(Soure_Path, date1);

                                            if (isValid1)
                                            {
                                                File.Copy(Soure_Path, Output_Path + temp_FileName, true);
                                            }


                                        }
                                    }
                                    //Prakash
                                    else if (Formatted_File_Name.Contains("QATAR_SWITCH_"))
                                    {
                                        if (DateTime.Today.DayOfWeek.ToString() != "Monday")
                                        {
                                            temp_FileName = Formatted_File_Name.Substring(0, Formatted_File_Name.LastIndexOf("_"));
                                            temp_FileName = temp_FileName + "_" + Foramtted_Recon_Date + db_Ext;
                                            File.Copy(Soure_Path, Output_Path + temp_FileName, true);
                                        }
                                        else
                                        {
                                            string path1 = "";
                                            string path2 = "";
                                            string path3 = "";
                                            string Date = "";
                                            int hol = obj.Get_HolidaysTotal(conString, Country, "MM/dd/yyyy");
                                            obj.GetSpecificFileNameQatarswitch(Directory + "Input\\Emails", out path1, out path2, out path3);
                                            DateTime myDate = DateTime.ParseExact(DateTime.Today.ToString("yyyyMMdd"), "yyyyMMdd", System.Globalization.CultureInfo.InvariantCulture);
                                            Date = myDate.AddDays(-1).ToString("yyyyMMdd");
                                            obj.VIETNAM_CashINATM_Formatting(path1, Date, Output_Path, hol, Formatted_File_Name, db_Ext);
                                            Date = myDate.AddDays(-2).ToString("yyyyMMdd");
                                            obj.VIETNAM_CashINATM_Formatting(path2, Date, Output_Path, hol, Formatted_File_Name, db_Ext);
                                            Date = myDate.AddDays(-3).ToString("yyyyMMdd");
                                            obj.VIETNAM_CashINATM_Formatting(path3, Date, Output_Path, hol, Formatted_File_Name, db_Ext);
                                        }
                                    }
                                    else if (Recon_name == "QATAR - BRANCH ATM")
                                    {
                                        if (Formatted_File_Name.Contains("eatran"))
                                        { temp_FileName = Formatted_File_Name; }
                                    }
                                    //else if (Recon_name == "BAHRAIN - Branch ATM Recon")
                                    //{
                                    //    if (Formatted_File_Name.Contains("SBHA"))
                                    //    {
                                    //        temp_FileName = Formatted_File_Name;
                                    //    }
                                    //}
                                    else if (Recon_name == "UAE ATM RECON")
                                    {
                                        if (Formatted_File_Name.Contains("CBUAE_ACQ_MASTER_DCCY_BATCH_1") || Formatted_File_Name.Contains("CBUAE_ACQ_MASTER_DCCY_BATCH_2"))
                                        {
                                            temp_FileName = Formatted_File_Name + db_Ext;//modified by srinath -29Jun
                                        }
                                    }
                                    else if (Recon_name == "Philippines PSGL CB NOSTRO ((Manual recon - Local Nostro - CB - Statement Vs PSGL)")
                                    {
                                        if (Formatted_File_Name.Contains("881331101") || Formatted_File_Name.Contains("881331102") || Formatted_File_Name.Contains("1065009508") || Formatted_File_Name.Contains("1065020013") || Formatted_File_Name.Contains("1065020048") || Formatted_File_Name.Contains("1065020154") || Formatted_File_Name.Contains("1067668002") || Formatted_File_Name.Contains("20093354009"))
                                        {
                                            temp_FileName = Formatted_File_Name + db_Ext;//modified by srinath -29Jun
                                        }
                                    }
                                    else if (Recon_name == "Indonesia - STS Report")
                                    {
                                        if (Formatted_File_Name.Contains("30600612012_"))
                                        {
                                            temp_FileName = Formatted_File_Name.Substring(0, Formatted_File_Name.LastIndexOf("_"));
                                            temp_FileName = temp_FileName + "_" + Foramtted_Recon_Date + db_Ext;
                                        }
                                        else
                                        {
                                            temp_FileName = Formatted_File_Name + db_Ext;//modified by srinath -29Jun
                                        }
                                    }
                                    else if (Recon_name == "Indonesia - CSAC report" || Recon_name == "Visa Base II – Trial Balance Preparation – TOTAL" || Recon_name == "Issuer - EBBS Internal Account Reconciliation ATM / POS" || Recon_name == "Qatar STS Holding and Cashiers Order" || Recon_name == "India CCS Suspense")
                                    {
                                        temp_FileName = Formatted_File_Name + db_Ext;//modified by srinath -29Jun
                                    }
                                    //Prakash-10/08/2017
                                    else if (Recon_name == "Srilanka Manual Recon") //Prakash-05/04/2018
                                    {
                                        if (File_Name.Contains("FIN800PA") || File_Name.Contains("FIN802PA") || File_Name.Contains("FIN802PB") ||
                                            File_Name.Contains("FIN805PA") || File_Name.Contains("FIN805PB") || File_Name.Contains("FIN806PA"))
                                        {
                                            List<string> Rest_All_Files = null;
                                            File_Name = File_Name.Replace("X", "");
                                            Rest_All_Files = System.IO.Directory.GetFiles(temp_Source_Path, "*" + File_Name + "*.*").OrderBy(x => new FileInfo(x).CreationTime).ToList();

                                            foreach (string filePath in Rest_All_Files)
                                            {
                                                string F_Name = Path.GetFileName(filePath);

                                                if (!File.Exists(Output_Path + F_Name))
                                                {
                                                    File.Copy(filePath, Output_Path + F_Name, true);
                                                }
                                            }
                                            Non_For_Counter++;
                                        }
                                        else
                                        {
                                            string SMR_FileName = Formatted_File_Name + db_Ext;

                                            if (!File.Exists(Output_Path + SMR_FileName))
                                            {
                                                File.Copy(Soure_Path, Output_Path + SMR_FileName, true);
                                                Non_For_Counter++;
                                            }
                                        }
                                    }
                                    else if (Recon_name == "Merchant Deposit Ac-Mobile Topup")
                                    {
                                        List<string> Rest_All_Files = null;
                                        if ((Recon_name == "Merchant Deposit Ac-Mobile Topup"))
                                        {
                                            File_Name = File_Name.Remove(File_Name.Length - 8);
                                            Rest_All_Files = System.IO.Directory.GetFiles(temp_Source_Path, "*" + File_Name + "*.*").OrderBy(x => new FileInfo(x).CreationTime).ToList();
                                        }

                                        foreach (string filePath in Rest_All_Files)
                                        {
                                            string F_Name = Path.GetFileName(filePath);

                                            if (!File.Exists(Output_Path + F_Name))
                                            {
                                                File.Copy(filePath, Output_Path + F_Name, true);
                                            }

                                        }
                                        Non_For_Counter++;
                                    }
                                    //31-08
                                    else if (Recon_name == "Issuer - EBBS Internal Account Reconciliation ATM" || Recon_name == "MXG - sabre" || Recon_name == "288824 RECON REPORT" || Recon_name == "Sophis BTB")
                                    {
                                        temp_FileName = Formatted_File_Name + db_Ext;
                                    }
                                    else if (Recon_name == "Opics ZNOR-ZIRC" || Recon_name == "TRBC" || Recon_name == "OPICS Sentry Position Daily" || Recon_name == "Structured Finance Position Monthly")
                                    {
                                        if (File_Name.Contains("Structured_FIN_") && Recon_name == "Structured Finance Position Monthly")
                                        {
                                            File_Name = obj.Get_MonthlyFileName(Directory + "Input\\OpicsPlus\\", "Structured_FIN_");
                                            temp_FileName = File_Name + db_Ext;
                                        }
                                        else
                                        {
                                            temp_FileName = Formatted_File_Name + db_Ext;
                                        }
                                    }
                                    else if (Recon_name == "India Failed Trade" && Source_App == "OpicsPlus")
                                    {
                                        Foramtted_Recon_Date = obj.Get_Recon_Date(conString, Country, "dd-MMM yyyy");
                                        temp_FileName = Formatted_File_Name + db_Ext.ToLower();
                                        temp_FileName = temp_FileName.Replace("DD", Foramtted_Recon_Date.Substring(0, 2));
                                    }
                                    else if (Recon_name == "Srilanka - Position Balancing" || Recon_name == "Malaysia Failed Trade")
                                    {
                                        Foramtted_Recon_Date = obj.Get_Recon_Date(conString, Country, "ddMMyyyy");
                                        temp_FileName = Formatted_File_Name + db_Ext.ToLower();
                                        temp_FileName = temp_FileName.Replace("DDMMYYYY", Foramtted_Recon_Date);
                                    }
                                    else if (Recon_name == "India Failed Trade" && Source_App == "PSGL")
                                    {
                                        Foramtted_Recon_Date = obj.Get_Recon_Date(conString, Country, "ddMMyyyy");
                                        temp_FileName = Formatted_File_Name + db_Ext.ToLower();
                                        temp_FileName = temp_FileName.Replace("DDMMYYYY", Foramtted_Recon_Date);
                                    }
                                    else if (Recon_name == "Botswana-card suspense - inter reject - disputed recon")
                                    {
                                        Foramtted_Recon_Date = obj.Get_Recon_Date(conString, Country, "yyddMM");
                                        temp_FileName = Formatted_File_Name + db_Ext.ToLower();
                                        temp_FileName = temp_FileName.Replace("YYDDMM", Foramtted_Recon_Date);
                                    }
                                    else if (Recon_name == "Philippines - BSP DDA RECON (Manual recon - CB recon eBBS Vs. CB statements)")
                                    {
                                        Foramtted_Recon_Date = obj.Get_Recon_Date(conString, Country, "dd.MM.yyyy");
                                        temp_FileName = Formatted_File_Name + db_Ext.ToLower();
                                        temp_FileName = temp_FileName.Replace("DD.MM.YYYY", Foramtted_Recon_Date);
                                    }
                                    else if (Recon_name == "Malaysia Other AA Codes")
                                    {
                                        temp_FileName = Formatted_File_Name; //Changed this-Prakash-> temp_FileName = temp_FileName + "_" + Recon_Date + "." + File_Ext; 
                                    }
                                    else if (Recon_name == "CDSC Stock Recon")
                                    {
                                        temp_FileName = Formatted_File_Name + db_Ext; //Changed this-Prakash-> temp_FileName = temp_FileName + "_" + Recon_Date + "." + File_Ext; 
                                    }
                                    //else if (Recon_name == "JORDON BONDS")
                                    //{
                                    //    temp_FileName = obj.GetSpecificFileNamePortfolioBonds(Directory + "Input\\Emails\\") + ".xlsx";//Changed this-Prakash-> temp_FileName = temp_FileName + "_" + Recon_Date + "." + File_Ext; 
                                    //}
                                    else if (Recon_name == "Kenya - VISA Electron DR.Card Suspense AC Recon KES USD GBP EUR YEN and Outstanding Report")
                                    {
                                        if (File_Name.Contains("debit2"))
                                        {
                                            temp_FileName = obj.KVEDeb2(Directory + "Input\\Shared Drive_Kenya\\");
                                        }
                                        else if (File_Name.Contains("debit3"))
                                        {
                                            temp_FileName = obj.KVEDeb3(Directory + "Input\\Shared Drive_Kenya\\");
                                        }
                                        else if (File_Name.Contains("EP210D"))
                                        {
                                            temp_FileName = obj.KVEEP210(Directory + "Input\\Shared Drive_Kenya\\") + ".TXT";
                                        }
                                        else if (File_Name.Contains("EP747"))
                                        {
                                            temp_FileName = obj.KVEEP747(Directory + "Input\\Shared Drive_Kenya\\") + ".TXT";
                                        }
                                        else if (File_Name.Contains("KES_EBBS"))// || File_Name.Contains("GBP_EBBS") || File_Name.Contains("GBP_EBBS") || File_Name.Contains("USD_EBBS") || File_Name.Contains("YEN_EBBS"))
                                        {
                                            temp_FileName = obj.KESEBBS(Directory + "Input\\EBBS_Kenya\\") + ".xlsx";
                                        }
                                        else if (File_Name.Contains("GBP_EBBS"))
                                        {
                                            temp_FileName = obj.GBPEBBS(Directory + "Input\\EBBS_Kenya\\") + ".xlsx";
                                        }
                                        else if (File_Name.Contains("EUR_EBBS"))
                                        {
                                            temp_FileName = obj.EUREBBS(Directory + "Input\\EBBS_Kenya\\") + ".xlsx";
                                        }
                                        else if (File_Name.Contains("USD_EBBS"))
                                        {
                                            temp_FileName = obj.USDEBBS(Directory + "Input\\EBBS_Kenya\\") + ".xlsx";
                                        }
                                        else if (File_Name.Contains("YEN_EBBS"))
                                        {
                                            temp_FileName = obj.YENEBBS(Directory + "Input\\EBBS_Kenya\\") + ".xlsx";
                                        }
                                    }
                                    else if (Recon_name == "PVB UNITED KINGDOM - MONTHLY" || Recon_name == "PVB SINGAPORE - MONTHLY" || Recon_name == "PVB HONGKONG - MONTHLY")
                                    {
                                        string s = File_Name.Substring(File_Name.Length - 8, 8).Trim();
                                        DateTime myDate = DateTime.ParseExact(s, "ddMMyyyy", System.Globalization.CultureInfo.InvariantCulture);
                                        temp_FileName = Formatted_File_Name.Replace("MM_YY", myDate.ToString("MM_yy")) + db_Ext;
                                    }
                                    else if (Recon_name == "HongKong Failed Trade Online")
                                    {
                                        Formatted_File_Name = File_Name + db_Ext;
                                        temp_FileName = File_Name + db_Ext;
                                    }
                                    else
                                    {
                                        temp_FileName = Formatted_File_Name.Substring(0, Formatted_File_Name.LastIndexOf("_"));
                                        temp_FileName = temp_FileName + "_" + Foramtted_Recon_Date + db_Ext; //Changed this-Prakash-> temp_FileName = temp_FileName + "_" + Recon_Date + "." + File_Ext; 
                                    }
                                    if (!string.IsNullOrEmpty(temp_FileName))
                                    {
                                        File.Copy(Soure_Path, Output_Path + temp_FileName, true);
                                        Non_For_Counter++;
                                    }
                                }
                                else
                                {
                                    File.Copy(Soure_Path, Output_Path + FileName, true);
                                    Non_For_Counter++;
                                }
                            }
                            //*******************************Multiple file download on Monday Logics for FX files***************************************//
                            if (ts.Days > 1 && ((Recon_name == "Zimbabwe FX Recon_Zimbabwe FXR Adjustments") || (Recon_name == "Kenya FX Recon_Kenya FXR Adjustments") || (Recon_name == "Uganda FX Recon_Uganda FXR Adjustments") || (Recon_name == "TANZANIA FX RECON_TANZANIA FXR Adjustments") || (Recon_name == "DIFC FX Recon - Advised-DIFC Adjustment Report") || (Recon_name == "UAE FX Recon - Advised_UAE Adjustment Report") || (Recon_name == "BAHRAIN DBU FX Recon - Advised-BAHRAIN DBU Adjustment Report") || (Recon_name == "BAHRAIN OBU FX Recon - Advised-BAHRAIN OBU Adjustment Report") || (Recon_name == "Botswana FX Recon_Botswana FXR Adjustments") || (Recon_name == "NETS & Cash card Topup Settlement") || (Recon_name == "BAHRAIN SWITCH RECON")))
                            {
                                List<string> Rest_All_Files = null;
                                if ((Recon_name == "BAHRAIN SWITCH RECON"))
                                {
                                    Recon_Date = obj.Get_Recon_Date(conString, Country, "MM.dd.yyyy");
                                    File_Name = File_Name.Remove(File_Name.Length - 9);
                                    Rest_All_Files = System.IO.Directory.GetFiles(temp_Source_Path, "*" + File_Name + "*.*").OrderBy(x => new FileInfo(x).CreationTime).ToList();
                                }
                                else if ((Recon_name == "NETS & Cash card Topup Settlement"))
                                {
                                    Recon_Date = obj.Get_Recon_Date(conString, Country, "MM.dd.yyyy");
                                    File_Name = File_Name.Remove(File_Name.Length - 6);
                                    Rest_All_Files = System.IO.Directory.GetFiles(temp_Source_Path, "*" + File_Name + "*.*").OrderBy(x => new FileInfo(x).CreationTime).ToList();
                                }
                                else if ((Recon_name == "VIETNAM - CASH IN ATM"))
                                {
                                    Recon_Date = obj.Get_Recon_Date(conString, Country, "MM.dd.yyyy");
                                    File_Name = File_Name.Remove(File_Name.Length - 8);
                                    Rest_All_Files = System.IO.Directory.GetFiles(temp_Source_Path, "*" + File_Name + "*.*").OrderBy(x => new FileInfo(x).CreationTime).ToList();
                                }
                                else
                                {
                                    Rest_All_Files = System.IO.Directory.GetFiles(temp_Source_Path, "*" + Convert.ToString(d[2]) + "*.*").OrderBy(x => new FileInfo(x).CreationTime).ToList();
                                }
                                foreach (string filePath in Rest_All_Files)
                                {
                                    string inputName = Formatted_File_Name.Substring(0, Formatted_File_Name.LastIndexOf("_"));
                                    string dt_name = string.Empty;
                                    inputName = inputName + "_" + Recon_Date + db_Ext;
                                    if (File.Exists(filePath))
                                    {
                                        if (!File.Exists(Desti_Path + inputName))
                                        {
                                            File.Copy(filePath, Desti_Path + inputName, true);
                                        }

                                        if (Formatted_File_Name.ToUpper() != "NA" && !string.IsNullOrEmpty(Formatted_File_Name.Trim()))
                                        {

                                            string F_Name = Path.GetFileName(filePath);
                                            if (F_Name.ToLower().Contains("scbct") || F_Name.ToLower().Contains("scbpt"))
                                            {
                                                dt_name = obj.Get_Recon_DateForNETS(filePath);
                                                Formatted_File_Name = Path.GetFileNameWithoutExtension(Formatted_File_Name);
                                                Formatted_File_Name = Formatted_File_Name.Remove(Formatted_File_Name.Length - 8);
                                                Formatted_File_Name = Formatted_File_Name + dt_name + db_Ext;

                                            }
                                            else if (F_Name.Contains("Acquirer report") || F_Name.Contains("Issuer report"))
                                            {
                                                dt_name = obj.Get_Recon_DateForBahrain(filePath);
                                                Formatted_File_Name = Path.GetFileNameWithoutExtension(Formatted_File_Name);
                                                Formatted_File_Name = Formatted_File_Name.Substring(0, Formatted_File_Name.Length - 8);
                                                Formatted_File_Name = Formatted_File_Name + dt_name + db_Ext;
                                            }
                                            else if (F_Name.Contains("EASVN"))
                                            {
                                                dt_name = obj.Get_Recon_DateForEASVN(filePath);
                                                //dt_name = Convert.ToDateTime(dt_name).ToString("ddMMyyyy");
                                                Formatted_File_Name = Path.GetFileNameWithoutExtension(Formatted_File_Name);
                                                Formatted_File_Name = Formatted_File_Name.Remove(Formatted_File_Name.Length - 8);
                                                Formatted_File_Name = Formatted_File_Name + dt_name + db_Ext;
                                            }
                                            else if (F_Name.Contains("CGB570R1") || F_Name.Contains("DIRECT_DB_CR_TRANS_GENERATION_DIRECT_DB_CR_TRANS_GENERATION"))
                                            {
                                                dt_name = obj.Get_Recon_DateForEASVN(filePath);
                                                //dt_name = Convert.ToDateTime(dt_name).ToString("ddMMyyyy");
                                                Formatted_File_Name = Path.GetFileNameWithoutExtension(Formatted_File_Name);
                                                Formatted_File_Name = Formatted_File_Name.Remove(Formatted_File_Name.Length - 8);
                                                Formatted_File_Name = Formatted_File_Name + dt_name + db_Ext;
                                            }
                                            else if ((Recon_name == "Zimbabwe FX Recon_Zimbabwe FXR Adjustments") || (Recon_name == "Kenya FX Recon_Kenya FXR Adjustments") || (Recon_name == "Uganda FX Recon_Uganda FXR Adjustments") || (Recon_name == "TANZANIA FX RECON_TANZANIA FXR Adjustments") || (Recon_name == "Botswana FX Recon_Botswana FXR Adjustments") || (Recon_name == "DIFC FX Recon - Advised-DIFC Adjustment Report") || (Recon_name == "UAE FX Recon - Advised_UAE Adjustment Report") || (Recon_name == "BAHRAIN DBU FX Recon - Advised-BAHRAIN DBU Adjustment Report") || (Recon_name == "BAHRAIN OBU FX Recon - Advised-BAHRAIN OBU Adjustment Report"))
                                            {
                                                Formatted_File_Name = Path.GetFileNameWithoutExtension(Formatted_File_Name);
                                                dt_name = Path.GetFileNameWithoutExtension(filePath);
                                                if (dt_name == "s2bx")
                                                {
                                                    continue;
                                                }
                                                dt_name = Path.GetFileNameWithoutExtension(filePath);
                                                dt_name = dt_name.Substring(dt_name.Length - 10);
                                                DateTime Dte = DateTime.ParseExact(dt_name, "MM.dd.yyyy", System.Globalization.CultureInfo.InvariantCulture);
                                                if (F_Name.Contains("FXR08"))
                                                {
                                                    dt_name = obj.Get_Recon_DateForfxro8(filePath);
                                                }
                                                else if (F_Name.Contains("FXRENTA"))
                                                {
                                                    dt_name = obj.Get_Recon_DateforFxtenta(filePath);
                                                }
                                                else
                                                {
                                                    dt_name = Dte.ToString("yyyyMMdd");
                                                }
                                                Formatted_File_Name = Formatted_File_Name.Remove(Formatted_File_Name.Length - 8);
                                                if (!string.IsNullOrEmpty(db_Ext))
                                                    Formatted_File_Name = Formatted_File_Name + dt_name + db_Ext;
                                                else
                                                    Formatted_File_Name = Formatted_File_Name + dt_name + ".dat";
                                            }
                                            else
                                            {
                                                Formatted_File_Name = Path.GetFileNameWithoutExtension(Formatted_File_Name);
                                            }
                                            if (Formatted_File_Name.ToUpper().Contains("DDMMYYYY"))
                                            {
                                                Foramtted_Recon_Date = obj.Get_Recon_Date_For_Monday_Logic(conString, Country, "ddMMyyyy");
                                                Formatted_File_Name = Formatted_File_Name.Remove(Formatted_File_Name.Length - 8);
                                                Formatted_File_Name = Formatted_File_Name + Foramtted_Recon_Date;
                                            }
                                            else if (Formatted_File_Name.ToUpper().Contains("YYYYMMDD") || Formatted_File_Name.Contains("yyyyMMdd"))
                                            {
                                                Foramtted_Recon_Date = obj.Get_Recon_Date_For_Monday_Logic(conString, Country, "yyyyMMdd");
                                                Formatted_File_Name = Formatted_File_Name.Remove(Formatted_File_Name.Length - 8);
                                                Formatted_File_Name = Formatted_File_Name + Foramtted_Recon_Date;
                                            }

                                            string temp_FileName = Formatted_File_Name.Substring(0, Formatted_File_Name.LastIndexOf("_"));
                                            string temp_Recon_Date = string.Empty;

                                            DateTime myDate = DateTime.ParseExact(Recon_Date, "MM.dd.yyyy", System.Globalization.CultureInfo.InvariantCulture);
                                            if ((Recon_name == "BAHRAIN SWITCH RECON") || (Recon_name == "NETS & Cash card Topup Settlement") || (Recon_name == "VIETNAM - CASH IN ATM"))
                                            {
                                                temp_Recon_Date = myDate.ToString("ddMMyyyy");
                                            }
                                            else
                                            {
                                                temp_Recon_Date = myDate.ToString("yyyyMMdd");
                                            }
                                            //******************************************************************************************************
                                            if ((Recon_name == "Zimbabwe FX Recon_Zimbabwe FXR Adjustments") || (Recon_name == "Kenya FX Recon_Kenya FXR Adjustments") ||
                                                (Recon_name == "Uganda FX Recon_Uganda FXR Adjustments") || (Recon_name == "TANZANIA FX RECON_TANZANIA FXR Adjustments") ||
                                                (Recon_name == "Botswana FX Recon_Botswana FXR Adjustments") || (Recon_name == "NETS & Cash card Topup Settlement") ||
                                                (Recon_name == "DIFC FX Recon - Advised-DIFC Adjustment Report") || (Recon_name == "UAE FX Recon - Advised_UAE Adjustment Report") ||
                                                (Recon_name == "BAHRAIN DBU FX Recon - Advised-BAHRAIN DBU Adjustment Report") || (Recon_name == "BAHRAIN OBU FX Recon - Advised-BAHRAIN OBU Adjustment Report") ||
                                                (Recon_name == "BAHRAIN SWITCH RECON") || (Recon_name == "VIETNAM - CASH IN ATM") || (Recon_name == "VIETNAM - RLS RECONS"))
                                            {
                                                if (!File.Exists(Output_Path + Formatted_File_Name))
                                                {
                                                    File.Copy(filePath, Output_Path + Formatted_File_Name, true);
                                                }
                                            }
                                            else
                                            {
                                                temp_FileName = temp_FileName + "_" + temp_Recon_Date + db_Ext; //Changed this-Prakash-> temp_FileName = temp_FileName + "_" + Recon_Date + "." + File_Ext; 
                                                if (!File.Exists(Output_Path + temp_FileName))
                                                {
                                                    File.Copy(filePath, Output_Path + temp_FileName, true);
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            //**************************************************************************************************************//
                            if (dr2.Length == 0 && Non_For_Counter == File_Count)
                            {
                                SqlCommand Updt_cmd = new SqlCommand("update ARC_Recon_Master set Is_Recon_Completed = 1, Recon_Status = 'COMPLETED', PSID = '" + Environment.UserName + "' where Recon_Id = " + Recon_Id + "", con);
                                con.Open();
                                Updt_cmd.ExecuteNonQuery();
                                con.Close();
                            }
                        }
                        //********************************For Online Billers************************
                        DataTable dt_MY_ITT_Pend = new DataTable();
                        DataTable dt_MY_ITT_Pross = new DataTable();
                        DataTable dt_MY_final = new DataTable();
                        DataTable dt_VN_ITT_Pend = new DataTable();
                        DataTable dt_VN_ITT_Pross = new DataTable();
                        DataTable dt_VN_final = new DataTable();
                        DataTable dt_ID_ITT_Pend = new DataTable();
                        DataTable dt_ID_ITT_Pross = new DataTable();
                        DataTable dt_ID_final = new DataTable();
                        DataTable dt_SG_ITT_Pend = new DataTable();
                        DataTable dt_SG_ITT_Pross = new DataTable();
                        DataTable dt_SG_final = new DataTable();
                        DataTable dt_IN_ITT_Pend = new DataTable();
                        DataTable dt_IN_final = new DataTable();
                        DataTable dt_DUBI_AE = new DataTable();
                        DataTable dt_DUBI_SCB_Pos = new DataTable();
                        DataTable dt_Vietnm_EOD1 = new DataTable();
                        DataTable dt_Vietnm_EOD2 = new DataTable();
                        int DTcount = 0;
                        int DUBI_Indx = 0;
                        //************************************************************************//
                        foreach (DataRow d in dr2)
                        {
                            string Country = Convert.ToString(d[1]);
                            string File_Name = Convert.ToString(d[2]);
                            string IsFormatting = Convert.ToString(d[3]);
                            string Source_App = Convert.ToString(d[4]);
                            string File_Ext = Convert.ToString(d[5]);
                            string Formatted_File_Name = Convert.ToString(d[6]);
                            string AutomationStatus = Convert.ToString(d[7]);

                            //********************************************************************
                            string Recon_Date = obj.Get_Recon_Date(conString, Country, "yyyyMMdd");//yyyyMMdd

                            if (File_Ext.Contains("xlsx"))
                            {
                                File_Ext = "xlsx";
                            }
                            if (Recon_name == "Sri Lanka - Daily NCS CDS")
                            {
                                if (File_Name.Contains("SS_LK_CUS"))
                                {
                                    File_Name = obj.GetSpecificNCSCDS(Directory + "Input\\Seccure_Srilanka\\", "SS_LK_CUS");
                                }
                                else if (File_Name.Contains("DEX_LEDG_BAL"))
                                {
                                    File_Name = obj.GetSpecificNCSCDS(Directory + "Input\\Emails\\", "DEX_LEDG_BAL");
                                }
                                else if (File_Name.Contains("SCB ANZ"))
                                {
                                    File_Name = obj.GetSpecificNCSCDS(Directory + "Input\\Emails\\", "SCB ANZ");
                                }
                                else if (File_Name.Contains("LBSCB"))
                                {
                                    File_Name = obj.GetSpecificNCSCDS(Directory + "Input\\Emails\\", "LBSCB");
                                }
                                else if (File_Name.Contains("HoldingsDet"))
                                {
                                    File_Name = obj.GetSpecificNCSCDS(Directory + "Input\\Emails\\", "HoldingsDet");
                                }
                            }
                            if (Recon_name == "JORDON BONDS")
                            {
                                if (File_Name.Contains("SS_JO_CUS_"))
                                {
                                    File_Name = obj.GetSpecificJordonBonds(Directory + "Input\\Seccure_Jordan\\", "SS_JO_CUS_");
                                }
                            }

                            if (Recon_name == "Nepal Account Balance (BOI)")
                            {
                                if (File_Name.Contains("BOI Statement"))
                                {
                                    File_Name = obj.GetSpecificJordonBonds(Directory + "Input\\Emails\\", "BOI Statement") + ".pdf";
                                }
                            }
                            if (Recon_name == "INDONESIA CARDS - JETCO RECON")
                            {
                                File_Name = obj.GetSpecificMCD(Directory + "Input\\Emails\\", "sc-000050-raw") + ".zip";
                            }
                            if (Recon_name == "BANK OF ENGLAND")
                            {

                                if (File_Name.Contains("CM_Collateral"))
                                {
                                    File_Name = obj.GetSpecificMCD(Directory + "Input\\Emails\\", "CM_Collateral");
                                }
                                else if (File_Name.Contains("BTS_FI_PSN"))
                                {
                                    File_Name = obj.GetSpecificMCD(Directory + "Input\\Emails\\", "BTS_FI_PSN");
                                }
                            }
                            if (Recon_name == "Demat Custody")
                            {
                                if (File_Name.Contains("SCBPI_HOLD_BOD"))
                                {
                                    File_Name = obj.GetSpecificMCD(Directory + "Input\\Emails\\", "SCBPI_HOLD_BOD");
                                }
                                else if (File_Name.Contains("scb eod") && !File_Name.Contains("RC"))
                                {
                                    File_Name = obj.GetSpecificMCD(Directory + "Input\\Emails\\", "scb eod");
                                }
                                else if (File_Name.Contains("scb eod") && File_Name.Contains("RC"))
                                {
                                    File_Name = obj.GetSpecificMCD(Directory + "Input\\Emails\\", "RC");
                                }
                            }

                            if (Recon_name == "Kenya - VISA Electron DR.Card Suspense AC Recon KES USD GBP EUR YEN and Outstanding Report")
                            {
                                if (File_Name.Contains("debit2"))
                                {
                                    File_Name = obj.KVEDeb2(Directory + "Input\\Shared Drive_Kenya\\");
                                }
                                else if (File_Name.Contains("debit3"))
                                {
                                    File_Name = obj.KVEDeb3(Directory + "Input\\Shared Drive_Kenya\\");
                                }
                                else if (File_Name.Contains("EP210D"))
                                {
                                    File_Name = obj.KVEEP210(Directory + "Input\\Shared Drive_Kenya\\");
                                }
                                else if (File_Name.Contains("EP747"))
                                {
                                    File_Name = obj.KVEEP747(Directory + "Input\\Shared Drive_Kenya\\");
                                }
                            }

                            if (Recon_name == "Structured Funding  - BTS VS Custody")
                            {
                                if (File_Name.Contains("ACBS"))
                                {
                                    File_Name = obj.Clearstream(Directory + "Input\\Emails\\", "ACBS");
                                }
                                else if (File_Name.Contains("Sentry"))
                                {
                                    File_Name = obj.Clearstream(Directory + "Input\\Emails\\", "Sentry");
                                }
                                else if (File_Name.Contains("Structured Funding - Reconciliation List"))
                                {
                                    File_Name = obj.Clearstream(Directory + "Input\\Emails\\", "Structured Funding - Reconciliation List");
                                }
                                else if (File_Name.Contains("BTS_FI_PSN"))
                                {
                                    File_Name = obj.Clearstream(Directory + "Input\\Emails\\", "BTS_FI_PSN");
                                }
                                else if (File_Name.Contains("OPICS"))
                                {
                                    File_Name = obj.Clearstream(Directory + "Input\\OpicsPlus\\", "OPICS");
                                }
                                else if (File_Name.Contains("IR_FUND_COL"))
                                {
                                    File_Name = obj.Clearstream(Directory + "Input\\MurexSF_MOC - Multiple countries\\", "IR_FUND_COL");
                                }
                                else if (File_Name.Contains("CR_FUND_OFF_C1"))
                                {
                                    File_Name = obj.Clearstream(Directory + "Input\\MurexSF_MOC - Multiple countries\\", "CR_FUND_OFF_C1");
                                }
                                else if (File_Name.Contains("CR_FUND_OFF_C2"))
                                {
                                    File_Name = obj.Clearstream(Directory + "Input\\MurexSF_MOC - Multiple countries\\", "CR_FUND_OFF_C2");
                                }
                                else if (File_Name.Contains("CR_FUND_COL"))
                                {
                                    File_Name = obj.Clearstream(Directory + "Input\\MurexSF_MOC - Multiple countries\\", "CR_FUND_COL");
                                }
                                else if (File_Name.Contains("CR_FUND_GRNT"))
                                {
                                    File_Name = obj.Clearstream(Directory + "Input\\MurexSF_MOC - Multiple countries\\", "CR_FUND_GRNT");
                                }
                                else if (File_Name.Contains("CR_FUND_EQUITY"))
                                {
                                    File_Name = obj.Clearstream(Directory + "Input\\MurexSF_MOC - Multiple countries\\", "CR_FUND_EQUITY");
                                }
                                else if (File_Name.Contains("CR_FUND_ND"))
                                {
                                    File_Name = obj.Clearstream(Directory + "Input\\MurexSF_MOC - Multiple countries\\", "CR_FUND_ND");
                                }
                                else if (File_Name.Contains("CR_FUND_DISTR"))
                                {
                                    File_Name = obj.Clearstream(Directory + "Input\\MurexSF_MOC - Multiple countries\\", "CR_FUND_DISTR");
                                }
                                else if (File_Name.Contains("CR_FUND_FXRCDRV"))
                                {
                                    File_Name = obj.Clearstream(Directory + "Input\\MurexSF_MOC - Multiple countries\\", "CR_FUND_FXRCDRV");
                                }
                                else if (File_Name.Contains("CR_FUND_LC"))
                                {
                                    File_Name = obj.Clearstream(Directory + "Input\\MurexSF_MOC - Multiple countries\\", "CR_FUND_LC");
                                }
                                else if (File_Name.Contains("CR_SLT_BSLOAN"))
                                {
                                    File_Name = obj.Clearstream(Directory + "Input\\MurexSF_MOC - Multiple countries\\", "CR_SLT_BSLOAN");
                                }
                                else if (File_Name.Contains("RAZOR"))
                                {
                                    File_Name = obj.Clearstream(Directory + "Input\\Razor_MOC - Multiple countries\\", "RAZOR");
                                }
                            }
                            if (Recon_name == "DFLT-FXSETT-PD")
                            {
                                File_Name = obj.GetSpecificMCD(Directory + "Input\\Emails\\", "DF_FX_Holding_Statement") + ".pdf";
                            }
                            //Added on 06-03-18
                            if (Recon_name == "Bony and Clearstream1")
                            {
                                if (File_Name.Contains("AGREEMENT SUMMARY REPORT (TXT)"))
                                {
                                    //File_Name = File_Name + "." + File_Ext;
                                    //strIInputFileName = File_Name;
                                    File_Name = obj.GetSpecificMCD(Directory + "Input\\Emails\\", "AGREEMENT SUMMARY REPORT (TXT)_NTB");
                                }
                            }
                            if (Recon_name == "Bony and Clearstream2")
                            {
                                if (File_Name.Contains("alloc_extract"))
                                {
                                    File_Name = obj.GetSpecificMCD(Directory + "Input\\Emails\\", "alloc_extract") + ".pdduz";
                                }
                            }
                            if (Recon_name == "Bony and Clearstream3")
                            {
                                if (File_Name.Contains("COLLATERAL BALANCE"))
                                {
                                    File_Name = obj.GetSpecificMCD(Directory + "Input\\Emails\\", "COLLATERAL BALANCE");
                                }
                            }
                            if (Recon_name == "GM POS CUST")
                            {
                                if (File_Name.Contains("Treasury bill redicount"))
                                {
                                    File_Name = obj.GetSpecificMCD(Directory + "Input\\Emails\\", "Treasury bill redicount");
                                }
                                else if (File_Name.Contains("TREASURY BILL HOLDINGS"))
                                {
                                    File_Name = obj.GetSpecificMCD(Directory + "Input\\Emails\\", "TREASURY BILL HOLDINGS");
                                }
                            }
                            if (Recon_name == "Africa Custody-Opics Position weekly")
                            {
                                File_Name = obj.GetSpecificMCD(Directory + "Input\\Emails\\", "SECURITY HOLDINGS");
                            }
                            if (Recon_name == "IC Pos Cust")
                            {
                                File_Name = obj.GetSpecificMCD(Directory + "Input\\Emails\\", "RECON ");
                            }
                            if (Recon_name == "SCBDT1398")
                            {
                                File_Name = obj.GetSpecificMCD(Directory + "Input\\Emails\\", "SCBDT");
                            }
                            if (Recon_name == "DFLT-SEC-PD")
                            {
                                File_Name = obj.GetSpecificMCD(Directory + "Input\\Emails\\", "DF_Securities_Holding");
                            }
                            if (Recon_name == "Africa Custody-Opics Position weekly1")
                            {
                                File_Name = obj.GetSpecificMCD(Directory + "Input\\Emails\\", "STATEMENT OF HOLDING") + ".pdf";
                            }
                            if (Recon_name == "EUROCLEAR")
                            {
                                File_Name = obj.GetSpecificMCD(Directory + "Input\\Emails\\", "Euroclear") + ".pdf";
                            }
                            if (Recon_name == "CC-RSIRSDFLT-PD")
                            {
                                File_Name = obj.GetSpecificMCD(Directory + "Input\\Emails\\", "DF_REDRV_Holding_Statement") + ".xlsx";
                            }
                            if (Recon_name == "HK0000112831")
                            {
                                File_Name = obj.GetSpecificMCD(Directory + "Input\\Emails\\", "HK0000112831");
                            }
                            if (Recon_name == "RBC Limited")
                            {
                                File_Name = obj.GetSpecificMCD(Directory + "Input\\Emails\\", "00408876101");
                            }
                            if (Recon_name == "Srilanka TLM Open Items-CA-LK-BRH-122131-Email")
                            {
                                File_Name = obj.GetSpecificMCD(Directory + "Input\\Emails\\", "ACOM");
                            }
                            if (Recon_name == "Kenya CUSTODY-OPICS position Fortnightly")
                            {
                                File_Name = obj.GetSpecificMCD(Directory + "Input\\Emails\\", "CBK Securities");
                            }
                            if (Recon_name == "HK0000112791")
                            {
                                File_Name = obj.GetSpecificMCD(Directory + "Input\\Emails\\", "AI-MAS");
                            }
                            if (Recon_name == "BNCA CLMBA COP-LK0000006596")
                            {
                                if (File_Name.Contains("LKR_BI"))
                                {
                                    File_Name = obj.GetSpecificMCD(Directory + "Input\\Emails\\", "LKR_BI");
                                    Formatted_File_Name = Formatted_File_Name.Replace("YYYYMMDD", File_Name.Substring(File_Name.Length - 15, 8));
                                }
                                else if (File_Name.Contains("BNCA_BI"))
                                {
                                    File_Name = obj.GetSpecificMCD(Directory + "Input\\Emails\\", "BNCA_BI");
                                    Formatted_File_Name = Formatted_File_Name.Replace("YYYYMMDD", File_Name.Substring(File_Name.Length - 16, 8));
                                }

                            }
                            if (File_Name.Contains("DD-MMM YYYY"))
                            {
                                Recon_Date = obj.Get_Recon_Date(conString, Country, "dd-MMM yyyy");
                                File_Name = File_Name.Remove(File_Name.Length - 11);
                                File_Name = File_Name + Recon_Date + "-0010-GMT";
                            }
                            else if (File_Name.Contains("DD.MM.YYYY"))
                            {
                                if (File_Name.Contains("AB-DETAIL_"))
                                {
                                    File_Name = obj.GetSpecificFileNameABDETAIL(Directory + "Input\\Emails\\");
                                }
                                else if (File_Name.Contains("BILLING SETTLEMENT"))
                                {
                                    File_Name = obj.GetSpecificFileName(Directory + "Input\\Emails\\");
                                }
                                else if (File_Name.Contains("ACQ SETTLEMENT"))
                                {
                                    File_Name = obj.GetSpecificFileNameSmartLink(Directory + "Input\\Emails\\", "ACQ");
                                }
                                else if (File_Name.Contains("ISS SETTLEMENT"))
                                {
                                    File_Name = obj.GetSpecificFileNameSmartLink(Directory + "Input\\Emails\\", "ISS");
                                }
                                else if (File_Name.Contains("S4 POSITION"))
                                {
                                    File_Name = File_Name.Remove(File_Name.Length - 10);
                                    File_Name = File_Name + System.DateTime.Today.ToString("dd.MM.yyyy");
                                }

                                //25-05 Kiran
                                else if (File_Name.ToLower().Contains("inward rejected") || File_Name.ToLower().Contains("inward received") || File_Name.ToLower().Contains("outward presented") || File_Name.ToLower().Contains("outward returned"))
                                {
                                    Recon_Date = obj.Get_Recon_Date(conString, Country, "dd.MM.yyyy");
                                    File_Name = File_Name.Remove(File_Name.Length - 10);
                                    File_Name = File_Name + Recon_Date;
                                    File_Ext = "xlsx";
                                }
                                else
                                {
                                    Recon_Date = obj.Get_Recon_Date(conString, Country, "dd.MM.yyyy");
                                    File_Name = File_Name.Remove(File_Name.Length - 10);
                                    File_Name = File_Name + Recon_Date;
                                }
                            }
                            else if (File_Name.Contains("YYYY-MM-DD"))
                            {
                                ////25-05 Kiran
                                //if (Recon_name == "Bony and Clearstream")
                                //{
                                //    if (File_Name.Contains("Client_92078"))
                                //    {
                                //        File_Name = obj.GetSpecificFileName_BonyClear(Directory + "Input\\Emails\\", Recon_Date);
                                //    }
                                //}

                                //if (Recon_name == "BAHRAIN ATM RECON")
                                //{
                                //    if (File_Name.Contains("MCI.AR.T464."))
                                //    {
                                //        File_Name = obj.GetSpecificFileName_BahrainATM(Directory + "Input\\" + Source_App + "_" + Country);

                                //    }
                                //}
                                //else 
                                if (Recon_name == "UAE ATM RECON")
                                {
                                    if (File_Name.Contains("MCI.AR.T464."))
                                    {
                                        File_Name = obj.GetSpecificFileName_BahrainATM(Directory + "Input\\" + Source_App + "_" + Country);

                                    }
                                }

                                else
                                {
                                    Recon_Date = obj.Get_Recon_Date(conString, Country, "yyyy-MM-dd");
                                    File_Name = File_Name.Substring(0, File_Name.Length - 10) + Recon_Date;
                                }
                            }

                            else if (File_Name.Contains("yyyyMMdd"))
                            {
                                File_Name = File_Name.Substring(0, File_Name.Length - 8);
                                if (File_Name.Contains("TB_OPS_DAILY_TRADE_REPORT-yyyyMMdd"))
                                {
                                    File_Name = File_Name + Recon_Date + "-0010-GMT";
                                }
                                else
                                {
                                    File_Name = File_Name + Recon_Date;
                                }
                            }
                            else if (File_Name.Contains("DD-MMM-YYYY") || File_Name.Contains("dd-MMM-yyyy"))
                            {
                                if (Recon_name == "Vietnam I-banking" && File_Name.ToUpper().Contains("IBANKING SETTLEMENT"))
                                {
                                    DateTime chkdt = DateTime.ParseExact(Recon_Date, "ddMMyyyy", CultureInfo.InvariantCulture).AddDays(-1);
                                    Recon_Date = chkdt.ToString("ddMMyyyy");
                                    File_Name = File_Name.Remove(File_Name.Length - 8);
                                    File_Name = File_Name + Recon_Date;
                                }
                                else if (Recon_name == "IBROKER  - SG" || Recon_name == "IBROKER  - MY")
                                {
                                    Recon_Date = obj.Get_Recon_Date(conString, Country, "dd-MMM-yyyy");
                                    DateTime chkdt = DateTime.ParseExact(Recon_Date, "dd-MMM-yyyy", CultureInfo.InvariantCulture);
                                    File_Name = File_Name.Remove(File_Name.Length - 11);
                                    Recon_Date = DateTime.Today.ToString("dd-MMM-yyyy");
                                    File_Name = File_Name + Recon_Date;
                                }
                                else
                                {
                                    Recon_Date = obj.Get_Recon_Date(conString, Country, "dd-MMM-yyyy").ToUpper();
                                    File_Name = File_Name.Remove(File_Name.Length - 11);
                                    File_Name = File_Name + Recon_Date;
                                }
                            }

                            else if (File_Name.Contains("DDMMYY") && !File_Name.Contains("DDMMYYYY"))
                            {
                                Recon_Date = obj.Get_Recon_Date(conString, Country, "ddMMyy");
                                File_Name = File_Name.Remove(File_Name.Length - 6);
                                if (Recon_name == "Vietnam ACB")
                                {
                                    if (DateTime.Today.DayOfWeek.ToString() != "Tuesday")
                                    {
                                        string Date = "";
                                        DateTime dtVietnm = DateTime.ParseExact(Recon_Date, "ddMMyy", CultureInfo.InvariantCulture);
                                        Date = dtVietnm.AddDays(-1).ToString("ddMMyy");
                                        File_Name = File_Name + Date;
                                    }
                                    else
                                    {

                                        string Date = "";
                                        DateTime dtVietnm = DateTime.ParseExact(Recon_Date, "ddMMyy", CultureInfo.InvariantCulture);
                                        Date = dtVietnm.AddDays(-3).ToString("ddMMyy");
                                        File_Name = File_Name + Date;
                                    }
                                }
                                else if (Recon_name == "RBI RTGS")
                                {
                                    File_Name = obj.GetRBIRTGS(Directory + "Input\\Emails\\");
                                    File_Name = File_Name.Replace("DDMMYY", Recon_Date);
                                }
                                else if (Recon_name == "Malaysia - MCD Recon")
                                {
                                    File_Name = obj.GetSpecificMCD(Directory + "Input\\Emails\\", "CFT003_Daily");
                                }
                                else if (Recon_name == "Malaysia - MCD Recon-Monthly")
                                {
                                    File_Name = obj.GetSpecificMCD(Directory + "Input\\Emails\\", "TCFT003");
                                }
                                else if (Recon_name == "Srilanka TLM Open Items-CA-LK-BRH-170254-LKR-LANKA BELL (PD)")
                                {
                                    File_Name = obj.Get_KEELSFilename(Directory + "Input\\Emails\\", "LB");
                                }
                                else if (Recon_name == "INDONESIA CARDS - BATCH 2 REPORT-SCBNET")
                                {
                                    if (File_Name.Contains("MGDAQ_MID"))// _DDMMYY
                                    {
                                        File_Name = obj.GetIND_BAT2FileName(Directory + "Input\\Shared Drive_Indonesia\\");
                                        File_Name = File_Name.Replace("DDMMYY", Recon_Date);

                                    }
                                    else
                                    {
                                        File_Name = obj.GetIND_BAT2FileName1(Directory + "Input\\Shared Drive_Indonesia\\");
                                        File_Name = File_Name.Replace("DDMMYY", Recon_Date);

                                    }
                                }
                                else
                                {
                                    File_Name = File_Name + Recon_Date;
                                }

                            }
                            else if (File_Name.Contains("DDMMYYYY") && Recon_name != "Settlement Suspense Accounts")
                            {
                                Recon_Date = obj.Get_Recon_Date(conString, Country, "ddMMyyyy");
                                if (Recon_name == "Vietnam I-banking" && File_Name.Contains("IBANKING SETTLEMENT"))
                                {
                                    if (DateTime.Today.DayOfWeek.ToString() != "Tuesday")
                                    {
                                        string Date = "";
                                        DateTime dtVietnm = DateTime.ParseExact(Recon_Date, "ddMMyyyy", CultureInfo.InvariantCulture);
                                        Date = dtVietnm.AddDays(-1).ToString("ddMMyyyy");
                                        File_Name = File_Name.Remove(File_Name.Length - 8);
                                        File_Name = File_Name + Date;
                                    }
                                    else
                                    {
                                        string Date = "";
                                        DateTime dtVietnm = DateTime.ParseExact(Recon_Date, "ddMMyyyy", CultureInfo.InvariantCulture);
                                        Date = dtVietnm.AddDays(-3).ToString("ddMMyyyy");
                                        File_Name = File_Name.Remove(File_Name.Length - 8);
                                        File_Name = File_Name + Date;
                                    }
                                }
                                else if ((Recon_name == "Vietnam Billing") || (Recon_name == "Vietnam Smart link"))  // added on 23 03 2017 for Vietnam billing and Vietnam smart link for T-2 days
                                {
                                    if (File_Name.Contains("BILLING SETTLEMENT"))
                                    {
                                        File_Name = obj.GetSpecificFileName(Directory + "Input\\Emails\\");
                                    }
                                    else if (File_Name.Contains("ACQ SETTLEMENT"))
                                    {
                                        File_Name = obj.GetSpecificFileNameSmartLink(Directory + "Input\\Emails\\", "ACQ");
                                    }
                                    else if (File_Name.Contains("ISS SETTLEMENT"))
                                    {
                                        File_Name = obj.GetSpecificFileNameSmartLink(Directory + "Input\\Emails\\", "ISS");
                                    }
                                }
                                //25-05 Kiran
                                else if (Recon_name == "Jordan Stock recon open items")
                                {
                                    //if (File_Name.ToLower().Contains("trading"))
                                    //{
                                    //    File_Name = obj.Get_JordanStock_Trading_FileName(Directory + "Input\\" + Source_App + "_" + Country + "\\");
                                    //}
                                    //else if (File_Name.ToLower().Contains("custody"))
                                    //{
                                        File_Name = obj.Get_JordanStock_Custody_FileName(Directory + "Input\\" + Source_App + "_" + Country + "\\");
                                    //}

                                }

                                //30-06
                                else if (Recon_name == "UAE-SCBNET Settlement Suspense and CUP Settlement Suspense")
                                {
                                    if (File_Name.Contains("ACOM"))
                                    {
                                        File_Name = obj.GetFileNameUAECUPS(Directory + "Input\\Shared Drive_UAE\\");
                                    }
                                }

                                //Added By Anees...
                                else if (Recon_name == "CASH PAYMENT SUSPENSE")
                                {
                                    if (File_Name.Contains("CHQ"))// _DDMMYYYY
                                    {
                                        File_Name = obj.GetCASH_PAY_CHQFileName(Directory + "Input\\Emails\\");
                                        File_Name = File_Name.Replace("DDMMYYYY", Recon_Date);

                                    }
                                    else
                                    {
                                        File_Name = obj.GetCASH_PAY_S2BFileName(Directory + "Input\\Emails\\");
                                        File_Name = File_Name.Replace("DDMMYYYY", Recon_Date);

                                    }
                                }
                                else if (Recon_name == "GHANA INWARD CLEARING")
                                {
                                    if (File_Name.Contains("EXT. INTERFACE"))// _DDMMYYYY
                                    {
                                        File_Name = obj.GetGhana_Ext_FileName(Directory + "Input\\PDF_Conversion\\");
                                        File_Name = File_Name.Replace("DDMMYYYY", Recon_Date);

                                    }
                                    else
                                    {
                                        File_Name = obj.GetGhana_Gross_FileName(Directory + "Input\\PDF_Conversion\\");
                                        File_Name = File_Name.Replace("DDMMYYYY", Recon_Date);

                                    }
                                }
                                else if (Recon_name == "TR0190033936")
                                {
                                    if (File_Name.Contains("Statement under account THCCSTDG"))
                                    {
                                        File_Name = obj.Get_MonthlyFileName(Directory + "Input\\Emails\\", "Statement under account THCCSTDG");
                                    }
                                }
                                else if (Recon_name == "Srilanka TLM Open Items-CA-LK-BRH-170254-LKR-KEELYS (W-M)")
                                {
                                    if (File_Name.Contains("LK_KELLYS_"))
                                    {
                                        File_Name = obj.Get_MonthlyFileName(Directory + "Input\\Emails\\", "LK_KELLYS_");
                                    }
                                }
                                else if (Recon_name == "Malaysia - MCD Recon-Monthly")
                                {
                                    File_Name = obj.GetSpecificMCD(Directory + "Input\\Emails\\", "TCFT003");
                                }
                                else if (Recon_name == "Malaysia - MCD Recon")
                                {
                                    File_Name = obj.GetSpecificMCD(Directory + "Input\\Emails\\", "CFT003_Daily");
                                }
                                else if (Recon_name == "BAHRAIN - Branch ATM Recon" || Recon_name == "Bahrain CDM Recon")
                                {
                                    File_Name = obj.GetSpecificMCD(Directory + "Input\\SFTP_BAHRAIN\\", "SBHA");
                                }
                                else if (Recon_name == "UAE BRANCH ATM")
                                {
                                    File_Name = obj.GetSpecificMCD(Directory + "Input\\SFTP_UAE\\", "EASAE");
                                }
                                else if (Recon_name == "UAE Travelex Recon")
                                {
                                    File_Name = obj.GetSpecificMCD(Directory + "Input\\SFTP_UAE\\", "TRAVELEX_LITE_UAE_NEW");
                                }
                                else if (Recon_name == "PVB HONGKONG - MONTHLY")
                                {
                                    if (File_Name.Contains("Security trade Extract"))
                                    {
                                        File_Name = obj.GetSpecificMCD(Directory + "Input\\R2W_Hong Kong\\", "Security trade Extract");
                                    }
                                    else if (File_Name.Contains("Security_Position_PVB_HK_DDMMYYYY"))
                                    {
                                        File_Name = obj.GetSpecificMCD(Directory + "Input\\R2W_Hong Kong\\", "Security_Position_PVB_HK");
                                    }
                                }
                                else if (Recon_name == "PVB UNITED KINGDOM - MONTHLY")
                                {
                                    if (File_Name.Contains("Security trade Extract"))
                                    {
                                        File_Name = obj.GetSpecificMCD(Directory + "Input\\R2W_United Kingdom\\", "Security trade Extract");
                                    }
                                    else if (File_Name.Contains("Security_Position_PVB_UK"))
                                    {
                                        File_Name = obj.GetSpecificMCD(Directory + "Input\\R2W_United Kingdom\\", "Security_Position_PVB_UK");
                                    }
                                }
                                else if (Recon_name == "PVB SINGAPORE - MONTHLY")
                                {
                                    if (File_Name.Contains("Security trade Extract"))
                                    {
                                        File_Name = obj.GetSpecificMCD(Directory + "Input\\R2W_Singapore\\", "Security trade Extract");
                                    }
                                    else if (File_Name.Contains("Security_Position_PVB_SG"))
                                    {
                                        File_Name = obj.GetSpecificMCD(Directory + "Input\\R2W_Singapore\\", "Security_Position_PVB_SG");
                                    }
                                }
                                else if (Recon_name == "CCMS OPEN ITEMS")
                                {
                                    if (File_Name.Contains("CSW64D") && Recon_name == "CCMS OPEN ITEMS")
                                    {
                                        File_Name = obj.GetCCMS_CSW64FileName(Directory + "Input\\Emails\\");
                                    }
                                    else if (File_Name.Contains("CSW65D") && Recon_name == "CCMS OPEN ITEMS")
                                    {
                                        File_Name = obj.GetCCMS_CSW65FileName(Directory + "Input\\Emails\\");
                                    }
                                }
                                else if (Recon_name == "NSE-CURR FUT-NSE-CURR FUT -PD")
                                {
                                    File_Name = obj.GetSpecificMCD(Directory + "Input\\Emails\\", "NS_Collateral");
                                }
                                else if (Recon_name == "Hong kong CMU")
                                {
                                    File_Name = obj.GetSpecificMCD(Directory + "Input\\PDF_Conversion\\", "CMUD5101") + ".pdf";
                                }
                                else
                                {
                                    File_Name = File_Name.Remove(File_Name.Length - 8);
                                    File_Name = File_Name + Recon_Date;
                                }
                            }
                            else if (File_Name.Contains("YYMMDD") && !File_Name.Contains("YYYYMMDD"))
                            {
                                Recon_Date = obj.Get_Recon_Date(conString, Country, "yyMMdd");
                                if (Recon_name == "UAE Clearing Recon")
                                {
                                    if (File_Name.Contains("ICCSC03"))
                                    {
                                        File_Name = obj.GetFileNameUAEClearing1(Directory + "Input\\Shared Drive_UAE\\");
                                    }
                                    else if (File_Name.Contains("ICCSC02"))
                                    {
                                        File_Name = obj.GetFileNameUAEClearing2(Directory + "Input\\Shared Drive_UAE\\");
                                    }
                                }
                                else if (Recon_name == "BAHRAIN ATM RECON")
                                {
                                    if (File_Name.Contains("MCI.AR.T464."))
                                    {
                                        File_Name = obj.GetSpecificFileName_BahrainATM(Directory + "Input\\" + Source_App + "_" + Country);

                                    }
                                }
                                else if (Recon_name == "UAE ATM RECON")
                                {
                                    if (File_Name.Contains("MCI.AR.T464."))
                                    {
                                        File_Name = obj.GetSpecificFileName_BahrainATM(Directory + "Input\\" + Source_App + "_" + Country);

                                    }
                                }
                                else if (Recon_name == "UAE-SCBNET Settlement Suspense and CUP Settlement Suspense")
                                {
                                    if (File_Name.Contains("ACOM"))
                                    {
                                        File_Name = obj.GetFileNameUAECUPS(Directory + "Input\\Shared Drive_UAE\\");
                                    }
                                }
                                else
                                {

                                    File_Name = File_Name.Remove(File_Name.Length - 6);
                                    File_Name = File_Name + Recon_Date;
                                }
                            }
                            else if (File_Name.Contains("MMDD") && (!File_Name.Contains("YYYYMMDD") && !File_Name.Contains("MMDDYYYY")))
                            {
                                if (Recon_name == "Vietnam Visa TLM open items")
                                {
                                    if (DateTime.Today.DayOfWeek.ToString() != "Tuesday")
                                    {
                                        Recon_Date = obj.Get_Recon_Date(conString, Country, "MMdd");
                                        int daystot = obj.Get_HolidaysTotal(conString, Country, "MMdd");
                                        string Date = "";
                                        DateTime dtVietnm = DateTime.ParseExact(Recon_Date, "MMdd", CultureInfo.InvariantCulture);
                                        Date = dtVietnm.AddDays(-1).ToString("MMdd");
                                        File_Name = File_Name.Remove(File_Name.Length - 4);

                                        File_Name = File_Name + Date;
                                    }
                                    else
                                    {
                                        Recon_Date = obj.Get_Recon_Date(conString, Country, "MMdd");
                                        int daystot = obj.Get_HolidaysTotal(conString, Country, "MMdd");
                                        string Date = "";
                                        DateTime dtVietnm = DateTime.ParseExact(Recon_Date, "MMdd", CultureInfo.InvariantCulture);
                                        Date = dtVietnm.AddDays(-3).ToString("MMdd");
                                        File_Name = File_Name.Remove(File_Name.Length - 4);

                                        File_Name = File_Name + Date;
                                    }
                                }
                                else if (Recon_name == "JERSEY WEEKLY BBH RECON")
                                {
                                    if (File_Name.Contains("Clearstream"))
                                    {
                                        File_Name = obj.Clearstream(Directory + "Input\\ClearStream_Jersey\\", "Clearstream");
                                    }
                                    else if (File_Name.Contains("Input_Data_BBH"))
                                    {
                                        File_Name = obj.Clearstream(Directory + "Input\\BBH_Jersey\\", "Input_Data_BBH");
                                    }
                                    else if (File_Name.Contains("T24 CLS AS ON"))
                                    {
                                        File_Name = obj.Clearstream(Directory + "Input\\T24_Jersey\\", "T24 CLS AS ON");
                                    }
                                    else if (File_Name.Contains("Input_data_T24_"))
                                    {
                                        File_Name = obj.Clearstream(Directory + "Input\\T24_Jersey\\", "Input_data_T24_");
                                    }
                                }
                                else if (Recon_name == "289282-Meps ATM Settlement")
                                {
                                    Recon_Date = obj.Get_Recon_Date(conString, Country, "MMdd");
                                    File_Name = File_Name.Remove(File_Name.Length - 4);
                                    File_Name = File_Name + Recon_Date;
                                }
                            }
                            else if (File_Name.Contains("DDMM") && !File_Name.Contains("DDMM-DDMM") && Recon_name != "Settlement Suspense Accounts")
                            {
                                Recon_Date = obj.Get_Recon_Date(conString, Country, "ddMM");
                                File_Name = File_Name.Remove(File_Name.Length - 4);
                                File_Name = File_Name + Recon_Date;
                            }
                            //25-05 Kiran
                            else if (File_Name.Contains("YYYYMMDD"))
                            {
                                if (Recon_name == "Thailand - Custody - Depo Recon")
                                {
                                    Recon_Date = obj.Get_Recon_Date(conString, Country, "yyyyMMdd");
                                    File_Ext = "";
                                    File_Name = obj.GetSpecificFileName_Thailand_Custody_DepoRecon(Directory + "Input\\Emails\\", Recon_Date);
                                }
                                else if (Recon_name == "Vietnam Visa TLM open items")
                                {
                                    if (File_Name.Contains("SWITCH REPORT") || File_Name.Contains("VISA ACQUIRER SETTLEMENT-EP745"))
                                    {
                                        if (DateTime.Today.DayOfWeek.ToString() != "Tuesday")
                                        {
                                            Recon_Date = obj.Get_Recon_Date(conString, Country, "yyyyMMdd");//yyyyMMdd

                                            DateTime myDate = DateTime.ParseExact(Recon_Date, "yyyyMMdd", System.Globalization.CultureInfo.InvariantCulture);

                                            if (File_Name.Contains("SWITCH REPORT"))
                                            {
                                                Recon_Date = myDate.ToString("yyyyMMdd");
                                            }

                                            else if (File_Name.Contains("VISA ACQUIRER SETTLEMENT-EP745"))
                                            {
                                                Recon_Date = myDate.AddDays(-1).ToString("yyyyMMdd");
                                            }

                                            File_Name = File_Name.Substring(0, File_Name.Length - 8) + Recon_Date;
                                        }
                                        else
                                        {
                                            Recon_Date = obj.Get_Recon_Date(conString, Country, "yyyyMMdd");//yyyyMMdd

                                            DateTime myDate = DateTime.ParseExact(Recon_Date, "yyyyMMdd", System.Globalization.CultureInfo.InvariantCulture);
                                            if (File_Name.Contains("SWITCH REPORT"))
                                            {
                                                Recon_Date = myDate.ToString("yyyyMMdd");
                                            }

                                            else if (File_Name.Contains("VISA ACQUIRER SETTLEMENT-EP745"))
                                            {
                                                Recon_Date = myDate.AddDays(-1).ToString("yyyyMMdd");
                                            }
                                            File_Name = File_Name.Substring(0, File_Name.Length - 8) + Recon_Date;
                                        }
                                    }

                                }
                                else if (Recon_name == "Vietnam VNPay")
                                {
                                    if (File_Name.Contains("BillPayment_Mobile_TopUp"))
                                    {
                                        Recon_Date = obj.Get_Recon_Date(conString, Country, "yyyyMMdd");//yyyyMMdd
                                        File_Name = File_Name.Substring(0, File_Name.Length - 8);
                                        File_Name = File_Name + Recon_Date;
                                    }
                                    else if (File_Name.Contains("_inc_scvn"))
                                    {
                                        if (DateTime.Today.DayOfWeek.ToString() != "Tuesday")
                                        {
                                            DateTime myDate = DateTime.ParseExact(Recon_Date, "yyyyMMdd", System.Globalization.CultureInfo.InvariantCulture);
                                            Recon_Date = myDate.ToString("yyyyMMdd");
                                            File_Name = Recon_Date + File_Name.Substring(File_Name.Length - 9, 9);
                                        }
                                        else
                                        {
                                            DateTime myDate = DateTime.ParseExact(Recon_Date, "yyyyMMdd", System.Globalization.CultureInfo.InvariantCulture);
                                            Recon_Date = myDate.AddDays(-2).ToString("yyyyMMdd");
                                            File_Name = Recon_Date + File_Name.Substring(File_Name.Length - 9, 9);
                                        }
                                    }

                                }
                                else if (Recon_name == "Singapore-Monthly Unit Trust")
                                {
                                    File_Name = obj.GetFileNameSGMonthlyunitTrust(Directory + "Input\\" + Source_App + "_" + Country + "\\");
                                }
                                else if (Recon_name == "Hong Kong Monthly Unit Trust")
                                {
                                    File_Name = obj.GetFileNameHKMonthlyunitTrust(Directory + "Input\\" + Source_App + "_" + Country + "\\");
                                }
                                else
                                {
                                    Recon_Date = obj.Get_Recon_Date(conString, Country, "yyyyMMdd");
                                    File_Name = File_Name.Substring(0, File_Name.Length - 8);
                                    File_Name = File_Name + Recon_Date;
                                }
                            }

                            else if (File_Name.Contains("DD-MMM-YYYY"))
                            {
                                Recon_Date = obj.Get_Recon_Date(conString, Country, "dd-MMM-yyyy");
                                File_Name = File_Name.Remove(File_Name.Length - 11);
                                File_Name = File_Name + Recon_Date;
                            }
                            else if (File_Name.Contains("DD_MM_YYYY"))
                            {
                                Recon_Date = obj.Get_Recon_Date(conString, Country, "dd_MM_yyyy");
                                File_Name = File_Name.Remove(File_Name.Length - 10);
                                File_Name = File_Name + Recon_Date;
                            }
                            else if (File_Name.Contains("DDMM-DDMM"))
                            {
                                File_Name = obj.GetVietnamACB(Directory + "\\Input\\Emails\\");
                            }

                            //25-05 Kiran
                            else if (File_Name.Contains("Presented") || File_Name.Contains("Received") || File_Name.Contains("Rejected") || File_Name.Contains("Returned"))
                            {
                                File_Ext = "xlsx";
                            }
                            else if (File_Name.Contains("MMDDYYYY"))
                            {
                                if (Recon_name == "Brunei Inward Clearing")
                                {
                                    if (File_Name.Contains("bninw1"))
                                    {
                                        File_Name = obj.Clearstream(Directory + "Input\\Emails\\", "bninw1");
                                    }
                                    else if (File_Name.Contains("bninw2"))
                                    {
                                        File_Name = obj.Clearstream(Directory + "Input\\Emails\\", "bninw2");
                                    }
                                    else if (File_Name.Contains("PGINW"))
                                    {
                                        File_Name = obj.Clearstream(Directory + "Input\\Emails\\", "PGINW");
                                    }
                                }
                                else
                                {
                                    Recon_Date = obj.Get_Recon_Date(conString, Country, "MMddyyyy");
                                    File_Name = Recon_Date;
                                }
                            }
                            else if (!File_Name.Contains("DD-MM-YYYY") && File_Name.Contains("DD-MM-YY"))
                            {
                                Recon_Date = obj.Get_Recon_Date(conString, Country, "dd-MM-yy");
                                File_Name = File_Name.Substring(0, File_Name.Length - 8) + Recon_Date;
                                //}
                                //else
                                //{
                                //    File_Name = File_Name.Substring(0, File_Name.Length - 8) + Recon_Date;
                                //}
                            }
                            else if (File_Name.Contains("DD-MMM-YY"))
                            {
                                Recon_Date = obj.Get_Recon_Date(conString, Country, "dd-MMM-yy");
                                File_Name = File_Name.Replace("DD-MMM-YY", Recon_Date);
                            }
                            else if (File_Name.Contains("DD-MM-YYYY"))
                            {
                                Recon_Date = obj.Get_Recon_Date(conString, Country, "dd-MM-yyyy");
                                if (File_Name.Contains("CURSA_AS_OF_") || File_Name.Contains("CURSC_AS_OF_") || File_Name.Contains("CURSE_AS_OF_") || File_Name.Contains("CURSI_AS_OF_") || File_Name.Contains("CURST_AS_OF_"))
                                {
                                    File_Name = File_Name.Substring(0, File_Name.Length - 10) + Recon_Date;
                                }
                                else if (File_Name.Contains("LBC Basic Sheet"))// DD-MM-YYYY
                                {
                                    File_Name = obj.GetMISC_SINGFileName(Directory + "Input\\Emails\\");
                                    File_Name = File_Name.Replace("DD-MM-YYYY", Recon_Date);
                                    // File_Name = File_Name.Substring(0, File_Name.Length - 10) + Recon_Date;

                                }
                                else
                                {
                                    File_Name = File_Name.Substring(0, File_Name.Length - 10) + Recon_Date;
                                }
                            }
                            else if (File_Name.Contains("SCBMA") || File_Name.Contains("SCBFC"))
                            {
                                string tempFileN = "";
                                if (File_Name.Contains("SCBMA"))
                                    tempFileN = "SCBMA";
                                if (File_Name.Contains("SCBFC"))
                                    tempFileN = "SCBFC";

                                File_Name = obj.Get_MonthlyFileName(Directory + "Input\\Emails\\", tempFileN);
                            }
                            else if (File_Name.Contains("JGB"))
                            {
                                File_Name = obj.Get_MonthlyFileName(Directory + "Input\\Emails\\", "JGB");
                            }
                            else if (File_Name.Contains("scb eod"))
                            {
                                File_Name = obj.Get_MonthlyFileName(Directory + "Input\\Emails\\", "scb eod");
                            }
                            else if (File_Name.Contains("AI-MAS Shares held Book"))
                            {
                                File_Name = obj.Get_MonthlyFileName(Directory + "Input\\Emails\\", "AI-MAS Shares held Book");
                            }
                            else if (File_Name.Contains("_RACSTRBI_"))
                            {
                                File_Name = obj.GetRBIFileName(Directory + "Input\\Emails\\");
                            }
                            else if (File_Name.Contains("WEB REPORT"))
                            {
                                File_Name = obj.GetWebCollections(Directory + "Input\\Web Report_India\\");
                            }
                            else if (File_Name.Contains("105d"))//Added By Aneesh 09/11/17
                            {
                                File_Name = obj.GetSettelment_105d(Directory + "Input\\Control D_Malaysia\\");
                            }
                            else if (File_Name.Contains("SWCHD57"))
                            {
                                File_Name = obj.GetSettelment_Switch(Directory + "Input\\Emails\\");
                            }
                            else if (File_Name.Contains("MGDAQ") && Recon_name == "Settlement Suspense Accounts")
                            {
                                File_Name = obj.GetSettelment_MGDAQ(Directory + "Input\\Emails\\");
                            }
                            else if (File_Name.Contains("MGDIS") && Recon_name == "Settlement Suspense Accounts")
                            {
                                File_Name = obj.GetSettelment_MGDIS(Directory + "Input\\Emails\\");
                            }
                            //Added By Aneesh 09/11/17
                            else if (File_Name.Contains("STAT09-SCB"))
                            {
                                File_Name = obj.Get_MepsFileName(Directory + "Input\\Emails\\");
                            }

                            else if (File_Name.Contains("SMY04536C"))
                            {
                                File_Name = obj.GetCo_Dis_4536FileName(Directory + "Input\\Emails\\");
                            }
                            else if (File_Name.Contains("SMY04587C"))
                            {
                                File_Name = obj.GetCo_Dis_4587FileName(Directory + "Input\\Emails\\");
                            }
                            else if (File_Name.Contains("TBILL") && Recon_name == "CASH PAYMENT SUSPENSE")
                            {
                                File_Name = obj.GetCASH_PAY_TBILLFileName(Directory + "Input\\Emails\\");
                            }
                            else if (File_Name.Contains("Inward") && Recon_name == "GIRO SUSPENSE")
                            {
                                File_Name = obj.GetGiro_InwrdFileName(Directory + "Input\\Ebbs_Malaysia\\");
                            }
                            else if (File_Name.Contains("Outward") && Recon_name == "GIRO SUSPENSE")
                            {
                                File_Name = obj.GetGiro_OutwrdFileName(Directory + "Input\\Ebbs_Malaysia\\");
                            }
                            else if (File_Name.Contains("CCMSVISA") && Recon_name == "CCMS OPEN ITEMS")
                            {
                                File_Name = obj.GetCCMS_VISAFileName(Directory + "Input\\Ebbs_Malaysia\\");
                            }
                            else if (File_Name.Contains("CCMSMASTER") && Recon_name == "CCMS OPEN ITEMS")
                            {
                                File_Name = obj.GetCCMS_MASTERFileName(Directory + "Input\\Ebbs_Malaysia\\");
                            }
                            //else if (File_Name.Contains("CSW64D") && Recon_name == "CCMS OPEN ITEMS")
                            //{
                            //    File_Name = obj.GetCCMS_CSW64FileName(Directory + "Input\\Emails\\");
                            //}
                            //else if (File_Name.Contains("CSW65D") && Recon_name == "CCMS OPEN ITEMS")
                            //{
                            //    File_Name = obj.GetCCMS_CSW65FileName(Directory + "Input\\Emails\\");
                            //}
                            else if (File_Name.Contains("C00039CSESB01_"))
                            {
                                File_Name = obj.GetCCASSFileName(Directory + "Input\\Emails\\");
                            }
                            else if (File_Name.Contains("B01914CSESB01_"))
                            {
                                File_Name = obj.GetCCASSBRKFileName(Directory + "Input\\Emails\\");
                            }
                            //20-07
                            else if (File_Name.Contains("HongKong_Trade_TB_OPS_DAILY_TRADE_REPORT"))
                            {
                                File_Name = obj.GetSpecificFileName_TB_OPS_DAILY_TRADE_REPORT_HK(Directory + "Input\\Emails\\");
                            }
                            else if (File_Name.Contains("TB_OPS_DAILY_TRADE_REPORT"))
                            {
                                File_Name = obj.GetSgpr_TBOPSFileName(Directory + "Input\\Emails\\");
                            }
                            else if (File_Name.Contains("IMXBP791 BR"))
                            {
                                File_Name = obj.GetSgpr_IMXBP791BRFileName(Directory + "Input\\Control D_Singapore\\");
                            }
                            else if (File_Name.Contains("IMXBP791 SUB"))
                            {
                                File_Name = obj.GetSgpr_IMXBP791SUBFileName(Directory + "Input\\Control D_Singapore\\");
                            }
                            else if (File_Name.Contains("18opxor029"))
                            {
                                File_Name = obj.GetSgpr_18opxor029FileName(Directory + "Input\\Emails\\");
                            }
                            else if (File_Name.Contains("20opxor029"))
                            {
                                File_Name = obj.GetSgpr_20opxor029FileName(Directory + "Input\\Emails\\");
                            }
                            else if (File_Name.Contains("Utilizations Data of BR 18"))
                            {
                                File_Name = obj.GetSgpr_Utilisations_18FileName(Directory + "Input\\Emails\\");
                            }
                            else if (File_Name.Contains("Utilizations Data of BR 20"))
                            {
                                File_Name = obj.GetSgpr_Utilisations_20FileName(Directory + "Input\\Emails\\");
                            }

                            // Ended By Anees...

                            // ragav 25 05 2017
                            else if (File_Name.Contains("Sophu"))
                            {
                                File_Name = obj.GetSpecificFileName_Vietnamsacom(Directory + "Input\\Emails\\");
                            }
                            // ragav 25 05 2017
                            //25-05 Kiran
                            else if (File_Name == "DD-MM-YYYY")
                            {
                                Recon_Date = obj.Get_Recon_Date(conString, Country, "dd-MM-yyyy");
                                File_Name = Recon_Date;
                            }
                            //25-05 Kiran
                            else if (Recon_name == "UAE Clearing Recon")
                            {
                                if (File_Name.Contains("IC 00"))
                                {
                                    File_Name = obj.GetFileNameUAEIC(Directory + "Input\\Ebbs_UAE\\");
                                }
                                else if (File_Name.Contains("OC 00"))
                                {
                                    File_Name = obj.GetFileNameUAEOC(Directory + "Input\\Ebbs_UAE\\");
                                }
                            }
                            //25-05 Kiran
                            else if (Recon_name == "Oman Clearing Recon")
                            {
                                if (File_Name.Contains("IC 00"))
                                {
                                    File_Name = obj.GetFileNameOMNIC(Directory + "Input\\EBBS_OMAN\\");
                                }
                                else if (File_Name.Contains("OC 00"))
                                {
                                    File_Name = obj.GetFileNameOMNOC(Directory + "Input\\EBBS_OMAN\\");
                                }
                                else if (File_Name.Contains("IR"))
                                {
                                    File_Name = obj.GetFileNameOMNOR(Directory + "Input\\EBBS_OMAN\\");
                                }
                            }
                            else if (Recon_name == "Sri Lanka - Daily NCS CDS")
                            {
                                if (File_Name.Contains("SS_LK_CUS"))
                                {
                                    File_Name = obj.GetSpecificNCSCDS(Directory + "Input\\Seccure_Srilanka\\", "SS_LK_CUS");
                                }
                                else if (File_Name.Contains("DEX_LEDG_BAL"))
                                {
                                    File_Name = obj.GetSpecificNCSCDS(Directory + "Input\\Emails\\", "DEX_LEDG_BAL");
                                }
                                else if (File_Name.Contains("SCB ANZ"))
                                {
                                    File_Name = obj.GetSpecificNCSCDS(Directory + "Input\\Emails\\", "SCB ANZ");
                                }
                                else if (File_Name.Contains("LBSCB"))
                                {
                                    File_Name = obj.GetSpecificNCSCDS(Directory + "Input\\Emails\\", "LBSCB");
                                }
                                else if (File_Name.Contains("HoldingsDet"))
                                {
                                    File_Name = obj.GetSpecificNCSCDS(Directory + "Input\\Emails\\", "HoldingsDet");
                                }
                            }
                            else if (Recon_name == "Qatar Clearing Recon")
                            {

                            }
                            else if (Recon_name == "Srilanka TLM Open Items-CA-LK-BRH-122131-LKR-CASHDROP")
                            {
                                if (File_Name.Contains("PAYMENT"))
                                {
                                    File_Name = obj.GetSpecificNCSCDS(Directory + "Input\\Emails", "PAYMENT");
                                }
                                else
                                {
                                    File_Name = obj.GetSpecificNCSCDS(Directory + "Input\\Emails", "DEPOSIT");
                                }
                            }
                            //25-05 Kiran
                            else if (Recon_name == "Jordan Clearing Recon")
                            {
                                if (File_Name.Contains("IC 00"))
                                {
                                    File_Name = obj.GetFileNameJORIC(Directory + "Input\\Ebbs_JORDAN\\");
                                }
                                else if (File_Name.Contains("OC 00"))
                                {
                                    File_Name = obj.GetFileNameJOROC(Directory + "Input\\Ebbs_JORDAN\\");
                                }
                                else if (File_Name.Contains("OR 00"))
                                {
                                    File_Name = obj.GetFileNameJOROR(Directory + "Input\\Ebbs_JORDAN\\");
                                }
                                else
                                {

                                }
                            }
                            //25-05 Kiran
                            else if (Recon_name == "Nigeria")
                            {

                                File_Name = obj.GetFileNameNigeria(Directory + "Input\\Emails\\");

                            }
                            else if (Recon_name == "CBJ")
                            {
                                File_Name = obj.GetFileNameCBJ(Directory + "Input\\Emails\\");
                            }
                            //25-05 Kiran
                            //06-03-18 Aneesh
                            else if (File_Name.Contains("Fail Trade") || (File_Name.Contains("AGREEMENT SUMMARY REPORT (TXT)_NTB") && !Recon_name.Contains("Bony and Clearstream1")))
                            {

                            }
                            //25-05 Kiran
                            else if (Recon_name == "Hong Kong Trade RPR")
                            {
                                if (File_Name.Contains("TB_OPS_DAILY_TRADE_REPORT"))
                                {
                                    File_Name = obj.GetSpecificFileName_TB_OPS_DAILY_TRADE_REPORT_HK(Directory + "Input\\Emails\\");
                                }
                            }
                            //Commented by Prakash
                            //else if (!File_Name.Contains("DD-MMM-YYYY") || !File_Name.Contains("dd-MMM-yyyy"))
                            //{

                            //    Recon_Date = obj.Get_Recon_Date(conString, Country, "dd-MM-yy").ToUpper();
                            //    File_Name = File_Name.Remove(File_Name.Length - 11);
                            //    File_Name = File_Name + Recon_Date;
                            //}

                            else if (File_Name.Contains("MONTH YYYY"))
                            {
                                System.DateTime date = System.DateTime.Today; //AddDays(-1)
                                File_Name = File_Name.Replace("MONTH YYYY", date.ToString("MMMM yyyy").ToUpper());
                            }

                            //****************************************************************************************************//

                            if (Source_App.ToUpper() == "S2BX")
                            {
                                if (!string.IsNullOrEmpty(File_Ext))
                                    Soure_Path = Directory + "Input\\s2bx\\" + "\\" + File_Name + "." + File_Ext;
                                else
                                    Soure_Path = Directory + "Input\\s2bx\\" + "\\" + File_Name;
                            }
                            else if (Source_App == "PDF_Conversion")
                            {
                                if (!string.IsNullOrEmpty(File_Ext))
                                    Soure_Path = StrDirectory + "Input\\PDF_Conversion\\" + "\\" + File_Name + "." + File_Ext;
                                else
                                    Soure_Path = StrDirectory + "Input\\PDF_Conversion\\";
                            }
                            else if (Source_App == "GenericFTP")
                            {
                                if (!string.IsNullOrEmpty(File_Ext))
                                    Soure_Path = StrDirectory + "Input\\GenericFTP\\" + "\\" + File_Name + "." + File_Ext;
                                else
                                    Soure_Path = StrDirectory + "Input\\GenericFTP\\" + File_Name;
                            }
                            else if (Source_App != "Email" && Source_App != "OpicsPVB" && Source_App != "OpicsPlus")
                            {
                                if (!string.IsNullOrEmpty(File_Ext))
                                    Soure_Path = Directory + "Input\\" + Source_App + "_" + Country + "\\" + "\\" + File_Name + "." + File_Ext;
                                else
                                    Soure_Path = Directory + "Input\\" + Source_App + "_" + Country + "\\" + "\\" + File_Name;
                            }
                            else
                            {
                                if (!string.IsNullOrEmpty(File_Ext) && !File_Ext.Contains("pdf") && !File_Ext.Contains("raw"))
                                    Soure_Path = Directory + "Input\\Emails\\" + File_Name + "." + File_Ext;
                                else
                                    Soure_Path = Directory + "Input\\Emails\\" + "\\" + File_Name;

                                if (Source_App == "OpicsPVB")
                                {
                                    if (!string.IsNullOrEmpty(File_Ext))
                                        Soure_Path = Directory + "Input\\" + Source_App + "\\" + File_Name + "." + File_Ext;
                                    else
                                        Soure_Path = Directory + "Input\\" + Source_App + "\\" + File_Name;
                                    if (Recon_name == "MXPB file")
                                    {
                                        if (!(File.Exists(Soure_Path)))
                                        {
                                            Soure_Path = Soure_Path.Replace(File_Name, File_Name + "_0");
                                        }
                                    }
                                }
                                else if (Source_App == "OpicsPlus")
                                {
                                    if (!string.IsNullOrEmpty(File_Ext))
                                        Soure_Path = Directory + "Input\\" + Source_App + "\\" + File_Name + "." + File_Ext;
                                    else
                                        Soure_Path = Directory + "Input\\" + Source_App + "\\" + File_Name;

                                }

                            }

                            Desti_Path = Directory + "Files_For_Formatting_Or_Non_Formatting\\" + Recon_name + "\\Formatting\\";
                            Output_Path = Directory + "Output\\" + Recon_name + "\\";

                            //string FileName = Soure_Path.Remove(0, Soure_Path.LastIndexOf("\\")).Replace("\\", "").Trim();

                            if (Convert.ToString(d[2]) == "RDR001D/RDRP01CB IN")
                            {
                                File_Name = "RDRP01CB IN";
                                Soure_Path = Directory + "Input\\" + Source_App + "_" + Country + "\\" + "\\" + File_Name + "." + File_Ext;
                            }


                            string FilePath = Directory + "Input\\" + Source_App + "_" + Country + "\\" + File_Name + "." + File_Ext;
                            if (File.Exists(Soure_Path))
                            {
                                if (string.IsNullOrEmpty(AutomationStatus) && AutomationStatus != "COMPLETED")
                                {
                                    cmd.Dispose();
                                    cmd = new SqlCommand("update ARC_Scope_BaseLine set IsProcessed = 1, AutomationStatus = 'COMPLETED' where Recon = '" + Recon_name + "' and Report_Source_File_Name = '" + File_Name + "'", con);
                                    con.Open();
                                    cmd.ExecuteNonQuery();
                                    con.Close();
                                }
                                File.Copy(Soure_Path, Desti_Path + File_Name + "." + File_Ext, true);
                                if (Formatted_File_Name.ToUpper() != "NA" && !string.IsNullOrEmpty(Formatted_File_Name.Trim()))
                                {

                                    string db_Ext = System.IO.Path.GetExtension(Formatted_File_Name);
                                    Formatted_File_Name = Path.GetFileNameWithoutExtension(Formatted_File_Name);
                                    if (Formatted_File_Name.Contains("DD-MMM YYYY"))
                                    {
                                        Foramtted_Recon_Date = obj.Get_Recon_Date(conString, Country, "dd-MMM yyyy");
                                        Formatted_File_Name = Formatted_File_Name.Remove(Formatted_File_Name.Length - 11);
                                        Formatted_File_Name = Formatted_File_Name + Foramtted_Recon_Date;
                                    }
                                    else if (Formatted_File_Name.Contains("DD_MM_YYYY"))
                                    {
                                        Foramtted_Recon_Date = obj.Get_Recon_Date(conString, Country, "dd_MM_yyyy");
                                        Formatted_File_Name = Formatted_File_Name.Remove(Formatted_File_Name.Length - 10);
                                        Formatted_File_Name = Formatted_File_Name + Foramtted_Recon_Date;
                                    }
                                    else if (Formatted_File_Name.Contains("DD-MMM-YY"))
                                    {
                                        Foramtted_Recon_Date = obj.Get_Recon_Date(conString, Country, "dd-MMM-yy");
                                        Formatted_File_Name = Formatted_File_Name.Replace("DD-MMM-YY", Foramtted_Recon_Date);
                                    }
                                    else if (Formatted_File_Name.Contains("DD.MM.YYYY"))
                                    {
                                        if (File_Name.Contains("AB-DETAIL_"))
                                        {
                                            Foramtted_Recon_Date = obj.GetSpecificFileNameABDETAIL(Soure_Path);
                                        }
                                        else
                                        {
                                            Foramtted_Recon_Date = obj.Get_Recon_Date(conString, Country, "dd.MM.yyyy");
                                        }
                                        Formatted_File_Name = Formatted_File_Name.Remove(Formatted_File_Name.Length - 10);
                                        Formatted_File_Name = Formatted_File_Name + Foramtted_Recon_Date;
                                    }
                                    else if (Formatted_File_Name.Contains("DDMMYYYY"))
                                    {
                                        Recon_Date = obj.Get_Recon_Date(conString, Country, "ddMMyyyy");
                                        if (File_Name.Contains("BILLING SETTLEMENT"))
                                        {
                                            Foramtted_Recon_Date = obj.Get_Recon_Date(conString, Country, "ddMMyyyy"); ;
                                            Foramtted_Recon_Date = obj.GetSettlementDateFromExcel(Soure_Path, Foramtted_Recon_Date);
                                        }
                                        else if (File_Name.Contains("ACQ SETTLEMENT"))
                                        {
                                            Foramtted_Recon_Date = obj.Get_Recon_Date(conString, Country, "ddMMyyyy"); ;
                                            Foramtted_Recon_Date = obj.GetSettlementDateFromExcel(Soure_Path, Recon_Date);
                                        }
                                        else if (File_Name.Contains("ISS SETTLEMENT"))
                                        {
                                            Foramtted_Recon_Date = obj.Get_Recon_Date(conString, Country, "ddMMyyyy"); ;
                                            Foramtted_Recon_Date = obj.GetSettlementDateFromExcel(Soure_Path, Recon_Date);
                                        }
                                        else if ((Recon_name == "NETS & Cash card Topup Settlement"))
                                        {
                                            Foramtted_Recon_Date = obj.Get_Recon_DateForNETS(Soure_Path);
                                        }
                                        else if ((Recon_name == "BAHRAIN SWITCH RECON"))
                                        {
                                            Foramtted_Recon_Date = obj.Get_Recon_DateForBahrain(Soure_Path);
                                        }
                                        else if ((Recon_name == "VIETNAM - CASH IN ATM"))
                                        {
                                            Foramtted_Recon_Date = obj.Get_Recon_DateForEASVN(Soure_Path);
                                            DateTime myDate = DateTime.ParseExact(Foramtted_Recon_Date, "yyMMdd", System.Globalization.CultureInfo.InvariantCulture);

                                            Foramtted_Recon_Date = myDate.ToString("ddMMyyyy");
                                        }
                                        else if (Recon_name == "VIETNAM - RLS RECONS")
                                        {
                                            if (File_Name.Contains("CGB570R1"))
                                            {
                                                Foramtted_Recon_Date = obj.Get_Recon_DateForCGB570R1(Soure_Path);
                                            }
                                            else if (File_Name.Contains("DIRECT_DB_CR_TRANS_GENERATION_DIRECT_DB_CR_TRANS_GENERATION"))
                                            {
                                                Foramtted_Recon_Date = obj.Get_Recon_DateForDIRECT_DB_CR_TRANS_GENERATION_DIRECT_DB_CR_TRANS_GENERATION(Soure_Path);
                                            }
                                        }
                                        else if (Recon_name == "Vietnam ACB")
                                        {
                                            Foramtted_Recon_Date = obj.Get_Recon_Date(conString, Country, "ddMMyyyy");
                                            DateTime myDate = DateTime.ParseExact(Foramtted_Recon_Date, "ddMMyyyy", System.Globalization.CultureInfo.InvariantCulture);
                                            int hol = obj.Get_HolidaysTotal(conString, Country, "ddMMyyyy");
                                            Foramtted_Recon_Date = myDate.AddDays(-hol).ToString("ddMMyyyy");

                                            Formatted_File_Name = Formatted_File_Name.Substring(0, Formatted_File_Name.Length - Foramtted_Recon_Date.Length) + Foramtted_Recon_Date;


                                        }
                                        else if (Recon_name == "Vietnam Visa TLM open items")
                                        {
                                            if (Formatted_File_Name.Contains("SCB_VISA_SWCH_DATED"))
                                            {
                                                Foramtted_Recon_Date = obj.Get_Recon_Date(conString, Country, "ddMMyyyy");
                                                Formatted_File_Name = Formatted_File_Name.Remove(Formatted_File_Name.Length - 8);
                                                Formatted_File_Name = Formatted_File_Name + Foramtted_Recon_Date;
                                            }
                                            else
                                            {
                                                Foramtted_Recon_Date = obj.Get_Recon_Date(conString, Country, "ddMMyyyy");
                                                DateTime myDate = DateTime.ParseExact(Foramtted_Recon_Date, "ddMMyyyy", System.Globalization.CultureInfo.InvariantCulture);
                                                int hol = obj.Get_HolidaysTotal(conString, Country, "ddMMyyyy");
                                                Foramtted_Recon_Date = myDate.AddDays(-hol).ToString("ddMMyyyy");

                                                Formatted_File_Name = Formatted_File_Name.Substring(0, Formatted_File_Name.Length - Foramtted_Recon_Date.Length) + Foramtted_Recon_Date;
                                            }
                                        }
                                        else if (Recon_name == "Vietnam I-banking")
                                        {
                                            if (Formatted_File_Name.Contains("BillPayment_Mobile_TopUp"))
                                            {
                                                Foramtted_Recon_Date = obj.Get_Recon_Date(conString, Country, "ddMMyyyy");
                                                DateTime myDate = DateTime.ParseExact(Foramtted_Recon_Date, "ddMMyyyy", System.Globalization.CultureInfo.InvariantCulture);
                                                int hol = obj.Get_HolidaysTotal(conString, Country, "ddMMyyyy");
                                                Foramtted_Recon_Date = myDate.AddDays(-hol).ToString("ddMMyyyy");

                                                Formatted_File_Name = Formatted_File_Name.Substring(0, Formatted_File_Name.Length - Foramtted_Recon_Date.Length) + Foramtted_Recon_Date;
                                            }
                                            else
                                            {

                                                Foramtted_Recon_Date = obj.Get_Recon_Date(conString, Country, "ddMMyyyy");
                                                Formatted_File_Name = Formatted_File_Name.Remove(Formatted_File_Name.Length - 8);
                                                Formatted_File_Name = Formatted_File_Name + Foramtted_Recon_Date;
                                            }
                                        }
                                        else if (Recon_name == "Singapore - Holdings Reconciliation")
                                        {
                                            Foramtted_Recon_Date = System.DateTime.Today.ToString("ddMMyyyy");
                                            Formatted_File_Name = Formatted_File_Name.Remove(Formatted_File_Name.Length - 8);
                                            Formatted_File_Name = Formatted_File_Name + Foramtted_Recon_Date;
                                        }
                                        else if (Recon_name == "UAE ATM RECON" && File_Name.Contains("TT464T0"))
                                        {
                                            Foramtted_Recon_Date = System.DateTime.Today.ToString("ddMMyyyy");
                                            Foramtted_Recon_Date = obj.Get_Recon_Date_UAE_ATM_TT464T0(Soure_Path);
                                            Formatted_File_Name = Formatted_File_Name.Remove(Formatted_File_Name.Length - 8);
                                            Formatted_File_Name = Formatted_File_Name + Foramtted_Recon_Date;
                                        }
                                        else if (Recon_name == "SCBMA1638" || Recon_name == "SG0000094921" || Recon_name == "TR0190033936" || Recon_name == "RBI RTGS" || Recon_name == "JP0000005862")
                                        {
                                            Foramtted_Recon_Date = obj.Get_Recon_Date_Monthly(conString, Country, "ddMMyyyy");
                                            Formatted_File_Name = Formatted_File_Name.Remove(Formatted_File_Name.Length - 8);
                                            Formatted_File_Name = Formatted_File_Name + Foramtted_Recon_Date;
                                        }
                                        else if (Recon_name == "MISC CASH PYT_RECEIPT ACCOUNT & MISC CASHIER ORDER SUSPENSE")
                                        {
                                            Foramtted_Recon_Date = DateTime.Now.ToString("ddMMyyyy");
                                            Formatted_File_Name = Formatted_File_Name.Remove(Formatted_File_Name.Length - 8);
                                            Formatted_File_Name = Formatted_File_Name + Foramtted_Recon_Date;
                                        }
                                        else if (Recon_name == "Structured Funding  - BTS VS Custody")
                                        {
                                            if (File_Name.Contains("ACBS"))
                                            {
                                                Foramtted_Recon_Date = obj.Get_Recon_Date(conString, Country, "ddMMyyyy");
                                                Formatted_File_Name = Formatted_File_Name.Remove(Formatted_File_Name.Length - 8);
                                                Formatted_File_Name = Formatted_File_Name + Foramtted_Recon_Date;
                                            }
                                        }
                                        else if (Recon_name == "BAHRAIN - Branch ATM Recon" || Recon_name == "Bahrain CDM Recon" || Recon_name == "UAE BRANCH ATM" || Recon_name == "UAE Travelex Recon")
                                        {
                                            Foramtted_Recon_Date = obj.Get_Recon_Date(conString, Country, "ddMMyyyy");
                                            Formatted_File_Name = Formatted_File_Name.Remove(Formatted_File_Name.Length - 8);
                                            Formatted_File_Name = Formatted_File_Name + Foramtted_Recon_Date;
                                        }
                                        else if (Recon_name == "Brunei Inward Clearing")
                                        {
                                            Recon_Date = DateTime.Now.ToString("ddMMyyyy");
                                            Foramtted_Recon_Date = DateTime.Now.ToString("ddMMyyyy");
                                            Formatted_File_Name = Formatted_File_Name.Remove(Formatted_File_Name.Length - 8);
                                            Formatted_File_Name = Formatted_File_Name + Foramtted_Recon_Date;
                                        }
                                        else if (Recon_name == "Kenya CUSTODY-OPICS position Fortnightly")
                                        {
                                            //DateTime myDate1 = DateTime.ParseExact(File_Name.Substring(File_Name.Length - 6, 6), "ddMMyy", System.Globalization.CultureInfo.InvariantCulture);
                                            Foramtted_Recon_Date = obj.Get_Recon_Date(conString, Country, "ddMMyyyy");
                                            Formatted_File_Name = Formatted_File_Name.Replace("DDMMYYYY", Foramtted_Recon_Date);
                                        }
                                        else if (Recon_name == "Srilanka TLM Open Items-CA-LK-BRH-122131-Email")
                                        {
                                            DateTime myDate1 = DateTime.ParseExact(File_Name.Substring(3, 6), "yyMMdd", System.Globalization.CultureInfo.InvariantCulture);
                                            Foramtted_Recon_Date = myDate1.ToString("ddMMyyyy");
                                            Formatted_File_Name = Formatted_File_Name.Replace("DDMMYYYY", Foramtted_Recon_Date);
                                        }
                                        else
                                        {
                                            Foramtted_Recon_Date = obj.Get_Recon_Date(conString, Country, "ddMMyyyy");
                                            Formatted_File_Name = Formatted_File_Name.Remove(Formatted_File_Name.Length - 8);
                                            Formatted_File_Name = Formatted_File_Name + Foramtted_Recon_Date;
                                        }
                                    }
                                    else if (Formatted_File_Name.Contains("MMDDYYYY"))
                                    {
                                        if (Recon_name == "Nigeria")
                                        {
                                            Foramtted_Recon_Date = obj.Get_Recon_Date(conString, Country, "MMddyyyy");
                                            Formatted_File_Name = Formatted_File_Name.Substring(0, 9) + Foramtted_Recon_Date + Formatted_File_Name.Substring(Formatted_File_Name.Length - 15, 15);

                                        }
                                        else
                                        {
                                            Foramtted_Recon_Date = obj.Get_Recon_Date(conString, Country, "MMddyyyy");
                                            Formatted_File_Name = Formatted_File_Name.Remove(Formatted_File_Name.Length - 8);
                                            Formatted_File_Name = Formatted_File_Name + Foramtted_Recon_Date;
                                        }
                                    }
                                    else if (Formatted_File_Name.Contains("DDMMYY"))
                                    {
                                        if (Recon_name == "RBI RTGS")
                                        {
                                            Foramtted_Recon_Date = obj.Get_Recon_Date_Monthly(conString, Country, "ddMMyy");
                                            Formatted_File_Name = Formatted_File_Name.Replace("DDMMYY", Foramtted_Recon_Date);
                                        }
                                        else
                                        {
                                            Foramtted_Recon_Date = obj.Get_Recon_Date(conString, Country, "ddMMyy");
                                            Formatted_File_Name = Formatted_File_Name.Remove(Formatted_File_Name.Length - 6);
                                            Formatted_File_Name = Formatted_File_Name + Foramtted_Recon_Date;
                                        }
                                    }
                                    else if (Formatted_File_Name.ToUpper().Contains("YYYYMMDD") || Formatted_File_Name.Contains("yyyyMMdd"))
                                    {
                                        if (ts.Days > 1 && (Recon_name == "Zimbabwe FX Recon_Zimbabwe FXR Adjustments") || (Recon_name == "Kenya FX Recon_Kenya FXR Adjustments") || (Recon_name == "Uganda FX Recon_Uganda FXR Adjustments") || (Recon_name == "TANZANIA FX RECON_TANZANIA FXR Adjustments") || (Recon_name == "Botswana FX Recon_Botswana FXR Adjustments"))
                                        {
                                            Foramtted_Recon_Date = obj.Get_Recon_Date_For_Monday_Logic(conString, Country, "yyyyMMdd");
                                            Formatted_File_Name = Formatted_File_Name.Remove(Formatted_File_Name.Length - 8);
                                            Formatted_File_Name = Formatted_File_Name + Foramtted_Recon_Date;
                                        }
                                        else if (Recon_name == "Nigeria")
                                        {
                                            Foramtted_Recon_Date = obj.Get_Recon_Date_For_Monday_Logic(conString, Country, "yyyyMMdd");
                                            Formatted_File_Name = Formatted_File_Name.Substring(0, 9) + Foramtted_Recon_Date + Formatted_File_Name.Substring(Formatted_File_Name.Length - 11, 11);

                                        }
                                        else if (Recon_name == "Bony and Clearstream2")
                                        {
                                            if (Formatted_File_Name.Contains("PSGL_CUS_"))
                                            {
                                                Recon_Date = obj.Get_Recon_Date(conString, Country, "yyyyMMdd");
                                                Foramtted_Recon_Date = obj.Get_Recon_Date(conString, Country, "yyyyMMdd");
                                                File_Name = obj.BonyClearalloc(StrDirectory + "Input\\Emails") + ".pdduz";
                                                Formatted_File_Name = Formatted_File_Name.Replace("YYYYMMDD", Foramtted_Recon_Date);
                                            }

                                        }
                                        else if (Recon_name == "Bony and Clearstream3")
                                        {
                                            if (Formatted_File_Name.Contains("PSGL_CUS_"))
                                            {
                                                Recon_Date = obj.Get_Recon_Date(conString, Country, "yyyyMMdd");
                                                Foramtted_Recon_Date = obj.Get_Recon_Date(conString, Country, "yyyyMMdd");
                                                File_Name = File_Name.Replace("YYYYMMDD", Foramtted_Recon_Date);
                                                Formatted_File_Name = Formatted_File_Name.Replace("YYYYMMDD", Foramtted_Recon_Date);
                                            }

                                        }
                                        ////25-05 Kiran
                                        //else if (Recon_name == "Bony and Clearstream")
                                        //{
                                        //    if (Formatted_File_Name.Contains("PSGL_CUS_"))
                                        //    {
                                        //        Foramtted_Recon_Date = obj.Get_Recon_Date_For_Monday_Logic(conString, Country, "yyyyMMdd");
                                        //        Formatted_File_Name = Formatted_File_Name.Substring(0, 9) + Foramtted_Recon_Date + Formatted_File_Name.Substring(Formatted_File_Name.Length - 11, 11);
                                        //    }
                                        //    else
                                        //    {
                                        //        Foramtted_Recon_Date = obj.Get_Recon_Date(conString, Country, "yyyyMMdd");
                                        //        Formatted_File_Name = Formatted_File_Name.Remove(Formatted_File_Name.Length - 8);
                                        //        Formatted_File_Name = Formatted_File_Name + Foramtted_Recon_Date;
                                        //    }
                                        //}
                                        else if (Recon_name == "RBI RTGS")
                                        {
                                            DateTime myDate1 = DateTime.ParseExact(File_Name.Substring(8, 6), "ddMMyy", System.Globalization.CultureInfo.InvariantCulture);
                                            Formatted_File_Name = Formatted_File_Name.Substring(0, 13) + myDate1.ToString("ddMMyyyy");

                                        }
                                        else if (Recon_name == "Malaysia - MCD Recon")
                                        {
                                            DateTime myDate1 = DateTime.ParseExact(File_Name.Substring(13, 8), "ddMMyyyy", System.Globalization.CultureInfo.InvariantCulture);
                                            Formatted_File_Name = Formatted_File_Name.Replace("YYYYMMDD", myDate1.ToString("yyyyMMdd"));

                                        }
                                        else if (Recon_name == "Malaysia - MCD Recon-Monthly")
                                        {
                                            DateTime myDate1 = DateTime.ParseExact(File_Name.Substring(File_Name.Length - 8, 8), "ddMMyyyy", System.Globalization.CultureInfo.InvariantCulture);
                                            Formatted_File_Name = Formatted_File_Name.Replace("YYYYMMDD", myDate1.ToString("yyyyMMdd"));

                                        }
                                        else if (Recon_name == "CBJ")
                                        {
                                            string q = File_Name.Substring(File_Name.Length - 11, 11);
                                            DateTime myDate1 = DateTime.ParseExact(q, "dd MMM yyyy", System.Globalization.CultureInfo.InvariantCulture);
                                            Formatted_File_Name = Formatted_File_Name.Replace("YYYYMMDD", myDate1.ToString("yyyyMMdd"));

                                        }
                                        else if (Recon_name == "NSE-CURR FUT-NSE-CURR FUT -PD")
                                        {
                                            string q = File_Name.Substring(File_Name.Length - 8, 8);
                                            DateTime myDate1 = DateTime.ParseExact(q, "ddMMyyyy", System.Globalization.CultureInfo.InvariantCulture);
                                            Formatted_File_Name = Formatted_File_Name.Replace("YYYYMMDD", myDate1.ToString("yyyyMMdd"));
                                        }
                                        //17-01
                                        //Foramtted_Recon_Date = obj.Get_Recon_Date_Monthly(conString, Country, "dd.MMM.yyyy");
                                        else if (Recon_name == "BANK OF ENGLAND" || Recon_name == "DFLT-FXSETT-PD" || Recon_name == "Demat Custody" || Recon_name == "EUROCLEAR" || Recon_name == "CC-RSIRSDFLT-PD" || Recon_name == "Africa Custody-Opics Position weekly" || Recon_name == "Africa Custody-Opics Position weekly1" || Recon_name == "HK0000112791" || Recon_name == "HK0000112831" || Recon_name == "RBC Limited" || Recon_name == "Hong Kong Monthly Unit Trust" || Recon_name == "GM POS CUST" || Recon_name == "IC Pos Cust" || Recon_name == "SCBDT1398" || Recon_name == "DFLT-SEC-PD")
                                        {
                                            Foramtted_Recon_Date = obj.Get_Recon_Date_Monthly(conString, Country, "yyyyMMdd");
                                            Formatted_File_Name = Formatted_File_Name.Replace("YYYYMMDD", Foramtted_Recon_Date);
                                        }
                                        else if (Recon_name == "Kenya CUSTODY-OPICS position Fortnightly")
                                        {
                                            Foramtted_Recon_Date = obj.Get_Recon_Date_Monthly(conString, Country, "yyyyMMdd");
                                            Formatted_File_Name = Formatted_File_Name.Replace("YYYYMMDD", Foramtted_Recon_Date);
                                        }
                                        else if (Recon_name == "Srilanka TLM Open Items-CA-LK-BRH-122131-Email")
                                        {

                                            Formatted_File_Name = Formatted_File_Name.Replace("YYYYMMDD", Foramtted_Recon_Date);
                                        }
                                        else
                                        {
                                            Foramtted_Recon_Date = obj.Get_Recon_Date(conString, Country, "yyyyMMdd");
                                            Formatted_File_Name = Formatted_File_Name.Remove(Formatted_File_Name.Length - 8);
                                            Formatted_File_Name = Formatted_File_Name + Foramtted_Recon_Date;
                                        }

                                    }

                                    string temp_FileName = "";
                                    string temp_FileNamehalf = "";
                                    //31-08
                                    if (Recon_name == "India - CMPC Suspense" || Recon_name == "MXG - sabre" || Recon_name == "Malaysia Other AA Codes" || Recon_name == "India - RBI Main Account" || Recon_name == "Vietnam - Open Item" || Recon_name == "India - RBI RTGS Account" || Recon_name == "UK cls" || Recon_name == "Jordan Clearing Recon" || Recon_name == "Nigeria" || Recon_name == "UAE Clearing Recon" || Recon_name == "RBI RTGS" || Recon_name == "Singapore-Monthly Unit Trust" || Recon_name == "HongKong-Monthly Unit Trust" || Recon_name == "Philippines - BSP DDA RECON (Manual recon - CB recon eBBS Vs. CB statements)" || Recon_name == "Sri Lanka - Daily NCS CDS" || Recon_name == "BTS Vs Martini Trade (MOC -FMSO-BTS Vs Martini Trade)" || Recon_name == "JERSEY WEEKLY BBH RECON" || Recon_name == "Malaysia - MCD Recon" || Recon_name == "Malaysia - MCD Recon-Monthly" || Recon_name == "BANK OF ENGLAND" || Recon_name == "BNCA CLMBA COP-LK0000006596" || Recon_name == "HK0000112831" || Recon_name == "GM POS CUST" || Recon_name == "DFLT-FXSETT-PD" || Recon_name == "Demat Custody" || Recon_name == "EUROCLEAR" || Recon_name == "CC-RSIRSDFLT-PD" || Recon_name == "Africa Custody-Opics Position weekly" || Recon_name == "Africa Custody-Opics Position weekly1" || Recon_name == "HK0000112791" || Recon_name == "Kenya CUSTODY-OPICS position Fortnightly" || Recon_name == "Structured Funding  - BTS VS Custody" || Recon_name == "RBC Limited" || Recon_name == "IC Pos Cust" || Recon_name == "SCBDT1398" || Recon_name == "DFLT-SEC-PD" || Recon_name == "Singapore Third party Cash" || Recon_name == "Singapore Failed Trade Online" || Recon_name == "BAHRAIN - Branch ATM Recon" || Recon_name == "Kenya - VISA Electron DR.Card Suspense AC Recon KES USD GBP EUR YEN and Outstanding Report" || Recon_name == "GenericFTP")
                                    {
                                        temp_FileName = Formatted_File_Name + db_Ext; //Changed this-Prakash-> temp_FileName = temp_FileName + "_" + Recon_Date + "." + File_Ext; 
                                    }
                                    //06-03
                                    else if (Recon_name == "PVB HONGKONG - MONTHLY")
                                    {
                                        Foramtted_Recon_Date = obj.Get_Recon_Date_Monthly(conString, Country, "ddMMyyyy");
                                        Formatted_File_Name = Formatted_File_Name.Substring(0, Formatted_File_Name.Length - 8) + Foramtted_Recon_Date;
                                        Formatted_File_Name = Formatted_File_Name + db_Ext;
                                    }
                                    else if (Recon_name == "JP0000005862")
                                    {
                                        Foramtted_Recon_Date = obj.Get_Recon_Date_Monthly(conString, Country, "dd.MMM.yyyy");
                                        string dt = Foramtted_Recon_Date.Substring(3, 8);
                                        Formatted_File_Name = Formatted_File_Name.Replace("MMM.YYYY", dt);
                                        Formatted_File_Name = Formatted_File_Name + db_Ext;
                                    }
                                    else
                                    {
                                        temp_FileName = Formatted_File_Name.Substring(0, Formatted_File_Name.LastIndexOf("_"));
                                        temp_FileNamehalf = temp_FileName + "_";
                                        temp_FileName = temp_FileName + "_" + Foramtted_Recon_Date + db_Ext; //Changed this-Prakash-> temp_FileName = temp_FileName + "_" + Recon_Date + "." + File_Ext; 
                                    }
                                    //------------------------------------- OLD -------
                                    //File.Copy(Soure_Path, Output_Path + File_Name + "." + File_Ext, true);

                                    if (Recon_name == "Singapore SEC RPR")
                                    {
                                        DataTable dt = obj.Formatting_Singapore_SSC(Convert.ToString(d[2]), Soure_Path);
                                        Formatting_SG_SEC_RPR_Signs(dt);
                                        dt_Final.Merge(dt);
                                        For_Counter++;
                                    }
                                    //31-08
                                    else if (Recon_name == "MXPB file")
                                    {
                                        obj.MXPB(Soure_Path, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, File_Name, File_Ext);
                                        For_Counter++;
                                    }
                                    else if (Recon_name == "RBC Limited")
                                    {
                                        Recon_Date = obj.Get_Recon_Date_Monthly(conString, Country, "yyyyMMdd");
                                        obj.RBC_Limited(Soure_Path, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, File_Name, File_Ext);
                                        For_Counter++;
                                    }
                                    else if (Recon_name == "India Failed Trade")
                                    {
                                        if (File_Name.Contains("IndiaFailTrade1"))
                                        {
                                            obj.India_Failed_Trade(Soure_Path, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, File_Name, File_Ext, out FlagIndiaFT_Recon);
                                            if (FlagIndiaFT_Recon == true)
                                            {
                                                For_Counter = For_Counter + 7;
                                            }
                                        }
                                    }
                                    else if (Recon_name == "IC Pos Cust")
                                    {
                                        Recon_Date = obj.Get_Recon_Date_Monthly(conString, Country, "yyyyMMdd");
                                        obj.ICPOS_CUS(Soure_Path, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, File_Name, File_Ext);
                                        For_Counter++;
                                    }
                                    else if (Recon_name == "GenericFTP")
                                    {
                                        Recon_Date = obj.Get_Recon_Date(conString, Country, "yyyyMMdd");
                                        obj.GenericFTP(Soure_Path, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, File_Name, File_Ext);
                                        For_Counter++;
                                    }
                                    else if (Recon_name == "SCBDT1398")
                                    {
                                        Recon_Date = obj.Get_Recon_Date_Monthly(conString, Country, "dd/MM/yyyy");
                                        obj.SCBDT1398(Soure_Path, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, File_Name, File_Ext);
                                        For_Counter++;
                                    }
                                    else if (Recon_name == "Singapore Third party Cash")
                                    {
                                        if (File_Name.Contains("MT950"))
                                        {
                                            Recon_Date = obj.Get_Recon_Date(conString, Country, "ddMMyyyy");
                                            obj.Singapore_Third_Party_Cash(Soure_Path, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, File_Name, File_Ext);
                                            For_Counter = For_Counter + 7;
                                        }
                                    }
                                    else if (Recon_name == "DFLT-SEC-PD")
                                    {
                                        Recon_Date = obj.Get_Recon_Date_Monthly(conString, Country, "dd/MM/yyyy");
                                        obj.DFLT_SEC_PD(Soure_Path, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, File_Name, File_Ext);
                                        For_Counter++;
                                    }
                                    else if (Recon_name == "Srilanka TLM Open Items-CA-LK-BRH-122131-Email")
                                    {
                                        obj.Srilanka_TLM_Open_Items_122131_Email(Soure_Path, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, File_Name, File_Ext);
                                        For_Counter++;
                                    }
                                    else if (Recon_name == "Structured Funding  - BTS VS Custody")
                                    {
                                        if (File_Name.Contains("ACBS"))
                                        {
                                            obj.StructuredFundingRecon(Soure_Path, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, File_Name, File_Ext, Directory);
                                            For_Counter = For_Counter + 17;
                                        }
                                    }
                                    else if (Recon_name == "Singapore - Prepaid")
                                    {
                                        if (temp_FileName.Contains("RPBK014_SG"))
                                        {
                                            obj.RPBK014_SG(Soure_Path, Output_Path, (Output_Path.Trim() + temp_FileName));
                                            For_Counter++;
                                        }
                                        else if (temp_FileName.Contains("RPCH014_SG"))
                                        {
                                            obj.RPCH014_SG(Soure_Path, Output_Path, (Output_Path + temp_FileName));
                                            For_Counter++;
                                        }
                                    }
                                    //31-08
                                    else if (Recon_name == "MXG - sabre")
                                    {

                                        if (temp_FileName.Contains("MXG-SABRE") && !temp_FileName.Contains("MXG-SABRE as of 1-") && !temp_FileName.Contains("MXG-SABRE as of 2-") && !temp_FileName.Contains("MXG-SABRE as of 3-"))
                                        {
                                            obj.MXGsabre(Soure_Path, Output_Path, (Output_Path.Trim() + temp_FileName), out dt_MX1);
                                            For_Counter++;
                                        }
                                        else if (temp_FileName.Contains("MXG-SABRE as of 1-"))
                                        {
                                            obj.MXGsabre1(Soure_Path, Output_Path, (Output_Path.Trim() + temp_FileName), out dt_MX2);
                                            For_Counter++;
                                        }
                                        else if (temp_FileName.Contains("MXG-SABRE as of 2-"))
                                        {
                                            obj.MXGsabre2(Soure_Path, Output_Path, (Output_Path.Trim() + temp_FileName), out dt_MX3);
                                            For_Counter++;
                                        }
                                        else if (temp_FileName.Contains("MXG-SABRE as of 3-"))
                                        {
                                            obj.MXGsabre3(Soure_Path, Output_Path, (Output_Path.Trim() + temp_FileName), out dt_MX4);
                                            obj.MXGsabre_Consolidated((Output_Path.Trim() + temp_FileName.Replace("3-", "")), dt_MX1, dt_MX2, dt_MX3, dt_MX4);
                                            For_Counter++;
                                        }
                                    }
                                    else if (Recon_name == "Hong Kong LPU RPR")
                                    {
                                        DataTable dt = obj.Formatting_HongKong_LPU(Convert.ToString(d[2]), Soure_Path);
                                        Formatting_SG_SEC_RPR_Signs(dt);
                                        dt_Final.Merge(dt);
                                        For_Counter++;

                                        if (For_Counter == dr2.Length)
                                        {
                                            dt_Final.Rows.Add("NULL");
                                        }
                                    }
                                    else if (Recon_name == "MAURITIUS - DAILY RECON")
                                    {
                                        obj.MAURITIUS_Stock_Formatting(Soure_Path, (Output_Path + temp_FileName));
                                        SqlCommand Updt_cmd2 = new SqlCommand("update ARC_Recon_Master set Is_Recon_Completed = 1, Recon_Status = 'COMPLETED', PSID = '" + Environment.UserName + "' where Recon_Id = " + Recon_Id + "", con);
                                        con.Open();
                                        Updt_cmd2.ExecuteNonQuery();
                                        con.Close();
                                    }
                                    //added By Anees...
                                    else if (Recon_name == "MISC CASH PYT_RECEIPT ACCOUNT & MISC CASHIER ORDER SUSPENSE")//TEMPORY RECON NAME ANEES 
                                    {
                                        //Commented By aneesh--03-05-18
                                        Recon_Date = obj.Get_Recon_Date(conString, Country, "dd-MM-yyyy");
                                        string Output_Dir = Directory + "Input\\Crystal Report\\" + Country + "\\";
                                        bool count_check = false;
                                        //obj.MISC_Cash_PYT_SUSPENSE(Soure_Path, Output_Dir, Output_Path, (Output_Path + temp_FileName), Recon_name, Recon_Date, Formatted_File_Name, temp_FileName);
                                        obj.MISC_Cash_PYT_SUSPENSE_UPD(conString, Soure_Path, Output_Dir, Output_Path, (Output_Path + temp_FileName), Recon_name, Recon_Date, Formatted_File_Name, temp_FileName, out count_check);
                                        if (count_check == true)
                                        {
                                            For_Counter++;
                                        }
                                    }
                                    else if (Recon_name == "CO DISPOSAL")//TEMPORY RECON NAME ANEES 
                                    {
                                        //Commited By Aneesh 03-05-18
                                        string Output_Dir = Directory + "Input\\Crystal Report\\" + Country + "\\";
                                        if (temp_FileName.Contains("PSGL_312900001171"))
                                        {
                                            //obj.CO_Disposal_04587(Soure_Path, Output_Dir, Output_Path, (Output_Path + temp_FileName), Recon_name, Recon_Date, Formatted_File_Name, temp_FileName);
                                            obj.CO_Disposal_04587_UPD(conString, Soure_Path, Output_Dir, Output_Path, (Output_Path + temp_FileName), Recon_name, Recon_Date, Formatted_File_Name, temp_FileName);
                                            For_Counter++;
                                        }
                                        else
                                        {
                                            //obj.CO_Disposal_04536(Soure_Path, Output_Dir, Output_Path, (Output_Path + temp_FileName), Recon_name, Recon_Date, Formatted_File_Name, temp_FileName);
                                            obj.CO_Disposal_04536_UPD(conString, Soure_Path, Output_Dir, Output_Path, (Output_Path + temp_FileName), Recon_name, Recon_Date, Formatted_File_Name, temp_FileName);
                                            For_Counter++;
                                        }
                                    }
                                    else if (Recon_name == "Srilanka TLM Open Items-CA-LK-BRH-122131-LKR-CASHDROP")
                                    {
                                        if (File_Name.Contains("PAYMENT"))
                                        {
                                            Recon_Date = obj.Get_Recon_Date(conString, Country, "dd/MM/yyyy");
                                            obj.SRILANKATLM_CASHDROP_New(Soure_Path, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, File_Name, File_Ext, Soure_Path);
                                            For_Counter = For_Counter + 2;
                                        }
                                    }
                                    else if (Recon_name == "GIRO SUSPENSE")//TEMPORY RECON NAME ANEES 
                                    {
                                        //Commited By Aneesh --03-05-18
                                        string Output_Dir = Directory + "Input\\Crystal Report\\" + Country + "\\";
                                        if (Soure_Path.Contains("Inward"))
                                        {
                                            bool check_count = false;
                                            //obj.Giro(Soure_Path, Output_Dir, Output_Path, (Output_Path + temp_FileName), Recon_name, Recon_Date, Formatted_File_Name, temp_FileName);
                                            obj.Giro_UPD(conString, Soure_Path, Output_Dir, Output_Path, (Output_Path + temp_FileName), Recon_name, Recon_Date, Formatted_File_Name, temp_FileName, out check_count);
                                            if (check_count == true)
                                            {
                                                For_Counter++;
                                            }
                                        }
                                        else if (Soure_Path.Contains("Outward"))
                                        {
                                            For_Counter++;
                                        }
                                    }
                                    else if (Recon_name == "BAHRAIN - Branch ATM Recon")
                                    {
                                        if (Soure_Path.Contains("SBHA"))
                                        {
                                            obj.BAH_Br_ATM(Soure_Path, Output_Path, (Output_Path + temp_FileName), Recon_name, Recon_Date, Formatted_File_Name, temp_FileName);
                                            For_Counter++;
                                        }
                                    }
                                    else if (Recon_name == "Bahrain CDM Recon")
                                    {
                                        if (Soure_Path.Contains("SBHA"))
                                        {
                                            obj.BAH_CDM_ATM(Soure_Path, Output_Path, (Output_Path + temp_FileName), Recon_name, Recon_Date, Formatted_File_Name, temp_FileNamehalf);
                                            For_Counter++;
                                        }
                                    }
                                    else if (Recon_name == "UAE BRANCH ATM")
                                    {
                                        if (Soure_Path.Contains("EASAE"))
                                        {
                                            obj.UAE_BRH_ATM(Soure_Path, Output_Path, (Output_Path + temp_FileName), Recon_name, Recon_Date, Formatted_File_Name, temp_FileNamehalf);
                                            For_Counter++;
                                        }
                                    }
                                    else if (Recon_name == "UAE Travelex Recon")
                                    {
                                        if (Soure_Path.Contains("TRAVELEX_LITE_UAE_NEW"))
                                        {
                                            obj.UAE_TRV_RCN(Soure_Path, Output_Path, (Output_Path + temp_FileName), Recon_name, Recon_Date, Formatted_File_Name, temp_FileNamehalf);
                                            For_Counter++;
                                        }
                                    }
                                    else if (Recon_name == "PVB SINGAPORE - MONTHLY")
                                    {
                                        if (File_Name.Contains("Security_Position_PVB"))
                                        {
                                            Recon_Date = obj.Get_Recon_Date_Monthly(conString, Country, "ddMMyyyy");
                                            obj.PVB_Singapore(Soure_Path, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, File_Name, File_Ext);
                                            For_Counter++;
                                        }
                                    }
                                    else if (Recon_name == "PVB HONGKONG - MONTHLY")
                                    {
                                        Recon_Date = obj.Get_Recon_Date(conString, Country, "ddMMyyyy");
                                        string s = Formatted_File_Name.Substring(0, Formatted_File_Name.Length - 12) + Recon_Date + ".csv";
                                        obj.PVB_UKNew(Soure_Path, Recon_Date, Desti_Path, Recon_name, Output_Path, s, File_Name, File_Ext);
                                        For_Counter++;
                                    }
                                    else if (Recon_name == "NSE-CURR FUT-NSE-CURR FUT -PD")
                                    {
                                        obj.NSECURR(Soure_Path, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, File_Name, File_Ext);
                                        For_Counter++;
                                    }
                                    else if (Recon_name == "Hong Kong Monthly Unit Trust")
                                    {
                                        obj.HK_MonthlyunitTrust(Soure_Path, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, File_Name, File_Ext);
                                        For_Counter++;
                                    }
                                    else if (Recon_name == "JERSEY WEEKLY BBH RECON")
                                    {
                                        if (File_Name.Contains("Clearstream"))
                                        {
                                            obj.JerseyBBH(Soure_Path, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, File_Name, File_Ext, StrDirectory);
                                            For_Counter = For_Counter + 4;
                                        }
                                    }
                                    else if (Recon_name == "Nigeria – Mobile Money open items report")
                                    {
                                        //Commented by Harita --03-05-18
                                        //obj.nigeria_mobile_money(Soure_Path, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, File_Name, File_Ext);
                                        //For_Counter++;

                                        int flag = 0;
                                        obj.nigeria_mobile_money_NEW(conString, Soure_Path, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, File_Name, File_Ext, out flag);
                                        if (flag > 0)
                                        {
                                            For_Counter++;
                                        }
                                    }
                                    else if (Recon_name == "Indonesia Failed Trade online")
                                    {
                                        Recon_Date = obj.Get_Recon_Date(conString, Country, "ddMMyyyy");
                                        obj.Indonesia_FailedTrade_Online(Soure_Path, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, File_Name, File_Ext);
                                        For_Counter++;
                                    }
                                    //else if (Recon_name == "Singapore Failed Trade")
                                    //{
                                    //    string Output_Dir = Directory + "Input\\Murex_Singapore\\";
                                    //    if (Soure_Path.Contains("PSGL_SGP_FAIL_TRADE_BAL_287"))
                                    //    {
                                    //        obj.Singapore_FailedTrade(Soure_Path, Recon_Date, Output_Dir, Recon_name, Output_Path, Formatted_File_Name, File_Name, File_Ext);
                                    //        For_Counter++;
                                    //    }
                                    //    else if (Soure_Path.Contains("PSGL_SGP_FAIL_TRADE_BAL_287"))
                                    //    {
                                    //        obj.Singapore_FailedTrade(Soure_Path, Recon_Date, Output_Dir, Recon_name, Output_Path, Formatted_File_Name, File_Name, File_Ext);
                                    //        For_Counter++;
                                    //    }
                                    //}
                                    //Need to change local paths after db is updated
                                    else if (Recon_name == "Philippines - BSP DDA RECON (Manual recon - CB recon eBBS Vs. CB statements)")
                                    {
                                        //obj.Philippines_BSP_DDA(Soure_Path, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, File_Name, File_Ext);
                                        For_Counter++;
                                    }
                                    else if (Recon_name == "Malaysia - Inward   Outward clearing")
                                    {
                                        if (File_Name.Contains("ICCNU"))
                                        {
                                            string sm = obj.Get_Recon_Date(conString, Country, "ddMMyyyy"); //Recon_Date = obj.Get_Recon_Date(conString, Country, "ddMMyyyy");
                                            obj.Malaysia_IWOW1(Soure_Path, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, File_Name, File_Ext, sm, Directory);
                                            For_Counter = For_Counter + 2;
                                        }
                                        else if (File_Name.Contains("RPT_TRANSACTION_LISTING"))
                                        {
                                            string sm = obj.Get_Recon_Date(conString, Country, "ddMMyyyy");
                                            Formatted_File_Name = Formatted_File_Name.Substring(0, Formatted_File_Name.Length - 8) + sm + ".csv";
                                            obj.RBIRTGS(Soure_Path, Desti_Path + Recon_name + "\\" + Formatted_File_Name, Formatted_File_Name, Output_Path);
                                            For_Counter++;
                                        }
                                        //RBIRTGS

                                    }
                                    else if (Recon_name == "CBJ")
                                    {
                                        Recon_Date = obj.Get_Recon_Date_Monthly(conString, Country, "dd/MM/yyyy");

                                        obj.CBJ(Soure_Path, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, File_Name, File_Ext);
                                        For_Counter++;
                                    }
                                    else if (Recon_name == "BNCA CLMBA COP-LK0000006596")
                                    {
                                        if (File_Name.Contains("LKR_BI"))
                                        {
                                            Recon_Date = obj.Get_Recon_Date_Monthly(conString, Country, "dd/MM/yyyy");
                                            obj.BNCA_CLMBA_COP(Soure_Path, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, File_Name, File_Ext);
                                            For_Counter = For_Counter + 2;
                                        }
                                    }
                                    else if (Recon_name == "PVB UNITED KINGDOM - MONTHLY")
                                    {
                                        if (File_Name.Contains("Security_Position_PVB_UK"))
                                        {
                                            obj.PVB_UKNew(Soure_Path, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, File_Name, File_Ext);
                                            For_Counter++;
                                        }
                                    }
                                    else if (Recon_name == "Sri Lanka - Daily NCS CDS")
                                    {
                                        if (File_Name.Contains("HoldingsDet"))
                                        {
                                            obj.LK_NCS_CDS(Soure_Path, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, File_Name, File_Ext, StrDirectory);
                                            For_Counter = For_Counter + 5;
                                        }
                                    }

                                    else if (Recon_name == "JORDON BONDS")
                                    {
                                        obj.Jordan_Bonds(Soure_Path, Recon_Date, Output_Path, Recon_name, Output_Path, Formatted_File_Name, File_Name, db_Ext);
                                        For_Counter++;
                                    }
                                    //14-03
                                    else if (Recon_name == "Nepal Account Balance (BOI)")
                                    {
                                        obj.NEPAL_BOI(Soure_Path, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, File_Name, File_Ext);
                                        For_Counter++;
                                    }

                                    else if (Recon_name == "Brunei Inward Clearing")
                                    {
                                        if (File_Name.Contains("PGINW_"))
                                        {
                                            bool isValid = obj.Brunei_Inward(Soure_Path, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, File_Name, File_Ext);
                                            if (isValid)
                                                For_Counter = For_Counter + 3;
                                        }
                                    }
                                    else if (Recon_name == "BTS Vs Martini Trade (MOC -FMSO-BTS Vs Martini Trade)")
                                    {
                                        obj.BTS_Martini(Soure_Path, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, File_Name, File_Ext);
                                        For_Counter++;
                                    }
                                    else if (Recon_name == "Singapore-Monthly Unit Trust" || Recon_name == "HongKong-Monthly Unit Trust")
                                    {
                                        obj.Singapore_Monthly_Trust(Soure_Path, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, File_Name, File_Ext);
                                        For_Counter++;
                                    }
                                    else if (Recon_name == "Srilanka TLM Open Items-CA-LK-BRH-170254-LKR-KEELYS (W-M)")
                                    {
                                        if (Formatted_File_Name.Contains("PSGL_170255_BRK_"))
                                        {
                                            obj.SRILANKATLM_KEELS(Soure_Path, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, File_Name, File_Ext, Directory);
                                            For_Counter++;
                                        }
                                    }
                                    else if (Recon_name == "Srilanka TLM Open Items-CA-LK-BRH-170254-LKR-LANKA BELL (PD)")
                                    {
                                        if (Formatted_File_Name.Contains("LK_LANKABELL"))
                                        {
                                            //Commented by Harita--03-05-18
                                            //obj.SRILANKATLM_LANKABELL(Soure_Path, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, File_Name, File_Ext, Directory);
                                            //For_Counter++;


                                            int check_count = 0;
                                            obj.SRILANKATLM_LANKABELL_NEW(conString, Soure_Path, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, File_Name, File_Ext, Directory, out check_count);
                                            if (check_count > 0)
                                            {
                                                For_Counter++;
                                            }
                                        }
                                    }
                                    else if (Recon_name == "GHANA INWARD CLEARING")//TEMPORY RECON NAME ANEES 
                                    {
                                        if (temp_FileName.Contains("SCB_GHA_CLG_EBS"))
                                        {
                                            string Output_Dir = Directory + "Input\\Crystal Report\\" + Country + "\\";
                                            obj.GHANA_INWARD_CLEARING(Soure_Path, Output_Path, (Output_Path + temp_FileName), Output_Dir);
                                            For_Counter++;
                                        }
                                        else if (temp_FileName.Contains("SCB_GHA_CLG_CB"))
                                        {
                                            string Output_Dir = Directory + "Input\\Crystal Report\\" + Country + "\\";
                                            obj.GHANA_INWARD_CLEARING01(Soure_Path, Output_Path, (Output_Path + temp_FileName), Output_Dir);
                                            For_Counter++;
                                        }
                                    }
                                    else if (Recon_name == "INDONESIA CARDS - BATCH 2 REPORT-INET")//TEMPORY RECON NAME ANEES 
                                    {
                                        if (temp_FileName.Contains("CBINDONESIA_ELEC"))
                                        {
                                            obj.Indonesia_Batch2Report_ELEC(Soure_Path, (Output_Path + temp_FileName), Recon_Date);
                                            //temp_FileName = temp_FileName.Replace("ELEC", "POS");                                            
                                            For_Counter++;
                                        }
                                        else if (temp_FileName.Contains("CBINDONESIA_POS"))
                                        {
                                            obj.Indonesia_Batch2Report_POS(Soure_Path, (Output_Path + temp_FileName));
                                            For_Counter++;
                                        }
                                    }
                                    else if (Recon_name == "INDONESIA CARDS - BATCH 2 REPORT-SCBNET")
                                    {
                                        if (temp_FileName.Contains("CBINDONESIA_SCBNET_ACQ_") || temp_FileName.Contains("CBINDONESIA_SCBNET_ISS"))
                                        {
                                            Recon_Date = obj.Get_Recon_Date(conString, Country, "ddMMyy");
                                            string SFTP_Dir = Directory + "Input\\Shared Drive_Indonesia\\";
                                            obj.INDONESIA_CARDS_BATCH2_MGDAQ_MGDIS(Soure_Path, Recon_Date, (Output_Path + temp_FileName), SFTP_Dir, Output_Path + temp_FileNamehalf);
                                            For_Counter++;
                                        }
                                    }
                                    else if (Recon_name == "INDONESIA CARDS - JETCO RECON")
                                    {
                                        if (temp_FileName.Contains("CBINDONESIA_ABDETAIL_"))
                                        {
                                            Recon_Date = obj.Get_Recon_Date(conString, Country, "yyyyMMdd");
                                            string SFTP_Dir = Directory + "Input\\Emails\\";
                                            obj.INDONESIA_jetco(Soure_Path, Recon_Date, (Output_Path + temp_FileName), SFTP_Dir, Output_Path + temp_FileNamehalf);
                                            For_Counter++;
                                        }
                                    }
                                    else if (Recon_name == "CASH PAYMENT SUSPENSE")
                                    {
                                        //string crystalpath = Directory + "Input\\Crystal Report\\" + Country + "\\";
                                        //if (temp_FileName.Contains("S2B"))
                                        //{
                                        //    obj.CASH_PAYMENT_SUSPENSE_S2B(Soure_Path, (Output_Path + temp_FileName), crystalpath, Foramtted_Recon_Date, temp_FileNamehalf, Output_Path);
                                        //    For_Counter++;
                                        //}
                                        //else if (temp_FileName.Contains("CHQ"))
                                        //{
                                        //    obj.CASH_PAYMENT_SUSPENSE_CHQ(Soure_Path, (Output_Path + temp_FileName), crystalpath, Foramtted_Recon_Date, temp_FileNamehalf, Output_Path);
                                        //    For_Counter++;
                                        //}
                                        //else if (temp_FileName.Contains("TBILL"))
                                        //{
                                        //    obj.CASH_PAYMENT_SUSPENSE_T_BILL(Soure_Path, (Output_Path + temp_FileName), crystalpath, Foramtted_Recon_Date, temp_FileNamehalf, Output_Path);
                                        //    For_Counter++;
                                        //}
                                        if (temp_FileName.Contains("S2B"))
                                        {
                                            bool count_check = false;
                                            obj.CASH_PAYMENT_SUSPENSE_S2B_UPD(conString, Soure_Path, (Output_Path + temp_FileName), Recon_name, Foramtted_Recon_Date, temp_FileNamehalf, Output_Path, out count_check);
                                            if (count_check == true)
                                            {
                                                For_Counter++;
                                            }
                                        }
                                        else if (temp_FileName.Contains("CHQ"))
                                        {
                                            bool count_check = false;
                                            obj.CASH_PAYMENT_SUSPENSE_CHQ_UPD(conString, Soure_Path, (Output_Path + temp_FileName), Recon_name, Foramtted_Recon_Date, temp_FileNamehalf, Output_Path, out count_check);
                                            if (count_check == true)
                                            {
                                                For_Counter++;
                                            }
                                        }
                                        else if (temp_FileName.Contains("TBILL"))
                                        {
                                            bool count_check = false;
                                            obj.CASH_PAYMENT_SUSPENSE_T_BILL_UPD(conString, Soure_Path, (Output_Path + temp_FileName), Recon_name, Foramtted_Recon_Date, temp_FileNamehalf, Output_Path, out count_check);
                                            if (count_check == true)
                                            {
                                                For_Counter++;
                                            }
                                        }
                                    }
                                    else if (Recon_name == "Malaysia Other AA Codes")
                                    {
                                        cls_MalaysiaOtherAA objMalaysiaOtherAA = new cls_MalaysiaOtherAA();
                                        objMalaysiaOtherAA.MalaysiaOtherAA(Soure_Path, Recon_Date, Output_Path, Recon_name, Output_Path, Formatted_File_Name, File_Ext);
                                        For_Counter++;
                                    }
                                    else if (Recon_name == "CCMS OPEN ITEMS")
                                    {
                                        string crystalpath = Directory + "Input\\Crystal Report\\" + Country + "\\";
                                        if (temp_FileName.Contains("PSGL_289109_BRK"))
                                        {
                                            bool count_check = false;
                                            obj.CCMS_OPEN_Visa(conString, Soure_Path, crystalpath, Output_Path, (Output_Path + temp_FileName), Recon_name, Recon_Date, Formatted_File_Name, temp_FileName, out count_check);
                                            if (count_check == true)
                                            {
                                                For_Counter++;
                                            }
                                        }
                                        else if (temp_FileName.Contains("PSGL_289236_BRK"))
                                        {
                                            bool count_check = false;
                                            obj.CCMS_OPEN_Master(conString, Soure_Path, crystalpath, Output_Path, (Output_Path + temp_FileName), Recon_name, Recon_Date, Formatted_File_Name, temp_FileName, out count_check);
                                            if (count_check == true)
                                            {
                                                For_Counter++;
                                            }
                                        }
                                        else if (Soure_Path.Contains("CSW64D") || Soure_Path.Contains("CSW65D"))
                                        {
                                            //DataTable dt = obj.Formatting_CCMS_Open_Item(Convert.ToString(d[2]), Soure_Path, crystalpath, Recon_Date);
                                            DataTable dt = obj.Formatting_CCMS_Open_Item(conString, Convert.ToString(d[2]), Soure_Path, crystalpath, Recon_Date, Recon_name);
                                            For_Counter++;
                                            For_Counter3++;
                                            dt_Final.Merge(dt);
                                            if (For_Counter3 > 1)
                                            {
                                                for (int k = dt_Final.Rows.Count - 1; k >= 0; k--)
                                                {
                                                    if (dt_Final.Rows[k][0].ToString().Contains("ENT - REVD VS Values is Not Matching"))
                                                    {
                                                        dt_Final.Clear();
                                                    }
                                                }
                                                if (dt_Final.Rows.Count > 1)
                                                {
                                                    obj.ExportToExcel_Common(dt_Final, Output_Path + "CCMS_64-65.xlsx");
                                                    obj.FileRenam((Output_Path + "CCMS_64-65.xlsx"), (Output_Path + temp_FileName), Output_Path, Recon_name, Formatted_File_Name, temp_FileName);
                                                }
                                                else
                                                {
                                                    cmd = new SqlCommand("update ARC_Scope_BaseLine set PSID = '" + Environment.UserName + "', IsProcessed = 1, AutomationStatus = 'Values is Not Matching' where Recon = '" + Recon_name + "' and Report_Source_File_Name in ('CSW65D','CSW64D')", con);
                                                    con.Open();
                                                    cmd.ExecuteNonQuery();
                                                    con.Close();
                                                }
                                            }
                                        }
                                    }
                                    else if (Recon_name == "Settlement Suspense Accounts")
                                    {
                                        string crystalpath = Directory + "Input\\Crystal Report\\" + Country + "\\";
                                        if (Formatted_File_Name.Contains("PSGL_289027_BRK"))
                                        {
                                            //105D
                                            //Commented By Aneesh ---03-05-18
                                            //obj.Settelment_105d(Soure_Path, crystalpath, Output_Path, (Output_Path + temp_FileName), Recon_name, Recon_Date, Formatted_File_Name, temp_FileName);
                                            bool count_check = false;
                                            obj.Settelment_105d_UPD(conString, Soure_Path, crystalpath, Output_Path, (Output_Path + temp_FileName), Recon_name, Recon_Date, Formatted_File_Name, temp_FileName, out count_check);
                                            if (count_check == true)
                                            {
                                                For_Counter++;
                                            }
                                        }
                                        else if (Formatted_File_Name.Contains("PSGL_288896_BRK"))
                                        {
                                            //Switch
                                            //Commented By Aneesh ---03-05-18
                                            //obj.Settelment_Switch(Soure_Path, crystalpath, Output_Path, (Output_Path + temp_FileName), Recon_name, Recon_Date, Formatted_File_Name, temp_FileName);
                                            bool count_check = false;
                                            obj.Settelment_Switch_UPD(conString, Soure_Path, crystalpath, Output_Path, (Output_Path + temp_FileName), Recon_name, Recon_Date, Formatted_File_Name, temp_FileName, out count_check);
                                            if (count_check == true)
                                            {
                                                For_Counter++;
                                            }
                                        }
                                        else if (Soure_Path.Contains("MGDAQ_MMY") || Soure_Path.Contains("MGDIS_MMY"))
                                        {
                                            //DataTable dt = obj.Formatting_Settelment_Suspense_Item(Convert.ToString(d[2]), Soure_Path, crystalpath, Recon_Date);
                                            DataTable dt = obj.Formatting_Settelment_Suspense_Item(conString, Convert.ToString(d[2]), Soure_Path, crystalpath, Recon_Date, Recon_name);
                                            dt_Final.Merge(dt);
                                            For_Counter++;
                                            if (For_Counter > 1)
                                            {
                                                obj.ExportToExcel_Common(dt_Final, Output_Path + "SETTELMENT_AQ-IS.xlsx");
                                                obj.FileRenam((Output_Path + "SETTELMENT_AQ-IS.xlsx"), (Output_Path + Formatted_File_Name), Output_Path, Recon_name, Formatted_File_Name, Formatted_File_Name);
                                            }
                                        }
                                    }

                                    //ended By Anees...
                                    //25-05 Kiran
                                    else if (Recon_name == "Thailand - Custody - Depo Recon")
                                    {
                                        //06-07
                                        if (!File.Exists(Output_Path + Formatted_File_Name + db_Ext))
                                        {
                                            obj.ThailandCustodyDepo(Soure_Path, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, File_Name, db_Ext);
                                            For_Counter++;
                                        }

                                    }
                                    else if (Recon_name == "BANK OF ENGLAND")
                                    {
                                        if (File_Name.Contains("CM_Collateral"))
                                        {
                                            Recon_Date = obj.Get_Recon_Date_Monthly(conString, Country, "yyyyMMdd");
                                            obj.BankofEngland(Soure_Path, Desti_Path, Formatted_File_Name, Output_Path, Recon_Date);
                                            For_Counter = For_Counter + 2;
                                        }
                                    }
                                    else if (Recon_name == "Kenya CUSTODY-OPICS position Fortnightly")
                                    {
                                        Recon_Date = obj.Get_Recon_Date_Monthly(conString, Country, "yyyyMMdd");
                                        obj.Kenya_CUSTODY_OPICS_position_Fortnightly(Soure_Path, Desti_Path, Formatted_File_Name, Output_Path, Recon_Date);
                                        For_Counter++;

                                    }
                                    else if (Recon_name == "GM POS CUST")
                                    {
                                        if (File_Name.Contains("Treasury bill redicount"))
                                        {
                                            Recon_Date = obj.Get_Recon_Date_Monthly(conString, Country, "yyyyMMdd");
                                            obj.GM_POS_CUST(Soure_Path, Desti_Path, Formatted_File_Name, Output_Path, Recon_Date);
                                            For_Counter = For_Counter + 2;
                                        }
                                    }
                                    else if (Recon_name == "Demat Custody")
                                    {
                                        if (File_Name.Contains("SCBPI_HOLD_BOD"))
                                        {
                                            Recon_Date = obj.Get_Recon_Date_Monthly(conString, Country, "yyyyMMdd");
                                            obj.DEMAT_CUSTODY(Soure_Path, Desti_Path, Formatted_File_Name, Output_Path, Recon_Date);
                                            For_Counter = For_Counter + 3;
                                        }
                                    }
                                    else if (Recon_name == "HK0000112831")
                                    {
                                        Recon_Date = obj.Get_Recon_Date_Monthly(conString, Country, "yyyyMMdd");
                                        obj.HK0000112831(Soure_Path, Desti_Path, Formatted_File_Name, Output_Path, Recon_Date);
                                        For_Counter++;
                                    }
                                    else if (Recon_name == "HK0000112791")
                                    {
                                        Recon_Date = obj.Get_Recon_Date_Monthly(conString, Country, "dd/MM/yyyy");
                                        obj.HK0000112791(Soure_Path, Desti_Path, Formatted_File_Name, Output_Path, Recon_Date);
                                        For_Counter++;
                                    }
                                    else if (Recon_name == "Africa Custody-Opics Position weekly")
                                    {
                                        //Recon_Date = obj.Get_Recon_Date_Monthly(conString, Country, "dd/MM/yyyy");
                                        obj.Africa_Custody_Opics_Position_weekly(Soure_Path, Desti_Path, Formatted_File_Name, Output_Path, Recon_Date);
                                        For_Counter++;
                                    }
                                    else if (Recon_name == "Africa Custody-Opics Position weekly1")
                                    {
                                        //Recon_Date = obj.Get_Recon_Date_Monthly(conString, Country, "dd/MM/yyyy");
                                        obj.Africa_Custody_Opics_Position_weekly1(Soure_Path, Desti_Path, Formatted_File_Name, Output_Path, Recon_Date);
                                        For_Counter++;
                                    }
                                    else if (Recon_name == "EUROCLEAR")
                                    {
                                        Recon_Date = obj.Get_Recon_Date_Monthly(conString, Country, "dd/MM/yyyy");
                                        obj.EUROCLEAR(Soure_Path, Desti_Path, Formatted_File_Name, Output_Path, Recon_Date);
                                        For_Counter++;
                                    }
                                    else if (Recon_name == "CC-RSIRSDFLT-PD")
                                    {
                                        Recon_Date = obj.Get_Recon_Date_Monthly(conString, Country, "yyyyMMdd");
                                        obj.CC_RSIRSDFLT_PD(Soure_Path, Desti_Path, Formatted_File_Name, Output_Path, Recon_Date);
                                        For_Counter++;
                                    }
                                    else if (Recon_name == "DFLT-FXSETT-PD")
                                    {
                                        Recon_Date = obj.Get_Recon_Date_Monthly(conString, Country, "dd/MM/yyyy");
                                        obj.DFLT_FXSETT_PD(Soure_Path, Desti_Path, Formatted_File_Name, Output_Path, Recon_Date);
                                        For_Counter++;
                                    }
                                    //Added on 06-03-18
                                    else if (Recon_name == "Bony and Clearstream1")
                                    {
                                        if (File_Name.Contains("AGREEMENT SUMMARY REPORT (TXT)_NTB"))
                                        {
                                            obj.BonyandClearstream_AGREEMENTSUMMARY1(Soure_Path, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, File_Name, File_Ext);
                                            For_Counter++;
                                        }

                                    }
                                    else if (Recon_name == "Bony and Clearstream2")
                                    {
                                        if (File_Name.Contains("alloc_extract_v2"))
                                        {
                                            obj.alloc_extract_v2(Soure_Path, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, File_Name, File_Ext);
                                            For_Counter++;
                                        }

                                    }
                                    else if (Recon_name == "Bony and Clearstream3")
                                    {
                                        if (File_Name.Contains("COLLATERAL BALANCE"))
                                        {
                                            obj.COLLATERAL_BALANCE(Soure_Path, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, File_Name, File_Ext);
                                            For_Counter++;
                                        }

                                    }

                                    //25-05 Kiran
                                    else if (Recon_name == "Nigeria")
                                    {

                                        string date = obj.Get_Recon_Date(conString, Country, "yyyyMMdd");
                                        Formatted_File_Name = Formatted_File_Name.Substring(0, 9) + date + Formatted_File_Name.Substring(Formatted_File_Name.Length - 11, 11);
                                        obj.Formatting_Nigeria(Directory + "Input\\Emails\\", Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, db_Ext);
                                        For_Counter++;

                                    }
                                    //25-05 Kiran
                                    else if (Recon_name == "South Africa-  Stock open items")
                                    {
                                        obj.SouthAfrica_Stock_openitems(Recon_Date, File_Name, Desti_Path, Formatted_File_Name, db_Ext);
                                        For_Counter++;
                                    }
                                    //25-05 Kiran
                                    //else if (Recon_name == "Bony and Clearstream")
                                    //{
                                    //    if (File_Name.Contains("Client_92078"))
                                    //    {
                                    //        obj.BonyandClearstream_Client_92078(Soure_Path, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, File_Name, db_Ext);
                                    //    }
                                    //    else if (File_Name.Contains("Bony and Clearstream"))
                                    //    {
                                    //        obj.BonyandClearstream_FailTrade(Soure_Path, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, File_Name, db_Ext, conString);
                                    //    }
                                    //    else if (File_Name.Contains("AGREEMENT SUMMARY REPORT"))
                                    //    {
                                    //        obj.BonyandClearstream_AGREEMENTSUMMARY(Soure_Path, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, File_Name, db_Ext);
                                    //    }
                                    //    For_Counter++;
                                    //}
                                    //24-07
                                    else if (Recon_name == "Vietnam Smart link")
                                    {
                                        Formatted_File_Name = Formatted_File_Name.Substring(0, Formatted_File_Name.Length - 8) + Foramtted_Recon_Date;
                                        obj.Vietnam_SmartLink(Soure_Path, Output_Path, Desti_Path, Formatted_File_Name, temp_FileName, db_Ext, Recon_Date, Recon_name);
                                        For_Counter++;
                                    }
                                    else if (Recon_name == "Inter MM")
                                    {
                                        if (File_Name.Contains("InterMM_22") || File_Name.Contains("InterMM_24"))
                                        {
                                            Formatted_File_Name = Formatted_File_Name.Substring(0, Formatted_File_Name.Length - 8) + Foramtted_Recon_Date;
                                            obj.Inter_MM1(Soure_Path, Output_Path, Desti_Path, Formatted_File_Name, temp_FileName, db_Ext, Recon_Date, Recon_name);
                                            For_Counter++;
                                        }
                                        else if (File_Name.Contains("InterMM_66") || File_Name.Contains("InterMM_67") || File_Name.Contains("InterMM_69") || File_Name.Contains("InterMM_72"))
                                        {
                                            Formatted_File_Name = Formatted_File_Name.Substring(0, Formatted_File_Name.Length - 8) + Foramtted_Recon_Date;
                                            obj.Inter_MM2(Soure_Path, Output_Path, Desti_Path, Formatted_File_Name, temp_FileName, db_Ext, Recon_Date, Recon_name);
                                            For_Counter++;
                                        }
                                        else if (File_Name.Contains("InterMM_62"))
                                        {
                                            Formatted_File_Name = Formatted_File_Name.Substring(0, Formatted_File_Name.Length - 8) + Foramtted_Recon_Date;
                                            obj.Inter_MM3(Soure_Path, Output_Path, Desti_Path, Formatted_File_Name, temp_FileName, db_Ext, Recon_Date, Recon_name);
                                            For_Counter++;
                                        }
                                        else if (File_Name.Contains("InterMM_63"))
                                        {
                                            Formatted_File_Name = Formatted_File_Name.Substring(0, Formatted_File_Name.Length - 8) + Foramtted_Recon_Date;
                                            obj.Inter_MM4(Soure_Path, Output_Path, Desti_Path, Formatted_File_Name, temp_FileName, db_Ext, Recon_Date, Recon_name);
                                            For_Counter++;
                                        }

                                    }
                                    //24-07
                                    else if (Recon_name == "Vietnam Billing")
                                    {
                                        Formatted_File_Name = Formatted_File_Name.Substring(0, Formatted_File_Name.Length - 8) + Foramtted_Recon_Date;
                                        obj.Vietnam_SmartLink(Soure_Path, Output_Path, Desti_Path, Formatted_File_Name, temp_FileName, db_Ext, Recon_Date, Recon_name);
                                        For_Counter++;
                                    }

                                    //25-05 Kiran
                                    else if (Recon_name == "Qatar Stock Recon")
                                    {
                                        obj.QatarStockRecon(Soure_Path, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, File_Name);
                                        For_Counter++;
                                    }
                                    //Ragavendran
                                    else if (Recon_name == "Dubai DC Stock")
                                    {

                                        obj.Dubai_DC(Soure_Path, Recon_Date, Output_Path + temp_FileName);
                                        //obj.WriteData_dubai_AE(dt_DUBI_AE, Output_Path + temp_FileName);
                                        For_Counter++;
                                    }
                                    else if (Recon_name == "DUBAI AE STOCK RECON")
                                    {
                                        if (File_Name.Contains("CustodianInventory"))
                                        {
                                            dt_DUBI_AE = obj.dubaiAE_Cust(Soure_Path, Recon_Date);
                                            DUBI_Indx++;
                                            For_Counter++;
                                        }
                                        else if (File_Name.Contains("scb_position_as_on_1_of_1_"))
                                        {
                                            dt_DUBI_SCB_Pos = obj.dubaiAE_SCB_Position(Soure_Path, Recon_Date);
                                            DUBI_Indx++;
                                            For_Counter++;
                                        }
                                        if (DUBI_Indx == 2)
                                        {
                                            dt_DUBI_AE.Merge(dt_DUBI_SCB_Pos);
                                            DataRow[] dr_Dlt = dt_DUBI_AE.Select("isnull(SUBACC,'') = ''");
                                            foreach (DataRow d_del in dr_Dlt)
                                            {
                                                d_del.Delete();
                                            }
                                            dt_DUBI_AE.AcceptChanges();
                                            obj.WriteData_dubai_AE(dt_DUBI_AE, Output_Path + temp_FileName);
                                        }
                                    }
                                    //else if (Recon_name == "Hong Kong Trade RPR")
                                    //{
                                    //    if (File_Name.Contains("TB_OPS_DAILY_TRADE_REPORT-"))
                                    //    {
                                    //        obj2.Hong_Kong_Trade_RPR(Desti_Path, Country, conString, File_Name, Output_Path, File_Ext, Recon_Date, Directory);
                                    //    }
                                    //    else if (File_Name == "IMXHP2B1")
                                    //    {
                                    //        obj2.HongKong_Get_IMXHP2B1(Desti_Path, Country, conString, File_Name, Output_Path, File_Ext, Directory);
                                    //    }
                                    //    else if (File_Name == "60opxor029")
                                    //    {
                                    //        obj2.HongKong_Formatting_60opx(Desti_Path, Country, conString, File_Name, Output_Path, File_Ext, Directory);
                                    //    }
                                    //}
                                    else if (Recon_name == "Malaysia - EOD Open Item Report")
                                    {
                                        if (File_Name.Contains("ITT Pending"))
                                        {
                                            dt_MY_ITT_Pend = obj.GetITT_Pending(Soure_Path, Country);
                                            dt_MY_final.Merge(dt_MY_ITT_Pend);
                                            DTcount++;
                                        }
                                        else if (File_Name.Contains("ITT Processed"))
                                        {
                                            dt_MY_ITT_Pross = obj.GetITT_Processed(Soure_Path, Country);
                                            dt_MY_final.Merge(dt_MY_ITT_Pross);
                                            DTcount++;
                                        }
                                        if (DTcount == 2)
                                        {
                                            DataView dv = new DataView(dt_MY_final);
                                            dv.Sort = "d";
                                            dt_MY_final = dv.ToTable();
                                            string excelOutputFile = Output_Path + "Output.xlsx";
                                            string excelFinalFile = Output_Path + "GMI_CASH.csv";
                                            obj.ExportToExcel_MYEOD_Sheet(dt_MY_final, excelOutputFile);
                                            obj.ExportToExcel_MYEOD(dt_MY_final, excelFinalFile, Country);
                                            if (File.Exists(excelFinalFile))
                                            {
                                                SqlCommand Updt_cmd2 = new SqlCommand("update ARC_Recon_Master set Is_Recon_Completed = 1, Recon_Status = 'COMPLETED', PSID = '" + Environment.UserName + "' where Recon_Id = " + Recon_Id + "", con);
                                                con.Open();
                                                Updt_cmd2.ExecuteNonQuery();
                                                con.Close();
                                            }
                                        }
                                    }
                                    else if (Recon_name == "Indonesia - EOD Open Item Report")
                                    {
                                        if (File_Name.Contains("ITT Pending"))
                                        {
                                            dt_ID_ITT_Pend = obj.GetITT_Pending(Soure_Path, Country);
                                            dt_ID_final.Merge(dt_ID_ITT_Pend);
                                            DTcount++;
                                        }
                                        else if (File_Name.Contains("ITT Processed"))
                                        {
                                            dt_ID_ITT_Pross = obj.GetITT_Processed(Soure_Path, Country);
                                            dt_ID_final.Merge(dt_ID_ITT_Pross);
                                            DTcount++;
                                        }
                                        if (DTcount == 2)
                                        {
                                            DataView dv = new DataView(dt_ID_final);
                                            dv.Sort = "d";
                                            dt_ID_final = dv.ToTable();
                                            string excelOutputFile = Output_Path + "Output.xlsx";
                                            string excelFinalFile = Output_Path + "GMI_CASH.csv";
                                            obj.ExportToExcel_MYEOD_Sheet(dt_ID_final, excelOutputFile);
                                            obj.ExportToExcel_MYEOD(dt_ID_final, excelFinalFile, Country);
                                            if (File.Exists(excelFinalFile))
                                            {
                                                SqlCommand Updt_cmd2 = new SqlCommand("update ARC_Recon_Master set Is_Recon_Completed = 1, Recon_Status = 'COMPLETED', PSID = '" + Environment.UserName + "' where Recon_Id = " + Recon_Id + "", con);
                                                con.Open();
                                                Updt_cmd2.ExecuteNonQuery();
                                                con.Close();
                                            }
                                        }
                                    }
                                    else if (Recon_name == "Vietnam - EOD Open Item Report")
                                    {
                                        if (File_Name.Contains("ITT Pending"))
                                        {
                                            dt_VN_ITT_Pend = obj.GetITT_Pending(Soure_Path, Country);
                                            dt_VN_final.Merge(dt_VN_ITT_Pend);
                                            DTcount++;
                                        }
                                        else if (File_Name.Contains("ITT Processed"))
                                        {
                                            dt_VN_ITT_Pross = obj.GetITT_Processed(Soure_Path, Country);
                                            dt_VN_final.Merge(dt_VN_ITT_Pross);
                                            DTcount++;
                                        }
                                        if (DTcount == 2)
                                        {
                                            DataView dv = new DataView(dt_VN_final);
                                            dv.Sort = "d";
                                            dt_VN_final = dv.ToTable();
                                            string excelOutputFile = Output_Path + "Output.xlsx";
                                            string excelFinalFile = Output_Path + "GMI_CASH.csv";
                                            obj.ExportToExcel_MYEOD_Sheet(dt_VN_final, excelOutputFile);
                                            obj.ExportToExcel_MYEOD(dt_VN_final, excelFinalFile, Country);
                                            if (File.Exists(excelFinalFile))
                                            {
                                                SqlCommand Updt_cmd2 = new SqlCommand("update ARC_Recon_Master set Is_Recon_Completed = 1, Recon_Status = 'COMPLETED', PSID = '" + Environment.UserName + "' where Recon_Id = " + Recon_Id + "", con);
                                                con.Open();
                                                Updt_cmd2.ExecuteNonQuery();
                                                con.Close();
                                            }
                                        }
                                    }
                                    else if (Recon_name == "Singapore - EOD Open Item Report")
                                    {
                                        if (File_Name.Contains("ITT Pending"))
                                        {
                                            dt_SG_ITT_Pend = obj.GetITT_Pending(Soure_Path, Country);
                                            dt_SG_final.Merge(dt_SG_ITT_Pend);
                                            DTcount++;
                                        }
                                        else if (File_Name.Contains("ITT Processed"))
                                        {
                                            dt_SG_ITT_Pross = obj.GetITT_Processed(Soure_Path, Country);
                                            dt_SG_final.Merge(dt_SG_ITT_Pross);
                                            DTcount++;
                                        }
                                        if (DTcount == 2)
                                        {
                                            DataView dv = new DataView(dt_SG_final);
                                            dv.Sort = "d";
                                            dt_SG_final = dv.ToTable();
                                            string excelOutputFile = Output_Path + "Output.xlsx";
                                            string excelFinalFile = Output_Path + "GMI_CASH.csv";
                                            obj.ExportToExcel_MYEOD_Sheet(dt_SG_final, excelOutputFile);
                                            obj.ExportToExcel_MYEOD(dt_SG_final, excelFinalFile, Country);
                                            if (File.Exists(excelFinalFile))
                                            {
                                                SqlCommand Updt_cmd2 = new SqlCommand("update ARC_Recon_Master set Is_Recon_Completed = 1, Recon_Status = 'COMPLETED', PSID = '" + Environment.UserName + "' where Recon_Id = " + Recon_Id + "", con);
                                                con.Open();
                                                Updt_cmd2.ExecuteNonQuery();
                                                con.Close();
                                            }
                                        }
                                    }
                                    else if (Recon_name == "Phillipines - EOD Open Item Report")
                                    {
                                        if (File_Name.Contains("ITT Pending"))
                                        {
                                            dt_ID_ITT_Pend = obj.GetITT_Pending(Soure_Path, Country);
                                            dt_ID_final.Merge(dt_ID_ITT_Pend);
                                            DTcount++;
                                        }
                                        else if (File_Name.Contains("ITT Processed"))
                                        {
                                            dt_ID_ITT_Pross = obj.GetITT_Processed(Soure_Path, Country);
                                            dt_ID_final.Merge(dt_ID_ITT_Pross);
                                            DTcount++;
                                        }
                                        if (DTcount == 2)
                                        {
                                            DataView dv = new DataView(dt_ID_final);
                                            dv.Sort = "d";
                                            dt_ID_final = dv.ToTable();
                                            string excelOutputFile = Output_Path + "Output.xlsx";
                                            string excelFinalFile = Output_Path + "GMI_CASH.csv";
                                            obj.ExportToExcel_MYEOD_Sheet(dt_ID_final, excelOutputFile);
                                            obj.ExportToExcel_MYEOD(dt_ID_final, excelFinalFile, Country);
                                            if (File.Exists(excelFinalFile))
                                            {
                                                SqlCommand Updt_cmd2 = new SqlCommand("update ARC_Recon_Master set Is_Recon_Completed = 1, Recon_Status = 'COMPLETED', PSID = '" + Environment.UserName + "' where Recon_Id = " + Recon_Id + "", con);
                                                con.Open();
                                                Updt_cmd2.ExecuteNonQuery();
                                                con.Close();
                                            }
                                        }
                                    }
                                    else if (Recon_name == "India - EOD Open Item Report")
                                    {
                                        if (File_Name.Contains("ITT Pending"))
                                        {
                                            dt_IN_ITT_Pend = obj.GetITT_Pending(Soure_Path, Country);
                                            dt_IN_final.Merge(dt_IN_ITT_Pend);
                                            DTcount++;
                                        }

                                        if (DTcount == 1)
                                        {
                                            DataView dv = new DataView(dt_IN_final);
                                            dv.Sort = "d";
                                            dt_IN_final = dv.ToTable();
                                            string excelOutputFile = Output_Path + "Output.xlsx";
                                            string excelFinalFile = Output_Path + "GMI_CASH.csv";
                                            obj.ExportToExcel_MYEOD_Sheet(dt_IN_final, excelOutputFile);
                                            obj.ExportToExcel_MYEOD(dt_IN_final, excelFinalFile, Country);
                                            if (File.Exists(excelFinalFile))
                                            {
                                                SqlCommand Updt_cmd2 = new SqlCommand("update ARC_Recon_Master set Is_Recon_Completed = 1, Recon_Status = 'COMPLETED', PSID = '" + Environment.UserName + "' where Recon_Id = " + Recon_Id + "", con);
                                                con.Open();
                                                Updt_cmd2.ExecuteNonQuery();
                                                con.Close();
                                            }
                                        }
                                    }
                                    else if (Recon_name == "Nigeria - EOD Open Item Report")
                                    {
                                        if (File_Name.Contains("ITT Register"))
                                        {
                                            dt_IN_ITT_Pend = obj.GetITT_Register(Soure_Path, Country);
                                            dt_IN_final.Merge(dt_IN_ITT_Pend);
                                            DTcount++;
                                        }

                                        if (DTcount == 1)
                                        {
                                            DataView dv = new DataView(dt_IN_final);
                                            dv.Sort = "d";
                                            dt_IN_final = dv.ToTable();
                                            string excelOutputFile = Output_Path + "Output.xlsx";
                                            string excelFinalFile = Output_Path + "GMI_CASH.csv";
                                            obj.ExportToExcel_MYEOD_Sheet(dt_IN_final, excelOutputFile);
                                            obj.ExportToExcel_MYEOD(dt_IN_final, excelFinalFile, Country);
                                            if (File.Exists(excelFinalFile))
                                            {
                                                SqlCommand Updt_cmd2 = new SqlCommand("update ARC_Recon_Master set Is_Recon_Completed = 1, Recon_Status = 'COMPLETED', PSID = '" + Environment.UserName + "' where Recon_Id = " + Recon_Id + "", con);
                                                con.Open();
                                                Updt_cmd2.ExecuteNonQuery();
                                                con.Close();
                                            }
                                        }
                                    }
                                    else if (Recon_name == "UK Nostro thrid party johnson matthey")
                                    {
                                        DataTable dt_UK_Metals = new DataTable();
                                        string excelInputFile = Soure_Path;
                                        string excelFinalFile = Output_Path + "GMI_CASH.csv";

                                        dt_UK_Metals = obj.ReadExcelFile(excelInputFile);
                                        obj.ExportToExcel_JM_FinalFile(dt_UK_Metals, excelFinalFile);

                                        if (File.Exists(excelFinalFile))
                                        {
                                            SqlCommand Updt_cmd2 = new SqlCommand("update ARC_Recon_Master set Is_Recon_Completed = 1, Recon_Status = 'COMPLETED', PSID = '" + Environment.UserName + "' where Recon_Id = " + Recon_Id + "", con);
                                            con.Open();
                                            Updt_cmd2.ExecuteNonQuery();
                                            con.Close();
                                        }
                                    }
                                    else if (Recon_name == "IBROKER  - SG")
                                    {
                                        Recon_Date = obj.Get_Recon_Date(conString, Country, "MM/dd/yyyy");
                                        obj.Formatting_Singapore_IBROKER(Soure_Path, Output_Path + Formatted_File_Name + db_Ext, Recon_Date);
                                        For_Counter++;
                                    }
                                    else if (Recon_name == "IBROKER  - MY")
                                    {
                                        Recon_Date = obj.Get_Recon_Date(conString, Country, "MM/dd/yyyy");
                                        obj.Formatting_Malaysia_IBROKER(Soure_Path, Output_Path + Formatted_File_Name + db_Ext, Recon_Date);
                                        For_Counter++;
                                    }

                                    else if (Recon_name == "India - CMPC Suspense")
                                    {
                                        string path1 = "";
                                        string path2 = "";
                                        string path3 = "";

                                        //change to Monday
                                        if (DateTime.Today.DayOfWeek.ToString() == "Monday")
                                        {
                                            //11-07
                                            path1 = Directory + "Input\\EBBS_India";
                                            if (File_Name.Contains("CURSA_AS_OF"))
                                            {
                                                obj.GetFileName_CMPC_CURSA(path1, out path2, out path3);
                                                DateTime myDate = DateTime.ParseExact(DateTime.Today.ToString("dd-MM-yyyy"), "dd-MM-yyyy", System.Globalization.CultureInfo.InvariantCulture);
                                                Recon_Date = myDate.AddDays(-2).ToString("dd_MM_yyyy");
                                                Formatted_File_Name = Formatted_File_Name.Substring(0, Formatted_File_Name.Length - 10) + Recon_Date;
                                                obj.Formatting_India_CMPC_Suspense(path2, Output_Path, Desti_Path, Formatted_File_Name, temp_FileName, db_Ext, Recon_Date, Recon_name);
                                                if (path3 != "")
                                                {

                                                    Recon_Date = myDate.AddDays(-3).ToString("dd_MM_yyyy");

                                                    Formatted_File_Name = Formatted_File_Name.Substring(0, Formatted_File_Name.Length - 10) + Recon_Date;

                                                    obj.Formatting_India_CMPC_Suspense(path3, Output_Path, Desti_Path, Formatted_File_Name, temp_FileName, db_Ext, Recon_Date, Recon_name);
                                                }
                                            }
                                            if (File_Name.Contains("CURSC_AS_OF"))
                                            {
                                                obj.GetFileName_CMPC_CURSC(path1, out path2, out path3);
                                                DateTime myDate = DateTime.ParseExact(DateTime.Today.ToString("dd-MM-yyyy"), "dd-MM-yyyy", System.Globalization.CultureInfo.InvariantCulture);
                                                Recon_Date = myDate.AddDays(-2).ToString("dd_MM_yyyy");
                                                Formatted_File_Name = Formatted_File_Name.Substring(0, Formatted_File_Name.Length - 10) + Recon_Date;
                                                obj.Formatting_India_CMPC_Suspense(path2, Output_Path, Desti_Path, Formatted_File_Name, temp_FileName, db_Ext, Recon_Date, Recon_name);
                                                if (path3 != "")
                                                {

                                                    Recon_Date = myDate.AddDays(-3).ToString("dd_MM_yyyy");

                                                    Formatted_File_Name = Formatted_File_Name.Substring(0, Formatted_File_Name.Length - 10) + Recon_Date;

                                                    obj.Formatting_India_CMPC_Suspense(path3, Output_Path, Desti_Path, Formatted_File_Name, temp_FileName, db_Ext, Recon_Date, Recon_name);
                                                }
                                            }
                                            if (File_Name.Contains("CURSE_AS_OF"))
                                            {
                                                obj.GetFileName_CMPC_CURSE(path1, out path2, out path3);
                                                DateTime myDate = DateTime.ParseExact(DateTime.Today.ToString("dd-MM-yyyy"), "dd-MM-yyyy", System.Globalization.CultureInfo.InvariantCulture);
                                                Recon_Date = myDate.AddDays(-2).ToString("dd_MM_yyyy");
                                                Formatted_File_Name = Formatted_File_Name.Substring(0, Formatted_File_Name.Length - 10) + Recon_Date;
                                                obj.Formatting_India_CMPC_Suspense(path2, Output_Path, Desti_Path, Formatted_File_Name, temp_FileName, db_Ext, Recon_Date, Recon_name);
                                                if (path3 != "")
                                                {

                                                    Recon_Date = myDate.AddDays(-3).ToString("dd_MM_yyyy");

                                                    Formatted_File_Name = Formatted_File_Name.Substring(0, Formatted_File_Name.Length - 10) + Recon_Date;

                                                    obj.Formatting_India_CMPC_Suspense(path3, Output_Path, Desti_Path, Formatted_File_Name, temp_FileName, db_Ext, Recon_Date, Recon_name);
                                                }
                                            }
                                            if (File_Name.Contains("CURSI_AS_OF"))
                                            {
                                                obj.GetFileName_CMPC_CURSI(path1, out path2, out path3);
                                                DateTime myDate = DateTime.ParseExact(DateTime.Today.ToString("dd-MM-yyyy"), "dd-MM-yyyy", System.Globalization.CultureInfo.InvariantCulture);
                                                Recon_Date = myDate.AddDays(-2).ToString("dd_MM_yyyy");
                                                Formatted_File_Name = Formatted_File_Name.Substring(0, Formatted_File_Name.Length - 10) + Recon_Date;
                                                obj.Formatting_India_CMPC_Suspense(path2, Output_Path, Desti_Path, Formatted_File_Name, temp_FileName, db_Ext, Recon_Date, Recon_name);
                                                if (path3 != "")
                                                {

                                                    Recon_Date = myDate.AddDays(-3).ToString("dd_MM_yyyy");

                                                    Formatted_File_Name = Formatted_File_Name.Substring(0, Formatted_File_Name.Length - 10) + Recon_Date;

                                                    obj.Formatting_India_CMPC_Suspense(path3, Output_Path, Desti_Path, Formatted_File_Name, temp_FileName, db_Ext, Recon_Date, Recon_name);
                                                }
                                            }
                                            if (File_Name.Contains("CURST_AS_OF"))
                                            {
                                                obj.GetFileName_CMPC_CURST(path1, out path2, out path3);
                                                DateTime myDate = DateTime.ParseExact(DateTime.Today.ToString("dd-MM-yyyy"), "dd-MM-yyyy", System.Globalization.CultureInfo.InvariantCulture);
                                                Recon_Date = myDate.AddDays(-2).ToString("dd_MM_yyyy");
                                                Formatted_File_Name = Formatted_File_Name.Substring(0, Formatted_File_Name.Length - 10) + Recon_Date;
                                                obj.Formatting_India_CMPC_Suspense(path2, Output_Path, Desti_Path, Formatted_File_Name, temp_FileName, db_Ext, Recon_Date, Recon_name);
                                                if (path3 != "")
                                                {

                                                    Recon_Date = myDate.AddDays(-3).ToString("dd_MM_yyyy");

                                                    Formatted_File_Name = Formatted_File_Name.Substring(0, Formatted_File_Name.Length - 10) + Recon_Date;

                                                    obj.Formatting_India_CMPC_Suspense(path3, Output_Path, Desti_Path, Formatted_File_Name, temp_FileName, db_Ext, Recon_Date, Recon_name);
                                                }
                                            }
                                            For_Counter++;

                                        }
                                        else
                                        {
                                            obj.Formatting_India_CMPC_Suspense(Soure_Path, Output_Path, Desti_Path, Formatted_File_Name, temp_FileName, db_Ext, Recon_Date, Recon_name);
                                            For_Counter++;
                                        }

                                    }
                                    else if (Recon_name == "Bank Indonesia Custody - Opics Position Reconciliation")
                                    {
                                        obj.Bank_Indnesia(Soure_Path, Desti_Path + Formatted_File_Name + db_Ext, Desti_Path, Output_Path, Recon_Date, Recon_name, Formatted_File_Name);
                                        For_Counter++;
                                    }
                                    //*************************************************************************//Kiran Code
                                    else if (Recon_name == "Vietnam ACB")
                                    {
                                        if (DateTime.Today.DayOfWeek.ToString() != "Tuesday")
                                        {
                                            //17-07 Now
                                            if (File_Name.ToString().ToLower().Contains("detail"))
                                            {
                                                int hol = obj.Get_HolidaysTotal(conString, Country, "MM/dd/yyyy");
                                                Recon_Date = obj.Get_Recon_Date(conString, Country, "yyyyMMdd");
                                                obj.VIETNAM_ACB_Formatting(Soure_Path, Recon_Date, Output_Path, hol, Formatted_File_Name, Desti_Path, Recon_name);
                                                For_Counter++;
                                            }
                                            else if (File_Name.Contains("SVNDTAQ"))
                                            {
                                                int hol = obj.Get_HolidaysTotal(conString, Country, "MM/dd/yyyy");
                                                Recon_Date = obj.Get_Recon_Date(conString, Country, "ddMMyy");
                                                obj.VIETNAM_ACB_SVNDTAQ(Soure_Path, Recon_Date, Output_Path, hol);
                                                For_Counter++;
                                            }
                                        }
                                        else
                                        {
                                            string path1 = "";
                                            string path2 = "";
                                            string path3 = "";
                                            string Date = "";
                                            if (File_Name.ToString().ToLower().Contains("detail"))
                                            {
                                                obj.GetFileNameVietnam_detail(Soure_Path.Substring(0, Soure_Path.Length - (db_Ext.Length + File_Name.Length)), out path1, out path2, out path3);
                                                Recon_Date = obj.Get_Recon_Date(conString, Country, "yyyyMMdd");
                                                int hol = obj.Get_HolidaysTotal(conString, Country, "MM/dd/yyyy");
                                                obj.VIETNAM_ACB_Formatting(path1, Recon_Date, Output_Path, hol, Formatted_File_Name, Desti_Path, Recon_name);
                                                For_Counter++;
                                            }
                                            else if (File_Name.Contains("SVNDTAQ"))
                                            {
                                                obj.GetFileNameVietnam_SVNDTAQ(Soure_Path.Substring(0, Soure_Path.Length - (db_Ext.Length + File_Name.Length)), out path1, out path2, out path3);
                                                int hol = obj.Get_HolidaysTotal(conString, Country, "MM/dd/yyyy");
                                                Recon_Date = obj.Get_Recon_Date(conString, Country, "ddMMyy");
                                                DateTime myDate = DateTime.ParseExact(Recon_Date, "ddMMyy", System.Globalization.CultureInfo.InvariantCulture);
                                                Date = myDate.AddDays(-1).ToString("ddMMyy");
                                                obj.VIETNAM_ACB_SVNDTAQ(path1, Date, Output_Path, hol);
                                                Date = myDate.AddDays(-2).ToString("ddMMyy");
                                                obj.VIETNAM_ACB_SVNDTAQ(path2, Date, Output_Path, hol);
                                                Date = myDate.AddDays(-3).ToString("ddMMyy");
                                                obj.VIETNAM_ACB_SVNDTAQ(path3, Date, Output_Path, hol);
                                                For_Counter++;
                                            }
                                        }
                                    }
                                    else if (Recon_name == "Vietnam I-banking")
                                    {

                                        string Date = "";
                                        if (DateTime.Today.DayOfWeek.ToString() != "Tuesday")
                                        {
                                            if (File_Name.Contains("BillPayment_Mobile"))
                                            {
                                                int hol = obj.Get_HolidaysTotal(conString, Country, "MM/dd/yyyy");
                                                Recon_Date = obj.Get_Recon_Date(conString, Country, "yyyyMMdd");
                                                obj.VIETNAM_IBANKING(Soure_Path, Recon_Date, Output_Path, Formatted_File_Name, db_Ext, hol, Formatted_File_Name, Desti_Path, Recon_name);
                                                For_Counter++;
                                            }
                                            else if (File_Name.Contains("IBANKING SETTLEMENT"))
                                            {
                                                //25-07 1554577
                                                int hol = obj.Get_HolidaysTotal(conString, Country, "MM/dd/yyyy");
                                                DateTime myDate = DateTime.ParseExact(Recon_Date, "ddMMyyyy", System.Globalization.CultureInfo.InvariantCulture);
                                                Date = myDate.AddDays(-1).ToString("ddMMyyyy");
                                                obj.Vietnam_I_banking_IBANKING_SETTLEMENT(Soure_Path, Date, Output_Path, Formatted_File_Name, db_Ext, hol, Formatted_File_Name, Desti_Path, Recon_name);
                                                For_Counter++;
                                            }
                                        }
                                        else
                                        {
                                            if (File_Name.Contains("BillPayment_Mobile"))
                                            {
                                                int hol = obj.Get_HolidaysTotal(conString, Country, "MM/dd/yyyy");
                                                Recon_Date = obj.Get_Recon_Date(conString, Country, "yyyyMMdd");
                                                obj.VIETNAM_IBANKING(Soure_Path, Recon_Date, Output_Path, Formatted_File_Name, db_Ext, hol, Formatted_File_Name, Desti_Path, Recon_name);
                                                For_Counter++;
                                            }
                                            else if (File_Name.Contains("IBANKING SETTLEMENT"))
                                            {
                                                //obj.GetFileNameVietnam_IBANKING(Soure_Path.Substring(0, Soure_Path.Length - (db_Ext.Length + File_Name.Length + 1)), out path1, out path2, out path3);
                                                int hol = obj.Get_HolidaysTotal(conString, Country, "MM/dd/yyyy");

                                                DateTime myDate = DateTime.ParseExact(Recon_Date, "ddMMyyyy", System.Globalization.CultureInfo.InvariantCulture);
                                                Date = myDate.AddDays(-3).ToString("ddMMyyyy");
                                                obj.Vietnam_I_banking_IBANKING_SETTLEMENT(Soure_Path, Date, Output_Path, Formatted_File_Name, db_Ext, hol, Formatted_File_Name, Desti_Path, Recon_name);
                                                //Date = myDate.AddDays(-2).ToString("ddMMyyyy");
                                                //obj.Vietnam_I_banking_IBANKING_SETTLEMENT(path3, Date, Output_Path, Formatted_File_Name, db_Ext, hol, Formatted_File_Name, Desti_Path, Recon_name);
                                                For_Counter++;

                                            }
                                        }

                                    }
                                    else if (Recon_name == "Vietnam VNPay")
                                    {
                                        if (DateTime.Today.DayOfWeek.ToString() != "Tuesday")
                                        {
                                            if (File_Name.Contains("_inc_scvn"))
                                            {

                                                Recon_Date = obj.Get_Recon_Date(conString, Country, "yyyyMMdd");
                                                string Date = Recon_Date;
                                                DateTime myDate = DateTime.ParseExact(Recon_Date, "yyyyMMdd", System.Globalization.CultureInfo.InvariantCulture);

                                                int hol = obj.Get_HolidaysTotal(conString, Country, "yyyyMMdd");
                                                Recon_Date = myDate.AddDays(-1).ToString("dd/MM/yyyy");
                                                obj.Vietnam_VNPAY_inc_scvn(Soure_Path, Recon_Date, Output_Path, Date, hol, Desti_Path);
                                            }
                                            else if (File_Name.Contains("BillPayment_Mobile_TopUp"))
                                            {
                                                //30-06
                                                int hol = obj.Get_HolidaysTotal(conString, Country, "MM/dd/yyyy");
                                                Recon_Date = obj.Get_Recon_Date(conString, Country, "yyyyMMdd");
                                                obj.VIETNAM_IBANKING(Soure_Path, Recon_Date, Output_Path, Formatted_File_Name, db_Ext, hol, Formatted_File_Name, Desti_Path, Recon_name);
                                            }
                                            For_Counter++;
                                        }
                                        else
                                        {
                                            string path1 = "";
                                            string path2 = "";
                                            string path3 = "";
                                            if (File_Name.Contains("_inc_scvn"))
                                            {
                                                obj.GetFileNameVietnam_inc_scvn(Soure_Path.Substring(0, Soure_Path.Length - (db_Ext.Length + File_Name.Length + 1)), out path1, out path2, out path3);
                                                Recon_Date = obj.Get_Recon_Date(conString, Country, "dd/MM/yyyy");
                                                string Date = Recon_Date;
                                                int hol = obj.Get_HolidaysTotal(conString, Country, "MM/dd/yyyy");
                                                obj.Vietnam_VNPAY_inc_scvn(path1, Recon_Date, Output_Path, Date, hol, Desti_Path);

                                                DateTime myDate1 = DateTime.ParseExact(Recon_Date, "dd/MM/yyyy", System.Globalization.CultureInfo.InvariantCulture);
                                                Date = myDate1.AddDays(-1).ToString("dd/MM/yyyy");
                                                obj.Vietnam_VNPAY_inc_scvn(path2, Date, Output_Path, Date, hol, Desti_Path);
                                                Date = myDate1.AddDays(-2).ToString("dd/MM/yyyy");
                                                obj.Vietnam_VNPAY_inc_scvn(path3, Date, Output_Path, Date, hol, Desti_Path);
                                            }
                                            else if (File_Name.Contains("BillPayment_Mobile_TopUp"))
                                            {
                                                int hol = obj.Get_HolidaysTotal(conString, Country, "MM/dd/yyyy");
                                                Recon_Date = obj.Get_Recon_Date(conString, Country, "yyyyMMdd");
                                                obj.VIETNAM_IBANKING(Soure_Path, Recon_Date, Output_Path, Formatted_File_Name, db_Ext, hol, Formatted_File_Name, Desti_Path, Recon_name);
                                            }
                                            For_Counter++;
                                        }

                                    }
                                    else if (Recon_name == "Vietnam Visa TLM open items")
                                    {
                                        string path1 = "";
                                        string path2 = "";
                                        string path3 = "";
                                        string Date = "";
                                        if (DateTime.Today.DayOfWeek.ToString() != "Tuesday")
                                        {
                                            if (File_Name.Contains("SWITCH REPORT"))
                                            {
                                                int hol = obj.Get_HolidaysTotal(conString, Country, "MM/dd/yyyy");
                                                Recon_Date = obj.Get_Recon_Date(conString, Country, "yyyyMMdd");
                                                DateTime myDate = DateTime.ParseExact(Recon_Date, "yyyyMMdd", System.Globalization.CultureInfo.InvariantCulture);
                                                Date = myDate.ToString("ddMMyyyy");
                                                Formatted_File_Name = Formatted_File_Name.Substring(0, Formatted_File_Name.Length - 8) + Date;
                                                obj.VIETNAM_IBANKING(Soure_Path, Recon_Date, Output_Path, Formatted_File_Name, db_Ext, hol, Formatted_File_Name, Desti_Path, Recon_name);
                                                For_Counter++;
                                            }
                                            else if (File_Name.Contains("Purchase") || File_Name.Contains("VISA ACQUIRER"))
                                            {
                                                int hol = obj.Get_HolidaysTotal(conString, Country, "MM/dd/yyyy");
                                                Recon_Date = obj.Get_Recon_Date(conString, Country, "ddMMyyyy");
                                                DateTime myDate = DateTime.ParseExact(Recon_Date, "ddMMyyyy", System.Globalization.CultureInfo.InvariantCulture);
                                                Date = myDate.AddDays(-1).ToString("ddMMyyyy");
                                                Formatted_File_Name = Formatted_File_Name.Substring(0, Formatted_File_Name.Length - 8) + Date;
                                                obj.VIETNAM_Purchase_VISA_ACQUIRER(Soure_Path, Recon_Date, Output_Path, File_Name, hol, Formatted_File_Name, Desti_Path, Recon_name);
                                                For_Counter++;
                                            }

                                        }
                                        else
                                        {
                                            if (File_Name.Contains("SWITCH REPORT"))
                                            {
                                                int hol = obj.Get_HolidaysTotal(conString, Country, "MM/dd/yyyy");
                                                Recon_Date = obj.Get_Recon_Date(conString, Country, "yyyyMMdd");
                                                obj.VIETNAM_SWITCH(Soure_Path, Recon_Date, Output_Path, Formatted_File_Name, db_Ext, hol, Formatted_File_Name, Desti_Path, Recon_name);
                                                For_Counter++;
                                            }
                                            else if (File_Name.Contains("Purchase"))
                                            {
                                                obj.GetFileNameVietnam_Purchase(Soure_Path.Substring(0, Soure_Path.Length - (db_Ext.Length + File_Name.Length + 1)), out path1, out path2, out path3);
                                                int hol = obj.Get_HolidaysTotal(conString, Country, "MM/dd/yyyy");
                                                Recon_Date = obj.Get_Recon_Date(conString, Country, "ddMMyyyy");
                                                DateTime myDate = DateTime.ParseExact(Recon_Date, "ddMMyyyy", System.Globalization.CultureInfo.InvariantCulture);
                                                Date = myDate.AddDays(-1).ToString("ddMMyyyy");
                                                Formatted_File_Name = Formatted_File_Name.Substring(0, Formatted_File_Name.Length - 8) + Date;
                                                obj.VIETNAM_Purchase_VISA_ACQUIRER(path1, Recon_Date, Output_Path, File_Name, hol, Formatted_File_Name, Desti_Path, Recon_name);


                                                Date = myDate.AddDays(-2).ToString("ddMMyyyy");
                                                Formatted_File_Name = Formatted_File_Name.Substring(0, Formatted_File_Name.Length - 8) + Date;
                                                obj.VIETNAM_Purchase_VISA_ACQUIRER(path2, Date, Output_Path, File_Name, hol, Formatted_File_Name, Desti_Path, Recon_name);
                                                Date = myDate.AddDays(-3).ToString("ddMMyyyy");
                                                Formatted_File_Name = Formatted_File_Name.Substring(0, Formatted_File_Name.Length - 8) + Date;
                                                obj.VIETNAM_Purchase_VISA_ACQUIRER(path3, Date, Output_Path, File_Name, hol, Formatted_File_Name, Desti_Path, Recon_name);
                                                For_Counter++;

                                            }
                                            else if (File_Name.Contains("VISA ACQUIRER"))
                                            {
                                                obj.GetFileNameVietnam_VisaACQ(Soure_Path.Substring(0, Soure_Path.Length - (db_Ext.Length + File_Name.Length + 1)), out path1, out path2, out path3);
                                                int hol = obj.Get_HolidaysTotal(conString, Country, "MM/dd/yyyy");
                                                Recon_Date = obj.Get_Recon_Date(conString, Country, "ddMMyyyy");
                                                DateTime myDate = DateTime.ParseExact(Recon_Date, "ddMMyyyy", System.Globalization.CultureInfo.InvariantCulture);
                                                Date = myDate.AddDays(-1).ToString("ddMMyyyy");
                                                Formatted_File_Name = Formatted_File_Name.Substring(0, Formatted_File_Name.Length - 8) + Date;
                                                obj.VIETNAM_Purchase_VISA_ACQUIRER(path1, Recon_Date, Output_Path, File_Name, hol, Formatted_File_Name, Desti_Path, Recon_name);

                                                Date = myDate.AddDays(-2).ToString("ddMMyyyy");
                                                Formatted_File_Name = Formatted_File_Name.Substring(0, Formatted_File_Name.Length - 8) + Date;
                                                obj.VIETNAM_Purchase_VISA_ACQUIRER(path2, Date, Output_Path, File_Name, hol, Formatted_File_Name, Desti_Path, Recon_name);
                                                Date = myDate.AddDays(-3).ToString("ddMMyyyy");
                                                Formatted_File_Name = Formatted_File_Name.Substring(0, Formatted_File_Name.Length - 8) + Date;
                                                obj.VIETNAM_Purchase_VISA_ACQUIRER(path3, Date, Output_Path, File_Name, hol, Formatted_File_Name, Desti_Path, Recon_name);
                                                For_Counter++;

                                            }

                                        }

                                    }

                                    //***************************************************************************//
                                    else if (Recon_name == "PHP INWARD CLEARING RECON - EOD")
                                    {
                                        if (File_Name.Contains("manila"))
                                        {
                                            Recon_Date = obj.Get_Recon_Date(conString, Country, "ddMMyyyy");
                                            obj.PHP_INWARD_CLEARING_MANILA(Soure_Path, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name);
                                        }
                                        else if (File_Name.Contains("cb inward"))
                                        {
                                            obj.PHP_INWARD_CLEARING_CB_INWARD(Soure_Path, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, db_Ext);
                                        }
                                        For_Counter++;
                                    }

                                    //25-05 Kiran Change inside method
                                    else if (Recon_name == "Jordan Stock recon open items" || Recon_name == "UAE-SCBNET Settlement Suspense and CUP Settlement Suspense")
                                    {
                                        if (File_Name.Contains("SHAREBOOK")) //(File_Name.Contains("custody") || File_Name.Contains("trading"))
                                        {
                                            File.Copy(Soure_Path, Desti_Path + Formatted_File_Name + ".csv");
                                            obj.JordonStockandUAE(Directory + "Input\\Emails\\", Desti_Path + Formatted_File_Name + ".csv", Desti_Path, Output_Path, Recon_Date, Recon_name, Formatted_File_Name, db_Ext);
                                        }
                                        else if (File_Name.Contains("ACOM"))
                                        {
                                            obj.UAECUPS(Directory + "Input\\Shared Drive_UAE\\", Desti_Path + Formatted_File_Name + ".csv", Desti_Path, Output_Path, Recon_Date, Recon_name, Formatted_File_Name, db_Ext);
                                        }
                                        For_Counter++;
                                    }
                                    //25-05 Kiran Change inside method
                                    else if (Recon_name == "Zimbabwe - Account Balance")
                                    {
                                        if (File_Name.Contains("RTGS Statements"))
                                        {
                                            //Commented by Harita--03-05-18
                                            //string Status = obj.Zimbabwe_RTGS_Statement(Directory + "Input\\Emails\\", Desti_Path + Formatted_File_Name + db_Ext, Desti_Path, Output_Path, Recon_Date, Recon_name, Formatted_File_Name, db_Ext, Directory + "Input\\Crystal Report\\Zimbabwe\\");

                                            int check_value = 0;
                                            string Status = obj.Zimbabwe_RTGS_Statement_NEW(conString, Directory + "Input\\Emails\\", Desti_Path + Formatted_File_Name + db_Ext, Desti_Path, Output_Path, Recon_Date, Recon_name, Formatted_File_Name, db_Ext, Directory + "Input\\Crystal Report\\Zimbabwe\\", out check_value);

                                            if (Status == "COMPLETED" && check_value > 0)
                                            {
                                                For_Counter++;
                                            }
                                            else if (Status == "Amount Not matching" || Status == "Crystal Report Not Found")
                                            {
                                                SqlCommand Updt_cmd2 = new SqlCommand("update ARC_Recon_Master set Is_Recon_Completed = 1, Recon_Status = '" + Status + "', PSID = '" + Environment.UserName + "' where Recon_Id = " + Recon_Id + "", con);
                                                con.Open();
                                                Updt_cmd2.ExecuteNonQuery();
                                                con.Close();
                                            }
                                        }
                                    }

                                    else if (Recon_name == "Singapore - Holdings Reconciliation")
                                    {
                                        if (File_Name == "CDP782" || File_Name == "CDP782.TXT")
                                        {
                                            File.Copy(Soure_Path, Output_Path + temp_FileName, true);
                                            obj.Singapore_Holdings(Country, Recon_name, Source_App, File_Name, Formatted_File_Name, db_Ext, conString, Directory, Desti_Path, Recon_Date);
                                        }
                                        For_Counter++;
                                    }
                                    else if (Recon_name == "UAE - UTILITY Payment Recon")
                                    {
                                        if (File_Name == "DU")
                                        {
                                            File.Copy(Soure_Path, Output_Path + temp_FileName, true);
                                            obj.UAE_UtilityPayment_DU_File(Country, Recon_name, Source_App, File_Name, Formatted_File_Name, db_Ext, conString, Directory, Desti_Path, Recon_Date);
                                        }
                                        For_Counter++;
                                    }
                                    //25-05 Kiran change inside method
                                    else if (Recon_name == "Qatar Clearing Recon")
                                    {
                                        //Kiran 01-08-2017
                                        if (File_Name.Contains("4230") || File_Name.Contains("4210") || File_Name.Contains("4110") || File_Name.Contains("4130"))
                                        {
                                            //15-07
                                            obj.Qatar_Clearing_RenameCSV_4110(Soure_Path, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, db_Ext);
                                        }
                                        else if (File_Name.Contains("IR"))
                                        {
                                            obj.Qatar_Clearing_IREBBS(Soure_Path, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, db_Ext);
                                        }
                                        else if (File_Name.Contains("OC"))
                                        {
                                            //15-07
                                            obj.Qatar_Clearing_OCEBBS(Soure_Path, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, db_Ext);
                                        }
                                        For_Counter++;
                                    }
                                    //25-05 Kiran Change inside method
                                    else if (Recon_name == "Oman Clearing Recon")
                                    {
                                        string IC = "";
                                        //15-07
                                        if (File_Name.ToLower().Contains("inward received"))
                                        {
                                            obj.Oman_Inward_Received(Soure_Path, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, db_Ext);
                                        }
                                        else if (File_Name.ToLower().Contains("outward returned") || File_Name.ToLower().Contains("outward presented"))
                                        {
                                            obj.Oman_OutwardPresented_OutwardReturned(Soure_Path, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, db_Ext);
                                        }
                                        else if (File_Name.ToLower().Contains("inward rejected"))
                                        {
                                            obj.Oman_InwardRejected(Soure_Path, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, db_Ext);
                                        }
                                        else if (File_Name.Contains("OC 00"))
                                        {
                                            IC = "OC";
                                            obj.Oman_BatchOC(Directory + "Input\\Ebbs_Oman\\", Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, db_Ext, IC);

                                        }
                                        else if (File_Name.Contains("IR"))
                                        {
                                            obj.Oman_IR(Soure_Path, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, db_Ext);
                                        }
                                        else if (File_Name.Contains("IC 00"))
                                        {
                                            IC = "IC";
                                            obj.Oman_BatchOC(Directory + "Input\\Ebbs_Oman\\", Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, db_Ext, IC);
                                        }
                                        For_Counter++;
                                    }
                                    //25-05 Kiran Change inside method
                                    else if (Recon_name == "Jordan Clearing Recon")
                                    {
                                        string IC = "";
                                        string OC = "";
                                        int Setter = 0;
                                        if (File_Name.Contains("4110_1041100") || File_Name.Contains("4110_1041100") || File_Name.Contains("4110_1041100") || File_Name.Contains("4110_1041100"))
                                        {

                                            if (Setter == 0)
                                            {
                                                Setter = 1;
                                                Recon_Date = obj.Get_Recon_Date(conString, Country, "dd/MM/yyyy");
                                                obj.Jordan_Clearing_Report(Directory + "Input\\ECC_JORDAN\\", Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, db_Ext);

                                            }
                                        }
                                        else if (File_Name.Contains("OC 00"))
                                        {
                                            OC = "OC 00";
                                            obj.Jordan_Clearing_Report1(Directory + "Input\\Ebbs_JORDAN\\", Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, db_Ext, OC);
                                        }
                                        else if (File_Name.Contains("IC 00"))
                                        {
                                            //15-07
                                            IC = "IC 00";
                                            obj.Jordan_Clearing_Report1(Directory + "Input\\Ebbs_JORDAN\\", Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, db_Ext, IC);
                                        }
                                        else if (File_Name.Contains("OR 00"))
                                        {
                                            //15-07
                                            obj.Jordan_Clearing_Report2(Directory + "Input\\Ebbs_JORDAN\\" + File_Name + ".xls", Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, db_Ext);
                                        }
                                        For_Counter++;
                                    }
                                    //25-05 Kiran Change inside method
                                    else if (Recon_name == "UAE Clearing Recon")
                                    {
                                        string IC = "";
                                        string OC = "";
                                        if (File_Name.Contains("ICCSC02001044"))
                                        {
                                            obj.UAE_Clearing_FTP(Soure_Path, Desti_Path + Formatted_File_Name + db_Ext, Desti_Path, Output_Path, Recon_Date, Recon_name, Formatted_File_Name);
                                        }
                                        else if (File_Name.Contains("IC 00"))
                                        {
                                            IC = "IC 00";
                                            //15-07
                                            obj.UAE_Clearing_ICOC(Directory + "Input\\Ebbs_UAE\\", Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, db_Ext, IC);
                                        }
                                        else if (File_Name.Contains("OC 00"))
                                        {
                                            OC = "OC 00";
                                            obj.UAE_Clearing_ICOC(Directory + "Input\\Ebbs_UAE\\", Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, db_Ext, OC);
                                        }

                                        For_Counter++;
                                    }

                                    //25-05 Kiran Change inside method
                                    else if (Recon_name == "Bahrain Clearing Recon")
                                    {
                                        if (File_Name.Contains("Presented") || File_Name.Contains("Received") || File_Name.Contains("Rejected") || File_Name.Contains("Returned"))
                                        {
                                            obj.ClearingRecon_SaveFile(Soure_Path, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, db_Ext);
                                        }
                                        else
                                        {
                                            obj.Bahrain_ClearingRecon(Soure_Path, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, db_Ext);
                                        }
                                        For_Counter++;
                                    }
                                    else if (Recon_name == "UAE SWITCH RECON")
                                    {
                                        string Output_Dir = Directory + "Input\\Crystal Report\\" + Country + "\\";
                                        obj.UAE_SWITCH_RECON(Soure_Path, Recon_Date, Output_Path, temp_FileName, Formatted_File_Name, Directory, temp_FileNamehalf, Output_Dir);
                                        For_Counter++;
                                    }
                                    //Added By Anees..
                                    else if (Recon_name == "Hong Kong - CCASS" || Recon_name == "Hong Kong - CCASS BROKER ACCOUNT")
                                    {
                                        obj.Hong_Kong_CCASS_And_BROKER(Soure_Path, Recon_Date, Output_Path + temp_FileName);
                                        For_Counter++;
                                    }
                                    else if (Recon_name == "BAHRAIN LOANS RECON")
                                    {
                                        string Output_Dir = Directory + "Input\\Crystal Report\\" + Country + "\\";
                                        obj.Beharin_Loan_Recon(Soure_Path, Output_Dir, Output_Path, (Output_Path + temp_FileName), Recon_name, Recon_Date, Formatted_File_Name, temp_FileName, conString);
                                        For_Counter++;
                                    }
                                    //Ended By Anees...
                                    else if (Recon_name == "INDONESIA CARDS - BATCH 1 REPORT")
                                    {
                                        Recon_Date = obj.Get_Recon_Date(conString, Country, "yyMMdd");
                                        obj.INDONESIA_CARDS_BATCH_REPSCBX_REPATMBX(Soure_Path, Recon_Date, Output_Path + temp_FileName, Directory, Output_Path + temp_FileNamehalf);
                                        For_Counter++;
                                    }
                                    else if (Recon_name == "Malaysia - MCD Recon" || Recon_name == "Malaysia - MCD Recon-Monthly")
                                    {
                                        obj.MalaysiaMCD(Soure_Path, Output_Path + Formatted_File_Name);
                                        For_Counter++;
                                    }
                                    // ragav 27 05 2017
                                    //else if (Recon_name == "289282-Meps ATM Settlement")
                                    //{
                                    //    string Output_Path3 = Output_Path + temp_FileName;
                                    //    obj.Meps_ATM_Settlement_2892821(Soure_Path, Output_Path3);
                                    //    For_Counter++;
                                    //}
                                    else if (Recon_name == "UK cls")
                                    {
                                        string outputpath2 = Output_Path + temp_FileName;
                                        string outputpath3 = Output_Path + "Output.xls";
                                        obj.UkCls(Soure_Path, outputpath2, outputpath3, Recon_Date);
                                        For_Counter++;
                                    }
                                    // ragav 27 05 2017

                                    else if (Recon_name == "India - RBI Main Account")
                                    {
                                        obj.India_RBI_Main_Account(Soure_Path, Recon_Date, Country, Output_Path + temp_FileName, Output_Path, temp_FileName);
                                        For_Counter++;
                                    }
                                    //Added By Anees..
                                    else if (Recon_name == "India - RBI RTGS Account")
                                    {
                                        obj.India_RBI_RTG_Account(Soure_Path, Recon_Date, Country, Output_Path + temp_FileName, Output_Path);
                                        For_Counter++;
                                    }
                                    else if (Recon_name == "Kenya - VISA Electron DR.Card Suspense AC Recon KES USD GBP EUR YEN and Outstanding Report")
                                    {
                                        if (File_Name.Contains("debit2"))
                                        {
                                            obj.Kenya_VSA_DR(Soure_Path, Recon_Date, Country, Output_Path + temp_FileName, Output_Path, temp_FileNamehalf);
                                            For_Counter = For_Counter + 3;
                                        }
                                    }

                                    else if (Recon_name == "289282-Meps ATM Settlement")
                                    {
                                        if (File_Name.Contains("STAT09-SCB"))
                                        {
                                            obj.Meps_ATM_File(Soure_Path, Recon_Date, Country, Output_Path + temp_FileName, Output_Path, temp_FileNamehalf);
                                            For_Counter++;
                                        }
                                        else if (File_Name.Contains("PRE"))
                                        {
                                            Recon_Date = obj.Get_Recon_Date(conString, Country, "MMdd");
                                            obj.Meps_ATM_PREFile(Soure_Path, Recon_Date, Country, Output_Path + temp_FileName, Output_Path, temp_FileNamehalf);
                                            For_Counter++;

                                        }
                                        else
                                        {
                                            Recon_Date = obj.Get_Recon_Date(conString, Country, "ddMM");
                                            obj.Meps_ATM_JrnlFile(Soure_Path, Recon_Date, Country, Output_Path + temp_FileName, Output_Path, temp_FileNamehalf);
                                            For_Counter++;
                                        }
                                    }

                                    //Ended By Anees..
                                    else if (Recon_name == "Nigeria - Daily Bonds   T-BILLS Recon")
                                    {
                                        obj.Nigeria_DailyBonds_TBILLS(Country, Recon_name, Source_App, File_Name, Formatted_File_Name, db_Ext, conString, Directory, Desti_Path, Recon_Date);
                                        For_Counter++;
                                    }
                                    else if (Recon_name == "Nigeria - Daily Equity Position Recon")
                                    {
                                        obj.Nigeria_DailyEquity_Position(Country, Recon_name, Source_App, File_Name, Formatted_File_Name, db_Ext, conString, Directory, Desti_Path, Recon_Date);
                                        For_Counter++;
                                    }
                                    // ragav 25 05 2017 
                                    else if (Recon_name == "Vietnam - Open Item")
                                    {
                                        string crystalpath = Directory + "Input\\Crystal Report\\" + Country + "\\" + "ACCOUNT BALANCE EXTENDED_CONSOLIDATED.xls";
                                        string Output_Path1 = Output_Path + temp_FileName;
                                        string Status = obj.VIETNAM_SA_COM(conString, Soure_Path, crystalpath, Output_Path1, Recon_Date, Recon_name);
                                        if (Status == "COMPLETED")
                                        {
                                            For_Counter++;
                                        }
                                        else if (Status == "Balance is Not Matching" && Status == "Crystal Report Not Found")
                                        {
                                            SqlCommand Updt_cmd2 = new SqlCommand("update ARC_Recon_Master set Is_Recon_Completed = 1, Recon_Status = '" + Status + "', PSID = '" + Environment.UserName + "' where Recon_Id = " + Recon_Id + "", con);
                                            con.Open();
                                            Updt_cmd2.ExecuteNonQuery();
                                            con.Close();
                                        }
                                    }
                                    // ragav 25 05 2017 
                                    else if (Recon_name == "WEB COLLECTIONS")
                                    {
                                        //Commented By aneesh 03-05-18
                                        string Output_Dir = Directory + "Input\\Crystal Report\\" + Country + "\\";
                                        string Output_Path1 = Output_Path + temp_FileName;
                                        bool count_check = false;
                                        //obj.Web_Collection(Soure_Path, Output_Dir, Output_Path, (Output_Path + temp_FileName), Recon_name, Recon_Date, Formatted_File_Name, temp_FileName);
                                        obj.Web_Collection_UPD(conString, Soure_Path, Output_Dir, Output_Path, (Output_Path + temp_FileName), Recon_name, Recon_Date, Formatted_File_Name, temp_FileName, out count_check);
                                        if (count_check == true)
                                        {
                                            For_Counter++;
                                        }
                                    }
                                    else if (Recon_name == "MY- Suspense Accounts  288160,288161 & 288169")
                                    {
                                        //Commited By Aneesh ---03-05-18
                                        string Output_Dir = Directory + "Input\\Crystal Report\\" + Country + "\\";
                                        string Output_Path1 = Output_Path + temp_FileName;
                                        bool count_check = false;
                                        obj.mysuspense_288169(conString, Soure_Path, Output_Dir, Output_Path, (Output_Path + temp_FileName), Recon_name, Recon_Date, Formatted_File_Name, temp_FileName, out count_check);
                                        For_Counter++;

                                    }
                                    else if (Recon_name == "Srilanka TLM Open Items-CA-LK-BRH-122131")
                                    {
                                        string Output_Dir = Directory + "Input\\Crystal Report\\India\\";
                                        obj.RBIRTGS(Soure_Path, Desti_Path + Recon_name + "\\" + Formatted_File_Name, Formatted_File_Name, Output_Path);
                                        For_Counter++;
                                    }
                                    else if (Recon_name == "SG0000094921")
                                    {
                                        string Output_Dir = Directory + "Input\\Crystal Report\\India\\";
                                        obj.SG0000094921(Soure_Path, Desti_Path + Recon_name + "\\" + Formatted_File_Name, Formatted_File_Name, Output_Path);
                                        For_Counter++;
                                    }
                                    else if (Recon_name == "JP0000005862")
                                    {
                                        string Output_Dir = Directory + "Input\\Crystal Report\\India\\";
                                        obj.JP0000005862(Soure_Path, Desti_Path + Recon_name + "\\" + Formatted_File_Name, Formatted_File_Name, Output_Path);
                                        For_Counter++;
                                    }
                                    else if (Recon_name == "SCBMA1638")
                                    {
                                        string Output_Dir = Directory + "Input\\Crystal Report\\India\\";
                                        obj.SCBMA1638(Soure_Path, Desti_Path + Recon_name + "\\" + Formatted_File_Name, Formatted_File_Name, Output_Path);
                                        For_Counter++;
                                    }
                                    else if (Recon_name == "RBI RTGS")
                                    {
                                        string Output_Dir = Directory + "Input\\Crystal Report\\India\\";
                                        obj.RBIRTGS1(Soure_Path, Desti_Path + Recon_name + "\\" + Formatted_File_Name, Formatted_File_Name, Output_Path);
                                        For_Counter++;
                                    }
                                    else if (Recon_name == "TR0190033936")
                                    {
                                        string Output_Dir = Directory + "Input\\Crystal Report\\India\\";
                                        obj.TR0190033936(Soure_Path, Desti_Path + Recon_name + "\\" + Formatted_File_Name, File_Name, Formatted_File_Name, Output_Path);
                                        For_Counter++;
                                    }
                                    else
                                    {
                                        File.Copy(Soure_Path, Output_Path + temp_FileName, true);
                                        For_Counter++;
                                    }
                                }
                                else
                                {
                                    if (!File.Exists(Output_Path + File_Name + "." + File_Ext))
                                    {
                                        if (Recon_name != "Hong Kong Trade RPR" && Recon_name != "Singapore Trade RPR")
                                        {
                                            For_Counter++;
                                            File.Copy(Soure_Path, Output_Path + File_Name + "." + File_Ext);
                                        }
                                    }

                                    if (Recon_name == "Singapore SEC RPR")
                                    {
                                        DataTable dt = obj.Formatting_Singapore_SSC(Convert.ToString(d[2]), Soure_Path);
                                        Formatting_SG_SEC_RPR_Signs(dt);
                                        dt_Final.Merge(dt);
                                        For_Counter++;
                                    }
                                    else if (Recon_name == "Hong Kong LPU RPR")
                                    {
                                        DataTable dt = obj.Formatting_HongKong_LPU(Convert.ToString(d[2]), Soure_Path);
                                        Formatting_SG_SEC_RPR_Signs(dt);
                                        dt_Final.Merge(dt);
                                        For_Counter++;

                                        if (dt_Final.Rows.Count == 0)
                                            dt_Final.Rows.Add("NULL");
                                    }
                                    else if (Recon_name == "Singapore Trade RPR")
                                    {
                                        string Output_Dir = Directory + "Input\\Crystal Report\\" + Country + "\\";
                                        string Save_File_Path = "";
                                        string Save_File_Path_1 = "";
                                        if (Soure_Path.Contains("TB_OPS_DAILY_TRADE_REPORT"))
                                        {
                                            obj.Singapore_Trade_RPR_TBOPS(Soure_Path, Output_Dir, Output_Path, Recon_name, Recon_Date, Formatted_File_Name);
                                            For_Counter++;
                                        }
                                        else if (Soure_Path.Contains("IMXBP791 BR") || Soure_Path.Contains("IMXBP791 SUB"))
                                        {
                                            DataTable dt = obj.Formatting_Singapore_Trade_Rpr(Convert.ToString(d[2]), Soure_Path, Output_Dir, Recon_Date);
                                            dt_Final.Merge(dt);
                                            For_Counter++;
                                            For_Counter1++;
                                            if (For_Counter1 > 1)
                                            {
                                                Save_File_Path = Output_Path + "IMXBP791.csv";
                                                obj.ExportToExcel_Common(dt_Final, Save_File_Path);
                                                //File.Move(Save_File_Path, Path.ChangeExtension(Save_File_Path, ".csv"));
                                            }

                                        }
                                        else if (Soure_Path.Contains("20opxor029") || Soure_Path.Contains("18opxor029"))
                                        {
                                            DataTable dt = obj.Formatting_Singapore_Trade_Rpr(Convert.ToString(d[2]), Soure_Path, Output_Dir, Recon_Date);
                                            dt_Final1.Merge(dt);
                                            For_Counter++;
                                            For_Counter2++;
                                            if (For_Counter2 > 1)
                                            {
                                                dt_Final.Merge(dt_Final1);
                                                Save_File_Path = Output_Path + "18opxor029.csv";
                                                Save_File_Path_1 = Output_Path + "Final_Output.csv";
                                                obj.ExportToExcel_Common(dt_Final1, Save_File_Path);
                                                obj.ExportToExcel_Common(dt_Final, Save_File_Path_1);

                                            }
                                        }
                                    }



                                    //25-05 Kiran
                                    else if (Recon_name == "Hong Kong Trade RPR")
                                    {
                                        if (File_Name.Contains("TB_OPS_DAILY_TRADE_REPORT"))
                                        {
                                            obj.HongKongTradeRPR_TBOPS(Soure_Path, Desti_Path + Formatted_File_Name + File_Ext, Desti_Path, Output_Path, Recon_Date, Recon_name, Formatted_File_Name, File_Ext);
                                        }
                                        else if (File_Name.Contains("IMXHP2B1"))
                                        {
                                            obj.HongKongTradeRPR_IMXHP2B1(Soure_Path, Soure_Path, Desti_Path + Formatted_File_Name + File_Ext, Desti_Path, Output_Path, Recon_Date, Recon_name, Formatted_File_Name, File_Ext, conString, out dt_HKRPR1);
                                        }
                                        else if (File_Name.Contains("60opxor029"))
                                        {
                                            //19-07
                                            obj.HongKongTradeRPR_60opxor029(Soure_Path, Soure_Path, Desti_Path + Formatted_File_Name + File_Ext, Desti_Path, Output_Path, Recon_Date, Recon_name, Formatted_File_Name, File_Ext, conString, out dt_HKRPR2);
                                            Recon_Date = obj.Get_Recon_Date(conString, Country, "dd-MM-yyyy");
                                            obj.FinalConsolidated_HKTradeRPR(dt_HKRPR1, dt_HKRPR2, Recon_Date, Output_Path);
                                        }
                                        For_Counter++;
                                    }
                                }
                            }
                        }
                        if (For_Counter == dr2.Length && For_Counter != 0)
                        {
                            if (dt_Final.Rows.Count > 0 && (Recon_name == "Singapore SEC RPR" || Recon_name == "Hong Kong LPU RPR"))
                            {
                                string SaveFilePAth = obj.ExportToExcel(dt_Final, ref Output_Path, Recon_name, Output_Path, Directory, Flag);
                                //AUTOMATIONSTARTTIME = null,
                                //AUTOMATIONENDTIME = null,
                                if (!string.IsNullOrEmpty(SaveFilePAth))
                                {
                                    SqlCommand Updt_cmd2 = new SqlCommand("update ARC_Recon_Master set Is_Recon_Completed = 1, Recon_Status = 'COMPLETED', PSID = '" + Environment.UserName + "',AUTOMATIONSTARTTIME='" + DateTime.Now.ToLongTimeString() + "',AUTOMATIONENDTIME='" + DateTime.Now.ToLongTimeString() + "' where Recon_Id = " + Recon_Id + "", con);
                                    con.Open();
                                    Updt_cmd2.ExecuteNonQuery();
                                    con.Close();
                                }
                            }
                            else
                            {
                                SqlCommand Updt_cmd2 = new SqlCommand("update ARC_Recon_Master set Is_Recon_Completed = 1, Recon_Status = 'COMPLETED', PSID = '" + Environment.UserName + "',AUTOMATIONSTARTTIME='" + DateTime.Now.ToLongTimeString() + "',AUTOMATIONENDTIME='" + DateTime.Now.ToLongTimeString() + "' where Recon_Id = " + Recon_Id + "", con);
                                con.Open();
                                Updt_cmd2.ExecuteNonQuery();
                                con.Close();
                            }
                            //*********************************************************************************************

                            //SA1001
                            objReconLog.ReconID = Recon_Id.ToString();
                            objReconLog.LineNo = "NIL";
                            objReconLog.ErrorMessage = "NIL";
                            objReconLog.Flag = "End";
                            //objReconLog.StartTime = "";
                            objReconLog.EndTime = DateTime.Now.ToShortTimeString();
                            objReconLog.ReconName = Recon_name;
                            objReconLog.UserID = Environment.UserName;
                            //objReconLog.DateTime = DateTime.Now.ToString();
                            insertReconLog(objReconLog);
                            Console.WriteLine("End Time -->" + DateTime.Now.ToShortTimeString() + " Recon: " + Recon_name + " --> Completed Successfully");
                            //EA1001

                        }


                    }

                }
                //aTimer.Start();
            }
            catch (Exception ex)
            {
                //int linenum = Convert.ToInt32(ex.StackTrace.Substring(ex.StackTrace.LastIndexOf(' ')));
                //string exception = "Line No:" + linenum.ToString(); // +"-" + ex.Message.ToString().Substring(0, ex.Message.ToString().Length - 10);
                //Console.WriteLine("Exception -->>" + DateTime.Now.ToShortTimeString());
                SqlConnection con = new SqlConnection(conString);
                SqlCommand Updt_cmd2 = new SqlCommand("update ARC_Recon_Master set Is_Recon_Completed = 1, Recon_Status = 'SKIP', PSID = '" + Environment.UserName + "' where Recon_Id = " + Recon_Id + "", con);
                con.Open();
                Updt_cmd2.ExecuteNonQuery();
                con.Close();
                //SA1001
                Console.WriteLine("End Time -->" + DateTime.Now.ToShortTimeString() + " Recon: " + Recon_name + " --> Has Formatting Issue Please Check Once Again");
                objReconLog.ReconID = Recon_Id.ToString();
                objReconLog.LineNo = "Nil";//linenum.ToString();
                objReconLog.ErrorMessage = ex.ToString();
                objReconLog.Flag = "Error";
                objReconLog.StartTime = "";
                objReconLog.EndTime = "";
                //objReconLog.ReconName = Recon_name;   
                objReconLog.UserID = Environment.UserName;
                objReconLog.DateTime = DateTime.Now.ToString();
                insertReconLog(objReconLog);
                //EA1001
                //aTimer.Start();
            }
        }

        public void Formating_3_2(string StrDirectory)
        {
            aTimer.Stop();
            //SA1001
            Program.clsReconLog objReconLog = new Program.clsReconLog();
            //EA1001
            string Recon_name = "";
            try
            {
                DAccess das = new DAccess();
                Formatting_Logics obj = new Formatting_Logics();
                Hashtable hat = new Hashtable();
                int insupdaval = 0;
                string sDirectory = Main_DIR_SharePath + DateTime.Now.ToString("dd-MMM-yyyy") + "_Files\\";

                //Indidvidual recons
                string strquery = "select recon_name,recon_id,total_files,recon_date from Arc_Recon_Master_Holiday_Date_Logic where  recon_name='HK CASH -DAILY' order by recon_name,Recon_date";

                //All Recons
                //string strquery = "select recon_name,recon_id,total_files,recon_date from Arc_Recon_Master_Holiday_Date_Logic where Is_Recon_Completed = 0 and Is_Active = 1 and recon_id in (select recon_id from arc_recon_master where Is_Recon_Completed = 0 and Is_Active = 1 and Is_Holiday_Logic = 1 and recon_name != 'India Clearing' and recon_name != 'India Clearing Inward' and recon_name != 'India Clearing Outward') order by recon_name,Recon_date";


                DataTable dtReconMaster = das.Select_Table(strquery, hat, "Text");

                string strIInputFileName = string.Empty;
                string strOutPutFileName = string.Empty;
                string SourcePath = string.Empty;
                string Foramtted_Recon_Date = string.Empty;
                string strReconName = string.Empty;
                string Desti_Path = string.Empty;
                string Output_Path = string.Empty;
                string Recon_Date = string.Empty;
                string db_Ext = string.Empty;
                bool Flag_Recon = false;

                int iraq_bal = 0;
                DataTable dt_MX1 = new DataTable();
                DataTable dt_MX2 = new DataTable();
                DataTable dt_MX3 = new DataTable();
                DataTable dt_MX4 = new DataTable();
                DataTable dt_ken1 = new DataTable();
                DataTable dt_ken2 = new DataTable();
                DataTable dt_ken3 = new DataTable();
                DataTable dt_ken4 = new DataTable();
                DataTable dt_ken5 = new DataTable();
                DataTable dt_ken6 = new DataTable();
                DataTable CIS_LOT = new DataTable();
                DataTable CIS_SCB = new DataTable();
                DataTable CIS_Consol = new DataTable();
                for (int i = 0; i < dtReconMaster.Rows.Count; i++)
                {
                    Recon_name = Convert.ToString(dtReconMaster.Rows[i]["recon_name"]);
                    int Recon_Id = Convert.ToInt32(dtReconMaster.Rows[i]["recon_id"]);
                    int File_Count = Convert.ToInt32(dtReconMaster.Rows[i]["total_files"]);
                    DateTime dtRecondate = Convert.ToDateTime(dtReconMaster.Rows[i]["recon_date"]);
                    bool chkresult = false;
                    int NoOfFileinFolder = 0;
                    string selquery1 = "select distinct Recon_Date,Is_Recon_Completed from Arc_Recon_Master_Holiday_Date_Logic where recon_name ='" + Recon_name + "' order by Recon_date";
                    DataTable dtsel1 = das.Select_Table(selquery1, hat, "Text");

                    NoOfFileinFolder = obj.CheckFilesFoleder(StrDirectory, Recon_name, Recon_Id.ToString(), dtRecondate, Directory, out chkresult);

                    int ProcessedFileCount = 0;

                    if (File_Count == NoOfFileinFolder)// || Recon_name == "India Clearing Outward" || Recon_name == "India Clearing Inward" || Recon_name == "India Clearing") //// Add "India Clearing" For UAT purpose only - Prakash
                    {
                        //SA1001
                        clearRconLog(objReconLog);
                        objReconLog.ReconID = Recon_Id.ToString();
                        objReconLog.LineNo = "NIL";
                        objReconLog.ErrorMessage = "NIL";
                        objReconLog.Flag = "Start";
                        objReconLog.StartTime = DateTime.Now.ToShortTimeString();
                        objReconLog.EndTime = "NIL";
                        objReconLog.ReconName = Recon_name;
                        objReconLog.UserID = Environment.UserName;
                        objReconLog.DateTime = DateTime.Now.ToString();
                        insertReconLog(objReconLog);
                        Console.WriteLine("Start Time -->" + DateTime.Now.ToShortTimeString() + " Recon: " + Recon_name);
                        //EA1001                        
                        ///Added by Prakash - For checking the Least Recon Date file is processed or not, if not skip that recon and go for next recon
                        string selquery = "select top(1) Report_Source_File_Name,Recon_Date,IsProcessed,automationStatus from arc_scope_baseline_logic where recon ='" + Recon_name + "' order by Recon_date";
                        DataTable dtsel = das.Select_Table(selquery, hat, "Text");

                        if (dtsel.Rows[0]["IsProcessed"].ToString().ToLower() == "false")
                        {
                            if (Recon_name != "India Clearing Outward" && Recon_name != "India Clearing Inward" && Recon_name != "India Clearing")
                            {
                                i++;
                                continue;
                            }
                        }
                        ///Added by Prakash


                        //Indidvidual recons
                        strquery = "select Team, Country_Name, Recon, Report_Source_File_Name,FTP_File_Format_Name, Recon_date from ARC_Scope_Baseline_Logic where recon='HK CASH -DAILY' and recon_date='" + dtRecondate.ToString("MM/dd/yyyy") + "' ";


                        //All Recons-15-02-18
                        //strquery = "select Team, Country_Name, Recon, Report_Source_File_Name,FTP_File_Format_Name, Recon_date from ARC_Scope_Baseline_Logic where recon_id in (select recon_id from arc_recon_master where Is_Recon_Completed = 0 and Is_Active = 1 and Is_Holiday_Logic = 1) and recon_date='" + dtRecondate.ToString("MM/dd/yyyy") + "' ";

                        DataTable dtBaseHoliday = das.Select_Table(strquery, hat, "Text");

                        strquery = "update Arc_Recon_Master_Holiday_Date_Logic set PSID = '" + Environment.UserName + "',AutomationStartTime='" + DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss") + "' where Recon_Id = " + Recon_Id + " and recon_date='" + dtRecondate.ToString("MM/dd/yyyy") + "'";
                        insupdaval = das.ins_upd_fun(strquery, hat, "text");

                        strquery = "select * from Arc_Scope_Baseline where recon='" + Recon_name + "'";
                        DataTable dtScopeBaseline = das.Select_Table(strquery, hat, "Text");

                        DataRow[] dr = dtScopeBaseline.Select("Format_Direct_Upload <> 'Formatting'");
                        DataRow[] dr2 = dtScopeBaseline.Select("Format_Direct_Upload = 'Formatting'");

                        foreach (DataRow d in dr)
                        {
                            strIInputFileName = "";
                            strOutPutFileName = "";
                            string Country = Convert.ToString(d["Country_Name"]);
                            string File_Name = Convert.ToString(d["Report_Source_File_Name"]);
                            string IsFormatting = Convert.ToString(d["Format_Direct_Upload"]);
                            string Source_App = Convert.ToString(d["Source_Application"]);
                            string File_Ext = Convert.ToString(d["File_Format"]);
                            string Formatted_File_Name = Convert.ToString(d["FTP_File_Format_Name"]);
                            string AutomationStatus = Convert.ToString(d["AutomationStatus"]);
                            strReconName = Convert.ToString(d["recon"]);

                            if (Source_App == "PDF_Conversion")
                            {
                                SourcePath = StrDirectory + "Input\\PDF_Conversion\\";
                            }
                            else if (Source_App != "Email")
                            {
                                SourcePath = StrDirectory + "Input\\" + Source_App + "_" + Country + "\\";
                            }
                            else
                            {
                                SourcePath = StrDirectory + "Input\\Emails\\";
                            }
                            Desti_Path = StrDirectory + "output\\" + strReconName + "\\";


                            string filerquery = "Country_name='" + Country + "' and recon='" + strReconName + "' and Report_Source_File_Name='" + File_Name + "'";
                            if (Formatted_File_Name != null)
                            {
                                if (Formatted_File_Name.Trim().ToUpper() != "NULL")
                                {
                                    filerquery = filerquery + " and FTP_File_Format_Name='" + Formatted_File_Name + "'";
                                }
                            }

                            if (Recon_name == "Nepal - ATM CUP INTERNATIONAL Recon")
                            {
                                Formatted_File_Name = Convert.ToString(d["FTP_File_Format_Name"]);
                                File_Name = Convert.ToString(d["Report_Source_File_Name"]);

                                DateTime dtfiledate = dtRecondate.AddDays(1);
                                File_Name = File_Name.Substring(0, 4) + dtfiledate.ToString("yyddMM");

                                Recon_Date = dtRecondate.ToString("ddMMyyyy");
                                Formatted_File_Name = Formatted_File_Name.Replace("DDMMYYYY", Recon_Date);
                                strOutPutFileName = Formatted_File_Name;

                                string[] strGetFile = System.IO.Directory.GetFiles(SourcePath, File_Name + "*");
                                for (int f = 0; f < strGetFile.Length; f++)
                                {
                                    strIInputFileName = Path.GetFileName(strGetFile[f]);
                                }
                            }
                            else if (Recon_name == "Qatar STS Holding and Cashiers Order EBBS")
                            {
                                strIInputFileName = File_Name + "." + File_Ext;
                                strOutPutFileName = Formatted_File_Name;
                            }
                            else if (Recon_name == "Qatar - RCMS")
                            {
                                if (File_Name.Contains("SCB_GL_"))
                                {
                                    strIInputFileName = File_Name + "." + File_Ext;
                                    strOutPutFileName = Formatted_File_Name;
                                }
                                else
                                {
                                    Recon_Date = dtRecondate.ToString("ddMMyy");
                                    File_Name = File_Name.Replace("DDMMYY", Recon_Date);
                                    Formatted_File_Name = Formatted_File_Name.Replace("DDMMYY", Recon_Date);
                                    strIInputFileName = File_Name + "." + File_Ext;
                                    strOutPutFileName = Formatted_File_Name;
                                }
                            }
                            else if (Recon_name == "Singapore SCBNet Settlement")
                            {
                                if (File_Name.Contains("MGDAQ_MSG_"))
                                {
                                    Recon_Date = dtRecondate.ToString("ddMMyy");
                                    File_Name = obj.GetFileNameMGDAQ(StrDirectory + "Input\\Shared Drive_" + Country + "\\", Recon_Date) + ".TXT";
                                    strIInputFileName = File_Name;
                                    Recon_Date = dtRecondate.ToString("ddMMyyyy");
                                    Formatted_File_Name = Formatted_File_Name.Replace("DDMMYYYY", Recon_Date);
                                    strOutPutFileName = Formatted_File_Name;
                                }
                                else if (File_Name.Contains("MGDIS_MSG"))
                                {
                                    Recon_Date = dtRecondate.ToString("ddMMyy");
                                    File_Name = obj.GetFileNameMGDIS(StrDirectory + "Input\\Shared Drive_" + Country + "\\", Recon_Date) + ".TXT";
                                    strIInputFileName = File_Name;
                                    Recon_Date = dtRecondate.ToString("ddMMyyyy");
                                    Formatted_File_Name = Formatted_File_Name.Replace("DDMMYYYY", Recon_Date);
                                    strOutPutFileName = Formatted_File_Name;
                                }
                            }
                            else if (Recon_name == "Singapore CUP Settlement")
                            {
                                if (File_Name.Contains("ACOM"))
                                {
                                    Recon_Date = dtRecondate.ToString("yyMMdd");
                                    File_Name = obj.GetFileNameACOM(StrDirectory + "Input\\Shared Drive_" + Country + "\\", Recon_Date);
                                    strIInputFileName = File_Name;
                                    Recon_Date = dtRecondate.ToString("ddMMyyyy");
                                    Formatted_File_Name = Formatted_File_Name.Replace("DDMMYYYY", Recon_Date);
                                    strOutPutFileName = Formatted_File_Name;
                                }
                            }
                            else if (Recon_name == "Nepal -Retail Banking ATM CARD RECON" || Recon_name == "JORDAN - ATM RECON")
                            {
                                Formatted_File_Name = Convert.ToString(d["FTP_File_Format_Name"]);
                                File_Name = Convert.ToString(d["Report_Source_File_Name"]);

                                DateTime dtfiledate = dtRecondate.AddDays(1);
                                File_Name = File_Name.Substring(0, 4) + dtfiledate.ToString("yyddMM");

                                if (Formatted_File_Name.Contains("YYYYMMDD"))
                                {
                                    Recon_Date = dtRecondate.ToString("yyyyMMdd");
                                    Formatted_File_Name = Formatted_File_Name.Replace("YYYYMMDD", Recon_Date);
                                }
                                else if (Formatted_File_Name.Contains("DDMMYYYY"))
                                {
                                    Recon_Date = dtRecondate.ToString("ddMMyyyy");
                                    Formatted_File_Name = Formatted_File_Name.Replace("DDMMYYYY", Recon_Date);
                                }
                                strOutPutFileName = Formatted_File_Name;

                                string[] strGetFile = System.IO.Directory.GetFiles(SourcePath, File_Name + "*");
                                for (int f = 0; f < strGetFile.Length; f++)
                                {
                                    strIInputFileName = Path.GetFileName(strGetFile[f]);
                                }
                            }
                            else if (Recon_name == "India Trade RPR")
                            {
                                if (File_Name.Contains("40opxor029"))
                                {
                                    strIInputFileName = obj.IndiaRPR(StrDirectory + "Input\\OPICS Report LINK_India");
                                    strIInputFileName = strIInputFileName + "." + File_Ext;
                                    strOutPutFileName = Formatted_File_Name;
                                }
                                else if (File_Name.Contains("TB_OPS_DAILY_TRADE_REPORT"))
                                {
                                    Recon_Date = dtRecondate.ToString("yyyyMMdd");
                                    File_Name = File_Name.Replace("YYYYMMDD", Recon_Date) + "." + File_Ext;
                                    strIInputFileName = File_Name;
                                    Recon_Date = dtRecondate.ToString("ddMMyyyy");
                                    Formatted_File_Name = Formatted_File_Name.Replace("DDMMYYYY", Recon_Date);
                                    strOutPutFileName = Formatted_File_Name;
                                }
                                else if (File_Name.Contains("PSGL_INDIA_BAL_285004_289954") || File_Name.Contains("IMX") || File_Name.Contains("RPR"))
                                {
                                    Recon_Date = dtRecondate.ToString("ddMMyyyy");
                                    File_Name = File_Name.Replace("DDMMYYYY", Recon_Date) + "." + File_Ext;
                                    strIInputFileName = File_Name;
                                    Formatted_File_Name = Formatted_File_Name.Replace("DDMMYYYY", Recon_Date);
                                    strOutPutFileName = Formatted_File_Name;
                                }
                                //else if (File_Name.Contains("FX_DEALS_IND"))
                                //{
                                //    Recon_Date = dt_Recon.ToString("ddMMyyyy");
                                //    File_Name = File_Name.Replace("DDMMYYYY", Recon_Date);
                                //    strIInputFileName = File_Name;
                                //}
                            }
                            else if (Recon_name == "Brunei - BCC Borrowing")
                            {
                                if (File_Name.ToUpper().Contains("DD-MMM YYYY"))
                                {
                                    Recon_Date = dtRecondate.ToString("dd-MMM yyyy");
                                    string Rec_Date_01 = DateTime.Now.ToString("dd-MMM-yyyy");
                                    File_Name = File_Name.Replace("DD-MMM-YYYY", Rec_Date_01);
                                    File_Name = File_Name.Replace("DD-MMM YYYY", Recon_Date) + "." + File_Ext;
                                    strIInputFileName = File_Name;
                                    strOutPutFileName = File_Name;
                                }

                                else if (File_Name.ToUpper().Contains("DDMMYYYY"))
                                {
                                    Recon_Date = dtRecondate.ToString("ddMMyyyy");
                                    File_Name = File_Name.Replace("DDMMYYYY", Recon_Date) + "." + File_Ext;
                                    strIInputFileName = File_Name;
                                    strOutPutFileName = File_Name;
                                }
                            }
                            else if (Recon_name == "Hong Kong CMS RPR")
                            {
                                if (File_Name.Contains("60opxor029"))
                                {
                                    strIInputFileName = File_Name + "." + File_Ext;
                                    strOutPutFileName = File_Name + "." + File_Ext;
                                }
                                else if (File_Name.ToUpper().Contains("DDMMYYYY"))
                                {
                                    Recon_Date = dtRecondate.ToString("ddMMyyyy");
                                    File_Name = File_Name.Replace("DDMMYYYY", Recon_Date) + "." + File_Ext;
                                    strIInputFileName = File_Name;
                                    strOutPutFileName = File_Name;
                                }
                            }

                            else if (Recon_name == "Mobile Recharge Transaction - Reconciliation-Total")
                            {
                                string FilePath = Directory + "Input\\" + Source_App + "_" + Country + "\\";
                                Output_Path = Directory + "Output\\" + Recon_name + "\\";
                                Desti_Path = Directory + "Files_For_Formatting_Or_Non_Formatting\\" + Recon_name + "\\Non_Formatting\\";

                                Recon_Date = dtRecondate.ToString("yyyyMMdd");

                                if (ProcessedFileCount == 0)
                                {
                                    obj.Mobile_Recharge_Validation(File_Name, FilePath, Output_Path, Recon_Date, Desti_Path);
                                    ProcessedFileCount = 4;
                                }
                            }
                            else if (Recon_name == "Acquirer Transactions - Manual Match  UnMatch Move" || Recon_name == "Acquirer Transactions - Manual Match  UnMatch Move master")
                            {
                                if (File_Name.ToUpper().Contains("DDMMYYYY"))
                                {
                                    Recon_Date = dtRecondate.ToString("ddMMyyyy");

                                    File_Name = File_Name.Replace("DDMMYYYY", Recon_Date) + "." + File_Ext;

                                    if (File_Name.Contains(".PGP"))
                                    {
                                        strIInputFileName = File_Name.Replace(".PGP", "");
                                    }
                                    else
                                    {
                                        strIInputFileName = File_Name;
                                    }

                                    Formatted_File_Name = Formatted_File_Name.Replace("DDMMYYYY", Recon_Date);
                                    strOutPutFileName = Formatted_File_Name;
                                }
                                else if (File_Name.Contains("CS105D EP-745"))
                                {
                                    Recon_Date = dtRecondate.ToString("ddMMyyyy");
                                    File_Name = File_Name + "_" + Recon_Date + "." + File_Ext;
                                    strIInputFileName = File_Name;

                                    Formatted_File_Name = Formatted_File_Name.Replace("DDMMYYYY", Recon_Date);
                                    strOutPutFileName = Formatted_File_Name;
                                }
                                else if (File_Name.Contains("CS105D EP-747"))
                                {
                                    Recon_Date = dtRecondate.ToString("ddMMyyyy");
                                    File_Name = File_Name + "_" + Recon_Date + "." + File_Ext;
                                    strIInputFileName = File_Name;
                                    strOutPutFileName = "";
                                    ProcessedFileCount++;
                                }
                                else if (File_Name.ToUpper().Contains("DDMMYY"))
                                {
                                    Recon_Date = dtRecondate.ToString("ddMMyy");
                                    File_Name = File_Name.Replace("DDMMYY", Recon_Date) + "." + File_Ext;
                                    strIInputFileName = File_Name;
                                    Formatted_File_Name = Formatted_File_Name.Replace("DDMMYYYY", Recon_Date);
                                    strOutPutFileName = Formatted_File_Name;
                                }

                                if (File_Name.Contains("T464"))
                                {
                                    Recon_Date = dtRecondate.AddDays(-1).ToString("dd");
                                    File_Name = File_Name + ".D" + Recon_Date;
                                    strIInputFileName = File_Name;

                                    Formatted_File_Name = Formatted_File_Name.Replace("DDMMYYYY", dtRecondate.ToString("ddMMyyyy"));
                                    strOutPutFileName = Formatted_File_Name;
                                }
                            }
                            else if (Recon_name == "Hong Kong – SCBNET")
                            {
                                if (File_Name.Contains("MGDAQ_MHK_"))
                                {
                                    Recon_Date = dtRecondate.ToString("ddMMyy");
                                    File_Name = obj.GetSpecificFileName_HKSCBNET1(sDirectory + "Input\\Shared Drive_Hong Kong\\", Recon_Date);// +".txt";
                                    strIInputFileName = File_Name;
                                    Recon_Date = dtRecondate.ToString("ddMMyyyy");
                                    Formatted_File_Name = Formatted_File_Name.Replace("DDMMYYYY", Recon_Date);
                                    strOutPutFileName = Formatted_File_Name;
                                }
                                else if (File_Name.Contains("MGDIS_MHK_"))
                                {
                                    Recon_Date = dtRecondate.ToString("ddMMyy");
                                    File_Name = obj.GetSpecificFileName_HKSCBNET2(sDirectory + "Input\\Shared Drive_Hong Kong\\", Recon_Date);// +".txt";
                                    strIInputFileName = File_Name;
                                    Recon_Date = dtRecondate.ToString("ddMMyyyy");
                                    Formatted_File_Name = Formatted_File_Name.Replace("DDMMYYYY", Recon_Date);
                                    strOutPutFileName = Formatted_File_Name;
                                }
                                else
                                {
                                    Recon_Date = dtRecondate.ToString("ddMMyyyy");
                                    File_Name = File_Name.Replace("DDMMYYYY", Recon_Date) + "." + File_Ext;
                                    strIInputFileName = File_Name;
                                    strOutPutFileName = File_Name;
                                }
                            }
                            else if (File_Name.ToUpper().Contains("DDMMYYYY") && !File_Name.ToUpper().Contains("YYYYMMDD"))
                            {
                                if (Recon_name == "Kenya - VISA Electron ATM Suspense AC recon and outstanding Report")
                                {
                                    Recon_Date = dtRecondate.ToString("ddMMyyyy");

                                    DateTime myDate = DateTime.ParseExact(dtRecondate.ToString("ddMMyyyy"), "ddMMyyyy", System.Globalization.CultureInfo.InvariantCulture);
                                    DateTime myDate1 = DateTime.ParseExact(dtRecondate.ToString("yyyyMMdd"), "yyyyMMdd", System.Globalization.CultureInfo.InvariantCulture);
                                    if (File_Name.Contains("debit4"))
                                    {
                                        int date1 = myDate.DayOfYear;

                                        File_Name = File_Name.Replace("DDMMYYYY", Recon_Date);
                                        File_Name = File_Name.Replace("DDD", date1.ToString().PadLeft(3, '0'));
                                        strIInputFileName = File_Name;

                                        Formatted_File_Name = Formatted_File_Name.Replace("YYYYMMDD", myDate1.ToString("yyyyMMdd"));
                                        strOutPutFileName = Formatted_File_Name;
                                    }
                                }
                                else if (Recon_name == "CLS-MLS Recon" || Recon_name == "Malaysia-RPR" || Recon_name == "Taiwan-RPR" || Recon_name == "Thailand-RPR" || Recon_name == "Hong kong CMU")
                                {
                                    Recon_Date = dtRecondate.ToString("ddMMyyyy");
                                    File_Name = File_Name.Replace("DDMMYYYY", Recon_Date) + "." + File_Ext;
                                    Recon_Date = dtRecondate.ToString("yyyyMMdd");
                                    Formatted_File_Name = Formatted_File_Name.Replace("YYYYMMDD", Recon_Date);
                                    strIInputFileName = File_Name;
                                    strOutPutFileName = Formatted_File_Name;
                                }
                                else if (Recon_name == "Srilanka TLM Open Items-CA-LK-BRH-CA-LK-BRH-289095-LKR-RLS")
                                {
                                    Recon_Date = dtRecondate.ToString("ddMMyyyy");
                                    File_Name = File_Name.Replace("DDMMYYYY", Recon_Date) + "." + File_Ext;
                                    Formatted_File_Name = Formatted_File_Name.Replace("DDMMYYYY", Recon_Date);
                                    strIInputFileName = File_Name;
                                    strOutPutFileName = Formatted_File_Name;
                                }
                                else if (Recon_name == "Srilanka TLM Open Items-CA-LK-BRH-289109-LKR - Debit card account")
                                {
                                    Recon_Date = dtRecondate.ToString("ddMMyyyy");
                                    File_Name = File_Name.Replace("DDMMYYYY", Recon_Date) + "." + File_Ext;
                                    Formatted_File_Name = Formatted_File_Name.Replace("DDMMYYYY", Recon_Date);
                                    strIInputFileName = File_Name;
                                    strOutPutFileName = Formatted_File_Name;
                                }
                                else if (Recon_name == "Thailand Phase 1 and 2 account" || Recon_name == "ENETS SETTLEMENT" || Recon_name == "SINGAPORE ATM and CDM")
                                {
                                    Recon_Date = dtRecondate.ToString("ddMMyyyy");
                                    File_Name = File_Name.Replace("DDMMYYYY", Recon_Date) + "." + File_Ext;
                                    Formatted_File_Name = Formatted_File_Name.Replace("DDMMYYYY", Recon_Date);
                                    strIInputFileName = File_Name;
                                    strOutPutFileName = Formatted_File_Name;
                                }
                                else if (Recon_name == "India RPR")
                                {
                                    Recon_Date = dtRecondate.ToString("ddMMyyyy");
                                    File_Name = File_Name.Replace("DDMMYYYY", Recon_Date) + "." + File_Ext;
                                    Recon_Date = dtRecondate.ToString("yyyyMMdd");
                                    Formatted_File_Name = Formatted_File_Name.Replace("YYYYMMDD", Recon_Date);
                                    strIInputFileName = File_Name;
                                    strOutPutFileName = Formatted_File_Name;
                                }
                                else
                                {
                                    Recon_Date = dtRecondate.ToString("ddMMyyyy");
                                    File_Name = File_Name.Replace("DDMMYYYY", Recon_Date) + "." + File_Ext;
                                    strIInputFileName = File_Name;
                                    strOutPutFileName = File_Name;
                                }
                            }
                            else if (File_Name.ToUpper().Contains("DD.MM.YYYY"))
                            {
                                if (Recon_name == "Indonesia -TRADE & LPU RECON")
                                {
                                    Recon_Date = dtRecondate.ToString("dd.MM.yyyy");
                                    File_Name = File_Name.Replace("DD.MM.YYYY", Recon_Date) + " ." + File_Ext;
                                    Formatted_File_Name = Formatted_File_Name.Replace("DD.MM.YYYY", Recon_Date);
                                    strIInputFileName = File_Name;
                                    strOutPutFileName = Formatted_File_Name;
                                }
                                else if (Recon_name == "HK CASH -DAILY")
                                {
                                    Recon_Date = dtRecondate.ToString("dd.MM.yyyy");
                                    //Sankalp 13 Aug
                                    File_Name = File_Name.Replace("DD.MM.YYYY", Recon_Date) + "." + File_Ext;
                                    Formatted_File_Name = Formatted_File_Name.Replace("DD.MM.YYYY", Recon_Date);
                                    strIInputFileName = File_Name;
                                    strOutPutFileName = Formatted_File_Name;
                                    //Recon_Date = dtRecondate.ToString("dd.MM.yyyy");
                                    //File_Name = File_Name.Replace("DD.MM.YYYY", Recon_Date).Replace(".", "") + "." + File_Ext;
                                    //Formatted_File_Name = Formatted_File_Name.Replace("DD.MM.YYYY", Recon_Date);
                                    //strIInputFileName = File_Name;
                                    //strOutPutFileName = Formatted_File_Name;
                                }
                                else
                                {
                                    Recon_Date = dtRecondate.ToString("dd.MM.yyyy");
                                    File_Name = File_Name.Replace("DD.MM.YYYY", Recon_Date) + "." + File_Ext;
                                    Formatted_File_Name = Formatted_File_Name.Replace("DD.MM.YYYY", Recon_Date);
                                    strIInputFileName = File_Name;
                                    strOutPutFileName = Formatted_File_Name;
                                }
                            }
                            else if (File_Name.ToUpper().Contains("DD.MM.YY"))
                            {
                                if (Recon_name == "India -OCCS")
                                {
                                    Recon_Date = dtRecondate.ToString("dd.MM.yy");
                                    File_Name = File_Name.Replace("DD.MM.YY", Recon_Date) + "." + File_Ext;
                                    Formatted_File_Name = Formatted_File_Name.Replace("DD.MM.YY", Recon_Date);
                                    strIInputFileName = File_Name;
                                    strOutPutFileName = Formatted_File_Name;
                                }
                            }
                            else if (File_Name.ToUpper().Contains("YYMMDD") && !File_Name.ToUpper().Contains("YYYYMMDD"))
                            {
                                if (Recon_name == "SUSPENSE OPEN ITEMS(CUP)")
                                {
                                    Recon_Date = dtRecondate.ToString("yyMMdd");
                                    File_Name = File_Name.Replace("YYMMDD", Recon_Date);
                                    Recon_Date = dtRecondate.ToString("ddMMyyyy");
                                    Formatted_File_Name = Formatted_File_Name.Replace("DDMMYYYY", Recon_Date);

                                    strIInputFileName = File_Name;
                                    strOutPutFileName = Formatted_File_Name;
                                }
                                //else if (Recon_name == "JORDAN - ATM RECON")
                                //{
                                //    if (File_Name.Contains("SMS_"))
                                //    {
                                //        Recon_Date = dtRecondate.ToString("yyMMdd");
                                //        File_Name = obj.GetSpecificFileName_JordanATMRecon(StrDirectory + "Input\\SharedDrive_Jordan\\", Recon_Date) + "." + File_Ext;
                                //        Recon_Date = dtRecondate.ToString("yyyyMMdd");
                                //        Formatted_File_Name = Formatted_File_Name.Replace("YYYYMMDD", Recon_Date);

                                //        strIInputFileName = File_Name;
                                //        strOutPutFileName = Formatted_File_Name;
                                //    }
                                //}
                                else
                                {
                                    Recon_Date = dtRecondate.ToString("yyMMdd");
                                    File_Name = File_Name.Replace("YYMMDD", Recon_Date) + "." + File_Ext;
                                    strIInputFileName = File_Name;
                                    strOutPutFileName = File_Name;
                                }
                            }
                            else if (File_Name.ToUpper().Contains("DDMMYY") && !File_Name.ToUpper().Contains("YYYYMMDD"))
                            {
                                if (Recon_name == "Srilanka TLM Open Items-CA-LK-BRH-170254-LKR-LANKA BELL (PD)" || Recon_name == "CDSC Stock Recon")
                                {
                                    Recon_Date = dtRecondate.ToString("ddMMyy");
                                    File_Name = File_Name.Replace("DDMMYY", Recon_Date);
                                    Recon_Date = dtRecondate.ToString("ddMMyyyy");
                                    Formatted_File_Name = Formatted_File_Name.Replace("DDMMYYYY", Recon_Date);

                                    strIInputFileName = File_Name + "." + File_Ext;
                                    strOutPutFileName = Formatted_File_Name;
                                }
                                else
                                {
                                    Recon_Date = dtRecondate.ToString("ddMMyy");
                                    File_Name = File_Name.Replace("DDMMYY", Recon_Date) + "." + File_Ext;
                                    strIInputFileName = File_Name;
                                    strOutPutFileName = File_Name;
                                }
                            }
                            else if (File_Name.ToUpper().Contains("YYYYMMDD"))
                            {
                                if (Recon_name == "VIETNAM VND OPEN ITEMS (CITAD)")
                                {
                                    if (File_Name.Contains("LOCALBANK_STMT_TB_VN_SBV_"))
                                    {
                                        Recon_Date = dtRecondate.ToString("yyyyMMdd");
                                        File_Name = File_Name.Replace("YYYYMMDD", Recon_Date) + "." + File_Ext;
                                        strIInputFileName = File_Name;
                                        strOutPutFileName = File_Name;
                                    }

                                    else
                                    {
                                        Recon_Date = dtRecondate.ToString("yyyyMMdd");
                                        string Recon_Date_01 = dtRecondate.ToString("ddMMyyyy");
                                        File_Name = File_Name.Replace("DDMMYYYY", Recon_Date_01);
                                        File_Name = File_Name.Replace("YYYYMMDD", Recon_Date) + "." + File_Ext;
                                        strIInputFileName = File_Name;
                                        strOutPutFileName = File_Name;
                                    }
                                }
                                else if (Recon_name == "OPICS-ABS Position daily")
                                {
                                    Recon_Date = dtRecondate.ToString("yyyyMMdd");
                                    File_Name = File_Name.Replace("YYYYMMDD", Recon_Date) + "." + File_Ext;
                                    Formatted_File_Name = Formatted_File_Name.Replace("YYYYMMDD", Recon_Date);
                                    strIInputFileName = File_Name;
                                    strOutPutFileName = Formatted_File_Name;
                                }

                                else if (Recon_name == "Srilanka TLM Open Items-CA-LK-BRH-170254-LKR-ARPICO")
                                {
                                    Recon_Date = dtRecondate.ToString("yyyyMMdd");
                                    File_Name = obj.GetSpecificFileName_APRICO(sDirectory + "Input\\Emails\\", Recon_Date) + "." + File_Ext;
                                    Recon_Date = dtRecondate.ToString("MMddyyyy");
                                    Formatted_File_Name = Formatted_File_Name.Replace("MMDDYYYY", Recon_Date);
                                    strIInputFileName = File_Name;
                                    strOutPutFileName = Formatted_File_Name;
                                }
                                else
                                {
                                    Recon_Date = dtRecondate.ToString("yyyyMMdd");
                                    File_Name = File_Name.Replace("YYYYMMDD", Recon_Date) + "." + File_Ext;
                                    strIInputFileName = File_Name;
                                    strOutPutFileName = File_Name;
                                }
                            }
                            else if (File_Name.ToUpper().Contains("DDMMM"))
                            {
                                Recon_Date = dtRecondate.ToString("ddMMM");
                                File_Name = File_Name.Replace("DDMMM", Recon_Date) + "." + File_Ext;
                                strIInputFileName = File_Name;
                                strOutPutFileName = File_Name;
                            }
                            else if (File_Name.ToUpper().Contains("DD_MM"))
                            {
                                Recon_Date = dtRecondate.ToString("dd_MM").ToUpper();
                                File_Name = File_Name.Replace("DD_MM", Recon_Date) + "." + File_Ext;
                                Formatted_File_Name = Formatted_File_Name.Replace("DD_MM", Recon_Date);
                                strIInputFileName = File_Name;
                                strOutPutFileName = Formatted_File_Name;
                            }
                            else if (File_Name.ToUpper().Contains("YYDDMM"))
                            {
                                if (Recon_name == "Botswana-card suspense - inter reject - disputed recon" || Recon_name == "Kenya - Card Suspense Reconciliation Report - Disputed Transactions AC Reconciliations" || Recon_name == "NIGERIA 288893 CARD SUSPENSE OPEN ITEM")
                                {
                                    if (File_Name.Contains("SCC_"))
                                    {
                                        Recon_Date = dtRecondate.ToString("yyddMM");
                                        File_Name = obj.GetFileNameBotswanaCard(sDirectory + "Input\\" + Source_App + "_" + Country + "\\", Recon_Date);
                                        Formatted_File_Name = Formatted_File_Name.Replace("YYDDMM", Recon_Date);
                                        strIInputFileName = File_Name;
                                        strOutPutFileName = Formatted_File_Name;

                                    }

                                }
                                else
                                {
                                    Recon_Date = dtRecondate.ToString("yyddMM");
                                    File_Name = obj.GetSpecificFileName_NIGERIACARD(sDirectory + "Input\\" + Source_App + "_" + Country + "\\", Recon_Date);
                                    Formatted_File_Name = Formatted_File_Name.Replace("YYDDMM", Recon_Date);
                                    strIInputFileName = File_Name;
                                    strOutPutFileName = Formatted_File_Name;
                                }
                            }
                            else if (File_Name.ToUpper().Contains("DD-MM-YYYY"))
                            {
                                Recon_Date = dtRecondate.ToString("dd-MM-yyyy");
                                File_Name = File_Name.Replace("DD-MM-YYYY", Recon_Date) + "." + File_Ext;
                                strIInputFileName = File_Name;
                                strOutPutFileName = File_Name;
                            }
                            //File moving output and update database
                            if (strIInputFileName.Trim() != "" && strOutPutFileName.Trim() != "")
                            {
                                if (strIInputFileName.Contains("Brunei_LOCAL") || strIInputFileName.Contains("Brunei_USER_TRANS") || strIInputFileName.Contains("Brunei_USER_ESSEN"))
                                {
                                    string tempInputFileName = strIInputFileName.Replace(".MFD", "");
                                    int cnt_i = 0;
                                    string[] allFiles = System.IO.Directory.GetFiles(SourcePath);
                                    {
                                        foreach (string file in allFiles)
                                        {
                                            string[] txtfile = file.Split('\\');
                                            string strtxtfile = txtfile[txtfile.Length - 1];
                                            if (file.Contains(tempInputFileName))
                                            {
                                                GC.Collect();
                                                File.Copy(SourcePath + strtxtfile, Desti_Path + strtxtfile, true);
                                                cnt_i++;
                                            }
                                        }
                                    }
                                    if (cnt_i > 0)
                                    {
                                        ProcessedFileCount++;
                                    }
                                }
                                //bala
                                if (File.Exists(SourcePath + strIInputFileName))
                                {
                                    GC.Collect();
                                    File.Copy(SourcePath + strIInputFileName, Desti_Path + strOutPutFileName, true);

                                    //strquery = "update ARC_Scope_Baseline_Logic set PSID = '" + Environment.UserName + "', IsProcessed = 1, AutomationStatus = 'COMPLETED' where Country_name='" + Country + "' and recon='" + strReconName + "' and Report_Source_File_Name='" + Convert.ToString(d["Report_Source_File_Name"]) + "' and Recon_date='" + dtRecondate.ToString("MM/dd/yyyy") + "'";
                                    //insupdaval = das.ins_upd_fun(strquery, hat, "text");

                                    ProcessedFileCount++;
                                }
                            }
                        }
                        /////////////////////////////////////////// Formatting Logic /////////////////////////////////////
                        foreach (DataRow d in dr2)
                        {
                            string Country = Convert.ToString(d[4]);
                            string File_Name = Convert.ToString(d[9]);
                            string IsFormatting = Convert.ToString(d[16]);
                            string Source_App = Convert.ToString(d[11]);
                            string File_Ext = Convert.ToString(d[15]);
                            string Formatted_File_Name = Convert.ToString(d[10]);
                            //string AutomationStatus = Convert.ToString(d[7]);
                            ///InputFileName
                            ///
                            string intrimpath;
                            if (Source_App == "Email")
                            {
                                SourcePath = StrDirectory + "Input\\" + "Emails" + "\\";
                                intrimpath = StrDirectory + "Files_For_Formatting_Or_Non_Formatting" + "\\";
                                Desti_Path = StrDirectory + "output\\" + strReconName + "\\";
                            }
                            else
                            {
                                SourcePath = StrDirectory + "Input\\" + Source_App + "_" + Country + "\\";
                                Desti_Path = StrDirectory + "output\\" + strReconName + "\\";
                                intrimpath = StrDirectory + "Files_For_Formatting_Or_Non_Formatting" + "\\";
                            }
                            if (Recon_name == "Nepal SOM Nostro")
                            {
                                if (File_Name.ToUpper().Contains("YYYY_MM_DD"))
                                {
                                    Recon_Date = dtRecondate.ToString("yyyy_MM_dd");
                                    File_Name = File_Name.Replace("YYYY_MM_DD", Recon_Date);
                                    strIInputFileName = File_Name;
                                }
                                else if (File_Name.ToUpper().Contains("MM_DD_YYYY"))
                                {
                                    Recon_Date = dtRecondate.ToString("MM_dd_yyyy");
                                    File_Name = File_Name.Replace("MM_DD_YYYY", Recon_Date);
                                    strIInputFileName = File_Name;
                                }

                            }

                            if (Recon_name == "Acquirer Transactions - Manual Match  UnMatch Move master")
                            {
                                if (File_Name.ToUpper().Contains("MDCC"))
                                {
                                    Recon_Date = dtRecondate.ToString("dd-MM-yyyy");
                                    File_Name = File_Name + "_" + Recon_Date;
                                    strIInputFileName = File_Name;
                                }
                            }
                            if (Recon_name == "Srilanka TLM Open Items-CA-LK-BRH-170254-LKR-ARPICO")
                            {
                                Recon_Date = dtRecondate.ToString("yyyyMMdd");
                                File_Name = obj.GetSpecificFileName_APRICO(sDirectory + "Input\\Emails\\", Recon_Date) + "." + File_Ext;
                                Recon_Date = dtRecondate.ToString("MMddyyyy");
                                Formatted_File_Name = Formatted_File_Name.Replace("MMDDYYYY", Recon_Date);
                                strIInputFileName = File_Name;
                                strOutPutFileName = Formatted_File_Name;
                            }
                            else if (Recon_name == "India Trade RPR")
                            {
                                if (File_Name.Contains("FX_DEALS_IND"))
                                {
                                    Recon_Date = dtRecondate.ToString("ddMMyyyy");
                                    File_Name = File_Name.Replace("DDMMYYYY", Recon_Date) + "." + File_Ext;
                                    strIInputFileName = File_Name;
                                }
                            }
                            if (Recon_name == "Srilanka TLM Open Items-CA-LK-BRH-122131-LKR-CASHDROP")
                            {
                                Recon_Date = dtRecondate.ToString("yyyyMMdd");

                                if (File_Name.Contains("PAYMENT_CASH_Rajagiriya_"))
                                {

                                    File_Name = obj.PAYMENT_CASH_Rajagiriya(Directory + "Input\\Emails\\", Recon_Date) + "." + File_Ext;
                                    strIInputFileName = File_Name;
                                }
                                else if (File_Name.Contains("PAYMENT_CASH_Priority_Center_"))
                                {
                                    File_Name = obj.PAYMENT_CASH_Priority_Center(Directory + "Input\\Emails\\", Recon_Date) + "." + File_Ext;
                                    strIInputFileName = File_Name;
                                }
                                else if (File_Name.Contains("PAYMENT_CASH_PETTAH_"))
                                {
                                    File_Name = obj.PAYMENT_CASH_PETTAH(Directory + "Input\\Emails\\", Recon_Date) + "." + File_Ext;
                                    strIInputFileName = File_Name;
                                }
                                else if (File_Name.Contains("PAYMENT_CASH_MORATUWA_"))
                                {
                                    File_Name = obj.PAYMENT_CASH_MORATUWA(Directory + "Input\\Emails\\", Recon_Date) + "." + File_Ext;
                                    strIInputFileName = File_Name;
                                }
                                else if (File_Name.Contains("PAYMENT_CASH_KIR_"))
                                {
                                    File_Name = obj.PAYMENT_CASH_KIR(Directory + "Input\\Emails\\", Recon_Date) + "." + File_Ext;
                                    strIInputFileName = File_Name;
                                }
                                else if (File_Name.Contains("DEPOSIT_CASH_PETTAH_"))
                                {
                                    File_Name = obj.DEPOSIT_CASH_PETTAH(Directory + "Input\\Emails\\", Recon_Date) + "." + File_Ext;
                                    strIInputFileName = File_Name;
                                }
                                else if (File_Name.Contains("PAYMENT_CASH_FORT_"))
                                {
                                    File_Name = obj.PAYMENT_CASH_FORT(Directory + "Input\\Emails\\", Recon_Date) + "." + File_Ext;
                                    strIInputFileName = File_Name;
                                }
                                else if (File_Name.Contains("PAYMENT_CASH_Col"))
                                {
                                    File_Name = obj.PAYMENT_CASH_Col_3(Directory + "Input\\Emails\\", Recon_Date) + "." + File_Ext;
                                    strIInputFileName = File_Name;
                                }
                                else if (File_Name.Contains("DEPOSIT_CASH_Rajagiriya_"))
                                {
                                    File_Name = obj.DEPOSIT_CASH_Rajagiriya(Directory + "Input\\Emails\\", Recon_Date) + "." + File_Ext;
                                    strIInputFileName = File_Name;
                                }
                                else if (File_Name.Contains("DEPOSIT_CASH_Priority_"))
                                {
                                    File_Name = obj.DEPOSIT_CASH_Priority_Center(Directory + "Input\\Emails\\", Recon_Date) + "." + File_Ext;
                                    strIInputFileName = File_Name;
                                }
                                else if (File_Name.Contains("DEPOSIT_CASH_MORATUWA_"))
                                {
                                    File_Name = obj.DEPOSIT_CASH_MORATUWA(Directory + "Input\\Emails\\", Recon_Date) + "." + File_Ext;
                                    strIInputFileName = File_Name;
                                }
                                else if (File_Name.Contains("DEPOSIT_CASH_KIR_"))
                                {
                                    File_Name = obj.DEPOSIT_CASH_KIR(Directory + "Input\\Emails\\", Recon_Date) + "." + File_Ext;
                                    strIInputFileName = File_Name;
                                }
                                else if (File_Name.Contains("DEPOSIT_CASH_FORT_"))
                                {
                                    File_Name = obj.DEPOSIT_CASH_FORT(Directory + "Input\\Emails\\", Recon_Date) + "." + File_Ext;
                                    strIInputFileName = File_Name;
                                }
                                else if (File_Name.Contains("DEPOSIT_CASH_Col"))
                                {
                                    File_Name = obj.DEPOSIT_CASH_Col_3(Directory + "Input\\Emails\\", Recon_Date) + "." + File_Ext;
                                    strIInputFileName = File_Name;
                                }

                            }
                            if (File_Name.ToUpper().Contains("DDMMM") && !File_Name.ToUpper().Contains("DDMMMYYYY"))
                            {
                                Recon_Date = dtRecondate.ToString("ddMMM");
                                File_Name = File_Name.Replace("DDMMM", Recon_Date);
                                strIInputFileName = File_Name;
                                strOutPutFileName = File_Name;
                            }
                            if (File_Name.ToUpper().Contains("DDMMMYYYY"))
                            {
                                if (Recon_name == "Nepal Account Balance (Instrument)")
                                {
                                    Recon_Date = dtRecondate.ToString("ddMMMyyyy");
                                    File_Name = File_Name.Replace("DDMMMYYYY", Recon_Date) + "." + File_Ext;
                                    Recon_Date = dtRecondate.ToString("ddMMyyyy");
                                    Formatted_File_Name = Formatted_File_Name.Replace("DDMMYYYY", Recon_Date);
                                    strIInputFileName = File_Name;
                                    strOutPutFileName = Formatted_File_Name;
                                }
                                else
                                {
                                    Recon_Date = dtRecondate.ToString("ddMMMyyyy");
                                    File_Name = File_Name.Replace("DDMMMYYYY", Recon_Date);
                                    strIInputFileName = File_Name;
                                    strOutPutFileName = File_Name;
                                }
                            }
                            if (File_Name.ToUpper().Contains("DD MM YY"))
                            {
                                Recon_Date = dtRecondate.ToString("dd MM yy");
                                File_Name = File_Name.Replace("DD MM YY", Recon_Date);
                                strIInputFileName = File_Name;
                                strOutPutFileName = Formatted_File_Name;
                            }
                            if (File_Name.ToUpper().Contains("DD MMM YY"))
                            {
                                if (Recon_name == "TW0000010121SC")
                                {
                                    Recon_Date = dtRecondate.ToString("dd MMM yy");
                                    File_Name = File_Name.Replace("DD MMM YY", Recon_Date);
                                    Recon_Date = dtRecondate.ToString("yyyyMMdd");
                                    Formatted_File_Name = Formatted_File_Name.Replace("YYYYMMDD", Recon_Date);
                                    strIInputFileName = File_Name;
                                    strOutPutFileName = Formatted_File_Name;
                                }
                                else
                                {
                                    Recon_Date = dtRecondate.ToString("dd MMM yy");
                                    File_Name = File_Name.Replace("DD MMM YY", Recon_Date);
                                    strIInputFileName = File_Name;
                                    strOutPutFileName = Formatted_File_Name;
                                }
                            }
                            else if (File_Name.ToUpper().Contains("DD-MMM"))
                            {
                                Recon_Date = dtRecondate.ToString("dd-MMM");
                                File_Name = File_Name.Replace("DD-MMM", Recon_Date);
                                strIInputFileName = File_Name;
                                strOutPutFileName = File_Name;
                            }
                            else if (File_Name.ToUpper().Contains("DD_MM_YYYY"))
                            {
                                Recon_Date = dtRecondate.ToString("dd_MM_yyyy");
                                File_Name = File_Name.Replace("DD_MM_YYYY", Recon_Date);
                                strIInputFileName = File_Name;
                                strOutPutFileName = File_Name;
                            }
                            else if (File_Name.ToUpper().Contains("DD-MM-YYYY"))
                            {
                                Recon_Date = dtRecondate.ToString("dd-MM-yyyy");
                                File_Name = File_Name.Replace("DD-MM-YYYY", Recon_Date);
                                strIInputFileName = File_Name;
                                strOutPutFileName = File_Name;
                            }
                            else if (File_Name.ToUpper().Contains("DD-MM-YYYY"))
                            {
                                Recon_Date = dtRecondate.ToString("dd-MM-yyyy").ToUpper();
                                File_Name = File_Name.Replace("DD-MM-YYYY", Recon_Date) + "." + File_Ext;
                                strIInputFileName = File_Name;
                                strOutPutFileName = File_Name;
                            }
                            else if (File_Name.ToUpper().Contains("DD-MM"))
                            {
                                Recon_Date = dtRecondate.ToString("dd-MM");
                                File_Name = File_Name.Replace("DD-MM", Recon_Date);
                                strIInputFileName = File_Name;
                                strOutPutFileName = File_Name;
                            }
                            else if (File_Name.ToUpper().Contains("MMM.YYYY"))
                            {
                                Recon_Date = dtRecondate.ToString("MMM.yyyy");
                                File_Name = File_Name.Replace("MMM.YYYY", Recon_Date);
                                Formatted_File_Name = Formatted_File_Name.Replace("MMM.YYYY", Recon_Date);
                                strIInputFileName = File_Name;
                                strOutPutFileName = Formatted_File_Name;
                            }
                            else if (File_Name.ToUpper().Contains("DDMMYYYY"))
                            {
                                if (Recon_name == "Cash Bal Upload Process Tally Sheet Fill, Ebbs Bal")
                                {
                                    Recon_Date = dtRecondate.ToString("ddMMyyyy");
                                    File_Name = File_Name.Replace("DDMMYYYY", Recon_Date) + "." + File_Ext;
                                    Formatted_File_Name = Formatted_File_Name.Replace("DDMMYYYY", Recon_Date);
                                    strIInputFileName = File_Name;
                                    strOutPutFileName = Formatted_File_Name;
                                }
                                else if (Recon_name == "CIS-CUSTODYpositiondaily-G4sloominsBrinkers")
                                {
                                    if (File_Name.Contains("LOT"))
                                    {
                                        Recon_Date = dtRecondate.ToString("ddMMyyyy");
                                        File_Name = obj.GetSpecificFileName_CIS(Directory + "Input\\Emails\\", Recon_Date) + "." + File_Ext;
                                        Formatted_File_Name = Formatted_File_Name.Replace("DDMMYY", Recon_Date);
                                        strIInputFileName = File_Name;
                                        strOutPutFileName = Formatted_File_Name;
                                    }
                                    else
                                    {
                                        Recon_Date = dtRecondate.ToString("ddMMyyyy");
                                        File_Name = File_Name.Replace("DDMMYYYY", Recon_Date) + "." + File_Ext;
                                        Formatted_File_Name = Formatted_File_Name.Replace("DDMMYY", Recon_Date);
                                        strIInputFileName = File_Name;
                                        strOutPutFileName = Formatted_File_Name;
                                    }
                                }
                                else if (Recon_name == "Outward Clearing Recon Report")
                                {

                                    if (File_Name.Contains("OCC_eBBS"))
                                    {
                                        Recon_Date = dtRecondate.ToString("ddMMyyyy").ToUpper();
                                        File_Name = obj.OutwardClearing(Directory + "Input\\PDF_Conversion\\", Recon_Date, "OCC_eBBS");
                                        strIInputFileName = File_Name;
                                    }
                                    else if (File_Name.Contains("OCC_Decisioning"))
                                    {
                                        Recon_Date = dtRecondate.ToString("ddMMyyyy").ToUpper();
                                        File_Name = obj.OutwardClearing(Directory + "Input\\PDF_Conversion\\", Recon_Date, "OCC_Decisioning");
                                        strIInputFileName = File_Name;
                                    }
                                }
                                else if (Recon_name == "Srilanka TLM Open Items-CA-LK-BRH-122131")
                                {

                                    Recon_Date = dtRecondate.ToString("ddMMyyyy");
                                    File_Name = File_Name.Replace("DDMMYYYY", Recon_Date);
                                    Formatted_File_Name = Formatted_File_Name.Replace("DDMMYYYY", Recon_Date);
                                    strIInputFileName = File_Name;
                                    strOutPutFileName = Formatted_File_Name;

                                }
                                else if (Recon_name == "Hong kong CMU" || Recon_name == "Malaysia - MCD Recon")
                                {

                                    Recon_Date = dtRecondate.ToString("ddMMyyyy");
                                    File_Name = File_Name.Replace("DDMMYYYY", Recon_Date);
                                    Recon_Date = dtRecondate.ToString("yyyyMMdd");
                                    Formatted_File_Name = Formatted_File_Name.Replace("YYYYMMDD", Recon_Date);
                                    strIInputFileName = File_Name;
                                    strOutPutFileName = Formatted_File_Name;

                                }
                                else
                                {
                                    Recon_Date = dtRecondate.ToString("ddMMyyyy");
                                    File_Name = File_Name.Replace("DDMMYYYY", Recon_Date);
                                    strIInputFileName = File_Name;
                                    strOutPutFileName = File_Name;
                                }
                            }
                            else if (File_Name.ToUpper().Contains("DDMMYY"))
                            {
                                if (Recon_name == "Acquirer Transactions - Manual Match  UnMatch Move")
                                {
                                    Recon_Date = dtRecondate.ToString("ddMMyy");
                                    string Recon_Date_FTP = dtRecondate.ToString("ddMMyyyy");
                                    File_Name = File_Name.Replace("DDMMYY", Recon_Date);
                                    Formatted_File_Name = Formatted_File_Name.Replace("DDMMYYYY", Recon_Date_FTP);
                                    strIInputFileName = File_Name;
                                    strOutPutFileName = Formatted_File_Name;
                                }
                                else
                                {
                                    Recon_Date = dtRecondate.ToString("ddMMyy");
                                    File_Name = File_Name.Replace("DDMMYY", Recon_Date);
                                    Formatted_File_Name = Formatted_File_Name.Replace("DDMMYY", Recon_Date);
                                    strIInputFileName = File_Name;
                                    strOutPutFileName = Formatted_File_Name;
                                }

                            }
                            else if (File_Name.ToUpper().Contains("YYYY-MM-DD"))
                            {
                                if (Recon_name == "Bony and Clearstream")
                                {
                                    Recon_Date = dtRecondate.ToString("yyyy-MM-dd");
                                    File_Name = obj.GetSpecificFileName_BonyClear(Directory + "Input\\Emails\\", Recon_Date);
                                }
                                else if (Recon_name == "SCB IRAQ Account Balance Report")
                                {
                                    Recon_Date = dtRecondate.ToString("yyyy-MM-dd");
                                    File_Name = File_Name.Replace("YYYY-MM-DD", Recon_Date);
                                    Recon_Date = dtRecondate.ToString("ddMMyyyy");
                                    Formatted_File_Name = Formatted_File_Name.Replace("DDMMYYYY", Recon_Date);
                                    strIInputFileName = File_Name.Trim() + ".xlsx";
                                    strOutPutFileName = Formatted_File_Name;
                                }

                                else
                                {
                                    Recon_Date = dtRecondate.ToString("yyyy-MM-dd");
                                    File_Name = File_Name.Replace("YYYY-MM-DD", Recon_Date);
                                    Recon_Date = dtRecondate.ToString("ddMMyyyy");
                                    Formatted_File_Name = Formatted_File_Name.Replace("DDMMYYYY", Recon_Date);
                                    strIInputFileName = File_Name;
                                    strOutPutFileName = Formatted_File_Name;
                                }
                            }
                            else if (File_Name.ToUpper().Contains("MM-DD-YYYY"))
                            {
                                Recon_Date = dtRecondate.ToString("MM-dd-yyyy");
                                File_Name = File_Name.Replace("MM-DD-YYYY", Recon_Date);
                                strIInputFileName = File_Name;
                                strOutPutFileName = File_Name;
                            }
                            else if (File_Name.ToUpper().Contains("MMDDYYYY"))
                            {
                                Recon_Date = dtRecondate.ToString("MMddyyyy").ToUpper();
                                File_Name = File_Name.Replace("MMDDYYYY", Recon_Date);
                                strIInputFileName = File_Name;
                            }
                            else if (File_Name.ToUpper().Contains("YYYY-MM"))
                            {
                                if (Recon_name == "SG0000094921")
                                {
                                    File_Name = obj.Get_MonthlyFileName(Directory + "Input\\Emails\\", "AI-MAS Shares held Book");
                                }
                                else
                                {
                                    Recon_Date = dtRecondate.ToString("yyyy-MM").ToUpper();
                                    File_Name = File_Name.Replace("YYYY-MM", Recon_Date).Trim();
                                    Recon_Date = dtRecondate.ToString("ddMMyyyy").ToUpper();
                                    Formatted_File_Name = Formatted_File_Name.Replace("DDMMYYYY", Recon_Date).Trim();
                                    strIInputFileName = File_Name.Trim();
                                    strOutPutFileName = Formatted_File_Name;
                                }
                            }
                            else if (File_Name.ToUpper().Contains("DD_MMM"))
                            {
                                Recon_Date = dtRecondate.ToString("dd_MMM");
                                File_Name = File_Name.Replace("DD_MMM", Recon_Date) + "." + File_Ext;
                            }
                            else if (File_Name.ToUpper().Contains("DD.MM.YYYY"))
                            {
                                Recon_Date = dtRecondate.ToString("dd.MM.yyyy");
                                File_Name = File_Name.Replace("DD.MM.YYYY", Recon_Date);
                            }
                            ///Formatted FileName


                            if (Formatted_File_Name.ToUpper().Contains("DD.MM.YYYY"))
                            {
                                string ext = "";
                                ext = Formatted_File_Name.Substring(Formatted_File_Name.LastIndexOf("."));
                                Formatted_File_Name = Formatted_File_Name.Replace(ext, "");
                                Formatted_File_Name = Formatted_File_Name.Remove(Formatted_File_Name.Length - 10);
                                Foramtted_Recon_Date = dtRecondate.ToString("dd.MM.yyyy");
                                Formatted_File_Name = Formatted_File_Name + Foramtted_Recon_Date + ext;
                            }
                            else if (Formatted_File_Name.ToUpper().Contains("YYYYMMDD"))
                            {
                                if (Recon_name == "Bony and Clearstream" || Recon_name == "VIETNAM VND OPEN ITEMS (CITAD)")
                                {
                                    if (Formatted_File_Name.Contains("PSGL_CUS_"))
                                    {
                                        string ext = "";
                                        ext = Formatted_File_Name.Substring(Formatted_File_Name.LastIndexOf("."));
                                        Foramtted_Recon_Date = dtRecondate.ToString("yyyyMMdd");
                                        Formatted_File_Name = Formatted_File_Name.Substring(0, 9) + Foramtted_Recon_Date + Formatted_File_Name.Substring(Formatted_File_Name.Length - 15, 15);
                                    }
                                    else if (Formatted_File_Name.Contains("LOCALBANK_STMT_TB_VN_SBV_"))
                                    {
                                        string ext = "";
                                        File_Name = File_Name.Replace("YYYYMMDD", Recon_Date);
                                        ext = Formatted_File_Name.Substring(Formatted_File_Name.LastIndexOf("."));
                                        Formatted_File_Name = Formatted_File_Name.Replace(ext, "");
                                        Formatted_File_Name = Formatted_File_Name.Remove(Formatted_File_Name.Length - 8);
                                        Foramtted_Recon_Date = dtRecondate.ToString("yyyyMMdd");
                                        Formatted_File_Name = Formatted_File_Name + Foramtted_Recon_Date + ext;
                                    }
                                    else
                                    {
                                        string ext = "";
                                        ext = Formatted_File_Name.Substring(Formatted_File_Name.LastIndexOf("."));
                                        Formatted_File_Name = Formatted_File_Name.Replace(ext, "");
                                        Formatted_File_Name = Formatted_File_Name.Remove(Formatted_File_Name.Length - 8);
                                        Foramtted_Recon_Date = dtRecondate.ToString("yyyyMMdd");
                                        Formatted_File_Name = Formatted_File_Name + Foramtted_Recon_Date + ext;
                                    }

                                }
                                else if (Recon_name == "FED Reserve MOC")
                                {
                                    if (Formatted_File_Name.Contains("PSGL_CUS_"))
                                    {
                                        string ext = "";
                                        ext = Formatted_File_Name.Substring(Formatted_File_Name.LastIndexOf("."));
                                        Foramtted_Recon_Date = dtRecondate.ToString("yyyyMMdd");
                                        Formatted_File_Name = Formatted_File_Name.Substring(0, 9) + Foramtted_Recon_Date + Formatted_File_Name.Substring(Formatted_File_Name.Length - 16, 15);
                                    }
                                }
                                else if (Recon_name == "SCBSB1857")
                                {
                                    if (Formatted_File_Name.Contains("PSGL_CUS_"))
                                    {
                                        string ext = "";
                                        ext = Formatted_File_Name.Substring(Formatted_File_Name.LastIndexOf("."));
                                        Recon_Date = dtRecondate.ToString("yyyyMMdd");
                                        Foramtted_Recon_Date = dtRecondate.ToString("yyyyMMdd");
                                        File_Name = File_Name.Replace("YYYYMMDD", Foramtted_Recon_Date);
                                        Formatted_File_Name = Formatted_File_Name.Substring(0, 9) + Foramtted_Recon_Date + Formatted_File_Name.Substring(Formatted_File_Name.Length - 15, 15);
                                    }

                                }
                                else if (Recon_name == "Bony and Clearstream2")
                                {
                                    if (Formatted_File_Name.Contains("PSGL_CUS_"))
                                    {
                                        string ext = "";
                                        ext = Formatted_File_Name.Substring(Formatted_File_Name.LastIndexOf("."));
                                        Recon_Date = dtRecondate.ToString("yyyyMMdd");
                                        Foramtted_Recon_Date = dtRecondate.ToString("yyyyMMdd");
                                        File_Name = obj.BonyClearalloc(StrDirectory + "Input\\Emails") + ".pdduz";
                                        Formatted_File_Name = Formatted_File_Name.Replace("YYYYMMDD", Foramtted_Recon_Date);
                                    }

                                }
                                else if (Recon_name == "Bony and Clearstream3")
                                {
                                    if (Formatted_File_Name.Contains("PSGL_CUS_"))
                                    {
                                        string ext = "";
                                        ext = Formatted_File_Name.Substring(Formatted_File_Name.LastIndexOf("."));
                                        Recon_Date = dtRecondate.ToString("yyyyMMdd");
                                        Foramtted_Recon_Date = dtRecondate.ToString("yyyyMMdd");
                                        File_Name = File_Name.Replace("YYYYMMDD", Foramtted_Recon_Date);
                                        Formatted_File_Name = Formatted_File_Name.Replace("YYYYMMDD", Foramtted_Recon_Date);
                                    }

                                }
                                else
                                {
                                    string ext = "";
                                    ext = Formatted_File_Name.Substring(Formatted_File_Name.LastIndexOf("."));
                                    Formatted_File_Name = Formatted_File_Name.Replace(ext, "");
                                    Formatted_File_Name = Formatted_File_Name.Remove(Formatted_File_Name.Length - 8);
                                    Foramtted_Recon_Date = dtRecondate.ToString("yyyyMMdd");
                                    Formatted_File_Name = Formatted_File_Name + Foramtted_Recon_Date + ext;
                                }
                            }

                            // ragavendran 07-09-2017
                            else if (Formatted_File_Name.ToUpper().Contains("DDMMYYYY"))
                            {
                                string ext = "";
                                ext = Formatted_File_Name.Substring(Formatted_File_Name.LastIndexOf("."));
                                Formatted_File_Name = Formatted_File_Name.Replace(ext, "");
                                Formatted_File_Name = Formatted_File_Name.Remove(Formatted_File_Name.Length - 8);
                                Foramtted_Recon_Date = dtRecondate.ToString("ddMMyyyy");
                                //bala	added for  India Clearing In/out Recon
                                if (Recon_name != "India - Phantom Nostro")
                                {
                                    Recon_Date = dtRecondate.ToString("ddMMyyyy");
                                }
                                //bala
                                Formatted_File_Name = Formatted_File_Name + Foramtted_Recon_Date + ext;


                            }
                            else if (Formatted_File_Name.ToUpper().Contains("MMDDYYYY"))
                            {
                                if (Recon_name == "Srilanka TLM Open Items-CA-LK-BRH-170254-LKR-ARPICO")
                                {
                                    Recon_Date = dtRecondate.ToString("yyyyMMdd");
                                    File_Name = obj.GetSpecificFileName_APRICO(sDirectory + "Input\\Emails\\", Recon_Date) + "." + File_Ext;
                                    Recon_Date = dtRecondate.ToString("MMddyyyy");
                                    Formatted_File_Name = Formatted_File_Name.Replace("MMDDYYYY", Recon_Date);
                                    strIInputFileName = File_Name;
                                    strOutPutFileName = Formatted_File_Name;
                                }
                            }
                            // ragavendran 07-09-2017

                            if (Source_App.ToUpper() == "S2BX")
                            {
                                if (!string.IsNullOrEmpty(File_Ext))
                                    SourcePath = sDirectory + "Input\\s2bx\\" + "\\" + File_Name + "." + File_Ext;
                                else
                                    SourcePath = sDirectory + "Input\\s2bx\\" + "\\" + File_Name;
                            }
                            else if (Source_App == "PDF_Conversion")
                            {
                                if (!string.IsNullOrEmpty(File_Ext))
                                    SourcePath = StrDirectory + "Input\\PDF_Conversion\\" + "\\" + File_Name + "." + File_Ext;
                                else
                                    SourcePath = StrDirectory + "Input\\PDF_Conversion\\";
                            }
                            else if (Source_App != "Email")
                            {
                                if (!string.IsNullOrEmpty(File_Ext))
                                    SourcePath = sDirectory + "Input\\" + Source_App + "_" + Country + "\\" + "\\" + File_Name + "." + File_Ext;
                                else
                                    SourcePath = sDirectory + "Input\\" + Source_App + "_" + Country + "\\" + "\\" + File_Name;
                            }
                            else
                            {
                                if (!string.IsNullOrEmpty(File_Ext))
                                    SourcePath = sDirectory + "Input\\Emails\\" + File_Name + "." + File_Ext;
                                else
                                    SourcePath = sDirectory + "Input\\Emails\\" + "\\" + File_Name;
                            }

                            Desti_Path = sDirectory + "Files_For_Formatting_Or_Non_Formatting\\" + Recon_name + "\\Formatting\\";
                            Output_Path = sDirectory + "Output\\" + Recon_name + "\\";

                            if (Recon_name == "VN Stock Reconciliation Report")
                            {
                                if (File_Name.Contains("tradingRecon"))
                                {
                                    obj.TradingRecon(SourcePath, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, File_Ext);
                                    ProcessedFileCount++;
                                }
                                else if (File_Name.Contains("PH30") || File_Name.Contains("Consolidate Account List for Custody") || File_Name.Contains("DE83"))
                                {
                                    ProcessedFileCount++;
                                    if (Flag_Recon == false)
                                    {
                                        Flag_Recon = true;
                                        obj.VNStockReport(SourcePath, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, File_Ext);
                                    }
                                }

                            }
                            else if (Recon_name == "Singapore - Prepaid")
                            {
                                if (File_Name.Contains("RPBK014_"))
                                {
                                    obj.RPBK014_SG(SourcePath, Output_Path, (Output_Path.Trim() + Formatted_File_Name));
                                    ProcessedFileCount++;
                                }
                                else if (File_Name.Contains("RPCH014_"))
                                {
                                    obj.RPCH014_SG(SourcePath, Output_Path, (Output_Path + Formatted_File_Name));
                                    ProcessedFileCount++;
                                }

                            }
                            else if (Recon_name == "SCB IRAQ Account Balance Report")
                            {
                                if (File_Name.Contains("(IQD)"))
                                {
                                    int count_check = 0;
                                    obj.SCB_IRAQ_Account_NEW(conString, SourcePath, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, File_Name, File_Ext, StrDirectory, iraq_bal, out iraq_bal, out count_check);
                                    if (count_check == 2)
                                    {
                                        ProcessedFileCount = ProcessedFileCount + iraq_bal;
                                    }
                                    //Commented by Harita-03-05-18
                                    //obj.SCB_IRAQ_Account(SourcePath, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, File_Name, File_Ext, StrDirectory, iraq_bal, out iraq_bal);
                                    //ProcessedFileCount = ProcessedFileCount + iraq_bal;
                                }
                            }
                            else if (Recon_name == "India - CMPC Suspense")
                            {
                                obj.Formatting_India_CMPC_Suspense(SourcePath, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, File_Name, File_Ext, StrDirectory);
                                ProcessedFileCount++;
                            }
                            else if (Recon_name == "Srilanka Clearing")
                            {
                                obj.Srilanka_Clearing(SourcePath, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, File_Name, File_Ext, StrDirectory);
                                ProcessedFileCount++;
                            }
                            else if (Recon_name == "Bony and Clearstream")
                            {
                                if (File_Name.Contains("Client_92078"))
                                {
                                    obj.BonyandClearstream_Client_92078(SourcePath, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, File_Name, File_Ext);
                                    ProcessedFileCount++;
                                }
                                else if (File_Name.Contains("Bony and Clearstream"))
                                {
                                    obj.BonyandClearstream_FailTrade(SourcePath, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, File_Name, File_Ext, conString);
                                    ProcessedFileCount++;
                                }
                                else if (File_Name.Contains("AGREEMENT SUMMARY REPORT"))
                                {
                                    obj.BonyandClearstream_AGREEMENTSUMMARY(SourcePath, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, File_Name, File_Ext);
                                    ProcessedFileCount++;
                                }
                            }

                            else if (Recon_name == "kenya receivables")
                            {
                                if (File_Name.Contains("PSGL_011_170204_YTD_"))
                                {
                                    obj.KenyaReceivables(SourcePath, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, File_Name, File_Ext, StrDirectory);
                                    ProcessedFileCount = ProcessedFileCount + 5;
                                }
                            }
                            else if (Recon_name == "Visa Base II – Trial Balance Preparation – TOTAL")
                            {
                                obj.Visa_Base2(SourcePath, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, File_Name, File_Ext);
                                ProcessedFileCount++;
                            }
                            else if (Recon_name == "Malaysia - Inward   Outward clearing")
                            {
                                obj.Malaysia_IWOW(SourcePath, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, File_Name, File_Ext);
                                ProcessedFileCount = ProcessedFileCount + 3;
                            }
                            else if (Recon_name == "HongKong Failed Trade Online")
                            {
                                obj.HK_FTO(SourcePath, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, File_Name, File_Ext);
                                ProcessedFileCount++;
                            }
                            else if (Recon_name == "Malaysia-RPR")
                            {
                                obj.Malaysia_RPR(SourcePath, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, File_Name, File_Ext);
                                ProcessedFileCount++;
                            }
                            else if (Recon_name == "Srilanka TLM Open Items-CA-LK-BRH-122131")
                            {
                                string Output_Dir = Directory + "Input\\Crystal Report\\India\\";
                                obj.RBIRTGS(SourcePath, Desti_Path + Recon_name + "\\" + Formatted_File_Name, Formatted_File_Name, Output_Path);
                                ProcessedFileCount++;
                            }
                            else if (Recon_name == "SCB Cameroon1" || Recon_name == "SCB Cameroon2")
                            {
                                string Output_Dir = Directory + "Input\\PDF_Conversion\\";
                                obj.RBIRTGS(SourcePath, Desti_Path + Recon_name + "\\" + Formatted_File_Name, Formatted_File_Name, Output_Path);
                                ProcessedFileCount++;
                            }


                            else if (Recon_name == "BTS VS Trade Blazer")
                            {
                                obj.BTSVSTRADE(SourcePath, Output_Path, Formatted_File_Name);
                                ProcessedFileCount++;
                            }
                            else if (Recon_name == "Nepal Account Balance (Instrument)")
                            {
                                if (Formatted_File_Name.Contains("SCB_NEPAL_CLG_ECC_OUTWARD"))
                                {
                                    obj.Nepal_Account_Balance_OW(SourcePath, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, File_Name, File_Ext);
                                }
                                else if (Formatted_File_Name.Contains("SCB_NEPAL_CLG_EBS_INWARDBATCHENTRY"))
                                {
                                    obj.Nepal_Account_Balance_ORG(SourcePath, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, File_Name, File_Ext);
                                }
                                else if (Formatted_File_Name.Contains("SCB_NEPAL_CLG_EBS_INWARDOUTWARD"))
                                {
                                    obj.Nepal_Account_Balance_BATCH(SourcePath, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, File_Name, File_Ext);
                                }
                                else if (Formatted_File_Name.Contains("SCB_NEPAL_CLG_ECC_INWARD"))
                                {
                                    obj.Nepal_Account_Balance_IW(SourcePath, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, File_Name, File_Ext);
                                }
                                ProcessedFileCount++;
                            }
                            else if (Recon_name == "BAHRAIN LOANS RECON")
                            {
                                string Output_Dir = Directory + "Input\\Crystal Report\\" + Country + "\\";
                                obj.Beharin_Loan_Recon(SourcePath, Output_Dir, Output_Path, (Output_Path + Formatted_File_Name), Recon_name, Recon_Date, Formatted_File_Name, Formatted_File_Name, conString);
                                ProcessedFileCount++;
                            }
                            else if (Recon_name == "Thailand Statements")
                            {
                                if (ProcessedFileCount == 0)
                                {
                                    obj.Thailand_settlement(SourcePath, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, File_Name, File_Ext);
                                    ProcessedFileCount = ProcessedFileCount + 4;
                                }
                            }

                            else if (Recon_name == "MXPB file")
                            {
                                obj.MXPB(SourcePath, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, File_Name, File_Ext);
                                ProcessedFileCount++;
                            }
                            else if (Recon_name == "Srilanka TLM Open Items-CA-LK-BRH-170254-LKR-SINGER")
                            {
                                if (Formatted_File_Name.Contains("PSGL_55792_BRK_LK"))
                                {
                                    //Commented By Harita--03-05-18
                                    //obj.SRILANKATLM_SINGER(SourcePath, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, File_Name, File_Ext, sDirectory);
                                    //ProcessedFileCount++;


                                    //NEW
                                    int check_count = 0;
                                    obj.SRILANKATLM_SINGER_NEW(conString, SourcePath, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, File_Name, File_Ext, sDirectory, out check_count);
                                    if (check_count > 0)
                                    {
                                        ProcessedFileCount++;
                                    }
                                }
                            }
                            else if (Recon_name == "Srilanka TLM Open Items-CA-LK-BRH-170254-LKR-ARPICO")
                            {
                                if (Formatted_File_Name.Contains("LK_ARPICO_"))
                                {
                                    obj.SRILANKATLM_ARPICO(SourcePath, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, File_Name, File_Ext, sDirectory);
                                    ProcessedFileCount++;
                                }
                            }
                            else if (Recon_name == "Singapore Failed Trade")
                            {
                                if (SourcePath.Contains("PSGL_SGP_FAIL_TRADE_BAL_150"))
                                {
                                    obj.Singapore_FailedTrade(SourcePath, Recon_Date, Output_Path + Formatted_File_Name, Recon_name, Output_Path, Formatted_File_Name, File_Name, File_Ext);
                                    ProcessedFileCount++;
                                }
                                else if (SourcePath.Contains("PSGL_SGP_FAIL_TRADE_BAL_287"))
                                {
                                    obj.Singapore_FailedTrade(SourcePath, Recon_Date, Output_Path + Formatted_File_Name, Recon_name, Output_Path, Formatted_File_Name, File_Name, File_Ext);
                                    ProcessedFileCount++;
                                }
                            }
                            else if (Recon_name == "Srilanka TLM Open Items-CA-LK-BRH-289109-LKR - Debit card account")
                            {
                                if (Formatted_File_Name.Contains("LK_VISADEBITCARDEBBS_"))
                                {
                                    obj.SRILANKATLM_LKRDEBITCARD(SourcePath, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, File_Name, File_Ext, sDirectory);
                                    ProcessedFileCount++;
                                }
                            }
                            else if (Recon_name == "Srilanka TLM Open Items-CA-LK-BRH-CA-LK-BRH-287910-LKR-CHQ CLEARING")
                            {
                                if (Formatted_File_Name.Contains("LK_CHEQUE_CLEARING_"))
                                {                                    
                                    obj.SRILANKATLM_CHEQUE_CLEARING(SourcePath, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, File_Name, File_Ext, sDirectory);
                                    ProcessedFileCount++;
                                    //Commented by Aneesh--04-07-18
                                    //int check_count = 0;
                                    //obj.SRILANKATLM_CHEQUE_CLEARING_NEW(conString, SourcePath, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, File_Name, File_Ext, sDirectory, out check_count);
                                    //if (check_count > 0)
                                    //{
                                    //    ProcessedFileCount++;
                                    //}
                                }
                            }
                            else if (Recon_name == "Srilanka TLM Open Items-CA-LK-BRH-122131-LKR-CASHDROP")
                            {
                                if (Formatted_File_Name.Contains("PSGL_95092_BRK_"))
                                {
                                    obj.SRILANKATLM_CASHDROP(SourcePath, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, File_Name, File_Ext, sDirectory);
                                    ProcessedFileCount = ProcessedFileCount + 14;
                                }
                            }
                            else if (Recon_name == "Srilanka TLM Open Items-CA-LK-BRH-170254-LKR-COMM BANK (PD)")
                            {
                                if (Formatted_File_Name.Contains("PSGL_170254_BRK_LK_"))
                                {
                                    //Commented by Harita--03-05-18
                                    //obj.SRILANKATLM_COMMBANK(SourcePath, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, File_Name, File_Ext, sDirectory);
                                    //ProcessedFileCount++;

                                    //New
                                    int check_count = 0;
                                    obj.SRILANKATLM_COMMBANK_NEW(conString, SourcePath, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, File_Name, File_Ext, sDirectory, out check_count);
                                    if (check_count > 0)
                                    {
                                        ProcessedFileCount++;
                                    }
                                }
                            }
                            else if (Recon_name == "Srilanka TLM Open Items-CA-LK-BRH-CA-LK-BRH-170254-LKR-NTB (PD)")
                            {
                                if (Formatted_File_Name.Contains("PSGL_45792_BRK_"))
                                {
                                    //Commented by Harita--03-05-18
                                    //obj.SRILANKATLM_NTB(SourcePath, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, File_Name, File_Ext, sDirectory);
                                    //ProcessedFileCount++;

                                    //new
                                    int check_count = 0;
                                    obj.SRILANKATLM_NTB_NEW(conString, SourcePath, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, File_Name, File_Ext, sDirectory, out check_count);
                                    if (check_count > 0)
                                    {
                                        ProcessedFileCount++;
                                    }
                                }
                            }
                            else if (Recon_name == "Srilanka TLM Open Items-CA-LK-BRH-170254-LKR-KEELYS (W-M)")
                            {
                                if (Formatted_File_Name.Contains("PSGL_170255_BRK_"))
                                {
                                    obj.SRILANKATLM_KEELS(SourcePath, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, File_Name, File_Ext, sDirectory);
                                    ProcessedFileCount++;
                                }
                            }
                            else if (Recon_name == "TW0000010121SC")
                            {
                                obj.Taiwan_Recon(SourcePath, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, File_Name, File_Ext);
                                ProcessedFileCount++;
                            }

                            else if (Recon_name == "Outward Clearing Recon Report")
                            {
                                if (ProcessedFileCount == 0)
                                {
                                    obj.Outward_clearing_old(SourcePath, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, File_Name, File_Ext);
                                    ProcessedFileCount = ProcessedFileCount + 2;
                                }
                            }

                            //Need to change local paths after db is updated
                            else if (Recon_name == "Indonesia Failed Trade Online")
                            {
                                obj.Indonesia_FailedTrade_Online(SourcePath, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, File_Name, File_Ext);
                                ProcessedFileCount++;
                            }

                            //Need to change local paths after db is updated
                            else if (Recon_name == "Hong kong CMU")
                            {
                                obj.HongKong_CMU(SourcePath, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, (Output_Path + Formatted_File_Name));
                                ProcessedFileCount++;
                            }
                            //Need to change local paths after db is updated
                            else if (Recon_name == "India Clearing")
                            {
                                obj.India_Clearing_Recon(SourcePath, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, File_Name, File_Ext, StrDirectory);
                                ProcessedFileCount = ProcessedFileCount + 72;
                            }
                            else if (Recon_name == "India Clearing Inward")
                            {
                                obj.India_Clearing_Inward(SourcePath, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, File_Name, File_Ext, StrDirectory);
                                ProcessedFileCount = ProcessedFileCount + 72;
                            }
                            else if (Recon_name == "India Clearing Outward")
                            {
                                obj.India_Clearing_Outward(SourcePath, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, File_Name, File_Ext, StrDirectory);
                                ProcessedFileCount = ProcessedFileCount + 72;
                            }
                            //Need to change local paths after db is updated

                            else if (Recon_name == "Indonesia - Blotter USD")
                            {
                                obj.Indonesia_Blotter(SourcePath, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, File_Name, File_Ext);
                                ProcessedFileCount = ProcessedFileCount++;
                            }
                            else if (Recon_name == "Singapore Trade SNS")
                            {
                                if (File_Name.Contains("SCB_GL_YTD_ACCT_PROD_DEPT_OPER_287"))
                                {
                                    obj.SingaporeTradeSNS(SourcePath, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, File_Name, File_Ext);
                                    ProcessedFileCount = ProcessedFileCount + 5;
                                }

                                //ProcessedFileCount++;
                            }

                            else if (Recon_name == "CIS-CUSTODYpositiondaily-G4sloominsBrinkers")
                            {
                                if (File_Name.Contains("LOT"))
                                {
                                    obj.CIS_LOT(SourcePath, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, File_Name, File_Ext, out CIS_LOT);
                                    ProcessedFileCount++;
                                }
                                else if (File_Name.Contains("SCB"))
                                {
                                    obj.CIS_SCB(SourcePath, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, File_Name, File_Ext, out CIS_SCB);
                                    ProcessedFileCount++;
                                }
                                else if (File_Name.Contains("Consolidated Standard Chartered"))
                                {
                                    obj.CIS_CONSOLIDATED(SourcePath, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, File_Name, File_Ext, out CIS_Consol);
                                    obj.CIS_FTPFile(SourcePath, Recon_Date, Desti_Path, Recon_name, Output_Path, Formatted_File_Name, File_Name, File_Ext, CIS_LOT, CIS_SCB, CIS_Consol);
                                    ProcessedFileCount++;
                                }
                            }
                            else if (Recon_name == "India - Phantom Nostro")
                            {
                                string Output_Dir = sDirectory + "Input\\Crystal Report\\India\\";
                                //obj.phantomnostro(SourcePath + File_Name, Desti_Path + Recon_name + "\\" + Formatted_File_Name);
                                obj.IndiaPhantomNostro(SourcePath, Recon_Date, Output_Dir, Recon_name, Output_Path, Formatted_File_Name);
                                ProcessedFileCount++;
                            }

                            else if (Recon_name == "SCBSB1857")
                            {
                                obj.SCBSB(SourcePath, Recon_Date, Recon_name, Output_Path, (Output_Path + Formatted_File_Name), Formatted_File_Name, File_Name);
                                ProcessedFileCount++;
                            }
                            else if (Recon_name == "FED Reserve MOC")
                            {
                                string Output_Dir = sDirectory + "Input\\Crystal Report\\United states\\";
                                obj.FEDReserve(SourcePath, Recon_Date, Output_Dir, Recon_name, Output_Path, (Output_Path + Formatted_File_Name), Formatted_File_Name, File_Name);
                                ProcessedFileCount++;
                            }
                            else if (Recon_name == "Cash Bal Upload Process Tally Sheet Fill, Ebbs Bal")
                            {
                                string Output_Dir = sDirectory + "Input\\Crystal Report\\United states\\";
                                obj.cashbal(SourcePath, Recon_Date, Output_Dir, Recon_name, Output_Path, (Output_Path + Formatted_File_Name), Formatted_File_Name, File_Name);
                                ProcessedFileCount++;
                            }
                            else if (Recon_name == "Malaysia FMO SNS & EBBS")
                            {
                                obj.Malaysia_FMO(SourcePath, Recon_Date, Recon_name, Output_Path, (Output_Path + Formatted_File_Name), Formatted_File_Name, File_Name);
                                ProcessedFileCount++;
                            }
                            else if (Recon_name == "India Trade RPR")
                            {
                                if (SourcePath.Contains("FX_DEALS_IND1_"))
                                {
                                    obj.India_RPR(SourcePath, Recon_Date, Recon_name, Output_Path, (Output_Path + Formatted_File_Name), Formatted_File_Name, File_Name);
                                    ProcessedFileCount =ProcessedFileCount + 3;
                                }
                            }
                            else if (Recon_name == "VIETNAM VND OPEN ITEMS (CITAD)")
                            {
                                //Commented By Aneesh 03-05-18
                                string Output_Dir = sDirectory + "Input\\Crystal Report\\VIETNAM\\";
                                //obj.CITAD(SourcePath, Recon_Date, Output_Dir, Output_Path, (Output_Path + Formatted_File_Name));
                                bool count_check = false;
                                obj.CITAD_UPD(conString, SourcePath, Recon_Date, Output_Dir, Output_Path, (Output_Path + Formatted_File_Name), Recon_name, out count_check);
                                if (count_check == true)
                                {
                                    ProcessedFileCount++;
                                }
                            }
                            else if (Recon_name == "Nepal SOM Nostro")
                            {
                                string Output_Dir = sDirectory + "Input\\Crystal Report\\Nepal\\";
                                string Output_Pat = Output_Path + Formatted_File_Name;
                                string cccou = "NepalSOM";
                                DataTable dt = obj.NepalSOM(conString, SourcePath, Recon_Date, Output_Dir, Output_Path, (Output_Path + Formatted_File_Name), ProcessedFileCount, Recon_name);
                                ProcessedFileCount++;
                                dt_Final_nepal.Merge(dt);
                                if (ProcessedFileCount == 15)
                                {
                                    obj.ExportToExcel_IndiaRBI(dt_Final_nepal, Output_Pat, cccou);
                                }
                            }
                            else if (Recon_name == "Hong Kong - BOCI")
                            {
                                obj.HongKong_BOCI_Formatting(conString, StrDirectory, Recon_name, File_Name, File_Ext, Formatted_File_Name, Recon_Date);
                                ProcessedFileCount++;
                            }

                            else if (Recon_name == "OWN Recon")
                            {
                                if (Formatted_File_Name.Contains("OWNCUSTODY1_FTP"))
                                {
                                    obj.OWNRecon(SourcePath, Desti_Path + Formatted_File_Name, sDirectory + "Input\\", Output_Path, Formatted_File_Name, Recon_Date, Recon_name);
                                    ProcessedFileCount++;
                                }
                                else if (Formatted_File_Name.Contains("OWNCUSTODY2_FTP"))
                                {
                                    obj.OWNRecon_File2(SourcePath, Desti_Path + Formatted_File_Name, sDirectory + "Input\\", Output_Path, Formatted_File_Name, Recon_Date, Recon_name);
                                    ProcessedFileCount++;
                                }
                            }
                            else if (Recon_name == "India Sundry and Suspense, EBBS and IDBI report" || Recon_name == "CLS-MLS Recon")
                            {
                                obj.phantomnostro(SourcePath, (Output_Path.Trim() + Formatted_File_Name));
                                ProcessedFileCount++;
                            }
                            else if (Recon_name == "JAPAN - Account Balance report Nostro")
                            {
                                Recon_Date = dtRecondate.Date.ToString("ddMMMyyyy");///Sandhiya 
                                obj.JAPANACCBal(SourcePath, (Output_Path.Trim() + Formatted_File_Name), Recon_Date, intrimpath, Formatted_File_Name, Recon_name);
                                ProcessedFileCount++;
                            }
                            else if (Recon_name == "MXG - sabre")
                            {

                                if (Formatted_File_Name.Contains("MXG-SABRE") && !Formatted_File_Name.Contains("MXG-SABRE as of 1-") && !Formatted_File_Name.Contains("MXG-SABRE as of 2-") && !Formatted_File_Name.Contains("MXG-SABRE as of 3-"))
                                {
                                    obj.MXGsabre(SourcePath, Output_Path, (Output_Path.Trim() + Formatted_File_Name), out dt_MX1);
                                    obj.MXGsabre_Consolidated((Output_Path.Trim() + Formatted_File_Name.Replace("3-", "")), dt_MX1, dt_MX2, dt_MX3, dt_MX4);
                                    ProcessedFileCount++;
                                }
                                else if (Formatted_File_Name.Contains("MXG-SABRE as of 1-"))
                                {
                                    obj.MXGsabre1(SourcePath, Output_Path, (Output_Path.Trim() + Formatted_File_Name), out dt_MX2);
                                    ProcessedFileCount++;
                                }
                                else if (Formatted_File_Name.Contains("MXG-SABRE as of 2-"))
                                {
                                    obj.MXGsabre2(SourcePath, Output_Path, (Output_Path.Trim() + Formatted_File_Name), out dt_MX3);
                                    ProcessedFileCount++;
                                }
                                else if (Formatted_File_Name.Contains("MXG-SABRE as of 3-"))
                                {
                                    obj.MXGsabre3(SourcePath, Output_Path, (Output_Path.Trim() + Formatted_File_Name), out dt_MX4);
                                    ProcessedFileCount++;
                                }
                            }
                            else if (Recon_name == "Acquirer Transactions - Manual Match  UnMatch Move master")
                            {
                                obj.Acqurirer_Transaction_Master(SourcePath, (Output_Path.Trim() + Formatted_File_Name));
                                ProcessedFileCount++;
                            }
                            else if (Recon_name == "Acquirer Transactions - Manual Match  UnMatch Move")
                            {
                                obj.Acqurirer_Transaction_Move_DMS(SourcePath, (Output_Path.Trim() + Formatted_File_Name), Output_Path.Trim(), Formatted_File_Name, Recon_Date);
                                ProcessedFileCount++;
                            }
                        }
                        if (File_Count == ProcessedFileCount)
                        {
                            strquery = "update Arc_Recon_Master_Holiday_Date_Logic set Is_Recon_Completed = 1, Recon_Status = 'COMPLETED', AutomationEndTime='" + DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss") + "' where Recon_Id = " + Recon_Id + " and Recon_date='" + dtRecondate.ToString("MM/dd/yyyy") + "'";
                            insupdaval = das.ins_upd_fun(strquery, hat, "text");
                            Console.WriteLine("End Time -->" + DateTime.Now.ToShortTimeString() + " Recon: " + Recon_name + " --> Completed Successfully");
                        }
                        else
                        {
                            strquery = "update Arc_Recon_Master_Holiday_Date_Logic set Is_Recon_Completed = 0, Recon_Status = 'File Count Mismatch', AutomationEndTime='" + DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss") + "' where Recon_Id = " + Recon_Id + " and Recon_date='" + dtRecondate.ToString("MM/dd/yyyy") + "'";
                            insupdaval = das.ins_upd_fun(strquery, hat, "text");
                            Console.WriteLine("End Time -->" + DateTime.Now.ToShortTimeString() + " Recon: " + Recon_name + " -->Has Formatting Issue Please Check Once Again");
                        }
                        //SA1001
                        objReconLog.ReconID = Recon_Id.ToString();
                        objReconLog.LineNo = "NIL";
                        objReconLog.ErrorMessage = "NIL";
                        objReconLog.Flag = "End";
                        //objReconLog.StartTime = "NIL";
                        objReconLog.EndTime = DateTime.Now.ToShortTimeString();
                        objReconLog.ReconName = Recon_name;
                        objReconLog.UserID = Environment.UserName;
                        //objReconLog.DateTime = objReconLog.DateTime;
                        insertReconLog(objReconLog);
                        //EA1001
                    }

                }
            }
            catch (Exception ex)
            {
                int linenum = Convert.ToInt32(ex.StackTrace.Substring(ex.StackTrace.LastIndexOf(' ')));
                string exception = "Line No:" + linenum.ToString();
                Console.WriteLine("End Time -->" + DateTime.Now.ToShortTimeString() + " Recon: " + Recon_name + " -->Has Formatting Issue Please Check Once Again");
                Console.WriteLine("Exception -->>" + DateTime.Now.ToShortTimeString());
                //SA1001
                //objReconLog.ReconID = Recon_Id.ToString();
                objReconLog.LineNo = linenum.ToString();
                objReconLog.ErrorMessage = ex.ToString();
                objReconLog.Flag = "Error";
                //objReconLog.StartTime = "";
                //objReconLog.EndTime = "";
                //objReconLog.ReconName = Recon_name;
                objReconLog.UserID = Environment.UserName;
                objReconLog.DateTime = DateTime.Now.ToString();
                insertReconLog(objReconLog);
                //EA1001
                //aTimer.Start();
            }
        }



        public static void Bind_Recon_Holiday_Status()
        {
            try
            {
                DAccess das = new DAccess();
                Hashtable hat = new Hashtable();
                DataTable dtReconHoidayStatus = new DataTable();
                string fileLocation = @"C:\ARC\RPAOS 2133 - Holiday Logics\Recon_File_Holiday_Status.xlsx";
                string excelConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + fileLocation + ";Extended Properties=\"Excel 12.0 xml;HDR=Yes;IMEX=1\"";
                OleDbConnection connection = new OleDbConnection();
                connection.ConnectionString = excelConnectionString;
                string query = "SELECT * FROM [Sheet1$]";
                OleDbDataAdapter odatest = new OleDbDataAdapter(query, connection);
                odatest.Fill(dtReconHoidayStatus);

                string strquery = "select * from arc_scope_baseline";
                DataTable dtGetDetails = das.Select_Table(strquery, hat, "Text");

                for (int i = 0; i < dtReconHoidayStatus.Rows.Count; i++)
                {
                    string team = dtReconHoidayStatus.Rows[i]["Team"].ToString();
                    string couName = dtReconHoidayStatus.Rows[i]["Country_Name"].ToString();
                    string Recon = dtReconHoidayStatus.Rows[i]["Recon"].ToString();
                    string REportSouFileName = dtReconHoidayStatus.Rows[i]["Report_Source_File_Name"].ToString();
                    string FTPFILENAme = dtReconHoidayStatus.Rows[i]["FTP_File_Format_Name"].ToString();
                    string IsSat = dtReconHoidayStatus.Rows[i]["Sat"].ToString();
                    string IsSun = dtReconHoidayStatus.Rows[i]["Sun"].ToString();
                    string IsHoliday = dtReconHoidayStatus.Rows[i]["Holiday"].ToString();
                    string FileSat = dtReconHoidayStatus.Rows[i]["File_Available _Sat"].ToString();
                    string FileSun = dtReconHoidayStatus.Rows[i]["File_Available _Sun"].ToString();
                    string FileHoliday = dtReconHoidayStatus.Rows[i]["File_Available _Holiday"].ToString();
                    string LastTransaction = dtReconHoidayStatus.Rows[i]["Last_Transaction"].ToString();

                    if (IsSat == "Y")
                    {
                        IsSat = "1";
                    }
                    else
                    {
                        IsSat = "0";
                    }

                    if (FileSat == "Y")
                    {
                        FileSat = "1";
                    }
                    else
                    {
                        FileSat = "0";
                    }

                    if (IsSun == "Y")
                    {
                        IsSun = "1";
                    }
                    else
                    {
                        IsSun = "0";
                    }

                    if (FileSun == "Y")
                    {
                        FileSun = "1";
                    }
                    else
                    {
                        FileSun = "0";
                    }

                    if (IsHoliday == "Y")
                    {
                        IsHoliday = "1";
                    }
                    else
                    {
                        IsHoliday = "0";
                    }

                    if (FileHoliday == "Y")
                    {
                        FileHoliday = "1";
                    }
                    else
                    {
                        FileHoliday = "0";
                    }

                    string filerquery = "Country_name='" + couName + "' and recon='" + Recon + "' and Report_Source_File_Name='" + REportSouFileName + "' ";
                    if (FTPFILENAme != null)
                    {
                        if (FTPFILENAme.Trim().ToUpper() != "NULL")
                        {
                            filerquery = filerquery + " and FTP_File_Format_Name='" + FTPFILENAme + "'";
                        }
                    }

                    dtGetDetails.DefaultView.RowFilter = filerquery;
                    DataView dvReconDet = dtGetDetails.DefaultView;
                    if (dvReconDet.Count > 0)
                    {
                        string CountID = dvReconDet[0]["Country_ID"].ToString();
                        string ProduID = dvReconDet[0]["Product_Id"].ToString();
                        string reconId = dvReconDet[0]["Recon_Id"].ToString();

                        string strQuery = "if not exists(select * from ARC_Holiday_Recon_Run_Status where " + filerquery + " )";
                        strQuery = strQuery + " insert into ARC_Holiday_Recon_Run_Status(Country_id,Recon_id,Product_id,Country_name,Team,Recon,Report_Source_File_Name,FTP_File_Format_Name,is_sat,is_sun,is_holiday,is_File_Available_holiday,Is_File_Available_Sat,Is_File_Available_Sun,Last_Trasaction)";
                        strQuery = strQuery + " values('" + CountID + "','" + reconId + "','" + ProduID + "','" + couName + "','" + team + "','" + Recon + "','" + REportSouFileName + "','" + FTPFILENAme + "','" + IsSat + "','" + IsSun + "','" + IsHoliday + "','" + FileHoliday + "','" + FileSat + "','" + FileSun + "','" + LastTransaction + "')";
                        int insquery = das.ins_upd_fun(strQuery, hat, "Text");
                    }
                }
            }
            catch
            {
            }
        }

        public void MoveToHistory(string CountryName, string Team, string ReconName, string constring)
        {
            try
            {
                Hashtable hat = new Hashtable();
                DAccess das = new DAccess();
                int Scope_id = 0;
                string strGetMaxScoipeId = "select max(scope_id) from Arc_Scope_BaseLine_history";
                DataTable dtMaxScopeId = das.Select_Table(strGetMaxScoipeId, hat, "text");
                if (dtMaxScopeId.Rows.Count > 0)
                {
                    if (dtMaxScopeId.Rows[0][0] != null)
                    {
                        if (dtMaxScopeId.Rows[0][0].ToString() != "")
                        {
                            Scope_id = Convert.ToInt32(dtMaxScopeId.Rows[0][0].ToString());
                        }
                    }
                }
                string ftpval = "";
                string filerquery = " Country_Name='" + CountryName + "' and Recon='" + ReconName + "' and Team='" + Team + "' ";

                string strReconMasterHoliDateQuery = "select Recon_Id,Recon_name,Team,Country,Total_Files,Convert(nvarchar(15),Recon_Date,101) Recon_Date,Is_Recon_Completed,Recon_Status,Is_Active,convert(nvarchar(50),SLA_Time, 101) + ' ' + CONVERT(VARCHAR(8),SLA_Time, 108) SLA_Time,convert(nvarchar(50),Receipt_Time, 101) + ' ' + CONVERT(VARCHAR(8), Receipt_Time, 108) Receipt_Time,convert(nvarchar(50),AutomationStartTime, 101) + ' ' + CONVERT(VARCHAR(8),AutomationStartTime, 108) AutomationStartTime,convert(nvarchar(50),AutomationEndTime, 101) + ' ' + CONVERT(VARCHAR(8),AutomationEndTime, 108) AutomationEndTime,PSID  from Arc_Recon_Master_Holiday_Date_Logic where Country='" + CountryName + "' and Recon_Name='" + ReconName + "' and Team='" + Team + "' and Is_Recon_Completed=1";
                DataTable dtReconOld = das.Select_Table(strReconMasterHoliDateQuery, hat, "Text");


                string strGetQuery = "select a.In_Scope_For_ARC,a.Algorithms,a.Team,a.Country_Name,a.Site,a.Recon,a.SLA_Time,Manual_FTP,a.Report_Source_File_Name,a.FTP_File_Format_Name,a.Source_Application,Source_path,a.FTP_Destination_Path,a.Receipt_Time,a.File_Format,a.Format_Direct_Upload,a.Remarks,a.Frequency,a.Country_ID,b.IsProcessed,b.automationStatus,a.Product_Id,a.Recon_Id,a.Email_Subject,Convert(nvarchar(15),b.Recon_Date,101) Recon_Date,b.PSID,Convert(nvarchar(15),b.Processed_Date,101) Processed_Date,b.AutomationStartTime,b.AutomationEndTime,b.remarks,b.RHID from arc_scope_baseline a,ARC_Scope_Baseline_Logic b";
                strGetQuery = strGetQuery + " where a.Country_id=b.Country_id and a.product_id=b.product_id and a.Recon_Id=b.Recon_Id and a.Country_Name=b.Country_Name and a.Report_Source_File_Name=b.Report_Source_File_Name and isnull(a.FTP_File_Format_Name,'')=isnull(b.FTP_File_Format_Name,'') ";
                strGetQuery = strGetQuery + " and a.Country_Name='" + CountryName + "' and a.Recon='" + ReconName + "' and a.Team='" + Team + "'";

                DataTable dtGetDetails = das.Select_Table(strGetQuery, hat, "Text");

                for (int i = 0; i < dtGetDetails.Rows.Count; i++)
                {
                    string ScARC = dtGetDetails.Rows[i]["In_Scope_For_ARC"].ToString();
                    string algo = dtGetDetails.Rows[i]["Algorithms"].ToString();
                    string team = dtGetDetails.Rows[i]["Team"].ToString();
                    string couName = dtGetDetails.Rows[i]["Country_Name"].ToString();
                    string Site = dtGetDetails.Rows[i]["Site"].ToString();
                    string Recon = dtGetDetails.Rows[i]["Recon"].ToString();
                    string SLA_Time = dtGetDetails.Rows[i]["SLA_Time"].ToString();
                    string ManuFTP = dtGetDetails.Rows[i]["Manual_FTP"].ToString();
                    string REportSouFileName = dtGetDetails.Rows[i]["Report_Source_File_Name"].ToString();
                    string FTPFILENAme = dtGetDetails.Rows[i]["FTP_File_Format_Name"].ToString();
                    string SourceApplication = dtGetDetails.Rows[i]["Source_Application"].ToString();
                    string SourcePath = dtGetDetails.Rows[i]["Source_path"].ToString();
                    string FTPDestinationPath = dtGetDetails.Rows[i]["FTP_Destination_Path"].ToString();
                    string ReceiptTime = dtGetDetails.Rows[i]["Receipt_Time"].ToString();
                    string FileFormat = dtGetDetails.Rows[i]["File_Format"].ToString();
                    string FormatDirect = dtGetDetails.Rows[i]["Format_Direct_Upload"].ToString();
                    string Remarks = dtGetDetails.Rows[i]["Remarks"].ToString();
                    string Frequen = dtGetDetails.Rows[i]["Frequency"].ToString();
                    string CountID = dtGetDetails.Rows[i]["Country_ID"].ToString();
                    string IsProcessed = dtGetDetails.Rows[i]["IsProcessed"].ToString();
                    string ProduID = dtGetDetails.Rows[i]["Product_Id"].ToString();
                    string CurDate = dtGetDetails.Rows[i]["Processed_date"].ToString();
                    string EmailSub = dtGetDetails.Rows[i]["Email_Subject"].ToString();
                    string reconId = dtGetDetails.Rows[i]["Recon_Id"].ToString();
                    string Recondate = dtGetDetails.Rows[i]["Recon_Date"].ToString();
                    string AutomationStatus = dtGetDetails.Rows[i]["automationStatus"].ToString();
                    string PSID = dtGetDetails.Rows[i]["PSID"].ToString();
                    string AutoStartTime = dtGetDetails.Rows[i]["AutomationStartTime"].ToString();
                    string AutoEndTime = dtGetDetails.Rows[i]["AutomationEndTime"].ToString();
                    string RHID = dtGetDetails.Rows[i]["RHID"].ToString();

                    //************ Checking Recon Master Status Completed **********************************

                    dtReconOld.DefaultView.RowFilter = "Country='" + couName + "' and Recon_Name='" + Recon + "' and Team='" + team + "' and Recon_Date='" + Recondate + "'";
                    DataView dvReconMaster = dtReconOld.DefaultView;
                    if (dvReconMaster.Count > 0)
                    {
                        Scope_id++;
                        string strHistoryMoveInsQuery = "if not exists(select * from Arc_Scope_BaseLine_history where " + filerquery + " and Report_Source_File_Name = '" + REportSouFileName + "' and FTP_File_Format_Name = '" + FTPFILENAme + "' and Recon_Date='" + Recondate + "')";
                        strHistoryMoveInsQuery = strHistoryMoveInsQuery + " insert into Arc_Scope_BaseLine_history (scope_id,In_Scope_For_ARC,Algorithms,Team,Country_Name,Site,Recon,SLA_Time,Manual_FTP,Report_Source_File_Name,FTP_File_Format_Name,Source_Application,Source_path,FTP_Destination_Path,Receipt_Time,File_Format,Format_Direct_Upload,Remarks,Frequency,Country_ID,IsProcessed,Product_Id,Recon_Id,[Current_Date],Email_Subject,Recon_Date,automationStatus,PSID,AutomationStartTime,AutomationEndTime)";
                        strHistoryMoveInsQuery = strHistoryMoveInsQuery + " Values('" + Scope_id + "','" + ScARC + "','" + algo + "','" + team + "','" + couName + "','" + Site + "','" + Recon + "','" + SLA_Time + "','" + ManuFTP + "','" + REportSouFileName + "','" + FTPFILENAme + "','" + SourceApplication + "','" + SourcePath + "','" + FTPDestinationPath + "','" + ReceiptTime + "','" + FileFormat + "','" + FormatDirect + "','" + Remarks + "','" + Frequen + "','" + CountID + "','" + IsProcessed + "','" + ProduID + "','" + reconId + "','" + CurDate + "','" + EmailSub + "','" + Recondate + "','" + AutomationStatus + "','" + PSID + "','" + AutoStartTime + "','" + AutoEndTime + "')";
                        strHistoryMoveInsQuery = strHistoryMoveInsQuery + " else update Arc_Scope_BaseLine_history set PSID='" + PSID + "',automationStatus='" + AutomationStatus + "',IsProcessed='" + IsProcessed + "',AutomationStartTime='" + AutoStartTime + "',AutomationEndTime='" + AutoEndTime + "',[Current_Date]='" + CurDate + "' where " + filerquery + " and Recon_Date='" + Recondate + "'";
                        int insval = das.ins_upd_fun(strHistoryMoveInsQuery, hat, "Text");

                        string strHolidayReconDelQuery = "delete from ARC_Scope_Baseline_Logic where RHID='" + RHID + "'";
                        insval = das.ins_upd_fun(strHolidayReconDelQuery, hat, "Text");
                    }
                }

                //Moving Old Recon Master date

                for (int i = 0; i < dtReconOld.Rows.Count; i++)
                {
                    string reconId = dtReconOld.Rows[i]["Recon_id"].ToString();
                    string team = dtReconOld.Rows[i]["Team"].ToString();
                    string couName = dtReconOld.Rows[i]["Country"].ToString();
                    string Recon = dtReconOld.Rows[i]["Recon_name"].ToString();
                    string nooffile = dtReconOld.Rows[i]["Total_files"].ToString();
                    string SLATime = dtReconOld.Rows[i]["SLA_Time"].ToString();
                    string Receipt_Time = dtReconOld.Rows[i]["Receipt_time"].ToString();
                    string ReconCompleted = dtReconOld.Rows[i]["Is_Recon_Completed"].ToString();
                    string ReconStatus = dtReconOld.Rows[i]["Recon_Status"].ToString();
                    string ISActive = dtReconOld.Rows[i]["Is_Active"].ToString();
                    string PSID = dtReconOld.Rows[i]["PSID"].ToString();
                    string AutomationStartTime = dtReconOld.Rows[i]["AutomationStartTime"].ToString();
                    string AutomationEndTime = dtReconOld.Rows[i]["AutomationEndTime"].ToString();
                    string Recondate = dtReconOld.Rows[i]["Recon_Date"].ToString();

                    string strReconMasterTableInsert = "if not exists(select * from Arc_Recon_Master_Holiday_Date_Logic_History  where Recon_name='" + Recon + "' and team='" + team + "' and  Country='" + couName + "' and recon_date='" + Recondate + "')";
                    strReconMasterTableInsert = strReconMasterTableInsert + " insert into Arc_Recon_Master_Holiday_Date_Logic_History (Recon_Id,Recon_name,Team,Country,Total_Files,Recon_Date,Is_Recon_Completed,Recon_Status,Is_Active,SLA_Time,Receipt_Time,AutomationStartTime,AutomationEndTime,PSID) values('" + reconId + "','" + Recon + "','" + team + "','" + couName + "','" + nooffile + "','" + Recondate + "','" + ReconCompleted + "','" + ReconStatus + "','" + ISActive + "','" + SLATime + "','" + Receipt_Time + "','" + AutomationStartTime + "','" + AutomationEndTime + "','" + PSID + "')";
                    strReconMasterTableInsert = strReconMasterTableInsert + " else Update Arc_Recon_Master_Holiday_Date_Logic_History set Is_Recon_Completed='" + ReconCompleted + "',Recon_Status='" + ReconStatus + "',Is_Active='" + ISActive + "',AutomationStartTime='" + AutomationStartTime + "',AutomationEndTime='" + AutomationEndTime + "',PSID='" + PSID + "' where Recon_name='" + Recon + "' and team='" + team + "' and  Country='" + couName + "' and recon_date='" + Recondate + "'";
                    int insvalrecon = das.ins_upd_fun(strReconMasterTableInsert, hat, "Text");

                    strReconMasterTableInsert = "Delete Arc_Recon_Master_Holiday_Date_Logic where Country='" + CountryName + "' and Recon_Name='" + ReconName + "' and Team='" + Team + "' and recon_date='" + Recondate + "'";
                    insvalrecon = das.ins_upd_fun(strReconMasterTableInsert, hat, "Text");
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        public void Holiday_Logics(string constring)
        {
            try
            {
                DAccess das = new DAccess();
                Hashtable hat = new Hashtable();
                SqlConnection con = new SqlConnection(conString);

                DateTime currDate = DateTime.Now;
                DateTime dtval = DateTime.Today;
                DateTime dtFinalDate = dtval;

                DataTable dtHolidayCheck = das.Select_Table("select recon from arc_scope_baseline where [Current_Date]='" + currDate.ToString("yyyy/MM/dd") + "'", hat, "Text");
                if (dtHolidayCheck.Rows.Count < 1)
                {
                    //Individual Recon
                    //string strReconMasterQuery = "select recon_id,recon_name,team,country,Total_Files,convert(nvarchar(50),SLA_Time, 101) + ' ' + CONVERT(VARCHAR(8),SLA_Time, 108) SLA_Time,convert(nvarchar(50),Receipt_Time, 101) + ' ' + CONVERT(VARCHAR(8), Receipt_Time, 108) Receipt_Time,Is_Recon_Completed,Recon_Status,Is_Active,PSID,AutomationStartTime,AutomationEndTime from arc_recon_master where recon_name in ('Macau Suspense')";

                    //All Recons
                    string strReconMasterQuery = "select recon_id,recon_name,team,country,Total_Files,convert(nvarchar(50),SLA_Time, 101) + ' ' + CONVERT(VARCHAR(8),SLA_Time, 108) SLA_Time,convert(nvarchar(50),Receipt_Time, 101) + ' ' + CONVERT(VARCHAR(8), Receipt_Time, 108) Receipt_Time,Is_Recon_Completed,Recon_Status,Is_Active,PSID,AutomationStartTime,AutomationEndTime from arc_recon_master where  Is_Active = 1 and Is_Holiday_Logic = 1";

                    DataTable dtReconMaster = das.Select_Table(strReconMasterQuery, hat, "Text");

                    string strHoliQuery = "select * from arc_holiday_master where Holiday_date between '" + dtFinalDate.AddDays(-30).ToString("MM/dd/yyyy") + "' and '" + dtFinalDate.ToString("MM/dd/yyyy") + "'";
                    DataTable dtHoliday = das.Select_Table(strHoliQuery, hat, "Text");

                    string strReconHoli = "select * from ARC_Holiday_Recon_Run_Status";
                    DataTable dtReconHoli = das.Select_Table(strReconHoli, hat, "Text");

                    DataTable dtLastReconDetails = new DataTable();

                    //Individual Recon
                    //string strGetQuery = "select a.Country_Id,Recon_ID,a.Product_ID,a.Country_Name,a.Team,Recon,a.Report_Source_File_Name,a.ftp_file_format_name,a.[current_date],b.gulf from arc_scope_baseline a,Arc_Country_Details b where a.Country_Id=b.Country_Id and recon='Macau Suspense' ";

                    //All Recons
                    string strGetQuery = "select a.Country_Id,Recon_ID,a.Product_ID,a.Country_Name,a.Team,Recon,a.Report_Source_File_Name,a.ftp_file_format_name,a.[current_date],b.gulf from arc_scope_baseline a,Arc_Country_Details b where a.Country_Id=b.Country_Id and a.recon_id in (select recon_id from arc_recon_master where Is_Active = 1 and Is_Holiday_Logic = 1)";

                    DataTable dtGetDetails = das.Select_Table(strGetQuery, hat, "Text");
                    string temprecon = "";

                    DateTime DtStartdate = dtval.AddDays(-1);
                    for (int i = 0; i < dtGetDetails.Rows.Count; i++)
                    {
                        bool histflag = false;
                        string team = dtGetDetails.Rows[i]["Team"].ToString();
                        string couName = dtGetDetails.Rows[i]["Country_Name"].ToString();
                        string Recon = dtGetDetails.Rows[i]["Recon"].ToString();
                        string REportSouFileName = dtGetDetails.Rows[i]["Report_Source_File_Name"].ToString();
                        string FTPFILENAme = dtGetDetails.Rows[i]["FTP_File_Format_Name"].ToString();
                        string CountID = dtGetDetails.Rows[i]["Country_ID"].ToString();
                        string ProduID = dtGetDetails.Rows[i]["Product_Id"].ToString();
                        string reconId = dtGetDetails.Rows[i]["Recon_Id"].ToString();
                        string reconcurdate = dtGetDetails.Rows[i]["current_date"].ToString();
                        string IsGulf = dtGetDetails.Rows[i]["gulf"].ToString();


                        string filerquery = "Country_ID='" + CountID + "' and Product_Id='" + ProduID + "' and Recon_Id='" + reconId + "' and Recon='" + Recon + "' and Report_Source_File_Name='" + REportSouFileName + "' and FTP_File_Format_Name = '" + FTPFILENAme + "'";
                        //if (FTPFILENAme != null)
                        //{
                        //    if (FTPFILENAme.Trim().ToUpper() != "NULL")
                        //    {
                        //        filerquery = filerquery + " and FTP_File_Format_Name='" + FTPFILENAme + "'";
                        //    }
                        //}

                        dtReconHoli.DefaultView.RowFilter = filerquery;
                        DataView dvReconHolid = dtReconHoli.DefaultView;

                        bool IsSatFileAvailable = false;
                        bool IsSunFileAvailable = false;
                        bool IsHolidayFileAvailable = false;
                        bool ReconRunSat = false;
                        bool ReconRunSun = false;
                        bool ReconRunHoliday = false;
                        bool IsAlternateWeek = false;
                        bool IsAlternateSatFileAvailable = false;
                        bool IsAlternateSunFileAvailable = false;
                        int LastTrasaction = -1;
                        if (dvReconHolid.Count > 0)
                        {
                            if (dvReconHolid[0]["Is_File_Available_Sat"].ToString().Trim().ToLower() == "true" || dvReconHolid[0]["Is_File_Available_Sat"].ToString().Trim() == "1")
                            {
                                IsSatFileAvailable = true;
                            }
                            if (dvReconHolid[0]["Is_File_Available_Sun"].ToString().Trim().ToLower() == "true" || dvReconHolid[0]["Is_File_Available_Sun"].ToString().Trim() == "1")
                            {
                                IsSunFileAvailable = true;
                            }
                            if (dvReconHolid[0]["Is_File_Available_Holiday"].ToString().Trim().ToLower() == "true" || dvReconHolid[0]["Is_File_Available_Holiday"].ToString().Trim() == "1")
                            {
                                IsHolidayFileAvailable = true;
                            }
                            if (dvReconHolid[0]["Is_Sat"].ToString().Trim().ToLower() == "true" || dvReconHolid[0]["Is_Sat"].ToString().Trim() == "1")
                            {
                                ReconRunSat = true;
                            }
                            if (dvReconHolid[0]["Is_Sun"].ToString().Trim().ToLower() == "true" || dvReconHolid[0]["Is_Sun"].ToString().Trim() == "1")
                            {
                                ReconRunSun = true;
                            }
                            if (dvReconHolid[0]["Is_Holiday"].ToString().Trim().ToLower() == "true" || dvReconHolid[0]["Is_Holiday"].ToString().Trim() == "1")
                            {
                                ReconRunHoliday = true;
                            }
                            if (dvReconHolid[0]["is_Alternate_week"].ToString().Trim().ToLower() == "true" || dvReconHolid[0]["is_Alternate_week"].ToString().Trim() == "1")
                            {
                                IsAlternateWeek = true;
                            }
                            if (dvReconHolid[0]["is_Alternate_Sat_File_Available"].ToString().Trim().ToLower() == "true" || dvReconHolid[0]["is_Alternate_Sat_File_Available"].ToString().Trim() == "1")
                            {
                                IsAlternateSatFileAvailable = true;
                            }
                            if (dvReconHolid[0]["is_Alternate_Sun_File_Available"].ToString().Trim().ToLower() == "true" || dvReconHolid[0]["is_Alternate_Sun_File_Available"].ToString().Trim() == "1")
                            {
                                IsAlternateSunFileAvailable = true;
                            }

                            LastTrasaction = Convert.ToInt32(dvReconHolid[0]["Last_Trasaction"].ToString());
                        }


                        dtFinalDate = dtval.AddDays(LastTrasaction);

                        if (temprecon != Recon)
                        {
                            temprecon = Recon;
                            MoveToHistory(couName, team, Recon, constring);


                            dtLastReconDetails = das.Select_Table("select max(Recon_Date) last_recon_date from arc_scope_baseline_history where Isprocessed=1 and automationStatus like '%Completed' and recon_date is not null and Recon_Id='" + reconId + "' and Recon='" + Recon + "'", hat, "Text");

                            if (dtLastReconDetails.Rows.Count > 0)
                            {
                                if (dtLastReconDetails.Rows[0]["last_recon_date"] != null)
                                {
                                    if (dtLastReconDetails.Rows[0]["last_recon_date"].ToString().Trim() != "")
                                    {
                                        DtStartdate = Convert.ToDateTime(dtLastReconDetails.Rows[0]["last_recon_date"]);
                                        DtStartdate = DtStartdate.AddDays(1);
                                    }
                                }
                            }
                        }

                        bool holidayfilecheck = false;
                        for (DateTime dtReconDate = dtFinalDate; dtReconDate >= DtStartdate; dtReconDate = dtReconDate.AddDays(-1))
                        {
                            bool Runnablerecon = true;

                            if (dtReconDate.ToString("ddd").ToLower() == "fri" && IsGulf.ToUpper() == "GULF")
                            {
                                if (IsSatFileAvailable == false)
                                {
                                    Runnablerecon = false;
                                }
                            }

                            if (dtReconDate.ToString("ddd").ToLower() == "sat")
                            {
                                if (IsGulf.ToUpper() == "GULF")
                                {
                                    if (IsSunFileAvailable == false)//commented by bala || holidayfilecheck == false) 
                                    {
                                        Runnablerecon = false;
                                    }
                                }
                                else
                                {
                                    //For alternate sat
                                    Boolean alcheck = false;
                                    if (IsAlternateWeek == true)
                                    {
                                        if ((dtReconDate.Day <= 7) || (dtReconDate.Day >= 14 && dtReconDate.Day <= 21) || (dtReconDate.Day >= 28 && dtReconDate.Day <= 31))
                                        {
                                            if (IsAlternateSatFileAvailable == true)
                                            {
                                                alcheck = true;
                                            }
                                            else
                                            {
                                                Runnablerecon = false;
                                            }
                                            //Runnablerecon = false;
                                        }
                                        else
                                        {
                                            if (ReconRunSat == true && alcheck == true)//Sat file yet to come Monday
                                            {

                                                if (IsSatFileAvailable == false)
                                                {
                                                    Runnablerecon = false;
                                                }
                                            }
                                            else//Sat file yet to come tuesday
                                            {
                                                if (IsSatFileAvailable == false)//commented by bala || holidayfilecheck == false)
                                                {
                                                    Runnablerecon = false;
                                                }
                                            }
                                        }
                                    }
                                    else
                                    {
                                        if (ReconRunSat == true && alcheck == true)//Sat file yet to come Monday
                                        {

                                            if (IsSatFileAvailable == false)
                                            {
                                                Runnablerecon = false;
                                            }
                                        }
                                        else//Sat file yet to come tuesday
                                        {
                                            if (IsSatFileAvailable == false)//commented by bala || holidayfilecheck == false)
                                            {
                                                Runnablerecon = false;
                                            }
                                        }
                                    }
                                }
                            }

                            if (dtReconDate.ToString("ddd").ToLower() == "sun" && IsGulf.ToUpper() != "GULF")
                            {
                                Boolean alcheck = false;//Alternate Week check
                                if (IsAlternateWeek == true)
                                {
                                    if ((dtReconDate.Day <= 7) || (dtReconDate.Day >= 14 && dtReconDate.Day <= 21) || (dtReconDate.Day >= 28 && dtReconDate.Day <= 31))
                                    {
                                        if (IsAlternateSunFileAvailable == true)
                                        {
                                            alcheck = true;
                                        }
                                        else
                                        {
                                            Runnablerecon = false;
                                        }
                                    }
                                    else
                                    {
                                        if (ReconRunSun == true && alcheck == false)//Sun file yet to come Monday
                                        {
                                            if (IsSunFileAvailable == false)
                                            {
                                                Runnablerecon = false;
                                            }
                                        }
                                        else//Sun file yet to come tuesday
                                        {
                                            if (IsSunFileAvailable == false)//commented by bala|| holidayfilecheck == false)
                                            {
                                                Runnablerecon = false;
                                            }
                                        }
                                    }
                                }
                                else
                                {
                                    if (ReconRunSun == true && alcheck == false)//Sun file yet to come Monday
                                    {
                                        if (IsSunFileAvailable == false)
                                        {
                                            Runnablerecon = false;
                                        }
                                    }
                                    else//Sun file yet to come tuesday
                                    {
                                        if (IsSunFileAvailable == false)//commented by bala || holidayfilecheck == false)
                                        {
                                            Runnablerecon = false;
                                        }
                                    }
                                }
                            }

                            dtHoliday.DefaultView.RowFilter = "Country_ID='" + CountID + "' and Holiday_date='" + dtReconDate + "'";
                            DataView dvHoliday = dtHoliday.DefaultView;
                            if (dvHoliday.Count > 0)
                            {
                                if (ReconRunHoliday == true)
                                {
                                    if (IsHolidayFileAvailable == false)
                                    {
                                        Runnablerecon = false;
                                    }
                                }
                                else
                                {
                                    if (IsHolidayFileAvailable == false)//commented by bala|| holidayfilecheck == false)
                                    {
                                        Runnablerecon = false;
                                    }
                                }
                            }
                            //Added Bala-25/04/18
                            if (Recon == "Kenya - VISA Electron ATM Suspense AC recon and outstanding Report" || Recon == "Srilanka TLM Open Items-CA-LK-BRH-122131-SharedDrive")
                            {
                                if (DateTime.Now.ToString("ddd").ToLower() == "tue")
                                {
                                    if (dtReconDate.ToString("ddd").ToLower() == "sat" || dtReconDate.ToString("ddd").ToLower() == "sun")
                                    {
                                        Runnablerecon = true;
                                    }
                                }
                            }

                            //Added Bala

                            if (Runnablerecon == true)
                            {
                                holidayfilecheck = true;

                                string strReconDateInsUpdQuery = "if not exists(select * from ARC_Scope_Baseline_Logic where " + filerquery + " and recon_date='" + dtReconDate.ToString("MM-dd-yyyy") + "')";
                                strReconDateInsUpdQuery = strReconDateInsUpdQuery + " insert into ARC_Scope_Baseline_Logic (Country_Id,Recon_ID,Product_ID,Country_Name,Team,Recon,Report_Source_File_Name,ftp_file_format_name,Recon_Date,IsProcessed) ";
                                strReconDateInsUpdQuery = strReconDateInsUpdQuery + " values('" + CountID + "','" + reconId + "','" + ProduID + "','" + couName + "','" + team + "','" + Recon + "','" + REportSouFileName + "','" + FTPFILENAme + "','" + dtReconDate.ToString("MM-dd-yyyy") + "','0')";
                                strReconDateInsUpdQuery = strReconDateInsUpdQuery + " else Update ARC_Scope_Baseline_Logic set PSID=Null,automationStatus=Null,IsProcessed=0,AutomationStartTime=Null,AutomationEndTime=Null,Processed_Date=Null where " + filerquery + " and recon_date='" + dtReconDate.ToString("MM-dd-yyyy") + "'";
                                int insval = das.ins_upd_fun(strReconDateInsUpdQuery, hat, "Text");

                                string nooffile = "";
                                dtReconMaster.DefaultView.RowFilter = "Recon_Id='" + reconId + "' and Recon_name='" + Recon + "' and team='" + team + "' and  Country='" + couName + "'";
                                DataView dvReconMaster = dtReconMaster.DefaultView;
                                if (dvReconMaster.Count > 0)
                                {
                                    nooffile = dvReconMaster[0]["Total_Files"].ToString();

                                    string SLATime = dvReconMaster[0]["SLA_Time"].ToString();
                                    string Receipt_Time = dvReconMaster[0]["Receipt_Time"].ToString();

                                    string strReconMasterTableInsert = "if not exists(select * from Arc_Recon_Master_Holiday_Date_Logic where Recon_Id='" + reconId + "' and Recon_name='" + Recon + "' and team='" + team + "' and  Country='" + couName + "' and Total_Files='" + nooffile + "' and Recon_Date='" + dtReconDate.ToString("MM-dd-yyyy") + "')";
                                    strReconMasterTableInsert = strReconMasterTableInsert + " insert into Arc_Recon_Master_Holiday_Date_Logic(Recon_Id,Recon_name,Team,Country,Total_Files,Recon_Date,Is_Recon_Completed,Is_Active,SLA_Time,Receipt_Time) values('" + reconId + "','" + Recon + "','" + team + "','" + couName + "','" + nooffile + "','" + dtReconDate.ToString("MM-dd-yyyy") + "','0','1','" + SLATime + "','" + Receipt_Time + "')";
                                    strReconMasterTableInsert = strReconMasterTableInsert + " else Update Arc_Recon_Master_Holiday_Date_Logic set Is_Recon_Completed='0',Recon_Status=Null,Is_Active='1',AutomationStartTime=Null,AutomationEndTime=Null,PSID=Null where Recon_Id='" + reconId + "' and Recon_name='" + Recon + "' and team='" + team + "' and  Country='" + couName + "' and Total_Files='" + nooffile + "' and Recon_Date='" + dtReconDate.ToString("MM-dd-yyyy") + "'";
                                    int insvalrecon = das.ins_upd_fun(strReconMasterTableInsert, hat, "Text");
                                }
                            }
                        }
                    }

                    ///Normal History
                    ///
                    SqlCommand cmd = new SqlCommand("dbo.ARC_SP_CLEAN_MASTER_DATA", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@SYSTEM_DATE", DateTime.Now);
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        public static DataTable GetReconDate(string strCountryName, string strRecon, string strReportSourceFileName, string strFTPFileFormateName, string strDateFormate, string constr)
        {
            DataTable dtReconDate = new DataTable();
            try
            {
                Hashtable hat = new Hashtable();
                string strQuery = "select convert(nvarchar,recon_date,101)recon_date,country_name,recon,report_source_file_name,ftp_file_format_name from ARC_Scope_Baseline_Logic where country_name='" + strCountryName + "' and recon='" + strRecon + "' and report_source_file_name='" + strReportSourceFileName + "' and isprocessed=0";
                if (strFTPFileFormateName.Trim() != "")
                {
                    strQuery = strQuery + " and ftp_file_format_name='" + strFTPFileFormateName + "'";
                }
                strQuery = strQuery + " order by recon_date";
                SqlConnection con = new SqlConnection(constr);
                con.Close();
                con.Open();
                SqlDataAdapter da = new SqlDataAdapter(strQuery, con);
                con.Close();
                da.Fill(dtReconDate);
                //dtReconDate = das.Select_Table(strQuery, hat, "Text");

                for (int i = 0; i < dtReconDate.Rows.Count; i++)
                {
                    DateTime myDate = DateTime.ParseExact(dtReconDate.Rows[i]["recon_date"].ToString(), "MM/dd/yyyy", System.Globalization.CultureInfo.InvariantCulture);
                    dtReconDate.Rows[i]["recon_date"] = myDate.ToString(strDateFormate);
                }
            }
            catch
            {
            }
            return dtReconDate;
        }

        public static string Get_Recon_Date(string CountryName, string Date_Format)
        {
            DAccess das = new DAccess();
            Formatting_Logics obj = new Formatting_Logics();
            Hashtable hat = new Hashtable();
            string Final_Date = string.Empty;
            string fmt = CultureInfo.CurrentCulture.DateTimeFormat.ShortDatePattern;

            try
            {
                int day = 0;
                string actd = "";
                int datefound = 0;
                System.Data.DataTable dt = new System.Data.DataTable();
                System.Data.DataTable table = new System.Data.DataTable();
                System.Data.DataTable date = new System.Data.DataTable();
                string Today = DateTime.Now.ToString("dddd");

                //string date = DateTime.Now.ToString("09/09/2017");
                //*************************************************************************
                //SqlDataAdapter ad = new SqlDataAdapter("dbo.ARC_SP_Get_Holiday_Date", con);
                //ad.SelectCommand.CommandType = CommandType.StoredProcedure;
                //ad.SelectCommand.Parameters.AddWithValue("@Country_Name", CountryName);
                //con.Open();
                //ad.Fill(table);
                //con.Close();

                hat.Clear();
                hat.Add("@Country_Name", CountryName);
                table = das.Select_Table("dbo.ARC_SP_Get_Holiday_Date", hat, "sp");

                if (table.Rows.Count > 0)
                {
                    if (Convert.ToString(table.Rows[0][2]).Trim() == "NonGulf")
                    {
                        int Year = Convert.ToInt32(DateTime.Now.ToString("yyyy"));
                        //DateTime EndOfYear = Convert.ToDateTime("31-12-" + Year + "");
                        DateTime startDate = new DateTime(Year, 1, 1);
                        DateTime endDate = new DateTime(Year, 12, 31);

                        date.Columns.Add("Holiday_Date", typeof(DateTime));
                        date.Columns.Add("Country_Id", typeof(long));
                        date.Columns.Add("Gulf");
                        TimeSpan diff = endDate - startDate;
                        int days = diff.Days;
                        for (var i = 0; i <= days; i++)
                        {
                            var testDate = startDate.AddDays(i);
                            try
                            {
                                switch (testDate.DayOfWeek)
                                {
                                    case DayOfWeek.Saturday:
                                    case DayOfWeek.Sunday:
                                        date.Rows.Add();
                                        date.Rows.Add(testDate.ToString(fmt));
                                        break;
                                }

                            }
                            catch
                            {

                            }
                        }
                        date.Merge(table);
                        obj.ExecRemoveDuplicateRows(date, "Holiday_Date");
                    }
                    else
                    {
                        int Year = Convert.ToInt32(DateTime.Now.ToString("yyyy"));
                        DateTime startDate = new DateTime(Year, 1, 1);
                        DateTime endDate = new DateTime(Year, 12, 31);

                        date.Columns.Add("Holiday_Date", typeof(DateTime));
                        date.Columns.Add("Country_Id", typeof(long));
                        date.Columns.Add("Gulf");
                        TimeSpan diff = endDate - startDate;
                        int days = diff.Days;
                        for (var i = 0; i <= days; i++)
                        {
                            var testDate = startDate.AddDays(i);
                            switch (testDate.DayOfWeek)
                            {
                                case DayOfWeek.Friday:
                                case DayOfWeek.Saturday:
                                    date.Rows.Add(testDate.ToString(fmt));
                                    break;
                            }
                        }
                        date.Merge(table);
                    }
                }
                else
                {
                    //SqlCommand ad1 = new SqlCommand("dbo.ARC_SP_Get_Holiday_Date_NoHoliday", con);
                    //ad1.CommandType = CommandType.StoredProcedure;
                    //ad1.Parameters.AddWithValue("@Country_Name", CountryName);
                    //con.Open();
                    // string Result = Convert.ToString(ad1.ExecuteScalar());

                    // con.Close();

                    hat.Clear();
                    hat.Add("@Country_Name", CountryName);
                    table = das.Select_Table("dbo.ARC_SP_Get_Holiday_Date_NoHoliday", hat, "sp");

                    string Result = "";
                    if (table.Rows.Count > 0)
                    {
                        Result = table.Rows[0][0].ToString();
                    }

                    if (Result == "NonGulf")
                    {
                        int Year = Convert.ToInt32(DateTime.Now.ToString("yyyy"));
                        DateTime startDate = new DateTime(Year, 1, 1);
                        DateTime endDate = new DateTime(Year, 12, 31);

                        date.Columns.Add("Holiday_Date", typeof(DateTime));
                        date.Columns.Add("Country_Id", typeof(long));
                        date.Columns.Add("Gulf");
                        TimeSpan diff = endDate - startDate;
                        int days = diff.Days;
                        for (var i = 0; i <= days; i++)
                        {
                            var testDate = startDate.AddDays(i);
                            switch (testDate.DayOfWeek)
                            {
                                case DayOfWeek.Saturday:
                                case DayOfWeek.Sunday:
                                    date.Rows.Add(testDate.ToString(fmt));
                                    break;
                            }
                        }
                    }
                    else
                    {
                        int Year = Convert.ToInt32(DateTime.Now.ToString("yyyy"));
                        DateTime startDate = new DateTime(Year, 1, 1);
                        DateTime endDate = new DateTime(Year, 12, 31);

                        date.Columns.Add("date");
                        TimeSpan diff = endDate - startDate;
                        int days = diff.Days;
                        for (var i = 0; i <= days; i++)
                        {
                            var testDate = startDate.AddDays(i);
                            switch (testDate.DayOfWeek)
                            {
                                case DayOfWeek.Friday:
                                case DayOfWeek.Saturday:
                                    date.Rows.Add(testDate.ToString(fmt));
                                    break;
                            }
                        }
                    }
                    date.Merge(table);

                }
                //************************************************

                DataView v = date.DefaultView;
                v.Sort = "Holiday_Date";
                System.Data.DataTable d = new System.Data.DataTable();
                d = v.ToTable();
                try
                {
                    for (int i = 0; i <= d.Rows.Count - 1; i++)
                    {
                        if (d.Rows[i][0].ToString() != "")
                        {

                            string d1 = DateTime.Now.AddDays(-1).ToString("MM/dd/yyyy");
                            string d2 = DateTime.Now.AddDays(-2).ToString("MM/dd/yyyy");
                            string d3 = DateTime.Now.AddDays(-3).ToString("MM/dd/yyyy");
                            string d4 = DateTime.Now.AddDays(-4).ToString("MM/dd/yyyy");
                            string d5 = DateTime.Now.AddDays(-5).ToString("MM/dd/yyyy");
                            actd = Convert.ToDateTime(d.Rows[i][0]).ToString("MM/dd/yyyy");
                            if (d1 == actd)
                            {
                                datefound = 1;
                                day = day + 1;
                                actd = Convert.ToDateTime(d.Rows[i - 1][0]).ToString("MM/dd/yyyy");
                                if (d2 == actd)
                                {
                                    day = day + 1;
                                    actd = Convert.ToDateTime(d.Rows[i - 2][0]).ToString("MM/dd/yyyy");
                                    if (d3 == actd)
                                    {
                                        day = day + 1;
                                        actd = Convert.ToDateTime(d.Rows[i - 3][0]).ToString("MM/dd/yyyy");
                                        if (d4 == actd)
                                        {
                                            day = day + 1;
                                            actd = Convert.ToDateTime(d.Rows[i - 4][0]).ToString("MM/dd/yyyy");
                                            if (d5 == actd)
                                            {
                                                day = day + 1;
                                                actd = Convert.ToDateTime(d.Rows[i - 5][0]).ToString("MM/dd/yyyy");
                                            }
                                        }
                                    }
                                }
                            }
                        }


                    }


                    if (datefound == 0)
                    {
                        ////MessageBox.Show("Pick yesterdays File");
                        Final_Date = DateTime.Now.AddDays(-1).ToString("MM/dd/yyyy");
                    }
                    else
                    {
                        //MessageBox.Show("Pick " + (day + 1).ToString() + " Days before File");
                        int t = 0;
                        t = t - (day + 1);
                        Final_Date = DateTime.Now.AddDays(t).ToString("MM/dd/yyyy");

                    }
                }
                catch
                {
                    //MessageBox.Show("");
                }

            }
            catch
            {
                return null;

            }

            string[] Date = Final_Date.Split(' ');
            if (Date[0].ToString().Contains("/"))
            {
                string[] Date_Final = Date[0].Split('/');

                Final_Date = "";
                if (Date_Final[1].Length == 1 && Date_Final[0].Length == 2)
                {
                    Final_Date = "0" + Date_Final[1] + Date_Final[0] + Date_Final[2];
                }
                else if (Date_Final[1].Length == 2 && Date_Final[0].Length == 1)
                {
                    Final_Date = Date_Final[1] + "0" + Date_Final[0] + Date_Final[2];
                }
                else if (Date_Final[1].Length == 1 && Date_Final[0].Length == 1)
                {
                    Final_Date = "0" + Date_Final[1] + "0" + Date_Final[0] + Date_Final[2];
                }
                else if (Date_Final[1].Length == 2 && Date_Final[0].Length == 2)
                {
                    Final_Date = Date_Final[1] + Date_Final[0] + Date_Final[2];
                }
            }
            else if (Date[0].ToString().Contains("."))
            {
                string[] Date_Final = Date[0].Split('.');

                Final_Date = "";
                if (Date_Final[1].Length == 1 && Date_Final[0].Length == 2)
                {
                    Final_Date = "0" + Date_Final[1] + Date_Final[0] + Date_Final[2];
                }
                else if (Date_Final[1].Length == 2 && Date_Final[0].Length == 1)
                {
                    Final_Date = Date_Final[1] + "0" + Date_Final[0] + Date_Final[2];
                }
                else if (Date_Final[1].Length == 1 && Date_Final[0].Length == 1)
                {
                    Final_Date = "0" + Date_Final[1] + "0" + Date_Final[0] + Date_Final[2];
                }
                else if (Date_Final[1].Length == 2 && Date_Final[0].Length == 2)
                {
                    Final_Date = Date_Final[1] + Date_Final[0] + Date_Final[2];
                }
            }
            else if (Date[0].ToString().Contains("-"))
            {
                string[] Date_Final = Date[0].Split('-');

                Final_Date = "";
                if (Date_Final[1].Length == 1 && Date_Final[0].Length == 2)
                {
                    Final_Date = "0" + Date_Final[1] + Date_Final[0] + Date_Final[2];
                }
                else if (Date_Final[1].Length == 2 && Date_Final[0].Length == 1)
                {
                    Final_Date = Date_Final[1] + "0" + Date_Final[0] + Date_Final[2];
                }
                else if (Date_Final[1].Length == 1 && Date_Final[0].Length == 1)
                {
                    Final_Date = "0" + Date_Final[1] + "0" + Date_Final[0] + Date_Final[2];
                }
                else if (Date_Final[1].Length == 2 && Date_Final[0].Length == 2)
                {
                    Final_Date = Date_Final[1] + Date_Final[0] + Date_Final[2];
                }
            }
            DateTime myDate = DateTime.ParseExact(Final_Date, "ddMMyyyy", System.Globalization.CultureInfo.InvariantCulture);
            Final_Date = myDate.ToString(Date_Format);

            return Final_Date;
        }


        //*******************************************************************//
        public void Check_Recon_Files_Count(string Recon_Name, int Recon_ID, DataTable dt, out int fcount)
        {
            fcount = 0;
            dt = obj.Get_All_Files_Details(Recon_Name, Recon_ID, conString);
            fcount = obj.Get_All_Files_Count_From_Folders(dt, Recon_Name, conString, Directory);
        }
        //*******************************************************************//

        public DataTable Formatting_SG_SEC_RPR_Signs(DataTable dt)
        {
            /**** BRANCH *****/
            dt.AsEnumerable().Where(r => r.Field<string>(5) == "Branch-O1" && r.Field<string>(6) == "Purchase").ToList().ForEach(r =>
            { r["TRANS AMOUNT"] = "-" + r.Field<string>(2); });
            dt.AsEnumerable().Where(r => r.Field<string>(5) == "Branch-O1" && r.Field<string>(6) == "Purchase").ToList().ForEach(r =>
            { r["LOCAL EQUIVALENT"] = "-" + r.Field<string>(3); });
            dt.AsEnumerable().Where(r => r.Field<string>(5) == "Branch-RDS" && r.Field<string>(6) == "Purchase").ToList().ForEach(r =>
            { r["TRANS AMOUNT"] = "-" + r.Field<string>(2); });
            dt.AsEnumerable().Where(r => r.Field<string>(5) == "Branch-RDS" && r.Field<string>(6) == "Purchase").ToList().ForEach(r =>
            { r["LOCAL EQUIVALENT"] = "-" + r.Field<string>(3); });

            dt.AsEnumerable().Where(r => r.Field<string>(5) == "Branch-O1" && r.Field<string>(6) == "Sale").ToList().ForEach(r =>
            { r["TRANS AMOUNT"] = (r.Field<string>(2)).Replace("-", "+"); });
            dt.AsEnumerable().Where(r => r.Field<string>(5) == "Branch-O1" && r.Field<string>(6) == "Sale").ToList().ForEach(r =>
            { r["LOCAL EQUIVALENT"] = (r.Field<string>(3)).Replace("-", "+"); });
            dt.AsEnumerable().Where(r => r.Field<string>(5) == "Branch-RDS" && r.Field<string>(6) == "Sale").ToList().ForEach(r =>
            { r["TRANS AMOUNT"] = (r.Field<string>(2)).Replace("-", "+"); });
            dt.AsEnumerable().Where(r => r.Field<string>(5) == "Branch-RDS" && r.Field<string>(6) == "Sale").ToList().ForEach(r =>
            { r["LOCAL EQUIVALENT"] = (r.Field<string>(3)).Replace("-", "+"); });


            /**** SUB *****/
            dt.AsEnumerable().Where(r => r.Field<string>(5) == "SUB-O1" && r.Field<string>(6) == "Purchase").ToList().ForEach(r =>
            { r["TRANS AMOUNT"] = "-" + r.Field<string>(2); });
            dt.AsEnumerable().Where(r => r.Field<string>(5) == "SUB-O1" && r.Field<string>(6) == "Purchase").ToList().ForEach(r =>
            { r["LOCAL EQUIVALENT"] = "-" + r.Field<string>(3); });
            dt.AsEnumerable().Where(r => r.Field<string>(5) == "SUB-RDS" && r.Field<string>(6) == "Purchase").ToList().ForEach(r =>
            { r["TRANS AMOUNT"] = "-" + r.Field<string>(2); });
            dt.AsEnumerable().Where(r => r.Field<string>(5) == "SUB-RDS" && r.Field<string>(6) == "Purchase").ToList().ForEach(r =>
            { r["LOCAL EQUIVALENT"] = "-" + r.Field<string>(3); });

            dt.AsEnumerable().Where(r => r.Field<string>(5) == "SUB-O1" && r.Field<string>(6) == "Sale").ToList().ForEach(r =>
            { r["TRANS AMOUNT"] = (r.Field<string>(2)).Replace("-", "+"); });
            dt.AsEnumerable().Where(r => r.Field<string>(5) == "SUB-O1" && r.Field<string>(6) == "Sale").ToList().ForEach(r =>
            { r["LOCAL EQUIVALENT"] = (r.Field<string>(3)).Replace("-", "+"); });
            dt.AsEnumerable().Where(r => r.Field<string>(5) == "SUB-RDS" && r.Field<string>(6) == "Sale").ToList().ForEach(r =>
            { r["TRANS AMOUNT"] = (r.Field<string>(2)).Replace("-", "+"); });
            dt.AsEnumerable().Where(r => r.Field<string>(5) == "SUB-RDS" && r.Field<string>(6) == "Sale").ToList().ForEach(r =>
            { r["LOCAL EQUIVALENT"] = (r.Field<string>(3)).Replace("-", "+"); });


            //OPXR
            dt.AsEnumerable().Where(r => r.Field<string>(5) == "Branch-OPX" && r.Field<string>(6) == "Sale").ToList().ForEach(r =>
            { r["TRANS AMOUNT"] = "-" + r.Field<string>(2); });
            dt.AsEnumerable().Where(r => r.Field<string>(5) == "Branch-OPX" && r.Field<string>(6) == "Sale").ToList().ForEach(r =>
            { r["LOCAL EQUIVALENT"] = "-" + r.Field<string>(3); });

            dt.AsEnumerable().Where(r => r.Field<string>(5) == "SUB" && r.Field<string>(6) == "Sale").ToList().ForEach(r =>
            { r["TRANS AMOUNT"] = "-" + r.Field<string>(2); });
            dt.AsEnumerable().Where(r => r.Field<string>(5) == "SUB" && r.Field<string>(6) == "Sale").ToList().ForEach(r =>
            { r["LOCAL EQUIVALENT"] = "-" + r.Field<string>(3); });


            /** PURCHASE/SALE **/
            dt.AsEnumerable().Where(r => r.Field<string>(5) == "Branch-O1" && r.Field<string>(6) == "Purchase").ToList().ForEach(r =>
            { r["PURCHASE/SALE"] = (r.Field<string>(6)).Replace("Purchase", "Dept Posted Purchase"); });
            dt.AsEnumerable().Where(r => r.Field<string>(5) == "Branch-O1" && r.Field<string>(6) == "Sale").ToList().ForEach(r =>
            { r["PURCHASE/SALE"] = (r.Field<string>(6)).Replace("Sale", "Dept Posted Sale"); });

            dt.AsEnumerable().Where(r => r.Field<string>(5) == "SUB-O1" && r.Field<string>(6) == "Purchase").ToList().ForEach(r =>
            { r["PURCHASE/SALE"] = (r.Field<string>(6)).Replace("Purchase", "Dept Posted Purchase"); });
            dt.AsEnumerable().Where(r => r.Field<string>(5) == "SUB-O1" && r.Field<string>(6) == "Sale").ToList().ForEach(r =>
            { r["PURCHASE/SALE"] = (r.Field<string>(6)).Replace("Sale", "Dept Posted Sale"); });

            dt.AsEnumerable().Where(r => r.Field<string>(5) == "Branch-RDS" && r.Field<string>(6) == "Purchase").ToList().ForEach(r =>
            { r["PURCHASE/SALE"] = (r.Field<string>(6)).Replace("Purchase", "Dept Booked RDS Purchase"); });
            dt.AsEnumerable().Where(r => r.Field<string>(5) == "Branch-RDS" && r.Field<string>(6) == "Sale").ToList().ForEach(r =>
            { r["PURCHASE/SALE"] = (r.Field<string>(6)).Replace("Sale", "Dept Booked RDS Sale"); });

            dt.AsEnumerable().Where(r => r.Field<string>(5) == "SUB-RDS" && r.Field<string>(6) == "Purchase").ToList().ForEach(r =>
            { r["PURCHASE/SALE"] = (r.Field<string>(6)).Replace("Purchase", "Dept Booked RDS Purchase"); });
            dt.AsEnumerable().Where(r => r.Field<string>(5) == "SUB-RDS" && r.Field<string>(6) == "Sale").ToList().ForEach(r =>
            { r["PURCHASE/SALE"] = (r.Field<string>(6)).Replace("Sale", "Dept Booked RDS Sale"); });



            dt.AsEnumerable().Where(r => r.Field<string>(5) == "Branch-OPX" && r.Field<string>(6) == "Purchase").ToList().ForEach(r =>
            { r["PURCHASE/SALE"] = (r.Field<string>(6)).Replace("Purchase", "Treasury Posted Purchase"); });
            dt.AsEnumerable().Where(r => r.Field<string>(5) == "Branch-OPX" && r.Field<string>(6) == "Sale").ToList().ForEach(r =>
            { r["PURCHASE/SALE"] = (r.Field<string>(6)).Replace("Sale", "Treasury Posted Sale"); });

            dt.AsEnumerable().Where(r => r.Field<string>(5) == "SUB" && r.Field<string>(6) == "Purchase").ToList().ForEach(r =>
            { r["PURCHASE/SALE"] = (r.Field<string>(6)).Replace("Purchase", "Treasury Posted Purchase"); });
            dt.AsEnumerable().Where(r => r.Field<string>(5) == "SUB" && r.Field<string>(6) == "Sale").ToList().ForEach(r =>
            { r["PURCHASE/SALE"] = (r.Field<string>(6)).Replace("Sale", "Treasury Posted Sale"); });



            dt.AcceptChanges();

            return dt;
        }

        public void GetShareDriveFiles(string conStr)
        {
            bool IsMulti_Download = false;
            try
            {
                SqlConnection con = new SqlConnection();
                con.ConnectionString = conStr;
                con.Open();
                //SqlDataAdapter sda = new SqlDataAdapter("select * from Arc_Scope_BaseLine where Recon = 'Angola FX Recon - Advised-Angola Adjustment Report'", con);
                SqlDataAdapter sda = new SqlDataAdapter("select * from Arc_Scope_BaseLine where (Source_Application like '%Shared Drive%' or Source_Application like '%ebbs - country share path%') and Team = 'FX' and IsProcessed = 0", con);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                con.Close();
                if (dt.Rows.Count > 0)
                {
                    foreach (DataRow dr in dt.Rows)
                    {
                        IsMulti_Download = false;
                        string Recon_Name = Convert.ToString(dr["Recon"]).Trim();
                        string Country_Name = Convert.ToString(dr["Country_Name"]).Trim();
                        string Scope_Id = Convert.ToString(dr["Scope_Id"]).Trim();
                        string Report_Source_File_Name = Convert.ToString(dr["Report_Source_File_Name"]).Trim();
                        string Source_Appilcation = Convert.ToString(dr["Source_Application"]).Trim();
                        string Recon_Date = string.Empty;
                        if ((Recon_Name == "Zimbabwe FX Recon_Zimbabwe FXR Adjustments") || (Recon_Name == "Kenya FX Recon_Kenya FXR Adjustments") || (Recon_Name == "Uganda FX Recon_Uganda FXR Adjustments") || (Recon_Name == "TANZANIA FX RECON_TANZANIA FXR Adjustments") || (Recon_Name == "Botswana FX Recon_Botswana FXR Adjustments"))
                        {
                            Recon_Date = obj.Get_Recon_Date_For_Monday_Logic(conStr, Country_Name, "MM.dd.yyyy");//yyyyMMdd 6 days working
                        }
                        else
                        {
                            Recon_Date = obj.Get_Recon_Date(conStr, Country_Name, "MM.dd.yyyy");//yyyyMMdd 5 days working
                        }
                        //Recon_Date = Convert.ToDateTime(Recon_Date).ToString("MM.dd.yyyy");
                        string CurrentDay = DateTime.Today.ToString("dddd");
                        string ValueConcat = Recon_Date.Substring(3, 2);
                        int start_DD = Convert.ToInt32(ValueConcat);

                        //Recon_Date = Recon_Date.Remove(Recon_Date.IndexOf(".")) + "." + start_DD + Recon_Date.Remove(0, Recon_Date.LastIndexOf("."));
                        TimeSpan ts = (DateTime.Today - Convert.ToDateTime(Recon_Date).Date);

                        if (ts.Days > 1 && ((Recon_Name == "Zimbabwe FX Recon_Zimbabwe FXR Adjustments") || (Recon_Name == "Kenya FX Recon_Kenya FXR Adjustments") || (Recon_Name == "Uganda FX Recon_Uganda FXR Adjustments") || (Recon_Name == "TANZANIA FX RECON_TANZANIA FXR Adjustments") || (Recon_Name == "Botswana FX Recon_Botswana FXR Adjustments")))
                        {
                            IsMulti_Download = true;
                            bool Is_Chk = false;
                            while (Convert.ToDateTime(Recon_Date).Date < DateTime.Now.AddDays(-1).Date)
                            {
                                //Recon_Date = Recon_Date.Remove(Recon_Date.IndexOf(".")) + "." + start_DD + Recon_Date.Remove(0, Recon_Date.LastIndexOf("."));
                                if (Is_Chk == true)
                                {
                                    Recon_Date = Convert.ToDateTime(Recon_Date).AddDays(1).ToString("MM.dd.yyyy");
                                }
                                obj.GetNigeria_FX_Files(Country_Name, Recon_Name, Source_Appilcation, Report_Source_File_Name, conStr, Recon_Date, Directory, IsMulti_Download);
                                start_DD++;
                            }
                        }
                        else
                        {
                            obj.GetNigeria_FX_Files(Country_Name, Recon_Name, Source_Appilcation, Report_Source_File_Name, conStr, Recon_Date, Directory, IsMulti_Download);
                        }
                    }
                    //return true;
                }
                else
                {
                    //return false;
                }
            }
            catch
            {
                //return false;
            }
        }

        public void CheckFileRunning()
        {
            #region Checking Drive
            Scripting.FileSystemObject FSO = new Scripting.FileSystemObject();
            string sDrive = FSO.GetDriveName(System.Windows.Forms.Application.ExecutablePath);
            Scripting.Drive drvName = FSO.GetDrive(sDrive);
            string sShare = drvName.ShareName;
            bool sExist = FSO.DriveExists(sDrive);
            bool sFolderExist = FSO.FolderExists(System.Windows.Forms.Application.ExecutablePath);
            bool sFileExist = FSO.FileExists(System.Windows.Forms.Application.ExecutablePath);
            if (sExist && sFolderExist || sFileExist)
            {
                if (sFileExist)
                {
                    if (sShare == null)
                    {
                        MessageBox.Show("Sorry! You can't use this Utility From Local Drive.!...", "Application Not Running!..", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        foreach (var p in System.Diagnostics.Process.GetProcessesByName("ARC_Formatting"))
                        {
                            p.Kill();
                        }
                    }
                }
            }
            #endregion
        }

        public static string Decrypt(string cipherText)
        {
            try
            {
                string EncryptionKey = "MAKV2SPBNI99212";
                byte[] cipherBytes = Convert.FromBase64String(cipherText);
                using (Aes encryptor = Aes.Create())
                {
                    Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
                    encryptor.Key = pdb.GetBytes(32);
                    encryptor.IV = pdb.GetBytes(16);
                    using (MemoryStream ms = new MemoryStream())
                    {
                        using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateDecryptor(), CryptoStreamMode.Write))
                        {
                            cs.Write(cipherBytes, 0, cipherBytes.Length);
                            cs.Close();
                        }
                        cipherText = Encoding.Unicode.GetString(ms.ToArray());
                    }
                }
                return cipherText;
            }
            catch
            {
                return null;
            }
        }

        //SA1001
        public void insertReconLog(Program.clsReconLog objReconLog)
        {
            SqlConnection con = new SqlConnection(conString);
            using (SqlCommand cmd = new SqlCommand("ARC_SP_Recon_Log", con))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@ReconID", SqlDbType.VarChar).Value = objReconLog.ReconID;
                cmd.Parameters.Add("@ReconName", SqlDbType.VarChar).Value = objReconLog.ReconName;
                cmd.Parameters.Add("@UserID", SqlDbType.VarChar).Value = objReconLog.UserID;
                cmd.Parameters.Add("@ErrorMessage", SqlDbType.VarChar).Value = objReconLog.ErrorMessage;
                cmd.Parameters.Add("@lineNo", SqlDbType.VarChar).Value = objReconLog.LineNo;
                cmd.Parameters.Add("@StartTime", SqlDbType.VarChar).Value = objReconLog.StartTime;
                cmd.Parameters.Add("@EndTime", SqlDbType.VarChar).Value = objReconLog.EndTime;
                cmd.Parameters.Add("@Flag", SqlDbType.VarChar).Value = objReconLog.Flag;
                cmd.Parameters.Add("@DateTime", SqlDbType.VarChar).Value = objReconLog.DateTime;
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                cmd.ExecuteNonQuery();
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }

        public class clsReconLog
        {
            private string reconID;
            public string ReconID
            {
                get { return reconID; }
                set { reconID = value; }
            }

            private string reconName;
            public string ReconName
            {
                get { return reconName; }
                set { reconName = value; }
            }

            private string userID;
            public string UserID
            {
                get { return userID; }
                set { userID = value; }
            }

            private string errorMessage;
            public string ErrorMessage
            {
                get { return errorMessage; }
                set { errorMessage = value; }
            }

            private string lineNo;
            public string LineNo
            {
                get { return lineNo; }
                set { lineNo = value; }
            }

            private string startTime;
            public string StartTime
            {
                get { return startTime; }
                set { startTime = value; }
            }

            private string endTime;
            public string EndTime
            {
                get { return endTime; }
                set { endTime = value; }
            }

            private string flag;
            public string Flag
            {
                get { return flag; }
                set { flag = value; }
            }

            private string dateTime;
            public string DateTime
            {
                get { return dateTime; }
                set { dateTime = value; }
            }
        }

        public void clearRconLog(Program.clsReconLog objReconLog)
        {
            objReconLog.ReconID = "";
            objReconLog.LineNo = "";
            objReconLog.ErrorMessage = "";
            objReconLog.Flag = "";
            objReconLog.StartTime = "";
            objReconLog.EndTime = "";
            objReconLog.ReconName = "";
            objReconLog.UserID = "";
            objReconLog.DateTime = "";
        }
        //EA1001

        //SA1003
        static bool ConsoleEventCallback(int eventType)
        {
            if (eventType == 2 || eventType == 6)
            {
                consoleClose();
            }
            return false;
        }

        public static void consoleClose()
        {
            string query = "";

            string filePath = Main_DIR_SharePath + "ExeRunning_Info.txt";

            File.Delete(filePath);

            if (!string.IsNullOrEmpty(strReconID))
            {

                query = "Update ARC_Recon_Log set ErrorFlag = 1, ErrorMessage = 'Application Closed', DateTime = '" + DateTime.Now.ToString() + "' where ReconID = '" + strReconID + "' and DateTime = '" + strDateTime + "' and UserID = '" + Environment.UserName + "'";

                //string query = "Update ARC_Recon_Log set ErrorFlag = 1, ErrorMessage = 'Application Closed', DateTime = '" + DateTime.Now.ToString() + "' where ID = '35'";

                SqlConnection con = new SqlConnection(conString);
                SqlCommand cmd = new SqlCommand(query, con);
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                cmd.ExecuteNonQuery();
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }

        }

        public static bool IsExeRunning(string filePath)
        {

            if (!File.Exists(filePath))
            {
                FileStream aFile = new FileStream(filePath, FileMode.Append, FileAccess.Write);
                StreamWriter sw = new StreamWriter(aFile);
                sw.Write("User Id: " + Environment.UserName);
                sw.Write(Environment.NewLine);
                sw.Write("Start Time: " + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
                sw.Write(Environment.NewLine);
                sw.Write("--------------------------------------------------");
                sw.Close();
                aFile.Close();
                return false;
            }
            else
            {
                string readText = File.ReadAllText(filePath);

                string UserName = readText.Substring(0, 18);
                UserName = UserName.Remove(0, 9);

                MessageBox.Show("Exe is already running in " + UserName + " user machine...", "ARC", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return true;
            }
        }
        //EA1003
    }
}
