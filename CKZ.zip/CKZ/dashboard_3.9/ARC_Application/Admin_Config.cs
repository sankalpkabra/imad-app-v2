﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;
using System.Security.Cryptography;
using System.IO;
using System.Collections;
using System.Text.RegularExpressions;

namespace ARC_Application
{
    public partial class Admin_Config : Form
    {
        DAccesss.Program das = new DAccesss.Program();
        Formatting_Logics obj = new Formatting_Logics();
        static string conString = ConfigurationManager.ConnectionStrings["ARC_conStr"].ConnectionString;
        static string Main_DIR_SharePath = ConfigurationManager.ConnectionStrings["Share_Path"].ToString();
        string Directory = Main_DIR_SharePath + DateTime.Now.ToString("dd-MMM-yyyy") + "_Files\\";

        SQLEncryption ecp = new SQLEncryption();
        string strAppl = "";
        string strCountr = "";
        string strPrdt = "";
        string date;
        string selectedProduct;
        string selectedcountry;
        int i;
        int j;
        List<string> DGV_FTP_lst = new List<string>();

        System.Data.DataTable dt = new System.Data.DataTable();
        //Image i1 = Image.FromFile(@"\\10.132.5.214\TempFiles\ARC Main Solutions\ARC_Latest_Solution\Images\index1.jpg");
        //Image i2 = Image.FromFile(@"\\10.132.5.214\TempFiles\ARC Main Solutions\ARC_Latest_Solution\Images\index2.jpg");
        //Image i3 = Image.FromFile(@"\\10.132.5.214\TempFiles\ARC Main Solutions\ARC_Latest_Solution\Images\index3.png");
        int Total;
        int Completed;
        string sla;
        SqlConnection con;
        SqlCommand cmd;
        SqlDataAdapter da;
        int countryID = 0;
        int HolidayID = 0;

        public Admin_Config()
        {

            if (!conString.StartsWith("Data"))
            {
                conString = ecp.Decrypt(conString);
            }
            InitializeComponent();
            refreshdata();
            Recon_ViewRecord("", "");
            //ViewRecord();
            HolidayData();
            //Date_Check();

            tabPage1.AutoScroll = true;
        }

        private void Admin_Config_Load(object sender, EventArgs e)
        {
            this.BackColor = System.Drawing.Color.White;
            con = new SqlConnection(conString);
            con.Open();
            cmd = new SqlCommand("select App_Id,App_Name from ARC_Applicationdetails", con);
            da = new SqlDataAdapter(cmd);
            dt = new System.Data.DataTable();
            da.Fill(dt);
            //Lst_Application_01.DataSource = dt;
            //Lst_Application_01.DisplayMember = "App_Name";
            //Lst_Application_01.ValueMember = "App_Id";
            if (dt.Rows.Count > 0)
            {
                foreach (DataRow item in dt.Rows)
                {
                    chklstApplication.Items.Add(item["App_Name"].ToString());
                }
            }
            con.Close();
            con.Open();
            cmd = new SqlCommand("select Country_Id,Country_name from ARC_Country_Details", con);
            da = new SqlDataAdapter(cmd);
            dt = new System.Data.DataTable();
            da.Fill(dt);
            //Lst_Countries_01.DataSource = dt;
            //Lst_Countries_01.DisplayMember = "Country_name";
            //Lst_Countries_01.ValueMember = "Country_Id";
            if (dt.Rows.Count > 0)
            {
                foreach (DataRow item in dt.Rows)
                {
                    chklstCountries.Items.Add(item["Country_name"].ToString());
                }
            }
            con.Close();
            con.Open();
            cmd = new SqlCommand("select Product_Id,Product_Name from ARC_Product_Details", con);
            da = new SqlDataAdapter(cmd);
            dt = new System.Data.DataTable();
            da.Fill(dt);
            //Lst_Prdt_01.DataSource = dt;
            //Lst_Prdt_01.DisplayMember = "Product_Name";
            //Lst_Prdt_01.ValueMember = "Product_Id";
            if (dt.Rows.Count > 0)
            {
                foreach (DataRow item in dt.Rows)
                {
                    chklstProduct.Items.Add(item["Product_Name"].ToString());
                }
            }
            con.Close();
            //Lst_Application_01.SelectedIndex = -1;
            //Lst_Countries_01.SelectedIndex = -1;
            //Lst_Prdt_01.SelectedIndex = -1;
            chklstPageAccess.Items.Add("Config Management");
            chklstPageAccess.Items.Add("Reports");
            chklstPageAccess.Items.Add("Recon Acccess");

            //Start Added on 19/04/2018
            ResetRecipientList();


            //End Added on 19/04/2018



        }



        private string Encrypt(string clearText)
        {
            try
            {
                string EncryptionKey = "MAKV2SPBNI99212";
                byte[] clearBytes = Encoding.Unicode.GetBytes(clearText);
                using (Aes encryptor = Aes.Create())
                {
                    Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
                    encryptor.Key = pdb.GetBytes(32);
                    encryptor.IV = pdb.GetBytes(16);
                    using (MemoryStream ms = new MemoryStream())
                    {
                        using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateEncryptor(), CryptoStreamMode.Write))
                        {
                            cs.Write(clearBytes, 0, clearBytes.Length);
                            cs.Close();
                        }
                        clearText = Convert.ToBase64String(ms.ToArray());
                    }
                }
                return clearText;
            }
            catch
            {
                return null;
            }
        }

        private string Decrypt(string cipherText)
        {
            try
            {
                string EncryptionKey = "MAKV2SPBNI99212";
                byte[] cipherBytes = Convert.FromBase64String(cipherText);
                using (Aes encryptor = Aes.Create())
                {
                    Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
                    encryptor.Key = pdb.GetBytes(32);
                    encryptor.IV = pdb.GetBytes(16);
                    using (MemoryStream ms = new MemoryStream())
                    {
                        using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateDecryptor(), CryptoStreamMode.Write))
                        {
                            cs.Write(cipherBytes, 0, cipherBytes.Length);
                            cs.Close();
                        }
                        cipherText = Encoding.Unicode.GetString(ms.ToArray());
                    }
                }
                return cipherText;
            }
            catch
            {
                return null;
            }
        }


        #region User Management
        private void btnAddUser_Click(object sender, EventArgs e)
        {
            try
            {
                strAppl = "";
                strCountr = "";
                strPrdt = "";
                string strselecteditems_01 = "";
                string strselecteditems_02 = "";
                string strselecteditems_03 = "";
                string lstCountry = string.Empty;
                string lstProduct = string.Empty;
                string lstApplication = string.Empty;
                if (txtUserPSID.Text.Trim() == "")
                {
                    MessageBox.Show("Please Enter the PSID..!");
                    return;
                }

                if (txtUserPSID.Text != "")
                {
                    SqlConnection con = new SqlConnection(conString);
                    con.Open();
                    SqlCommand cmdd = new SqlCommand("select [userid] from ARC_user_info where userid='" + txtUserPSID.Text + "'", con);
                    da = new SqlDataAdapter(cmdd);
                    dt = new System.Data.DataTable();
                    da.Fill(dt);
                    con.Close();
                    bool Flag = false;

                    if (dt.Rows.Count > 0)
                    {
                        Flag = true;
                        MessageBox.Show("PSID Already Exists.. !");
                        return;
                    }


                    if (txtUserName.Text.Trim() == "")
                    {
                        MessageBox.Show("Please Enter the User_Name..!");
                        return;
                    }
                    if (txtLineManager.Text.Trim() == "")
                    {
                        MessageBox.Show("Please Enter the Line Manager PSID..!");
                        return;
                    }
                    if (cmbAccessType.SelectedIndex < 1)
                    {
                        MessageBox.Show("Please select the Access Type..!");
                        return;
                    }

                    if (cmbAccessType.SelectedItem == null)
                    {
                        MessageBox.Show("Please select only one item in listbox");
                        return;
                    }

                    if (chklstProduct.CheckedItems.Count > 0)
                    {
                        foreach (object chkProd in chklstProduct.CheckedItems)
                        {
                            con.Open();
                            cmd = new SqlCommand("select Product_Id from dbo.ARC_Product_Details where Product_Name='" + chkProd + "'", con);
                            da = new SqlDataAdapter(cmd);
                            dt = new System.Data.DataTable();
                            da.Fill(dt);
                            string Prdt_ID = dt.Rows[0].ItemArray[0].ToString();
                            con.Close();
                            lstProduct = lstProduct + "," + Prdt_ID;
                        }
                    }
                    else
                    {
                        MessageBox.Show("Please select atleast one item in Product");
                        return;
                    }
                    if (chklstCountries.CheckedItems.Count > 0)
                    {
                        foreach (object chkCountry in chklstCountries.CheckedItems)
                        {
                            con.Open();
                            cmd = new SqlCommand("select Country_Id from ARC_Country_Details where Country_name='" + chkCountry + "'", con);
                            da = new SqlDataAdapter(cmd);
                            dt = new System.Data.DataTable();
                            da.Fill(dt);
                            string Ctry_ID = dt.Rows[0].ItemArray[0].ToString();
                            con.Close();
                            lstCountry = lstCountry + "," + Ctry_ID;
                        }
                    }
                    else
                    {
                        MessageBox.Show("Please select atleast one item in Country");
                        return;
                    }
                    if (chklstApplication.CheckedItems.Count > 0)
                    {
                        foreach (object chkApp in chklstApplication.CheckedItems)
                        {
                            con.Open();
                            cmd = new SqlCommand("select App_Id from ARC_Applicationdetails where App_Name='" + chkApp + "'", con);
                            da = new SqlDataAdapter(cmd);
                            dt = new System.Data.DataTable();
                            da.Fill(dt);
                            string App_ID = dt.Rows[0].ItemArray[0].ToString();
                            con.Close();
                            lstApplication = lstApplication + "," + App_ID;
                        }
                    }
                    else
                    {
                        MessageBox.Show("Please select atleast one item in Application");
                        return;
                    }
                    strPrdt = lstProduct.TrimStart(',');
                    strCountr = lstCountry.TrimStart(',');
                    strAppl = lstApplication.TrimStart(',');


                    //if (chklstProduct.CheckedItems.Count == 1)
                    //{
                    //    for (int i = 0; i < chklstProduct.Items.Count; i++)
                    //    {
                    //        if (chklstProduct.SelectedItem.ToString() == chklstProduct.Items[i].ToString())
                    //        {
                    //            strselecteditems_02 = chklstProduct.Items[i].ToString();
                    //            con.Open();
                    //            cmd = new SqlCommand("select Product_Id from dbo.ARC_Product_Details where Product_Name='" + strselecteditems_02 + "'", con);
                    //            da = new SqlDataAdapter(cmd);
                    //            dt = new System.Data.DataTable();
                    //            da.Fill(dt);
                    //            string Prdt_ID = dt.Rows[0].ItemArray[0].ToString();
                    //            con.Close();
                    //            strPrdt = Prdt_ID;
                    //            i = chklstProduct.Items.Count;
                    //        }
                    //    }
                    //}
                    //else
                    //{
                    //    MessageBox.Show("Please select only one item in Product");
                    //    return;
                    //}
                    //if (chklstApplication.CheckedItems.Count == 1)
                    //{
                    //    for (int i = 0; i < chklstApplication.Items.Count; i++)
                    //    {
                    //        if (chklstApplication.SelectedItem.ToString() == chklstApplication.Items[i].ToString())
                    //        {
                    //            strselecteditems_01 = chklstApplication.Items[i].ToString();
                    //            con.Open();
                    //            SqlCommand cmd = new SqlCommand("select App_Id from ARC_Applicationdetails where App_Name='" + strselecteditems_01 + "'", con);
                    //            da = new SqlDataAdapter(cmd);
                    //            dt = new System.Data.DataTable();
                    //            da.Fill(dt);
                    //            string Applic_ID = dt.Rows[0].ItemArray[0].ToString();
                    //            con.Close();
                    //            i = chklstApplication.Items.Count;
                    //            strAppl = Applic_ID;
                    //        }
                    //    }
                    //}
                    //else
                    //{
                    //    MessageBox.Show("Please select only one item in Application");
                    //    return;
                    //}

                    //if (chklstCountries.CheckedItems.Count == 1)
                    //{
                    //    for (int i = 0; i < chklstCountries.Items.Count; i++)
                    //    {
                    //        if (chklstCountries.SelectedItem.ToString() == chklstCountries.Items[i].ToString())
                    //        {
                    //            strselecteditems_03 = chklstCountries.Items[i].ToString();
                    //            con.Open();
                    //            cmd = new SqlCommand("select Country_Id from ARC_Country_Details where Country_name='" + strselecteditems_03 + "'", con);
                    //            da = new SqlDataAdapter(cmd);
                    //            dt = new System.Data.DataTable();
                    //            da.Fill(dt);
                    //            string Contry_ID = dt.Rows[0].ItemArray[0].ToString();
                    //            con.Close();
                    //            strCountr = Contry_ID;
                    //            i = chklstCountries.Items.Count;
                    //        }
                    //    }
                    //}
                    //else
                    //{
                    //    MessageBox.Show("Please select only one item in Country");
                    //    return;
                    //}

                    string strPageAccess = "";
                    if (chklstPageAccess.CheckedItems.Count == 1)
                    {
                        for (int i = 0; i < chklstPageAccess.Items.Count; i++)
                        {
                            if (chklstPageAccess.SelectedItem.ToString() == chklstPageAccess.Items[i].ToString())
                            {
                                strselecteditems_03 = chklstPageAccess.Items[i].ToString();
                                strPageAccess = strselecteditems_03;
                                i = chklstPageAccess.Items.Count;
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("Please select only one item in Page Access");
                        return;
                    }

                    System.Data.DataTable dt_grid = new System.Data.DataTable();
                    dt_grid.Columns.Add("User_Id");
                    dt_grid.Columns.Add("Products");
                    dt_grid.Columns.Add("Countrys");
                    dt_grid.Columns.Add("Application");

                    for (int i = 0; i < 1; i++)
                    {
                        dt_grid.Rows.Add();
                        dt_grid.Rows[i][0] = txtUserPSID.Text;
                        dt_grid.Rows[i][1] = strselecteditems_01;
                        dt_grid.Rows[i][2] = strselecteditems_02;
                        dt_grid.Rows[i][3] = strselecteditems_03;
                    }
                    dataGridView.DataSource = dt_grid;
                    dataGridView.Visible = true;
                    //strAppl = strAppl.Substring(1, strAppl.ToString().Length - 1);
                    //strCountr = strCountr.Substring(1, strCountr.ToString().Length - 1);
                    //strPrdt = strPrdt.Substring(1, strPrdt.ToString().Length - 1);
                    string UserID = txtUserPSID.Text;
                    string Psd = "Arc@123";
                    string role = cmbAccessType.SelectedItem.ToString().Trim();

                    string LUserId = txtLineManager.Text;
                    DateTime date = DateTime.Today;
                    DateTime date1 = DateTime.Today.AddDays(90);
                    con.Open();
                    cmd = new SqlCommand("insert into ARC_User_Info(UserID,Password,UserRole,StartDate,EndDate) values(@UserID,@Password,@UserRole,@StartDate,@EndDate)", con);
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@UserID", UserID);
                    cmd.Parameters.AddWithValue("@Password", Encrypt(Psd.Trim()));
                    cmd.Parameters.AddWithValue("@UserRole", role);
                    cmd.Parameters.AddWithValue("@StartDate", date);
                    cmd.Parameters.AddWithValue("@EndDate", date1);
                    cmd.ExecuteNonQuery();
                    con.Close();

                    int Role_Details_Id = 1;
                    con.Open();
                    cmd = new SqlCommand("insert into ARC_User_Details(User_Id,User_Name,Manager_Id,Role_Details_Id,App_id,Country_Id,Product_Id,Page_Access) values(@User_Id,@User_Name,@Manager_Id,@Role_Details_Id,@App_id,@Country_Id,@Product_Id,@Page_Access)", con);
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@User_Id", UserID);
                    cmd.Parameters.AddWithValue("@User_Name", txtUserName.Text);
                    cmd.Parameters.AddWithValue("@Manager_Id", LUserId);
                    cmd.Parameters.AddWithValue("@Role_Details_Id", Role_Details_Id);
                    cmd.Parameters.AddWithValue("@App_id", strAppl);
                    cmd.Parameters.AddWithValue("@Country_Id", strCountr);
                    cmd.Parameters.AddWithValue("@Product_Id", strPrdt);
                    cmd.Parameters.AddWithValue("@Page_Access", strPageAccess);
                    cmd.ExecuteNonQuery();
                    con.Close();

                    con.Open();
                    cmd = new SqlCommand("insert into ARC_User_Access_Details(User_Id,App_id,Country_Id,Page_Access) values(@User_Id,@App_id,@Country_Id,@Page_Access)", con);
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@User_Id", UserID);
                    cmd.Parameters.AddWithValue("@App_id", strAppl);
                    cmd.Parameters.AddWithValue("@Country_Id", strCountr);
                    cmd.Parameters.AddWithValue("@Page_Access", strPageAccess);
                    cmd.ExecuteNonQuery();
                    con.Close();

                    con.Open();
                    SqlCommand com = new SqlCommand("select Password from dbo.ARC_User_Info where UserID=@UserID", con);
                    com.CommandType = CommandType.Text;
                    com.Parameters.AddWithValue("@UserID", UserID);
                    SqlDataReader dr = com.ExecuteReader();
                    while (dr.Read())
                    {
                        if (dr.HasRows == true)
                        {
                            string Password = (string)dr["Password"];
                            Psd = Decrypt(Password.Trim());
                            Microsoft.Office.Interop.Outlook.Application app = new Microsoft.Office.Interop.Outlook.Application();
                            Microsoft.Office.Interop.Outlook.MailItem mailItem = app.CreateItem(Microsoft.Office.Interop.Outlook.OlItemType.olMailItem);
                            mailItem.Subject = "SCB: Password Reset";
                            mailItem.To = UserID;
                            mailItem.Body = "Dear User.\n \n Your Login Password For ARC Applications is " + Psd + "";
                            mailItem.Importance = Microsoft.Office.Interop.Outlook.OlImportance.olImportanceHigh;
                            //mailItem.Send();
                        }
                    }
                    con.Close();
                    //Loading.Visible = false;
                    SearchFunction();
                    MessageBox.Show("User Added Successfully.. !");
                    //Clear_Function();

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        public void Clear_Function()
        {
            txtUserPSID.Text = "";
            txtUserName.Text = "";
            cmbAccessType.Text = "";
            txtLineManager.Text = "";
            while (chklstProduct.CheckedIndices.Count > 0)
            {
                chklstProduct.SetItemChecked(chklstProduct.CheckedIndices[0], false);
            }
            while (chklstApplication.CheckedIndices.Count > 0)
            {
                chklstApplication.SetItemChecked(chklstApplication.CheckedIndices[0], false);
            }
            while (chklstCountries.CheckedIndices.Count > 0)
            {
                chklstCountries.SetItemChecked(chklstCountries.CheckedIndices[0], false);
            }
            while (chklstPageAccess.CheckedIndices.Count > 0)
            {
                chklstPageAccess.SetItemChecked(chklstPageAccess.CheckedIndices[0], false);
            }
            chklstProduct.SelectedItems.Clear();
            chklstApplication.SelectedItems.Clear();
            chklstCountries.SelectedItems.Clear();
            chklstPageAccess.SelectedItems.Clear();
            dataGridView.Visible = false;
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            Clear_Function();
        }

        private void btnDeleteUser_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(conString);
                if (txtUserPSID.Text.Trim() != "")
                {
                    con.Open();
                    SqlCommand com = new SqlCommand("select Manager_Id from dbo.ARC_User_Details where User_ID='" + txtUserPSID.Text + "'", con);
                    com.CommandType = CommandType.Text;
                    com.Parameters.AddWithValue("@User_ID", txtUserPSID.Text);
                    SqlDataReader dr = com.ExecuteReader();
                    while (dr.Read())
                    {
                        if (dr.HasRows == true)
                        {
                            int Manager = Convert.ToInt32(dr["Manager_Id"].ToString());
                            // string Psd = ecp.Decrypt(Password.Trim());
                            Microsoft.Office.Interop.Outlook.Application app = new Microsoft.Office.Interop.Outlook.Application();
                            Microsoft.Office.Interop.Outlook.MailItem mailItem = app.CreateItem(Microsoft.Office.Interop.Outlook.OlItemType.olMailItem);
                            mailItem.Subject = "SCB: Removed Allocation";
                            mailItem.To = Manager.ToString();
                            mailItem.Body = "Dear Admin.\n \n We had Removed All the Access For ARC Aplications For the Particular UserID:- " + txtUserPSID.Text + "";
                            mailItem.Importance = Microsoft.Office.Interop.Outlook.OlImportance.olImportanceHigh;
                            //mailItem.Send();
                        }
                    }

                    con.Close();
                    con.Open();
                    cmd = new SqlCommand("Delete from ARC_User_Details where User_Id='" + txtUserPSID.Text + "'", con);
                    cmd.ExecuteNonQuery();
                    con.Close();

                    con.Open();
                    cmd = new SqlCommand("Delete from ARC_User_Info where UserID='" + txtUserPSID.Text + "'", con);
                    cmd.ExecuteNonQuery();
                    con.Close();

                    con.Open();
                    cmd = new SqlCommand("Delete from ARC_User_Access_Details where User_Id='" + txtUserPSID.Text + "'", con);
                    cmd.ExecuteNonQuery();
                    con.Close();

                    MessageBox.Show("User Deleted Successfully...!");
                    Clear_Function();
                }
                else
                {
                    MessageBox.Show("Please Enter the User_Id To remove Details of the User...!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            SearchFunction();
        }
        public void SearchFunction()
        {
            try
            {
                SqlConnection con = new SqlConnection(conString);
                if (txtUserPSID.Text.Trim() != "")
                {
                    string strPSID = txtUserPSID.Text.ToString();
                    //string strquery = "select a.user_id,a.user_name,a.manager_id,a.product_id,a.app_id,a.country_id,a.page_access,b.userrole from ARC_User_Details a,ARC_User_Info b where b.userid=a.user_id and a.user_id='" + txtUserPSID.Text + "'; select Product_Id,Product_name from dbo.ARC_Product_Details; select * from ARC_User_Access_Details a,ARC_Country_Details b,ARC_Applicationdetails d where a.Country_Id=b.country_id and a.app_id=d.app_id  and user_id='" + txtUserPSID.Text + "' order by b.Country_Name,d.app_name,a.Page_Access; select Country_Id,	Country_Name from ARC_Country_Details;select App_ID,App_Name from ARC_Applicationdetails;";
                    string strquery = "select a.user_id,a.user_name,a.manager_id,a.product_id,a.app_id,a.country_id,a.page_access,b.userrole from ARC_User_Details a,ARC_User_Info b where b.userid=a.user_id and a.user_id='" + txtUserPSID.Text + "'; select Product_Id,Product_name from dbo.ARC_Product_Details;select Country_Id,	Country_Name from ARC_Country_Details;select App_ID,App_Name from ARC_Applicationdetails;";
                    con.Close();
                    con.Open();
                    SqlDataAdapter da = new SqlDataAdapter(strquery, con);
                    DataSet ds = new DataSet();
                    da.Fill(ds);
                    con.Close();
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        Clear_Function();

                        string username = ds.Tables[0].Rows[0]["user_name"].ToString();
                        string managerid = ds.Tables[0].Rows[0]["manager_id"].ToString();
                        string userrole = ds.Tables[0].Rows[0]["userrole"].ToString();
                        string country = ds.Tables[0].Rows[0]["country_id"].ToString();
                        string product = ds.Tables[0].Rows[0]["product_id"].ToString();
                        string appli = ds.Tables[0].Rows[0]["app_id"].ToString();
                        string pageaccess = ds.Tables[0].Rows[0]["page_access"].ToString();
                        string productname = "";

                        txtUserPSID.Text = strPSID;
                        txtUserName.Text = username;
                        cmbAccessType.SelectedText = userrole;
                        txtLineManager.Text = managerid;

                        string[] produsp = product.Split(',');
                        string[] Pageaccessp = pageaccess.Split(',');

                        //for (int i = 0; i < produsp.Length; i++)
                        //{
                        //    string prodid = produsp[i].ToString();
                        //    if (prodid.Trim() != "")
                        //    {
                        //        ds.Tables[1].DefaultView.RowFilter = "Product_Id='" + prodid + "'";
                        //        DataView dvproduct = ds.Tables[1].DefaultView;
                        //        if (dvproduct.Count > 0)
                        //        {
                        //            productname = dvproduct[0]["product_name"].ToString();

                        //            for (int m = 0; m < chklstProduct.Items.Count; m++)
                        //            {
                        //                if (productname.Trim().ToUpper() == chklstProduct.Items[m].ToString().Trim().ToUpper())
                        //                {
                        //                    chklstProduct.SetItemCheckState(m, CheckState.Checked);
                        //                    chklstProduct.SetSelected(m, true);
                        //                    m = chklstProduct.Items.Count;
                        //                }
                        //            }
                        //        }
                        //    }
                        //}

                        for (int i = 0; i < Pageaccessp.Length; i++)
                        {
                            string pagename = Pageaccessp[i].ToString();
                            if (pagename.Trim() != "")
                            {
                                for (int m = 0; m < chklstPageAccess.Items.Count; m++)
                                {
                                    if (pagename.Trim().ToUpper() == chklstPageAccess.Items[m].ToString().Trim().ToUpper())
                                    {
                                        chklstPageAccess.SetItemCheckState(m, CheckState.Checked);
                                        chklstPageAccess.SetSelected(m, true);
                                        m = chklstCountries.Items.Count;
                                    }
                                }
                            }
                        }



                        System.Data.DataTable dt_grid = new System.Data.DataTable();
                        dt_grid.Columns.Add("User_Id");
                        dt_grid.Columns.Add("Products");
                        dt_grid.Columns.Add("Application");
                        dt_grid.Columns.Add("Countries");

                        string[] arrAppID = appli.TrimStart(',').TrimEnd(',').Split(',');
                        string[] arrCountryID = country.TrimStart(',').TrimEnd(',').Split(',');
                        string[] arrProdID = product.TrimStart(',').TrimEnd(',').Split(',');



                        List<string> lstCountryName = new List<string>();
                        List<string> lstProductName = new List<string>();
                        List<string> lstApplicationName = new List<string>();

                        foreach (string strProduct in arrProdID)
                        {
                            string productName = ds.Tables[1].AsEnumerable()
                                .Where(m => m.Field<Int64>("Product_Id") == Convert.ToInt64(strProduct))
                                .Select(m => new { ProductName = m.Field<string>("Product_Name") }).FirstOrDefault().ProductName;
                            lstProductName.Add(productName);
                        }

                        foreach (string strCountry in arrCountryID)
                        {
                            string countryName = ds.Tables[2].AsEnumerable()
                                                .Where(m => m.Field<Int64>("Country_Id") == Convert.ToInt64(strCountry))
                                                .Select(m => new { country = m.Field<string>("Country_Name") }).FirstOrDefault().country;
                            lstCountryName.Add(countryName);

                        }

                        foreach (string strApplication in arrAppID)
                        {
                            string applicationName = ds.Tables[3].AsEnumerable()
                                .Where(m => m.Field<int>("App_Id") == Convert.ToInt32(strApplication))
                                .Select(m => new { ApplicationName = m.Field<string>("App_Name") }).FirstOrDefault().ApplicationName;
                            lstApplicationName.Add(applicationName);
                        }

                        dt_grid.Rows.Add(txtUserPSID.Text, string.Join(",", lstProductName),  string.Join(",", lstApplicationName),string.Join(",", lstCountryName));



                        for (int m = 0; m < chklstProduct.Items.Count; m++)
                        {
                            if (lstProductName.Select(x => x.ToUpper()).Contains(chklstProduct.Items[m].ToString().Trim().ToUpper()))
                            {
                                chklstProduct.SetItemCheckState(m, CheckState.Checked);
                                chklstProduct.SetSelected(m, true);

                            }
                        }
                        for (int m = 0; m < chklstCountries.Items.Count; m++)
                        {
                            if (lstCountryName.Select(x => x.ToUpper()).Contains(chklstCountries.Items[m].ToString().Trim().ToUpper()))
                            {
                                chklstCountries.SetItemCheckState(m, CheckState.Checked);
                                chklstCountries.SetSelected(m, true);

                            }
                        }
                        for (int m = 0; m < chklstApplication.Items.Count; m++)
                        {
                            if (lstApplicationName.Select(x => x.ToUpper()).Contains(chklstApplication.Items[m].ToString().Trim().ToUpper()))
                            {
                                chklstApplication.SetItemCheckState(m, CheckState.Checked);
                                chklstApplication.SetSelected(m, true);

                            }
                        }



                        //dt_grid.Columns.Add("Page_Access");

                        // for (int j = 0; j < ds.Tables[2].Rows.Count; j++)
                        // {

                        //     string appname = ds.Tables[2].Rows[j]["app_name"].ToString();
                        //     //for (int m = 0; m < chklstApplication.Items.Count; m++)
                        //     //{
                        //     //    if (appname.Trim().ToUpper() == chklstApplication.Items[m].ToString().Trim().ToUpper())
                        //     //    {
                        //     //        chklstApplication.SetItemCheckState(m, CheckState.Checked);
                        //     //        chklstApplication.SetSelected(m, true);
                        //     //        m = chklstApplication.Items.Count;
                        //     //    }
                        //     //}

                        //     string couname = ds.Tables[2].Rows[j]["Country_name"].ToString();
                        //     //for (int m = 0; m < chklstCountries.Items.Count; m++)
                        //     //{
                        //     //    if (couname.Trim().ToUpper() == chklstCountries.Items[m].ToString().Trim().ToUpper())
                        //     //    {
                        //     //        chklstCountries.SetItemCheckState(m, CheckState.Checked);
                        //     //        chklstCountries.SetSelected(m, true);
                        //     //        m = chklstCountries.Items.Count;
                        //     //    }
                        //     //}

                        // //    dt_grid.Rows.Add();
                        // //    dt_grid.Rows[j][0] = txtUserPSID.Text;
                        // //    dt_grid.Rows[j][1] = productname;
                        // //    dt_grid.Rows[j][2] = couname;
                        // //    dt_grid.Rows[j][3] = appname;
                        // //    // dt_grid.Rows[j][4] = pagename;
                        //}

                        dataGridView.DataSource = dt_grid;
                        dataGridView.Visible = true;
                    }
                    else
                    {
                        MessageBox.Show("PSID Not Exists ...!");
                    }
                }
                else
                {
                    MessageBox.Show("Please Enter the PSID...!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void btnEditUser_Click(object sender, EventArgs e)
        {
            try
            {
                strAppl = "";
                strCountr = "";
                strPrdt = "";
                string strselecteditems_01 = "";
                string strselecteditems_02 = "";
                string strselecteditems_03 = "";
                string lstCountry = string.Empty;
                string lstProduct = string.Empty;
                string lstApplication = string.Empty;
                if (txtUserPSID.Text.Trim() == "")
                {
                    MessageBox.Show("Please Enter the PSID..!");
                    return;
                }

                if (txtUserPSID.Text != "")
                {
                    DataSet ds = new DataSet();
                    SqlConnection con = new SqlConnection(conString);
                    con.Open();
                    SqlCommand cmdd = new SqlCommand("select * from ARC_user_info b where userid='" + txtUserPSID.Text + "' ;select * from ARC_User_Details where user_id='" + txtUserPSID.Text + "'", con);
                    da = new SqlDataAdapter(cmdd);
                    dt = new System.Data.DataTable();
                    da.Fill(ds);
                    con.Close();
                    bool Flag = false;

                    if (ds.Tables[0].Rows.Count == 0)
                    {
                        Flag = true;
                        MessageBox.Show("PSID Not Exists ...!");
                        return;
                    }


                    if (txtUserName.Text.Trim() == "")
                    {
                        MessageBox.Show("Please Enter the User_Name..!");
                        return;
                    }
                    if (txtLineManager.Text.Trim() == "")
                    {
                        MessageBox.Show("Please Enter the Line Manager PSID..!");
                        return;
                    }

                    if (cmbAccessType.Text.Trim() == "" && cmbAccessType.Text.ToString().Trim().ToUpper() == "NULL")
                    {
                        MessageBox.Show("Please select the Access Type..!");
                        return;
                    }

                    if (chklstProduct.CheckedItems.Count > 0)
                    {
                        foreach (object chkProd in chklstProduct.CheckedItems)
                        {
                            con.Open();
                            cmd = new SqlCommand("select Product_Id from dbo.ARC_Product_Details where Product_Name='" + chkProd + "'", con);
                            da = new SqlDataAdapter(cmd);
                            dt = new System.Data.DataTable();
                            da.Fill(dt);
                            string Prdt_ID = dt.Rows[0].ItemArray[0].ToString();
                            con.Close();
                            lstProduct = lstProduct + "," + Prdt_ID;
                        }
                    }
                    else
                    {
                        MessageBox.Show("Please select atleast one item in Product");
                        return;
                    }
                    if (chklstCountries.CheckedItems.Count > 0)
                    {
                        foreach (object chkCountry in chklstCountries.CheckedItems)
                        {
                            con.Open();
                            cmd = new SqlCommand("select Country_Id from ARC_Country_Details where Country_name='" + chkCountry + "'", con);
                            da = new SqlDataAdapter(cmd);
                            dt = new System.Data.DataTable();
                            da.Fill(dt);
                            string Ctry_ID = dt.Rows[0].ItemArray[0].ToString();
                            con.Close();
                            lstCountry = lstCountry + "," + Ctry_ID;
                        }
                    }
                    else
                    {
                        MessageBox.Show("Please select atleast one item in Country");
                        return;
                    }
                    if (chklstApplication.CheckedItems.Count > 0)
                    {
                        foreach (object chkApp in chklstApplication.CheckedItems)
                        {
                            con.Open();
                            cmd = new SqlCommand("select App_Id from ARC_Applicationdetails where App_Name='" + chkApp + "'", con);
                            da = new SqlDataAdapter(cmd);
                            dt = new System.Data.DataTable();
                            da.Fill(dt);
                            string App_ID = dt.Rows[0].ItemArray[0].ToString();
                            con.Close();
                            lstApplication = lstApplication + "," + App_ID;
                        }
                    }
                    else
                    {
                        MessageBox.Show("Please select atleast one item in Application");
                        return;
                    }
                    strPrdt = lstProduct.TrimStart(',');
                    strCountr = lstCountry.TrimStart(',');
                    strAppl = lstApplication.TrimStart(',');

                    //if (chklstProduct.CheckedItems.Count == 1)
                    //{
                    //    foreach (var row in chklstProduct.CheckedItems)
                    //    {
                    //        strselecteditems_02 = row.ToString();
                    //        con.Open();
                    //        cmd = new SqlCommand("select Product_Id from dbo.ARC_Product_Details where Product_Name='" + strselecteditems_02 + "'", con);
                    //        da = new SqlDataAdapter(cmd);
                    //        dt = new System.Data.DataTable();
                    //        da.Fill(dt);
                    //        string Prdt_ID = dt.Rows[0].ItemArray[0].ToString();
                    //        con.Close();
                    //        strPrdt = Prdt_ID;
                    //    }
                    //}
                    //else
                    //{
                    //    MessageBox.Show("Please select only one item in Product");
                    //    return;
                    //}

                    //if (chklstApplication.CheckedItems.Count == 1)
                    //{
                    //    foreach (var row in chklstApplication.CheckedItems)
                    //    {
                    //        strselecteditems_01 = row.ToString();
                    //        con.Open();
                    //        SqlCommand cmd = new SqlCommand("select App_Id from ARC_Applicationdetails where App_Name='" + strselecteditems_01 + "'", con);
                    //        da = new SqlDataAdapter(cmd);
                    //        dt = new System.Data.DataTable();
                    //        da.Fill(dt);
                    //        string Applic_ID = dt.Rows[0].ItemArray[0].ToString();
                    //        con.Close();
                    //        strAppl = Applic_ID;
                    //    }
                    //}
                    //else
                    //{
                    //    MessageBox.Show("Please select the Application");
                    //    return;
                    //}

                    //if (chklstCountries.CheckedItems.Count == 1)
                    //{
                    //    foreach (var row in chklstCountries.CheckedItems)
                    //    {
                    //        strselecteditems_03 = row.ToString();
                    //        con.Open();
                    //        cmd = new SqlCommand("select Country_Id from ARC_Country_Details where Country_name='" + strselecteditems_03 + "'", con);
                    //        da = new SqlDataAdapter(cmd);
                    //        dt = new System.Data.DataTable();
                    //        da.Fill(dt);
                    //        string Contry_ID = dt.Rows[0].ItemArray[0].ToString();
                    //        con.Close();
                    //        strCountr = Contry_ID;
                    //    }
                    //}
                    //else
                    //{
                    //    MessageBox.Show("Please select the Country");
                    //    return;
                    //}
                    string strPageAccess = "";
                    if (chklstPageAccess.CheckedItems.Count > 0)
                    {
                        foreach (var row in chklstPageAccess.CheckedItems)
                        {
                            strselecteditems_03 = row.ToString();
                            if (strPageAccess == "")
                            {
                                strPageAccess = strselecteditems_03;
                            }
                            else
                            {
                                strPageAccess = strPageAccess + "," + strselecteditems_03;
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("Please select only one item in Page Access");
                        return;
                    }

                    ds.Tables[1].DefaultView.RowFilter = "Product_Id='" + strPrdt + "' and Country_Id='" + strCountr + "' and App_id='" + strAppl + "' and  Page_Access='" + strPageAccess + "'";
                    DataView dvcheck = ds.Tables[1].DefaultView;
                    if (dvcheck.Count > 0)
                    {
                        MessageBox.Show("User already having access ...!");
                        return;
                    }

                    string UserID = txtUserPSID.Text;

                    con.Open();
                    cmd = new SqlCommand("insert into ARC_User_Access_Details(User_Id,App_id,Country_Id,Page_Access) values(@User_Id,@App_id,@Country_Id,@Page_Access)", con);
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@User_Id", UserID);
                    cmd.Parameters.AddWithValue("@App_id", strAppl);
                    cmd.Parameters.AddWithValue("@Country_Id", strCountr);
                    cmd.Parameters.AddWithValue("@Page_Access", strPageAccess);
                    cmd.ExecuteNonQuery();
                    con.Close();

                    //Hashtable hatcountry = new Hashtable();
                    //Hashtable hatapp = new Hashtable();
                    //Hashtable hatpage = new Hashtable();

                    //hatapp.Add(strAppl, strAppl);
                    //hatpage.Add(strPageAccess, strPageAccess);
                    //hatcountry.Add(strCountr, strCountr);

                    //for (int d = 0; d < ds.Tables[1].Rows.Count; d++)
                    //{
                    //    string strappdet = ds.Tables[1].Rows[i]["App_id"].ToString();
                    //    string strcountdet = ds.Tables[1].Rows[i]["Country_Id"].ToString();
                    //    string strpagedet = ds.Tables[1].Rows[i]["Page_Access"].ToString();

                    //    if (!hatcountry.Contains(strcountdet))
                    //    {
                    //        hatcountry.Add(strcountdet, strcountdet);
                    //        strCountr = strCountr + "," + strcountdet;
                    //    }

                    //    if (!hatapp.Contains(strappdet))
                    //    {
                    //        hatapp.Add(strappdet, strappdet);
                    //        strAppl = strAppl + "," + strappdet;
                    //    }

                    //    if (!hatpage.Contains(strpagedet))
                    //    {
                    //        hatpage.Add(strpagedet, strpagedet);
                    //        strPageAccess = strPageAccess + "," + strpagedet;
                    //    }
                    //}

                    string Psd = "Arc@123";
                    string role = cmbAccessType.Text.ToString().Trim();

                    string LUserId = txtLineManager.Text;
                    DateTime date = DateTime.Today;
                    DateTime date1 = DateTime.Today.AddDays(90);

                    con.Open();
                    cmd = new SqlCommand("update ARC_User_Info set userrole=@UserRole,StartDate=@StartDate,EndDate=@EndDate where UserID=@UserID", con);
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@UserID", UserID);
                    //cmd.Parameters.AddWithValue("@Password", Encrypt(Psd.Trim()));
                    cmd.Parameters.AddWithValue("@UserRole", role);
                    cmd.Parameters.AddWithValue("@StartDate", date);
                    cmd.Parameters.AddWithValue("@EndDate", date1);
                    cmd.ExecuteNonQuery();
                    con.Close();
                    int Role_Details_Id = 1;

                    con.Open();
                    cmd = new SqlCommand("update ARC_User_Details set User_Name=@User_Name,Manager_Id=@Manager_Id,Role_Details_Id=@Role_Details_Id,App_id=@App_id,Country_Id=@Country_Id,Product_Id=@Product_Id,Page_Access=@Page_Access where User_Id=@User_Id", con);
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@User_Id", UserID);
                    cmd.Parameters.AddWithValue("@User_Name", txtUserName.Text);
                    cmd.Parameters.AddWithValue("@Manager_Id", LUserId);
                    cmd.Parameters.AddWithValue("@Role_Details_Id", Role_Details_Id);
                    cmd.Parameters.AddWithValue("@App_id", strAppl);
                    cmd.Parameters.AddWithValue("@Country_Id", strCountr);
                    cmd.Parameters.AddWithValue("@Product_Id", strPrdt);
                    cmd.Parameters.AddWithValue("@Page_Access", strPageAccess);
                    cmd.ExecuteNonQuery();
                    con.Close();

                    //con.Open();
                    //SqlCommand com = new SqlCommand("select Password from dbo.ARC_User_Info where UserID=@UserID", con);
                    //com.CommandType = CommandType.Text;
                    //com.Parameters.AddWithValue("@UserID", UserID);
                    //SqlDataReader dr = com.ExecuteReader();
                    //while (dr.Read())
                    //{
                    //    if (dr.HasRows == true)
                    //    {
                    //        string Password = (string)dr["Password"];
                    //        Psd = Decrypt(Password.Trim());
                    //        Microsoft.Office.Interop.Outlook.Application app = new Microsoft.Office.Interop.Outlook.Application();
                    //        Microsoft.Office.Interop.Outlook.MailItem mailItem = app.CreateItem(Microsoft.Office.Interop.Outlook.OlItemType.olMailItem);
                    //        mailItem.Subject = "SCB: Password Reset";
                    //        mailItem.To = UserID;
                    //        mailItem.Body = "Dear User.\n \n Your Login Password For ARC Applications is " + Psd + "";
                    //        mailItem.Importance = Microsoft.Office.Interop.Outlook.OlImportance.olImportanceHigh;
                    //        mailItem.Send();
                    //    }
                    //}
                    //con.Close();

                    SearchFunction();
                    MessageBox.Show("User Updated Successfully.. !");
                    //Clear_Function();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
        #endregion

        #region Holiday
        public void HolidayData()
        {
            System.Data.DataTable dt_Final = new System.Data.DataTable();
            dt_Final.Columns.Add("Country_Id");
            dt_Final.Columns.Add("Country_Name");
            dt_Final.Rows.Add("0", "--SELECT LIST--");
            SqlConnection con = new SqlConnection(conString);
            con.Open();
            SqlCommand cmd = new SqlCommand("ARC_SP_GetCountries", con);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            System.Data.DataTable dt = new System.Data.DataTable();
            sda.Fill(dt);

            foreach (DataRow d in dt.Rows)
            {
                dt_Final.ImportRow(d);
            }
            cmb_Holiday.ValueMember = "Country_Id";
            cmb_Holiday.DisplayMember = "Country_Name";
            cmb_Holiday.DataSource = dt_Final;


            con.Close();

        }

        private void btn_ViewCalendar_Click(object sender, EventArgs e)
        {
            try
            {
                countryID = cmb_Holiday.SelectedIndex;
                string countryName = this.cmb_Holiday.GetItemText(this.cmb_Holiday.SelectedItem);

                SqlConnection con = new SqlConnection(conString);
                if (countryID != 0)
                {
                    con.Open();
                    System.Data.DataTable dt_Cntry = new System.Data.DataTable();

                    SqlCommand com = new SqlCommand("select Holiday_ID, Holiday_Date, Holiday_Reason from ARC_Holiday_Master where Country_Id ='" + countryID + "'", con);

                    SqlDataAdapter da = new SqlDataAdapter(com);
                    da.Fill(dt_Cntry);

                    DGV_Holiday.DataSource = dt_Cntry;
                    DGV_Holiday.Columns[0].Visible = false;
                    con.Close();
                    DGV_Holiday.AllowUserToAddRows = false;
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        //Display Data in DataGridView  
        private void DisplayData()
        {
            try
            {
                SqlConnection con = new SqlConnection(conString);

                con.Open();
                System.Data.DataTable dt_Cntry = new System.Data.DataTable();

                SqlCommand com = new SqlCommand("select Holiday_ID, Holiday_Date, Holiday_Reason from ARC_Holiday_Master", con);

                SqlDataAdapter da = new SqlDataAdapter(com);
                da.Fill(dt_Cntry);

                //dt_Cntry.Columns.RemoveAt(0);
                DGV_Holiday.Columns[0].Visible = false;

                DGV_Holiday.DataSource = dt_Cntry;
                con.Close();
                DGV_Holiday.AllowUserToAddRows = false;

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        //Clear Data  
        private void ClearData()
        {
            cmb_Holiday.Text = "";
            dtPicker_From.Text = "";
            txt_HolidayReson.Text = "";
            cmb_Holiday.SelectedIndex = 0;
        }

        //Update Record  
        private void btn_UpdateCalendar_Click(object sender, EventArgs e)
        {
            countryID = cmb_Holiday.SelectedIndex;

            string countryName = this.cmb_Holiday.GetItemText(this.cmb_Holiday.SelectedItem);

            if (dtPicker_From.Text != "" && txt_HolidayReson.Text != "" && countryID > 0 && HolidayID > 0)
            {
                cmd = new SqlCommand("update ARC_Holiday_Master set Holiday_Date=@Holiday_Date, Holiday_Reason=@Holiday_Reason, Country_Id = @Country_Id, Last_Updated_By=@PSID, Last_Update_Datetime=@Updated_Datetime where Holiday_ID=@id", con);
                con.Open();
                cmd.Parameters.AddWithValue("@id", HolidayID);
                cmd.Parameters.AddWithValue("@Holiday_Date", dtPicker_From.Text);
                cmd.Parameters.AddWithValue("@Holiday_Reason", txt_HolidayReson.Text);
                cmd.Parameters.AddWithValue("@Country_Id", countryID);
                cmd.Parameters.AddWithValue("@PSID", Environment.UserName);
                cmd.Parameters.AddWithValue("@Updated_Datetime", System.DateTime.Today);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Record Updated Successfully");
                con.Close();
                DisplayData();
                ClearData();
            }
            else
            {
                MessageBox.Show("Please Select Record to Update");
            }
        }

        private void DGV_Holiday_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            HolidayID = Convert.ToInt32(DGV_Holiday.Rows[e.RowIndex].Cells[0].Value);

            cmb_Holiday.SelectedIndex = countryID;

            dtPicker_From.Text = DGV_Holiday.Rows[e.RowIndex].Cells[1].Value.ToString();
            txt_HolidayReson.Text = DGV_Holiday.Rows[e.RowIndex].Cells[2].Value.ToString();
        }

        private void btn_AddCalendar_Click(object sender, EventArgs e)
        {
            if (dtPicker_From.Text != "" && txt_HolidayReson.Text != "" && countryID > 0)
            {
                cmd = new SqlCommand("insert into ARC_Holiday_Master(Holiday_Date,Holiday_Reason, Country_Id,Last_Updated_By,Last_Update_Datetime) values(@Holiday_Date,@Holiday_Reason, @Country_Id,@PSID, @Updated_Datetime)", con);
                con.Open();
                cmd.Parameters.AddWithValue("@Holiday_Date", dtPicker_From.Text);
                cmd.Parameters.AddWithValue("@Holiday_Reason", txt_HolidayReson.Text);
                cmd.Parameters.AddWithValue("@Country_Id", countryID);
                cmd.Parameters.AddWithValue("@PSID", Environment.UserName);
                cmd.Parameters.AddWithValue("@Updated_Datetime", System.DateTime.Today);
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Record Inserted Successfully");
                DisplayData();
                ClearData();
            }
            else
            {
                MessageBox.Show("Please Provide Details!");
            }
        }

        private void btn_DeleteCalendar_Click(object sender, EventArgs e)
        {
            if (HolidayID != 0)
            {
                cmd = new SqlCommand("delete ARC_Holiday_Master where Holiday_ID=@id", con);
                con.Open();
                cmd.Parameters.AddWithValue("@id", HolidayID);
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Record Deleted Successfully!");
                DisplayData();
                ClearData();
            }
            else
            {
                MessageBox.Show("Please Select Record to Delete");
            }
        }
        #endregion

        #region FTP Status
        public void refreshdata()
        {
            try
            {
                DataTable dt_Final = new DataTable();
                dt_Final.Columns.Add("Country_Id");
                dt_Final.Columns.Add("Country_Name");
                dt_Final.Rows.Add("0", "--All--");
                SqlConnection con = new SqlConnection(conString);
                con.Open();
                SqlCommand cmd = new SqlCommand("ARC_SP_GetCountries", con);
                cmd.CommandType = CommandType.StoredProcedure;
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                sda.Fill(dt);

                foreach (DataRow d in dt.Rows)
                {
                    dt_Final.ImportRow(d);
                }

                //FTP Status
                cmb_FTP_cntry.ValueMember = "Country_Id";
                cmb_FTP_cntry.DisplayMember = "Country_Name";
                cmb_FTP_cntry.DataSource = dt_Final;

                DataTable dt_Final1 = new DataTable();
                dt_Final1.Columns.Add("Product_ID");
                dt_Final1.Columns.Add("Product_name");
                dt_Final1.Rows.Add("0", "--All--");
                cmd = new SqlCommand("ARC_SP_GetProducts", con);
                cmd.CommandType = CommandType.StoredProcedure;
                sda = new SqlDataAdapter(cmd);
                dt = new DataTable();
                sda.Fill(dt);
                foreach (DataRow d in dt.Rows)
                {
                    dt_Final1.ImportRow(d);
                }
                cmb_FTP_Prdt.ValueMember = "Product_ID";
                cmb_FTP_Prdt.DisplayMember = "Product_name";
                cmb_FTP_Prdt.DataSource = dt_Final1;

                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }

        }

        private void btnUpdate_FTP_Click(object sender, EventArgs e)
        {
            Hashtable hat = new Hashtable();
            SqlConnection con = new SqlConnection(conString);
            SqlCommand cmd = null;
            SqlCommand cmd1 = null;
            DataGridViewRowCollection Rows = DGV_FTP.Rows; //dataGridView1.Rows;
            bool IsCheck = false;
            con.Open();
            foreach (DataGridViewRow row in Rows)
            {
                string recon = row.Cells["Recon_Name"].Value.ToString();
                string Country = row.Cells["Country"].Value.ToString();

                if (row.Cells[3].Value != null && DGV_FTP_lst[row.Index] != null && row.Cells[3].Value.ToString() != DGV_FTP_lst[row.Index].ToString())
                {

                    if (row.Cells[3].Value != null && row.Cells[3].Value.ToString() == "True")
                    {
                        IsCheck = true;
                        cmd1 = new SqlCommand("update arc_recon_master set Is_FTP_Required = 1 where recon_name = '" + recon + "'", con);
                        int j = cmd1.ExecuteNonQuery();
                        if (j > 0)
                        {
                            DGV_FTP_lst[row.Index] = row.Cells[3].Value.ToString();//MessageBox.Show("Sucessful");
                        }
                    }
                    else if (row.Cells[3].Value != null && row.Cells[3].Value.ToString() == "False")
                    {
                        IsCheck = true;
                        cmd1 = new SqlCommand("update arc_recon_master set Is_FTP_Required = 0 where recon_name = '" + recon + "'", con);
                        int j = cmd1.ExecuteNonQuery();
                        if (j > 0)
                        {
                            DGV_FTP_lst[row.Index] = row.Cells[3].Value.ToString();
                        }
                    }
                }
            }
            con.Close();
            if (IsCheck == false)
            {
                MessageBox.Show("No Changes to update...!!!");
            }
            else
            {
                Recon_ViewRecord("", "");
                MessageBox.Show("Updated Sucessful");
            }
        }

        public void Recon_ViewRecord(string strProductVal, string strCountryVal)
        {
            int linnum = 0;
            date = DateTime.Now.ToString("HH:MM");
            try
            {
                Hashtable hat = new Hashtable();
                dt = new DataTable();


                string strquery = "select Recon_Name,	Team, Country, Is_FTP_Required from dbo.ARC_Recon_Master a  where Is_Active=1 " + strProductVal + " " + strCountryVal + "";
                strquery = strquery + "  order by Team,Country,Recon_name";
                dt = das.Select_Table(strquery, hat, "text");

                DGV_FTP.DataSource = dt;

                DataGridViewRowCollection Rows = DGV_FTP.Rows;

                int i = 0;
                foreach (DataGridViewRow row in Rows)
                {
                    DGV_FTP_lst.Add(row.Cells["Is_FTP_Required"].Value.ToString());
                }

                foreach (DataGridViewColumn dc in DGV_FTP.Columns)
                {
                    dc.SortMode = DataGridViewColumnSortMode.NotSortable;
                    if (dc.HeaderText == "Is_FTP_Required")
                    {
                        dc.ReadOnly = false;
                    }
                    else
                    {
                        dc.ReadOnly = true;
                    }
                }

            }
            catch (Exception ex)
            {
                int x = linnum;
            }
        }

        private void cmb_FTP_Prdt_SelectedIndexChanged(object sender, EventArgs e)
        {
            i = cmb_FTP_cntry.SelectedIndex;
            j = cmb_FTP_Prdt.SelectedIndex;
            selectedcountry = this.cmb_FTP_cntry.GetItemText(this.cmb_FTP_cntry.SelectedItem);
            selectedProduct = this.cmb_FTP_Prdt.GetItemText(this.cmb_FTP_Prdt.SelectedItem);

            string strProduct = "";
            string strCountry = "";
            if (i > 0)
            {
                strCountry = " and a.Country='" + selectedcountry + "'";
            }
            if (j > 0)
            {
                strProduct = " and a.Team='" + selectedProduct + "'";
            }

            Recon_ViewRecord(strProduct, strCountry);
        }

        private void cmb_FTP_cntry_SelectedIndexChanged(object sender, EventArgs e)
        {
            i = cmb_FTP_cntry.SelectedIndex;
            j = cmb_FTP_Prdt.SelectedIndex;
            selectedcountry = this.cmb_FTP_cntry.GetItemText(this.cmb_FTP_cntry.SelectedItem);
            selectedProduct = this.cmb_FTP_Prdt.GetItemText(this.cmb_FTP_Prdt.SelectedItem);

            string strProduct = "";
            string strCountry = "";
            if (i > 0)
            {
                strCountry = " and a.Country='" + selectedcountry + "'";
            }
            if (j > 0)
            {
                strProduct = " and a.Team='" + selectedProduct + "'";
            }

            Recon_ViewRecord(strProduct, strCountry);
        }
        #endregion

        private void btn_GenerateReport_Click(object sender, EventArgs e)
        {
            string Rec_Date1 = "";
            string Rec_Date2 = "";
            try
            {
                List<DataTable> dtArrList = new List<DataTable>();
                string From_Dates = From_Date.Text;
                string To_Dates = To_Date.Text;
                DateTime myDate1 = DateTime.ParseExact(From_Dates, "dd/MM/yyyy", System.Globalization.CultureInfo.InvariantCulture);
                Rec_Date1 = myDate1.ToString("yyyy-MM-dd");
                DateTime myDate2 = DateTime.ParseExact(To_Dates, "dd/MM/yyyy", System.Globalization.CultureInfo.InvariantCulture);
                Rec_Date2 = myDate2.ToString("yyyy-MM-dd");
                con = new SqlConnection(conString);
                con.Open();
                cmd = new SqlCommand("select Team,Country_Name,Recon,SLA_Time,Receipt_Time,Report_Source_File_Name,FTP_File_Format_Name,Source_Application,Recon_date,AutomationStatus from arc_scope_baseline_history where [Current_Date] between '" + Rec_Date1 + "' and '" + Rec_Date2 + "' order by team ", con);
                da = new SqlDataAdapter(cmd);
                dt = new System.Data.DataTable();
                da.Fill(dt);
                cmd = new SqlCommand("select Team,Country,Recon_name,SLA_Time,Receipt_Time, Recon_Status from arc_recon_master_history where ( [Current_Date] between '" + Rec_Date1 + "' and '" + Rec_Date2 + "') and Is_active = 1 and Is_Holiday_logic = 0", con);
                da = new SqlDataAdapter(cmd);
                System.Data.DataTable dt1 = new System.Data.DataTable();
                da.Fill(dt1);
                cmd = new SqlCommand(" select Team,Country,Recon_name,SLA_Time,Receipt_Time, Recon_Status, Recon_date from arc_recon_master_holiday_date_logic_history where convert (date, AutomationStartTime) between '" + Rec_Date1 + "' and '" + Rec_Date2 + "'and recon_name in (select recon_name from Arc_Recon_master where Is_active =1 and Is_Holiday_Logic = 1)", con);
                da = new SqlDataAdapter(cmd);
                System.Data.DataTable dt2 = new System.Data.DataTable();
                da.Fill(dt2);
                dt1.Merge(dt2);
                dtArrList.Add(dt);
                dtArrList.Add(dt1);

                string folderPath = Directory + "Dashboard_Report\\";
                SaveFileDialog saveDialog = new SaveFileDialog();
                saveDialog.Filter = "Excel files (*.xlsx)|*.xlsx|All files (*.*)|*.*";
                saveDialog.FilterIndex = 2;
                string filePath = folderPath + "Dashboard_Report_" + Environment.UserName + "_" + DateTime.Now.ToString("hh mm tt") + ".xlsx";

                ExportToExcel(dtArrList, filePath);

                con.Close();
                con.Open();
            }
            catch (Exception ex)
            {

            }
        }

        private void ExportToExcel(List<DataTable> Tbl, string ExcelFilePath)
        {
            try
            {
                if (Tbl.Count() == 0)
                    throw new Exception("No datatable is found");
                if (Tbl[0] == null || Tbl[0].Columns.Count == 0)
                    throw new Exception("ExportToExcel: Null or empty input table!\n");

                // load excel, and create a new workbook
                Microsoft.Office.Interop.Excel.Application excelApp = new Microsoft.Office.Interop.Excel.Application();
                excelApp.Workbooks.Add();

                // Create File level worksheet
                Microsoft.Office.Interop.Excel._Worksheet workSheet = (Microsoft.Office.Interop.Excel._Worksheet)excelApp.ActiveSheet;
                workSheet.Name = "File Level";
                // column headings
                for (int i = 0; i < Tbl[0].Columns.Count; i++)
                {
                    workSheet.Cells[1, (i + 1)] = Tbl[0].Columns[i].ColumnName;
                }

                // rows
                for (int i = 0; i < Tbl[0].Rows.Count; i++)
                {

                    for (int j = 0; j < Tbl[0].Columns.Count; j++)
                    {
                        workSheet.Cells[(i + 2), (j + 1)] = Tbl[0].Rows[i][j];
                    }
                }
                //Create Recon level worksheet
                excelApp.Worksheets.Add();
                Microsoft.Office.Interop.Excel._Worksheet workSheet1 = (Microsoft.Office.Interop.Excel._Worksheet)excelApp.ActiveSheet;
                workSheet1.Name = "Recon Level";
                for (int i = 0; i < Tbl[1].Columns.Count; i++)
                {
                    workSheet1.Cells[1, (i + 1)] = Tbl[1].Columns[i].ColumnName;
                }

                // rows
                for (int i = 0; i < Tbl[1].Rows.Count; i++)
                {

                    for (int j = 0; j < Tbl[1].Columns.Count; j++)
                    {
                        workSheet1.Cells[(i + 2), (j + 1)] = Tbl[1].Rows[i][j];
                    }
                }

                // check filepath
                if (ExcelFilePath != null && ExcelFilePath != "")
                {
                    try
                    {
                        workSheet.SaveAs(ExcelFilePath);
                        excelApp.Quit();
                        MessageBox.Show("Excel file saved!");
                        System.Runtime.InteropServices.Marshal.ReleaseComObject(workSheet);
                        System.Runtime.InteropServices.Marshal.ReleaseComObject(workSheet1);
                        System.Runtime.InteropServices.Marshal.ReleaseComObject(excelApp);
                    }
                    catch (Exception ex)
                    {
                        // throw new Exception("ExportToExcel: Excel file could not be saved! Check filepath.\n"
                        // + ex.Message);
                        System.Runtime.InteropServices.Marshal.ReleaseComObject(workSheet);
                        System.Runtime.InteropServices.Marshal.ReleaseComObject(workSheet1);
                        System.Runtime.InteropServices.Marshal.ReleaseComObject(excelApp);
                    }
                }
                else    // no filepath is given
                {
                    excelApp.Visible = true;
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(workSheet);
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(workSheet1);
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(excelApp);
                }

            }
            catch (Exception ex)
            {
                //throw new Exception("ExportToExcel: \n" + ex.Message);

            }
        }

        private void cmbProductName_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (Convert.ToString(cmbProductName.SelectedValue) != "0")
                {
                    con.Open();
                    //cmd = new SqlCommand("select Recon_Name as Recon_ID ,Recon_Name as Recon_Name from arc_recon_master where Is_Active=1 and IsEmailRequired=1 order by Recon_Name", con);
                    //cmd = new SqlCommand("select distinct recon.Recon_Name as Recon_ID ,recon.Recon_Name as Recon_Name from arc_recon_master recon inner join arc_scope_baseline base on recon.recon_name=base.Recon where recon.Is_Active=1 and recon.IsEmailRequired=1 and base.Product_Id=@ProductId order by recon.Recon_Name", con);
                    cmd = new SqlCommand("select distinct recon.Recon_Name as Recon_ID ,recon.Recon_Name as Recon_Name from arc_recon_master recon inner join arc_scope_baseline base on recon.recon_name=base.Recon where recon.Is_Active=1 and base.Source_Application ='Email' and base.Product_Id=@ProductId order by recon.Recon_Name", con);
                    cmd.Parameters.AddWithValue("@ProductId", cmbProductName.SelectedValue.ToString());
                    da = new SqlDataAdapter(cmd);
                    DataTable dtRecon = new System.Data.DataTable();
                    dtRecon.Columns.Add("Recon_ID");
                    dtRecon.Columns.Add("Recon_Name");
                    dtRecon.Rows.Add("0", "---Select Recon Name---");
                    da.Fill(dtRecon);
                    cmbReconName.DataSource = null;
                    cmbReconName.Items.Clear();
                    cmbReconName.ValueMember = "Recon_ID";
                    cmbReconName.DisplayMember = "Recon_Name";
                    cmbReconName.DataSource = dtRecon;
                    con.Close();
                }
                else
                {
                    cmbReconName.DataSource = null;
                    cmbReconName.Items.Clear();
                    DataTable dtRecon = new System.Data.DataTable();
                    dtRecon.Columns.Add("Recon_ID");
                    dtRecon.Columns.Add("Recon_Name");
                    dtRecon.Rows.Add("0", "---Select Recon Name---");
                    cmbReconName.DataSource = null;
                    cmbReconName.ValueMember = "Recon_ID";
                    cmbReconName.DisplayMember = "Recon_Name";
                    cmbReconName.DataSource = dtRecon;

                }

                cmbFileName.DataSource = null;
                cmbFileName.Items.Clear();
                DataTable dtFileName = new System.Data.DataTable();
                dtFileName.Columns.Add("Scope_id");
                dtFileName.Columns.Add("Report_Source_File_Name");
                dtFileName.Rows.Add("0", "---Select File Name---");
                cmbFileName.ValueMember = "Scope_id";
                cmbFileName.DisplayMember = "Report_Source_File_Name";
                cmbFileName.DataSource = dtFileName;

                txtEmailID.Text = string.Empty;
                ckb_IsMailFunctionalityRequired.Checked = false;

            }
            catch
            {
            }
        }

        private void cmbReconName_SelectedIndexChanged(object sender, EventArgs e)
        { //Start Added on 19/04/2018
            try
            {
                if (Convert.ToString(cmbProductName.SelectedValue) != "0" && Convert.ToString(cmbReconName.SelectedValue) != "0")
                {
                    con.Open();
                    cmd = new SqlCommand("select distinct Scope_id,isnull(Report_Source_File_Name,'')+'.'+isnull(File_Format,'') as Report_Source_File_Name from arc_scope_baseline where Recon=@Recon and Product_Id=@Product_Id order by Report_Source_File_Name", con);
                    cmd.Parameters.AddWithValue("@Recon", cmbReconName.SelectedValue.ToString());
                    cmd.Parameters.AddWithValue("@Product_Id", cmbProductName.SelectedValue.ToString());
                    da = new SqlDataAdapter(cmd);
                    DataTable dtFileName = new System.Data.DataTable();
                    dtFileName.Columns.Add("Scope_id");
                    dtFileName.Columns.Add("Report_Source_File_Name");
                    dtFileName.Rows.Add("0", "---Select File Name---");
                    da.Fill(dtFileName);
                    cmbFileName.DataSource = null;
                    cmbFileName.Items.Clear();
                    cmbFileName.ValueMember = "Scope_id";
                    cmbFileName.DisplayMember = "Report_Source_File_Name";
                    cmbFileName.DataSource = dtFileName;
                    con.Close();


                }
                else
                {
                    cmbFileName.DataSource = null;
                    cmbFileName.Items.Clear();

                    DataTable dtFileName = new System.Data.DataTable();
                    dtFileName.Columns.Add("Scope_id");
                    dtFileName.Columns.Add("Report_Source_File_Name");
                    dtFileName.Rows.Add("0", "---Select File Name---");
                    cmbFileName.ValueMember = "Scope_id";
                    cmbFileName.DisplayMember = "Report_Source_File_Name";
                    cmbFileName.DataSource = dtFileName;
                }
                txtEmailID.Text = string.Empty;
                ckb_IsMailFunctionalityRequired.Checked = false;
            }
            catch (Exception ex)
            {
                //throw ex;
            }

        }

        private void cmbFileName_SelectedIndexChanged(object sender, EventArgs e)
        {

            //Start Added on 19/04/2018
            try
            {
                ckb_IsMailFunctionalityRequired.Checked = false;


                if (Convert.ToString(cmbProductName.SelectedValue) != "0" && Convert.ToString(cmbFileName.SelectedValue) != "0" && Convert.ToString(cmbReconName.SelectedValue) != "0")
                {
                    con.Open();
                    cmd = new SqlCommand("select Email_Id,isMailFunctionalityRequired from arc_scope_baseline where Recon=@Recon and Report_Source_File_Name =@Report_Source_File_Name and Product_Id=@Product_Id", con);
                    cmd.Parameters.AddWithValue("@Recon", cmbReconName.SelectedValue.ToString());
                    cmd.Parameters.AddWithValue("@Report_Source_File_Name", cmbFileName.Text.Substring(0,cmbFileName.Text.LastIndexOf('.')).ToString());
                    cmd.Parameters.AddWithValue("@Product_Id", cmbProductName.SelectedValue.ToString());
                    SqlDataReader dr = cmd.ExecuteReader();
                    while (dr.Read())
                    {
                        if (dr.HasRows == true)
                        {
                            txtEmailID.Text = Convert.ToString(dr[0]);
                            ckb_IsMailFunctionalityRequired.Checked = Convert.ToBoolean(dr[1]);

                        }
                    }

                    con.Close();
                }
                else
                {
                    txtEmailID.Text = string.Empty;
                }
            }
            catch (Exception ex)
            {
                //throw ex;
            }
        }

        private void btnUpdateRecipient_Click(object sender, EventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(txtEmailID.Text.Trim()))
                {
                    string EmailIDs = string.Empty;

                    EmailIDs = txtEmailID.Text.TrimEnd(';');

                    string[] arrEmailID = EmailIDs.Split(';');

                    foreach (string email in arrEmailID)
                    {
                        if (!IsValidEmail(email))
                        {
                            MessageBox.Show("Please enter Valid EmailID");
                            return;
                        }
                    }
                }

                if (Convert.ToString(cmbProductName.SelectedValue) != "0" && Convert.ToString(cmbReconName.SelectedValue) != "0" && Convert.ToString(cmbFileName.SelectedValue) != "0" && !string.IsNullOrEmpty(txtEmailID.Text.Trim()))
                {
                    con.Open();
                    cmd = new SqlCommand("ARC_SP_Update_RecipientList", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Product_ID", cmbProductName.SelectedValue.ToString());
                    cmd.Parameters.AddWithValue("@Recon_Name", cmbReconName.SelectedValue.ToString());
                    cmd.Parameters.AddWithValue("@Scope_ID", cmbFileName.SelectedValue.ToString());
                    cmd.Parameters.AddWithValue("@Report_Source_File_Name", cmbFileName.Text.Substring(0,cmbFileName.Text.LastIndexOf('.')).ToString());
                    cmd.Parameters.AddWithValue("@Email_ID", txtEmailID.Text.Replace(',', ';').Trim());
                    cmd.Parameters.AddWithValue("@isMailFunctionalityRequired", ckb_IsMailFunctionalityRequired.Checked == true ? 1 : 0);
                    cmd.Parameters.AddWithValue("@Last_Updated_By", Environment.UserName);
                    cmd.Parameters.AddWithValue("@Time_Stamp", System.DateTime.Today);
                    cmd.ExecuteNonQuery();

                    SqlCommand cmd1 = new SqlCommand();
                    cmd1 = new SqlCommand("update arc_recon_master set IsEmailRequired =1 where recon_name = '" + cmbReconName.SelectedValue.ToString() + "'", con);
                    cmd1.ExecuteNonQuery();
                    
                    con.Close();

                    MessageBox.Show("Record Updated Successfully");
                    ResetRecipientList();


                }
                else
                {
                    MessageBox.Show("Please fill the details");
                }
            }
            catch (Exception ex)
            {
                //throw ex;
            }

        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            ResetRecipientList();
        }

        private void btnDownloadRecipientList_Click(object sender, EventArgs e)
        {

            try
            {
                List<DataTable> dtArrList = new List<DataTable>();
                DataTable dtRecipient = new DataTable();
                con.Open();
                cmd = new SqlCommand("select scope.Team,product.Product_Name,scope.Recon,isnull(scope.Report_Source_File_Name,'')+'.'+isnull(scope.File_Format,'') as Report_Source_File_Name,scope.Email_ID,case when isnull(scope.isMailFunctionalityRequired,0)=1 then 'Yes' Else 'No' End As MailFunctionalityRequired from arc_scope_Baseline scope inner join arc_product_details product on product.Product_ID=scope.Product_ID where recon in (select Recon_Name from arc_recon_master where Is_Active=1 and IsEmailRequired=1) order by scope.Team,product.Product_Name,scope.Recon,scope.Report_Source_File_Name,scope.Email_ID", con);
                da = new SqlDataAdapter(cmd);

                da.Fill(dtRecipient);
                con.Close();

                dtArrList.Add(dtRecipient);
                string folderPath = Directory + "Dashboard_Report\\";
                SaveFileDialog saveDialog = new SaveFileDialog();
                saveDialog.Filter = "Excel files (*.xlsx)|*.xlsx|All files (*.*)|*.*";
                saveDialog.FilterIndex = 2;
                string filePath = folderPath + "Recipient_List_" + Environment.UserName + "_" + DateTime.Now.ToString("hh mm tt") + ".xlsx";

                ExportToExcelRecipientList(dtArrList, filePath);
            }
            catch (Exception ex)
            {
                //throw ex;
            }
            finally
            {
                dt = null;
            }


        }

        private void ExportToExcelRecipientList(List<DataTable> Tbl, string ExcelFilePath)
        {
            try
            {
                if (Tbl.Count() == 0)
                    throw new Exception("No datatable is found");
                if (Tbl[0] == null || Tbl[0].Columns.Count == 0)
                    throw new Exception("ExportToExcel: Null or empty input table!\n");

                // load excel, and create a new workbook
                Microsoft.Office.Interop.Excel.Application excelApp = new Microsoft.Office.Interop.Excel.Application();
                excelApp.Workbooks.Add();

                // Create File level worksheet
                Microsoft.Office.Interop.Excel._Worksheet workSheet = (Microsoft.Office.Interop.Excel._Worksheet)excelApp.ActiveSheet;
                workSheet.Name = "Recipient List";
                // column headings
                for (int i = 0; i < Tbl[0].Columns.Count; i++)
                {
                    workSheet.Cells[1, (i + 1)] = Tbl[0].Columns[i].ColumnName;
                }

                // rows
                for (int i = 0; i < Tbl[0].Rows.Count; i++)
                {

                    for (int j = 0; j < Tbl[0].Columns.Count; j++)
                    {
                        workSheet.Cells[(i + 2), (j + 1)] = Tbl[0].Rows[i][j];
                    }
                }
                // check filepath
                if (ExcelFilePath != null && ExcelFilePath != "")
                {
                    try
                    {
                        workSheet.SaveAs(ExcelFilePath);
                        excelApp.Quit();
                        MessageBox.Show("Excel file saved!");
                        System.Runtime.InteropServices.Marshal.ReleaseComObject(workSheet);
                        System.Runtime.InteropServices.Marshal.ReleaseComObject(excelApp);
                    }
                    catch (Exception ex)
                    {
                        // throw new Exception("ExportToExcel: Excel file could not be saved! Check filepath.\n"
                        // + ex.Message);
                        System.Runtime.InteropServices.Marshal.ReleaseComObject(workSheet);
                        System.Runtime.InteropServices.Marshal.ReleaseComObject(excelApp);
                    }
                }
                else    // no filepath is given
                {
                    excelApp.Visible = true;
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(workSheet);
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(excelApp);
                }

            }
            catch (Exception ex)
            {
                //throw new Exception("ExportToExcel: \n" + ex.Message);

            }
        }

        private static Regex CreateValidEmailRegex()
        {
            string validEmailPattern = @"^(?("")("".+?(?<!\\)""@)|(([0-9a-z]((\.(?!\.))|[-!#\$%&'\*\+/=\?\^`\{\}\|~\w])*)(?<=[0-9a-z])@))" +
            @"(?(\[)(\[(\d{1,3}\.){3}\d{1,3}\])|(([0-9a-z][-0-9a-z]*[0-9a-z]*\.)+[a-z0-9][\-a-z0-9]{0,22}[a-z0-9]))$";

            return new Regex(validEmailPattern, RegexOptions.IgnoreCase);
        }

        static Regex ValidEmailRegex = CreateValidEmailRegex();

        private bool IsValidEmail(string emailAddress)
        {
            int SCID;
            if ((int.TryParse(emailAddress, out SCID) && emailAddress.Length == 7) || (ValidEmailRegex.IsMatch(emailAddress)))
                return true;
            else
                return false;
        }

        private void ResetRecipientList()
        {
            try
            {
                DataTable dt_Final1 = new DataTable();
                dt_Final1.Columns.Add("Product_ID");
                dt_Final1.Columns.Add("Product_name");
                dt_Final1.Rows.Add("0", "---Select Product Name---");
                con.Open();
                cmd = new SqlCommand("SELECT Product_ID,Product_name FROM dbo.ARC_Product_Details order by product_name", con);
                cmd.CommandType = CommandType.Text;
                da = new SqlDataAdapter(cmd);
                dt = new DataTable();
                da.Fill(dt);
                foreach (DataRow d in dt.Rows)
                {
                    dt_Final1.ImportRow(d);
                }
                cmbProductName.ValueMember = "Product_ID";
                cmbProductName.DisplayMember = "Product_name";
                cmbProductName.DataSource = dt_Final1;
                con.Close();


                DataTable dtRecon = new System.Data.DataTable();
                dtRecon.Columns.Add("Recon_ID");
                dtRecon.Columns.Add("Recon_Name");
                dtRecon.Rows.Add("0", "---Select Recon Name---");
                cmbReconName.DataSource = null;
                cmbReconName.ValueMember = "Recon_ID";
                cmbReconName.DisplayMember = "Recon_Name";
                cmbReconName.DataSource = dtRecon;



                //con.Open();
                //cmd = new SqlCommand("select Recon_Name as Recon_ID ,Recon_Name as Recon_Name from arc_recon_master where Is_Active=1 and IsEmailRequired=1 order by Recon_Name", con);
                //da = new SqlDataAdapter(cmd);
                //DataTable dtRecon = new System.Data.DataTable();
                //dtRecon.Columns.Add("Recon_ID");
                //dtRecon.Columns.Add("Recon_Name");
                //dtRecon.Rows.Add("0", "---Select Recon Name---");
                //da.Fill(dtRecon);
                //cmbReconName.DataSource = null;
                //cmbReconName.ValueMember = "Recon_ID";
                //cmbReconName.DisplayMember = "Recon_Name";
                //cmbReconName.DataSource = dtRecon;
                //con.Close();

                cmbFileName.DataSource = null;
                cmbFileName.Items.Clear();
                txtEmailID.Text = string.Empty;
                DataTable dtFileName = new System.Data.DataTable();
                dtFileName.Columns.Add("Scope_id");
                dtFileName.Columns.Add("Report_Source_File_Name");
                dtFileName.Rows.Add("0", "---Select File Name---");
                cmbFileName.ValueMember = "Scope_id";
                cmbFileName.DisplayMember = "Report_Source_File_Name";
                cmbFileName.DataSource = dtFileName;

                ckb_IsMailFunctionalityRequired.Checked = false;
            }
            catch
            {
            }
            finally
            {

            }

        }







    }
}
