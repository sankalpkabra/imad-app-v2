﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;
using System.Security.Cryptography;
using System.Configuration;
//using Microsoft.Office.Interop.Outlook;


namespace ARC_Application
{
    public partial class ARC_Login : Form
    {
        ApplicationClass Aps = new ApplicationClass();
        string conString = ConfigurationManager.ConnectionStrings["ARC_conStr"].ConnectionString;
        SQLEncryption ecp = new SQLEncryption();
        public string setValue;
        public SqlConnection conn;
        public SqlCommand com;

        public ARC_Login()
        {
            InitializeComponent();
            Login_Check();
        }

        private void Initialize()
        {

        }

        private void Btn_login_Click(object sender, EventArgs e)
        {
            conn = new SqlConnection(conString);
            string UserID = Txt_UserID.Text;            
            string Psd = Txt_Psd.Text;
            try
            {
                if (UserID == string.Empty)
                {
                    MessageBox.Show("Please enter a valid UserID!");
                    return;
                }
                else if (Psd == string.Empty)
                {
                    MessageBox.Show("Please enter a valid  Password!");
                    return;
                }
                else
                {
                    conn.Open();
                    string qry1 = "select UserID,Password,UserRole from dbo.ARC_User_Info where UserID=@UserID and Password=@Password";
                    com = new SqlCommand(qry1, conn);
                    com.Parameters.AddWithValue("@UserID", UserID);
                    com.Parameters.AddWithValue("@Password", ecp.Encrypt(Psd.Trim()));
                    // com.Parameters.AddWithValue("@Password", Encrypt(Psd.Trim()));
                    SqlDataReader dr = com.ExecuteReader();// this line show the exception....
                    
                    while (dr.Read())
                    {

                        if (dr.HasRows == true)
                        {
                            //MessageBox.Show("Login Successfull", "Login Information");
                            foreach (var p in System.Diagnostics.Process.GetProcessesByName("OpenSpan.Runtime"))
                            {
                                p.Kill();
                            }
                            this.Hide();
                            string UserRole = (string)dr["UserRole"];
                            if (UserRole == "Admin")
                            {
                                Admin_DashBoard Adm = new Admin_DashBoard();
                                Adm.Show();
                            }
                            else
                            {
                                Dashboard dash = new Dashboard();
                                dash.Show();
                                System.Diagnostics.Process.Start(@"C:\Program Files (x86)\OpenSpan\OpenSpan Runtime Enterprise\OpenSpan.Runtime.exe");
                                //System.Diagnostics.Process.Start(@"C:\Program Files (x86)\OpenSpan\OpenSpan Studio for Microsoft Visual Studio 2010\Application\OpenSpan.Runtime.exe");
                            }
                        }
                    }
                    if (dr.HasRows == false)
                    {
                        MessageBox.Show("User id and password does not match");
                    }
                    conn.Close();
                }
            }
            catch
            {
                //MessageBox.Show("Network Error ! Please Login");
            }
        }

        private void Txt_UserID_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) || Txt_UserID.Text.Length >= 7 && e.KeyChar != 8)// || Txt_UserID.Text.Length == 7)
            {
                e.Handled = true;
                //MessageBox.Show("Please Enter your UserID!");
            }

        }

        private void Btn_Cancel_Click(object sender, EventArgs e)
        {
            //Txt_UserID.Text = "";
            Txt_Psd.Text = "";
            this.Show();
        }

        private void lbl_RstPsd_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            try
            {
                if (Txt_UserID.Text == string.Empty)
                {
                    MessageBox.Show("Please Enter a valid UserID!");
                    return;
                }
                else
                {
                    this.Hide();
                    ChangePassword cpd = new ChangePassword(Txt_UserID.Text);
                    cpd.Show();
                }
            }
            catch
            {
            
            }
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            try
            {
                string UserID = Txt_UserID.Text;
                SqlConnection con = new SqlConnection(conString);
                con.Open();
                SqlCommand com = new SqlCommand("select Password from dbo.ARC_User_Info where UserID=@UserID", con);
                com.CommandType = CommandType.Text;
                com.Parameters.AddWithValue("@UserID", UserID);
                SqlDataReader dr = com.ExecuteReader();
                while (dr.Read())
                {
                    if (dr.HasRows == true)
                    {
                        string Password = (string)dr["Password"];
                        string Psd = ecp.Decrypt(Password.Trim());
                        Microsoft.Office.Interop.Outlook.Application app = new Microsoft.Office.Interop.Outlook.Application();
                        Microsoft.Office.Interop.Outlook.MailItem mailItem = app.CreateItem(Microsoft.Office.Interop.Outlook.OlItemType.olMailItem);
                        mailItem.Subject = "SCB: Password Reset";
                        mailItem.To = UserID;
                        mailItem.Body = "Dear User.\n \n Your Login Password For ARC Applications is " + Psd + "";
                        //"Dear G, Aneesh Kumar, \n"

                        //            +"Your LAN ID password is about to expire in 14 days."

                        //             +" User ID                                     :"
                        //             + " Password Expiry Date       :" + Psd

                        //             +" Please change the password before it expires in order to avoid disruption to your access to SCB systems."

                        //             +"User are required to change password every 90 days as part of the security requirement."
                        //             +"If you have recently changed your LAN ID password, you can disregard this email."     

                        //              +"This is a computer generated email, please do NOT reply to this email."; 

                        // Hi.\n Your Login Password For ARC Applications is " + Psd + "";
                        //mailItem.Attachments.Add(logPath);//logPath is a string holding path to the log.txt file
                        mailItem.Importance = Microsoft.Office.Interop.Outlook.OlImportance.olImportanceHigh;
                        mailItem.Send();

                    }
                }
                con.Close();
            }
            catch
            {
                MessageBox.Show("Network Error ! Please Login");
            }
        }

        private string Encrypt(string clearText)
        {
            try
            {
                string EncryptionKey = "MAKV2SPBNI99212";
                byte[] clearBytes = Encoding.Unicode.GetBytes(clearText);
                using (Aes encryptor = Aes.Create())
                {
                    Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
                    encryptor.Key = pdb.GetBytes(32);
                    encryptor.IV = pdb.GetBytes(16);
                    using (MemoryStream ms = new MemoryStream())
                    {
                        using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateEncryptor(), CryptoStreamMode.Write))
                        {
                            cs.Write(clearBytes, 0, clearBytes.Length);
                            cs.Close();
                        }
                        clearText = Convert.ToBase64String(ms.ToArray());
                    }
                }
                return clearText;
            }
            catch
            {
                return null;
            }
        }

        private string Decrypt(string cipherText)
        {
            try
            {
                string EncryptionKey = "MAKV2SPBNI99212";
                byte[] cipherBytes = Convert.FromBase64String(cipherText);
                using (Aes encryptor = Aes.Create())
                {
                    Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
                    encryptor.Key = pdb.GetBytes(32);
                    encryptor.IV = pdb.GetBytes(16);
                    using (MemoryStream ms = new MemoryStream())
                    {
                        using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateDecryptor(), CryptoStreamMode.Write))
                        {
                            cs.Write(cipherBytes, 0, cipherBytes.Length);
                            cs.Close();
                        }
                        cipherText = Encoding.Unicode.GetString(ms.ToArray());
                    }
                }
                return cipherText;
            }
            catch
            {
                return null;
            }
        }

        public void Login_Check()
        {
            try
            {
                string UserID = Txt_UserID.Text;
                SqlConnection con = new SqlConnection(conString);
                con.Open();
                SqlCommand com = new SqlCommand("select EndDate from dbo.ARC_User_Info where UserID=@UserID", con);
                com.CommandType = CommandType.Text;
                com.Parameters.AddWithValue("@UserID", UserID);
                SqlDataReader dr = com.ExecuteReader();
                while (dr.Read())
                {
                    if (dr.HasRows == true)
                    {
                        DateTime LastDate = (DateTime)dr["EndDate"];
                        DateTime LastDate1 = LastDate.AddDays(-1);
                        DateTime LastDate2 = LastDate.AddDays(-2);
                        DateTime ValidDate = DateTime.Today;
                        if (LastDate == ValidDate)
                        {
                            //Microsoft.Office.Interop.Outlook.Application app = new Microsoft.Office.Interop.Outlook.Application();
                            //Microsoft.Office.Interop.Outlook.MailItem mailItem = app.CreateItem(Microsoft.Office.Interop.Outlook.OlItemType.olMailItem);
                            //mailItem.Subject = "Hello";
                            //mailItem.To = UserID;
                            //mailItem.Body = "Hi.\n Your Password for ARC is has been to Expired on " + LastDate + "";
                            ////mailItem.Attachments.Add(logPath);//logPath is a string holding path to the log.txt file
                            //mailItem.Importance = Microsoft.Office.Interop.Outlook.OlImportance.olImportanceHigh;
                            //mailItem.Display(false);
                            //mailItem.Send();
                            //com = new SqlCommand("update dbo.ARC_User_Info set StartDate =null  where UserID=1554579", con);
                            //com.ExecuteNonQuery();
                        }
                        else if ((LastDate1 == ValidDate) || (LastDate2 == ValidDate))
                        {
                            Microsoft.Office.Interop.Outlook.Application app = new Microsoft.Office.Interop.Outlook.Application();
                            Microsoft.Office.Interop.Outlook.MailItem mailItem = app.CreateItem(Microsoft.Office.Interop.Outlook.OlItemType.olMailItem);
                            mailItem.Subject = "Hello";
                            mailItem.To = UserID;
                            mailItem.Body = "Dear G, Aneesh Kumar, \n"

                                        + "Your LAN ID password is about to expire in 14 days."

                                         + " User ID                                     :"
                                         + " Password Expiry Date       :" + LastDate

                                         + " Please change the password before it expires in order to avoid disruption to your access to SCB systems."

                                         + "User are required to change password every 90 days as part of the security requirement."
                                         + "If you have recently changed your LAN ID password, you can disregard this email."

                                          + "This is a computer generated email, please do NOT reply to this email.";

                            // "Hi.\n Your Password for ARC is going to Expires on " + LastDate + "";
                            //mailItem.Attachments.Add(logPath);//logPath is a string holding path to the log.txt file
                            mailItem.Importance = Microsoft.Office.Interop.Outlook.OlImportance.olImportanceHigh;
                            mailItem.Display(false);
                            mailItem.Send();
                        }

                    }
                }
                con.Close();
            }
            catch
            { 
                
            }


        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                conn = new SqlConnection(conString);
                string UserID = Txt_UserID.Text;
                //string Psd = Aps.Encryption(Txt_Psd.Text, "rajaking");
                string Psd = Txt_Psd.Text;
                string role = "Admin";
                conn.Open();
                com = new SqlCommand("insert into ARC_User_Info(UserID,Password,UserRole) values(@UserID,@Password,@UserRole)", conn);
                com.CommandType = CommandType.Text;
                com.Parameters.AddWithValue("@UserID", UserID);
                com.Parameters.AddWithValue("@Password", Encrypt(Psd.Trim()));
                com.Parameters.AddWithValue("@UserRole", role);
                com.ExecuteNonQuery();
                conn.Close();
            }
            catch
            { 
                
            }
        }

        private void ARC_Login_Load(object sender, EventArgs e)
        {
            try
            {
                Txt_UserID.Text = Environment.UserName;
                Txt_UserID.Enabled = false;
                SqlConnection con = new SqlConnection(conString);
                SqlCommand cmd = new SqlCommand("dbo.ARC_SP_CLEAN_MASTER_DATA", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@SYSTEM_DATE", DateTime.Now);
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
            }
            catch
            {

            }

        }
    }
}
