﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.OleDb;
using System.IO;
using Microsoft.Office.Interop.Excel;
using System.Windows.Forms;
using System.Collections;
namespace ARC_Formatting.FileFormatting
{
    public class cls_VN_Stock
    {
        public void VNStockReport(string Soure_Path, string Recon_Date, string Desti_Path, string Recon_name, string Output_Path, string Formatted_File_Name, string ext)
        {
            Microsoft.Office.Interop.Excel.Application app = new Microsoft.Office.Interop.Excel.Application();
            app.DisplayAlerts = false;
            app.Visible = false;
            Microsoft.Office.Interop.Excel.Workbook wb = null;
            try
            {
                string paths = Soure_Path.Substring(0, Soure_Path.LastIndexOf("\\")) + "\\";
                string[] files1 = Directory.GetFiles(paths);
                string file1 = "";
                string file2 = "";
                string file3 = "";
                for (int i = 0; i < files1.Length; i++)
                {
                    files1[i] = Path.GetFileName(files1[i]);
                    if (files1[i].Contains("DE83_"))
                    {
                        file1 = files1[i];
                    }
                    if (files1[i].Contains("Consolidate Account List for Custody"))
                    {
                        file2 = files1[i];
                    }
                    if (files1[i].Contains("PH30_"))
                    {
                        file3 = files1[i];
                    }
                }
                if (file1 != "" && file2 != "" && file3 != "")
                {
                    string excelFile = paths + file1;
                    string strConn;

                    //strConn = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + excelFile + ";Extended Properties=\"Excel 12.0;HDR=Yes\"";
                    strConn = String.Format(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source={0};Extended Properties=""Excel 12.0 Xml;HDR=YES""", excelFile);
                    System.Data.DataTable dtexcel = new System.Data.DataTable();
                    OleDbConnection conn = new OleDbConnection(strConn);

                    conn.Open();

                    System.Data.DataTable schemaTable = conn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, new object[] { null, null, null, "TABLE" });

                    //DataRow schemaRow = schemaTable.Rows[0];

                    string query = "SELECT * FROM [Sheet1$]";
                    OleDbDataAdapter daexcel = new OleDbDataAdapter(query, conn);
                    dtexcel.Locale = System.Globalization.CultureInfo.CurrentCulture;
                    daexcel.Fill(dtexcel);


                    for (int i = dtexcel.Rows.Count - 1; i >= 0; i--)
                    {
                        if (!dtexcel.Rows[i][11].ToString().Trim().Contains("Giao dịch"))
                        {
                            dtexcel.Rows.RemoveAt(i);
                        }
                    }
                    System.Data.DataTable dt1 = new System.Data.DataTable();
                    dt1.Columns.Add("Investor ID");
                    dt1.Columns.Add("Investor Name");
                    dt1.Columns.Add("Investor name");
                    dt1.Columns.Add("Trading code");
                    dt1.Columns.Add("Custodian code");
                    dt1.Columns.Add("Custodian name");
                    dt1.Columns.Add("Local Securities code");
                    dt1.Columns.Add("Local Securities");
                    dt1.Columns.Add("Date of trading code");
                    dt1.Columns.Add("Nationality of investor");
                    dt1.Columns.Add("Local Account code");
                    dt1.Columns.Add("Security  status");
                    dt1.Columns.Add("Quantity");
                    dt1.Columns.Add("Note");
                    dt1.Columns.Add("Type");
                    dt1.Columns.Add("Con");

                    for (int i = 0; i <= dtexcel.Rows.Count - 1; i++)
                    {
                        dt1.Rows.Add();
                        dt1.Rows[i][0] = dtexcel.Rows[i][0];
                        dt1.Rows[i][1] = dtexcel.Rows[i][1];
                        dt1.Rows[i][2] = dtexcel.Rows[i][2];
                        dt1.Rows[i][3] = dtexcel.Rows[i][3];
                        dt1.Rows[i][4] = dtexcel.Rows[i][4];
                        dt1.Rows[i][5] = dtexcel.Rows[i][5];
                        dt1.Rows[i][6] = dtexcel.Rows[i][6];
                        dt1.Rows[i][7] = dtexcel.Rows[i][7];
                        dt1.Rows[i][8] = dtexcel.Rows[i][8];
                        dt1.Rows[i][9] = dtexcel.Rows[i][9];
                        dt1.Rows[i][10] = dtexcel.Rows[i][10];
                        dt1.Rows[i][11] = dtexcel.Rows[i][11];
                        dt1.Rows[i][12] = "'" + dtexcel.Rows[i][12];
                        dt1.Rows[i][13] = dtexcel.Rows[i][13];
                        dt1.Rows[i][14] = dtexcel.Rows[i][14];
                        dt1.Rows[i][15] = "'" + dtexcel.Rows[i][10].ToString() + dtexcel.Rows[i][13].ToString();
                    }

                    System.Data.DataTable dt2 = new System.Data.DataTable();
                    dt2.Columns.Add("Row Labels");
                    dt2.Columns.Add("Sum of Quantity");
                    decimal dfin = 0.0m;

                    for (int i = 0; i <= dt1.Rows.Count - 1; i++)
                    {
                        dt2.Rows.Add();
                        dt2.Rows[i][0] = dt1.Rows[i][15];
                        decimal dini = Convert.ToDecimal(dt1.Rows[i][12].ToString().Replace("'", ""));

                        dt2.Rows[i][1] = "'" + dini.ToString("#.00");
                        if (dt1.Rows[i][12].ToString() != "")
                        {
                            dfin = dfin + Convert.ToDecimal(dt1.Rows[i][12].ToString().Replace("'", ""));
                        }
                    }
                    dt2.Rows.Add();
                    dt2.Rows[dt2.Rows.Count - 1][0] = "Grand Total";
                    dt2.Rows[dt2.Rows.Count - 1][1] = "'" + dfin.ToString("#.00");

                    string excelFile1 = paths + file3;
                    string ExcelfilePath = excelFile1.Substring(0, excelFile1.Length - 4) + "_1.xlsx";
                    if (File.Exists(ExcelfilePath))
                    {
                        File.Delete(ExcelfilePath);
                    }

                    wb = app.Workbooks.Open(excelFile1, Type.Missing, false, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                    wb.SaveAs(ExcelfilePath, Microsoft.Office.Interop.Excel.XlFileFormat.xlOpenXMLWorkbook, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlExclusive, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                    wb.Close();

                    //sheet 4 coding start
                    string strConn4;
                    strConn4 = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + ExcelfilePath + ";Extended Properties=\"Excel 12.0;HDR=Yes\"";

                    System.Data.DataTable dt_test = new System.Data.DataTable();
                    OleDbConnection conn4 = new OleDbConnection(strConn4);
                    wb = app.Workbooks.Open(ExcelfilePath, Type.Missing, false, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                    conn4.Open();
                    System.Data.DataTable schemaTable4 = conn4.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, new object[] { null, null, null, "TABLE" });

                    DataRow schemaRow4 = schemaTable4.Rows[0];
                    string sheet4 = schemaRow4["TABLE_NAME"].ToString();

                    string query4 = "SELECT  * FROM [" + sheet4 + "]";
                    OleDbDataAdapter daexcel4 = new OleDbDataAdapter(query4, conn4);
                    dt_test.Locale = System.Globalization.CultureInfo.CurrentCulture;
                    daexcel4.Fill(dt_test);
                    wb.Close();
                    app.Quit();
                    ReleaseComObject(wb);
                    ReleaseComObject(app);

                    string strConn1;
                    string flPath = paths + file2;
                    strConn1 = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + flPath + ";Extended Properties=\"Excel 12.0;HDR=Yes;IMEX=1\"";

                    System.Data.DataTable dtexcel1 = new System.Data.DataTable();
                    OleDbConnection conn1 = new OleDbConnection(strConn1);

                    conn1.Open();

                    string sheet1 = "VN Account-Security Reference$";
                    string query1 = "SELECT  * FROM [" + sheet1 + "]";
                    OleDbDataAdapter daexcel1 = new OleDbDataAdapter(query1, conn1);
                    dtexcel1.Locale = System.Globalization.CultureInfo.CurrentCulture;
                    daexcel1.Fill(dtexcel1);

                    // delete blank rows and columns
                    int columnId = 0;
                    for (int i = 0; i < dt_test.Rows.Count - 1; i++)
                    {
                        for (int j = 0; j < dt_test.Columns.Count; j++)
                        {
                            if (dt_test.Rows[i][j].ToString().Trim().Contains("BPT_BP_ID"))
                            {
                                columnId = j;
                                break;
                            }
                        }
                    }

                    for (int i = 0; i < dt_test.Rows.Count - 1; i++)
                    {
                        if (dt_test.Rows[0][columnId].ToString().Trim().Contains("BPT_BP_ID"))
                        {
                            break;
                        }
                        else
                        {
                            dt_test.Rows.RemoveAt(0);
                        }
                    }
                restart:
                    for (int i = 0; i < dt_test.Columns.Count; i++)
                    {
                        if (dt_test.Rows[0][i].ToString().Trim() == "")
                        {
                            dt_test.Columns.RemoveAt(i);
                            goto restart;
                        }
                    }

                    dt_test.Columns.RemoveAt(15);
                    dt_test.Columns.RemoveAt(31);

                    //populate OLD NCA sca ID
                    for (int i = 0; i <= dt_test.Rows.Count - 1; i++)
                    {
                        if (dt_test.Rows[i][6].ToString().Trim() == "")
                        {
                            for (int j = 0; j <= dtexcel1.Rows.Count - 1; j++)
                            {
                                if (dt_test.Rows[i][8].ToString().Trim() == dtexcel1.Rows[j][0].ToString().Trim())
                                {
                                    dt_test.Rows[i][6] = dtexcel1.Rows[j][3].ToString();
                                }
                            }
                        }
                    }
                    //delete own name
                    for (int i = dt_test.Rows.Count - 1; i >= 0; i--)
                    {
                        if ((dt_test.Rows[i][20].ToString().Trim().ToLower() == "own name") || (dt_test.Rows[i][20].ToString().Trim().ToLower() == ""))
                        {
                            dt_test.Rows.RemoveAt(i);
                        }
                    }
                    //addding columns
                    dt_test.Columns.Add("44");
                    dt_test.Columns.Add("45");
                    dt_test.Columns.Add("46");
                    dt_test.Columns.Add("47");
                    dt_test.Columns.Add("48");
                    dt_test.Columns.Add("49");

                    for (int i = 0; i <= dt_test.Rows.Count - 1; i++)
                    {
                        for (int j = 0; j <= dtexcel1.Rows.Count - 1; j++)
                        {
                            //VSA SCA ID
                            if (dt_test.Rows[i][6].ToString().Trim() == dtexcel1.Rows[j][3].ToString().Trim())
                            {
                                if (dtexcel1.Rows[j][1].ToString().Trim().ToUpper().Contains("SCB"))
                                {
                                    dt_test.Rows[i][40] = dtexcel1.Rows[j][1];
                                    break;
                                }
                                else if (dtexcel1.Rows[j][4].ToString().Trim().ToUpper().Contains("SCB"))
                                {
                                    dt_test.Rows[i][40] = dtexcel1.Rows[j][4];
                                    break;
                                }
                                else
                                {
                                    dt_test.Rows[i][40] = "";
                                    break;
                                }
                            }
                        }
                    }
                    for (int i = 0; i <= dt_test.Rows.Count - 1; i++)
                    {
                        if (dt_test.Rows[i][6].ToString().Trim() == "")
                        {
                            dt_test.Rows[i][40] = "";
                        }
                    }
                    //populate based on security shortname for missing values
                    for (int i = 0; i <= dt_test.Rows.Count - 1; i++)
                    {
                        for (int j = 0; j <= dtexcel1.Rows.Count - 1; j++)
                        {
                            //populate based on security shortname for missing values
                            if (dt_test.Rows[i][14].ToString() == dtexcel1.Rows[j][0].ToString() || dt_test.Rows[i][14].ToString() == dtexcel1.Rows[j][5].ToString())
                            {
                                dt_test.Rows[i][41] = dtexcel1.Rows[j][4];
                                break;
                            }
                        }
                    }
                    for (int i = 0; i <= dt_test.Rows.Count - 1; i++)
                    {
                        for (int j = 0; j <= dtexcel1.Rows.Count - 1; j++)
                        {
                            //Local stock code
                            if (dt_test.Rows[i][13].ToString().Trim() == dtexcel1.Rows[j][0].ToString().Trim() && (dtexcel1.Rows[j][7].ToString().Trim().ToLower() == "vsd" || dtexcel1.Rows[j][2].ToString().Trim().ToLower() == "vsd"))
                            {
                                if (dt_test.Rows[i][41].ToString().Trim() != "")
                                {
                                    dt_test.Rows[i][41] = dtexcel1.Rows[j][1].ToString();
                                    break;
                                }

                            }
                            else
                            {
                                dt_test.Rows[i][41] = "NA";
                            }
                        }
                    }

                    for (int i = 0; i <= dt_test.Rows.Count - 1; i++)
                    {
                        if (!dt_test.Rows[i][40].ToString().Trim().Contains("SCB") && dt_test.Rows[i][40].ToString() != "")
                        {
                            for (int j = 0; j <= dtexcel1.Rows.Count - 1; j++)
                            {
                                if (dt_test.Rows[i][6].ToString().Trim() == dtexcel1.Rows[j][3].ToString().Trim())
                                {
                                    dt_test.Rows[i][40] = dtexcel1.Rows[j][1];
                                    break;
                                }
                            }
                        }
                    }

                    //delete non vsd values from Local Stock Code 
                    for (int i = dt_test.Rows.Count - 1; i >= 0; i--)
                    {
                        if (dt_test.Rows[i][40].ToString() == "")
                        {
                            for (int j = 0; j <= dtexcel1.Rows.Count - 1; j++)
                            {
                                if ((dt_test.Rows[i][41].ToString() == dtexcel1.Rows[j][1].ToString()) && dtexcel1.Rows[j][2].ToString().Trim().ToLower() != "vsd")
                                {
                                    if (dtexcel1.Rows[j][2].ToString().Trim().ToLower() != "")
                                    {
                                        dt_test.Rows.RemoveAt(i);
                                    }
                                    break;
                                }
                            }
                        }
                    }

                    for (int i = 0; i <= dt_test.Rows.Count - 1; i++)
                    {
                        if (dt_test.Rows[i][40].ToString().Trim() == "")
                        {
                            dt_test.Rows[i][40] = dt_test.Rows[i][6];
                        }
                    }

                    //delete non vsd values from VSD'SCA 
                    for (int i = dt_test.Rows.Count - 1; i >= 0; i--)
                    {
                        for (int j = 0; j <= dtexcel1.Rows.Count - 1; j++)
                        {
                            if ((dt_test.Rows[i][40].ToString() == dtexcel1.Rows[j][2].ToString() || dt_test.Rows[i][40].ToString() == dtexcel1.Rows[j][3].ToString()) && dtexcel1.Rows[j][7].ToString().Trim().ToLower() != "vsd")
                            {
                                if (dtexcel1.Rows[j][7].ToString().Trim().ToLower() != "")
                                {
                                    dt_test.Rows.RemoveAt(i);
                                }
                                break;
                            }
                        }
                    }

                    //delete non vsd values after checking Security Short Name
                    for (int i = dt_test.Rows.Count - 1; i >= 0; i--)
                    {
                        if (dt_test.Rows[i][41].ToString() == "NA")
                        {
                            for (int j = 0; j <= dtexcel1.Rows.Count - 1; j++)
                            {
                                if ((dt_test.Rows[i][16].ToString() == dtexcel1.Rows[j][0].ToString() || dt_test.Rows[i][17].ToString() == dtexcel1.Rows[j][1].ToString()) && dtexcel1.Rows[j][2].ToString().Trim().ToLower() != "vsd")
                                {
                                    if (dtexcel1.Rows[j][2].ToString().Trim().ToLower() != "")
                                    {
                                        dt_test.Rows.RemoveAt(i);
                                    }
                                    break;
                                }
                            }
                        }
                    }

                    //Replacing NA value to blank
                    for (int i = dt_test.Rows.Count - 1; i >= 0; i--)
                    {
                        if (dt_test.Rows[i][41].ToString() == "NA")
                        {
                            for (int j = 0; j <= dtexcel1.Rows.Count - 1; j++)
                            {
                                if (dt_test.Rows[i][13].ToString().Trim() == dtexcel1.Rows[j][0].ToString().Trim() && dtexcel1.Rows[j][2].ToString().Trim().ToLower() != "vsd")
                                {
                                    if (dtexcel1.Rows[j][2].ToString().Trim().ToLower() != "")
                                    {
                                        dt_test.Rows.RemoveAt(i);
                                    }
                                    break;
                                }
                                else
                                {
                                    dt_test.Rows[i][41] = "";
                                }
                            }
                        }
                    }

                    //con values apply formula
                    for (int i = 0; i <= dt_test.Rows.Count - 1; i++)
                    {
                        for (int j = 0; j <= dtexcel1.Rows.Count - 1; j++)
                        {
                            dt_test.Rows[i][42] = dt_test.Rows[i][40].ToString() + dt_test.Rows[i][41].ToString();
                        }
                    }

                    // Qty column subtract formula and sale con
                    for (int i = 0; i <= dt_test.Rows.Count - 1; i++)
                    {
                        double d1 = Convert.ToDouble(dt_test.Rows[i][27].ToString());
                        double d2 = Convert.ToDouble(dt_test.Rows[i][32].ToString());
                        double d3 = d1 - d2;
                        dt_test.Rows[i][43] = d3.ToString("#.00");
                        dt_test.Rows[i][44] = dt_test.Rows[i][6].ToString() + dt_test.Rows[i][41].ToString();
                    }

                    string strConn2;

                    string mm = Output_Path.Substring(0, Output_Path.LastIndexOf("\\")) + "\\";
                    string[] files2 = Directory.GetFiles(mm);
                    string actfile = "";

                    for (int i = 0; i < files2.Length; i++)
                    {
                        files2[i] = Path.GetFileName(files2[i]);
                        if (files2[i].Contains("TRADE WORKINGS"))
                        {
                            actfile = files2[i];
                        }

                    }
                    string flPath2 = mm + actfile;
                    strConn2 = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + flPath2 + ";Extended Properties=\"Excel 12.0;HDR=Yes;IMEX=1\"";

                    System.Data.DataTable dtexcel2 = new System.Data.DataTable();
                    OleDbConnection conn2 = new OleDbConnection(strConn2);

                    conn2.Open();

                    string sheet2 = "Sheet4$";
                    string query2 = "SELECT  * FROM [" + sheet2 + "]";
                    OleDbDataAdapter daexcel2 = new OleDbDataAdapter(query2, conn2);
                    dtexcel2.Locale = System.Globalization.CultureInfo.CurrentCulture;
                    daexcel2.Fill(dtexcel2);
                    dt_test.Columns.Add("50");
                    for (int i = 0; i <= dt_test.Rows.Count - 1; i++)
                    {
                        double dds = 0.0f;
                        for (int j = 0; j <= dtexcel2.Rows.Count - 1; j++)
                        {
                            if (dt_test.Rows[i][44].ToString().Trim() == dtexcel2.Rows[j][7].ToString().Trim())
                            {
                                dds = dds + Convert.ToDouble(dtexcel2.Rows[j][5].ToString());
                                dt_test.Rows[i][45] = dds;
                            }
                        }
                    }
                    for (int i = 0; i <= dt_test.Rows.Count - 1; i++)
                    {
                        if (dt_test.Rows[i][45].ToString() == "")
                        {
                            dt_test.Rows[i][45] = "-";
                        }
                    }
                    for (int i = 0; i <= dt_test.Rows.Count - 1; i++)
                    {
                        if (dt_test.Rows[i][45].ToString() == "-")
                        {
                            double d1 = Convert.ToDouble(dt_test.Rows[i][43].ToString());
                            double d2 = Convert.ToDouble(0.00);
                            double d3 = d1 - d2;
                            dt_test.Rows[i][46] = d3.ToString("0.00");
                        }
                        else
                        {
                            double d1 = Convert.ToDouble(dt_test.Rows[i][43].ToString());
                            double d2 = Convert.ToDouble(dt_test.Rows[i][45].ToString());
                            double d3 = d1 - d2;
                            dt_test.Rows[i][46] = d3.ToString("0.00");
                        }
                    }
                    #region Dt Column Add
                    System.Data.DataTable dt3 = new System.Data.DataTable();
                    dt3.Columns.Add("BPT_BP_ID");
                    dt3.Columns.Add("OLD NCS BP ID");
                    dt3.Columns.Add("Group BP");
                    dt3.Columns.Add("BP Short Name");
                    dt3.Columns.Add("BP Full Name");
                    dt3.Columns.Add("SCA ID");
                    dt3.Columns.Add("OLD NCS SCA ID");
                    dt3.Columns.Add("Group SCA");
                    dt3.Columns.Add("SCA Short Name");
                    dt3.Columns.Add("SCA Full Name");
                    dt3.Columns.Add("SCA_TAX_DMCL");
                    dt3.Columns.Add("SCA PRPS");
                    dt3.Columns.Add("Security ID");
                    dt3.Columns.Add("ISIN");
                    dt3.Columns.Add("Sec Depo Code");
                    dt3.Columns.Add("Client Customised Security Code");
                    dt3.Columns.Add("SEC_PRNCPL_DPSTRY");
                    dt3.Columns.Add("Security Short Name");
                    dt3.Columns.Add("Security Full Name");
                    dt3.Columns.Add("Security Category");
                    dt3.Columns.Add("Security Sub Type");
                    dt3.Columns.Add("Registration Type");
                    dt3.Columns.Add("CE");
                    dt3.Columns.Add("SE");
                    dt3.Columns.Add("Agent Depo");
                    dt3.Columns.Add("Place of settlement");
                    dt3.Columns.Add("A/c at Agent/Depo");
                    dt3.Columns.Add("Booking Basis");
                    dt3.Columns.Add("Settled Balance");
                    dt3.Columns.Add("Qty Available");
                    dt3.Columns.Add("Price Ccy");
                    dt3.Columns.Add("MARKET PRICE");
                    dt3.Columns.Add("Local Currency");
                    dt3.Columns.Add("Portfolio Value");
                    dt3.Columns.Add("QTY BLOCKED");
                    dt3.Columns.Add("Lent Balance");
                    dt3.Columns.Add("Anticipated CR");
                    dt3.Columns.Add("Anticipated DR");
                    dt3.Columns.Add("TODAY CREDITS");
                    dt3.Columns.Add("TODAY DEBITS");
                    dt3.Columns.Add("TOMORROW CREDITS");
                    dt3.Columns.Add("TOMORROW DEBITS");
                    dt3.Columns.Add("VSD' SCA");
                    dt3.Columns.Add("Local stock code");
                    dt3.Columns.Add("Con");
                    dt3.Columns.Add("QTY");
                    dt3.Columns.Add("Sale con");
                    dt3.Columns.Add("Sale QTY");
                    dt3.Columns.Add("TOTAL");
                    #endregion
                    for (int i = 0; i <= dt_test.Rows.Count - 1; i++)
                    {
                        dt3.Rows.Add();
                        #region Data Adding in dt
                        dt3.Rows[i][0] = dt_test.Rows[i][0];
                        dt3.Rows[i][1] = dt_test.Rows[i][1];
                        dt3.Rows[i][2] = dt_test.Rows[i][2];
                        dt3.Rows[i][3] = dt_test.Rows[i][3];
                        dt3.Rows[i][4] = dt_test.Rows[i][4];
                        dt3.Rows[i][5] = dt_test.Rows[i][5];
                        dt3.Rows[i][6] = dt_test.Rows[i][6];
                        dt3.Rows[i][7] = dt_test.Rows[i][7];
                        dt3.Rows[i][8] = dt_test.Rows[i][8];
                        dt3.Rows[i][9] = dt_test.Rows[i][9];
                        dt3.Rows[i][10] = dt_test.Rows[i][10];
                        dt3.Rows[i][11] = dt_test.Rows[i][11];
                        dt3.Rows[i][12] = dt_test.Rows[i][12];
                        dt3.Rows[i][13] = dt_test.Rows[i][13];
                        dt3.Rows[i][14] = dt_test.Rows[i][14];
                        dt3.Rows[i][15] = "";
                        dt3.Rows[i][16] = dt_test.Rows[i][15];
                        dt3.Rows[i][17] = dt_test.Rows[i][16];
                        dt3.Rows[i][18] = dt_test.Rows[i][17];
                        dt3.Rows[i][19] = dt_test.Rows[i][18];
                        dt3.Rows[i][20] = dt_test.Rows[i][19];
                        dt3.Rows[i][21] = dt_test.Rows[i][20];
                        dt3.Rows[i][22] = dt_test.Rows[i][21];
                        dt3.Rows[i][23] = dt_test.Rows[i][22];
                        dt3.Rows[i][24] = dt_test.Rows[i][23];
                        dt3.Rows[i][25] = dt_test.Rows[i][24];
                        dt3.Rows[i][26] = dt_test.Rows[i][25];
                        dt3.Rows[i][27] = dt_test.Rows[i][26];
                        dt3.Rows[i][28] = dt_test.Rows[i][27];
                        dt3.Rows[i][29] = dt_test.Rows[i][28];
                        dt3.Rows[i][30] = dt_test.Rows[i][29];
                        dt3.Rows[i][31] = dt_test.Rows[i][30];
                        dt3.Rows[i][32] = "";
                        dt3.Rows[i][33] = dt_test.Rows[i][31];
                        dt3.Rows[i][34] = dt_test.Rows[i][32];
                        dt3.Rows[i][35] = dt_test.Rows[i][33];

                        dt3.Rows[i][36] = dt_test.Rows[i][34];
                        dt3.Rows[i][37] = dt_test.Rows[i][35];
                        dt3.Rows[i][38] = dt_test.Rows[i][36];
                        dt3.Rows[i][39] = dt_test.Rows[i][37];
                        dt3.Rows[i][40] = "'" + dt_test.Rows[i][38];
                        dt3.Rows[i][41] = dt_test.Rows[i][39];
                        dt3.Rows[i][42] = dt_test.Rows[i][40];
                        dt3.Rows[i][43] = dt_test.Rows[i][41];
                        dt3.Rows[i][44] = dt_test.Rows[i][42];
                        dt3.Rows[i][45] = dt_test.Rows[i][43];
                        dt3.Rows[i][46] = "'" + dt_test.Rows[i][44];
                        dt3.Rows[i][47] = dt_test.Rows[i][45];
                        dt3.Rows[i][48] = dt_test.Rows[i][46];
                        #endregion
                    }


                    System.Data.DataTable dt5 = new System.Data.DataTable();
                    decimal dfin2 = 0.0m;
                    dt5.Columns.Add("Row Labels");
                    dt5.Columns.Add("Sum of TOTAL");
                    for (int i = 0; i <= dt3.Rows.Count - 1; i++)
                    {
                        dt5.Rows.Add();
                        dt5.Rows[i][0] = dt3.Rows[i][44];
                        if (dt3.Rows[i][48].ToString() != "")
                        {
                            decimal dini = Convert.ToDecimal(dt3.Rows[i][48].ToString().Replace("'", ""));

                            dt5.Rows[i][1] = dini.ToString("#.00");
                            dfin2 = dfin2 + Convert.ToDecimal(dt3.Rows[i][48].ToString().Replace("'", ""));
                        }
                    }

                    Hashtable hat = new Hashtable();
                    for (int i = 0; i < dt5.Rows.Count; i++)
                    {
                        string name = dt5.Rows[i][0].ToString();
                        Double value = Convert.ToDouble(dt5.Rows[i][1].ToString());
                        if (hat.Contains(name))
                        {
                            Double dcn = Convert.ToDouble(hat[name]) + value;
                            hat[name] = dcn;
                        }
                        else
                        {
                            hat.Add(name, value);
                        }
                    }
                    System.Data.DataTable dt4 = new System.Data.DataTable();
                    dt4.Columns.Add("Row Labels");
                    dt4.Columns.Add("Sum of TOTAL");

                    foreach (DictionaryEntry d in hat)
                    {
                        DataRow dro = dt4.NewRow();
                        dro[0] = d.Key.ToString();
                        dro[1] = "'" + d.Value.ToString();
                        dt4.Rows.Add(dro);
                    }

                    dt4.Rows.Add();
                    dt4.Rows[dt4.Rows.Count - 1][0] = "Grand Total";
                    dt4.Rows[dt4.Rows.Count - 1][1] = "'" + dfin2.ToString("#.00");
                    DataSet ds1 = new DataSet("STATEMENT");
                    ds1.Tables.Add(dt1);
                    DataSet ds2 = new DataSet("STATEMENT PIVOT");
                    ds2.Tables.Add(dt2);
                    DataSet ds3 = new DataSet("Seccure");
                    ds3.Tables.Add(dt3);
                    DataSet ds4 = new DataSet("SECCURE PIVOT");
                    ds4.Tables.Add(dt4);
                    List<DataSet> dataSets = new List<DataSet>();
                    dataSets.Add(ds1);
                    dataSets.Add(ds2);
                    dataSets.Add(ds3);
                    dataSets.Add(ds4);
                    DataSetsToExcel_VN(dataSets, Output_Path + Formatted_File_Name);


                    //Sankalp 14 Sept
                    //Statement Pivot

                    System.Data.DataTable dt12 = new System.Data.DataTable();
                    dt12.Columns.Add("Row Labels");
                    dt12.Columns.Add("Secure");
                    dt12.Columns.Add("Statement");
                    dt12.Columns.Add("Diff");
                    int x = 0;
                    for (int i = 0; i < dt2.Rows.Count; i++)
                    {
                        for (int j = 0; j < dt4.Rows.Count; j++)
                        {
                            if (string.IsNullOrEmpty(dt2.Rows[i][0].ToString()) == false && string.IsNullOrEmpty(dt4.Rows[j][0].ToString()) == false)
                            {

                                if (dt2.Rows[i][0].ToString().Trim().Replace("'", "") == dt4.Rows[j][0].ToString().Trim())
                                {
                                    dt12.Rows.Add();
                                    dt12.Rows[x][0] = dt2.Rows[i][0].ToString();
                                    dt12.Rows[x][1] = dt2.Rows[i][1].ToString();
                                    dt12.Rows[x][2] = dt4.Rows[j][1].ToString();
                                    dt12.Rows[x][3] = Convert.ToString(Convert.ToDouble(dt12.Rows[x][1].ToString().Trim().Replace("'", "")) - Convert.ToDouble(dt12.Rows[x][2].ToString().Trim().Replace("'", "")));
                                    dt12.AcceptChanges();
                                    x++;
                                }
                            }

                        }

                    }

                    System.Data.DataTable dt13 = new System.Data.DataTable();
                    dt13.Columns.Add("Row Labels");
                    dt13.Columns.Add("Statement");
                    dt13.Columns.Add("Secure");
                    dt13.Columns.Add("Diff");
                    int y = 0;
                    for (int i = 0; i < dt4.Rows.Count; i++)
                    {
                        for (int j = 0; j < dt2.Rows.Count; j++)
                        {
                            if (string.IsNullOrEmpty(dt4.Rows[i][0].ToString()) == false && string.IsNullOrEmpty(dt2.Rows[j][0].ToString()) == false)
                            {


                                if (dt4.Rows[i][0].ToString().Trim() == dt2.Rows[j][0].ToString().Trim().Replace("'", ""))
                                {
                                    dt13.Rows.Add();
                                    dt13.Rows[y][0] = dt4.Rows[i][0].ToString();
                                    dt13.Rows[y][1] = dt4.Rows[i][1].ToString();
                                    dt13.Rows[y][2] = dt2.Rows[j][1].ToString();
                                    dt13.Rows[y][3] = Convert.ToString(Convert.ToDouble(dt13.Rows[y][1].ToString().Trim().Replace("'", "")) - Convert.ToDouble(dt13.Rows[y][2].ToString().Trim().Replace("'", "")));
                                    dt13.AcceptChanges();
                                    y++;
                                }

                            }

                        }

                    }
                    DataSet ds6 = new DataSet("SECURE PIVOT");
                    ds6.Tables.Add(dt12);
                    DataSet ds7 = new DataSet("STATEMENT PIVOT");
                    ds7.Tables.Add(dt13);
                    List<DataSet> dataSets1 = new List<DataSet>();
                    dataSets1.Add(ds6);
                    dataSets1.Add(ds7);
                    Formatted_File_Name = @"COMPARITIONAS ON DD.MM.YYYY.xlsx";

                    DataSetsToExcel_VN(dataSets1, Output_Path + Formatted_File_Name);
                }
            }
            catch
            {
                app.Quit();
                ReleaseComObject(wb);
                ReleaseComObject(app);

            }
        }


        public void DataSetsToExcel_VN(List<DataSet> dataSets, string fileName)
        {
            try
            {
                Microsoft.Office.Interop.Excel.Application xlApp =
                          new Microsoft.Office.Interop.Excel.Application();
                Workbook xlWorkbook = xlApp.Workbooks.Add(XlWBATemplate.xlWBATWorksheet);
                Sheets xlSheets = null;
                Worksheet xlWorksheet = null;

                foreach (DataSet dataSet in dataSets)
                {
                    System.Data.DataTable dataTable = dataSet.Tables[0];
                    int rowNo = dataTable.Rows.Count;
                    int columnNo = dataTable.Columns.Count;
                    int colIndex = 0;

                    //Create Excel Sheets
                    xlSheets = xlWorkbook.Sheets;
                    xlWorksheet = (Worksheet)xlSheets.Add(xlSheets[1],
                                   Type.Missing, Type.Missing, Type.Missing);
                    xlWorksheet.Name = dataSet.DataSetName;

                    //Generate Field Names
                    foreach (DataColumn dataColumn in dataTable.Columns)
                    {
                        colIndex++;
                        xlApp.Cells[1, colIndex] = dataColumn.ColumnName;
                    }

                    object[,] objData = new object[rowNo, columnNo];

                    //Convert DataSet to Cell Data
                    for (int row = 0; row < rowNo; row++)
                    {
                        for (int col = 0; col < columnNo; col++)
                        {
                            objData[row, col] = dataTable.Rows[row][col];
                        }
                    }

                    //Add the Data
                    Range range = xlWorksheet.Range[xlApp.Cells[2, 1], xlApp.Cells[rowNo + 1, columnNo]];
                    range.Value2 = objData;

                    //Format Data Type of Columns 
                    colIndex = 0;
                    foreach (DataColumn dataColumn in dataTable.Columns)
                    {
                        colIndex++;
                        string format = "@";
                        switch (dataColumn.DataType.Name)
                        {
                            case "Boolean":
                                break;
                            case "Byte":
                                break;
                            case "Char":
                                break;
                            case "DateTime":
                                format = "dd/mm/yyyy";
                                break;
                            case "Decimal":
                                format = "$* #,##0.00;[Red]-$* #,##0.00";
                                break;
                            case "Double":
                                break;
                            case "Int16":
                                format = "0";
                                break;
                            case "Int32":
                                format = "0";
                                break;
                            case "Int64":
                                format = "0";
                                break;
                            case "SByte":
                                break;
                            case "Single":
                                break;
                            case "TimeSpan":
                                break;
                            case "UInt16":
                                break;
                            case "UInt32":
                                break;
                            case "UInt64":
                                break;
                            default: //String
                                break;
                        }
                        //Format the Column according to Data Type
                        xlWorksheet.Range[xlApp.Cells[2, colIndex],
                              xlApp.Cells[rowNo + 1, colIndex]].NumberFormat = format;
                    }
                }

                //Remove the Default Worksheet
                ((Worksheet)xlApp.ActiveWorkbook.Sheets[xlApp.ActiveWorkbook.Sheets.Count]).Delete();

                //Save
                xlWorkbook.SaveAs(fileName,
                    System.Reflection.Missing.Value,
                    System.Reflection.Missing.Value,
                    System.Reflection.Missing.Value,
                    System.Reflection.Missing.Value,
                    System.Reflection.Missing.Value,
                    XlSaveAsAccessMode.xlNoChange,
                    System.Reflection.Missing.Value,
                    System.Reflection.Missing.Value,
                    System.Reflection.Missing.Value,
                    System.Reflection.Missing.Value,
                    System.Reflection.Missing.Value);

                xlWorkbook.Close();
                xlApp.Quit();
                GC.Collect();
            }
            catch
            {
            }
        }
        public void ReleaseComObject(object ob)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(ob);
                ob = null;
            }
            catch
            {
                ob = null;
            }
            finally
            {
                GC.Collect(GC.MaxGeneration);
                GC.WaitForPendingFinalizers();
            }
        }
    }
}
