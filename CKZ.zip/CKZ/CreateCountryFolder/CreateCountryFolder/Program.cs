﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Data.SqlClient;
using System.Data;
using System.Collections;
using ARC_Opics_DLL;
using System.Timers;

namespace CreateCountryFolder
{
    class Program
    {
        static System.Timers.Timer aTimer = new System.Timers.Timer();
        //string remoteDirStr = @"\\10.193.107.47\tlm_user_upload\TLMRPSNS\";
        //string remoteDirStr = string.Empty;
        static string constring = @"Data Source=UKWVIDSQL01I2.ZONE1.SCBDEV.NET\UAT_CL01_IN01,10502;Initial Catalog=CRC_QMT;User ID=CRCQMTUser;Password=eeSmd6fEu;";
        static string path1 = @"\\10.132.5.78\DataManagement\rpa\Country_Shared Drive\Zimbabwe_Country Sharedrive\" + DateTime.Today.ToString("dd-MMM-yyyy") + "\\";
        static string strdir = @"\\10.132.5.78\DataManagement\rpa\Country_Shared Drive\";
        static string MainString = @"\\10.132.5.78\DataManagement\rpa\ARC_UAT\" + DateTime.Today.ToString("dd-MMM-yyyy") + "_Files\\";
            
        static void Main(string[] args)
        {
            SqlConnection conn = new SqlConnection(constring);
            conn.Open();
            string UserID = System.Environment.UserName;
            string qrry1 = "select Is_FirstTimeLogin from dbo.ARC_User_Info where UserID=@UserID";
            SqlCommand com = new SqlCommand(qrry1, conn);
            com.Parameters.AddWithValue("@UserID", UserID);
            SqlDataReader dr1 = com.ExecuteReader();
            while (dr1.Read())
            {
                aTimer.Elapsed += new ElapsedEventHandler(OnTimedEvent);
                aTimer.Interval = (30000);  // 60 sec.
                aTimer.Enabled = true;
                aTimer.Start();
                //Console.WriteLine("Press \'q\' then Press Enter...! to quit the timer.");
                while (Console.Read() != 'q') ;
            }
                      
        }

        public static void OnTimedEvent(object source, ElapsedEventArgs e)
        {
            Program p = new Program();
            Console.WriteLine("Email to Share Drive code Start at -->>" + DateTime.Now.ToShortTimeString());
            try
            {
               
                p.Create_Directory_Chk(constring, path1);
                p.Folder_Movement_ChkRecon(constring, MainString, strdir);
                p.Folder_Movement_Formatting3_2(MainString, constring, strdir);  
                
                aTimer.Start();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                Console.ReadLine();
                aTimer.Start();
            }
            Console.WriteLine("Email to Share Drive code End at -->>" + DateTime.Now.ToShortTimeString());
        }

        public void Create_Directory_Chk(string conStr, string Main_DIR_SharePath)
        {
            aTimer.Stop();
            DataRow[] dr;
            try
            {
                
                if (!Directory.Exists(Main_DIR_SharePath))
                {
                    Directory.CreateDirectory(Main_DIR_SharePath);
                }
               // string filePath = Main_DIR_SharePath + "MailFoldersCreate_Info.txt";
                //bool IsRunning = IsExeRunning(filePath);
                bool IsRunning = false;
                if (IsRunning == false)
                {
                    System.Data.DataTable Share_Folder = new System.Data.DataTable();
                    Share_Folder = QueryValues_FolderCreation(conStr);
                    string Folderpath = string.Empty;
                    dr = Share_Folder.Select();
                    foreach (DataRow d in dr)
                    {
                        //string Email_Shared_Path = Convert.ToString(d["Email_Shared_Path"]);
                        string Email_Shared_Path = @"\\10.132.5.78\DataManagement\rpa\Country_Shared Drive\";
                        //string Email_Shared_Path = @"C:\10.132.5.214\Country_Shared Drive\";
                        string Country_Name = Convert.ToString(d["Country_Name"]) + "_Country Sharedrive";
                        if (Email_Shared_Path != "")
                        {
                            if (!Directory.Exists(Email_Shared_Path))
                            {
                                Directory.CreateDirectory(Email_Shared_Path);
                            }
                            if (DateTime.Today.DayOfWeek.ToString() != "Friday")
                            {
                                if (!Directory.Exists(Email_Shared_Path + "\\" + Country_Name + "\\" + DateTime.Today.AddDays(-1).ToString("dd-MMM-yyyy")))
                                {
                                    Directory.CreateDirectory(Email_Shared_Path + "\\" + Country_Name + "\\" + DateTime.Today.AddDays(-1).ToString("dd-MMM-yyyy"));
                                }
                                if (!Directory.Exists(Email_Shared_Path + "\\" + Country_Name + "\\" + DateTime.Today.ToString("dd-MMM-yyyy")))
                                {
                                    Directory.CreateDirectory(Email_Shared_Path + "\\" + Country_Name + "\\" + DateTime.Today.ToString("dd-MMM-yyyy"));
                                }
                                if (!Directory.Exists(Email_Shared_Path + "\\" + Country_Name + "\\" + DateTime.Today.AddDays(+1).ToString("dd-MMM-yyyy")))
                                {
                                    Directory.CreateDirectory(Email_Shared_Path + "\\" + Country_Name + "\\" + DateTime.Today.AddDays(+1).ToString("dd-MMM-yyyy"));
                                }

                            }
                            else
                            {
                                if (!Directory.Exists(Email_Shared_Path + "\\" + Country_Name + "\\" + DateTime.Today.ToString("dd-MMM-yyyy")))
                                {
                                    Directory.CreateDirectory(Email_Shared_Path + "\\" + Country_Name + "\\" + DateTime.Today.ToString("dd-MMM-yyyy"));
                                }
                                if (!Directory.Exists(Email_Shared_Path + "\\" + Country_Name + "\\" + DateTime.Today.AddDays(+1).ToString("dd-MMM-yyyy")))
                                {
                                    Directory.CreateDirectory(Email_Shared_Path + "\\" + Country_Name + "\\" + DateTime.Today.AddDays(+1).ToString("dd-MMM-yyyy"));
                                }
                                if (!Directory.Exists(Email_Shared_Path + "\\" + Country_Name + "\\" + DateTime.Today.AddDays(+2).ToString("dd-MMM-yyyy")))
                                {
                                    Directory.CreateDirectory(Email_Shared_Path + "\\" + Country_Name + "\\" + DateTime.Today.AddDays(+2).ToString("dd-MMM-yyyy"));
                                }
                                if (!Directory.Exists(Email_Shared_Path + "\\" + Country_Name + "\\" + DateTime.Today.AddDays(+3).ToString("dd-MMM-yyyy")))
                                {
                                    Directory.CreateDirectory(Email_Shared_Path + "\\" + Country_Name + "\\" + DateTime.Today.AddDays(+3).ToString("dd-MMM-yyyy"));
                                }
                            }
                        }
                    }
                    //continue;

                }
            }
           
            catch
            {
                //int d11 
                aTimer.Start();
            }
        }
        public void Folder_Movement_ChkRecon(string conString, string Main_DIR_SharePath, string strDirectory)
        {
            aTimer.Stop();
            string Country_Path = string.Empty;
            string InputFolder_Path = string.Empty;
            string[] mul = null;

            //SA1001
            try
            {
                System.Data.DataTable dt_Recon = new System.Data.DataTable();
                SqlConnection con = new SqlConnection(conString);
                SqlCommand cmd = new SqlCommand();
                //Individual Recons
                //SqlDataAdapter ad = new SqlDataAdapter("select * from ARC_Recon_Master where Recon_Name = 'Vietnam - Open Item'", con);

                //All Recons
                SqlDataAdapter ad = new SqlDataAdapter("select * from ARC_Recon_Master where Is_Recon_Completed = 0 and Is_Active = 1 and isMailDownloadComplete=0 and Is_Holiday_Logic = 0 order by Receipt_Time ASC", con);

                con.Open();
                ad.Fill(dt_Recon);
                DataRow[] drr = dt_Recon.Select();

                con.Close();
                for (int i = 0; i < dt_Recon.Rows.Count; i++)
                {

                    int files_moved_count = 0;
                    System.Data.DataTable Share_Folder = new System.Data.DataTable();
                    Share_Folder = QueryValues_ChkRecons(conString);

                    DataRow[] dr = Share_Folder.Select();

                    foreach (DataRow d in dr)
                    {
                        string Country = Convert.ToString(d["Country_Name"]);
                        string File_Name = Convert.ToString(d["Report_Source_File_Name"]);
                        string IsFormatting = Convert.ToString(d["Format_Direct_Upload"]);
                        string Source_App = Convert.ToString(d["Source_Application"]);
                        string File_Ext = Convert.ToString(d["File_Format"]);
                        string Receipt_Time = Convert.ToString(d["Receipt_Time"]);
                        string Email_Shared_Path = Convert.ToString(d["Email_Shared_Path"]);
                        string Recon = Convert.ToString(d["Recon"]);
                        //if (Recon == "VIETNAM VND OPEN ITEMS (CITAD)")
                        //{
                        
                        //}
                        string Email_Subject = Convert.ToString(d["Email_Subject"]);
                        string Email_ID = Convert.ToString(d["Email_ID"]);
                        string product_id = Convert.ToString(d["product_id"]);
                        int Recon_Id = Convert.ToInt32(d["Recon_ID"]);
                        bool foldermovement_complete = Convert.ToBoolean(d["foldermovement_complete"]);
                        bool isMailFunctionalityRequired = Convert.ToBoolean(d["isMailFunctionalityRequired"]);
                        var time = TimeSpan.Parse(Receipt_Time);
                        var dateTime = DateTime.Today.Add(time);

                        var diff = dateTime.Subtract(DateTime.Now);

                        double Hour = Convert.ToDouble(diff.Hours);
                        double Min = Convert.ToDouble(diff.Minutes);
                        double Sec = Convert.ToDouble(diff.Seconds);
                        //var res = String.Format("{0}:{1}:{2}", diff.Hours,diff.Minutes,diff.Seconds));

                        double converter = Hour * 60 + Min + (Sec / 60);
                        System.Data.DataTable dtt = new System.Data.DataTable();
                        SqlDataAdapter ad1 = new SqlDataAdapter("select count(*) from ARC_scope_baseline where source_application = 'Email' and foldermovement_complete=0 and Recon_id in (select Recon_id from ARC_recon_master where isMailDownloadComplete=0 and Recon_id='" + Recon_Id + "')", con);
                        con.Open();
                        ad1.Fill(dtt);
                        con.Close();
                        if (File_Name.Contains("YYYY_MM_DD"))
                        {
                            File_Name = File_Name.Replace("YYYY_MM_DD", "");
                        }
                        else if (File_Name.Contains("YYYY_MM_DD"))
                        {
                            File_Name = File_Name.Replace("YYYY_MM_DD", "");
                        }
                        else if (File_Name.Contains("DD-MMM YYYY"))
                        {
                            File_Name = File_Name.Replace("DD-MMM YYYY", "").Trim();
                        }
                        else if (File_Name.Contains("DD-MMM"))
                        {
                            File_Name = File_Name.Replace("DD-MMM", "");
                        }
                        else if (File_Name.Contains("DD-MM"))
                        {
                            File_Name = File_Name.Replace("DD-MM", "");
                        }
                        else if (File_Name.Contains("DD.MM.YYYY"))
                        {
                            File_Name = File_Name.Replace("DD.MM.YYYY", "");
                        }
                        else if (File_Name.Contains("DD_MM_YYYY"))
                        {
                            File_Name = File_Name.Replace("DD_MM_YYYY", "");
                        }
                        else if (File_Name.Contains("DD-MM-YYYY"))
                        {
                            File_Name = File_Name.Replace("DD-MM-YYYY", "");
                        }
                        else if (File_Name.Contains("MM.DD.YYYY"))
                        {
                            File_Name = File_Name.Replace("MM.DD.YYYY", "");
                        }
                        else if (File_Name.Contains("DDMMYYYY"))
                        {
                            File_Name = File_Name.Replace("DDMMYYYY", "");
                        }
                        else if (File_Name.Contains("DDMMYY"))
                        {
                            File_Name = File_Name.Replace("DDMMYY", "");
                        }
                        else if (File_Name.Contains("YYYYMMDD"))
                        {
                            File_Name = File_Name.Replace("YYYYMMDD", "");
                        }
                        else if (File_Name.Contains("YYYY-MM-DD"))
                        {
                            File_Name = File_Name.Replace("YYYY-MM-DD", "");
                        }
                        else if (File_Name.Contains("DD MMM YY"))
                        {
                            File_Name = File_Name.Replace("DD MMM YY", "");
                        }
                        else if (File_Name.Contains("DD MM YY"))
                        {
                            File_Name = File_Name.Replace("DD MM YY", "");
                        }
                        else if (File_Name.Contains("DD_MM"))
                        {
                            File_Name = File_Name.Replace("DD_MM", "");
                        }
                        else if (File_Name.Contains("YYDDMM"))
                        {
                            File_Name = File_Name.Replace("YYDDMM", "");
                        }
                        else if (File_Name.Contains("YYYY-MM"))
                        {
                            File_Name = File_Name.Replace("YYYY-MM", "");
                        }
                        else if (File_Name.Contains("DD.MM.YY"))
                        {
                            File_Name = File_Name.Replace("DD.MM.YY", "");
                        }
                        else if (File_Name.Contains("DDMM-DDMM"))
                        {
                            File_Name = File_Name.Replace("DDMM-DDMM", "");
                        }

                        //File_Name = GetFileName_ChkRecMulfiles(Email_Shared_Path + Country + "_Country Sharedrive\\" + DateTime.Today.ToString("dd-MMM-yyyy") + "\\", File_Name);
                        File_Name = GetFileName_ChkRecMulfiles(@"\\10.132.5.78\DataManagement\RPA\Country_Shared Drive\" + Country + "_Country Sharedrive\\" + DateTime.Today.ToString("dd-MMM-yyyy") + "\\", File_Name);
                        if (File_Name.Contains(','))
                        {
                            mul = File_Name.Split(',');
                            if (mul.Length > 2)
                            {
                                for (int x = 0; x <= mul.Length - 1; x++)
                                {
                                    if (mul[x].ToString() != "")
                                    {
                                        InputFolder_Path = Main_DIR_SharePath + "\\Input\\Emails\\" + mul[x].ToString().Trim() + "." + File_Ext;
                                        Country_Path = Email_Shared_Path + Country + "_Country Sharedrive\\" + DateTime.Today.ToString("dd-MMM-yyyy") + "\\" + mul[x].ToString().Trim() + "." + File_Ext;

                                        if (foldermovement_complete == false && File.Exists(Country_Path))
                                        {
                                            if (File.Exists(InputFolder_Path))
                                            {
                                                File.Delete(InputFolder_Path);
                                            }

                                            File.Copy(Country_Path, InputFolder_Path);
                                            files_moved_count = files_moved_count + 1;

                                        }
                                    }
                                    string query1 = "Update ARC_scope_baseline set Foldermovement_Complete = 1 where Recon_ID = '" + Recon_Id + "'";

                                    SqlConnection con1 = new SqlConnection(conString);
                                    SqlCommand cmd1 = new SqlCommand(query1, con1);
                                    if (con1.State == ConnectionState.Closed)
                                    {
                                        con1.Open();
                                    }
                                    cmd1.ExecuteNonQuery();
                                    if (con1.State == ConnectionState.Open)
                                    {
                                        con1.Close();
                                    }
                                    if (dt_Recon.Rows[i]["MailFilesReq"].ToString().Trim() != "")
                                    {
                                        if (files_moved_count == Convert.ToInt32(mul.Length - 1) * Convert.ToInt32(dt_Recon.Rows[i]["MailFilesReq"].ToString()))
                                        {

                                            SqlConnection conn = new SqlConnection(conString);
                                            SqlCommand Updt_cmd2 = new SqlCommand("update ARC_Recon_Master set IsMailDownloadComplete=1 where Recon_Id = " + Recon_Id + "", conn);
                                            conn.Open();
                                            Updt_cmd2.ExecuteNonQuery();
                                            conn.Close();

                                        }
                                    }
                                }
                            }
                        }

                        if (mul == null)
                        {
                            FileCopyUpdate(conString, File_Name, @"\\10.132.5.78\DataManagement\RPA\Country_Shared Drive\", Country, InputFolder_Path, Country_Path, File_Ext, Share_Folder, Recon, Email_ID, isMailFunctionalityRequired, foldermovement_complete, converter, files_moved_count, i, Recon_Id, dt_Recon, product_id, Main_DIR_SharePath, strDirectory);
                        }
                        else if (mul != null)
                        {
                            if (mul.Length <= 2)
                            {
                                FileCopyUpdate(conString, File_Name, @"\\10.132.5.78\DataManagement\RPA\Country_Shared Drive\", Country, InputFolder_Path, Country_Path, File_Ext, Share_Folder, Recon, Email_ID, isMailFunctionalityRequired, foldermovement_complete, converter, files_moved_count, i, Recon_Id, dt_Recon, product_id, Main_DIR_SharePath, strDirectory);
                            }
                        }


                        //SourcePath = StrDirectory + "Input\\" + Source_Application + "_" + Country_Name + "\\";

                    }
                }
            }
            catch 
            {
                aTimer.Start();
                //Console.WriteLine(ex.ToString());
            }
        }

        public static bool IsExeRunning(string filePath)
        {

            if (!File.Exists(filePath))
            {
                FileStream aFile = new FileStream(filePath, FileMode.CreateNew, FileAccess.Write);
                StreamWriter sw = new StreamWriter(aFile);
                sw.Write("User Id: " + Environment.UserName);
                sw.Write(Environment.NewLine);
                sw.Write("Start Time: " + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
                sw.Write(Environment.NewLine);
                sw.Write("--------------------------------------------------");
                sw.Close();
                aFile.Close();
                return false;
            }
            else
            {
                return true;
            }
        }

        public static System.Data.DataTable QueryValues_FolderCreation(string conString)
        {
            System.Data.DataTable dt = new System.Data.DataTable();
            System.Data.DataTable dt1 = new System.Data.DataTable();
            SqlConnection con = new SqlConnection(conString);
            SqlCommand cmd = new SqlCommand();
            //Individual Recons
            //SqlDataAdapter ad = new SqlDataAdapter("select * from ARC_scope_baseline where source_application = 'Email' and foldermovement_complete=0 and recon='Singapore SEC RPR'", con);
            con.Open();
            //ad.Fill(dt1);
            //con.Close();
            //All Recons
            SqlDataAdapter ad = new SqlDataAdapter("select distinct country_name from ARC_Scope_Baseline where source_application = 'Email'", con);
            ad.Fill(dt1);
            return dt1;
        }

        public static System.Data.DataTable QueryValues_ChkRecons(string conString)
        {
            System.Data.DataTable dt = new System.Data.DataTable();
            System.Data.DataTable dt1 = new System.Data.DataTable();
            SqlConnection con = new SqlConnection(conString);
            SqlCommand cmd = new SqlCommand();
            //Individual Recons
            //SqlDataAdapter ad = new SqlDataAdapter("select * from ARC_scope_baseline where source_application = 'Email' and foldermovement_complete=0 and recon='Vietnam ACB'", con);
            con.Open();
            //ad.Fill(dt1);
            //con.Close();
            //All Recons
            SqlDataAdapter ad = new SqlDataAdapter("select * from ARC_scope_baseline where source_application = 'Email' and (SLA_Time>='" + DateTime.Now.ToString("HH:mm:ss.fff") + "' and Receipt_Time<='" + DateTime.Now.ToString("HH:mm:ss.fff") + "') and foldermovement_complete=0 and Recon_id in (select recon_id from ARC_recon_master where Is_Holiday_Logic = 0) order by Receipt_Time ASC", con);
            ad.Fill(dt1);
            return dt1;
        }

        public static string GetFileName_ChkRec(string s, string Name)
        {
            string[] files1 = Directory.GetFiles(s);
            string actfile = "";
            for (int i = 0; i < files1.Length; i++)
            {
                files1[i] = Path.GetFileNameWithoutExtension(files1[i]);
                if (files1[i].ToString().Trim().ToUpper().Contains(Name.ToUpper()))
                {
                    actfile = files1[i];
                }
            }
            if (actfile != "")
            {
                return actfile;
            }
            else
            {
                return Name;
            }
        }
        public static string GetFileName_ChkRecMulfiles(string s, string Name)
        {
            string[] files1 = Directory.GetFiles(s);
            string actfile = "";
            for (int i = 0; i < files1.Length; i++)
            {
                files1[i] = Path.GetFileNameWithoutExtension(files1[i]);
                if (files1[i].ToString().Trim().ToUpper().Contains(Name.ToUpper()))
                {
                    actfile = actfile + "," + files1[i];
                }
            }
            if (actfile != "")
            {
                return actfile;
            }
            else
            {
                return Name;
            }
        }
        public static string GetFileName_3_2(string s, string Name, string Recon_Date)
        {
            string[] files1 = Directory.GetFiles(s);
            string actfile = "";
            for (int i = 0; i < files1.Length; i++)
            {
                files1[i] = Path.GetFileNameWithoutExtension(files1[i]);
                if (files1[i].ToString().Trim().ToUpper().Contains(Name.ToUpper()) && files1[i].ToString().Trim().ToUpper().Contains(Recon_Date.ToUpper().Trim()))
                {
                    actfile = files1[i];
                    break;
                }
            }
            if (actfile != "")
            {
                return actfile;
            }
            else
                return Name;
        }
        public static void FileCopyUpdate(string conString, string File_Name, string Email_Shared_Path, string Country, string InputFolder_Path, string Country_Path, string File_Ext, System.Data.DataTable Share_Folder, string Recon, string Email_ID, bool isMailFunctionalityRequired, bool foldermovement_complete, double converter, int files_moved_count, int i, int Recon_Id, System.Data.DataTable dt_Recon, string product_id, string Main_DIR_SharePath, string strDirectory)
        {
            if (File_Name != "")
            {
                File_Name = GetFileName_ChkRec(Email_Shared_Path + Country + "_Country Sharedrive\\" + DateTime.Today.ToString("dd-MMM-yyyy") + "\\", File_Name);
            }

            InputFolder_Path = Main_DIR_SharePath + "\\Input\\Emails\\" + File_Name.Replace(",", "") + "." + File_Ext;
            Country_Path = Email_Shared_Path + Country + "_Country Sharedrive\\" + DateTime.Today.ToString("dd-MMM-yyyy") + "\\" + File_Name.Replace(",", "") + "." + File_Ext;
            if (Share_Folder.Rows[i]["Email_ID"].ToString().Trim() == "" || Share_Folder.Rows[i]["Email_ID"].ToString().Trim() == string.Empty)
            {
                Console.WriteLine("Email ID Not Configured for " + Recon + " Recon for " + File_Name + " Files");
                Console.WriteLine();
            }
            if (Email_ID != "")
            {

                if (foldermovement_complete == false && File.Exists(Country_Path))
                {
                    if (File.Exists(InputFolder_Path))
                    {
                        File.Delete(InputFolder_Path);
                    }

                    File.Copy(Country_Path, InputFolder_Path);
                    files_moved_count = files_moved_count + 1;
                    if (Recon == "Vietnam - Open Item")
                    {
                        string query1 = "Update ARC_scope_baseline set Foldermovement_Complete = 1 where Recon_ID = '" + Recon_Id + "'";
                        SqlConnection con1 = new SqlConnection(conString);
                        SqlCommand cmd1 = new SqlCommand(query1, con1);
                        if (con1.State == ConnectionState.Closed)
                        {
                            con1.Open();
                        }
                        cmd1.ExecuteNonQuery();
                        if (con1.State == ConnectionState.Open)
                        {
                            con1.Close();
                        }
                    }
                    else
                    {
                        string query11 = "Update ARC_scope_baseline set Foldermovement_Complete = 1 where Report_Source_File_Name like '%" + File_Name.Replace(",", "") + "%' and Recon_ID = '" + Recon_Id + "'";

                        SqlConnection con11 = new SqlConnection(conString);
                        SqlCommand cmd11 = new SqlCommand(query11, con11);
                        if (con11.State == ConnectionState.Closed)
                        {
                            con11.Open();
                        }
                        cmd11.ExecuteNonQuery();
                        if (con11.State == ConnectionState.Open)
                        {
                            con11.Close();
                        }
                    }
                }
            }
            if (dt_Recon.Rows[i]["MailFilesReq"].ToString().Trim() != "")
            {

                if (files_moved_count == Convert.ToInt32(dt_Recon.Rows[i]["MailFilesReq"].ToString()))
                {
                    SqlConnection con = new SqlConnection(conString);
                    SqlCommand Updt_cmd2 = new SqlCommand("update ARC_Recon_Master set IsMailDownloadComplete=1 where Recon_Id = " + Recon_Id + "", con);
                    con.Open();
                    Updt_cmd2.ExecuteNonQuery();
                    con.Close();
                }
            }
        }
        public void Folder_Movement_Formatting3_2(string Main_DIR_SharePath, string conString, string strDirectory)
        {

            aTimer.Stop();
            string Country_Path = string.Empty;
            string InputFolder_Path = string.Empty;


            //SA1001
            try
            {
                DAccess das = new DAccess();
                Hashtable hat = new Hashtable();

                string sDirectory = Main_DIR_SharePath + DateTime.Now.ToString("dd-MMM-yyyy") + "_Files\\";

                //Indidvidual recons
                //string strquery = "select distinct recon_name,recon_id,total_files,MailFilesReq from Arc_Recon_Master_Holiday_Date_Logic where  recon_name='SCB IRAQ Account Balance Report' order by recon_name";

                //All Recons
                string strquery = "select distinct recon_name,recon_id,total_files,recon_date,MailFilesReq,receipt_time from Arc_Recon_Master_Holiday_Date_Logic where Is_Recon_Completed = 0 and Is_Active = 1 and recon_id in (select recon_id from arc_recon_master where Is_Recon_Completed = 0 and Is_Active = 1 and isMailDownloadComplete=0 and Is_Holiday_Logic = 1 and recon_name != 'India Clearing' and recon_name != 'India Clearing Inward' and recon_name != 'India Clearing Outward') order by receipt_time";
                System.Data.DataTable dtReconMaster = das.Select_Table(strquery, hat, "Text", conString);

                string strIInputFileName = string.Empty;
                string strOutPutFileName = string.Empty;
                string SourcePath = string.Empty;
                string Foramtted_Recon_Date = string.Empty;
                string strReconName = string.Empty;
                string Desti_Path = string.Empty;
                string Output_Path = string.Empty;
                string Recon_Date = string.Empty;
                string db_Ext = string.Empty;
                string Recon_name = string.Empty;

                int c = 0;

                for (int i = 0; i < dtReconMaster.Rows.Count; i++)
                {
                    bool flag = true;
                    int files_moved_count = 0;
                    int total_files_tobepresent = 0;
                    
                    Recon_name = Convert.ToString(dtReconMaster.Rows[i]["recon_name"]);
                    if (Recon_name == "VIETNAM VND OPEN ITEMS (CITAD)")
                    {

                    }
                    Recon_Date = Convert.ToString(dtReconMaster.Rows[i]["Recon_Date"]);

                    strquery = "select count(recon_date) as count from Arc_Recon_Master_Holiday_Date_Logic where recon_name='" + Recon_name + "'";
                    System.Data.DataTable dtcount = das.Select_Table(strquery, hat, "Text", conString);

                    if (dtcount.Rows[0]["count"].ToString().Trim() != "" && dtReconMaster.Rows[i]["MailFilesReq"].ToString().Trim() != "")
                    {
                        total_files_tobepresent = Convert.ToInt32(dtcount.Rows[0]["count"].ToString()) * Convert.ToInt32(dtReconMaster.Rows[i]["MailFilesReq"].ToString());
                    }
                    else
                    {
                        total_files_tobepresent = 0;
                    }

                    int Recon_Id = Convert.ToInt32(dtReconMaster.Rows[i]["recon_id"]);
                    int File_Count = Convert.ToInt32(dtReconMaster.Rows[i]["total_files"]);
                    //DateTime dtRecondate = Convert.ToDateTime(dtReconMaster.Rows[i]["recon_date"]);
                    //Recon_Date = Convert.ToString(dtReconMaster.Rows[i]["Recon_date"]);
                    string selquery1 = "select distinct Recon_Date,Is_Recon_Completed,MailFilesReq from Arc_Recon_Master_Holiday_Date_Logic where recon_name ='" + Recon_name + "' order by Recon_date";
                    System.Data.DataTable dtsel1 = das.Select_Table(selquery1, hat, "Text", conString);
                    for (int j = 0; j < dtsel1.Rows.Count; j++)
                    {
                        DateTime dt_Recondate = Convert.ToDateTime(dtsel1.Rows[j]["Recon_Date"]);
                        //EA1001                        
                        ///Added by Prakash - For checking the Least Recon Date file is processed or not, if not skip that recon and go for next recon
                        //string selquery = "select top(1) Report_Source_File_Name,Recon_Date,IsProcessed,automationStatus from arc_scope_baseline_logic where recon ='" + Recon_name + "' order by Recon_date";
                        // DataTable dtsel = das.Select_Table(selquery, hat, "Text");


                        //Indidvidual recons
                        //strquery = "select Team, Country_Name, Recon, Report_Source_File_Name,FTP_File_Format_Name, Recon_date from ARC_Scope_Baseline_Logic where recon='SCB IRAQ Account Balance Report' and recon_date='" + dt_Recondate.ToString("MM/dd/yyyy") + "' ";


                        //All Recons-15-02-18
                        strquery = "select * from ARC_scope_baseline_logic a inner join ARC_scope_baseline b on a.recon_id=b.recon_id where source_application = 'Email' and foldermovement_complete=0 and (SLA_Time>='" + DateTime.Now.ToString("HH:mm:ss.fff") + "' and Receipt_Time<='" + DateTime.Now.ToString("HH:mm:ss.fff") + "') and a.Recon_id in (select recon_id from ARC_recon_master where IsEmailRequired = 1 and Is_Holiday_Logic = 1) order by Receipt_Time asc";
                        System.Data.DataTable dtBaseHoliday = das.Select_Table(strquery, hat, "Text", conString);


                        System.Data.DataTable dt = new System.Data.DataTable();
                        SqlConnection con = new SqlConnection(conString);

                        strquery = "select * from ARC_scope_baseline where source_application = 'Email' and (SLA_Time>='" + DateTime.Now.ToString("HH:mm:ss.fff") + "' and Receipt_Time<='" + DateTime.Now.ToString("HH:mm:ss.fff") + "') and foldermovement_complete=0 and Recon_id in (select recon_id from ARC_recon_master where Is_Holiday_Logic = 1 and Recon_id='" + Recon_Id + "')order by Receipt_Time asc";
                        System.Data.DataTable dtScopeBaseline = das.Select_Table(strquery, hat, "Text", conString);

                        DataRow[] dr = dtScopeBaseline.Select();
                        //DataTable dtt = new DataTable();
                        //////SqlDataAdapter ad1 = new SqlDataAdapter("select count(*) from ARC_scope_baseline_logic where Recon_id in ('" + Recon_Id + "')", con);
                        //SqlDataAdapter ad1 = new SqlDataAdapter("select count(distinct B.Report_Source_File_Name) from ARC_scope_baseline_logic A, ARC_scope_baseline B where A.Recon_id='" + Recon_Id + "' and B.Recon_id='" + Recon_Id + "' and B.Source_Application='Email'", con);
                        //con.Open();
                        //ad1.Fill(dtt);
                        if (Convert.ToInt32(dtcount.Rows[0]["count"].ToString()) > 1)
                        {
                            foreach (DataRow d in dr)
                            {
                                string Country = Convert.ToString(d["Country_Name"]);
                                string File_Name = Convert.ToString(d["Report_Source_File_Name"]);
                                string IsFormatting = Convert.ToString(d["Format_Direct_Upload"]);
                                string Source_App = Convert.ToString(d["Source_Application"]);
                                string File_Ext = Convert.ToString(d["File_Format"]);
                                string Receipt_Time = Convert.ToString(d["Receipt_Time"]);
                                string Email_Shared_Path = Convert.ToString(d["Email_Shared_Path"]);
                                string Recon = Convert.ToString(d["Recon"]);
                                string Email_Subject = Convert.ToString(d["Email_Subject"]);
                                string Email_ID = Convert.ToString(d["Email_ID"]);
                                string product_id = Convert.ToString(d["product_id"]);
                                bool foldermovement_complete = Convert.ToBoolean(d["foldermovement_complete"]);
                                bool isMailFunctionalityRequired = Convert.ToBoolean(d["isMailFunctionalityRequired"]);
                                var time = TimeSpan.Parse(Receipt_Time);
                                var dateTime = DateTime.Today.Add(time);

                                var diff = dateTime.Subtract(DateTime.Now);

                                double Hour = Convert.ToDouble(diff.Hours);
                                double Min = Convert.ToDouble(diff.Minutes);
                                double Sec = Convert.ToDouble(diff.Seconds);
                                //var res = String.Format("{0}:{1}:{2}", diff.Hours,diff.Minutes,diff.Seconds));

                                double converter = Hour * 60 + Min + (Sec / 60);

                                if (File_Name.Contains("YYYY_MM_DD"))
                                {
                                    Recon_Date = dt_Recondate.ToString("yyyy_MM_dd");
                                    File_Name = File_Name.Replace("YYYY_MM_DD", Recon_Date);
                                }
                                else if (File_Name.Contains("DD-MMM"))
                                {
                                    Recon_Date = dt_Recondate.ToString("dd-MMM");
                                    File_Name = File_Name.Replace("DD-MMM", Recon_Date);
                                }
                                else if (File_Name.Contains("DD-MM"))
                                {
                                    Recon_Date = dt_Recondate.ToString("dd-MM");
                                    File_Name = File_Name.Replace("DD-MM", Recon_Date);
                                }
                                else if (File_Name.Contains("DD.MM.YYYY"))
                                {
                                    Recon_Date = dt_Recondate.ToString("dd.MM.yyyy");

                                    File_Name = File_Name.Replace("DD.MM.YYYY", Recon_Date);
                                }
                                else if (File_Name.Contains("DD_MM_YYYY"))
                                {
                                    Recon_Date = dt_Recondate.ToString("dd_MM_yyyy");

                                    File_Name = File_Name.Replace("DD_MM_YYYY", Recon_Date);
                                }
                                else if (File_Name.Contains("DD-MM-YYYY"))
                                {
                                    Recon_Date = dt_Recondate.ToString("dd-MM-yyyy");
                                    File_Name = File_Name.Replace("DD-MM-YYYY", Recon_Date);
                                }
                                else if (File_Name.Contains("MM.DD.YYYY"))
                                {
                                    Recon_Date = dt_Recondate.ToString("MM.dd.yyyy");
                                    File_Name = File_Name.Replace("MM.DD.YYYY", Recon_Date);
                                }
                                else if (File_Name.Contains("DDMMYYYY"))
                                {
                                    Recon_Date = dt_Recondate.ToString("ddMMyyyy");
                                    File_Name = File_Name.Replace("DDMMYYYY", Recon_Date);
                                }
                                else if (File_Name.Contains("DD-MMM YYYY"))
                                {
                                    Recon_Date = dt_Recondate.ToString("dd-MMM yyyy");
                                    File_Name = File_Name.Replace("DD-MMM YYYY", Recon_Date);
                                }
                                else if (File_Name.Contains("DDMMYY"))
                                {
                                    Recon_Date = dt_Recondate.ToString("ddMMyy");
                                    File_Name = File_Name.Replace("DDMMYY", Recon_Date);
                                }
                                else if (File_Name.Contains("YYYYMMDD"))
                                {

                                    if (Recon_name == "VIETNAM VND OPEN ITEMS (CITAD)")
                                    {
                                        if (File_Name.Contains("LOCALBANK_STMT_TB_VN_SBV_"))
                                        {
                                            Recon_Date = dt_Recondate.ToString("yyyyMMdd");
                                            File_Name = File_Name.Replace("YYYYMMDD", Recon_Date) + "." + File_Ext;
                                            strIInputFileName = File_Name;
                                            strOutPutFileName = File_Name;
                                        }

                                        else
                                        {
                                            Recon_Date = dt_Recondate.ToString("yyyyMMdd");
                                            string Recon_Date_01 = dt_Recondate.ToString("ddMMyyyy");
                                            File_Name = File_Name.Replace("DDMMYYYY", Recon_Date_01);
                                            File_Name = File_Name.Replace("YYYYMMDD", Recon_Date) + "." + File_Ext;
                                            strIInputFileName = File_Name;
                                            strOutPutFileName = File_Name;
                                        }
                                    }
                                    Recon_Date = dt_Recondate.ToString("yyyyMMdd");
                                    File_Name = File_Name.Replace("YYYYMMDD", Recon_Date);
                                }
                                else if (File_Name.Contains("YYYY-MM-DD"))
                                {
                                    Recon_Date = dt_Recondate.ToString("yyyy-MM-dd");
                                    File_Name = File_Name.Replace("YYYY-MM-DD", Recon_Date);
                                }
                                else if (File_Name.Contains("DD MMM YY"))
                                {
                                    Recon_Date = dt_Recondate.ToString("dd MMM yy");
                                    File_Name = File_Name.Replace("DD MMM YY", Recon_Date);
                                }
                                else if (File_Name.Contains("DD MM YY"))
                                {
                                    Recon_Date = dt_Recondate.ToString("dd MM yy");
                                    File_Name = File_Name.Replace("DD MM YY", Recon_Date);
                                }
                                else if (File_Name.Contains("DD_MM"))
                                {
                                    Recon_Date = dt_Recondate.ToString("dd_MM");
                                    File_Name = File_Name.Replace("DD_MM", Recon_Date);
                                }
                                else if (File_Name.Contains("YYDDMM"))
                                {
                                    Recon_Date = dt_Recondate.ToString("yyddMM");
                                    File_Name = File_Name.Replace("YYDDMM", Recon_Date);
                                }
                                else if (File_Name.Contains("YYYY-MM"))
                                {
                                    Recon_Date = dt_Recondate.ToString("yyyy-MM");
                                    File_Name = File_Name.Replace("YYYY-MM", Recon_Date);
                                }
                                else if (File_Name.Contains("DD.MM.YY"))
                                {
                                    Recon_Date = dt_Recondate.ToString("dd.MM.yy");
                                    File_Name = File_Name.Replace("DD.MM.YY", Recon_Date);
                                }
                                ////if multiple folders for multiple days
                                ////DateTime myDate = DateTime.ParseExact(ReconDate.ToString(), "yyyy-MM-dd", System.Globalization.CultureInfo.InvariantCulture);

                                //if (File_Name != "")
                                //{
                                File_Name = GetFileName_3_2(Email_Shared_Path + Country + "_Country Sharedrive\\" + DateTime.Now.ToString("dd-MMM-yyyy") + "\\", File_Name, Recon_Date);
                                // }

                                InputFolder_Path = Main_DIR_SharePath + strDirectory + "\\Input\\Emails\\" + File_Name + "." + File_Ext;
                                Country_Path = Email_Shared_Path + Country + "_Country Sharedrive\\" + DateTime.Now.ToString("dd-MMM-yyyy") + "\\" + File_Name + "." + File_Ext;
                                if (File.Exists(Country_Path))
                                {
                                    c++;
                                }
                                else
                                {

                                }
                            }
                        }
                    }

                    if (Convert.ToInt32(dtcount.Rows[0]["count"].ToString()) > 1)
                    {
                        if (c == total_files_tobepresent)
                        {
                            flag = true;
                        }
                        else
                        {
                            flag = false;
                        }
                    }


                    if (flag == true)
                    {
                        System.Data.DataTable dt = new System.Data.DataTable();
                        SqlConnection con = new SqlConnection(conString);

                        strquery = "select * from ARC_scope_baseline where source_application = 'Email' and (SLA_Time>='" + DateTime.Now.ToString("HH:mm:ss.fff") + "' and Receipt_Time<='" + DateTime.Now.ToString("HH:mm:ss.fff") + "') and foldermovement_complete=0 and Recon_id in (select recon_id from ARC_recon_master where IsEmailRequired = 1 and Recon_id='" + Recon_Id + "')";
                        System.Data.DataTable dtScopeBaseline = das.Select_Table(strquery, hat, "Text", conString);
                        string sysFormat = System.Globalization.CultureInfo.CurrentCulture.DateTimeFormat.ShortDatePattern + " hh:mm:ss tt";
                        DateTime myDate = DateTime.ParseExact(Recon_Date, sysFormat, System.Globalization.CultureInfo.InvariantCulture);
                        DataRow[] dr = dtScopeBaseline.Select();

                        if (dtScopeBaseline.Rows.Count > 0)
                        {
                            foreach (DataRow d in dr)
                            {
                                string Country = Convert.ToString(d["Country_Name"]);
                                string File_Name = Convert.ToString(d["Report_Source_File_Name"]);
                                string File_Ext = Convert.ToString(d["File_Format"]);
                                string Receipt_Time = Convert.ToString(d["Receipt_Time"]);
                                string Email_Shared_Path = Convert.ToString(d["Email_Shared_Path"]);
                                string Recon = Convert.ToString(d["Recon"]);
                                string Email_Subject = Convert.ToString(d["Email_Subject"]);
                                string Email_ID = Convert.ToString(d["Email_ID"]);
                                string product_id = Convert.ToString(d["product_id"]);
                                bool foldermovement_complete = Convert.ToBoolean(d["foldermovement_complete"]);
                                bool isMailFunctionalityRequired = Convert.ToBoolean(d["isMailFunctionalityRequired"]);
                                var time = TimeSpan.Parse(Receipt_Time);
                                var dateTime = DateTime.Today.Add(time);

                                var diff = dateTime.Subtract(DateTime.Now);

                                double Hour = Convert.ToDouble(diff.Hours);
                                double Min = Convert.ToDouble(diff.Minutes);
                                double Sec = Convert.ToDouble(diff.Seconds);
                                //var res = String.Format("{0}:{1}:{2}", diff.Hours,diff.Minutes,diff.Seconds));
                                double converter = Hour * 60 + Min + (Sec / 60);
                                for (int j = 0; j < dtsel1.Rows.Count; j++)
                                {
                                    File_Name = Convert.ToString(d["Report_Source_File_Name"]);

                                    if (File_Name.Contains("YYYY_MM_DD"))
                                    {
                                        Recon_Date = myDate.ToString("yyyy_MM-dd");
                                        File_Name = File_Name.Replace("YYYY_MM_DD", "");
                                    }
                                    //
                                    else if (File_Name.Contains("DD-MMM YYYY") && File_Name.Contains("DD-MMM-YYYY"))
                                    {
                                        Recon_Date = myDate.ToString("dd-MMM-yyyy");
                                        File_Name = File_Name.Replace("DD-MMM YYYY", "");
                                        File_Name = File_Name.Replace("DD-MMM-YYYY", "");
                                        File_Name = File_Name.Substring(0, File_Name.Length - 20);
                                    }
                                    else if (File_Name.Contains("DD-MMM YYYY"))
                                    {
                                        Recon_Date = myDate.ToString("yyyy_MM-dd");
                                        File_Name = File_Name.Replace("DD-MMM YYYY", "");
                                    }
                                    else if (File_Name.Contains("DD-MMM-YYYY"))
                                    {
                                        Recon_Date = myDate.ToString("yyyy_MM-dd");
                                        File_Name = File_Name.Replace("DD-MMM-YYYY", "");
                                    }
                                    else if (File_Name.Contains("DD-MMM"))
                                    {
                                        Recon_Date = myDate.ToString("yyyy_MM-dd");
                                        File_Name = File_Name.Replace("DD-MMM", "");
                                    }
                                    else if (File_Name.Contains("DD-MM"))
                                    {
                                        Recon_Date = myDate.ToString("yyyy_MM-dd");
                                        File_Name = File_Name.Replace("DD-MM", "");
                                    }
                                    else if (File_Name.Contains("DD.MM.YYYY"))
                                    {
                                        Recon_Date = myDate.ToString("yyyy_MM-dd");
                                        File_Name = File_Name.Replace("DD.MM.YYYY", "");
                                    }
                                    else if (File_Name.Contains("DD_MM_YYYY"))
                                    {
                                        Recon_Date = myDate.ToString("dd_MM_yyyy");
                                        File_Name = File_Name.Replace("DD_MM_YYYY", "");
                                    }
                                    else if (File_Name.Contains("DD-MM-YYYY"))
                                    {
                                        Recon_Date = myDate.ToString("dd-MM-yyyy");
                                        File_Name = File_Name.Replace("DD-MM-YYYY", "");
                                    }
                                    else if (File_Name.Contains("MM.DD.YYYY"))
                                    {
                                        Recon_Date = myDate.ToString("MM.dd.yyyy");
                                        File_Name = File_Name.Replace("MM.DD.YYYY", "");
                                    }
                                    else if (File_Name.Contains("DDMMYYYY"))
                                    {
                                        Recon_Date = myDate.ToString("ddMMyyyy");
                                        File_Name = File_Name.Replace("DDMMYYYY", "");
                                    }
                                    else if (File_Name.Contains("DD-MMM YYYY"))
                                    {
                                        Recon_Date = myDate.ToString("dd-MMM yyyy");
                                        File_Name = File_Name.Replace("DD-MMM YYYY", "");
                                    }
                                    else if (File_Name.Contains("DDMMYY"))
                                    {
                                        Recon_Date = myDate.ToString("ddMMyy");
                                        File_Name = File_Name.Replace("DDMMYY", "");
                                    }
                                    else if (File_Name.Contains("YYYYMMDD"))
                                    {
                                        Recon_Date = myDate.ToString("yyyyMMdd");
                                        File_Name = File_Name.Replace("YYYYMMDD", "");
                                    }
                                    else if (File_Name.Contains("YYYY-MM-DD"))
                                    {
                                        Recon_Date = myDate.ToString("yyyy-MM-dd");
                                        File_Name = File_Name.Replace("YYYY-MM-DD", "");
                                    }
                                    else if (File_Name.Contains("DD MMM YY"))
                                    {
                                        Recon_Date = myDate.ToString("dd MMM yy");
                                        File_Name = File_Name.Replace("DD MMM YY", "");
                                    }
                                    else if (File_Name.Contains("DD MM YY"))
                                    {
                                        Recon_Date = myDate.ToString("dd MM yy");
                                        File_Name = File_Name.Replace("DD MM YY", "");
                                    }
                                    else if (File_Name.Contains("DD_MM"))
                                    {
                                        Recon_Date = myDate.ToString("dd_MM");
                                        File_Name = File_Name.Replace("DD_MM", "");
                                    }
                                    else if (File_Name.Contains("YYDDMM"))
                                    {
                                        Recon_Date = myDate.ToString("yyddMM");
                                        File_Name = File_Name.Replace("YYDDMM", "");
                                    }
                                    else if (File_Name.Contains("YYYY-MM"))
                                    {
                                        Recon_Date = myDate.ToString("yyyy-MM");
                                        File_Name = File_Name.Replace("YYYY-MM", "");
                                    }
                                    else if (File_Name.Contains("DD.MM.YY"))
                                    {
                                        Recon_Date = myDate.ToString("dd.MM.yy");
                                        File_Name = File_Name.Replace("DD.MM.YY", "");
                                    }
                                    ////if multiple folders for multiple days
                                    ////DateTime myDate = DateTime.ParseExact(ReconDate.ToString(), "yyyy-MM-dd", System.Globalization.CultureInfo.InvariantCulture);

                                    //if (File_Name != "")
                                    //{
                                    File_Name = GetFileName_3_2(Email_Shared_Path + Country + "_Country Sharedrive\\" + DateTime.Now.ToString("dd-MMM-yyyy") + "\\", File_Name, Recon_Date);
                                    // }

                                    InputFolder_Path = Main_DIR_SharePath + strDirectory + "\\Input\\Emails\\" + File_Name + "." + File_Ext;
                                    Country_Path = Email_Shared_Path + Country + "_Country Sharedrive\\" + DateTime.Now.ToString("dd-MMM-yyyy") + "\\" + File_Name + "." + File_Ext;
                                    if (File_Name != "")
                                    {
                                        if (foldermovement_complete == false && File.Exists(Country_Path))
                                        {
                                            if (File.Exists(InputFolder_Path))
                                            {
                                                File.Delete(InputFolder_Path);
                                            }

                                            File.Copy(Country_Path, InputFolder_Path);

                                            files_moved_count = files_moved_count + 1;
                                        }

                                    }

                                }
                            }
                        }
                    }
                }
            }

            catch 
            {
                aTimer.Start();
               // Console.WriteLine(ex.ToString());
            }
        }
    }
}
