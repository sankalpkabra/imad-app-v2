﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Data.OleDb;
using System.Globalization;
using System.Data.SqlClient;
using Excel = Microsoft.Office.Interop.Excel;
using System.Data;

namespace ARC_Formatting.FileFormatting
{
    public class cls_PhantomNostro
    {
        public void India_PhantomNostro_Recon(string SourcePath, string Recon_Date, string Output_Dir, string Recon_name, string Output_Path, string Formatted_File_Name)
        {
            string InputFile = SourcePath;

            string OutputFileName = Formatted_File_Name.Substring(0, Formatted_File_Name.Length - 4);
            string FileName = Output_Dir + "Account_Balance_" + Recon_Date + ".xlsx";
            string[] CrystalFilePaths = Directory.GetFiles(Output_Dir);
            string AccountList = string.Empty;
            string Crystal_CurrentdayPath = string.Empty;
            string Crystal_PrvDayPath = string.Empty;
            for (int i = 0; i < CrystalFilePaths.Length; i++)
            {
                if (CrystalFilePaths[i].ToString().ToUpper() == FileName.ToUpper())
                {
                    Crystal_CurrentdayPath = CrystalFilePaths[i].ToString();
                }
                else if (CrystalFilePaths[i].ToString().Contains("AccountList"))
                {
                    AccountList = CrystalFilePaths[i].ToString();
                }
                else
                {
                    Crystal_PrvDayPath = CrystalFilePaths[i].ToString();
                }
            }

            string strConn1;
            System.Data.DataTable dtexcel1 = new System.Data.DataTable();
            System.Data.DataTable dtexcel2 = new System.Data.DataTable();
            System.Data.DataTable dtexcel3 = new System.Data.DataTable();
            System.Data.DataTable dtexcel4 = new System.Data.DataTable();
            System.Data.DataTable dtexcel5 = new System.Data.DataTable();
            System.Data.DataTable dtexcel6 = new System.Data.DataTable();
            System.Data.DataTable dtexcel7 = new System.Data.DataTable();

            DataTable dtfinal = new DataTable();

            //var FileName = Path.GetFileName(InputFile);
            #region Input File Read
            strConn1 = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + InputFile + ";Extended Properties='Excel 8.0;HDR=YES;IMEX=1'";
            OleDbConnection conn1 = new OleDbConnection(strConn1);
            conn1.Open();
            System.Data.DataTable schemaTable1 = conn1.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, new object[] { null, null, null, "TABLE" });

            DataRow schemaRow4 = schemaTable1.Rows[0];
            string sheet1 = schemaRow4["TABLE_NAME"].ToString();

            OleDbDataAdapter daexcel1 = null;
            if (!sheet1.EndsWith("_"))
            {
                string query = "SELECT  * FROM [" + sheet1 + "]";
                daexcel1 = new OleDbDataAdapter(query, conn1);
                dtexcel1.Locale = CultureInfo.CurrentCulture;
                daexcel1.Fill(dtexcel1);

                string query1 = "SELECT  distinct XSTR8 FROM [" + sheet1 + "]";
                daexcel1 = new OleDbDataAdapter(query1, conn1);
                dtexcel1.Locale = CultureInfo.CurrentCulture;
                daexcel1.Fill(dtexcel2);
            }
            conn1.Close();
            #endregion
            #region AccountList

            strConn1 = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + AccountList + ";Extended Properties='Excel 8.0;HDR=YES;IMEX=1'";
            OleDbConnection conn5 = new OleDbConnection(strConn1);
            conn5.Open();
            System.Data.DataTable schemaTable5 = conn5.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, new object[] { null, null, null, "TABLE" });

            DataRow schemaRow5 = schemaTable5.Rows[0];
            string sheet_AccountList = schemaRow5["TABLE_NAME"].ToString();

            OleDbDataAdapter daexcel5 = null;

            if (!sheet_AccountList.EndsWith("_"))
            {
                string query = "SELECT  * FROM [" + sheet_AccountList + "]";
                daexcel5 = new OleDbDataAdapter(query, conn5);
                dtexcel5.Locale = CultureInfo.CurrentCulture;
                daexcel5.Fill(dtexcel5);
            }
            conn1.Close();

            #endregion
            #region Crystal Current day file Read
            strConn1 = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + Crystal_CurrentdayPath + ";Extended Properties='Excel 8.0;HDR=YES'";
            OleDbConnection conn2 = new OleDbConnection(strConn1);
            conn2.Open();
            System.Data.DataTable schemaTable2 = conn2.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, new object[] { null, null, null, "TABLE" });

            DataRow schemaRow1 = schemaTable2.Rows[0];
            string sheet_Crystal_CurrDay = schemaRow1["TABLE_NAME"].ToString();

            OleDbDataAdapter daexcel2 = null;

            if (!sheet_Crystal_CurrDay.EndsWith("_"))
            {
                string query = "SELECT  * FROM [" + sheet_Crystal_CurrDay + "]";
                daexcel2 = new OleDbDataAdapter(query, conn2);
                dtexcel3.Locale = CultureInfo.CurrentCulture;
                daexcel2.Fill(dtexcel3);
            }
            conn1.Close();
            if (dtexcel3.Rows.Count > 0)
            {
                dtexcel6.Columns.Add("TLM ACC NO");
                dtexcel6.Columns.Add("ACCT  NAME");
                dtexcel6.Columns.Add("Sub Acc No");
                dtexcel6.Columns.Add("S/L");
                dtexcel6.Columns.Add("Latest_Stmt_Date");
                dtexcel6.Columns.Add("Closing balance");
                dtexcel6.Columns.Add("Missing Balance");
                dtexcel6.Columns.Add("Credit Outstanding Nos");
                dtexcel6.Columns.Add("Credit Outstanding Amount");
                dtexcel6.Columns.Add("Debit Outstanding Nos");
                dtexcel6.Columns.Add("Debit Outstanding Amount");
                dtexcel6.Columns.Add("Last Stmt / Ledger");
                dtexcel6.Columns.Add("Forward");
                dtexcel6.Columns.Add("Value Adjust Balance");

                for (int i = 0; i <= dtexcel3.Rows.Count; i++)
                {
                    if (dtexcel3.Rows[0][2].ToString().Trim().ToUpper() == "SUB ACC NO")
                    {
                        break;
                    }
                    else
                    {
                        dtexcel3.Rows.RemoveAt(0);
                    }
                }

                for (int j = 1; j < dtexcel3.Rows.Count; j++)
                {
                    dtexcel6.Rows.Add();
                    dtexcel6.Rows[j - 1][0] = dtexcel3.Rows[j][0];
                    dtexcel6.Rows[j - 1][1] = dtexcel3.Rows[j][1];
                    dtexcel6.Rows[j - 1][2] = dtexcel3.Rows[j][2];
                    dtexcel6.Rows[j - 1][3] = dtexcel3.Rows[j][3];
                    dtexcel6.Rows[j - 1][4] = dtexcel3.Rows[j][4];
                    dtexcel6.Rows[j - 1][5] = dtexcel3.Rows[j][5];
                    dtexcel6.Rows[j - 1][6] = dtexcel3.Rows[j][6];
                    dtexcel6.Rows[j - 1][7] = dtexcel3.Rows[j][7];
                    dtexcel6.Rows[j - 1][8] = dtexcel3.Rows[j][8];
                    dtexcel6.Rows[j - 1][9] = dtexcel3.Rows[j][9];
                    dtexcel6.Rows[j - 1][10] = dtexcel3.Rows[j][10];
                    dtexcel6.Rows[j - 1][11] = dtexcel3.Rows[j][11];
                    dtexcel6.Rows[j - 1][12] = dtexcel3.Rows[j][12];
                    dtexcel6.Rows[j - 1][13] = dtexcel3.Rows[j][13];

                }
            }
            #endregion
            #region Crystal Previous day file Read
            strConn1 = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + Crystal_PrvDayPath + ";Extended Properties='Excel 8.0;HDR=YES'";
            OleDbConnection conn3 = new OleDbConnection(strConn1);
            conn3.Open();
            System.Data.DataTable schemaTable3 = conn3.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, new object[] { null, null, null, "TABLE" });

            DataRow schemaRow2 = schemaTable3.Rows[0];
            string sheet_Crystal_PrvDay = schemaRow2["TABLE_NAME"].ToString();

            OleDbDataAdapter daexcel3 = null;

            if (!sheet_Crystal_PrvDay.EndsWith("_"))
            {
                string query = "SELECT  * FROM [" + sheet_Crystal_PrvDay + "]";
                daexcel3 = new OleDbDataAdapter(query, conn3);
                dtexcel4.Locale = CultureInfo.CurrentCulture;
                daexcel3.Fill(dtexcel4);
            }
            conn3.Close();
            if (dtexcel4.Rows.Count > 0)
            {
                dtexcel7.Columns.Add("TLM ACC NO");
                dtexcel7.Columns.Add("ACCT  NAME");
                dtexcel7.Columns.Add("Sub Acc No");
                dtexcel7.Columns.Add("S/L");
                dtexcel7.Columns.Add("Latest_Stmt_Date");
                dtexcel7.Columns.Add("Closing balance");
                dtexcel7.Columns.Add("Missing Balance");
                dtexcel7.Columns.Add("Credit Outstanding Nos");
                dtexcel7.Columns.Add("Credit Outstanding Amount");
                dtexcel7.Columns.Add("Debit Outstanding Nos");
                dtexcel7.Columns.Add("Debit Outstanding Amount");
                dtexcel7.Columns.Add("Last Stmt / Ledger");
                dtexcel7.Columns.Add("Forward");
                dtexcel7.Columns.Add("Value Adjust Balance");

                for (int i = 0; i <= dtexcel4.Rows.Count; i++)
                {
                    if (dtexcel4.Rows[0][2].ToString().Trim().ToUpper() == "SUB ACC NO")
                    {
                        break;
                    }
                    else
                    {
                        dtexcel4.Rows.RemoveAt(0);
                    }
                }

                for (int j = 1; j < dtexcel4.Rows.Count; j++)
                {
                    dtexcel7.Rows.Add();
                    dtexcel7.Rows[j - 1][0] = dtexcel4.Rows[j][0];
                    dtexcel7.Rows[j - 1][1] = dtexcel4.Rows[j][1];
                    dtexcel7.Rows[j - 1][2] = dtexcel4.Rows[j][2];
                    dtexcel7.Rows[j - 1][3] = dtexcel4.Rows[j][3];
                    dtexcel7.Rows[j - 1][4] = dtexcel4.Rows[j][4];
                    dtexcel7.Rows[j - 1][5] = dtexcel4.Rows[j][5];
                    dtexcel7.Rows[j - 1][6] = dtexcel4.Rows[j][6];
                    dtexcel7.Rows[j - 1][7] = dtexcel4.Rows[j][7];
                    dtexcel7.Rows[j - 1][8] = dtexcel4.Rows[j][8];
                    dtexcel7.Rows[j - 1][9] = dtexcel4.Rows[j][9];
                    dtexcel7.Rows[j - 1][10] = dtexcel4.Rows[j][10];
                    dtexcel7.Rows[j - 1][11] = dtexcel4.Rows[j][11];
                    dtexcel7.Rows[j - 1][12] = dtexcel4.Rows[j][12];
                    dtexcel7.Rows[j - 1][13] = dtexcel4.Rows[j][13];

                }
            }
            #endregion

            #region Datatable Column Name
            dtfinal.Columns.Add("OPBAL", typeof(string));
            dtfinal.Columns.Add("OPBALCY");
            dtfinal.Columns.Add("OPBALDATE");
            dtfinal.Columns.Add("OPBALTP");
            dtfinal.Columns.Add("MTYPE");
            dtfinal.Columns.Add("SIDE");
            dtfinal.Columns.Add("STMTNO");
            dtfinal.Columns.Add("STMTPG");
            dtfinal.Columns.Add("SUBACC");
            dtfinal.Columns.Add("THEIRREF");
            dtfinal.Columns.Add("REFERENCE 4");
            dtfinal.Columns.Add("AMOUNT", typeof(string));
            dtfinal.Columns.Add("SIGN");
            dtfinal.Columns.Add("ENTRY DATE");
            dtfinal.Columns.Add("REFERENCE 1");
            dtfinal.Columns.Add("REFERENCE 2");
            dtfinal.Columns.Add("REFERENCE 3");
            dtfinal.Columns.Add("TRANSACTION CODE");
            dtfinal.Columns.Add("VALUE DATE");
            dtfinal.Columns.Add("SOURCE CODE");
            dtfinal.Columns.Add("DEAL QUANTITY");
            dtfinal.Columns.Add("XSTR18");
            dtfinal.Columns.Add("XSTR19");
            dtfinal.Columns.Add("PRICE CURRENCY");
            dtfinal.Columns.Add("CATEGORY CODE");
            dtfinal.Columns.Add("COUNTERPARTY REF");
            dtfinal.Columns.Add("XAMT1");
            dtfinal.Columns.Add("XAMT10");
            dtfinal.Columns.Add("XAMT2");
            dtfinal.Columns.Add("XAMT3");
            dtfinal.Columns.Add("XAMT4");
            dtfinal.Columns.Add("XAMT5");
            dtfinal.Columns.Add("XAMT6");
            dtfinal.Columns.Add("XAMT7");
            dtfinal.Columns.Add("XAMT8");
            dtfinal.Columns.Add("XAMT9");
            dtfinal.Columns.Add("XCCY1");
            dtfinal.Columns.Add("XCCY2");
            dtfinal.Columns.Add("XCCY3");
            dtfinal.Columns.Add("XCCY4");
            dtfinal.Columns.Add("XCCY5");
            dtfinal.Columns.Add("XCCY6");
            dtfinal.Columns.Add("XCCY7");
            dtfinal.Columns.Add("XCCY8");
            dtfinal.Columns.Add("XCCY9");
            dtfinal.Columns.Add("XCCY10");
            dtfinal.Columns.Add("XDATE1");
            dtfinal.Columns.Add("XDATE10");
            dtfinal.Columns.Add("XDATE2");
            dtfinal.Columns.Add("XDATE3");
            dtfinal.Columns.Add("XDATE4");
            dtfinal.Columns.Add("XDATE5");
            dtfinal.Columns.Add("XDATE6");
            dtfinal.Columns.Add("XDATE7");
            dtfinal.Columns.Add("XDATE8");
            dtfinal.Columns.Add("XDATE9");
            dtfinal.Columns.Add("XSTR1");
            dtfinal.Columns.Add("XSTR12");
            dtfinal.Columns.Add("XSTR3");
            dtfinal.Columns.Add("XSTR4");
            dtfinal.Columns.Add("XSTR5");
            dtfinal.Columns.Add("XSTR6");
            dtfinal.Columns.Add("XSTR7");
            dtfinal.Columns.Add("XSTR8");
            dtfinal.Columns.Add("XSTR9");
            dtfinal.Columns.Add("XSTR10");
            dtfinal.Columns.Add("XFLAG1");
            dtfinal.Columns.Add("XFLAG10");
            dtfinal.Columns.Add("XFLAG2");
            dtfinal.Columns.Add("XFLAG3");
            dtfinal.Columns.Add("XFLAG4");
            dtfinal.Columns.Add("XFLAG5");

            dtfinal.Columns.Add("XFLAG6");
            dtfinal.Columns.Add("XFLAG7");
            dtfinal.Columns.Add("XFLAG8");
            dtfinal.Columns.Add("XFLAG9");
            dtfinal.Columns.Add("CLBAL", typeof(string));
            dtfinal.Columns.Add("CLBALCY");
            dtfinal.Columns.Add("CLBALDATE");
            dtfinal.Columns.Add("CLBALTP");
            dtfinal.Columns.Add("ACCOUNT");
            dtfinal.Columns.Add("TRANS CLASS");
            dtfinal.Columns.Add("XSTR11");
            dtfinal.Columns.Add("XSTR2");
            dtfinal.Columns.Add("BOOK");
            dtfinal.Columns.Add("SOURCE SYSTEM");
            dtfinal.Columns.Add("DESTINATIONID");
            dtfinal.Columns.Add("TERMINALID");
            dtfinal.Columns.Add("THEIRREF@");
            dtfinal.Columns.Add("CURRENCY");
            dtfinal.Columns.Add("REDENOM AMOUNT");
            dtfinal.Columns.Add("REDENOM CURRENCY");
            dtfinal.Columns.Add("ASSET CODE");
            dtfinal.Columns.Add("ASSET DESCRIPTION");
            dtfinal.Columns.Add("NARRATIVE");
            dtfinal.Columns.Add("ASSET TYPE");
            dtfinal.Columns.Add("RELATED REF");
            dtfinal.Columns.Add("REVERSAL");
            dtfinal.Columns.Add("SSRGIN");
            dtfinal.Columns.Add("COST");
            dtfinal.Columns.Add("COST CURRENCY");
            dtfinal.Columns.Add("ACCRUED AMOUNT");
            dtfinal.Columns.Add("ACCRUED AMOUNT CURRENCY");
            dtfinal.Columns.Add("PRICE BASE");
            dtfinal.Columns.Add("PRICE BASE CURRENCY");
            dtfinal.Columns.Add("ACCRUED AMOUNT BASE");
            dtfinal.Columns.Add("ACCRUED AMOUNT BASE CURRENCY");
            dtfinal.Columns.Add("DEAL PRICE");
            dtfinal.Columns.Add("DEAL PRICE CURRENCY");
            dtfinal.Columns.Add("DEAL PRICE BASE");
            dtfinal.Columns.Add("DEAL PRICE BASE CURRENCY");
            dtfinal.Columns.Add("AMOUNT BASE");
            dtfinal.Columns.Add("AMOUNT BASE CURRENCY");
            dtfinal.Columns.Add("UNREALISED PL");
            dtfinal.Columns.Add("UNREALISED PL CURRENCY");
            dtfinal.Columns.Add("NET PRESENT VALUE");
            dtfinal.Columns.Add("NET PRESENT VALUE CURRENCY");
            dtfinal.Columns.Add("REFERENCE 4 OVERFLOW");
            dtfinal.Columns.Add("TRANS TYPE");
            dtfinal.Columns.Add("ASSET GROUP");
            dtfinal.Columns.Add("EXCHANGE");
            dtfinal.Columns.Add("INSTRUMENT CLASS");
            dtfinal.Columns.Add("INSTRUMENT SUB CLASS");
            dtfinal.Columns.Add("ITEM MLNV");
            dtfinal.Columns.Add("SORT FLAG");
            dtfinal.Columns.Add("CONTRACT OR LOT SIZE");
            dtfinal.Columns.Add("NET OPTION VALUE");
            dtfinal.Columns.Add("TOTAL EQUITY");
            dtfinal.Columns.Add("COLLATERAL");
            dtfinal.Columns.Add("OPTION PREMIUMS");
            dtfinal.Columns.Add("MARKET VALUE BASE");
            dtfinal.Columns.Add("POSITION VALUE BASE");
            dtfinal.Columns.Add("CASH BALANCE");
            dtfinal.Columns.Add("NET VALUE FUTURES");
            dtfinal.Columns.Add("NET EQUITY");
            dtfinal.Columns.Add("NET VALUE FORWARDS");
            dtfinal.Columns.Add("INITIAL MARGIN");
            dtfinal.Columns.Add("CASH IN OR OUT");
            dtfinal.Columns.Add("REALISED P OR L");
            dtfinal.Columns.Add("OPENING CASH BALANCE");
            dtfinal.Columns.Add("COMMISSIONS");
            dtfinal.Columns.Add("MARKET VALUE CURRENCY");
            dtfinal.Columns.Add("NET ITEM TYPE");
            dtfinal.Columns.Add("STYLE FLAG");
            dtfinal.Columns.Add("EXPIRATION OR DELIVERY DATE");
            dtfinal.Columns.Add("LINK UNLINK TYPE");
            dtfinal.Columns.Add("RECORD TYPE FLAG");
            dtfinal.Columns.Add("PUT OR CALL FLAG");
            dtfinal.Columns.Add("CLEARING BROKER");
            dtfinal.Columns.Add("POSTING TYPE");
            dtfinal.Columns.Add("REBOOK REFERENCE");
            dtfinal.Columns.Add("FRONT END REFERENCE");
            dtfinal.Columns.Add("EXCHANGE CODE");
            dtfinal.Columns.Add("EXECUTING BROKER");
            dtfinal.Columns.Add("VERSION NUMBER");
            dtfinal.Columns.Add("XFLAG11");
            dtfinal.Columns.Add("XFLAG12");
            dtfinal.Columns.Add("XFLAG13");
            dtfinal.Columns.Add("XFLAG14");
            dtfinal.Columns.Add("XFLAG15");
            dtfinal.Columns.Add("XFLAG16");
            dtfinal.Columns.Add("XFLAG17");
            dtfinal.Columns.Add("XFLAG18");
            dtfinal.Columns.Add("XFLAG19");
            dtfinal.Columns.Add("XFLAG20");
            dtfinal.Columns.Add("XSTR13");
            dtfinal.Columns.Add("XSTR14");
            dtfinal.Columns.Add("XSTR15");
            dtfinal.Columns.Add("XSTR16");
            dtfinal.Columns.Add("XSTR17");
            dtfinal.Columns.Add("OURREF");
            #endregion

            int counter = 0;

            if (dtexcel2.Rows.Count > 0)
            {
                for (int j = 0; j < dtexcel2.Rows.Count; j++)
                {
                    Double SumAmount = 0;
                    string XSTR8 = dtexcel2.Rows[j]["XSTR8"].ToString();
                    string expression = "XSTR8=" + "'" + XSTR8 + "'";
                    DataTable dtNew = new DataTable();
                    DataRow[] foundRows;
                    DataRow[] foundRows1;
                    DataRow[] foundRows2;
                    DataRow[] foundRows3;

                    foundRows = dtexcel1.Select(expression);

                    for (int i = 0; i < foundRows.Length; i++)
                    {
                        Double Amount = Convert.ToDouble(foundRows[i][11].ToString());
                        //Double Amount = Convert.ToDouble(foundRows[i][0].ToString());
                        string Sign = foundRows[i][12].ToString();
                        //string Sign = foundRows[i][1].ToString();
                        if (Sign == "D")
                        {
                            Amount = -1 * Amount;
                        }
                        SumAmount = SumAmount + Amount;
                    }
                    string AccountExpression = "[BankCode] = '" + XSTR8 + "'";
                    foundRows3 = dtexcel5.Select(AccountExpression);
                    string FeedId = foundRows3[0][1].ToString();
                    string AccountName = foundRows3[0][2].ToString();
                    string AccountNo = foundRows3[0][3].ToString();

                    string condition = "[Sub Acc No] = '" + FeedId + "'";

                    if (dtexcel6.Rows.Count > 0)
                    {

                        foundRows1 = dtexcel6.Select(condition);
                        Double MissingBalance = 0;
                        MissingBalance = Convert.ToDouble(foundRows1[0][6].ToString());
                        Double SumAmount_New = Convert.ToDouble(SumAmount.ToString("#.00"));

                        if (MissingBalance == SumAmount_New)
                        {
                            foundRows2 = dtexcel7.Select(condition);
                            //string OpBal = foundRows2[0][5].ToString();
                            Double OpBal = Convert.ToDouble(foundRows2[0][5].ToString());
                            string OpBalDate = foundRows2[0][4].ToString();

                            for (int k = 0; k < foundRows.Length; k++)
                            {
                                if (k == 0 && counter == 0)
                                {

                                }
                                else
                                {
                                    counter++;
                                }
                                //string Amount = dtexcel1f.Rows[counter]["AMOUNT"].ToString();
                                Double Amount = Convert.ToDouble(dtexcel1.Rows[counter]["AMOUNT"].ToString());
                                string sign = dtexcel1.Rows[counter]["SIGN"].ToString();
                                string Reference2 = dtexcel1.Rows[counter]["REFERENCE 2"].ToString();
                                string ValueDate = dtexcel1.Rows[counter]["VALUE DATE"].ToString();
                                string XSTR3 = dtexcel1.Rows[counter]["XSTR3"].ToString();
                                string BaseCode = dtexcel1.Rows[counter]["XSTR8"].ToString();
                                Double ClosingBalance = Convert.ToDouble(OpBal) + MissingBalance;

                                string OpeningBalDate = GetDateFormat(OpBalDate);
                                DateTime OpeningBalDate1 = DateTime.ParseExact(OpeningBalDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                                OpeningBalDate = OpeningBalDate1.ToString("dd/MM/yyyy");

                                string strValueDate = GetDateFormat(OpBalDate);
                                DateTime dateT_ValueDate = DateTime.ParseExact(strValueDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                                strValueDate = dateT_ValueDate.ToString("dd/MM/yyyy");
                                dtfinal.Rows.Add();
                                dtfinal.Rows[counter][0] = "'" + OpBal.ToString("#0.000");
                                dtfinal.Rows[counter][1] = "INR";
                                dtfinal.Rows[counter][2] = OpeningBalDate;
                                dtfinal.Rows[counter][3] = "F";
                                dtfinal.Rows[counter][5] = "S";
                                dtfinal.Rows[counter][6] = 1;
                                dtfinal.Rows[counter][7] = 2;
                                dtfinal.Rows[counter][8] = FeedId;
                                dtfinal.Rows[counter][9] = AccountNo;
                                dtfinal.Rows[counter][11] = "'" + Amount.ToString("#0.000");
                                dtfinal.Rows[counter][12] = sign;
                                dtfinal.Rows[counter][15] = Reference2;
                                dtfinal.Rows[counter][18] = strValueDate;
                                dtfinal.Rows[counter][58] = XSTR3;
                                dtfinal.Rows[counter][60] = AccountName;
                                dtfinal.Rows[counter][63] = BaseCode;
                                dtfinal.Rows[counter][76] = "'" + ClosingBalance.ToString("#0.000");
                                dtfinal.Rows[counter][77] = "INR";
                                dtfinal.Rows[counter][78] = OpeningBalDate;
                                dtfinal.Rows[counter][79] = "F";


                            }
                        }
                        else
                        {
                        }
                    }
                }
            }
            if (dtfinal.Rows.Count > 0)
            {
                ExportToExcel(dtfinal, Output_Path, OutputFileName);
                RenameExtension(Output_Path, Recon_name, Recon_Date, OutputFileName);
            }

            else
            {

            }

        }

        public string GetDateFormat(string dat)
        {
            string val = "";
            string[] ar1 = dat.Trim().Split(' ');
            if (dat.ToString().Trim() != "")
            {
                string[] ar2 = ar1[0].ToString().Trim().Split('/');
                if (ar2[1].Length == 1 && ar2[0].Length == 2)
                {
                    val = "0" + ar2[1] + "/" + ar2[0] + "/" + ar2[2];
                }
                else if (ar2[1].Length == 2 && ar2[0].Length == 1)
                {
                    val = ar2[1] + "/" + "0" + ar2[0] + "/" + ar2[2];
                }
                else if (ar2[0].Length == 1 && ar2[1].Length == 1)
                {
                    val = "0" + ar2[1] + "/" + "0" + ar2[0] + "/" + ar2[2];
                }
                else if (ar2[0].Length == 2 && ar2[1].Length == 2)
                {
                    val = ar2[1] + "/" + ar2[0] + "/" + ar2[2];
                }

            }

            return val;
        }


        public void ExportToExcel(DataTable tbl, string Output_Path, string Formatted_File_Name)
        {
            

            // load excel, and create a new workbook
            var excelApp = new Microsoft.Office.Interop.Excel.Application();

            Microsoft.Office.Interop.Excel.Workbook workBook = null;
            workBook = excelApp.Workbooks.Add(Type.Missing);                // single worksheet
            Microsoft.Office.Interop.Excel._Worksheet workSheet = (Microsoft.Office.Interop.Excel.Worksheet)workBook.Worksheets.Add(Type.Missing);
            excelApp.DisplayAlerts = false;
            excelApp.Visible = false;
            for (var i = 0; i < tbl.Columns.Count; i++)
            {
                if (tbl.Columns[i].ColumnName == "THEIRREF@")
                {
                    workSheet.Cells[1, i + 1] = tbl.Columns[i].ColumnName.Replace("@", "");
                }
                else
                {
                    workSheet.Cells[1, i + 1] = tbl.Columns[i].ColumnName;
                }
            }

            // rows
            for (var i = 0; i < tbl.Rows.Count; i++)
            {
                // to do: format datetime values before printing
                for (var j = 0; j < tbl.Columns.Count; j++)
                {
                    workSheet.Cells[i + 2, j + 1] = tbl.Rows[i][j];
                }
            }
            try
            {
                Excel.Range usedrange = workSheet.UsedRange;
                Excel.Range r = usedrange.get_Range("A1", Type.Missing);
                workSheet.Columns.EntireColumn.AutoFit();
                if (!File.Exists(Output_Path + Formatted_File_Name+".xlsx"))
                    workBook.SaveCopyAs(Output_Path + Formatted_File_Name + ".xlsx");
                else
                    workBook.SaveCopyAs(Output_Path + Formatted_File_Name + "_2.xlsx");
                //File.Copy(excelFilePath, (Output_Path + "Final_Output.xls"));
                excelApp.Quit();
            }
            catch
            {

            }
            ReleaseComObject(workSheet);
            ReleaseComObject(workBook);
            ReleaseComObject(excelApp);
            
        }
        public void RenameExtension(string Output_Path, string Recon_name, string Recon_Date,string OutputFileName)
        {
            //string Output_Path = @"C:\1. Sarbeswar\Code\ARC\My Dev Code\OutPutFile\PhantomNostro\";
            //string Formatted_File_Name = "PSGL_RP";
            string inputFilePath = Output_Path + OutputFileName + ".xlsx";
            string files = Output_Path + OutputFileName + ".csv";
            //string Share_Path = @"C:\1. Sarbeswar\Code\ARC\My Dev Code\OutPutFile\";
            Microsoft.Office.Interop.Excel.Application app = new Microsoft.Office.Interop.Excel.Application();
            app.DisplayAlerts = false;
            app.Visible = false;
            Microsoft.Office.Interop.Excel.Workbook wb = app.Workbooks.Open(inputFilePath, Type.Missing, false, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
            // this does not throw exception if file doesnt exist


            wb.SaveAs(files, Microsoft.Office.Interop.Excel.XlFileFormat.xlCSVWindows, Type.Missing, Type.Missing, false, false, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlExclusive, Microsoft.Office.Interop.Excel.XlSaveConflictResolution.xlLocalSessionChanges, false, Type.Missing, Type.Missing, Type.Missing);
            wb.Close(false, Type.Missing, Type.Missing);
            app.Quit();
            ReleaseComObject(wb);
            ReleaseComObject(app);

            File.Move(files, Path.ChangeExtension(Output_Path + OutputFileName + ".csv", ".txt"));
            File.Delete(Output_Path + OutputFileName + ".dat");
            Fileses(Output_Path, Recon_name);
            File.Delete(Output_Path + OutputFileName + ".xlsx");
        }
        public void Fileses(string share, string Recon_Name)
        {
            try
            {
                string str = "";
                if (Directory.Exists(share))
                {
                    string[] files = System.IO.Directory.GetFiles(share);
                    string name = "";

                    for (int i = 0; i <= files.Length - 1; i++)
                    {
                        if (files[i].Contains(".txt"))
                        {
                            str = files[i];

                            name = Path.GetFileName(str);
                            string text = File.ReadAllText(str);
                            text = text.Replace(",", "|");
                            File.WriteAllText(str, text);                         
                            
                            
                            File.Move(str, Path.ChangeExtension(share + name, ".tlm"));
                            str = "";
                            name = "";
                        }
                    }
                }
                else
                {
                    // MessageBox.Show("Directory does not Exists");
                }
            }
            catch
            {
            }
        }
        public void ReleaseComObject(object ob)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(ob);
                ob = null;
            }
            catch
            {
                ob = null;
            }
            finally
            {
                GC.Collect(GC.MaxGeneration);
                GC.WaitForPendingFinalizers();
            }
        }
    }
}
