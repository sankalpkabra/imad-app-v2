﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;
using System.Configuration;

namespace ARC_Application
{
    public partial class Admin_DashBoard : Form
    {
        //string User_Name;
        Formatting_Logics obj = new Formatting_Logics();
        static string conString = ConfigurationManager.ConnectionStrings["ARC_conStr"].ConnectionString;
        string date;
        string selectedProduct;
        string selectedcountry;
        int i;
        int j;
        DataTable dt = new DataTable();
        //Image i1 = Image.FromFile(@"\\10.132.5.214\TempFiles\ARC Main Solutions\ARC_Latest_Solution\Images\index1.jpg");
        //Image i2 = Image.FromFile(@"\\10.132.5.214\TempFiles\ARC Main Solutions\ARC_Latest_Solution\Images\index2.jpg");
        //Image i3 = Image.FromFile(@"\\10.132.5.214\TempFiles\ARC Main Solutions\ARC_Latest_Solution\Images\index3.png");
        int Total;
        int Completed;
        string sla;
        string _reconName = string.Empty;
        string temprecon = string.Empty;
        // SqlConnection con;
        SqlCommand cmd;
        SqlDataAdapter da;

        public Admin_DashBoard()
        {
            InitializeComponent();
            ViewRecord();
            refreshdata();
            // Create_Directory();
            Timer timer = new Timer();
            timer.Interval = (100 * 2000); // 10 secs
            timer.Tick += new EventHandler(timer1_Tick);
            timer.Start();
        }

        private void Admin_DashBoard_Load(object sender, EventArgs e)
        {
            dataGridView2.Visible = false;

            //ViewRecord();
            //SqlConnection con = new SqlConnection(@"Data Source=ukwpidsql500i1.gdc-dev.net\DEV_CL01_IN01, 10501;Initial Catalog=CRC_QMT;User ID=CRCAdmin;Password=c275bpOSJ;");
            //DataTable dt1 = new DataTable();
            //con.Open();
            //SqlCommand cmd1 = new SqlCommand("ARC_SP_TotalReconCount", con);
            //cmd1.CommandType = CommandType.StoredProcedure;
            //cmd1.Parameters.AddWithValue("@Recon", "");
            //SqlDataAdapter da1 = new SqlDataAdapter(cmd1);
            //da1.Fill(dt1);
            //con.Close();
            //SqlConnection con1 = new SqlConnection(@"Data Source=ukwpidsql500i1.gdc-dev.net\DEV_CL01_IN01, 10501;Initial Catalog=CRC_QMT;User ID=CRCAdmin;Password=c275bpOSJ;");
            //DataTable dt2 = new DataTable();
            //con1.Open();
            //SqlCommand cmd2 = new SqlCommand("ARC_SP_TotalProcessedReconCount", con1);

            //cmd2.CommandType = CommandType.StoredProcedure;
            //cmd2.Parameters.AddWithValue("@Recon", "Singapore SEC RPR");
            //SqlDataAdapter da2 = new SqlDataAdapter(cmd2);
            //da2.Fill(dt2);
            //con1.Close();
            //DataTable dt = new DataTable();
            //dt.Rows.Add();
            //dt.Columns.Add("Recon Name");
            //dt.Columns.Add("Status", typeof(byte[]));
            //dt.Rows[0][0] = "Singapore SEC RPR";
            //if (dt1.Rows[0][0].ToString().Trim() == dt2.Rows[0][0].ToString().Trim())
            //{
            //    dt.Rows[0][1] = imageToByteArray(i1);
            //}

            //else
            //{
            //    if (dt2.Rows.Count == 0)
            //    {
            //        dt.Rows[0][1] = imageToByteArray(i2);
            //    }
            //    else
            //    {
            //        dt.Rows[0][1] = imageToByteArray(i3);
            //    }
            //}
            //DGV_AData.AllowUserToAddRows = false;
            //DGV_AData.DataSource = dt;


        }

        public void refreshdata()
        {
            DataTable dt_Final = new DataTable();
            dt_Final.Columns.Add("Country_Id");
            dt_Final.Columns.Add("Country_Name");
            dt_Final.Rows.Add("0", "--All--");
            SqlConnection con = new SqlConnection(conString);
            con.Open();
            SqlCommand cmd = new SqlCommand("ARC_SP_GetCountries", con);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);

            foreach (DataRow d in dt.Rows)
            {
                dt_Final.ImportRow(d);
            }

            cmb_cntry.SelectedIndexChanged -= new EventHandler(cmb_cntry_SelectedIndexChanged);
            cmb_cntry.ValueMember = "Country_Id";
            cmb_cntry.DisplayMember = "Country_Name";
            cmb_cntry.DataSource = dt_Final;
            cmb_cntry.SelectedIndexChanged -= new EventHandler(cmb_cntry_SelectedIndexChanged);

            DataTable dt_Final1 = new DataTable();
            dt_Final1.Columns.Add("Product_ID");
            dt_Final1.Columns.Add("Product_name");
            dt_Final1.Rows.Add("0", "--All--");
            cmd = new SqlCommand("ARC_SP_GetProducts", con);
            cmd.CommandType = CommandType.StoredProcedure;
            sda = new SqlDataAdapter(cmd);
            dt = new DataTable();
            sda.Fill(dt);
            foreach (DataRow d in dt.Rows)
            {
                dt_Final1.ImportRow(d);
            }
            cmb_Prdt.SelectedIndexChanged -= new EventHandler(cmb_Prdt_SelectedIndexChanged);
            cmb_Prdt.ValueMember = "Product_ID";
            cmb_Prdt.DisplayMember = "Product_name";
            cmb_Prdt.DataSource = dt_Final1;
            cmb_Prdt.SelectedIndexChanged += new EventHandler(cmb_Prdt_SelectedIndexChanged);
            con.Close();

        }

        public void ViewRecord()
        {
            date = DateTime.Now.ToString("HH:MM");
            try
            {
                SqlConnection con = new SqlConnection(conString);
                con.Open();
                cmd = new SqlCommand("ARC_SP_TotalProcessedReconCount", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Action", "All");
                da = new SqlDataAdapter(cmd);
                // DataTable dt1 = new DataTable();
                da.Fill(dt);
                //con.Close();
                //con.Open();
                //cmd = new SqlCommand("", con);
                dt.Columns.Add("Time To SLA");
                dt.Columns.Add("Actions", typeof(byte[]));
                if (dt.Columns.Contains("Actions"))
                {
                    for (int indx = 0; indx < dt.Rows.Count; indx++)
                    {
                        string sd1 = dt.Rows[indx][4].ToString();
                        string sd2 = date.ToString();
                        DateTime d = Convert.ToDateTime(dt.Rows[indx][5]);
                        DateTime d1 = Convert.ToDateTime(date);
                        sla = (d - d1).ToString();
                        if (Convert.ToBoolean(dt.Rows[indx][7]) == true && d.TimeOfDay < d1.TimeOfDay)
                        {
                            dt.Rows[indx][8] = "0.00";
                            dt.Rows[indx][9] = imageToByteArray(i1);
                        }
                        else if (Convert.ToBoolean(dt.Rows[indx][7]) == false && d.TimeOfDay > d1.TimeOfDay)
                        {
                            dt.Rows[indx][8] = sla;
                            dt.Rows[indx][9] = imageToByteArray(i3);
                        }
                        else if (Convert.ToBoolean(dt.Rows[indx][7]) == false && d.TimeOfDay < d1.TimeOfDay)
                        {
                            dt.Rows[indx][8] = sla;
                            dt.Rows[indx][9] = imageToByteArray(i2);
                        }
                        else if (Convert.ToBoolean(dt.Rows[indx][7]) == true && d.TimeOfDay > d1.TimeOfDay)
                        {
                            dt.Rows[indx][8] = "0.00";
                            dt.Rows[indx][9] = imageToByteArray(i1);
                        }
                    }
                }
                dt.Columns.Remove("Is_Recon_Completed");
                DGV_AData.DataSource = dt;
                con.Close();
                Total_count();
                DGV_AData.AllowUserToAddRows = false;
            }
            catch (Exception)
            { }
        }

        private void cmb_Prdt_SelectedIndexChanged(object sender, EventArgs e)
        {
            j = cmb_Prdt.SelectedIndex;
            selectedProduct = this.cmb_Prdt.GetItemText(this.cmb_Prdt.SelectedItem);
            SqlConnection con = new SqlConnection(conString);
            if (j != 0)
            {
                con.Open();
                dt = new DataTable();
                SqlCommand cmd = new SqlCommand("ARC_SP_TotalProcessedReconCount", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Action", "Product");
                cmd.Parameters.AddWithValue("@Product_ID", null);
                cmd.Parameters.AddWithValue("@Country_Id", null);
                cmd.Parameters.AddWithValue("@Country_Name", null);
                cmd.Parameters.AddWithValue("@team", selectedProduct);

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
                if (!dt.Columns.Contains("Actions"))
                {
                    dt.Columns.Add("Time To SLA");
                    dt.Columns.Add("Actions", typeof(byte[]));

                    for (int indx = 0; indx < dt.Rows.Count; indx++)
                    {
                        DateTime d = Convert.ToDateTime(dt.Rows[indx][5]);
                        DateTime d1 = Convert.ToDateTime(date);
                        sla = (d - d1).ToString();
                        if (Convert.ToBoolean(dt.Rows[indx][7]) == true && d.TimeOfDay < d1.TimeOfDay)
                        {
                            dt.Rows[indx][8] = "0.00";
                            dt.Rows[indx][9] = imageToByteArray(i1);
                        }
                        else if (Convert.ToBoolean(dt.Rows[indx][7]) == false && d.TimeOfDay > d1.TimeOfDay)
                        {
                            dt.Rows[indx][8] = sla;
                            dt.Rows[indx][9] = imageToByteArray(i3);
                        }
                        else if (Convert.ToBoolean(dt.Rows[indx][7]) == false && d.TimeOfDay < d1.TimeOfDay)
                        {
                            dt.Rows[indx][8] = sla;
                            dt.Rows[indx][9] = imageToByteArray(i2);
                        }
                        else if (Convert.ToBoolean(dt.Rows[indx][7]) == true && d.TimeOfDay > d1.TimeOfDay)
                        {
                            dt.Rows[indx][8] = "0.00";
                            dt.Rows[indx][9] = imageToByteArray(i1);
                        }
                    }
                }
                else
                {
                    for (int indx = 0; indx < dt.Rows.Count; indx++)
                    {
                        DateTime d = Convert.ToDateTime(dt.Rows[indx][5]);
                        DateTime d1 = Convert.ToDateTime(date);
                        sla = (d - d1).ToString();
                        if (Convert.ToBoolean(dt.Rows[indx][7]) == true && d.TimeOfDay < d1.TimeOfDay)
                        {
                            dt.Rows[indx][8] = "0.00";
                            dt.Rows[indx][9] = imageToByteArray(i1);
                        }
                        else if (Convert.ToBoolean(dt.Rows[indx][7]) == false && d.TimeOfDay > d1.TimeOfDay)
                        {
                            dt.Rows[indx][8] = sla;
                            dt.Rows[indx][9] = imageToByteArray(i3);
                        }
                        else if (Convert.ToBoolean(dt.Rows[indx][7]) == false && d.TimeOfDay < d1.TimeOfDay)
                        {
                            dt.Rows[indx][8] = sla;
                            dt.Rows[indx][9] = imageToByteArray(i2);
                        }
                        else if (Convert.ToBoolean(dt.Rows[indx][7]) == true && d.TimeOfDay > d1.TimeOfDay)
                        {
                            dt.Rows[indx][8] = "0.00";
                            dt.Rows[indx][9] = imageToByteArray(i1);
                        }
                    }
                }
                dt.Columns.Remove("Is_Recon_Completed");
                DGV_AData.DataSource = dt;
                con.Close();
                Products_count();
                DGV_AData.AllowUserToAddRows = false;

            }

        }

        private void cmb_cntry_SelectedIndexChanged(object sender, EventArgs e)
        {
            i = cmb_cntry.SelectedIndex;
            j = cmb_Prdt.SelectedIndex;
            selectedcountry = this.cmb_cntry.GetItemText(this.cmb_cntry.SelectedItem);
            selectedProduct = this.cmb_Prdt.GetItemText(this.cmb_Prdt.SelectedItem);
            if (j != 0)
            {
                SqlConnection con = new SqlConnection(conString);
                if (i != 0)
                {
                    con.Open();
                    dt = new DataTable();
                    SqlCommand cmd = new SqlCommand("ARC_SP_TotalProcessedReconCount", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Action", "Country");
                    cmd.Parameters.AddWithValue("@Country_Id", null);
                    cmd.Parameters.AddWithValue("@Country_Name", selectedcountry);
                    cmd.Parameters.AddWithValue("@team", selectedProduct);

                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(dt);
                    if (!dt.Columns.Contains("Actions"))
                    {
                        dt.Columns.Add("Time To SLA");
                        dt.Columns.Add("Actions", typeof(byte[]));

                        for (int indx = 0; indx < dt.Rows.Count; indx++)
                        {
                            DateTime d = Convert.ToDateTime(dt.Rows[indx][5]);
                            DateTime d1 = Convert.ToDateTime(date);
                            sla = (d - d1).ToString();
                            if (Convert.ToBoolean(dt.Rows[indx][7]) == true && d.TimeOfDay < d1.TimeOfDay)
                            {
                                dt.Rows[indx][8] = "0.00";
                                dt.Rows[indx][9] = imageToByteArray(i1);
                            }
                            else if (Convert.ToBoolean(dt.Rows[indx][7]) == false && d.TimeOfDay > d1.TimeOfDay)
                            {
                                dt.Rows[indx][8] = sla;
                                dt.Rows[indx][9] = imageToByteArray(i3);
                            }
                            else if (Convert.ToBoolean(dt.Rows[indx][7]) == false && d.TimeOfDay < d1.TimeOfDay)
                            {
                                dt.Rows[indx][8] = sla;
                                dt.Rows[indx][9] = imageToByteArray(i2);
                            }
                            else if (Convert.ToBoolean(dt.Rows[indx][7]) == true && d.TimeOfDay > d1.TimeOfDay)
                            {
                                dt.Rows[indx][8] = "0.00";
                                dt.Rows[indx][9] = imageToByteArray(i1);
                            }
                        }
                    }
                    else
                    {
                        for (int indx = 0; indx < dt.Rows.Count; indx++)
                        {
                            DateTime d = Convert.ToDateTime(dt.Rows[indx][5]);
                            DateTime d1 = Convert.ToDateTime(date);
                            sla = (d - d1).ToString();
                            if (Convert.ToBoolean(dt.Rows[indx][7]) == true && d.TimeOfDay < d1.TimeOfDay)
                            {
                                dt.Rows[indx][8] = "0.00";
                                dt.Rows[indx][9] = imageToByteArray(i1);
                            }
                            else if (Convert.ToBoolean(dt.Rows[indx][7]) == false && d.TimeOfDay > d1.TimeOfDay)
                            {
                                dt.Rows[indx][8] = sla;
                                dt.Rows[indx][9] = imageToByteArray(i3);
                            }
                            else if (Convert.ToBoolean(dt.Rows[indx][7]) == false && d.TimeOfDay < d1.TimeOfDay)
                            {
                                dt.Rows[indx][8] = sla;
                                dt.Rows[indx][9] = imageToByteArray(i2);
                            }
                            else if (Convert.ToBoolean(dt.Rows[indx][7]) == true && d.TimeOfDay > d1.TimeOfDay)
                            {
                                dt.Rows[indx][8] = "0.00";
                                dt.Rows[indx][9] = imageToByteArray(i1);
                            }
                        }
                    }
                    dt.Columns.Remove("Is_Recon_Completed");
                    DGV_AData.DataSource = dt;
                    con.Close();
                    Countrys_count();
                    DGV_AData.AllowUserToAddRows = false;

                }

            }
            else
            {
                MessageBox.Show("Please select the Product ComboBox First!");
                cmb_cntry.SelectedIndex = 0;
            }

        }

        public byte[] imageToByteArray(System.Drawing.Image imageIn)
        {
            MemoryStream ms = new MemoryStream();
            imageIn.Save(ms, System.Drawing.Imaging.ImageFormat.Gif);
            return ms.ToArray();
        }

        protected override void WndProc(ref Message m)
        {
            base.WndProc(ref m);
            if (m.Msg == 0x0112)
            {
                if (m.WParam == new IntPtr(0xF030))
                {

                    lnk_Logout.Location = new Point(1300, 100);
                    pictureBox1.Location = new Point(1200, -1);
                    DGV_AData.Width = 1350;
                    DGV_AData.Height = 330;
                    DGV_AData.Location = new Point(4, 185);
                    Btn_Clr.Location = new Point(1280, 131);

                }
                //else if (m.WParam == new IntPtr(0xF120))
                //{
                //    Dashboard.ActiveForm.Size = new Size(1201, 494);//this.Size = new Size(1201, 494);
                //    Dashboard.ActiveForm.Location = new Point();
                //    Dashboard.ActiveForm.StartPosition = FormStartPosition.CenterScreen;
                //    DGV_AData.Height = 200;
                //    DGV_AData.Width = 1220;
                //    DGV_AData.Location = new Point(4, 185);
                //    lnk_Logout.Location = new Point(1170, 80);
                //    Btn_Clr.Location = new Point(1150, 130);
                //}

            }
        }

        private void Btn_Clr_Click(object sender, EventArgs e)
        {
            cmb_cntry.SelectedIndex = 0;
            cmb_Prdt.SelectedIndex = 0;
            ViewRecord();
            //dateTimePicker1.ResetText();
            //Feed_Status.Text = "";
        }

        private void lnk_Logout_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            foreach (var p in System.Diagnostics.Process.GetProcessesByName("OpenSpan.Runtime"))
            {
                p.Kill();
            }
            this.Close();
            MessageBox.Show("You Have LoggedOut Successfully");
        }

        public void Total_count()
        {

            SqlConnection con = new SqlConnection(conString);
            con.Open();
            SqlCommand com = new SqlCommand("select count (*) as Total from ARC_Recon_Master", con);
            com.CommandType = CommandType.Text;
            SqlDataReader dr = com.ExecuteReader();
            while (dr.Read())
            {
                if (dr.HasRows == true)
                {
                    Total = (int)dr["Total"];
                }
            }
            con.Close();
            con.Open();
            com = new SqlCommand("select count (*) as Completed from ARC_Recon_Master where Is_Recon_Completed= 'true'", con);
            com.CommandType = CommandType.Text;
            dr = com.ExecuteReader();
            while (dr.Read())
            {
                if (dr.HasRows == true)
                {
                    Completed = (int)dr["Completed"];
                }
            }
            con.Close();
            lbl_cnt.Text = Total.ToString();
            lbl_com_cnt.Text = Completed.ToString();
            lbl_pen_cnt.Text = (Total - Completed).ToString();
        }

        public void Products_count()
        {

            selectedProduct = this.cmb_Prdt.GetItemText(this.cmb_Prdt.SelectedItem);
            SqlConnection con = new SqlConnection(conString);
            con.Open();
            SqlCommand com = new SqlCommand("select count (*) as Total from ARC_Recon_Master where Team='" + selectedProduct + "'", con);
            com.CommandType = CommandType.Text;
            SqlDataReader dr = com.ExecuteReader();
            while (dr.Read())
            {
                if (dr.HasRows == true)
                {
                    Total = (int)dr["Total"];
                }
            }
            con.Close();
            con.Open();
            com = new SqlCommand("select count (*) as Completed from ARC_Recon_Master where Is_Recon_Completed= 'true' and Team='" + selectedProduct + "'", con);
            com.CommandType = CommandType.Text;
            dr = com.ExecuteReader();
            while (dr.Read())
            {
                if (dr.HasRows == true)
                {
                    Completed = (int)dr["Completed"];
                }
            }
            con.Close();
            lbl_cnt.Text = Total.ToString();
            lbl_com_cnt.Text = Completed.ToString();
            lbl_pen_cnt.Text = (Total - Completed).ToString();
        }

        public void Countrys_count()
        {
            selectedcountry = this.cmb_cntry.GetItemText(this.cmb_cntry.SelectedItem);
            SqlConnection con = new SqlConnection(conString);
            con.Open();
            SqlCommand com = new SqlCommand("select count (*) as Total from ARC_Recon_Master where Country='" + selectedcountry + "'", con);
            com.CommandType = CommandType.Text;
            SqlDataReader dr = com.ExecuteReader();
            while (dr.Read())
            {
                if (dr.HasRows == true)
                {
                    Total = (int)dr["Total"];
                }
            }
            con.Close();
            con.Open();
            com = new SqlCommand("select count (*) as Completed from ARC_Recon_Master where Is_Recon_Completed= 'true' and Country='" + i + "'", con);
            com.CommandType = CommandType.Text;
            dr = com.ExecuteReader();
            while (dr.Read())
            {
                if (dr.HasRows == true)
                {
                    Completed = (int)dr["Completed"];
                }
            }
            con.Close();
            lbl_cnt.Text = Total.ToString();
            lbl_com_cnt.Text = Completed.ToString();
            lbl_pen_cnt.Text = (Total - Completed).ToString();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            ViewRecord();
        }

        private void DGV_AData_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

            SqlConnection con = new SqlConnection(conString);
            DataTable dt_DGV = new DataTable();
            if (e.RowIndex == -1) return;

            if (DGV_AData.CurrentCell.ColumnIndex.Equals(3))
            {
                if (DGV_AData.Rows[e.RowIndex].Cells[e.ColumnIndex].Value != null)
                {
                    _reconName = DGV_AData.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString();

                    if (temprecon == _reconName)
                    {
                        if (dataGridView2.Visible == true)
                        {
                            dataGridView2.Visible = false;
                        }
                        else
                        {
                            dataGridView2.Visible = true;
                            ViewRecords_DB(_reconName);
                        }
                    }
                    else
                    {
                        temprecon = _reconName;

                        dataGridView2.Visible = true;
                        ViewRecords_DB(_reconName);
                    }
                }
            }




        }

        public void ViewRecords_DB(string recon_name)
        {
            try
            {
                SqlConnection con = new SqlConnection(conString);
                date = DateTime.Now.ToString("hh:mm");
                con.Open();
                SqlCommand cmd = new SqlCommand("Select Scope_Id as [S No],Team,Country_Name,Recon,CONVERT(VARCHAR(8), SLA_Time, 108) as SLA_Time,CONVERT(VARCHAR(8), Receipt_Time, 108) as Receipt_Time,Report_Source_File_Name,FTP_File_Format_Name,Source_Application,IsProcessed FROM ARC_Scope_BaseLine where In_Scope_For_ARC='yes' and Recon ='" + recon_name + "'", con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                int c = 1;
                for (int idx = 0; idx < dt.Rows.Count; idx++)
                {
                    dt.Rows[idx][0] = c;
                    c++;
                }
                dt.Columns.Add("Actions", typeof(byte[]));
                if (dt.Columns.Contains("Actions"))
                {
                    for (int indx = 0; indx < dt.Rows.Count; indx++)
                    {
                        DateTime d = Convert.ToDateTime(dt.Rows[indx][4]);
                        DateTime d1 = Convert.ToDateTime(date);
                        if (Convert.ToBoolean(dt.Rows[indx][9]) == true && d.TimeOfDay < d1.TimeOfDay)
                        {
                            dt.Rows[indx][10] = obj.imageToByteArray(i1);
                        }
                        else if (Convert.ToBoolean(dt.Rows[indx][9]) == false && d.TimeOfDay > d1.TimeOfDay)
                        {
                            dt.Rows[indx][10] = obj.imageToByteArray(i3);
                        }
                        else if (Convert.ToBoolean(dt.Rows[indx][9]) == false && d.TimeOfDay < d1.TimeOfDay)
                        {
                            dt.Rows[indx][10] = obj.imageToByteArray(i2);
                        }
                        else if (Convert.ToBoolean(dt.Rows[indx][9]) == true && d.TimeOfDay > d1.TimeOfDay)
                        {
                            dt.Rows[indx][10] = obj.imageToByteArray(i1);
                        }
                    }
                }

                //Form1 f1 = new Form1(dt);
                //f1.Show();
                //f1.dataGridView1.Columns[10].Visible = false;


                dataGridView2.DataSource = dt;

                foreach (DataGridViewColumn dc in dataGridView2.Columns)
                {
                    dc.SortMode = DataGridViewColumnSortMode.NotSortable;

                    if (dc.HeaderText == "Select")
                    {
                        dc.ReadOnly = false;
                    }
                    else
                    {
                        dc.ReadOnly = true;
                    }
                }
                con.Close();
                Total_count();
            }
            catch
            {

            }
        }

    }
}