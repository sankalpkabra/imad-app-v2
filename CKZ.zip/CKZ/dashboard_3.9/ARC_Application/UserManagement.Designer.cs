﻿namespace ARC_Application
{
    partial class UserManagement
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UserManagement));
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Btn_cncl = new System.Windows.Forms.Button();
            this.Btn_Save = new System.Windows.Forms.Button();
            this.Btn_Search = new System.Windows.Forms.Button();
            this.lbl_Mod = new System.Windows.Forms.Label();
            this.cmb_mod = new System.Windows.Forms.ComboBox();
            this.cmb_cnty = new System.Windows.Forms.ComboBox();
            this.cmb_Rol = new System.Windows.Forms.ComboBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.lbl_rol = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lbl_Nam = new System.Windows.Forms.Label();
            this.lbl_Lmid = new System.Windows.Forms.Label();
            this.lbl_Psid = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Location = new System.Drawing.Point(-2, -2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1006, 103);
            this.panel1.TabIndex = 0;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(14, 14);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(161, 70);
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Transparent;
            this.panel2.Location = new System.Drawing.Point(181, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(825, 103);
            this.panel2.TabIndex = 0;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.dataGridView1);
            this.panel3.Controls.Add(this.Btn_cncl);
            this.panel3.Controls.Add(this.Btn_Save);
            this.panel3.Controls.Add(this.Btn_Search);
            this.panel3.Controls.Add(this.lbl_Mod);
            this.panel3.Controls.Add(this.cmb_mod);
            this.panel3.Controls.Add(this.cmb_cnty);
            this.panel3.Controls.Add(this.cmb_Rol);
            this.panel3.Controls.Add(this.textBox3);
            this.panel3.Controls.Add(this.textBox2);
            this.panel3.Controls.Add(this.textBox1);
            this.panel3.Controls.Add(this.lbl_rol);
            this.panel3.Controls.Add(this.label4);
            this.panel3.Controls.Add(this.lbl_Nam);
            this.panel3.Controls.Add(this.lbl_Lmid);
            this.panel3.Controls.Add(this.lbl_Psid);
            this.panel3.Location = new System.Drawing.Point(-2, 98);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1006, 336);
            this.panel3.TabIndex = 1;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(527, 48);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(240, 150);
            this.dataGridView1.TabIndex = 15;
            // 
            // Btn_cncl
            // 
            this.Btn_cncl.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.Btn_cncl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_cncl.ForeColor = System.Drawing.Color.White;
            this.Btn_cncl.Location = new System.Drawing.Point(438, 259);
            this.Btn_cncl.Name = "Btn_cncl";
            this.Btn_cncl.Size = new System.Drawing.Size(75, 28);
            this.Btn_cncl.TabIndex = 14;
            this.Btn_cncl.Text = "cancel";
            this.Btn_cncl.UseVisualStyleBackColor = false;
            // 
            // Btn_Save
            // 
            this.Btn_Save.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.Btn_Save.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_Save.ForeColor = System.Drawing.Color.White;
            this.Btn_Save.Location = new System.Drawing.Point(328, 259);
            this.Btn_Save.Name = "Btn_Save";
            this.Btn_Save.Size = new System.Drawing.Size(75, 28);
            this.Btn_Save.TabIndex = 13;
            this.Btn_Save.Text = "Save";
            this.Btn_Save.UseVisualStyleBackColor = false;
            // 
            // Btn_Search
            // 
            this.Btn_Search.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.Btn_Search.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_Search.ForeColor = System.Drawing.Color.White;
            this.Btn_Search.Location = new System.Drawing.Point(216, 259);
            this.Btn_Search.Name = "Btn_Search";
            this.Btn_Search.Size = new System.Drawing.Size(75, 28);
            this.Btn_Search.TabIndex = 12;
            this.Btn_Search.Text = "Search";
            this.Btn_Search.UseVisualStyleBackColor = false;
            this.Btn_Search.Click += new System.EventHandler(this.Btn_Search_Click);
            // 
            // lbl_Mod
            // 
            this.lbl_Mod.AutoSize = true;
            this.lbl_Mod.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Mod.Location = new System.Drawing.Point(198, 213);
            this.lbl_Mod.Name = "lbl_Mod";
            this.lbl_Mod.Size = new System.Drawing.Size(55, 15);
            this.lbl_Mod.TabIndex = 11;
            this.lbl_Mod.Text = "Module";
            // 
            // cmb_mod
            // 
            this.cmb_mod.FormattingEnabled = true;
            this.cmb_mod.Location = new System.Drawing.Point(328, 205);
            this.cmb_mod.Name = "cmb_mod";
            this.cmb_mod.Size = new System.Drawing.Size(121, 21);
            this.cmb_mod.TabIndex = 10;
            // 
            // cmb_cnty
            // 
            this.cmb_cnty.FormattingEnabled = true;
            this.cmb_cnty.Location = new System.Drawing.Point(328, 169);
            this.cmb_cnty.Name = "cmb_cnty";
            this.cmb_cnty.Size = new System.Drawing.Size(121, 21);
            this.cmb_cnty.TabIndex = 9;
            // 
            // cmb_Rol
            // 
            this.cmb_Rol.FormattingEnabled = true;
            this.cmb_Rol.Items.AddRange(new object[] {
            "Super Admin",
            "Admin",
            "Checker",
            "Maker"});
            this.cmb_Rol.Location = new System.Drawing.Point(328, 137);
            this.cmb_Rol.Name = "cmb_Rol";
            this.cmb_Rol.Size = new System.Drawing.Size(121, 21);
            this.cmb_Rol.TabIndex = 8;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(328, 74);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(100, 20);
            this.textBox3.TabIndex = 7;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(328, 105);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 20);
            this.textBox2.TabIndex = 6;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(328, 45);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 5;
            // 
            // lbl_rol
            // 
            this.lbl_rol.AutoSize = true;
            this.lbl_rol.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_rol.Location = new System.Drawing.Point(198, 145);
            this.lbl_rol.Name = "lbl_rol";
            this.lbl_rol.Size = new System.Drawing.Size(69, 15);
            this.lbl_rol.TabIndex = 4;
            this.lbl_rol.Text = "Role Flag";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(198, 177);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(55, 15);
            this.label4.TabIndex = 3;
            this.label4.Text = "Country";
            // 
            // lbl_Nam
            // 
            this.lbl_Nam.AutoSize = true;
            this.lbl_Nam.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Nam.Location = new System.Drawing.Point(198, 74);
            this.lbl_Nam.Name = "lbl_Nam";
            this.lbl_Nam.Size = new System.Drawing.Size(45, 15);
            this.lbl_Nam.TabIndex = 2;
            this.lbl_Nam.Text = "Name";
            // 
            // lbl_Lmid
            // 
            this.lbl_Lmid.AutoSize = true;
            this.lbl_Lmid.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Lmid.Location = new System.Drawing.Point(178, 106);
            this.lbl_Lmid.Name = "lbl_Lmid";
            this.lbl_Lmid.Size = new System.Drawing.Size(128, 15);
            this.lbl_Lmid.TabIndex = 1;
            this.lbl_Lmid.Text = "LineManager PSID";
            // 
            // lbl_Psid
            // 
            this.lbl_Psid.AutoSize = true;
            this.lbl_Psid.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Psid.Location = new System.Drawing.Point(198, 48);
            this.lbl_Psid.Name = "lbl_Psid";
            this.lbl_Psid.Size = new System.Drawing.Size(39, 15);
            this.lbl_Psid.TabIndex = 0;
            this.lbl_Psid.Text = "PSID";
            // 
            // UserManagement
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(777, 432);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.Name = "UserManagement";
            this.Text = "UserManagement";
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button Btn_cncl;
        private System.Windows.Forms.Button Btn_Save;
        private System.Windows.Forms.Button Btn_Search;
        private System.Windows.Forms.Label lbl_Mod;
        private System.Windows.Forms.ComboBox cmb_mod;
        private System.Windows.Forms.ComboBox cmb_cnty;
        private System.Windows.Forms.ComboBox cmb_Rol;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label lbl_rol;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lbl_Nam;
        private System.Windows.Forms.Label lbl_Lmid;
        private System.Windows.Forms.Label lbl_Psid;
        private System.Windows.Forms.DataGridView dataGridView1;
    }
}