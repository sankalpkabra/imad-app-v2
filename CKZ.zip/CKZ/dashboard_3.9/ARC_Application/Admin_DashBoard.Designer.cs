﻿using System.Windows.Forms;
namespace ARC_Application
{
    partial class Admin_DashBoard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Admin_DashBoard));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lbl_cntry = new System.Windows.Forms.Label();
            this.cmb_cntry = new System.Windows.Forms.ComboBox();
            this.lbl_Prd = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Pnl_User = new System.Windows.Forms.Panel();
            this.Btn_Export = new System.Windows.Forms.Button();
            this.Btn_Excel = new System.Windows.Forms.Button();
            this.cmb_Prdt = new System.Windows.Forms.ComboBox();
            this.Btn_Clr = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lnk_Logout = new System.Windows.Forms.LinkLabel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.DGV_AData = new System.Windows.Forms.DataGridView();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.lbl_pen = new System.Windows.Forms.Label();
            this.lbl_pen_cnt = new System.Windows.Forms.Label();
            this.lbl_com = new System.Windows.Forms.Label();
            this.lbl_com_cnt = new System.Windows.Forms.Label();
            this.lbl_cnt = new System.Windows.Forms.Label();
            this.lbl_rec = new System.Windows.Forms.Label();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.Pnl_User.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_AData)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.lbl_cntry);
            this.panel2.Controls.Add(this.cmb_cntry);
            this.panel2.Controls.Add(this.lbl_Prd);
            this.panel2.Controls.Add(this.panel1);
            this.panel2.Controls.Add(this.cmb_Prdt);
            this.panel2.Location = new System.Drawing.Point(5, 133);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(784, 37);
            this.panel2.TabIndex = 11;
            // 
            // lbl_cntry
            // 
            this.lbl_cntry.AutoSize = true;
            this.lbl_cntry.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_cntry.Location = new System.Drawing.Point(258, 6);
            this.lbl_cntry.Name = "lbl_cntry";
            this.lbl_cntry.Size = new System.Drawing.Size(51, 15);
            this.lbl_cntry.TabIndex = 20;
            this.lbl_cntry.Text = "Country";
            // 
            // cmb_cntry
            // 
            this.cmb_cntry.FormattingEnabled = true;
            this.cmb_cntry.Location = new System.Drawing.Point(329, 0);
            this.cmb_cntry.Name = "cmb_cntry";
            this.cmb_cntry.Size = new System.Drawing.Size(121, 21);
            this.cmb_cntry.TabIndex = 2;
            this.cmb_cntry.SelectedIndexChanged += new System.EventHandler(this.cmb_cntry_SelectedIndexChanged);
            // 
            // lbl_Prd
            // 
            this.lbl_Prd.AutoSize = true;
            this.lbl_Prd.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Prd.Location = new System.Drawing.Point(17, 6);
            this.lbl_Prd.Name = "lbl_Prd";
            this.lbl_Prd.Size = new System.Drawing.Size(52, 15);
            this.lbl_Prd.TabIndex = 17;
            this.lbl_Prd.Text = "Products";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.dataGridView1);
            this.panel1.Controls.Add(this.Pnl_User);
            this.panel1.Controls.Add(this.Btn_Excel);
            this.panel1.Location = new System.Drawing.Point(0, 180);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1054, 215);
            this.panel1.TabIndex = 9;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(39, 12);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(651, 150);
            this.dataGridView1.TabIndex = 4;
            // 
            // Pnl_User
            // 
            this.Pnl_User.Controls.Add(this.Btn_Export);
            this.Pnl_User.Location = new System.Drawing.Point(1, 231);
            this.Pnl_User.Name = "Pnl_User";
            this.Pnl_User.Size = new System.Drawing.Size(1053, 10);
            this.Pnl_User.TabIndex = 12;
            this.Pnl_User.Visible = false;
            // 
            // Btn_Export
            // 
            this.Btn_Export.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.Btn_Export.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_Export.ForeColor = System.Drawing.Color.White;
            this.Btn_Export.Location = new System.Drawing.Point(951, 210);
            this.Btn_Export.Name = "Btn_Export";
            this.Btn_Export.Size = new System.Drawing.Size(75, 28);
            this.Btn_Export.TabIndex = 12;
            this.Btn_Export.Text = "Export";
            this.Btn_Export.UseVisualStyleBackColor = false;
            // 
            // Btn_Excel
            // 
            this.Btn_Excel.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.Btn_Excel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_Excel.ForeColor = System.Drawing.Color.White;
            this.Btn_Excel.Location = new System.Drawing.Point(724, 174);
            this.Btn_Excel.Name = "Btn_Excel";
            this.Btn_Excel.Size = new System.Drawing.Size(104, 28);
            this.Btn_Excel.TabIndex = 5;
            this.Btn_Excel.Text = "Export to Excel";
            this.Btn_Excel.UseVisualStyleBackColor = false;
            // 
            // cmb_Prdt
            // 
            this.cmb_Prdt.FormattingEnabled = true;
            this.cmb_Prdt.Location = new System.Drawing.Point(89, 0);
            this.cmb_Prdt.Name = "cmb_Prdt";
            this.cmb_Prdt.Size = new System.Drawing.Size(121, 21);
            this.cmb_Prdt.TabIndex = 1;
            this.cmb_Prdt.SelectedIndexChanged += new System.EventHandler(this.cmb_Prdt_SelectedIndexChanged);
            // 
            // Btn_Clr
            // 
            this.Btn_Clr.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.Btn_Clr.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_Clr.ForeColor = System.Drawing.Color.White;
            this.Btn_Clr.Location = new System.Drawing.Point(933, 131);
            this.Btn_Clr.Name = "Btn_Clr";
            this.Btn_Clr.Size = new System.Drawing.Size(75, 28);
            this.Btn_Clr.TabIndex = 6;
            this.Btn_Clr.Text = "Refresh";
            this.Btn_Clr.UseVisualStyleBackColor = false;
            this.Btn_Clr.Click += new System.EventHandler(this.Btn_Clr_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox1.Location = new System.Drawing.Point(912, 2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(153, 71);
            this.pictureBox1.TabIndex = 20;
            this.pictureBox1.TabStop = false;
            // 
            // lnk_Logout
            // 
            this.lnk_Logout.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lnk_Logout.AutoSize = true;
            this.lnk_Logout.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnk_Logout.Location = new System.Drawing.Point(1012, 94);
            this.lnk_Logout.Name = "lnk_Logout";
            this.lnk_Logout.Size = new System.Drawing.Size(53, 15);
            this.lnk_Logout.TabIndex = 19;
            this.lnk_Logout.TabStop = true;
            this.lnk_Logout.Text = "LogOut";
            this.lnk_Logout.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnk_Logout_LinkClicked);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Location = new System.Drawing.Point(5, 2);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(114, 106);
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            // 
            // DGV_AData
            // 
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.Transparent;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.Black;
            this.DGV_AData.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.DGV_AData.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DGV_AData.BackgroundColor = System.Drawing.Color.White;
            this.DGV_AData.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGV_AData.GridColor = System.Drawing.Color.Blue;
            this.DGV_AData.Location = new System.Drawing.Point(6, 184);
            this.DGV_AData.Name = "DGV_AData";
            this.DGV_AData.ReadOnly = true;
            this.DGV_AData.RowHeadersVisible = false;
            this.DGV_AData.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.DGV_AData.Size = new System.Drawing.Size(1053, 190);
            this.DGV_AData.TabIndex = 21;
            this.DGV_AData.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DGV_AData_CellContentClick);
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(5, 3);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(114, 106);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox3.TabIndex = 22;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(912, 2);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(153, 71);
            this.pictureBox4.TabIndex = 23;
            this.pictureBox4.TabStop = false;
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // lbl_pen
            // 
            this.lbl_pen.AutoSize = true;
            this.lbl_pen.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_pen.Location = new System.Drawing.Point(582, 84);
            this.lbl_pen.Name = "lbl_pen";
            this.lbl_pen.Size = new System.Drawing.Size(69, 15);
            this.lbl_pen.TabIndex = 42;
            this.lbl_pen.Text = "Pending:-";
            // 
            // lbl_pen_cnt
            // 
            this.lbl_pen_cnt.AutoSize = true;
            this.lbl_pen_cnt.Location = new System.Drawing.Point(657, 86);
            this.lbl_pen_cnt.Name = "lbl_pen_cnt";
            this.lbl_pen_cnt.Size = new System.Drawing.Size(53, 13);
            this.lbl_pen_cnt.TabIndex = 41;
            this.lbl_pen_cnt.Text = "Pend_cnt";
            // 
            // lbl_com
            // 
            this.lbl_com.AutoSize = true;
            this.lbl_com.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_com.Location = new System.Drawing.Point(390, 84);
            this.lbl_com.Name = "lbl_com";
            this.lbl_com.Size = new System.Drawing.Size(85, 15);
            this.lbl_com.TabIndex = 40;
            this.lbl_com.Text = "Completed:-";
            // 
            // lbl_com_cnt
            // 
            this.lbl_com_cnt.AutoSize = true;
            this.lbl_com_cnt.Location = new System.Drawing.Point(481, 86);
            this.lbl_com_cnt.Name = "lbl_com_cnt";
            this.lbl_com_cnt.Size = new System.Drawing.Size(49, 13);
            this.lbl_com_cnt.TabIndex = 39;
            this.lbl_com_cnt.Text = "Com_cnt";
            // 
            // lbl_cnt
            // 
            this.lbl_cnt.AutoSize = true;
            this.lbl_cnt.Location = new System.Drawing.Point(300, 84);
            this.lbl_cnt.Name = "lbl_cnt";
            this.lbl_cnt.Size = new System.Drawing.Size(40, 13);
            this.lbl_cnt.TabIndex = 38;
            this.lbl_cnt.Text = "Ttl_cnt";
            // 
            // lbl_rec
            // 
            this.lbl_rec.AutoSize = true;
            this.lbl_rec.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_rec.Location = new System.Drawing.Point(151, 82);
            this.lbl_rec.Name = "lbl_rec";
            this.lbl_rec.Size = new System.Drawing.Size(143, 15);
            this.lbl_rec.TabIndex = 37;
            this.lbl_rec.Text = "Total No:of Records:-";
            // 
            // dataGridView2
            // 
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.Transparent;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.Black;
            this.dataGridView2.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView2.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.GridColor = System.Drawing.Color.Blue;
            this.dataGridView2.Location = new System.Drawing.Point(9, 412);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.RowHeadersVisible = false;
            this.dataGridView2.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView2.Size = new System.Drawing.Size(1053, 190);
            this.dataGridView2.TabIndex = 43;
            // 
            // Admin_DashBoard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1077, 669);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.lbl_pen);
            this.Controls.Add(this.lbl_pen_cnt);
            this.Controls.Add(this.lbl_com);
            this.Controls.Add(this.lbl_com_cnt);
            this.Controls.Add(this.lbl_cnt);
            this.Controls.Add(this.lbl_rec);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.DGV_AData);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.lnk_Logout);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.Btn_Clr);
            this.Name = "Admin_DashBoard";
            this.Text = "Admin_DashBoard";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Admin_DashBoard_Load);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.Pnl_User.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_AData)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lbl_cntry;
        private System.Windows.Forms.ComboBox cmb_cntry;
        private System.Windows.Forms.Button Btn_Clr;
        private System.Windows.Forms.Label lbl_Prd;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.LinkLabel lnk_Logout;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Panel Pnl_User;
        private System.Windows.Forms.Button Btn_Export;
        private System.Windows.Forms.Button Btn_Excel;
        private System.Windows.Forms.ComboBox cmb_Prdt;
        private System.Windows.Forms.DataGridView DGV_AData;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label lbl_pen;
        private System.Windows.Forms.Label lbl_pen_cnt;
        private System.Windows.Forms.Label lbl_com;
        private System.Windows.Forms.Label lbl_com_cnt;
        private System.Windows.Forms.Label lbl_cnt;
        private System.Windows.Forms.Label lbl_rec;
        private System.Windows.Forms.DataGridView dataGridView2;

    }
}