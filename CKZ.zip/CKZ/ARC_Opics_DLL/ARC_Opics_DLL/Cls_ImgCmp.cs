﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Windows.Forms;
using System.Drawing;
using System.Drawing.Imaging;
using System.Data;
using System.Threading;
using System.Runtime.InteropServices;
using Excel = Microsoft.Office.Interop.Excel;

namespace ARC_Opics_DLL
{
    public class Cls_ImgCmp
    {        
            public void ScreenCapture(string Path)
            {
                Bitmap bmpScreenshot;
                Graphics GLO_Screenshot;
                bmpScreenshot = new Bitmap(Screen.PrimaryScreen.Bounds.Width, Screen.PrimaryScreen.Bounds.Height, PixelFormat.Format32bppArgb);
                //Create a graphics object from the bitmap
                GLO_Screenshot = Graphics.FromImage(bmpScreenshot);
                GLO_Screenshot.CopyFromScreen(Screen.PrimaryScreen.Bounds.X, Screen.PrimaryScreen.Bounds.Y, 0, 0, Screen.PrimaryScreen.Bounds.Size, CopyPixelOperation.SourceCopy);
                bmpScreenshot.Save(Path, System.Drawing.Imaging.ImageFormat.Jpeg);
                bmpScreenshot.Dispose();
            }                          
            public void CropImage(int x, int y, int width, int height, string In_Path, string OutPath)
            {
                try
                {
                    Bitmap croppedImage;
                    using (var originalImage = new Bitmap(In_Path))
                    {
                        System.Drawing.Rectangle crop = new System.Drawing.Rectangle(x, y, width, height);
                        croppedImage = originalImage.Clone(crop, originalImage.PixelFormat);
                    }
                    croppedImage.Save(OutPath, ImageFormat.Jpeg);
                    croppedImage.Dispose();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                }
            }
        }    
}
