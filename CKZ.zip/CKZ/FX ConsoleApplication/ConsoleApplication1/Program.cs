﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
//using System.Drawing;
using System.Data.SqlClient;
using System.Collections;
using System.IO;
using System.Globalization;
using System.Configuration;
using System.Threading;
using System.Text;
using System.Security.Cryptography;

namespace ConsoleApplication1
{
    class Program
    {
        static string conString = ConfigurationManager.ConnectionStrings["ARC_conStr"].ConnectionString;
        static string strDirectory = ConfigurationManager.ConnectionStrings["Share_Path"].ToString();

        static void Main(string[] args)
        {
            if (!conString.StartsWith("Data"))
            {
                conString = Decrypt(conString);
            }

            try
            {
                Console.WriteLine("Start -->" + DateTime.Now);
                //GetShareDriveFiles_Africa(conString, strDirectory);
                GetShareDriveFiles_Mesa(conString, strDirectory);
                Console.WriteLine("End -->" + DateTime.Now);
                Thread.Sleep(10000);
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.ToString());
                Console.ReadLine();
                //Thread.Sleep(10000);
            }
        }


        /// <summary>
        /// Prakash Code for -  FX Recons
        /// </summary>
        /// <param name="conStr"></param>
        /// <param name="strDirectory"></param>
        public static void GetShareDriveFiles_Mesa(string conStr, string strDirectory)
        {
            strDirectory = strDirectory + DateTime.Now.ToString("dd-MMM-yyyy") + "_Files\\";
            bool IsMulti_Download = false;
            try
            {
                SqlConnection con = new SqlConnection();
                SqlCommand cmd = new SqlCommand();
                con.ConnectionString = conStr;
                con.Open();

                //SqlDataAdapter sda = new SqlDataAdapter("select * from Arc_Scope_BaseLine where (Source_Application like '%Shared Drive%' or Source_Application like '%ebbs - country share path%') and Team = 'FX' and IsProcessed = 0", con);

                SqlDataAdapter sda = new SqlDataAdapter("select * from Arc_Scope_BaseLine where (Source_Application like '%Shared Drive%' or Source_Application like '%ebbs - country share path%') and Team = 'FX' and IsProcessed = 0  and Country_Name NOT in ('Botswana','Kenya','TANZANIA','UGANDA','Zambia','Zimbabwe')", con);

                System.Data.DataTable dt = new System.Data.DataTable();
                sda.Fill(dt);
                con.Close();
                if (dt.Rows.Count > 0)
                {
                    foreach (DataRow dr in dt.Rows)
                    {
                        IsMulti_Download = false;
                        string Recon_Name = Convert.ToString(dr["Recon"]).Trim();
                        string Country_Name = Convert.ToString(dr["Country_Name"]).Trim();
                        string Scope_Id = Convert.ToString(dr["Scope_Id"]).Trim();
                        string Report_Source_File_Name = Convert.ToString(dr["Report_Source_File_Name"]).Trim();
                        string Source_Appilcation = Convert.ToString(dr["Source_Application"]).Trim();
                        string Recon_Date = string.Empty;

                        //Update PSID & Autx Start Time
                        cmd.Dispose();
                        cmd = new SqlCommand("update Arc_Scope_BaseLine set PSID = '" + Environment.UserName + "',AutomationStartTime = '" + DateTime.Now + "' where Scope_Id = '" + Scope_Id + "'", con);
                        con.Open();
                        cmd.ExecuteNonQuery();
                        con.Close();


                        if ((Recon_Name == "Zimbabwe FX Recon_Zimbabwe FXR Adjustments") || (Recon_Name == "Kenya FX Recon_Kenya FXR Adjustments") || (Recon_Name == "Uganda FX Recon_Uganda FXR Adjustments") || (Recon_Name == "TANZANIA FX RECON_TANZANIA FXR Adjustments") || (Recon_Name == "Botswana FX Recon_Botswana FXR Adjustments"))
                        {
                            Recon_Date = Get_Recon_Date_For_Monday_Logic(conStr, Country_Name, "MM.dd.yyyy");//yyyyMMdd 6 days working
                        }
                        else if (Recon_Name == "BAHRAIN DBU FX Recon - Advised-BAHRAIN DBU Adjustment Report" || Recon_Name == "BAHRAIN OBU FX Recon - Advised-BAHRAIN OBU Adjustment Report" || Recon_Name == "DIFC FX Recon - Advised-DIFC Adjustment Report" || Recon_Name == "UAE FX Recon - Advised_UAE Adjustment Report")
                        {
                            Recon_Date = Get_Recon_Date(conStr, Country_Name, "MM.dd.yyyy");//yyyyMMdd 5 days working
                            if (System.DateTime.Today.DayOfWeek == DayOfWeek.Sunday)
                            {
                                //System.DateTime dtemp = new DateTime();
                                Recon_Date = Convert.ToDateTime(Recon_Date).AddDays(2).ToString("MM.dd.yyyy");
                            }
                        }
                        else
                        {
                            Recon_Date = Get_Recon_Date(conStr, Country_Name, "MM.dd.yyyy");//yyyyMMdd 5 days working
                        }
                        Recon_Date = Convert.ToDateTime(Recon_Date).ToString("MM.dd.yyyy");
                        string CurrentDay = DateTime.Today.ToString("dddd");
                        string ValueConcat = Recon_Date.Substring(3, 2);
                        int start_DD = Convert.ToInt32(ValueConcat);

                        Recon_Date = Recon_Date.Remove(Recon_Date.IndexOf(".")) + "." + start_DD + Recon_Date.Remove(0, Recon_Date.LastIndexOf("."));
                        TimeSpan ts = (DateTime.Today - Convert.ToDateTime(Recon_Date).Date);

                        if (ts.Days > 1 && ((Recon_Name == "Zimbabwe FX Recon_Zimbabwe FXR Adjustments") || (Recon_Name == "Kenya FX Recon_Kenya FXR Adjustments") || (Recon_Name == "Uganda FX Recon_Uganda FXR Adjustments") || (Recon_Name == "TANZANIA FX RECON_TANZANIA FXR Adjustments") || (Recon_Name == "Botswana FX Recon_Botswana FXR Adjustments")))
                        {
                            IsMulti_Download = true;
                            while (Convert.ToDateTime(Recon_Date).Date < DateTime.Now.AddDays(-1).Date)
                            {
                                Recon_Date = Recon_Date.Remove(Recon_Date.IndexOf(".")) + "." + start_DD + Recon_Date.Remove(0, Recon_Date.LastIndexOf("."));
                                GetNigeria_FX_Files(Country_Name, Recon_Name, Source_Appilcation, Report_Source_File_Name, conStr, Recon_Date, strDirectory, IsMulti_Download);
                                start_DD++;
                            }
                        }

                        else
                        {
                            GetNigeria_FX_Files(Country_Name, Recon_Name, Source_Appilcation, Report_Source_File_Name, conStr, Recon_Date, strDirectory, IsMulti_Download);
                        }
                    }
                    //return true;
                }
                else
                {
                    //return false;
                }
            }
            catch
            {
                //return false;
            }
        }
      

        public static void GetShareDriveFiles_Africa(string conStr, string strDirectory)
        {
            strDirectory = strDirectory + DateTime.Now.ToString("dd-MMM-yyyy") + "_Files\\";
            bool IsMulti_Download = false;
            try
            {
                SqlConnection con = new SqlConnection();
                SqlCommand cmd = new SqlCommand();
                con.ConnectionString = conStr;
                con.Open();

                SqlDataAdapter sda = new SqlDataAdapter("select * from Arc_Scope_BaseLine where (Source_Application like '%Shared Drive%' or Source_Application like '%ebbs - country share path%') and Team = 'FX' and Country_Name in ('Botswana','Kenya','TANZANIA','UGANDA','Zambia','Zimbabwe')", con);

                System.Data.DataTable dt = new System.Data.DataTable();
                sda.Fill(dt);
                con.Close();
                if (dt.Rows.Count > 0)
                {
                    foreach (DataRow dr in dt.Rows)
                    {
                        IsMulti_Download = false;
                        string Recon_Name = Convert.ToString(dr["Recon"]).Trim();
                        string Country_Name = Convert.ToString(dr["Country_Name"]).Trim();
                        string Scope_Id = Convert.ToString(dr["Scope_Id"]).Trim();
                        string Report_Source_File_Name = Convert.ToString(dr["Report_Source_File_Name"]).Trim();
                        string Source_Appilcation = Convert.ToString(dr["Source_Application"]).Trim();
                        string Recon_Date = string.Empty;

                        //Update PSID & Autx Start Time
                        cmd.Dispose();
                        cmd = new SqlCommand("update Arc_Scope_BaseLine set PSID = '" + Environment.UserName + "',AutomationStartTime = '" + DateTime.Now + "' where Scope_Id = '" + Scope_Id + "'", con);
                        con.Open();
                        cmd.ExecuteNonQuery();
                        con.Close();


                        if ((Recon_Name == "Zimbabwe FX Recon_Zimbabwe FXR Adjustments") || (Recon_Name == "Kenya FX Recon_Kenya FXR Adjustments") || (Recon_Name == "Uganda FX Recon_Uganda FXR Adjustments") || (Recon_Name == "TANZANIA FX RECON_TANZANIA FXR Adjustments") || (Recon_Name == "Botswana FX Recon_Botswana FXR Adjustments"))
                        {
                            Recon_Date = Get_Recon_Date_For_Monday_Logic(conStr, Country_Name, "MM.dd.yyyy");//yyyyMMdd 6 days working
                        }
                        else if(Recon_Name  == "BAHRAIN DBU FX Recon - Advised-BAHRAIN DBU Adjustment Report" || Recon_Name  == "BAHRAIN OBU FX Recon - Advised-BAHRAIN OBU Adjustment Report" ||Recon_Name  == "DIFC FX Recon - Advised-DIFC Adjustment Report"||Recon_Name  == "UAE FX Recon - Advised_UAE Adjustment Report")
                        {
                            Recon_Date = Get_Recon_Date(conStr, Country_Name, "MM.dd.yyyy");//yyyyMMdd 5 days working
                            if(System.DateTime.Today.DayOfWeek == DayOfWeek.Sunday)
                            {
                                //System.DateTime dtemp = new DateTime();
                                Recon_Date = Convert.ToDateTime(Recon_Date).AddDays(2).ToString("MM.dd.yyyy");
                            }
                        }
                        else
                        {
                            Recon_Date = Get_Recon_Date(conStr, Country_Name, "MM.dd.yyyy");//yyyyMMdd 5 days working
                        }
                        Recon_Date = Convert.ToDateTime(Recon_Date).ToString("MM.dd.yyyy");
                        string CurrentDay = DateTime.Today.ToString("dddd");
                        string ValueConcat = Recon_Date.Substring(3, 2);
                        int start_DD = Convert.ToInt32(ValueConcat);

                        Recon_Date = Recon_Date.Remove(Recon_Date.IndexOf(".")) + "." + start_DD + Recon_Date.Remove(0, Recon_Date.LastIndexOf("."));
                        TimeSpan ts = (DateTime.Today - Convert.ToDateTime(Recon_Date).Date);

                        if (ts.Days > 1 && ((Recon_Name == "Zimbabwe FX Recon_Zimbabwe FXR Adjustments") || (Recon_Name == "Kenya FX Recon_Kenya FXR Adjustments") || (Recon_Name == "Uganda FX Recon_Uganda FXR Adjustments") || (Recon_Name == "TANZANIA FX RECON_TANZANIA FXR Adjustments") || (Recon_Name == "Botswana FX Recon_Botswana FXR Adjustments")))
                        {
                            IsMulti_Download = true;
                            while (Convert.ToDateTime(Recon_Date).Date < DateTime.Now.AddDays(-1).Date)
                            {
                                Recon_Date = Recon_Date.Remove(Recon_Date.IndexOf(".")) + "." + start_DD + Recon_Date.Remove(0, Recon_Date.LastIndexOf("."));
                                GetNigeria_FX_Files(Country_Name, Recon_Name, Source_Appilcation, Report_Source_File_Name, conStr, Recon_Date, strDirectory, IsMulti_Download);
                                start_DD++;
                            }
                        }
                        else
                        {
                            GetNigeria_FX_Files(Country_Name, Recon_Name, Source_Appilcation, Report_Source_File_Name, conStr, Recon_Date, strDirectory, IsMulti_Download);
                        }
                    }
                    //return true;
                }
                else
                {
                    //return false;
                }
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
        }
        //
      
        public static void GetNigeria_FX_Files(string Country, string Recon_Name, string Application, string Report_Source_File_Name, string conStr, string Recon_Date, string Share_Path, bool Is_Mulit_Download)
        {
            //string Recon_Date = Get_Recon_Date(conStr, Country, "MM.dd.yyyy");//yyyyMMdd
            SqlConnection con = new SqlConnection(conStr);
            TimeSpan ts = (DateTime.Today.Date - Convert.ToDateTime(Recon_Date).Date);
            try
            {
                string cn = string.Empty;
                string inputfile1And2 = "";
                Country = Country.ToLower().Trim();
                if (Country == "nigeria")
                {
                    cn = "NG";
                    inputfile1And2 = @"\\172.31.161.89\ng_fxrec\";

                }
                else if (Country == "tanzania")
                {
                    cn = "TZ";
                    inputfile1And2 = @"\\10.206.64.248\fxrec\TZ";

                }
                else if (Country == "jordan")
                {
                    cn = "JO";
                    inputfile1And2 = @"\\10.132.4.163\apps1\Fxrecon\JORDAN";
                }
                else if (Country == "botswana")
                {
                    cn = "BW";
                    inputfile1And2 = @"\\10.206.64.248\fxrec\BW";
                }
                else if (Country == "cameroon")
                {
                    cn = "CM";
                    inputfile1And2 = @"\\172.31.161.89\CM_fxrec";

                }
                else if (Country == "cote divore")
                {
                    cn = "CI";
                    inputfile1And2 = @"\\172.31.161.89\CI_fxrec";
                }
                else if (Country == "gambia")
                {
                    cn = "GM";
                    inputfile1And2 = @"\\172.31.161.89\GM_fxrec";
                }
                else if (Country == "ghana")
                {
                    cn = "GH";
                    inputfile1And2 = @"\\172.31.161.89\GH_fxrec";
                }
                else if (Country == "kenya")
                {
                    cn = "KE";
                    inputfile1And2 = @"\\10.206.64.248\fxrec";
                }
                else if (Country == "sierra leone")
                {
                    cn = "SL";
                    inputfile1And2 = @"\\172.31.161.89\SL_fxrec";
                }
                else if (Country == "srilanka")
                {
                    cn = "SR";
                    inputfile1And2 = @"\\10.172.40.96\dat\EOD\LK\GRH\Datacenter";

                    //old
                    //inputfile1And2 = @"\\10.172.40.125\dat\EOD\LK\GRH\Datacenter";

                }
                else if (Country == "uganda")
                {
                    cn = "UG";
                    inputfile1And2 = @"\\10.206.64.248\fxrec\UG";
                }

                else if (Country == "zambia")
                {
                    cn = "ZM";
                    inputfile1And2 = @"\\10.206.64.248\fxrec\ZM";
                }

                else if (Country == "zimbabwe")
                {
                    cn = "ZW";
                    inputfile1And2 = @"\\10.208.128.26\fxre";

                    //old path
                    //inputfile1And2 = @"\\10.208.128.26\fxrec\dwnloads";
                }
                //---------------------------------------------------------------------------------------------------//
                else if (Country == "qatar")
                {
                    cn = "QA";
                    inputfile1And2 = @"\\mesadxbfpnmiyab.ae.standardchartered.com\MIYABDAT\apps\Fxrecon\Imports\QAT";
                }

                else if (Country == "oman")
                {
                    cn = "OM";
                    inputfile1And2 = @"\\mesadxbfpnmiyab.ae.standardchartered.com\MIYABDAT\apps\Fxrecon\Imports\OMA";
                }

                else if (Country == "bahraindbu")
                {
                    cn = "BH";
                    //dbuorabu = "DBU";
                    inputfile1And2 = @"\\mesadxbfpnmiyab.ae.standardchartered.com\MIYABDAT\apps\Fxrecon\Imports\BAH";
                }

                else if (Country == "bahrainobu")
                {
                    cn = "BH";
                    //dbuorabu = "DBU";
                    inputfile1And2 = @"\\mesadxbfpnmiyab.ae.standardchartered.com\MIYABDAT\apps\Fxrecon\Imports\BAH";
                }

                else if (Country == "uae")
                {
                    cn = "AE";
                    inputfile1And2 = @"\\mesadxbfpnmiyab.ae.standardchartered.com\MIYABDAT\apps\Fxrecon\Imports\UAE";
                }

                else if (Country == "difc")
                {
                    cn = "DIFC";
                    inputfile1And2 = @"\\mesadxbfpnmiyab.ae.standardchartered.com\MIYABDAT\apps\Fxrecon\Imports\UAE";
                }
                //---------------------------------------------------------------------------------------------

                string year = DateTime.Today.Year.ToString();
                string month = DateTime.Today.ToString("MMMM").ToUpper();
                string dt = string.Empty;
                string _date = string.Empty;
                if (!string.IsNullOrEmpty(Recon_Date))
                {
                    //dt = DateTime.Today.AddDays(-1).ToString("MM.dd.yyyy");
                    //string _date = DateTime.Today.AddDays(-1).ToString("yyyyMMdd");
                    dt = Recon_Date;
                    _date = Convert.ToDateTime(Recon_Date).ToString("yyyyMMdd");
                }


                string targetPath = Share_Path + @"Input\" + Application + "_" + Country;
                string OutputPath = Share_Path + @"Output\" + Application + "_" + Country;

                if (Application == "ebbs - country share path")
                {
                    List<String> files = new List<String>();

                    if (Report_Source_File_Name.Contains("FXR08") || Report_Source_File_Name.Contains("FXRENTA"))
                    {
                        if (ts.Days > 1 && ((Recon_Name == "Zimbabwe FX Recon_Zimbabwe FXR Adjustments") || (Recon_Name == "Kenya FX Recon_Kenya FXR Adjustments") || (Recon_Name == "Uganda FX Recon_Uganda FXR Adjustments") || (Recon_Name == "TANZANIA FX RECON_TANZANIA FXR Adjustments") || (Recon_Name == "Botswana FX Recon_Botswana FXR Adjustments")))
                        {
                            ////old
                            //List<String> tempfile = new List<String>();
                            //if (Report_Source_File_Name.Contains("FXR08"))
                            //{
                            //    var tempfile1 = Directory.GetFiles(inputfile1And2, "fxr08*.*").OrderByDescending(d => new FileInfo(d).LastWriteTime).Where(d => new FileInfo(d).LastWriteTime.Date == Convert.ToDateTime(Recon_Date).Date).FirstOrDefault();
                            //    if (!string.IsNullOrEmpty(tempfile1))
                            //        tempfile.Add(tempfile1);
                            //}
                            //else if (Report_Source_File_Name.Contains("FXRENTA"))
                            //{
                            //    var tempfile3 = Directory.GetFiles(inputfile1And2, "fxrenta*.*").OrderByDescending(d => new FileInfo(d).LastWriteTime).Where(d => new FileInfo(d).LastWriteTime.Date == Convert.ToDateTime(Recon_Date).Date).FirstOrDefault();
                            //    if (!string.IsNullOrEmpty(tempfile3))
                            //        tempfile.Add(tempfile3);
                            //}
                            //files = tempfile;
                            ////old

                            //------------------------------------------------------
                            var directory = new DirectoryInfo(inputfile1And2);
                            FileInfo tempfile = null;

                            if (Report_Source_File_Name.Contains("FXR08"))
                                tempfile = (from f in directory.GetFiles("fxr08*.*")
                                            orderby f.LastWriteTime descending
                                            where f.LastWriteTime.Date == Convert.ToDateTime(Recon_Date).Date
                                            select f).FirstOrDefault();
                            else if (Report_Source_File_Name.Contains("FXRENTA"))
                                tempfile = (from f in directory.GetFiles("fxrenta*.*")
                                            orderby f.LastWriteTime descending
                                            where f.LastWriteTime.Date == Convert.ToDateTime(Recon_Date).Date
                                            select f).FirstOrDefault();

                            if (tempfile != null && !string.IsNullOrEmpty(tempfile.FullName))
                                files.Add(tempfile.FullName);
                        }
                        else
                        {
                            ////old
                            //var tempfile = "";
                            //if (Report_Source_File_Name.Contains("FXR08"))
                            //    tempfile = Directory.GetFiles(inputfile1And2, "fxr08*.*").OrderByDescending(d => new FileInfo(d).LastWriteTime).First();
                            //else if (Report_Source_File_Name.Contains("FXRENTA"))
                            //    tempfile = Directory.GetFiles(inputfile1And2, "fxrenta*.*").OrderByDescending(d => new FileInfo(d).LastWriteTime).First();
                            ////old
                            ////------------------------------------------------------

                            var directory = new DirectoryInfo(inputfile1And2);
                            FileInfo tempfile = null;

                            if (Report_Source_File_Name.Contains("FXR08"))
                                tempfile = (from f in directory.GetFiles("fxr08*.*")
                                            orderby f.LastWriteTime descending
                                            select f).First();
                            else if (Report_Source_File_Name.Contains("FXRENTA"))
                                tempfile = (from f in directory.GetFiles("fxrenta*.*")
                                            orderby f.LastWriteTime descending
                                            select f).First();

                            files.Add(tempfile.FullName);
                        }
                        //----------------------------------------------------------------//
                        foreach (string s in files)
                        {
                            string fileName = System.IO.Path.GetFileName(s);
                            //string file_Nm_ToUpdt_DB = Path.GetFileNameWithoutExtension(fileName);
                            if (fileName.Contains("FXR08"))
                            {
                                string temp_File_NM_DB = fileName.Remove(fileName.LastIndexOf(".")).Trim();
                                fileName = fileName.Substring(0, 5).Trim(); //// Takes the Character FXR08 alone - Prakash
                                string destFile = string.Empty;
                                if (Is_Mulit_Download == true)
                                {
                                    Recon_Date = Convert.ToDateTime(Recon_Date).AddDays(-1).ToString("MM.dd.yyyy");
                                    destFile = System.IO.Path.Combine(targetPath, fileName + Recon_Date + ".dat");// Recon_Date +
                                }
                                else
                                {
                                    destFile = System.IO.Path.Combine(targetPath, fileName + ".dat");// Recon_Date +
                                }

                                if (!File.Exists(destFile))
                                {
                                    System.IO.File.Copy(s, destFile, true);
                                    if (File.Exists(destFile))
                                    {
                                        SqlCommand cmd = new SqlCommand("update Arc_Scope_BaseLine set PSID = '" + Environment.UserName + "',AutomationEndTime = '" + DateTime.Now + "', IsProcessed = 1 , AutomationStatus = 'COMPLETED' where Country_Name = '" + Country + "' and Recon = '" + Recon_Name + "' and Report_Source_File_Name like '" + Report_Source_File_Name + "%'", con);
                                        con.Open();
                                        cmd.ExecuteNonQuery();
                                        con.Close();
                                        //Update the DB
                                    }
                                }
                            }
                            else if (fileName.Contains("FXRENTA"))
                            {

                                string temp_File_NM_DB = fileName.Remove(fileName.LastIndexOf(".")).Trim();
                                fileName = fileName.Substring(0, 7).Trim(); // Takes the Character FXRENTA alone - Prakash
                                string destFile = string.Empty;
                                if (Is_Mulit_Download == true)
                                {
                                    Recon_Date = Convert.ToDateTime(Recon_Date).AddDays(-1).ToString("MM.dd.yyyy");
                                    destFile = System.IO.Path.Combine(targetPath, fileName + Recon_Date + ".dat");// Recon_Date +
                                }
                                else
                                {
                                    destFile = System.IO.Path.Combine(targetPath, fileName + ".dat");// Recon_Date +
                                }
                                if (!File.Exists(destFile))
                                {
                                    System.IO.File.Copy(s, destFile, true);
                                    if (File.Exists(destFile))
                                    {
                                        SqlCommand cmd = new SqlCommand("update Arc_Scope_BaseLine set PSID = '" + Environment.UserName + "',AutomationEndTime = '" + DateTime.Now + "', IsProcessed = 1 , AutomationStatus = 'COMPLETED' where Country_Name = '" + Country + "' and Recon = '" + Recon_Name + "' and Report_Source_File_Name like '" + Report_Source_File_Name + "%'", con);
                                        con.Open();
                                        cmd.ExecuteNonQuery();
                                        con.Close();
                                        //Update the DB
                                    }
                                }
                            }
                        }
                    }

                }

                if (Application == "Shared Drive")
                {

                    string indt = DateTime.Today.AddDays(-2).ToString("MM.dd.yyyy");
                    string outdt = DateTime.Today.AddDays(-1).ToString("MM.dd.yyyy");

                    //string ctry = "";
                    string inputfile3 = "";
                    if (Country == "JORDAN")
                    {
                        //ctry = "Jordan";
                        inputfile3 = @"\\10.132.193.29\wkgrps\GRH\FX LPU\ARC\Jordan";
                    }
                    else if (Country == "Srilanka")
                    {
                        //ctry = "Srilanka";
                        inputfile3 = @"\\10.132.193.29\wkgrps\GRH\FX LPU\ARC\Srilanka";
                    }
                    else if (Country != "JORDAN" || Country != "Srilanka")
                    {
                        //ctry = "Africa";
                        inputfile3 = @"\\10.132.193.29\wkgrps\GRH\FX LPU\ARC\Africa";
                    }

                    if (Report_Source_File_Name.Contains("FX_TRADERNAME"))
                    {
                        List<string> file2 = new List<string>();
                        file2 = Directory.GetFiles(inputfile3, "FX_TRADERNAME*.*", SearchOption.AllDirectories).ToList(); //Directory.EnumerateFiles

                        foreach (string s in file2)
                        {
                            string fileName = System.IO.Path.GetFileName(s);
                            //string file_Nm_ToUpdt_DB = Path.GetFileNameWithoutExtension(fileName);
                            if (fileName.Contains("FX_TRADERNAME"))
                            {
                                //string tempfileName = (cn == "SR" ? ("FX_TRADERNAME_REF_DBU_" + cn + "_" + _date + ".dat") : ("FX_TRADERNAME_REF_" + cn + "_" + _date + ".dat"));
                                string temp_File_NM_DB = fileName.Remove(fileName.LastIndexOf(".")).Trim();
                                fileName = fileName.Substring(0, 13).Trim(); // Takes the Character FX_TRADERNAME alone - Prakash
                                string destFile = string.Empty;
                                //string destFile = System.IO.Path.Combine(targetPath, fileName + ".dat");
                                if (Is_Mulit_Download == true)
                                {
                                    Recon_Date = Convert.ToDateTime(Recon_Date).AddDays(-1).ToString("MM.dd.yyyy");
                                    destFile = System.IO.Path.Combine(targetPath, fileName + Recon_Date + ".dat");// Recon_Date +
                                }
                                else
                                {
                                    destFile = System.IO.Path.Combine(targetPath, fileName + ".dat");// Recon_Date +
                                }
                                if (!File.Exists(destFile))
                                {
                                    System.IO.File.Copy(s, destFile, true);
                                    if (File.Exists(destFile))
                                    {
                                        //counter++;
                                        SqlCommand cmd = new SqlCommand("update Arc_Scope_BaseLine set PSID = '" + Environment.UserName + "',AutomationEndTime = '" + DateTime.Now + "', IsProcessed = 1 , AutomationStatus = 'COMPLETED' where Country_Name = '" + Country + "' and Recon = '" + Recon_Name + "' and Report_Source_File_Name like '" + Report_Source_File_Name + "%'", con);
                                        con.Open();
                                        cmd.ExecuteNonQuery();
                                        con.Close();
                                        //Update the DB
                                    }
                                }
                            }
                        }
                    }
                    else if (Report_Source_File_Name.Contains("FX_TSM"))
                    {
                        List<string> file2 = new List<string>();
                        string inputfile_TSM = @"\\10.132.193.29\wkgrps\GRH\FX LPU\ARC\UAE and DIFC";
                        file2 = Directory.GetFiles(inputfile_TSM, "FX_TSM*.*", SearchOption.AllDirectories).ToList(); //Directory.EnumerateFiles

                        foreach (string s in file2)
                        {
                            string fileName = System.IO.Path.GetFileName(s);
                            //string file_Nm_ToUpdt_DB = Path.GetFileNameWithoutExtension(fileName);
                            if (fileName.Contains("FX_TSM"))
                            {
                                fileName = fileName.Substring(0, 6).Trim(); // Takes the Character FX_TSM alone - Prakash
                                string destFile = string.Empty;
                                if (Is_Mulit_Download == true)
                                {
                                    Recon_Date = Convert.ToDateTime(Recon_Date).AddDays(-1).ToString("MM.dd.yyyy");
                                    destFile = System.IO.Path.Combine(targetPath, fileName + Recon_Date + ".dat");
                                }
                                else
                                {
                                    destFile = System.IO.Path.Combine(targetPath, fileName + ".dat");
                                }
                                if (!File.Exists(destFile))
                                {
                                    System.IO.File.Copy(s, destFile, true);
                                    if (File.Exists(destFile))
                                    {
                                        //counter++;
                                        SqlCommand cmd = new SqlCommand("update Arc_Scope_BaseLine set PSID = '" + Environment.UserName + "',AutomationEndTime = '" + DateTime.Now + "', IsProcessed = 1 , AutomationStatus = 'COMPLETED' where Country_Name = '" + Country + "' and Recon = '" + Recon_Name + "' and Report_Source_File_Name like '" + Report_Source_File_Name + "%'", con);
                                        con.Open();
                                        cmd.ExecuteNonQuery();
                                        con.Close();
                                        //Update the DB
                                    }
                                }
                            }
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                if (ex.Message.Contains("Logon failure:") || ex.Message == @"Access to the path '\\10.132.193.29\wkgrps\GRH\FX LPU\ARC\Africa\' is denied.")
                {
                    //MessageBox.Show("User Credentials Required for " + Recon_Name + " Files");
                }

                Console.WriteLine(ex.ToString());
            }
        }

        public static string Get_Recon_Date_For_Monday_Logic(string conStr, string CountryName, string Date_Format)
        {
            string Final_Date = string.Empty;
            string fmt = CultureInfo.CurrentCulture.DateTimeFormat.ShortDatePattern;
            try
            {
                int day = 0;
                string actd = "";
                int datefound = 0;
                System.Data.DataTable dt = new System.Data.DataTable();
                System.Data.DataTable table = new System.Data.DataTable();
                System.Data.DataTable date = new System.Data.DataTable();
                SqlConnection con = new SqlConnection(conStr);
                string Today = DateTime.Now.ToString("dddd");

                //string date = DateTime.Now.ToString("09/09/2017");
                //--------------------------------------------------------------------
                if (Today == "Saturday" || Today == "Sunday")
                {
                    //return true;
                }
                else
                {
                    SqlDataAdapter ad = new SqlDataAdapter("dbo.ARC_SP_Get_Holiday_Date", con);
                    ad.SelectCommand.CommandType = CommandType.StoredProcedure;
                    ad.SelectCommand.Parameters.AddWithValue("@Country_Name", CountryName);
                    con.Open();
                    ad.Fill(table);
                    con.Close();

                    if (table.Rows.Count > 0)
                    {
                        if (Convert.ToString(table.Rows[0][2]).Trim() == "NonGulf")
                        {
                            int Year = Convert.ToInt32(DateTime.Now.ToString("yyyy"));
                            //DateTime EndOfYear = Convert.ToDateTime("31-12-" + Year + "");
                            DateTime startDate = new DateTime(Year, 1, 1);
                            DateTime endDate = new DateTime(Year, 12, 31);

                            date.Columns.Add("Holiday_Date", typeof(DateTime));
                            date.Columns.Add("Country_Id", typeof(long));
                            date.Columns.Add("Gulf");
                            TimeSpan diff = endDate - startDate;
                            int days = diff.Days;
                            for (var i = 0; i <= days; i++)
                            {
                                var testDate = startDate.AddDays(i);
                                try
                                {
                                    switch (testDate.DayOfWeek)
                                    {
                                        case DayOfWeek.Sunday:
                                            date.Rows.Add();
                                            date.Rows.Add(testDate.ToString(fmt));
                                            break;
                                    }

                                }
                                catch
                                {

                                }
                            }
                            date.Merge(table);
                            ExecRemoveDuplicateRows(date, "Holiday_Date");
                        }
                    }
                    else
                    {
                        SqlCommand ad1 = new SqlCommand("dbo.ARC_SP_Get_Holiday_Date_NoHoliday", con);
                        ad1.CommandType = CommandType.StoredProcedure;
                        ad1.Parameters.AddWithValue("@Country_Name", CountryName);
                        con.Open();
                        string Result = Convert.ToString(ad1.ExecuteScalar());

                        con.Close();

                        if (Result == "NoGulf")
                        {
                            int Year = Convert.ToInt32(DateTime.Now.ToString("yyyy"));
                            DateTime startDate = new DateTime(Year, 1, 1);
                            DateTime endDate = new DateTime(Year, 12, 31);

                            date.Columns.Add("date");
                            TimeSpan diff = endDate - startDate;
                            int days = diff.Days;
                            for (var i = 0; i <= days; i++)
                            {
                                var testDate = startDate.AddDays(i);
                                switch (testDate.DayOfWeek)
                                {
                                    case DayOfWeek.Sunday:
                                        date.Rows.Add(testDate.ToString(fmt));
                                        break;
                                }
                            }
                        }
                        date.Merge(table);

                    }
                    //------------------------------------------------------
                    DataView v = date.DefaultView;
                    v.Sort = "Holiday_Date";
                    System.Data.DataTable d = new System.Data.DataTable();
                    d = v.ToTable();

                    for (int i = 0; i <= d.Rows.Count - 1; i++)
                    {
                        if (d.Rows[i][0].ToString() != "")
                        {
                            string d1 = DateTime.Now.AddDays(-1).ToString("MM/dd/yyyy");
                            string d2 = DateTime.Now.AddDays(-2).ToString("MM/dd/yyyy");
                            string d3 = DateTime.Now.AddDays(-3).ToString("MM/dd/yyyy");
                            string d4 = DateTime.Now.AddDays(-4).ToString("MM/dd/yyyy");
                            string d5 = DateTime.Now.AddDays(-5).ToString("MM/dd/yyyy");
                            actd = Convert.ToDateTime(d.Rows[i][0]).ToString("MM/dd/yyyy");
                            if (d1 == actd)
                            {
                                datefound = 1;
                                day = day + 1;
                                actd = Convert.ToDateTime(d.Rows[i - 1][0]).ToString("MM/dd/yyyy");
                                if (d2 == actd)
                                {
                                    day = day + 1;
                                    actd = Convert.ToDateTime(d.Rows[i - 2][0]).ToString("MM/dd/yyyy");
                                    if (d3 == actd)
                                    {
                                        day = day + 1;
                                        actd = Convert.ToDateTime(d.Rows[i - 3][0]).ToString("MM/dd/yyyy");
                                        if (d4 == actd)
                                        {
                                            day = day + 1;
                                            actd = Convert.ToDateTime(d.Rows[i - 4][0]).ToString("MM/dd/yyyy");
                                            if (d5 == actd)
                                            {
                                                day = day + 1;
                                                actd = Convert.ToDateTime(d.Rows[i - 5][0]).ToString("MM/dd/yyyy");
                                            }
                                        }
                                    }
                                }
                            }
                        }

                    }
                    if (datefound == 0)
                    {
                        //MessageBox.Show("Pick yesterdays File");
                        Final_Date = DateTime.Now.AddDays(-1).ToString(Date_Format);
                    }
                    else
                    {
                        //MessageBox.Show("Pick " + (day + 1).ToString() + " Days before File");
                        int t = 0;
                        t = t - (day + 1);
                        Final_Date = DateTime.Now.AddDays(t).ToString(Date_Format);
                    }
                }

                string[] Date = Final_Date.Split(' ');
                if (Date[0].ToString().Contains("/"))
                {
                    string[] Date_Final = Date[0].Split('/');

                    Final_Date = "";
                    if (Date_Final[1].Length == 1 && Date_Final[0].Length == 2)
                    {
                        Final_Date = "0" + Date_Final[1] + Date_Final[0] + Date_Final[2];
                    }
                    else if (Date_Final[1].Length == 2 && Date_Final[0].Length == 1)
                    {
                        Final_Date = Date_Final[1] + "0" + Date_Final[0] + Date_Final[2];
                    }
                    else if (Date_Final[1].Length == 1 && Date_Final[0].Length == 1)
                    {
                        Final_Date = "0" + Date_Final[1] + "0" + Date_Final[0] + Date_Final[2];
                    }
                    else if (Date_Final[1].Length == 2 && Date_Final[0].Length == 2)
                    {
                        Final_Date = Date_Final[1] + Date_Final[0] + Date_Final[2];
                    }
                }
                else if (Date[0].ToString().Contains("."))
                {
                    string[] Date_Final = Date[0].Split('.');

                    Final_Date = "";
                    if (Date_Final[1].Length == 1 && Date_Final[0].Length == 2)
                    {
                        Final_Date = "0" + Date_Final[1] + Date_Final[0] + Date_Final[2];
                    }
                    else if (Date_Final[1].Length == 2 && Date_Final[0].Length == 1)
                    {
                        Final_Date = Date_Final[1] + "0" + Date_Final[0] + Date_Final[2];
                    }
                    else if (Date_Final[1].Length == 1 && Date_Final[0].Length == 1)
                    {
                        Final_Date = "0" + Date_Final[1] + "0" + Date_Final[0] + Date_Final[2];
                    }
                    else if (Date_Final[1].Length == 2 && Date_Final[0].Length == 2)
                    {
                        Final_Date = Date_Final[1] + Date_Final[0] + Date_Final[2];
                    }
                }
                DateTime myDate = DateTime.ParseExact(Final_Date, "ddMMyyyy", System.Globalization.CultureInfo.InvariantCulture);

                Final_Date = myDate.ToString(Date_Format);


                return Final_Date;
            }
            catch
            {
                //MessageBox.Show(ex.ToString());
                return null;
            }
        }

        public static string Get_Recon_Date(string conStr, string CountryName, string Date_Format)
        {
            string Final_Date = string.Empty;
            string fmt = CultureInfo.CurrentCulture.DateTimeFormat.ShortDatePattern;

            try
            {
                int day = 0;
                string actd = "";
                int datefound = 0;
                System.Data.DataTable dt = new System.Data.DataTable();
                System.Data.DataTable table = new System.Data.DataTable();
                System.Data.DataTable date = new System.Data.DataTable();
                SqlConnection con = new SqlConnection(conStr);
                string Today = DateTime.Now.ToString("dddd");

                //string date = DateTime.Now.ToString("09/09/2017");
                //-------------------------------------------------------------------------------
                SqlDataAdapter ad = new SqlDataAdapter("dbo.ARC_SP_Get_Holiday_Date", con);
                ad.SelectCommand.CommandType = CommandType.StoredProcedure;
                ad.SelectCommand.Parameters.AddWithValue("@Country_Name", CountryName);
                con.Open();
                ad.Fill(table);
                con.Close();

                if (table.Rows.Count > 0)
                {
                    if (Convert.ToString(table.Rows[0][2]).Trim() == "NonGulf")
                    {
                        int Year = Convert.ToInt32(DateTime.Now.ToString("yyyy"));
                        //DateTime EndOfYear = Convert.ToDateTime("31-12-" + Year + "");
                        DateTime startDate = new DateTime(Year, 1, 1);
                        DateTime endDate = new DateTime(Year, 12, 31);

                        date.Columns.Add("Holiday_Date", typeof(DateTime));
                        date.Columns.Add("Country_Id", typeof(long));
                        date.Columns.Add("Gulf");
                        TimeSpan diff = endDate - startDate;
                        int days = diff.Days;
                        for (var i = 0; i <= days; i++)
                        {
                            var testDate = startDate.AddDays(i);
                            try
                            {
                                switch (testDate.DayOfWeek)
                                {
                                    case DayOfWeek.Saturday:
                                    case DayOfWeek.Sunday:
                                        date.Rows.Add();
                                        date.Rows.Add(testDate.ToString(fmt));
                                        break;
                                }

                            }
                            catch
                            {

                            }
                        }
                        date.Merge(table);
                        ExecRemoveDuplicateRows(date, "Holiday_Date");
                    }
                    else
                    {
                        int Year = Convert.ToInt32(DateTime.Now.ToString("yyyy"));
                        DateTime startDate = new DateTime(Year, 1, 1);
                        DateTime endDate = new DateTime(Year, 12, 31);

                        date.Columns.Add("Holiday_Date", typeof(DateTime));
                        date.Columns.Add("Country_Id", typeof(long));
                        date.Columns.Add("Gulf");
                        TimeSpan diff = endDate - startDate;
                        int days = diff.Days;
                        for (var i = 0; i <= days; i++)
                        {
                            var testDate = startDate.AddDays(i);
                            switch (testDate.DayOfWeek)
                            {
                                case DayOfWeek.Friday:
                                case DayOfWeek.Saturday:
                                    date.Rows.Add(testDate.ToString(fmt));
                                    break;
                            }
                        }
                        date.Merge(table);
                    }
                }
                else
                {
                    SqlCommand ad1 = new SqlCommand("dbo.ARC_SP_Get_Holiday_Date_NoHoliday", con);
                    ad1.CommandType = CommandType.StoredProcedure;
                    ad1.Parameters.AddWithValue("@Country_Name", CountryName);
                    con.Open();
                    string Result = Convert.ToString(ad1.ExecuteScalar());

                    con.Close();

                    if (Result == "NonGulf")
                    {
                        int Year = Convert.ToInt32(DateTime.Now.ToString("yyyy"));
                        DateTime startDate = new DateTime(Year, 1, 1);
                        DateTime endDate = new DateTime(Year, 12, 31);

                        date.Columns.Add("Holiday_Date", typeof(DateTime));
                        date.Columns.Add("Country_Id", typeof(long));
                        date.Columns.Add("Gulf");
                        TimeSpan diff = endDate - startDate;
                        int days = diff.Days;
                        for (var i = 0; i <= days; i++)
                        {
                            var testDate = startDate.AddDays(i);
                            switch (testDate.DayOfWeek)
                            {
                                case DayOfWeek.Saturday:
                                case DayOfWeek.Sunday:
                                    date.Rows.Add(testDate.ToString(fmt));
                                    break;
                            }
                        }
                    }
                    else
                    {
                        int Year = Convert.ToInt32(DateTime.Now.ToString("yyyy"));
                        DateTime startDate = new DateTime(Year, 1, 1);
                        DateTime endDate = new DateTime(Year, 12, 31);

                        date.Columns.Add("date");
                        TimeSpan diff = endDate - startDate;
                        int days = diff.Days;
                        for (var i = 0; i <= days; i++)
                        {
                            var testDate = startDate.AddDays(i);
                            switch (testDate.DayOfWeek)
                            {
                                case DayOfWeek.Friday:
                                case DayOfWeek.Saturday:
                                    date.Rows.Add(testDate.ToString(fmt));
                                    break;
                            }
                        }
                    }
                    date.Merge(table);

                }
                //-------------------------------------------------------

                DataView v = date.DefaultView;
                v.Sort = "Holiday_Date";
                System.Data.DataTable d = new System.Data.DataTable();
                d = v.ToTable();
                try
                {
                    for (int i = 0; i <= d.Rows.Count - 1; i++)
                    {
                        if (d.Rows[i][0].ToString() != "")
                        {

                            string d1 = DateTime.Now.AddDays(-1).ToString("MM/dd/yyyy");
                            string d2 = DateTime.Now.AddDays(-2).ToString("MM/dd/yyyy");
                            string d3 = DateTime.Now.AddDays(-3).ToString("MM/dd/yyyy");
                            string d4 = DateTime.Now.AddDays(-4).ToString("MM/dd/yyyy");
                            string d5 = DateTime.Now.AddDays(-5).ToString("MM/dd/yyyy");
                            actd = Convert.ToDateTime(d.Rows[i][0]).ToString("MM/dd/yyyy");
                            if (d1 == actd)
                            {
                                datefound = 1;
                                day = day + 1;
                                actd = Convert.ToDateTime(d.Rows[i - 1][0]).ToString("MM/dd/yyyy");
                                if (d2 == actd)
                                {
                                    day = day + 1;
                                    actd = Convert.ToDateTime(d.Rows[i - 2][0]).ToString("MM/dd/yyyy");
                                    if (d3 == actd)
                                    {
                                        day = day + 1;
                                        actd = Convert.ToDateTime(d.Rows[i - 3][0]).ToString("MM/dd/yyyy");
                                        if (d4 == actd)
                                        {
                                            day = day + 1;
                                            actd = Convert.ToDateTime(d.Rows[i - 4][0]).ToString("MM/dd/yyyy");
                                            if (d5 == actd)
                                            {
                                                day = day + 1;
                                                actd = Convert.ToDateTime(d.Rows[i - 5][0]).ToString("MM/dd/yyyy");
                                            }
                                        }
                                    }
                                }
                            }
                        }


                    }


                    if (datefound == 0)
                    {
                        ////MessageBox.Show("Pick yesterdays File");
                        Final_Date = DateTime.Now.AddDays(-1).ToString("MM/dd/yyyy");
                    }
                    else
                    {
                        //MessageBox.Show("Pick " + (day + 1).ToString() + " Days before File");
                        int t = 0;
                        t = t - (day + 1);
                        Final_Date = DateTime.Now.AddDays(t).ToString("MM/dd/yyyy");

                    }
                }
                catch
                {
                    //MessageBox.Show("");
                }

            }
            catch
            {
                return null;

            }

            string[] Date = Final_Date.Split(' ');
            if (Date[0].ToString().Contains("/"))
            {
                string[] Date_Final = Date[0].Split('/');

                Final_Date = "";
                if (Date_Final[1].Length == 1 && Date_Final[0].Length == 2)
                {
                    Final_Date = "0" + Date_Final[1] + Date_Final[0] + Date_Final[2];
                }
                else if (Date_Final[1].Length == 2 && Date_Final[0].Length == 1)
                {
                    Final_Date = Date_Final[1] + "0" + Date_Final[0] + Date_Final[2];
                }
                else if (Date_Final[1].Length == 1 && Date_Final[0].Length == 1)
                {
                    Final_Date = "0" + Date_Final[1] + "0" + Date_Final[0] + Date_Final[2];
                }
                else if (Date_Final[1].Length == 2 && Date_Final[0].Length == 2)
                {
                    Final_Date = Date_Final[1] + Date_Final[0] + Date_Final[2];
                }
            }
            else if (Date[0].ToString().Contains("."))
            {
                string[] Date_Final = Date[0].Split('.');

                Final_Date = "";
                if (Date_Final[1].Length == 1 && Date_Final[0].Length == 2)
                {
                    Final_Date = "0" + Date_Final[1] + Date_Final[0] + Date_Final[2];
                }
                else if (Date_Final[1].Length == 2 && Date_Final[0].Length == 1)
                {
                    Final_Date = Date_Final[1] + "0" + Date_Final[0] + Date_Final[2];
                }
                else if (Date_Final[1].Length == 1 && Date_Final[0].Length == 1)
                {
                    Final_Date = "0" + Date_Final[1] + "0" + Date_Final[0] + Date_Final[2];
                }
                else if (Date_Final[1].Length == 2 && Date_Final[0].Length == 2)
                {
                    Final_Date = Date_Final[1] + Date_Final[0] + Date_Final[2];
                }
            }
            else if (Date[0].ToString().Contains("-"))
            {
                string[] Date_Final = Date[0].Split('-');

                Final_Date = "";
                if (Date_Final[1].Length == 1 && Date_Final[0].Length == 2)
                {
                    Final_Date = "0" + Date_Final[1] + Date_Final[0] + Date_Final[2];
                }
                else if (Date_Final[1].Length == 2 && Date_Final[0].Length == 1)
                {
                    Final_Date = Date_Final[1] + "0" + Date_Final[0] + Date_Final[2];
                }
                else if (Date_Final[1].Length == 1 && Date_Final[0].Length == 1)
                {
                    Final_Date = "0" + Date_Final[1] + "0" + Date_Final[0] + Date_Final[2];
                }
                else if (Date_Final[1].Length == 2 && Date_Final[0].Length == 2)
                {
                    Final_Date = Date_Final[1] + Date_Final[0] + Date_Final[2];
                }
            }
            DateTime myDate = DateTime.ParseExact(Final_Date, "ddMMyyyy", System.Globalization.CultureInfo.InvariantCulture);

            Final_Date = myDate.ToString(Date_Format);

            return Final_Date;
        }

        public static System.Data.DataTable ExecRemoveDuplicateRows(System.Data.DataTable table, string DistinctColumn)
        {
            try
            {
                ArrayList UniqueRecords = new ArrayList();
                ArrayList DuplicateRecords = new ArrayList();

                // Check if records is already added to UniqueRecords otherwise,
                // Add the records to DuplicateRecords
                foreach (DataRow dRow in table.Rows)
                {
                    if (UniqueRecords.Contains(dRow[DistinctColumn]))
                        DuplicateRecords.Add(dRow);
                    else
                        UniqueRecords.Add(dRow[DistinctColumn]);
                }

                // Remove duplicate rows from DataTable added to DuplicateRecords
                foreach (DataRow dRow in DuplicateRecords)
                {
                    table.Rows.Remove(dRow);
                }

                // Return the clean DataTable which contains unique records.
                return table;
            }
            catch
            {
                return null;
            }
        }


        private string Encrypt(string clearText)
        {
            try
            {
                string EncryptionKey = "MAKV2SPBNI99212";
                byte[] clearBytes = Encoding.Unicode.GetBytes(clearText);
                using (Aes encryptor = Aes.Create())
                {
                    Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
                    encryptor.Key = pdb.GetBytes(32);
                    encryptor.IV = pdb.GetBytes(16);
                    using (MemoryStream ms = new MemoryStream())
                    {
                        using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateEncryptor(), CryptoStreamMode.Write))
                        {
                            cs.Write(clearBytes, 0, clearBytes.Length);
                            cs.Close();
                        }
                        clearText = Convert.ToBase64String(ms.ToArray());
                    }
                }
                return clearText;
            }
            catch
            {
                return null;
            }
        }

        private static string Decrypt(string cipherText)
        {
            try
            {
                string EncryptionKey = "MAKV2SPBNI99212";
                byte[] cipherBytes = Convert.FromBase64String(cipherText);
                using (Aes encryptor = Aes.Create())
                {
                    Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
                    encryptor.Key = pdb.GetBytes(32);
                    encryptor.IV = pdb.GetBytes(16);
                    using (MemoryStream ms = new MemoryStream())
                    {
                        using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateDecryptor(), CryptoStreamMode.Write))
                        {
                            cs.Write(cipherBytes, 0, cipherBytes.Length);
                            cs.Close();
                        }
                        cipherText = Encoding.Unicode.GetString(ms.ToArray());
                    }
                }
                return cipherText;
            }
            catch
            {
                return null;
            }
        }
    }
}
