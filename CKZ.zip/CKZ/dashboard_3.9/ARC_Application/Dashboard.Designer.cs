﻿namespace ARC_Application
{
    partial class Dashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle41 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle42 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle43 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle44 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle45 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle46 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle47 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle48 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle49 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle50 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle51 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle52 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle53 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle54 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle55 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle56 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle57 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle58 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle59 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle60 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Dashboard));
            this.btn_Export = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.lnk_Logout = new System.Windows.Forms.LinkLabel();
            this.Btn_Clr = new System.Windows.Forms.Button();
            this.Btn_Srch = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.cmb_Recon = new System.Windows.Forms.ComboBox();
            this.lbl_File_name = new System.Windows.Forms.Label();
            this.lbl_cntry = new System.Windows.Forms.Label();
            this.cmb_cntry = new System.Windows.Forms.ComboBox();
            this.lbl_Prd = new System.Windows.Forms.Label();
            this.cmb_Prdt = new System.Windows.Forms.ComboBox();
            this.lbl_rec = new System.Windows.Forms.Label();
            this.lbl_cnt = new System.Windows.Forms.Label();
            this.lbl_com_cnt = new System.Windows.Forms.Label();
            this.lbl_com = new System.Windows.Forms.Label();
            this.lbl_pen_cnt = new System.Windows.Forms.Label();
            this.lbl_pen = new System.Windows.Forms.Label();
            this.btn_Clear_DB = new System.Windows.Forms.Button();
            this.Select = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.DGV_Data = new System.Windows.Forms.DataGridView();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.dataGridViewCheckBoxColumn2 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.dataGridViewCheckBoxColumn1 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.dgv_TLM = new System.Windows.Forms.DataGridView();
            this.dataGridViewCheckBoxColumn3 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.lbl_FlsPND = new System.Windows.Forms.Label();
            this.lbl_FlsPNDVW = new System.Windows.Forms.Label();
            this.lbl_FlsCMP = new System.Windows.Forms.Label();
            this.lbl_FlsCMPVW = new System.Windows.Forms.Label();
            this.lbl_FilcntVw = new System.Windows.Forms.Label();
            this.lbl_Files = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.cmb_Application = new System.Windows.Forms.ComboBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_Data)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_TLM)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_Export
            // 
            this.btn_Export.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.btn_Export.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Export.ForeColor = System.Drawing.Color.White;
            this.btn_Export.Location = new System.Drawing.Point(1219, 654);
            this.btn_Export.Name = "btn_Export";
            this.btn_Export.Size = new System.Drawing.Size(75, 28);
            this.btn_Export.TabIndex = 15;
            this.btn_Export.Text = "Export";
            this.btn_Export.UseVisualStyleBackColor = false;
            this.btn_Export.Click += new System.EventHandler(this.button1_Click);
            // 
            // lnk_Logout
            // 
            this.lnk_Logout.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lnk_Logout.AutoSize = true;
            this.lnk_Logout.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnk_Logout.Location = new System.Drawing.Point(1209, 80);
            this.lnk_Logout.Name = "lnk_Logout";
            this.lnk_Logout.Size = new System.Drawing.Size(53, 15);
            this.lnk_Logout.TabIndex = 28;
            this.lnk_Logout.TabStop = true;
            this.lnk_Logout.Text = "LogOut";
            this.lnk_Logout.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnk_Logout_LinkClicked_1);
            // 
            // Btn_Clr
            // 
            this.Btn_Clr.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.Btn_Clr.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_Clr.ForeColor = System.Drawing.Color.White;
            this.Btn_Clr.Location = new System.Drawing.Point(1212, 129);
            this.Btn_Clr.Name = "Btn_Clr";
            this.Btn_Clr.Size = new System.Drawing.Size(75, 28);
            this.Btn_Clr.TabIndex = 26;
            this.Btn_Clr.Text = "Refresh";
            this.Btn_Clr.UseVisualStyleBackColor = false;
            this.Btn_Clr.Click += new System.EventHandler(this.Btn_Clr_Click_1);
            // 
            // Btn_Srch
            // 
            this.Btn_Srch.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.Btn_Srch.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_Srch.ForeColor = System.Drawing.Color.White;
            this.Btn_Srch.Location = new System.Drawing.Point(1131, 129);
            this.Btn_Srch.Name = "Btn_Srch";
            this.Btn_Srch.Size = new System.Drawing.Size(75, 28);
            this.Btn_Srch.TabIndex = 25;
            this.Btn_Srch.Text = "Search";
            this.Btn_Srch.UseVisualStyleBackColor = false;
            this.Btn_Srch.Visible = false;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.cmb_Application);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.cmb_Recon);
            this.panel1.Controls.Add(this.lbl_File_name);
            this.panel1.Controls.Add(this.lbl_cntry);
            this.panel1.Controls.Add(this.cmb_cntry);
            this.panel1.Controls.Add(this.lbl_Prd);
            this.panel1.Controls.Add(this.cmb_Prdt);
            this.panel1.Location = new System.Drawing.Point(12, 124);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1105, 39);
            this.panel1.TabIndex = 30;
            // 
            // cmb_Recon
            // 
            this.cmb_Recon.FormattingEnabled = true;
            this.cmb_Recon.Location = new System.Drawing.Point(739, 11);
            this.cmb_Recon.Name = "cmb_Recon";
            this.cmb_Recon.Size = new System.Drawing.Size(326, 21);
            this.cmb_Recon.TabIndex = 37;
            this.cmb_Recon.SelectedIndexChanged += new System.EventHandler(this.cmb_Recon_SelectedIndexChanged);
            // 
            // lbl_File_name
            // 
            this.lbl_File_name.AutoSize = true;
            this.lbl_File_name.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_File_name.Location = new System.Drawing.Point(643, 13);
            this.lbl_File_name.Name = "lbl_File_name";
            this.lbl_File_name.Size = new System.Drawing.Size(73, 15);
            this.lbl_File_name.TabIndex = 36;
            this.lbl_File_name.Text = "Recon Name";
            // 
            // lbl_cntry
            // 
            this.lbl_cntry.AutoSize = true;
            this.lbl_cntry.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_cntry.Location = new System.Drawing.Point(222, 13);
            this.lbl_cntry.Name = "lbl_cntry";
            this.lbl_cntry.Size = new System.Drawing.Size(51, 15);
            this.lbl_cntry.TabIndex = 35;
            this.lbl_cntry.Text = "Country";
            // 
            // cmb_cntry
            // 
            this.cmb_cntry.Location = new System.Drawing.Point(297, 11);
            this.cmb_cntry.Name = "cmb_cntry";
            this.cmb_cntry.Size = new System.Drawing.Size(121, 21);
            this.cmb_cntry.TabIndex = 31;
            this.cmb_cntry.SelectedIndexChanged += new System.EventHandler(this.cmb_cntry_SelectedIndexChanged_1);
            // 
            // lbl_Prd
            // 
            this.lbl_Prd.AutoSize = true;
            this.lbl_Prd.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Prd.Location = new System.Drawing.Point(18, 13);
            this.lbl_Prd.Name = "lbl_Prd";
            this.lbl_Prd.Size = new System.Drawing.Size(52, 15);
            this.lbl_Prd.TabIndex = 34;
            this.lbl_Prd.Text = "Products";
            // 
            // cmb_Prdt
            // 
            this.cmb_Prdt.FormattingEnabled = true;
            this.cmb_Prdt.Location = new System.Drawing.Point(86, 11);
            this.cmb_Prdt.Name = "cmb_Prdt";
            this.cmb_Prdt.Size = new System.Drawing.Size(121, 21);
            this.cmb_Prdt.TabIndex = 30;
            this.cmb_Prdt.SelectedIndexChanged += new System.EventHandler(this.cmb_Prdt_SelectedIndexChanged_1);
            // 
            // lbl_rec
            // 
            this.lbl_rec.AutoSize = true;
            this.lbl_rec.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_rec.Location = new System.Drawing.Point(199, 80);
            this.lbl_rec.Name = "lbl_rec";
            this.lbl_rec.Size = new System.Drawing.Size(143, 15);
            this.lbl_rec.TabIndex = 31;
            this.lbl_rec.Text = "Total No:of Records:-";
            // 
            // lbl_cnt
            // 
            this.lbl_cnt.AutoSize = true;
            this.lbl_cnt.Location = new System.Drawing.Point(348, 82);
            this.lbl_cnt.Name = "lbl_cnt";
            this.lbl_cnt.Size = new System.Drawing.Size(40, 13);
            this.lbl_cnt.TabIndex = 32;
            this.lbl_cnt.Text = "Ttl_cnt";
            // 
            // lbl_com_cnt
            // 
            this.lbl_com_cnt.AutoSize = true;
            this.lbl_com_cnt.Location = new System.Drawing.Point(529, 84);
            this.lbl_com_cnt.Name = "lbl_com_cnt";
            this.lbl_com_cnt.Size = new System.Drawing.Size(49, 13);
            this.lbl_com_cnt.TabIndex = 33;
            this.lbl_com_cnt.Text = "Com_cnt";
            // 
            // lbl_com
            // 
            this.lbl_com.AutoSize = true;
            this.lbl_com.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_com.Location = new System.Drawing.Point(438, 82);
            this.lbl_com.Name = "lbl_com";
            this.lbl_com.Size = new System.Drawing.Size(85, 15);
            this.lbl_com.TabIndex = 34;
            this.lbl_com.Text = "Completed:-";
            // 
            // lbl_pen_cnt
            // 
            this.lbl_pen_cnt.AutoSize = true;
            this.lbl_pen_cnt.Location = new System.Drawing.Point(705, 84);
            this.lbl_pen_cnt.Name = "lbl_pen_cnt";
            this.lbl_pen_cnt.Size = new System.Drawing.Size(53, 13);
            this.lbl_pen_cnt.TabIndex = 35;
            this.lbl_pen_cnt.Text = "Pend_cnt";
            // 
            // lbl_pen
            // 
            this.lbl_pen.AutoSize = true;
            this.lbl_pen.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_pen.Location = new System.Drawing.Point(630, 82);
            this.lbl_pen.Name = "lbl_pen";
            this.lbl_pen.Size = new System.Drawing.Size(69, 15);
            this.lbl_pen.TabIndex = 36;
            this.lbl_pen.Text = "Pending:-";
            // 
            // btn_Clear_DB
            // 
            this.btn_Clear_DB.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.btn_Clear_DB.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Clear_DB.ForeColor = System.Drawing.Color.White;
            this.btn_Clear_DB.Location = new System.Drawing.Point(1081, 654);
            this.btn_Clear_DB.Name = "btn_Clear_DB";
            this.btn_Clear_DB.Size = new System.Drawing.Size(125, 28);
            this.btn_Clear_DB.TabIndex = 39;
            this.btn_Clear_DB.Text = "Retry";
            this.btn_Clear_DB.UseVisualStyleBackColor = false;
            this.btn_Clear_DB.Click += new System.EventHandler(this.btn_Clear_DB_Click);
            // 
            // Select
            // 
            this.Select.FillWeight = 99.22699F;
            this.Select.HeaderText = "Select";
            this.Select.Name = "Select";
            this.Select.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Select.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // DGV_Data
            // 
            this.DGV_Data.AllowUserToAddRows = false;
            this.DGV_Data.AllowUserToDeleteRows = false;
            this.DGV_Data.AllowUserToResizeRows = false;
            dataGridViewCellStyle41.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle41.BackColor = System.Drawing.SystemColors.Info;
            dataGridViewCellStyle41.SelectionBackColor = System.Drawing.Color.Transparent;
            dataGridViewCellStyle41.SelectionForeColor = System.Drawing.Color.Black;
            this.DGV_Data.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle41;
            this.DGV_Data.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DGV_Data.BackgroundColor = System.Drawing.Color.White;
            this.DGV_Data.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.DGV_Data.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Sunken;
            this.DGV_Data.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle42.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle42.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle42.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle42.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle42.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle42.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle42.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DGV_Data.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle42;
            this.DGV_Data.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGV_Data.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Select});
            dataGridViewCellStyle43.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle43.BackColor = System.Drawing.Color.MintCream;
            dataGridViewCellStyle43.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle43.ForeColor = System.Drawing.SystemColors.Desktop;
            dataGridViewCellStyle43.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle43.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle43.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.DGV_Data.DefaultCellStyle = dataGridViewCellStyle43;
            this.DGV_Data.GridColor = System.Drawing.Color.Blue;
            this.DGV_Data.Location = new System.Drawing.Point(6, 6);
            this.DGV_Data.Name = "DGV_Data";
            this.DGV_Data.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle44.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle44.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle44.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle44.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle44.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle44.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle44.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DGV_Data.RowHeadersDefaultCellStyle = dataGridViewCellStyle44;
            this.DGV_Data.RowHeadersVisible = false;
            this.DGV_Data.RowHeadersWidth = 31;
            dataGridViewCellStyle45.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.DGV_Data.RowsDefaultCellStyle = dataGridViewCellStyle45;
            this.DGV_Data.RowTemplate.Height = 26;
            this.DGV_Data.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.DGV_Data.Size = new System.Drawing.Size(1262, 436);
            this.DGV_Data.TabIndex = 14;
            this.DGV_Data.CellContentDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DGV_Data_CellContentDoubleClick);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Location = new System.Drawing.Point(12, 169);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1282, 479);
            this.tabControl1.TabIndex = 41;
            this.tabControl1.SelectedIndexChanged += new System.EventHandler(this.tabControl1_SelectedIndexChanged);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.DGV_Data);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1274, 453);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "File";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.dataGridView2);
            this.tabPage2.Controls.Add(this.dataGridView1);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1274, 453);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Recon";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToAddRows = false;
            this.dataGridView2.AllowUserToDeleteRows = false;
            this.dataGridView2.AllowUserToResizeRows = false;
            dataGridViewCellStyle46.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle46.BackColor = System.Drawing.SystemColors.Info;
            dataGridViewCellStyle46.SelectionBackColor = System.Drawing.Color.Transparent;
            dataGridViewCellStyle46.SelectionForeColor = System.Drawing.Color.Black;
            this.dataGridView2.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle46;
            this.dataGridView2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView2.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dataGridView2.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Sunken;
            this.dataGridView2.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle47.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle47.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle47.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle47.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle47.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle47.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle47.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle47;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewCheckBoxColumn2});
            dataGridViewCellStyle48.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle48.BackColor = System.Drawing.Color.MintCream;
            dataGridViewCellStyle48.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle48.ForeColor = System.Drawing.SystemColors.Desktop;
            dataGridViewCellStyle48.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle48.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle48.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView2.DefaultCellStyle = dataGridViewCellStyle48;
            this.dataGridView2.GridColor = System.Drawing.Color.Blue;
            this.dataGridView2.Location = new System.Drawing.Point(6, 295);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle49.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle49.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle49.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle49.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle49.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle49.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle49.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView2.RowHeadersDefaultCellStyle = dataGridViewCellStyle49;
            this.dataGridView2.RowHeadersVisible = false;
            this.dataGridView2.RowHeadersWidth = 31;
            dataGridViewCellStyle50.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView2.RowsDefaultCellStyle = dataGridViewCellStyle50;
            this.dataGridView2.RowTemplate.Height = 26;
            this.dataGridView2.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView2.Size = new System.Drawing.Size(1262, 147);
            this.dataGridView2.TabIndex = 16;
            // 
            // dataGridViewCheckBoxColumn2
            // 
            this.dataGridViewCheckBoxColumn2.FillWeight = 99.22699F;
            this.dataGridViewCheckBoxColumn2.HeaderText = "Select";
            this.dataGridViewCheckBoxColumn2.Name = "dataGridViewCheckBoxColumn2";
            this.dataGridViewCheckBoxColumn2.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewCheckBoxColumn2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            dataGridViewCellStyle51.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle51.BackColor = System.Drawing.SystemColors.Info;
            dataGridViewCellStyle51.SelectionBackColor = System.Drawing.Color.Transparent;
            dataGridViewCellStyle51.SelectionForeColor = System.Drawing.Color.Black;
            this.dataGridView1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle51;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dataGridView1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Sunken;
            this.dataGridView1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle52.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle52.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle52.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle52.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle52.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle52.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle52.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle52;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewCheckBoxColumn1});
            dataGridViewCellStyle53.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle53.BackColor = System.Drawing.Color.MintCream;
            dataGridViewCellStyle53.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle53.ForeColor = System.Drawing.SystemColors.Desktop;
            dataGridViewCellStyle53.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle53.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle53.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.DefaultCellStyle = dataGridViewCellStyle53;
            this.dataGridView1.GridColor = System.Drawing.Color.Blue;
            this.dataGridView1.Location = new System.Drawing.Point(6, 6);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle54.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle54.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle54.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle54.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle54.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle54.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle54.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.RowHeadersDefaultCellStyle = dataGridViewCellStyle54;
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.RowHeadersWidth = 31;
            dataGridViewCellStyle55.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.RowsDefaultCellStyle = dataGridViewCellStyle55;
            this.dataGridView1.RowTemplate.Height = 26;
            this.dataGridView1.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.Size = new System.Drawing.Size(1262, 283);
            this.dataGridView1.TabIndex = 15;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // dataGridViewCheckBoxColumn1
            // 
            this.dataGridViewCheckBoxColumn1.FillWeight = 99.22699F;
            this.dataGridViewCheckBoxColumn1.HeaderText = "Select";
            this.dataGridViewCheckBoxColumn1.Name = "dataGridViewCheckBoxColumn1";
            this.dataGridViewCheckBoxColumn1.ReadOnly = true;
            this.dataGridViewCheckBoxColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewCheckBoxColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.dgv_TLM);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(1274, 453);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "TLM";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // dgv_TLM
            // 
            this.dgv_TLM.AllowUserToAddRows = false;
            this.dgv_TLM.AllowUserToDeleteRows = false;
            this.dgv_TLM.AllowUserToResizeRows = false;
            dataGridViewCellStyle56.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle56.BackColor = System.Drawing.SystemColors.Info;
            dataGridViewCellStyle56.SelectionBackColor = System.Drawing.Color.Transparent;
            dataGridViewCellStyle56.SelectionForeColor = System.Drawing.Color.Black;
            this.dgv_TLM.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle56;
            this.dgv_TLM.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_TLM.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgv_TLM.BackgroundColor = System.Drawing.Color.White;
            this.dgv_TLM.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgv_TLM.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Sunken;
            this.dgv_TLM.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle57.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle57.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle57.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle57.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle57.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle57.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle57.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_TLM.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle57;
            this.dgv_TLM.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_TLM.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewCheckBoxColumn3});
            dataGridViewCellStyle58.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle58.BackColor = System.Drawing.Color.MintCream;
            dataGridViewCellStyle58.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle58.ForeColor = System.Drawing.SystemColors.Desktop;
            dataGridViewCellStyle58.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle58.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle58.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgv_TLM.DefaultCellStyle = dataGridViewCellStyle58;
            this.dgv_TLM.GridColor = System.Drawing.Color.Blue;
            this.dgv_TLM.Location = new System.Drawing.Point(6, 6);
            this.dgv_TLM.Name = "dgv_TLM";
            this.dgv_TLM.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle59.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle59.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle59.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle59.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle59.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle59.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle59.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_TLM.RowHeadersDefaultCellStyle = dataGridViewCellStyle59;
            this.dgv_TLM.RowHeadersVisible = false;
            this.dgv_TLM.RowHeadersWidth = 31;
            dataGridViewCellStyle60.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgv_TLM.RowsDefaultCellStyle = dataGridViewCellStyle60;
            this.dgv_TLM.RowTemplate.Height = 26;
            this.dgv_TLM.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dgv_TLM.Size = new System.Drawing.Size(1262, 399);
            this.dgv_TLM.TabIndex = 41;
            // 
            // dataGridViewCheckBoxColumn3
            // 
            this.dataGridViewCheckBoxColumn3.FillWeight = 99.22699F;
            this.dataGridViewCheckBoxColumn3.HeaderText = "Select";
            this.dataGridViewCheckBoxColumn3.Name = "dataGridViewCheckBoxColumn3";
            this.dataGridViewCheckBoxColumn3.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewCheckBoxColumn3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(1111, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(153, 38);
            this.pictureBox1.TabIndex = 20;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(12, 3);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(182, 106);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox3.TabIndex = 42;
            this.pictureBox3.TabStop = false;
            // 
            // lbl_FlsPND
            // 
            this.lbl_FlsPND.AutoSize = true;
            this.lbl_FlsPND.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_FlsPND.Location = new System.Drawing.Point(631, 69);
            this.lbl_FlsPND.Name = "lbl_FlsPND";
            this.lbl_FlsPND.Size = new System.Drawing.Size(69, 15);
            this.lbl_FlsPND.TabIndex = 48;
            this.lbl_FlsPND.Text = "Pending:-";
            // 
            // lbl_FlsPNDVW
            // 
            this.lbl_FlsPNDVW.AutoSize = true;
            this.lbl_FlsPNDVW.Location = new System.Drawing.Point(706, 71);
            this.lbl_FlsPNDVW.Name = "lbl_FlsPNDVW";
            this.lbl_FlsPNDVW.Size = new System.Drawing.Size(53, 13);
            this.lbl_FlsPNDVW.TabIndex = 47;
            this.lbl_FlsPNDVW.Text = "Pend_cnt";
            // 
            // lbl_FlsCMP
            // 
            this.lbl_FlsCMP.AutoSize = true;
            this.lbl_FlsCMP.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_FlsCMP.Location = new System.Drawing.Point(439, 69);
            this.lbl_FlsCMP.Name = "lbl_FlsCMP";
            this.lbl_FlsCMP.Size = new System.Drawing.Size(85, 15);
            this.lbl_FlsCMP.TabIndex = 46;
            this.lbl_FlsCMP.Text = "Completed:-";
            // 
            // lbl_FlsCMPVW
            // 
            this.lbl_FlsCMPVW.AutoSize = true;
            this.lbl_FlsCMPVW.Location = new System.Drawing.Point(530, 71);
            this.lbl_FlsCMPVW.Name = "lbl_FlsCMPVW";
            this.lbl_FlsCMPVW.Size = new System.Drawing.Size(49, 13);
            this.lbl_FlsCMPVW.TabIndex = 45;
            this.lbl_FlsCMPVW.Text = "Com_cnt";
            // 
            // lbl_FilcntVw
            // 
            this.lbl_FilcntVw.AutoSize = true;
            this.lbl_FilcntVw.Location = new System.Drawing.Point(349, 69);
            this.lbl_FilcntVw.Name = "lbl_FilcntVw";
            this.lbl_FilcntVw.Size = new System.Drawing.Size(61, 13);
            this.lbl_FilcntVw.TabIndex = 44;
            this.lbl_FilcntVw.Text = "TtlFiles_cnt";
            // 
            // lbl_Files
            // 
            this.lbl_Files.AutoSize = true;
            this.lbl_Files.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Files.Location = new System.Drawing.Point(200, 67);
            this.lbl_Files.Name = "lbl_Files";
            this.lbl_Files.Size = new System.Drawing.Size(121, 15);
            this.lbl_Files.TabIndex = 43;
            this.lbl_Files.Text = "Total No:of Files:-";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(427, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 15);
            this.label1.TabIndex = 38;
            this.label1.Text = "Application";
            // 
            // cmb_Application
            // 
            this.cmb_Application.FormattingEnabled = true;
            this.cmb_Application.Location = new System.Drawing.Point(500, 11);
            this.cmb_Application.Name = "cmb_Application";
            this.cmb_Application.Size = new System.Drawing.Size(121, 21);
            this.cmb_Application.TabIndex = 39;
            // 
            // Dashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1276, 694);
            this.Controls.Add(this.lbl_FlsPND);
            this.Controls.Add(this.lbl_FlsPNDVW);
            this.Controls.Add(this.lbl_FlsCMP);
            this.Controls.Add(this.lbl_FlsCMPVW);
            this.Controls.Add(this.lbl_FilcntVw);
            this.Controls.Add(this.lbl_Files);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.btn_Clear_DB);
            this.Controls.Add(this.lbl_pen);
            this.Controls.Add(this.lbl_pen_cnt);
            this.Controls.Add(this.lbl_com);
            this.Controls.Add(this.lbl_com_cnt);
            this.Controls.Add(this.lbl_cnt);
            this.Controls.Add(this.lbl_rec);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.lnk_Logout);
            this.Controls.Add(this.Btn_Clr);
            this.Controls.Add(this.Btn_Srch);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btn_Export);
            this.Name = "Dashboard";
            this.Text = "ARC-Dashboard";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Dashboard_FormClosed);
            this.Load += new System.EventHandler(this.Dashboard_Load_1);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_Data)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.tabPage3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_TLM)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btn_Export;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.LinkLabel lnk_Logout;
        private System.Windows.Forms.Button Btn_Clr;
        private System.Windows.Forms.Button Btn_Srch;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lbl_cntry;
        private System.Windows.Forms.ComboBox cmb_cntry;
        private System.Windows.Forms.Label lbl_Prd;
        private System.Windows.Forms.ComboBox cmb_Prdt;
        private System.Windows.Forms.Label lbl_rec;
        private System.Windows.Forms.Label lbl_cnt;
        private System.Windows.Forms.Label lbl_com_cnt;
        private System.Windows.Forms.Label lbl_com;
        private System.Windows.Forms.Label lbl_pen_cnt;
        private System.Windows.Forms.Label lbl_pen;
        private System.Windows.Forms.Label lbl_File_name;
        private System.Windows.Forms.Button btn_Clear_DB;
        //private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Select;
        private System.Windows.Forms.DataGridView DGV_Data;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewCheckBoxColumn dataGridViewCheckBoxColumn1;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.DataGridViewCheckBoxColumn dataGridViewCheckBoxColumn2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.ComboBox cmb_Recon;
        private System.Windows.Forms.Label lbl_FlsPND;
        private System.Windows.Forms.Label lbl_FlsPNDVW;
        private System.Windows.Forms.Label lbl_FlsCMP;
        private System.Windows.Forms.Label lbl_FlsCMPVW;
        private System.Windows.Forms.Label lbl_FilcntVw;
        private System.Windows.Forms.Label lbl_Files;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.DataGridView dgv_TLM;
        private System.Windows.Forms.DataGridViewCheckBoxColumn dataGridViewCheckBoxColumn3;
        private System.Windows.Forms.ComboBox cmb_Application;
        private System.Windows.Forms.Label label1;
    }
}