﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;
using DAccesss;
using System.Collections;

namespace ARC_Application
{
    public partial class Dashboard_Config : Form
    {
        DAccesss.Program das = new DAccesss.Program();
        DataTable dt_Final = new DataTable();
        string conString = ConfigurationManager.ConnectionStrings["ARC_conStr"].ConnectionString;
        static string Main_DIR_SharePath = ConfigurationManager.ConnectionStrings["Share_Path"].ToString();
        string date = string.Empty;
        int Flag = 0;
        string selectedProduct;
        string selectedcountry;
        int i;
        int j;
        DataTable dt = new DataTable();

        int Total;
        int Completed;
        int File_Count = 0;
        //int Folder_File_Count = 0;
        int Non_For_Counter = 0;
        int For_Counter = 0;
        public bool isexec = false;
        string destFile = string.Empty;
        SQLEncryption ecp = new SQLEncryption();
        string Directory = Main_DIR_SharePath + DateTime.Now.ToString("dd-MMM-yyyy") + "_Files\\";
        SqlCommand cmd;
        SqlDataAdapter da;
        string sla;
        string _reconName = string.Empty;
        string temprecon = string.Empty;

        public Dashboard_Config()
        {
            InitializeComponent();

            if (!conString.StartsWith("Data"))
            {
                conString = ecp.Decrypt(conString);
            }


            refreshdata();
            date = DateTime.Now.ToString("hh:mm");
            //Timer timer = new Timer();
            ////timer.Interval = (100 * 4500); // 7 min. 30 sec.
            //timer.Interval = (100 * 2500);
            //timer.Tick += new EventHandler(timer1_Tick);
            //timer.Start();
        }

        private void Dashboard_Config_Load(object sender, EventArgs e)
        {
            dataGridView2.Visible = false;
            File_ViewRecords("", "");
            Recon_ViewRecord("", "");
        }

        public void refreshdata()
        {
            try
            {
                DataTable dt_Final = new DataTable();
                dt_Final.Columns.Add("Country_Id");
                dt_Final.Columns.Add("Country_Name");
                dt_Final.Rows.Add("0", "--All--");
                SqlConnection con = new SqlConnection(conString);
                con.Open();
                SqlCommand cmd = new SqlCommand("ARC_SP_GetCountries", con);
                cmd.CommandType = CommandType.StoredProcedure;
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                sda.Fill(dt);

                foreach (DataRow d in dt.Rows)
                {
                    dt_Final.ImportRow(d);
                }

                cmb_cntry.ValueMember = "Country_Id";
                cmb_cntry.DisplayMember = "Country_Name";
                cmb_cntry.DataSource = dt_Final;

                cmbReconCountry.ValueMember = "Country_Id";
                cmbReconCountry.DisplayMember = "Country_Name";
                cmbReconCountry.DataSource = dt_Final;

                DataTable dt_Final1 = new DataTable();
                dt_Final1.Columns.Add("Product_ID");
                dt_Final1.Columns.Add("Product_name");
                dt_Final1.Rows.Add("0", "--All--");
                cmd = new SqlCommand("ARC_SP_GetProducts", con);
                cmd.CommandType = CommandType.StoredProcedure;
                sda = new SqlDataAdapter(cmd);
                dt = new DataTable();
                sda.Fill(dt);
                foreach (DataRow d in dt.Rows)
                {
                    dt_Final1.ImportRow(d);
                }


                cmb_Prdt.ValueMember = "Product_ID";
                cmb_Prdt.DisplayMember = "Product_name";
                cmb_Prdt.DataSource = dt_Final1;


                cmbReconProduct.ValueMember = "Product_ID";
                cmbReconProduct.DisplayMember = "Product_name";
                cmbReconProduct.DataSource = dt_Final1;

                con.Close();
            }
            catch
            {

            }

        }

        private void cmbFile_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            i = cmb_cntry.SelectedIndex;
            j = cmb_Prdt.SelectedIndex;
            selectedcountry = this.cmb_cntry.GetItemText(this.cmb_cntry.SelectedItem);
            selectedProduct = this.cmb_Prdt.GetItemText(this.cmb_Prdt.SelectedItem);

            string strProduct = "";
            string strCountry = "";
            if (i > 0)
            {
                strCountry = " and a.Country_Name='" + selectedcountry + "'";
            }
            if (j > 0)
            {
                strProduct = " and a.Team='" + selectedProduct + "'";
            }
            //Recon_ViewRecord(strProduct, strCountry);
            File_ViewRecords(strProduct, strCountry);
        }


        private void cmbRecon_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            i = cmbReconCountry.SelectedIndex;
            j = cmbReconProduct.SelectedIndex;
            selectedcountry = this.cmb_cntry.GetItemText(this.cmbReconCountry.SelectedItem);
            selectedProduct = this.cmb_Prdt.GetItemText(this.cmbReconProduct.SelectedItem);

            string strProduct = "";
            string strCountry = "";
            if (i > 0)
            {
                strCountry = " and a.Country='" + selectedcountry + "'";
            }
            if (j > 0)
            {
                strProduct = " and a.Team='" + selectedProduct + "'";
            }
            Recon_ViewRecord(strProduct, strCountry);
            dataGridView2.Visible = false;
        }

        public void File_ViewRecords(string strProductVal, string strCountryVal)
        {
            try
            {

                Hashtable hat = new Hashtable();
                //SqlConnection con = new SqlConnection(conString);
                date = DateTime.Now.ToString("hh:mm");
                //con.Open();
                //SqlCommand cmd = new SqlCommand("Select Scope_Id as [S No],Team,Country_Name,Recon,CONVERT(VARCHAR(8), SLA_Time, 108) as SLA_Time,CONVERT(VARCHAR(8), Receipt_Time, 108) as Receipt_Time,Report_Source_File_Name as [Input File Name],FTP_File_Format_Name as [Output File Name],Source_Application,IsProcessed,AutomationStartTime,AutomationEndTime,AutomationStatus FROM ARC_Scope_BaseLine where In_Scope_For_ARC='yes'", con);
                // Modified by 1554580 07 Sep 2017
                string strSelectQuery = "Select row_Number () over(order by Team,Country_name,Recon,Report_Source_File_Name) [S No],Team,Country_Name,Recon,CONVERT(VARCHAR(8), SLA_Time, 108) as SLA_Time,CONVERT(VARCHAR(8), Receipt_Time, 108) as Receipt_Time,Report_Source_File_Name+'.'+isnull(File_Format,'') as [Input File Name],FTP_File_Format_Name as [Output File Name],Source_Application,Frequency,Manual_FTP,IsProcessed,AutomationStartTime,AutomationEndTime,AutomationStatus,Convert(nvarchar(15),'NA') as [Recon date] FROM ARC_Scope_BaseLine a where In_Scope_For_ARC='yes' " + strProductVal + " " + strCountryVal + "";
                //strSelectQuery = strSelectQuery + " and recon not in('MXG - sabre','Kenya - VISA Electron ATM Suspense AC recon and outstanding Report','Singapore - Prepaid','Bony and Clearstream','VIETNAM VND OPEN ITEMS (CITAD)','JAPAN - Account Balance report Nostro','Hong Kong - BOCI','VN Stock Reconciliation Report','Indonesia -TRADE & LPU RECON','BRUNEI - BCC Borrowing','Indonesia OCC','India sundry and suspense, ebbs and IDBI report','Visa Base II – Trial Balance Preparation – TOTAL','Mobile Recharge Transaction - Reconciliation-Total','Indonesia - STS Report','Issuer - EBBS Internal Account Reconciliation ATM','CLS-MLS Recon','India - Phantom Nostro','OWN Recon','SUSPENSE OPEN ITEMS(CUP)','Nepal - ATM CUP INTERNATIONAL Recon','Nepal -Retail Banking ATM CARD RECON','Thailand  CMS 4121(STS) SNS (Manual)','Nepal SOM Nostro','FED Reserve MOC')";
                strSelectQuery = strSelectQuery + " and recon in(select recon_name from arc_Recon_master where Is_Active=1 and isnull(is_holiday_logic,'0')=0  ) ";
                strSelectQuery = strSelectQuery + " union select row_Number () over(order by a.Team,a.Country_name,a.Recon,a.Report_Source_File_Name)[S No],a.Team,a.Country_Name,a.Recon,CONVERT(VARCHAR(8), a.SLA_Time, 108) as SLA_Time,CONVERT(VARCHAR(8), a.Receipt_Time, 108) as Receipt_Time,a.Report_Source_File_Name+'.'+isnull(File_Format,'') as [Input File Name],a.FTP_File_Format_Name as [Output File Name],a.Source_Application,a.Frequency,Manual_FTP,b.IsProcessed,b.AutomationStartTime,b.AutomationEndTime,b.AutomationStatus,Convert(nvarchar(15),b.[Recon_date],103) as [Recon Date] from arc_scope_baseline a,ARC_Scope_Baseline_Logic b where a.Country_id=b.Country_id and a.product_id=b.product_id and a.Recon_Id=b.Recon_Id and a.Country_Name=b.Country_Name and a.Report_Source_File_Name=b.Report_Source_File_Name and isnull(a.FTP_File_Format_Name,'')=isnull(b.FTP_File_Format_Name,'') " + strProductVal + " " + strCountryVal + " ";
                strSelectQuery = strSelectQuery + " and a.recon in(select recon_name from arc_Recon_master where Is_Active=1 and isnull(is_holiday_logic,'0')=1) order by Team,Country_name,Recon";//Report_Source_File_Name
                // SqlCommand cmd = new SqlCommand(strSelectQuery, con);
                //SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = das.Select_Table(strSelectQuery, hat, "text");

                //da.Fill(dt);
                int c = 1;
                for (int idx = 0; idx < dt.Rows.Count; idx++)
                {
                    dt.Rows[idx][0] = c;
                    c++;
                }
                dt.Columns.Add("Download Status");

                int ReconCount = 0;
                int ReconCompleted = 0;
                if (dt.Columns.Contains("Download Status"))
                {
                    for (int indx = 0; indx < dt.Rows.Count; indx++)
                    {
                        ReconCount++;

                        //  DateTime d = Convert.ToDateTime(dt.Rows[indx][4]);
                        //DateTime d1 = Convert.ToDateTime(date);

                        if (Convert.ToBoolean(dt.Rows[indx]["IsProcessed"]) == true && (dt.Rows[indx]["AutomationStatus"].ToString().ToLower() == "completed"))
                        {
                            dt.Rows[indx]["Download Status"] = "Completed";
                            ReconCompleted++;
                        }
                        else if (Convert.ToBoolean(dt.Rows[indx]["IsProcessed"]) == true && (dt.Rows[indx]["AutomationStatus"].ToString().ToLower() == "manually completed"))
                        {
                            dt.Rows[indx]["Download Status"] = "Manually Completed";
                            ReconCompleted++;
                        }
                        else if (string.IsNullOrEmpty(dt.Rows[indx]["AutomationStartTime"].ToString()) && string.IsNullOrEmpty(dt.Rows[indx]["AutomationEndTime"].ToString()))
                        {
                            dt.Rows[indx]["Download Status"] = "Yet To Start";
                        }
                        else if (!string.IsNullOrEmpty(dt.Rows[indx]["AutomationStartTime"].ToString()) && string.IsNullOrEmpty(dt.Rows[indx]["AutomationEndTime"].ToString()))
                        {
                            dt.Rows[indx]["Download Status"] = "In Progress";
                        }
                        else if (!string.IsNullOrEmpty(dt.Rows[indx]["AutomationStartTime"].ToString()) && Convert.ToBoolean(dt.Rows[indx]["IsProcessed"]) == true)
                        {
                            dt.Rows[indx]["Download Status"] = "Completed";
                            ReconCompleted++;
                        }
                        else if (!string.IsNullOrEmpty(dt.Rows[indx]["AutomationStartTime"].ToString()) && !string.IsNullOrEmpty(dt.Rows[indx]["AutomationEndTime"].ToString()) && Convert.ToBoolean(dt.Rows[indx]["IsProcessed"]) == false)
                        {
                            dt.Rows[indx]["Download Status"] = "Error";
                        }
                        else
                        {
                            dt.Rows[indx]["Download Status"] = "Yet To Start";
                        }
                    }
                }


                dt.Columns.Remove("AutomationStartTime");
                dt.Columns.Remove("AutomationEndTime");
                dt.Columns.Remove("IsProcessed");
                dt.Columns.Remove("AutomationStatus");

                DGV_Data.DataSource = null;
                DGV_Data.DataSource = dt;
                //DGV_Data.Columns[0].Visible = false;
                // Added by 1554580 07 Sep 2017
                DGV_Data.Width = 1210;
                DGV_Data.Height = 420;

                foreach (DataGridViewColumn dc in DGV_Data.Columns)
                {
                   // dc.SortMode = DataGridViewColumnSortMode.NotSortable;
                    if (dc.HeaderText == "Select")
                    {
                        dc.ReadOnly = false;
                    }
                    else
                    {
                        dc.ReadOnly = true;
                    }
                }

                //Download Status - Color variant
                foreach (DataGridViewRow row in DGV_Data.Rows)
                {
                    foreach (DataGridViewColumn col in DGV_Data.Columns)
                    {
                        if (DGV_Data["Download Status", row.Index].Value.ToString().ToLower() == "yet to start")
                        {
                            DGV_Data["Download Status", row.Index].Style.BackColor = Color.SkyBlue;
                        }

                        if (DGV_Data["Download Status", row.Index].Value.ToString().ToLower() == "in progress")
                        {
                            DGV_Data["Download Status", row.Index].Style.BackColor = Color.Orange;
                        }

                        if (DGV_Data["Download Status", row.Index].Value.ToString().ToLower() == "completed")
                        {
                            DGV_Data["Download Status", row.Index].Style.BackColor = Color.LimeGreen;
                        }

                        if (DGV_Data["Download Status", row.Index].Value.ToString().ToLower() == "manually completed")
                        {
                            DGV_Data["Download Status", row.Index].Style.BackColor = Color.LimeGreen;
                        }

                        if (DGV_Data["Download Status", row.Index].Value.ToString().ToLower() == "error")
                        {
                            DGV_Data["Download Status", row.Index].Style.BackColor = Color.Firebrick;
                        }
                    }
                }

                //con.Close();
                //Total_count();
                lbl_cnt.Text = ReconCount.ToString();
                lbl_com_cnt.Text = ReconCompleted.ToString();
                lbl_pen_cnt.Text = (ReconCount - ReconCompleted).ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        public void Recon_ViewRecord(string strProductVal, string strCountryVal)
        {
            int linnum = 0;
            date = DateTime.Now.ToString("HH:MM");
            try
            {
                Hashtable hat = new Hashtable();
                dt = new DataTable();
                //SqlConnection con = new SqlConnection(conString);
                //con.Open();
                //cmd = new SqlCommand("ARC_SP_TotalProcessedReconCount", con);
                //cmd.CommandType = CommandType.StoredProcedure;
                //cmd.Parameters.AddWithValue("@Action", "All");
                //da = new SqlDataAdapter(cmd);
                //// DataTable dt1 = new DataTable();
                //da.Fill(dt);
                //con.Close();
                //con.Open();
                //cmd = new SqlCommand("", con);


                string strquery = "select Recon_ID as [S No],Team,Country,Recon_Name,Total_Files,CONVERT(varchar(5),convert(TIME, convert(DATETIME, SLA_Time, 120)))as SLA_Time, CONVERT(varchar(5),convert(TIME, convert(DATETIME, Receipt_Time, 120)))as Receipt_Time,Is_Recon_Completed, AutomationStartTime, AutomationEndTime,Convert(Nvarchar(50),'NA') Recon_date,isnull(Recon_Status,'') as Recon_Status  from dbo.ARC_Recon_Master a where Is_Active=1 " + strProductVal + " " + strCountryVal + "";
                //strquery = strquery + "  and recon_name not in('MXG - sabre','Kenya - VISA Electron ATM Suspense AC recon and outstanding Report','Singapore - Prepaid','Bony and Clearstream','VIETNAM VND OPEN ITEMS (CITAD)','JAPAN - Account Balance report Nostro','Hong Kong - BOCI','VN Stock Reconciliation Report','Indonesia -TRADE & LPU RECON','BRUNEI - BCC Borrowing','Indonesia OCC','India sundry and suspense, ebbs and IDBI report','Visa Base II – Trial Balance Preparation – TOTAL','Mobile Recharge Transaction - Reconciliation-Total','Indonesia - STS Report','Issuer - EBBS Internal Account Reconciliation ATM','CLS-MLS Recon','India - Phantom Nostro','OWN Recon','SUSPENSE OPEN ITEMS(CUP)','Nepal - ATM CUP INTERNATIONAL Recon','Nepal -Retail Banking ATM CARD RECON','Thailand  CMS 4121(STS) SNS (Manual)','Nepal SOM Nostro','FED Reserve MOC')";
                strquery = strquery + "  and isnull(is_holiday_logic,'0')=0 ";
                strquery = strquery + "  union select Recon_ID as [S No],Team,Country,Recon_Name,Total_Files,CONVERT(varchar(5),convert(TIME, convert(DATETIME, SLA_Time, 120)))as SLA_Time, CONVERT(varchar(5),convert(TIME, convert(DATETIME, Receipt_Time, 120)))as Receipt_Time,Is_Recon_Completed, AutomationStartTime, AutomationEndTime,Convert(nvarchar(15),Recon_date,103) Recon_Date,isnull(Recon_Status,'') as Recon_Status  from ARC_Recon_Master_Holiday_date_Logic a where Is_Active=1 " + strProductVal + " " + strCountryVal + "";
                strquery = strquery + "  and recon_name in(select recon_name from arc_Recon_master where Is_Active=1 and isnull(is_holiday_logic,'0')=1) order by Team,Country,Recon_name,recon_date";
                dt = das.Select_Table(strquery, hat, "text");

                //dt.Columns.Add("Time To SLA");
                dt.Columns.Add("Output Status");
                dt.Columns.Add("TLM FTP Status");

                int ReconCount = 0;
                int ReconCompleted = 0;
                if (dt.Columns.Contains("Output Status"))
                {
                    for (int indx = 0; indx < dt.Rows.Count; indx++)
                    {
                        ReconCount++;

                        linnum = indx;

                        string sd1 = dt.Rows[indx][4].ToString();
                        string sd2 = date.ToString();
                        DateTime d = Convert.ToDateTime(dt.Rows[indx][5]);
                        DateTime d1 = Convert.ToDateTime(date);
                        sla = (d - d1).ToString();
                        //if (Convert.ToBoolean(dt.Rows[indx][7]) == true && d.TimeOfDay < d1.TimeOfDay)
                        //{
                        //    dt.Rows[indx][8] = "0.00";
                        //    //dt.Rows[indx][9] = imageToByteArray(i1);
                        //}
                        //else if (Convert.ToBoolean(dt.Rows[indx][7]) == false && d.TimeOfDay > d1.TimeOfDay)
                        //{
                        //    dt.Rows[indx][8] = sla;
                        //    //dt.Rows[indx][9] = imageToByteArray(i3);
                        //}
                        //else if (Convert.ToBoolean(dt.Rows[indx][7]) == false && d.TimeOfDay < d1.TimeOfDay)
                        //{
                        //    dt.Rows[indx][8] = sla;
                        //    //dt.Rows[indx][9] = imageToByteArray(i2);
                        //}
                        //else if (Convert.ToBoolean(dt.Rows[indx][7]) == true && d.TimeOfDay > d1.TimeOfDay)
                        //{
                        //    dt.Rows[indx][8] = "0.00";
                        //    //dt.Rows[indx][9] = imageToByteArray(i1);
                        //}


                        if (string.IsNullOrEmpty(dt.Rows[indx]["AutomationStartTime"].ToString()) && string.IsNullOrEmpty(dt.Rows[indx]["AutomationEndTime"].ToString()))
                        {
                            dt.Rows[indx]["Output Status"] = "Yet To Start";
                        }
                        else if (!string.IsNullOrEmpty(dt.Rows[indx]["AutomationStartTime"].ToString()) && string.IsNullOrEmpty(dt.Rows[indx]["AutomationEndTime"].ToString()))
                        {
                            dt.Rows[indx]["Output Status"] = "In Progress";
                        }
                        else if (!string.IsNullOrEmpty(dt.Rows[indx]["AutomationStartTime"].ToString()) && Convert.ToBoolean(dt.Rows[indx]["Is_Recon_Completed"]) == true && dt.Rows[indx]["Recon_Status"].ToString().ToLower().Equals("completed"))
                        {
                            dt.Rows[indx]["Output Status"] = "Completed";
                            ReconCompleted++;
                        }
                        else if (!string.IsNullOrEmpty(dt.Rows[indx]["AutomationStartTime"].ToString()) && Convert.ToBoolean(dt.Rows[indx]["Is_Recon_Completed"]) == true && dt.Rows[indx]["Recon_Status"].ToString().ToLower().Equals("manually completed"))
                        {
                            dt.Rows[indx]["Output Status"] = "Manually Completed";
                            ReconCompleted++;
                        }
                        else if (!string.IsNullOrEmpty(dt.Rows[indx]["AutomationStartTime"].ToString()) && !string.IsNullOrEmpty(dt.Rows[indx]["AutomationEndTime"].ToString()) && Convert.ToBoolean(dt.Rows[indx]["Is_Recon_Completed"]) == false)
                        {
                            dt.Rows[indx]["Output Status"] = "Error";
                        }
                        else
                        {
                            dt.Rows[indx]["Output Status"] = "Yet To Start";
                        }
                    }
                }

                dt.Columns.Remove("AutomationStartTime");
                dt.Columns.Remove("AutomationEndTime");
                dt.Columns.Remove("Is_Recon_Completed");
                // Added by 1554580 07 Sep 2017
                int c = 1;
                for (int idx = 0; idx < dt.Rows.Count; idx++)
                {
                    dt.Rows[idx][0] = c;
                    c++;
                }

                dataGridView1.DataSource = dt;

                dataGridView1.Columns["dataGridViewCheckBoxColumn1"].DisplayIndex = dataGridView1.Columns.Count - 1;
                dataGridView1.Width = 1230;// Added by 1554580 07 Sep 2017
                //dataGridView1.Columns[0].Visible = false;

                foreach (DataGridViewColumn dc in dataGridView1.Columns)
                {
                   // dc.SortMode = DataGridViewColumnSortMode.NotSortable;

                    if (dc.HeaderText == "Select")
                    {
                        dc.ReadOnly = false;
                    }
                    else
                    {
                        dc.ReadOnly = true;
                    }
                }

                //Download Status - Color variant
                foreach (DataGridViewRow row in dataGridView1.Rows)
                {
                    foreach (DataGridViewColumn col in dataGridView1.Columns)
                    {
                        if (dataGridView1["Output Status", row.Index].Value.ToString().ToLower() == "yet to start")
                        {
                            dataGridView1["Output Status", row.Index].Style.BackColor = Color.SkyBlue;
                        }

                        if (dataGridView1["Output Status", row.Index].Value.ToString().ToLower() == "in progress")
                        {
                            dataGridView1["Output Status", row.Index].Style.BackColor = Color.Orange;
                        }

                        if (dataGridView1["Output Status", row.Index].Value.ToString().ToLower() == "completed")
                        {
                            dataGridView1["Output Status", row.Index].Style.BackColor = Color.LimeGreen;
                        }

                        //if (dataGridView1["Formatting Status", row.Index].Value.ToString().ToLower() == "manually completed")
                        //{
                        //    dataGridView1["Formatting Status", row.Index].Style.BackColor = Color.LimeGreen;
                        //}

                        if (dataGridView1["Output Status", row.Index].Value.ToString().ToLower() == "error")
                        {
                            dataGridView1["Output Status", row.Index].Style.BackColor = Color.Firebrick;
                        }
                    }
                }

                //con.Close();

                //Need to update

                lblReconFileCount.Text = ReconCount.ToString();
                lblReconCompleted.Text = ReconCompleted.ToString();
                lblReconPending.Text = (ReconCount - ReconCompleted).ToString();
            }
            catch (Exception ex)
            {
                int x = linnum;
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            SqlConnection con = new SqlConnection(conString);
            DataTable dt_DGV = new DataTable();
            if (e.RowIndex == -1) return;

            if (dataGridView1.CurrentCell.ColumnIndex.Equals(4))
            {
                if (dataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex].Value != null)
                {
                    _reconName = dataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString();

                    if (temprecon == _reconName)
                    {
                        if (dataGridView2.Visible == true)
                        {
                            dataGridView2.Visible = false;
                        }
                        else
                        {
                            dataGridView2.Visible = true;
                            ViewRecords_DB(_reconName);
                        }
                    }
                    else
                    {
                        temprecon = _reconName;

                        dataGridView2.Visible = true;
                        ViewRecords_DB(_reconName);
                    }
                }
            }
            dataGridView2.Height = 160;
            dataGridView2.Width = 1220;
        }

        public void ViewRecords_DB(string recon_name)
        {
            try
            {
                Hashtable hat = new Hashtable();
                SqlConnection con = new SqlConnection(conString);
                date = DateTime.Now.ToString("hh:mm");

                string strquery = "Select a.Scope_Id as [S No],b.Team,b.Country_Name,b.Recon,CONVERT(VARCHAR(8), a.SLA_Time, 108) as SLA_Time,CONVERT(VARCHAR(8), a.Receipt_Time, 108) as Receipt_Time,b.Report_Source_File_Name+'.'+isnull(a.File_Format,'') as [Input File Name],b.FTP_File_Format_Name as [Output File Name],a.Source_Application,a.Frequency,b.IsProcessed,b.AutomationStartTime,b.AutomationEndTime,b.Recon_Date,b.AutomationStatus FROM ARC_Scope_BaseLine a,Arc_Scope_Baseline_Logic b where a.Country_name=b.country_name and a.Team=B.Team and a.Report_Source_file_name=b.Report_Source_file_name and a.FTP_File_Format_name=b.Ftp_File_Format_Name and a.In_Scope_For_ARC='yes' and b.Recon ='" + recon_name + "' order by b.Report_Source_file_name,b.Recon_Date";
                DataTable dt = das.Select_Table(strquery, hat, "Text");
                if (dt.Rows.Count == 0)
                {
                    strquery = "Select Scope_Id as [S No],Team,Country_Name,Recon,CONVERT(VARCHAR(8), SLA_Time, 108) as SLA_Time,CONVERT(VARCHAR(8), Receipt_Time, 108) as Receipt_Time,Report_Source_File_Name+'.'+isnull(File_Format,'') as [Input File Name],FTP_File_Format_Name as [Output File Name],Source_Application,Frequency,IsProcessed,AutomationStartTime,AutomationEndTime,AutomationStatus FROM ARC_Scope_BaseLine where In_Scope_For_ARC='yes' and Recon ='" + recon_name + "'";
                    dt = das.Select_Table(strquery, hat, "text");
                }


                //con.Open();
                //SqlCommand cmd = new SqlCommand("Select Scope_Id as [S No],Team,Country_Name,Recon,CONVERT(VARCHAR(8), SLA_Time, 108) as SLA_Time,CONVERT(VARCHAR(8), Receipt_Time, 108) as Receipt_Time,Report_Source_File_Name as [Input File Name],FTP_File_Format_Name as [Output File Name],Source_Application,IsProcessed,AutomationStartTime,AutomationEndTime,AutomationStatus FROM ARC_Scope_BaseLine where In_Scope_For_ARC='yes' and Recon ='" + recon_name + "'", con);
                //SqlDataAdapter da = new SqlDataAdapter(cmd);
                //DataTable dt = new DataTable();
                //da.Fill(dt);
                int c = 1;
                for (int idx = 0; idx < dt.Rows.Count; idx++)
                {
                    dt.Rows[idx][0] = c;
                    c++;
                }
                //dt.Columns.Add("Download Status", typeof(byte[]));
                dt.Columns.Add("Download Status");
                if (dt.Columns.Contains("Download Status"))
                {
                    for (int indx = 0; indx < dt.Rows.Count; indx++)
                    {
                        DateTime d = Convert.ToDateTime(dt.Rows[indx][4]);
                        DateTime d1 = Convert.ToDateTime(date);
                        //if (Convert.ToBoolean(dt.Rows[indx][9]) == true && d.TimeOfDay < d1.TimeOfDay)
                        //{
                        //    dt.Rows[indx][10] = obj.imageToByteArray(i1);
                        //}
                        //else if (Convert.ToBoolean(dt.Rows[indx][9]) == false && d.TimeOfDay > d1.TimeOfDay)
                        //{
                        //    dt.Rows[indx][10] = obj.imageToByteArray(i3);
                        //}
                        //else if (Convert.ToBoolean(dt.Rows[indx][9]) == false && d.TimeOfDay < d1.TimeOfDay)
                        //{
                        //    dt.Rows[indx][10] = obj.imageToByteArray(i2);
                        //}
                        //else if (Convert.ToBoolean(dt.Rows[indx][9]) == true && d.TimeOfDay > d1.TimeOfDay)
                        //{
                        //    dt.Rows[indx][10] = obj.imageToByteArray(i1);
                        //}


                        if (Convert.ToBoolean(dt.Rows[indx]["IsProcessed"]) == true && (dt.Rows[indx]["AutomationStatus"].ToString().ToLower() == "completed"))
                        {
                            dt.Rows[indx]["Download Status"] = "Completed";
                        }
                        else if (Convert.ToBoolean(dt.Rows[indx]["IsProcessed"]) == true && (dt.Rows[indx]["AutomationStatus"].ToString().ToLower() == "manually completed"))
                        {
                            dt.Rows[indx]["Download Status"] = "Manually Completed";
                        }
                        else if (string.IsNullOrEmpty(dt.Rows[indx]["AutomationStartTime"].ToString()) && string.IsNullOrEmpty(dt.Rows[indx]["AutomationEndTime"].ToString()))
                        {
                            dt.Rows[indx]["Download Status"] = "Yet To Start";
                        }
                        else if (!string.IsNullOrEmpty(dt.Rows[indx]["AutomationStartTime"].ToString()) && string.IsNullOrEmpty(dt.Rows[indx]["AutomationEndTime"].ToString()))
                        {
                            dt.Rows[indx]["Download Status"] = "In Progress";
                        }
                        else if (!string.IsNullOrEmpty(dt.Rows[indx]["AutomationStartTime"].ToString()) && Convert.ToBoolean(dt.Rows[indx]["IsProcessed"]) == true)
                        {
                            dt.Rows[indx]["Download Status"] = "Completed";
                        }
                        else if (!string.IsNullOrEmpty(dt.Rows[indx]["AutomationStartTime"].ToString()) && !string.IsNullOrEmpty(dt.Rows[indx]["AutomationEndTime"].ToString()) && Convert.ToBoolean(dt.Rows[indx]["IsProcessed"]) == false)
                        {
                            dt.Rows[indx]["Download Status"] = "Error";
                        }
                        else
                        {
                            dt.Rows[indx]["Download Status"] = "Yet To Start";
                        }

                    }
                }

                //Form1 f1 = new Form1(dt);
                //f1.Show();
                //f1.dataGridView1.Columns[10].Visible = false;

                dt.Columns.Remove("AutomationStartTime");
                dt.Columns.Remove("AutomationEndTime");
                dt.Columns.Remove("IsProcessed");
                dt.Columns.Remove("AutomationStatus");

                dataGridView2.DataSource = dt;

                dataGridView2.Columns[0].Visible = false;
                dataGridView2.Width = 1254;// Added by 1554580 07 Sep 2017
                dataGridView2.Height = 135;
                foreach (DataGridViewColumn dc in dataGridView2.Columns)
                {
                    dc.SortMode = DataGridViewColumnSortMode.NotSortable;

                    if (dc.HeaderText == "Select")
                    {
                        dc.ReadOnly = false;
                    }
                    else
                    {
                        dc.ReadOnly = true;
                    }
                }


                //Download Status - Color variant
                foreach (DataGridViewRow row in dataGridView2.Rows)
                {
                    foreach (DataGridViewColumn col in dataGridView2.Columns)
                    {
                        if (dataGridView2["Download Status", row.Index].Value.ToString().ToLower() == "yet to start")
                        {
                            dataGridView2["Download Status", row.Index].Style.BackColor = Color.SkyBlue;
                        }

                        if (dataGridView2["Download Status", row.Index].Value.ToString().ToLower() == "in progress")
                        {
                            dataGridView2["Download Status", row.Index].Style.BackColor = Color.Orange;
                        }

                        if (dataGridView2["Download Status", row.Index].Value.ToString().ToLower() == "completed")
                        {
                            dataGridView2["Download Status", row.Index].Style.BackColor = Color.LimeGreen;
                        }

                        if (dataGridView2["Download Status", row.Index].Value.ToString().ToLower() == "manually completed")
                        {
                            dataGridView2["Download Status", row.Index].Style.BackColor = Color.LimeGreen;
                        }

                        if (dataGridView2["Download Status", row.Index].Value.ToString().ToLower() == "error")
                        {
                            dataGridView2["Download Status", row.Index].Style.BackColor = Color.Firebrick;
                        }
                    }
                }

                // con.Close();
                //Total_count();
            }
            catch
            {

            }
        }
        private void btnReconCompleted_Click(object sender, EventArgs e)
        {
            try
            {
                dataGridView2.Visible = false;
                //DateTime dtReconDate = DateTime.ParseExact(dtpReconDate.Text.ToString(), "dd/MM/yyyy", System.Globalization.CultureInfo.CurrentUICulture);
                Hashtable hat = new Hashtable();
                DataGridViewRowCollection Rows = dataGridView1.Rows;
                int colcnt = dataGridView1.Columns.Count;
                bool IsCheck = false;
                foreach (DataGridViewRow row in Rows)
                {
                    if (row.Cells[0].Value != null && row.Cells[0].Value.ToString().Trim().ToUpper() == "TRUE")
                    {
                        IsCheck = true;
                        string recon = row.Cells["Recon_Name"].Value.ToString();
                        string ReconDate = row.Cells["Recon_date"].Value.ToString();
                        string strInsUpdQuery = "";
                        int InsUpdVal = 0;
                        if (ReconDate.Trim().ToUpper() != "NA" && ReconDate.Trim() != null)
                        {
                            DateTime dtReconDate = DateTime.ParseExact(ReconDate, "dd/MM/yyyy", System.Globalization.CultureInfo.CurrentUICulture);

                            strInsUpdQuery = "update Arc_Recon_Master_Holiday_date_logic set Is_recon_Completed=1,Recon_Status='MANUALLY COMPLETED',PSID='" + Environment.UserName.ToString() + "',AutomationStartTime='" + DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss") + "',AutomationEndTime='" + DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss") + "' where recon_name='" + recon + "' and recon_date='" + dtReconDate.ToString("MM/dd/yyyy") + "'";
                            InsUpdVal = das.ins_upd_fun(strInsUpdQuery, hat, "text");

                            strInsUpdQuery = "update Arc_Scope_Baseline_Logic set IsProcessed=1,AutomationStatus='MANUALLY COMPLETED',PSID='" + Environment.UserName.ToString() + "',Processed_Date='" + DateTime.Now.ToString("MM/dd/yyyy") + "',AutomationStartTime='" + DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss") + "',AutomationEndTime='" + DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss") + "' where recon='" + recon + "' and recon_date='" + dtReconDate.ToString("MM/dd/yyyy") + "'";
                            InsUpdVal = das.ins_upd_fun(strInsUpdQuery, hat, "text");
                        }
                        else
                        {
                            strInsUpdQuery = "update arc_recon_master set Is_recon_Completed=1,Recon_Status='MANUALLY COMPLETED',PSID='" + Environment.UserName.ToString() + "',AutomationStartTime='" + DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss") + "',AutomationEndTime='" + DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss") + "' where recon_name='" + recon + "'";
                            InsUpdVal = das.ins_upd_fun(strInsUpdQuery, hat, "text");

                            strInsUpdQuery = "update Arc_Scope_baseline set IsProcessed=1,AutomationStatus='MANUALLY COMPLETED',PSID='" + Environment.UserName.ToString() + "',AutomationStartTime='" + DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss") + "',AutomationEndTime='" + DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss") + "' where recon='" + recon + "'";
                            InsUpdVal = das.ins_upd_fun(strInsUpdQuery, hat, "text");
                        }
                    }
                }
                if (IsCheck == false)
                {
                    MessageBox.Show("Please Select check box...!");
                }
                else
                {
                    Recon_ViewRecord("", "");
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void btnDisableRecon_Click(object sender, EventArgs e)
        {
            try
            {
                Hashtable hat = new Hashtable();
                DataGridViewRowCollection Rows = dataGridView1.Rows;
                int colcnt = dataGridView1.Columns.Count;
                bool IsCheck = false;
                foreach (DataGridViewRow row in Rows)
                {
                    if (row.Cells[0].Value != null && row.Cells[0].Value.ToString().Trim().ToUpper() == "TRUE")
                    {
                        IsCheck = true;
                        string recon = row.Cells["Recon_Name"].Value.ToString();
                        //cmd = new SqlCommand("update arc_recon_master set IS_Active = 0, Is_Recon_Completed = 0, PSID = '" + Environment.UserName.ToString() + "', Recon_Status = null where recon_name = '" + recon + "'", con);
                        int insupdaval = das.ins_upd_fun("update arc_recon_master set IS_Active = 0, Is_Recon_Completed = 0, PSID = '" + Environment.UserName.ToString() + "', Recon_Status = null where recon_name = '" + recon + "'", hat, "Text");

                        insupdaval = das.ins_upd_fun("update Arc_Recon_Master_Holiday_date_logic set IS_Active = 0, Is_Recon_Completed = 0, PSID = '" + Environment.UserName.ToString() + "', Recon_Status = null,AutomationStartTime=null,AutomationEndTime=null where recon_name = '" + recon + "'", hat, "Text");
                        //int i = das.ins_upd_fun("update arc_recon_master set IS_Active = 0, Is_Recon_Completed = 0, PSID = '" + Environment.UserName.ToString() + "', Recon_Status = null where recon_name = '" + recon + "'", hat, "Text");
                        if (i > 0)
                        {
                            //MessageBox.Show("Sucessful");
                        }
                    }
                }
                if (IsCheck == false)
                {
                    MessageBox.Show("Please Select check box...!");
                }
                else
                {
                    Recon_ViewRecord("", "");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void btn_Clear_DB_Click(object sender, EventArgs e)
        {
            Hashtable hat = new Hashtable();
            SqlConnection con = new SqlConnection(conString);
            SqlCommand cmd = null;
            SqlCommand cmd1 = null;
            SqlCommand cmd2 = null;
            DataGridViewRowCollection Rows = DGV_Data.Rows;
            bool IsCheck = false;
            con.Open();
            foreach (DataGridViewRow row in Rows)
            {
                ///Prakash Commneted -OLD
                    //if (row.Cells["Select"].Value != null && row.Cells["Select"].Value.ToString() == "True")
                //{
                //    IsCheck = true;
                //    string recon = row.Cells["Recon"].Value.ToString();
                //    string Country = row.Cells["Country_Name"].Value.ToString();
                //    string File_Name = row.Cells["Input File Name"].Value.ToString();
                //    string Recon_Date = row.Cells["Recon Date"].Value.ToString();
                //    cmd = new SqlCommand("update ARC_Scope_BaseLine set IsProcessed = 0, AutomationStatus = null, AutomationStartTime = null, AutomationEndTime = null, PSID = null where Recon = '" + recon + "' and  Country_Name = '" + Country + "' and Report_Source_File_Name = '" + File_Name + "'", con);
                //    cmd1 = new SqlCommand("update arc_recon_master set Is_Recon_Completed = 0, PSID = null, Recon_Status = null where recon_name = '" + recon + "'", con);
                //    if (Recon_Date != null && Recon_Date.Trim().ToUpper() != "NA")
                //    {
                //        DateTime dtRecon = DateTime.ParseExact(Recon_Date, "dd/MM/yyyy", System.Globalization.CultureInfo.InvariantCulture);

                //        int t = 0;
                //        string strInsUpdHoliDayFile = "update ARC_Scope_BaseLine_Logic set IsProcessed = 0, AutomationStatus = null, AutomationStartTime = null, AutomationEndTime = null, PSID = null,Processed_Date=null where Recon = '" + recon + "' and  Country_Name = '" + Country + "' and Report_Source_File_Name = '" + File_Name + "' and recon_date='" + dtRecon.ToString("MM/dd/yyyy") + "'";
                //        t = das.ins_upd_fun(strInsUpdHoliDayFile, hat, "Text");

                //        string strInsUpdHoliDayRecon = "update ARC_Recon_Master_Holiday_date_logic set Is_Recon_Completed = 0, PSID = null, Recon_Status = null where recon_name = '" + recon + "' and Recon_date='" + dtRecon.ToString("MM/dd/yyyy") + "'";
                //        t = das.ins_upd_fun(strInsUpdHoliDayRecon, hat, "Text");
                //    }
                //    int i = cmd.ExecuteNonQuery();
                //    int j = cmd1.ExecuteNonQuery();
                //    if (i > 0 || j > 0)
                //    {
                //        //MessageBox.Show("Sucessful");
                //    }
                //}
                ///Prakash Commneted -OLD
                ///
                if (row.Cells["Select"].Value != null && row.Cells["Select"].Value.ToString() == "True")
                {
                    IsCheck = true;
                    string recon = row.Cells["Recon"].Value.ToString();
                    string Country = row.Cells["Country_Name"].Value.ToString();
                    string[] File_Name = row.Cells["Input File Name"].Value.ToString().Split('.');
                    string Recon_Date = row.Cells["Recon Date"].Value.ToString();

                    //cmd = new SqlCommand("update ARC_Scope_BaseLine set IsProcessed = 0, AutomationStatus = null, AutomationStartTime = null, AutomationEndTime = null, PSID = null, Retry_Count= Retry_Count+1 where Recon = '" + recon + "' and  Country_Name = '" + Country + "' and Report_Source_File_Name = '" + File_Name + "'", con);
                    string query = "";
                    query = "select count(1) cnt from ARC_SCOPE_BASELINE where automationstarttime Is Not null and PSID  is not null and Recon = '" + recon + "' and  Country_Name = '" + Country + "' and Report_Source_File_Name like '" + File_Name[0] + "%'";
                    DataTable dt = das.Select_Table(query, hat, "Text");

                    int IsDataAvailable = 0;
                    if (dt.Rows.Count > 0)
                    {
                        IsDataAvailable = Convert.ToInt32(dt.Rows[0]["cnt"].ToString());
                    }
                    if (IsDataAvailable == 1)
                    {
                        cmd2 = new SqlCommand("insert into ARC_SCOPE_BASELINE_RETRY select * from ARC_SCOPE_BASELINE where  Recon = '" + recon + "' and  Country_Name = '" + Country + "' and Report_Source_File_Name like '" + File_Name[0] + "%'", con);
                        cmd = new SqlCommand("update ARC_Scope_BaseLine set IsProcessed = 0, AutomationStatus = null, AutomationStartTime = null, AutomationEndTime = null, PSID = null, Retry_Count= Retry_Count+1  where Recon = '" + recon + "' and  Country_Name = '" + Country + "' and Report_Source_File_Name like '" + File_Name[0] + "%'", con);
                    }
                    cmd1 = new SqlCommand("update arc_recon_master set Is_Recon_Completed = 0, PSID = null, Recon_Status = null,AutomationStartTime=Null,AutomationEndTime=null where recon_name = '" + recon + "'", con);
                    if (Recon_Date != null && Recon_Date.Trim().ToUpper() != "NA")
                    {
                        DateTime dtRecon = DateTime.ParseExact(Recon_Date, "dd/MM/yyyy", System.Globalization.CultureInfo.InvariantCulture);
                        int t = 0;

                        string strInsUpdHoliDayFileRetry = "insert into ARC_SCOPE_BASELINE_LOGIC_RETRY select * from ARC_SCOPE_BASELINE_LOGIC where Recon = '" + recon + "' and  Country_Name = '" + Country + "' and Report_Source_File_Name like '" + File_Name[0] + "%' and recon_date='" + dtRecon.ToString("MM/dd/yyyy") + "'";
                        t = das.ins_upd_fun(strInsUpdHoliDayFileRetry, hat, "Text");

                        string strInsUpdHoliDayFile = "update ARC_Scope_BaseLine_Logic set IsProcessed = 0, AutomationStatus = null, AutomationStartTime = null, AutomationEndTime = null, PSID = null,Processed_Date=null, Retry_Count= Retry_Count+1 where Recon = '" + recon + "' and  Country_Name = '" + Country + "' and Report_Source_File_Name like '" + File_Name[0] + "%' and recon_date='" + dtRecon.ToString("MM/dd/yyyy") + "'";
                        t = das.ins_upd_fun(strInsUpdHoliDayFile, hat, "Text");

                        string strInsUpdHoliDayRecon = "update ARC_Recon_Master_Holiday_date_logic set Is_Recon_Completed = 0, PSID = null, Recon_Status = null,AutomationStartTime=Null,AutomationEndTime=null where recon_name = '" + recon + "' and Recon_date='" + dtRecon.ToString("MM/dd/yyyy") + "'";
                        t = das.ins_upd_fun(strInsUpdHoliDayRecon, hat, "Text");
                    }
                    int i = 0;
                    int k = 0;
                    if (IsDataAvailable == 1)
                    {
                        k = cmd2.ExecuteNonQuery();
                        i = cmd.ExecuteNonQuery();
                    }
                    int j = cmd1.ExecuteNonQuery();
                    if (i > 0 || j > 0)
                    {
                        //MessageBox.Show("Sucessful");
                    }
                }
            }
            con.Close();
            if (IsCheck == false)
            {
                MessageBox.Show("Please Select check box...!");
            }
            else
            {
                File_ViewRecords("", "");
            }
        }

    }
}
