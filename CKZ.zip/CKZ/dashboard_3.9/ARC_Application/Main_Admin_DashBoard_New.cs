﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using Microsoft.Office.Interop.Excel;
using System.Globalization;
using System.Configuration;
using System.IO;
using System.Collections;
using System.Security.Cryptography;
using DAccesss;

namespace ARC_Application
{
    public partial class Main_Admin_DashBoard_New : Form
    {
        ArrayList arraylist1 = new ArrayList();
        ArrayList arraylist2 = new ArrayList();
        static string Main_DIR_SharePath = ConfigurationManager.ConnectionStrings["Share_Path"].ToString();
        string Directory = Main_DIR_SharePath + DateTime.Now.ToString("dd-MMM-yyyy") + "_Files\\";
        Formatting_Logics obj = new Formatting_Logics();
        static string conString = ConfigurationManager.ConnectionStrings["ARC_conStr"].ConnectionString;
        SQLEncryption ecp = new SQLEncryption();
        string strAppl = "";
        string strCountr = "";
        string strPrdt = "";
        string date;
        string selectedProduct;
        string selectedcountry;
        int i;
        int j;
        System.Data.DataTable dt = new System.Data.DataTable();
        ///
        /// Method  Btn_Srch_Click_1 commented - Aneesh
        //Need to uncomment Imp code
        //Image i1 = Image.FromFile(@"\\10.132.5.214\TempFiles\ARC Main Solutions\ARC_Latest_Solution\Images\index1.jpg");
        //Image i2 = Image.FromFile(@"\\10.132.5.214\TempFiles\ARC Main Solutions\ARC_Latest_Solution\Images\index2.jpg");
        //Image i3 = Image.FromFile(@"\\10.132.5.214\TempFiles\ARC Main Solutions\ARC_Latest_Solution\Images\index3.png");
        int Total;
        int Completed;
        string sla;
        SqlConnection con;
        SqlCommand cmd;
        SqlDataAdapter da;
        Dashboard_Config dashForm;
        DAccesss.Program das = new DAccesss.Program();

        public Main_Admin_DashBoard_New()
        {
            try
            {
                InitializeComponent();

                if (!conString.StartsWith("Data"))
                {
                    conString = ecp.Decrypt(conString);
                }

                Dashboard_Config dashForm = new Dashboard_Config();
                dashForm.TopLevel = false;
                //dashForm.AutoScroll = true;
                dashboard_panel.Controls.Add(dashForm);
                dashForm.Show();

                Admin_Config adminForm = new Admin_Config();
                adminForm.TopLevel = false;
                //adminForm.AutoScroll = true;
                admin_panel.Controls.Add(adminForm);
                adminForm.Show();

                //tabPage1.AutoScroll = true;
                Total_count();
               // refreshdata();

                LoadHolidayRecon();
            }
            catch (Exception ex)
            {

            }
        }

        public byte[] imageToByteArray(System.Drawing.Image imageIn)
        {
            MemoryStream ms = new MemoryStream();
            imageIn.Save(ms, System.Drawing.Imaging.ImageFormat.Gif);
            return ms.ToArray();
        }

        protected override void WndProc(ref Message m)
        {
            base.WndProc(ref m);
            //if (m.Msg == 0x0112)
            //{
            //    if (m.WParam == new IntPtr(0xF030))
            //    {
            //        Ref.Location = new System.Drawing.Point(1200, 130);
            //        lnk_Logout.Location = new System.Drawing.Point(1270, 0);
            //        Loading.Location = new System.Drawing.Point(650,0);
            //        Logout.Location = new System.Drawing.Point(1250, 80);
            //        DGV_AData.Width = 1300;
            //        DGV_AData.Height = 600;
            //        DGV_AData.Location = new System.Drawing.Point(4, 185);
            //        Btn_Clr.Location = new System.Drawing.Point(1240, 131);
            //        tabControl1.Height = 500;
            //        tabControl1.Width = 1350;
            //        tabPage1.AutoScroll = true;
            //    }
            //    else if (m.WParam == new IntPtr(0xF120))
            //    {

            //        //Main_Admin_DashBoard.ActiveForm.Size = new Size(1201, 494);//this.Size = new Size(1201, 494);
            //        //Main_Admin_DashBoard.ActiveForm.Location = new System.Drawing.Point();
            //        //Main_Admin_DashBoard.ActiveForm.StartPosition = FormStartPosition.CenterScreen;
            //        DGV_AData.Height = 241;
            //        DGV_AData.Width = 1097;

            //        lnk_Logout.Location = new System.Drawing.Point(1192, 82);
            //        Btn_Clr.Location = new System.Drawing.Point(1013, 89);
            //        tabControl1.Height = 423;
            //        tabControl1.Width = 1242;
            //        tabPage1.AutoScroll = true;

            //    }

            //}
        }

        private string Encrypt(string clearText)
        {
            try
            {
                string EncryptionKey = "MAKV2SPBNI99212";
                byte[] clearBytes = Encoding.Unicode.GetBytes(clearText);
                using (Aes encryptor = Aes.Create())
                {
                    Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
                    encryptor.Key = pdb.GetBytes(32);
                    encryptor.IV = pdb.GetBytes(16);
                    using (MemoryStream ms = new MemoryStream())
                    {
                        using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateEncryptor(), CryptoStreamMode.Write))
                        {
                            cs.Write(clearBytes, 0, clearBytes.Length);
                            cs.Close();
                        }
                        clearText = Convert.ToBase64String(ms.ToArray());
                    }
                }
                return clearText;
            }
            catch
            {
                return null;
            }
        }
       
        private string Decrypt(string cipherText)
        {
            try
            {
                string EncryptionKey = "MAKV2SPBNI99212";
                byte[] cipherBytes = Convert.FromBase64String(cipherText);
                using (Aes encryptor = Aes.Create())
                {
                    Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
                    encryptor.Key = pdb.GetBytes(32);
                    encryptor.IV = pdb.GetBytes(16);
                    using (MemoryStream ms = new MemoryStream())
                    {
                        using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateDecryptor(), CryptoStreamMode.Write))
                        {
                            cs.Write(cipherBytes, 0, cipherBytes.Length);
                            cs.Close();
                        }
                        cipherText = Encoding.Unicode.GetString(ms.ToArray());
                    }
                }
                return cipherText;
            }
            catch
            {
                return null;
            }
        }
        public void refreshdata()
        {
            try
            {
                System.Data.DataTable dt_Final = new System.Data.DataTable();
                dt_Final.Columns.Add("Country_Id");
                dt_Final.Columns.Add("Country_Name");
                dt_Final.Rows.Add("0", "--All--");
                SqlConnection con = new SqlConnection(conString);
                con.Open();
                SqlCommand cmd = new SqlCommand("ARC_SP_GetCountries", con);
                cmd.CommandType = CommandType.StoredProcedure;
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                System.Data.DataTable dt = new System.Data.DataTable();
                sda.Fill(dt);

                foreach (DataRow d in dt.Rows)
                {
                    dt_Final.ImportRow(d);
                }
                //cmb_cntry.ValueMember = "Country_Id";
                //cmb_cntry.DisplayMember = "Country_Name";
                //cmb_cntry.DataSource = dt_Final;

                System.Data.DataTable dt_Final1 = new System.Data.DataTable();
                dt_Final1.Columns.Add("Product_ID");
                dt_Final1.Columns.Add("Product_name");
                dt_Final1.Rows.Add("0", "--All--");
                cmd = new SqlCommand("ARC_SP_GetProducts", con);
                cmd.CommandType = CommandType.StoredProcedure;
                sda = new SqlDataAdapter(cmd);
                dt = new System.Data.DataTable();
                sda.Fill(dt);
                foreach (DataRow d in dt.Rows)
                {
                    dt_Final1.ImportRow(d);
                }
                //cmb_Prdt.ValueMember = "Product_ID";
                //cmb_Prdt.DisplayMember = "Product_name";
                //cmb_Prdt.DataSource = dt_Final1;
                con.Close();
            }
            catch
            {

            }

        }
        private void btnAccountAdd_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(conString);
            try
            {
                string strAccountNumber = txtAccountNumber.Text.ToString();
                string Reconname = cbRecon.Text.ToString();
                if (Reconname.Trim() != "")
                {
                    if (strAccountNumber.Trim() != "" && Reconname.Trim() != "")
                    {
                        string strQurey = "if not exists (select From_Account_Number from ARC_Recon_Account_Nmuber where Recon_Name='" + Reconname + "' and From_Account_Number='" + strAccountNumber + "' and To_Account_Number='" + txtToAccountNumber.Text + "')";
                        strQurey = strQurey + " insert into ARC_Recon_Account_Nmuber(Recon_Name,From_Account_Number,To_Account_Number) values('" + Reconname + "','" + strAccountNumber + "','" + txtToAccountNumber.Text + "')";
                        con.Close();
                        con.Open();
                        SqlCommand cmd = new SqlCommand(strQurey, con);
                        int insval = cmd.ExecuteNonQuery();
                        con.Close();
                        if (insval > 0)
                        {
                            MessageBox.Show("Account Number Added Successfully  ...!");
                            txtAccountNumber.Text = "";
                            txtToAccountNumber.Text = "";
                            LoadAccountNumber();
                        }
                        else
                        {
                            MessageBox.Show("Account Number Already Exists ...!");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Please Enter the From Account Number ...!");
                    }
                }
                else
                {
                    MessageBox.Show("Please Select the From Recon ...!");
                }

            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                con.Close();
            }
        }
        public void LoadAccountNumber()
        {
            SqlConnection con = new SqlConnection(conString);
            try
            {
                dgvAccountNumber.Visible = true;
                con.Close();
                con.Open();
                SqlCommand cmd = new SqlCommand("ARC_SP_Recon_Account_Number", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Recon_name", cbRecon.Text.ToString());
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                System.Data.DataTable dtAccount = new System.Data.DataTable();
                da.Fill(dtAccount);
                con.Close();
                dgvAccountNumber.DataSource = dtAccount;
                dgvAccountNumber.Columns[0].Width = 200;
                dgvAccountNumber.Columns[1].Width = 200;
                dgvAccountNumber.Width = 445;
                dgvAccountNumber.Height = 350;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                con.Close();
            }
        }

        private void cbRecon_SelectedIndexChanged(object sender, EventArgs e)
        {
            txtAccountNumber.Text = "";
            txtToAccountNumber.Text = "";
            LoadAccountNumber();
        }

        private void btnAccountNumberDelete_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(conString);
            try
            {
                string strAccountNumber = txtAccountNumber.Text.ToString();
                string Reconname = cbRecon.Text.ToString();
                if (Reconname.Trim() != "")
                {
                    if (strAccountNumber.Trim() != "")
                    {
                        string strQurey = "if exists (select From_Account_Number from ARC_Recon_Account_Nmuber where Recon_Name='" + Reconname + "' and From_Account_Number='" + strAccountNumber + "' and To_Account_Number='" + txtToAccountNumber.Text + "')";
                        strQurey = strQurey + " Delete ARC_Recon_Account_Nmuber where Recon_Name='" + Reconname + "' and From_Account_Number='" + strAccountNumber + "' and To_Account_Number='" + txtToAccountNumber.Text + "'";
                        con.Close();
                        con.Open();
                        SqlCommand cmd = new SqlCommand(strQurey, con);
                        int insval = cmd.ExecuteNonQuery();
                        con.Close();
                        if (insval > 0)
                        {
                            MessageBox.Show("Account Number Added Successfully  ...!");
                            txtAccountNumber.Text = "";
                            txtToAccountNumber.Text = "";
                            LoadAccountNumber();
                        }
                        else
                        {
                            MessageBox.Show("Account Number not exists to delete ...!");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Please Enter the From Account Number ...!");
                    }
                }
                else
                {
                    MessageBox.Show("Please Select the From Recon ...!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                con.Close();
            }

        }

        private void lnk_Logout_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            foreach (var p in System.Diagnostics.Process.GetProcessesByName("OpenSpan.Runtime"))
            {
                p.Kill();
            }

            foreach (var p in System.Diagnostics.Process.GetProcessesByName("ARC_Application"))
            {
                p.Kill();
            }
            this.Close();
            MessageBox.Show("You Have LogOut Successfully");
        }

        private void Ref_Click(object sender, EventArgs e)
        {
            Dashboard_Config dashForm = new Dashboard_Config();
            dashForm.TopLevel = false;
            //dashForm.AutoScroll = true;
            dashboard_panel.Controls.Add(dashForm);
            dashForm.Show();

            Admin_Config adminForm = new Admin_Config();
            adminForm.TopLevel = false;
            //adminForm.AutoScroll = true;
            admin_panel.Controls.Add(adminForm);
            adminForm.Show();
            Total_count();

        }

        public void Total_count()
        {

            SqlConnection con = new SqlConnection(conString);
            con.Open();
            SqlCommand com = new SqlCommand("select count (*) as Total from ARC_Recon_Master", con);
            com.CommandType = CommandType.Text;
            SqlDataReader dr = com.ExecuteReader();
            while (dr.Read())
            {
                if (dr.HasRows == true)
                {
                    Total = (int)dr["Total"];
                }
            }
            con.Close();
            con.Open();
            com = new SqlCommand("select count (*) as Completed from ARC_Recon_Master where Is_Recon_Completed= 'true'", con);
            com.CommandType = CommandType.Text;
            dr = com.ExecuteReader();
            while (dr.Read())
            {
                if (dr.HasRows == true)
                {
                    Completed = (int)dr["Completed"];
                }
            }
            con.Close();
            //lbl_cnt.Text = Total.ToString();
            //lbl_com_cnt.Text = Completed.ToString();
            //lbl_pen_cnt.Text = (Total - Completed).ToString();
        }
        public void LoadHolidayRecon()
        {
            try
            {
                Hashtable hat = new Hashtable();
                System.Data.DataTable dt_Final = new System.Data.DataTable();
                dt_Final.Columns.Add("Country_Id");
                dt_Final.Columns.Add("Country_Name");
                dt_Final.Rows.Add("0", "--All--");

                System.Data.DataTable dt = das.Select_Table("ARC_SP_GetCountries", hat, "sp");

                foreach (DataRow d in dt.Rows)
                {
                    dt_Final.ImportRow(d);
                }
                cbHLCountry.ValueMember = "Country_Id";
                cbHLCountry.DisplayMember = "Country_Name";
                cbHLCountry.DataSource = dt_Final;


                System.Data.DataTable dt_Final1 = new System.Data.DataTable();
                dt_Final1.Columns.Add("Product_ID");
                dt_Final1.Columns.Add("Product_name");
                dt_Final1.Rows.Add("0", "--All--");

                dt = das.Select_Table("ARC_SP_GetProducts", hat, "sp");
                foreach (DataRow d in dt.Rows)
                {
                    dt_Final1.ImportRow(d);
                }
                cbHLProduct.ValueMember = "Product_ID";
                cbHLProduct.DisplayMember = "Product_name";
                cbHLProduct.DataSource = dt_Final1;


                System.Data.DataTable dt_Final2 = new System.Data.DataTable();
                dt_Final2.Columns.Add("recon_name");
                dt_Final2.Columns.Add("Recon_Id");
                dt_Final2.Rows.Add("-- Select --", "0");
                dt = das.Select_Table("select recon_name,Recon_Id from Arc_Recon_master where is_active = 1 order by recon_name", hat, "Text");

                foreach (DataRow d in dt.Rows)
                {
                    dt_Final2.ImportRow(d);
                }
                cbHLRecon.ValueMember = "Recon_Id";
                cbHLRecon.DisplayMember = "recon_name";
                cbHLRecon.DataSource = dt_Final2;
            }
            catch
            {

            }
        }
        private void cbReconFilter_SelectIndexChanges(object sender, EventArgs e)
        {
            try
            {
                ClearHolidaySettings();
                Hashtable hat = new Hashtable();
                i = cbHLCountry.SelectedIndex;
                j = cbHLProduct.SelectedIndex;
                selectedcountry = this.cbHLCountry.GetItemText(this.cbHLCountry.SelectedItem);
                selectedProduct = this.cbHLProduct.GetItemText(this.cbHLProduct.SelectedItem);

                string strfilterquery = "";
                if (i > 0)
                {
                    strfilterquery = " where Country='" + selectedcountry + "'";
                }
                if (j > 0)
                {
                    if (strfilterquery.Trim() != "")
                    {
                        strfilterquery = strfilterquery + " and Team='" + selectedProduct + "'";
                    }
                    else
                    {
                        strfilterquery = " where Team='" + selectedProduct + "'";
                    }
                }

                System.Data.DataTable dt_Final2 = new System.Data.DataTable();
                dt_Final2.Columns.Add("recon_name");
                dt_Final2.Columns.Add("Recon_Id");
                dt_Final2.Rows.Add("-- Select --", "0");
                dt = das.Select_Table("select recon_name,Recon_Id from Arc_Recon_master " + strfilterquery + " order by recon_name", hat, "Text");

                foreach (DataRow d in dt.Rows)
                {
                    dt_Final2.ImportRow(d);
                }
                cbHLRecon.ValueMember = "Recon_Id";
                cbHLRecon.DisplayMember = "recon_name";
                cbHLRecon.DataSource = dt_Final2;
            }
            catch (Exception ex)
            {

            }
        }

        public void ClearHolidaySettings()
        {
            cbHLLastTransactionDate.Text = "0";

            cbSatFileAvailable.Checked = false;
            cbSatFileRun.Checked = false;

            cbSunFileAvailable.Checked = false;
            cbSunReconRun.Checked = false;

            cbHolidayReconRun.Checked = false;
            cbHolidayFileAvailable.Checked = false;

            cbAlternateWeek.Checked = false;
            cbAlternateSatFileAvailable.Checked = false;
            cbAlternateSunFileAvailable.Checked = false;
        }

        private void btnHLSave_Click(object sender, EventArgs e)
        {
            try
            {
                int j = cbHLRecon.SelectedIndex;
                if (j > 0)
                {
                    string strReconId = this.cbHLRecon.GetItemText(this.cbHLRecon.SelectedValue);
                    string strReconName = this.cbHLRecon.GetItemText(this.cbHLRecon.SelectedText);

                    Hashtable hat = new Hashtable();

                    string strquery = "select * from arc_scope_baseline where recon_id='" + strReconId + "'";
                    System.Data.DataTable dtReconHoidayStatus = das.Select_Table(strquery, hat, "Text");

                    if (dtReconHoidayStatus.Rows.Count > 0)
                    {
                        string LastTransaction = cbHLLastTransactionDate.Text.ToString();

                        if (LastTransaction.Trim() == "")
                        {
                            MessageBox.Show("Please enter the Last transaction date");
                            return;
                        }

                        string IsSat = "0";
                        string IsSun = "0";
                        string IsHoliday = "0";
                        string FileSat = "0";
                        string FileSun = "0";
                        string FileHoliday = "0";
                        string alternatweek = "0";
                        string alternatesatfile = "0";
                        string alternatesunfile = "0";

                        if (cbAlternateWeek.Checked == true)
                        {
                            alternatweek = "1";
                        }
                        else
                        {
                            alternatweek = "0";
                        }

                        if (cbSatFileRun.Checked == true)
                        {
                            IsSat = "1";
                        }
                        else
                        {
                            IsSat = "0";
                        }

                        if (cbSatFileAvailable.Checked == true)
                        {
                            FileSat = "1";
                        }
                        else
                        {
                            FileSat = "0";
                        }

                        if (cbSunReconRun.Checked == true)
                        {
                            IsSun = "1";
                        }
                        else
                        {
                            IsSun = "0";
                        }

                        if (cbSunFileAvailable.Checked == true)
                        {
                            FileSun = "1";
                        }
                        else
                        {
                            FileSun = "0";
                        }

                        if (cbHolidayReconRun.Checked == true)
                        {
                            IsHoliday = "1";
                        }
                        else
                        {
                            IsHoliday = "0";
                        }

                        if (cbHolidayFileAvailable.Checked == true)
                        {
                            FileHoliday = "1";
                        }
                        else
                        {
                            FileHoliday = "0";
                        }

                        if (cbAlternateSatFileAvailable.Checked == true)
                        {
                            alternatesatfile = "1";
                        }
                        else
                        {
                            alternatesatfile = "0";
                        }

                        if (cbAlternateSunFileAvailable.Checked == true)
                        {
                            alternatesunfile = "1";
                        }
                        else
                        {
                            alternatesunfile = "0";
                        }

                        string strQuery = "delete from ARC_Holiday_Recon_Run_Status where recon_id='" + strReconId + "' ";
                        int insquery = das.ins_upd_fun(strQuery, hat, "Text");

                        for (int i = 0; i < dtReconHoidayStatus.Rows.Count; i++)
                        {
                            string team = dtReconHoidayStatus.Rows[i]["Team"].ToString();
                            string couName = dtReconHoidayStatus.Rows[i]["Country_Name"].ToString();
                            string Recon = dtReconHoidayStatus.Rows[i]["Recon"].ToString();
                            string REportSouFileName = dtReconHoidayStatus.Rows[i]["Report_Source_File_Name"].ToString();
                            string FTPFILENAme = dtReconHoidayStatus.Rows[i]["FTP_File_Format_Name"].ToString();
                            string CountID = dtReconHoidayStatus.Rows[i]["Country_ID"].ToString();
                            string ProduID = dtReconHoidayStatus.Rows[i]["Product_Id"].ToString();
                            string reconId = dtReconHoidayStatus.Rows[i]["Recon_Id"].ToString();


                            strQuery = " insert into ARC_Holiday_Recon_Run_Status(Country_id,Recon_id,Product_id,Country_name,Team,Recon,Report_Source_File_Name,FTP_File_Format_Name,is_sat,is_sun,is_holiday,is_File_Available_holiday,Is_File_Available_Sat,Is_File_Available_Sun,Last_Trasaction,is_Alternate_Week,Is_Alternate_Sat_file_available,Is_Alternate_Sun_file_available)";
                            strQuery = strQuery + " values('" + CountID + "','" + reconId + "','" + ProduID + "','" + couName + "','" + team + "','" + Recon + "','" + REportSouFileName + "','" + FTPFILENAme + "','" + IsSat + "','" + IsSun + "','" + IsHoliday + "','" + FileHoliday + "','" + FileSat + "','" + FileSun + "','" + LastTransaction + "','" + alternatweek + "','" + alternatesatfile + "','" + alternatesunfile + "')";
                            insquery = das.ins_upd_fun(strQuery, hat, "Text");
                        }

                        ClearHolidaySettings();
                        MessageBox.Show("Recon Settings saved successfully.");
                    }
                    else
                    {
                        MessageBox.Show("File details not found for that Recon.");
                    }
                }
                else
                {
                    MessageBox.Show("Please select the Recon and then Proceed");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void btnHLDelete_Click(object sender, EventArgs e)
        {
            try
            {
                int j = cbHLRecon.SelectedIndex;
                if (j > 0)
                {
                    string strReconId = this.cbHLRecon.GetItemText(this.cbHLRecon.SelectedValue);
                    string strReconName = this.cbHLRecon.GetItemText(this.cbHLRecon.SelectedText);

                    Hashtable hat = new Hashtable();

                    string strQuery = "delete from ARC_Holiday_Recon_Run_Status where recon_id='" + strReconId + "' ";
                    int insquery = das.ins_upd_fun(strQuery, hat, "Text");

                    ClearHolidaySettings();
                    MessageBox.Show("Recon Settings Deleted successfully.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void cbHLRecon_SelectIndexChanges(object sender, EventArgs e)
        {
            try
            {
                Hashtable hat = new Hashtable();
                ClearHolidaySettings();
                i = cbHLRecon.SelectedIndex;
                if (i > 0)
                {
                    string strReconId = this.cbHLRecon.GetItemText(this.cbHLRecon.SelectedValue);
                    string strReconName = this.cbHLRecon.GetItemText(this.cbHLRecon.SelectedText);
                    System.Data.DataTable dtRecon = das.Select_Table("select * from ARC_Holiday_Recon_Run_Status where recon_id='" + strReconId + "'", hat, "Text");

                    if (dtRecon.Rows.Count > 0)
                    {
                        bool IsSat = Convert.ToBoolean(dtRecon.Rows[0]["is_sat"]);
                        bool IsSun = Convert.ToBoolean(dtRecon.Rows[0]["is_sun"]);
                        bool IsHoliday = Convert.ToBoolean(dtRecon.Rows[0]["is_Holiday"]);

                        bool IsFileAvailableSat = Convert.ToBoolean(dtRecon.Rows[0]["is_file_available_Sat"]);
                        bool IsFileAvailableSun = Convert.ToBoolean(dtRecon.Rows[0]["is_file_available_Sun"]);
                        bool IsFileAvailableHoliday = Convert.ToBoolean(dtRecon.Rows[0]["is_file_available_holiday"]);

                        string strval = dtRecon.Rows[0]["is_alternate_week"].ToString();

                        bool IsAlternateweek = false;
                        if (strval != "")
                        {
                            IsAlternateweek = Convert.ToBoolean(strval);
                        }

                        bool IsAlternateSatFile = false;
                        strval = dtRecon.Rows[0]["Is_Alternate_Sat_file_available"].ToString();
                        if (strval != "")
                        {
                            IsAlternateSatFile = Convert.ToBoolean(strval);
                        }

                        bool IsAlternateSunFile = false;
                        strval = dtRecon.Rows[0]["Is_Alternate_Sun_file_available"].ToString();
                        if (strval != "")
                        {
                            IsAlternateSunFile = Convert.ToBoolean(strval);
                        }

                        string LatsTrasaction = dtRecon.Rows[0]["Last_trasaction"].ToString();
                        if (LatsTrasaction.Trim() != "")
                        {
                            cbHLLastTransactionDate.Text = LatsTrasaction;
                        }


                        if (IsSat == true)
                        {
                            cbSatFileRun.Checked = true;
                        }

                        if (IsSun == true)
                        {
                            cbSunReconRun.Checked = true;
                        }

                        if (IsHoliday == true)
                        {
                            cbHolidayReconRun.Checked = true;
                        }

                        if (IsFileAvailableSat == true)
                        {
                            cbSatFileAvailable.Checked = true;
                        }

                        if (IsFileAvailableSun == true)
                        {
                            cbSunFileAvailable.Checked = true;
                        }

                        if (IsFileAvailableHoliday == true)
                        {
                            cbHolidayFileAvailable.Checked = true;
                        }

                        if (IsAlternateweek == true)
                        {
                            cbAlternateWeek.Checked = true;
                        }

                        if (IsAlternateSatFile == true)
                        {
                            cbAlternateSatFileAvailable.Checked = true;
                        }

                        if (IsAlternateSunFile == true)
                        {
                            cbAlternateSunFileAvailable.Checked = true;
                        }
                    }
                    else
                    {
                        // MessageBox.Show("Recon Details not Availble for Holiday Logic");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
    }
}