﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;
using System.Data.OleDb;
using System.Globalization;
using System.Diagnostics;
using System.Collections;
using System.Configuration;
using Excel = Microsoft.Office.Interop.Excel;

namespace ARC_Application
{
    class CCMS_Formatting
    {
        public void CCMS_Formatting_Logic()
        {
            Microsoft.Office.Interop.Outlook.Application app = null;
            Microsoft.Office.Interop.Outlook._NameSpace ns = null;
            double ExchangeRate = 0;

            Microsoft.Office.Interop.Outlook.MAPIFolder inboxFolder = null;
            Microsoft.Office.Interop.Outlook.MAPIFolder subFolder1 = null;

            app = new Microsoft.Office.Interop.Outlook.Application();
            ns = app.GetNamespace("MAPI");
            ns.Logon(null, null, false, false);
            StringBuilder builder = new StringBuilder();
            inboxFolder = ns.GetDefaultFolder(Microsoft.Office.Interop.Outlook.OlDefaultFolders.olFolderInbox);
            Microsoft.Office.Interop.Outlook.Accounts accounts = app.Session.Accounts;
            foreach (Microsoft.Office.Interop.Outlook.Account account in accounts)
            {
                builder.AppendFormat("{0}", account.SmtpAddress);
            }
            subFolder1 = inboxFolder.Folders["DataUpload-Retail, GRU"];
            foreach (Microsoft.Office.Interop.Outlook.MailItem mailItem in subFolder1.Items)//.Restrict("[MessageClass] = 'IPM.Schedule.Meeting.Request'")
            {
                var attachments = mailItem.Attachments;
                var mailbody = mailItem.Body;

                string[] bodymai = System.Text.RegularExpressions.Regex.Split(mailbody.ToString(), @"\s{2,}");
                //lines[0].Split(new char[] { ',' });
                var Subject = mailItem.Subject;
                //string mailadd = mailitem.senderemailaddress;
                for (int i = 0; i <= 15; i++)
                {
                    if (bodymai[i].ToString().Contains("Exchange rate"))
                    {
                        string a = bodymai[i];
                        string[] b = a.Split(':');
                        ExchangeRate = Convert.ToDouble(b[1].ToString());
                    }
                }
            }
            
            DataTable dtM01 = new DataTable();
            DataTable dtM02 = new DataTable();
            DataTable final = new DataTable();
            for (int k = 0; k <= 1; k++)
            {
                if (k == 0)
                {
                    dtM01 = check(ExchangeRate, k);

                }
                else
                {
                    dtM02 = GetDataSourceFromFile(k);
                }

            }
            final.Merge(dtM01);
            final.Merge(dtM02);
            ExportToExcel(final);
        }

        private void _Retail_Malaysia_CCMS_CSW64D_nd65_Merge_Load(object sender, EventArgs e)
        {
            Microsoft.Office.Interop.Outlook.Application app = null;
            Microsoft.Office.Interop.Outlook._NameSpace ns = null;
            double ExchangeRate = 0;

            //Microsoft.Office.Interop.Outlook.PostItem item = null;
            Microsoft.Office.Interop.Outlook.MAPIFolder inboxFolder = null;
            Microsoft.Office.Interop.Outlook.MAPIFolder subFolder1 = null;
            // Microsoft.Office.Interop.Outlook.MAPIFolder subFolder2 = null;
            // Microsoft.Office.Interop.Outlook.MAPIFolder subFolder3 = null;

            app = new Microsoft.Office.Interop.Outlook.Application();
            ns = app.GetNamespace("MAPI");
            ns.Logon(null, null, false, false);
            StringBuilder builder = new StringBuilder();
            inboxFolder = ns.GetDefaultFolder(Microsoft.Office.Interop.Outlook.OlDefaultFolders.olFolderInbox);
            Microsoft.Office.Interop.Outlook.Accounts accounts = app.Session.Accounts;
            foreach (Microsoft.Office.Interop.Outlook.Account account in accounts)
            {
                builder.AppendFormat("{0}", account.SmtpAddress);
            }
            subFolder1 = inboxFolder.Folders["DataUpload-Retail, GRU"];
            foreach (Microsoft.Office.Interop.Outlook.MailItem mailItem in subFolder1.Items)//.Restrict("[MessageClass] = 'IPM.Schedule.Meeting.Request'")
            {
                var attachments = mailItem.Attachments;
                var mailbody = mailItem.Body;

                string[] bodymai = System.Text.RegularExpressions.Regex.Split(mailbody.ToString(), @"\s{2,}");
                //lines[0].Split(new char[] { ',' });
                var Subject = mailItem.Subject;
                //string mailadd = mailitem.senderemailaddress;
                for (int i = 0; i <= 15; i++)
                {
                    if (bodymai[i].ToString().Contains("Exchange rate"))
                    {
                        string a = bodymai[i];
                        string[] b = a.Split(':');
                        ExchangeRate = Convert.ToDouble(b[1].ToString());
                    }
                }
            }
            DataTable dtM01 = new DataTable();
            DataTable dtM02 = new DataTable();
            DataTable final = new DataTable();
            for (int k = 0; k <= 1; k++)
            {
                if (k == 0)
                {
                    dtM01 = check(ExchangeRate, k);

                }
                else
                {
                    dtM02 = GetDataSourceFromFile(k);
                }

            }
            final.Merge(dtM01);
            final.Merge(dtM02);
            ExportToExcel(final);
        }

        private void ExportToExcel(DataTable tbl)
        {
            string excelFilePath = @"C:\ARC\Docs\Direct Upload Flow\Samples\Retail_Mal_CCMS\Input\Excel.xlsx";
            try
            {
                if (tbl == null || tbl.Columns.Count == 0)
                    throw new Exception("ExportToExcel: Null or empty input table!\n");

                // load excel, and create a new workbook
                var excelApp = new Microsoft.Office.Interop.Excel.Application();
                excelApp.Workbooks.Add();

                // single worksheet
                Microsoft.Office.Interop.Excel._Worksheet workSheet = (Excel.Worksheet)excelApp.ActiveSheet;
                //Microsoft.Office.Interop.Excel.Range range;
                // column headings
                for (var i = 0; i < tbl.Columns.Count; i++)
                {
                    workSheet.Cells[1, i + 1] = tbl.Columns[i].ColumnName;
                }

                // rows
                for (var i = 0; i < tbl.Rows.Count; i++)
                {
                    // to do: format datetime values before printing
                    for (var j = 0; j < tbl.Columns.Count; j++)
                    {
                        workSheet.Cells[i + 2, j + 1] = tbl.Rows[i][j];

                    }
                }

                // check file path
                if (!string.IsNullOrEmpty(excelFilePath))
                {
                    try
                    {
                        /*workSheet.Columns[03].ColumnWidth = 20;
                        workSheet.Columns[20].ColumnWidth = 20;
                        workSheet.Columns[14].ColumnWidth = 20;
                        workSheet.Columns[15].ColumnWidth = 20;
                        workSheet.SaveAs(excelFilePath);
                        excelApp.Quit();
                        MessageBox.Show("Excel file saved!");
                        File.Move(excelFilePath, Path.ChangeExtension(excelFilePath, ".csv"));*/
                    }
                    catch (Exception ex)
                    {
                        throw new Exception("ExportToExcel: Excel file could not be saved! Check filepath.\n"
                                            + ex.Message);
                    }
                }
                else
                { // no file path is given
                    excelApp.Visible = true;
                }
            }
            catch (Exception ex)
            {
                throw new Exception("ExportToExcel: \n" + ex.Message);
            }
        }

        public void FileRename()
        {
            string dt = DateTime.Now.ToString("yyyyMMdd");
            String inputDirectoryPat = @"C:\ARC\Docs\Direct Upload Flow\Samples\Retail_Mal_CCMS\Input\";
            // string inputDirectoryPat = @"C:\ARC\Docs\Direct Upload Flow\Samples\Malaysia\";
            String inputFileNamePatter = @"*.csv";
            var files = @"C:\ARC\Docs\Direct Upload Flow\Samples\Retail_Mal_CCMS\Output\PSGL_289236_BRK_" + dt + ".csv";
            string[] inputFilePaths = Directory.GetFiles(inputDirectoryPat, inputFileNamePatter);
            foreach (var inputFilePath in inputFilePaths)
            {
                DirectoryInfo di = new DirectoryInfo(inputFilePath);

                Microsoft.Office.Interop.Excel.Application app = new Microsoft.Office.Interop.Excel.Application();
                Microsoft.Office.Interop.Excel.Workbook wb = app.Workbooks.Open(inputFilePath, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);

                // this does not throw exception if file doesnt exist
                File.Delete(files);

                wb.SaveAs(files, Microsoft.Office.Interop.Excel.XlFileFormat.xlCSVWindows, Type.Missing, Type.Missing, false, false, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlExclusive, Microsoft.Office.Interop.Excel.XlSaveConflictResolution.xlLocalSessionChanges, false, Type.Missing, Type.Missing, Type.Missing);

                wb.Close(false, Type.Missing, Type.Missing);

                app.Quit();
                File.Move(files, Path.ChangeExtension(files, ".txt"));
                Fileses();

            }

        }

        public void Fileses()
        {

            try
            {
                string path = @"C:\ARC\Docs\Direct Upload Flow\Samples\Retail_Mal_CCMS\Output";
                string destpath = @"C:\ARC\Docs\Direct Upload Flow\Samples\Retail_Mal_CCMS\Output\";
                string str = "";

                if (Directory.Exists(path))
                {
                    string[] files = System.IO.Directory.GetFiles(path);
                    string name = "";

                    for (int i = 0; i <= files.Length - 1; i++)
                    {
                        str = files[i];
                        name = Path.GetFileName(str);
                        string text = File.ReadAllText(str);
                        text = text.Replace(",", "|");
                        text = text.Replace("'", "");
                        File.WriteAllText(str, text);
                        // File.Copy(str, Path.ChangeExtension(destpath + name, ".tlm"));
                        File.Move(str, Path.ChangeExtension(destpath + name, ".tlm"));
                        str = "";
                        name = "";

                    }
                }
                else
                {
                    MessageBox.Show("Directory does not Exists");
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public DataTable check(double Rate, int k)
        {
            // double Rate = 4.4255;
            string fileName = @"C:\ARC\Docs\Direct Upload Flow\Samples\Retail_Mal_CCMS\Input\daily report 31 Jan 2017\CSW64D 310117.txt";
            // string fileName = @"C:\ARC\Docs\Direct Upload Flow\Samples\Retail_Mal_CCMS\Input\daily report 31 Jan 2017\CSW65D 310117.txt";
            string filePath1 = @"C:\ARC\Docs\Direct Upload Flow\Samples\Retail_Mal_CCMS\Input\ACCOUNT%20BALANCE%20EXTENDED%20-%20CONSOLIDATED.xls";
            string filePath2 = @"C:\ARC\ccms\MANUAL RECON QUERY OF OPEN ITEM.xls";
            DataTable dtexcel = new DataTable();
            DataTable dtfinal = new DataTable();
            string Opbal = null;
            string Date = null;
            string Amount1 = null;
            string Date1 = null;
            string Dates = DateTime.Today.AddDays(-1).ToString("M/d/yyyy");
            string Damo = DateTime.Today.AddDays(-1).ToString("dd/MM");
            bool hasHeaders = true;
            string HDR = hasHeaders ? "Yes" : "No";
            string strConn;
            if (filePath1.Substring(filePath1.LastIndexOf('.')).ToLower() == ".xlsx")
                strConn = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + filePath1 + ";Extended Properties=\"Excel 12.0;HDR=" + HDR + ";IMEX=0\"";
            else
                strConn = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + filePath1 + ";Extended Properties=\"Excel 8.0;HDR=" + HDR + ";IMEX=0\"";
            string strConn1;
            if (filePath2.Substring(filePath2.LastIndexOf('.')).ToLower() == ".xlsx")
                strConn1 = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + filePath2 + ";Extended Properties=\"Excel 12.0;HDR=" + HDR + ";IMEX=0\"";
            else
                strConn1 = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + filePath2 + ";Extended Properties=\"Excel 8.0;HDR=" + HDR + ";IMEX=0\"";
            OleDbConnection conn = new OleDbConnection(strConn);
            conn.Close();
            conn.Open();
            DataTable schemaTable = conn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, new object[] { null, null, null, "TABLE" });
            DataRow schemaRow = schemaTable.Rows[0];
            string sheet = schemaRow["TABLE_NAME"].ToString();
            if (!sheet.EndsWith("_"))
            {
                string query = "SELECT  * FROM [" + sheet + "]";
                OleDbDataAdapter daexcel = new OleDbDataAdapter(query, conn);
                dtexcel.Locale = CultureInfo.CurrentCulture;
                daexcel.Fill(dtexcel);
                conn.Close();
                conn = new OleDbConnection(strConn1);
                conn.Open();
                DataTable schemaTable1 = conn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, new object[] { null, null, null, "TABLE" });
                DataRow schemaRow1 = schemaTable.Rows[0];
                string sheet1 = schemaRow["TABLE_NAME"].ToString();
                if (!sheet1.EndsWith("_"))
                {
                    string query1 = "SELECT  * FROM [" + sheet + "]";
                    OleDbDataAdapter daexcel1 = new OleDbDataAdapter(query1, conn);
                    dtfinal.Locale = CultureInfo.CurrentCulture;
                    daexcel1.Fill(dtfinal);
                    for (int j = 0; j <= dtexcel.Rows.Count - 1; j++)
                    {
                        string asa = dtexcel.Rows[j][4].ToString();

                        if (dtexcel.Rows[j][0].ToString() == "CA-MY-CBD-288894-MYR" && asa.Contains(Dates))
                        {
                            Opbal = dtexcel.Rows[j][5].ToString();
                            Date = DateTime.Today.AddDays(-1).ToString("M/d/yyyy");
                        }
                    }
                    for (int j = 0; j <= dtfinal.Rows.Count - 1; j++)
                    {
                        string asa = dtfinal.Rows[j][14].ToString();

                        if (dtfinal.Rows[j][0].ToString() == "CA-MY-CBD-288894-MYR" && asa.Contains(Damo))
                        //if (asa.Contains(Dates))
                        {
                            if (asa.Contains(" ENT - REVD MC"))
                            {
                                Amount1 = dtfinal.Rows[j][8].ToString();
                                Date1 = dtfinal.Rows[j][14].ToString();
                            }
                        }
                    }
                }
                conn.Close();
            }
            DataTable dt = new DataTable("CreditCards");
            DataTable dt1 = new DataTable();
            string[] columns = null;
            var lines = File.ReadAllLines(fileName);
            StreamReader objReader;
            objReader = new StreamReader(fileName);

            // assuming the first row contains the columns information
            if (lines.Count() > 0)
            {
                columns = lines[0].Split(new char[] { ',' });

                foreach (var column in columns)
                    dt.Columns.Add(column);
            }

            // reading rest of the data
            for (int i = 1; i < lines.Count(); i++)
            {
                DataRow dr = dt.NewRow();
                DataRow dr1 = dt.NewRow();
                string values = objReader.ReadLine();

                if (values.Contains("PAN:"))
                {
                    for (int j = 0; j < values.Count() && j < columns.Count(); j++)
                        dr[j] = values;

                    dt.Rows.Add(dr);
                }
                if (values.Contains("AMOUNTS:"))
                {
                    for (int j = 0; j < values.Count() && j < columns.Count(); j++)
                        dr1[j] = values;

                    dt.Rows.Add(dr1);
                }
            }
            dt1.Columns.Add("PAN");
            dt1.Columns.Add("Amount");
            for (int i = 0; i <= dt.Rows.Count - 1; i++)
            {
                dt1.Rows.Add();
                if (dt.Rows[i][0].ToString().Contains("PAN:"))
                {
                    dt1.Rows[i][0] = dt.Rows[i][0].ToString();
                }
                else if (dt.Rows[i][0].ToString().Contains("AMOUNTS:"))
                {
                    dt1.Rows[i][1] = dt.Rows[i][0].ToString();
                }
            }
            DataTable tdt1 = new DataTable();
            DataTable tdt2 = new DataTable();
            DataTable tdt3 = new DataTable();
            tdt1.Columns.Add("PAN");
            tdt2.Columns.Add("Amount");
            tdt3.Columns.Add("PAN");
            tdt3.Columns.Add("Amount");
            for (int i = 0; i <= dt1.Rows.Count - 1; i++)
            {
                tdt1.Rows.Add();
                if (dt1.Rows[i][0].ToString() != "")
                {
                    tdt1.Rows[i][0] = dt1.Rows[i][0].ToString();
                }
            }
            for (int i = 0; i <= dt1.Rows.Count - 1; i++)
            {
                tdt2.Rows.Add();
                if (dt1.Rows[i][1].ToString() != "")
                {
                    tdt2.Rows[i][0] = dt1.Rows[i][1].ToString();
                }
            }
            for (int i = dt1.Rows.Count - 1; i >= 0; i--)
            {
                if (tdt1.Rows[i][0] == DBNull.Value)
                    tdt1.Rows[i].Delete();
            }

            for (int i = dt1.Rows.Count - 1; i >= 0; i--)
            {
                if (tdt2.Rows[i][0] == DBNull.Value)
                    tdt2.Rows[i].Delete();
            }
            for (int i = 0; i <= tdt1.Rows.Count - 1; i++)
            {
                tdt3.Rows.Add();
                tdt3.Rows[i][0] = tdt1.Rows[i][0].ToString();
                tdt3.Rows[i][1] = tdt2.Rows[i][0].ToString();

            }
            DataTable dtt = new DataTable();
            dtt.Columns.Add("OPBAL");
            dtt.Columns.Add("OPBALCY");
            dtt.Columns.Add("OPBALDATE");
            dtt.Columns.Add("OPBALTP");
            dtt.Columns.Add("MTYPE");
            dtt.Columns.Add("SIDE");
            dtt.Columns.Add("STMTNO");
            dtt.Columns.Add("STMTPG");
            dtt.Columns.Add("SUBACC");
            dtt.Columns.Add("Amount");
            dtt.Columns.Add("SIGN");
            dtt.Columns.Add("ENTRY DATE");
            dtt.Columns.Add("REFERENCE 1");
            dtt.Columns.Add("REFERENCE 2");
            dtt.Columns.Add("REFERENCE 3");
            dtt.Columns.Add("TRANSACTION CODE");
            dtt.Columns.Add("VALUE DATE");
            dtt.Columns.Add("CLBAL");
            dtt.Columns.Add("CLBALCY");
            dtt.Columns.Add("CLBALDATE");
            dtt.Columns.Add("CLBALTP");
            double sum = 0;
            for (int i = 0; i <= tdt3.Rows.Count - 1; i++)
            {
                double amt = 0;
                string[] val0 = System.Text.RegularExpressions.Regex.Split(tdt3.Rows[i][0].ToString(), @"\s{2,}");

                string[] val1 = System.Text.RegularExpressions.Regex.Split(tdt3.Rows[i][1].ToString(), @"\s{2,}");
                dtt.Rows.Add();

                string[] valu = val1[2].Split(new char[] { '-' });
                if (valu[1].ToString().Contains("458"))
                {
                    dtt.Rows[i][9] = valu[0];
                }
                else
                {
                    amt = Convert.ToDouble(valu[0].ToString());
                    dtt.Rows[i][9] = (amt * Rate).ToString();
                }
                dtt.Rows[i][13] = val0[1].Substring(4, 16); ;
                // dt.Rows[i][2] = valu[0];
                dtt.Rows[i][0] = dtt.Rows[i][17] = Opbal;
                dtt.Rows[i][1] = dtt.Rows[i][18] = "MYR";
                dtt.Rows[i][2] = dtt.Rows[i][19] = "";// Date; //change the date afterwords
                dtt.Rows[i][3] = dtt.Rows[i][20] = "F";
                dtt.Rows[i][4] = "";
                dtt.Rows[i][5] = "L";
                dtt.Rows[i][6] = "1";
                dtt.Rows[i][7] = "2";
                dtt.Rows[i][8] = "CAMYCBD303288894MYR-PSG";
                dtt.Rows[i][10] = "C";
                //dt1.Rows[i][11] = dt1.Rows[i][16] = dtexcel.Rows[i][14].ToString(); //Need to put value Date
                dtt.Rows[i][12] = "288894";
                //// dt.Rows[i][13] = acc;
                dtt.Rows[i][14] = "303-1323-288894-MYR-800-100-10";
                dtt.Rows[i][15] = "SPLT";
                sum += Convert.ToDouble(dtt.Rows[i][9].ToString());

            }
            DataRow newRow = dtt.NewRow();
            dtt.Rows.InsertAt(newRow, 0);
            for (int i = 0; i < 1; i++)
            {
                //string[] val = System.Text.RegularExpressions.Regex.Split(dt.Rows[i][0].ToString(), @"\s{2,}");               
                if (dtt.Rows[i][0].ToString() == "")
                {
                    //string[] valu = System.Text.RegularExpressions.Regex.Split(val[3].ToString(), @"{'-'}");
                    // string[] valu = val[3].Split(new char[] { '-' });
                    dtt.Rows[i][9] = Amount1;
                    dtt.Rows[i][13] = Date1;
                    // dt.Rows[i][2] = valu[0];
                    dtt.Rows[i][0] = dtt.Rows[i][17] = Opbal;//Amount;
                    dtt.Rows[i][1] = dtt.Rows[i][18] = "MYR";
                    dtt.Rows[i][2] = dtt.Rows[i][19] = Date; //change the date afterwords
                    dtt.Rows[i][3] = dtt.Rows[i][20] = "F";
                    dtt.Rows[i][4] = "";
                    dtt.Rows[i][5] = "L";
                    dtt.Rows[i][6] = "1";
                    dtt.Rows[i][7] = "2";
                    dtt.Rows[i][8] = "CAMYCBD303288894MYR-PSG";
                    dtt.Rows[i][10] = "D";
                    //dt1.Rows[i][11] = dt1.Rows[i][16] = dtexcel.Rows[i][14].ToString(); //Need to put value Date
                    dtt.Rows[i][12] = "288894";
                    //// dt.Rows[i][13] = acc;
                    dtt.Rows[i][14] = "303-1323-288894-MYR-800-100-10";
                    dtt.Rows[i][15] = "SPLT";
                }
            }
            DataRow newRow01 = dtt.NewRow();
            dtt.Rows.InsertAt(newRow01, dtt.Rows.Count + 1);
            double final = 10377.103675 - sum;
            if (final <= 0.05)
            {
                //Need to check 
                //for (int i = dtt.Rows.Count - 1; i >= dtt.Rows.Count; i--)
                //{
                //    dtt.Rows[i][9] = final;
                //    dtt.Rows[i][13] = "Succ";
                //}
            }
            return dtt;
        }

        public DataTable GetDataSourceFromFile(int k)
        {
            string fileName = @"C:\ARC\Docs\Direct Upload Flow\Samples\Retail_Mal_CCMS\Input\daily report 31 Jan 2017\CSW65D 310117.txt";
            string filePath1 = @"C:\ARC\Docs\Direct Upload Flow\Samples\Retail_Mal_CCMS\Input\ACCOUNT%20BALANCE%20EXTENDED%20-%20CONSOLIDATED.xls";
            string filePath2 = @"C:\ARC\ccms\MANUAL RECON QUERY OF OPEN ITEM.xls";
            DataTable dtexcel = new DataTable();
            DataTable dtfinal = new DataTable();
            string Amount = null;
            string Date = null;
            string Amount1 = null;
            string Date1 = null;
            string Dates = DateTime.Today.AddDays(-1).ToString("M/d/yyyy");
            string Damo = DateTime.Today.AddDays(-1).ToString("dd/MM");
            bool hasHeaders = true;
            string HDR = hasHeaders ? "Yes" : "No";
            string strConn;
            if (filePath1.Substring(filePath1.LastIndexOf('.')).ToLower() == ".xlsx")
                strConn = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + filePath1 + ";Extended Properties=\"Excel 12.0;HDR=" + HDR + ";IMEX=0\"";
            else
                strConn = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + filePath1 + ";Extended Properties=\"Excel 8.0;HDR=" + HDR + ";IMEX=0\"";
            string strConn1;
            if (filePath2.Substring(filePath2.LastIndexOf('.')).ToLower() == ".xlsx")
                strConn1 = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + filePath2 + ";Extended Properties=\"Excel 12.0;HDR=" + HDR + ";IMEX=0\"";
            else
                strConn1 = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + filePath2 + ";Extended Properties=\"Excel 8.0;HDR=" + HDR + ";IMEX=0\"";
            OleDbConnection conn = new OleDbConnection(strConn);
            // conn.Close();
            conn.Open();
            DataTable schemaTable = conn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, new object[] { null, null, null, "TABLE" });
            DataRow schemaRow = schemaTable.Rows[0];
            string sheet = schemaRow["TABLE_NAME"].ToString();
            if (!sheet.EndsWith("_"))
            {
                string query = "SELECT  * FROM [" + sheet + "]";
                OleDbDataAdapter daexcel = new OleDbDataAdapter(query, conn);
                dtexcel.Locale = CultureInfo.CurrentCulture;
                daexcel.Fill(dtexcel);
                conn.Close();
                conn = new OleDbConnection(strConn1);
                conn.Open();
                DataTable schemaTable1 = conn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, new object[] { null, null, null, "TABLE" });
                DataRow schemaRow1 = schemaTable.Rows[0];
                string sheet1 = schemaRow["TABLE_NAME"].ToString();
                if (!sheet1.EndsWith("_"))
                {
                    string query1 = "SELECT  * FROM [" + sheet + "]";
                    OleDbDataAdapter daexcel1 = new OleDbDataAdapter(query1, conn);
                    dtfinal.Locale = CultureInfo.CurrentCulture;
                    daexcel1.Fill(dtfinal);
                    for (int j = 0; j <= dtexcel.Rows.Count - 1; j++)
                    {
                        string asa = dtexcel.Rows[j][4].ToString();

                        if (dtexcel.Rows[j][0].ToString() == "CA-MY-CBD-288894-MYR" && asa.Contains(Dates))
                        {
                            Amount = dtexcel.Rows[j][5].ToString();
                            Date = DateTime.Today.AddDays(-1).ToString("M/d/yyyy");
                        }
                    }
                    for (int j = 0; j <= dtfinal.Rows.Count - 1; j++)
                    {
                        string asa = dtfinal.Rows[j][14].ToString();

                        if (dtfinal.Rows[j][0].ToString() == "CA-MY-CBD-288894-MYR" && asa.Contains(Damo))
                        //if (asa.Contains(Dates))
                        {
                            if (asa.Contains("ENT - REVD VS"))
                            {
                                Amount1 = dtfinal.Rows[j][8].ToString();
                                Date1 = DateTime.Today.AddDays(-1).ToString("M/d/yyyy");
                            }
                        }
                    }
                }
                conn.Close();
            }
            DataTable dt = new DataTable("CreditCards");
            string[] columns = null;
            var lines = File.ReadAllLines(fileName);
            StreamReader objReader;
            objReader = new StreamReader(fileName);

            // assuming the first row contains the columns information
            if (lines.Count() > 0)
            {
                columns = lines[0].Split(new char[] { ',' });

                foreach (var column in columns)
                    dt.Columns.Add(column);
            }

            // reading rest of the data
            for (int i = 1; i < lines.Count(); i++)
            {
                DataRow dr = dt.NewRow();
                string values = objReader.ReadLine();

                if (values.Contains("PAN:"))
                {
                    for (int j = 0; j < values.Count() && j < columns.Count(); j++)
                        dr[j] = values;

                    dt.Rows.Add(dr);
                }
            }
            DataTable dt1 = new DataTable();
            dt1.Columns.Add("OPBAL");
            dt1.Columns.Add("OPBALCY");
            dt1.Columns.Add("OPBALDATE");
            dt1.Columns.Add("OPBALTP");
            dt1.Columns.Add("MTYPE");
            dt1.Columns.Add("SIDE");
            dt1.Columns.Add("STMTNO");
            dt1.Columns.Add("STMTPG");
            dt1.Columns.Add("SUBACC");
            dt1.Columns.Add("Amount");
            dt1.Columns.Add("SIGN");
            dt1.Columns.Add("ENTRY DATE");
            dt1.Columns.Add("REFERENCE 1");
            dt1.Columns.Add("REFERENCE 2");
            dt1.Columns.Add("REFERENCE 3");
            dt1.Columns.Add("TRANSACTION CODE");
            dt1.Columns.Add("VALUE DATE");
            dt1.Columns.Add("CLBAL");
            dt1.Columns.Add("CLBALCY");
            dt1.Columns.Add("CLBALDATE");
            dt1.Columns.Add("CLBALTP");
            for (int i = 0; i <= dt.Rows.Count - 1; i++)
            {
                string[] val = System.Text.RegularExpressions.Regex.Split(dt.Rows[i][0].ToString(), @"\s{2,}");
                dt1.Rows.Add();
                if (val[1].Contains("PAN:"))
                {
                    //string[] valu = System.Text.RegularExpressions.Regex.Split(val[3].ToString(), @"{'-'}");
                    string[] valu = val[3].Split(new char[] { '-' });
                    dt1.Rows[i][9] = valu[0];
                    dt1.Rows[i][13] = val[1].Substring(4, 16);
                    // dt.Rows[i][2] = valu[0];
                    dt1.Rows[i][0] = dt1.Rows[i][17] = Amount;
                    dt1.Rows[i][1] = dt1.Rows[i][18] = "MYR";
                    dt1.Rows[i][2] = dt1.Rows[i][19] = Date; //change the date afterwords
                    dt1.Rows[i][3] = dt1.Rows[i][20] = "F";
                    dt1.Rows[i][4] = "";
                    dt1.Rows[i][5] = "L";
                    dt1.Rows[i][6] = "1";
                    dt1.Rows[i][7] = "2";
                    dt1.Rows[i][8] = "CAMYCBD303288894MYR-PSG";
                    dt1.Rows[i][10] = "C";
                    //dt1.Rows[i][11] = dt1.Rows[i][16] = dtexcel.Rows[i][14].ToString(); //Need to put value Date
                    dt1.Rows[i][12] = "288894";
                    //// dt.Rows[i][13] = acc;
                    dt1.Rows[i][14] = "303-1323-288894-MYR-800-100-10";
                    dt1.Rows[i][15] = "SPLT";
                }
                if (val[3].Contains("PAN:"))
                {
                    string[] valu = val[5].Split(new char[] { '-' });
                    dt1.Rows[i][9] = valu[0];
                    dt1.Rows[i][13] = val[3].Substring(4, 16);
                    //dt1.Rows[i][0] = val[3];
                    //dt1.Rows[i][1] = val[5];
                    dt1.Rows[i][0] = dt1.Rows[i][17] = Amount;
                    dt1.Rows[i][1] = dt1.Rows[i][18] = "MYR";
                    dt1.Rows[i][2] = dt1.Rows[i][19] = Date; //change the date afterwords
                    dt1.Rows[i][3] = dt1.Rows[i][20] = "F";
                    dt1.Rows[i][4] = "";
                    dt1.Rows[i][5] = "L";
                    dt1.Rows[i][6] = "1";
                    dt1.Rows[i][7] = "2";
                    dt1.Rows[i][8] = "CAMYCBD303288894MYR-PSG";
                    dt1.Rows[i][10] = "C";
                    //dt1.Rows[i][11] = dt1.Rows[i][16] = dtexcel.Rows[i][14].ToString(); //Need to put value Date
                    dt1.Rows[i][12] = "288894";
                    //// dt.Rows[i][13] = acc;
                    dt1.Rows[i][14] = "303-1323-288894-MYR-800-100-10";
                    dt1.Rows[i][15] = "SPLT";

                }
            }
            DataRow newRow = dt1.NewRow();
            dt1.Rows.InsertAt(newRow, 0);
            for (int i = 0; i < 1; i++)
            {
                //string[] val = System.Text.RegularExpressions.Regex.Split(dt.Rows[i][0].ToString(), @"\s{2,}");               
                if (dt1.Rows[i][0].ToString() == "")
                {
                    //string[] valu = System.Text.RegularExpressions.Regex.Split(val[3].ToString(), @"{'-'}");
                    // string[] valu = val[3].Split(new char[] { '-' });
                    dt1.Rows[i][9] = "";
                    dt1.Rows[i][13] = "";
                    // dt.Rows[i][2] = valu[0];
                    dt1.Rows[i][0] = dt1.Rows[i][17] = Amount;
                    dt1.Rows[i][1] = dt1.Rows[i][18] = "MYR";
                    dt1.Rows[i][2] = dt1.Rows[i][19] = Date; //change the date afterwords
                    dt1.Rows[i][3] = dt1.Rows[i][20] = "F";
                    dt1.Rows[i][4] = "";
                    dt1.Rows[i][5] = "L";
                    dt1.Rows[i][6] = "1";
                    dt1.Rows[i][7] = "2";
                    dt1.Rows[i][8] = "CAMYCBD303288894MYR-PSG";
                    dt1.Rows[i][10] = "D";
                    //dt1.Rows[i][11] = dt1.Rows[i][16] = dtexcel.Rows[i][14].ToString(); //Need to put value Date
                    dt1.Rows[i][12] = "288894";
                    //// dt.Rows[i][13] = acc;
                    dt1.Rows[i][14] = "303-1323-288894-MYR-800-100-10";
                    dt1.Rows[i][15] = "SPLT";
                }
            }
            return dt1;
        }
    }
}
