﻿namespace ARC_Application
{
    partial class ChangePassword
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lbl_CurPsd = new System.Windows.Forms.Label();
            this.txt_CurPsd = new System.Windows.Forms.TextBox();
            this.Lbl_UID = new System.Windows.Forms.Label();
            this.txt_Npsd = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.Btn_Cnl = new System.Windows.Forms.Button();
            this.BtnUpd = new System.Windows.Forms.Button();
            this.txt_Rpsd = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lbl_CurPsd);
            this.groupBox1.Controls.Add(this.txt_CurPsd);
            this.groupBox1.Controls.Add(this.Lbl_UID);
            this.groupBox1.Controls.Add(this.txt_Npsd);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.Btn_Cnl);
            this.groupBox1.Controls.Add(this.BtnUpd);
            this.groupBox1.Controls.Add(this.txt_Rpsd);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Location = new System.Drawing.Point(47, 26);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(342, 238);
            this.groupBox1.TabIndex = 12;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "ARC ChangePassword";
            // 
            // lbl_CurPsd
            // 
            this.lbl_CurPsd.AutoSize = true;
            this.lbl_CurPsd.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CurPsd.ForeColor = System.Drawing.Color.SteelBlue;
            this.lbl_CurPsd.Location = new System.Drawing.Point(27, 73);
            this.lbl_CurPsd.Name = "lbl_CurPsd";
            this.lbl_CurPsd.Size = new System.Drawing.Size(104, 15);
            this.lbl_CurPsd.TabIndex = 19;
            this.lbl_CurPsd.Text = "Current Password";
            // 
            // txt_CurPsd
            // 
            this.txt_CurPsd.Location = new System.Drawing.Point(185, 68);
            this.txt_CurPsd.Name = "txt_CurPsd";
            this.txt_CurPsd.PasswordChar = '*';
            this.txt_CurPsd.Size = new System.Drawing.Size(100, 20);
            this.txt_CurPsd.TabIndex = 1;
            // 
            // Lbl_UID
            // 
            this.Lbl_UID.AutoSize = true;
            this.Lbl_UID.Location = new System.Drawing.Point(182, 34);
            this.Lbl_UID.Name = "Lbl_UID";
            this.Lbl_UID.Size = new System.Drawing.Size(40, 13);
            this.Lbl_UID.TabIndex = 17;
            this.Lbl_UID.Text = "UserID";
            // 
            // txt_Npsd
            // 
            this.txt_Npsd.Location = new System.Drawing.Point(185, 109);
            this.txt_Npsd.Name = "txt_Npsd";
            this.txt_Npsd.PasswordChar = '*';
            this.txt_Npsd.Size = new System.Drawing.Size(100, 20);
            this.txt_Npsd.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.SteelBlue;
            this.label2.Location = new System.Drawing.Point(27, 109);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(89, 15);
            this.label2.TabIndex = 15;
            this.label2.Text = "New Password";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.SteelBlue;
            this.label3.Location = new System.Drawing.Point(52, 32);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(48, 15);
            this.label3.TabIndex = 14;
            this.label3.Text = "User ID";
            // 
            // Btn_Cnl
            // 
            this.Btn_Cnl.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.Btn_Cnl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_Cnl.ForeColor = System.Drawing.Color.White;
            this.Btn_Cnl.Location = new System.Drawing.Point(195, 186);
            this.Btn_Cnl.Name = "Btn_Cnl";
            this.Btn_Cnl.Size = new System.Drawing.Size(75, 28);
            this.Btn_Cnl.TabIndex = 5;
            this.Btn_Cnl.Text = "Cancel";
            this.Btn_Cnl.UseVisualStyleBackColor = false;
            this.Btn_Cnl.Click += new System.EventHandler(this.Btn_Cnl_Click);
            // 
            // BtnUpd
            // 
            this.BtnUpd.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.BtnUpd.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnUpd.ForeColor = System.Drawing.Color.White;
            this.BtnUpd.Location = new System.Drawing.Point(65, 186);
            this.BtnUpd.Name = "BtnUpd";
            this.BtnUpd.Size = new System.Drawing.Size(75, 28);
            this.BtnUpd.TabIndex = 4;
            this.BtnUpd.Text = "Update";
            this.BtnUpd.UseVisualStyleBackColor = false;
            this.BtnUpd.Click += new System.EventHandler(this.BtnUpd_Click);
            // 
            // txt_Rpsd
            // 
            this.txt_Rpsd.Location = new System.Drawing.Point(185, 148);
            this.txt_Rpsd.Name = "txt_Rpsd";
            this.txt_Rpsd.PasswordChar = '*';
            this.txt_Rpsd.Size = new System.Drawing.Size(100, 20);
            this.txt_Rpsd.TabIndex = 3;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.SteelBlue;
            this.label4.Location = new System.Drawing.Point(27, 148);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(113, 15);
            this.label4.TabIndex = 10;
            this.label4.Text = "Re-Enter Password";
            // 
            // ChangePassword
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(441, 300);
            this.ControlBox = false;
            this.Controls.Add(this.groupBox1);
            this.Name = "ChangePassword";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ChangePassword";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label Lbl_UID;
        private System.Windows.Forms.TextBox txt_Npsd;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button Btn_Cnl;
        private System.Windows.Forms.Button BtnUpd;
        private System.Windows.Forms.TextBox txt_Rpsd;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txt_CurPsd;
        private System.Windows.Forms.Label lbl_CurPsd;
    }
}