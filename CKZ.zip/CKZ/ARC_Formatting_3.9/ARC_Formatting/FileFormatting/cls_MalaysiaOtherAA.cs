﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Data.OleDb;
using System.Globalization;
using System.Data.SqlClient;
using Excel = Microsoft.Office.Interop.Excel;
using System.Data;

namespace ARC_Formatting.FileFormatting
{
    public class cls_MalaysiaOtherAA
    {
        public void MalaysiaOtherAA(string SourcePath, string Recon_Date, string Output_Dir, string Recon_name, string Output_Path, string Formatted_File_Name,string File_Ext)
        {
            string outputFileName = Formatted_File_Name + "." + File_Ext;
            string strConn;
            System.Data.DataTable dtexcel1 = new System.Data.DataTable();
            strConn = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + SourcePath + ";Extended Properties='Excel 8.0;HDR=YES'";
            OleDbConnection conn1 = new OleDbConnection(strConn);
            conn1.Open();
            System.Data.DataTable schemaTable1 = conn1.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, new object[] { null, null, null, "TABLE" });

            DataRow schemaRow4 = schemaTable1.Rows[0];
            string sheet1 = schemaRow4["TABLE_NAME"].ToString();

            OleDbDataAdapter daexcel1 = null;
            if (!sheet1.EndsWith("_"))
            {
                string query = "SELECT  * FROM [" + sheet1 + "]";
                daexcel1 = new OleDbDataAdapter(query, conn1);
                dtexcel1.Locale = CultureInfo.CurrentCulture;
                daexcel1.Fill(dtexcel1);
            }
            conn1.Close();
            DataTable dtMain = new DataTable();


            for (int i = 0; i < dtexcel1.Rows.Count; i++)
            {
                if (dtexcel1.Rows[0][0].ToString().Trim().ToUpper() == "BRANCH DATE:")
                {
                    break;
                }
                else
                {
                    dtexcel1.Rows.RemoveAt(0);
                }
            }

            string BranchDate = string.Empty;

            //BranchDate = dtexcel1.Rows[0][1].ToString();
            BranchDate = dtexcel1.Rows[0][1].ToString().Replace(" ", "");
            DateTime BranchDate1 = DateTime.ParseExact(BranchDate, "ddMMMyy", CultureInfo.InvariantCulture);
            BranchDate = BranchDate1.ToString("MM/dd/yyyy");

            dtexcel1.Rows.RemoveAt(0);

            dtMain.Columns.Add("");
            dtMain.Columns.Add("Deal No.");
            dtMain.Columns.Add("Seq No.");
            dtMain.Columns.Add("Mnemonic");
            dtMain.Columns.Add("");
            dtMain.Columns.Add("Purch Ccy");
            dtMain.Columns.Add("Amount");
            dtMain.Columns.Add("Base Amount");
            dtMain.Columns.Add("");
            dtMain.Columns.Add("Sale Ccy");
            dtMain.Columns.Add("Amount@");
            dtMain.Columns.Add("Base Amount@");
            dtMain.Columns.Add("");
            dtMain.Columns.Add("FEDS No");
            dtMain.Columns.Add("Deal Type");

            for (int j = 1; j < dtexcel1.Rows.Count; j++)
            {
                if (dtexcel1.Rows[j][0].ToString().Trim().ToUpper() == "AA CODE:")
                {
                    dtMain.Rows.Add();
                    dtMain.Rows[j - 1][0] = dtexcel1.Rows[j][0].ToString();
                    dtMain.Rows[j - 1][1] = dtexcel1.Rows[j][1].ToString();
                }
                else
                {
                    dtMain.Rows.Add();
                    dtMain.Rows[j - 1][1] = dtexcel1.Rows[j][0].ToString();//Deal No.
                    dtMain.Rows[j - 1][2] = dtexcel1.Rows[j][1].ToString();//Seq No.
                    dtMain.Rows[j - 1][3] = dtexcel1.Rows[j][2].ToString();//Mnemonic
                    dtMain.Rows[j - 1][5] = dtexcel1.Rows[j][3].ToString();//Purch Ccy
                    dtMain.Rows[j - 1][6] = dtexcel1.Rows[j][4].ToString();//Amount
                    dtMain.Rows[j - 1][7] = dtexcel1.Rows[j][5].ToString();//Base AMount
                    dtMain.Rows[j - 1][9] = dtexcel1.Rows[j][6].ToString();//Sale Ccy
                    dtMain.Rows[j - 1][10] = dtexcel1.Rows[j][7].ToString();//Amount
                    dtMain.Rows[j - 1][11] = dtexcel1.Rows[j][8].ToString();//Base Amount
                    dtMain.Rows[j - 1][13] = dtexcel1.Rows[j][9].ToString();//FEEDS No
                    dtMain.Rows[j - 1][14] = dtexcel1.Rows[j][10].ToString();//Deal Type
                }
            }

            for (int k = 0; k < dtMain.Rows.Count; k++)
            {
                if (dtMain.Rows[k][13].ToString() != "")
                {
                    dtMain.Rows[k][1] = dtMain.Rows[k][1] + "-" + dtMain.Rows[k][13];
                }
            }

            DataTable dtfinal = new DataTable();

            dtfinal.Columns.Add("");
            dtfinal.Columns.Add("");
            dtfinal.Columns.Add("");
            dtfinal.Columns.Add("");
            dtfinal.Columns.Add("");
            dtfinal.Columns.Add("");
            dtfinal.Columns.Add("");
            dtfinal.Columns.Add("");
            dtfinal.Columns.Add("");
            dtfinal.Columns.Add("");
            dtfinal.Columns.Add("");
            dtfinal.Columns.Add("");
            dtfinal.Columns.Add("");
            dtfinal.Columns.Add("");
            dtfinal.Columns.Add("");
            dtfinal.Columns.Add("");

            dtfinal.Rows.Add();
            dtfinal.Rows[0][0] = "BRANCH           :";
            dtfinal.Rows[0][1] = "SG SUB DBU";
            dtfinal.Rows[0][14] = "SYSTEM DATE :";

            dtfinal.Rows.Add();
            dtfinal.Rows[1][0] = "REPORT REF   :";
            dtfinal.Rows[1][1] = "OPXOR029";
            dtfinal.Rows[1][6] = "STANDARD CHARTERED BANK";
            dtfinal.Rows[1][14] = "PAGE NO          :";
            dtfinal.Rows[1][15] = "1";

            dtfinal.Rows.Add();
            dtfinal.Rows[2][8] = "LIST OF FX DEALS UTILISED TODAY BY AA CODE (FOR RPR)";

            dtfinal.Rows.Add();
            dtfinal.Rows[3][0] = "BRANCH DATE:";
            dtfinal.Rows[3][1] = BranchDate;

            dtfinal.Rows.Add();
            dtfinal.Rows[4][1] = "Deal No.";
            dtfinal.Rows[4][2] = "Seq No.";
            dtfinal.Rows[4][3] = "Mnemonic";
            dtfinal.Rows[4][5] = "Purch Ccy";
            dtfinal.Rows[4][6] = "Amount";
            dtfinal.Rows[4][7] = "Base Amount";
            dtfinal.Rows[4][9] = "Sale Ccy";
            dtfinal.Rows[4][10] = "Amount";
            dtfinal.Rows[4][11] = "Base Amount";
            dtfinal.Rows[4][13] = "FEDS No";
            dtfinal.Rows[4][14] = "Deal Type";

            for (int l = 5; l < dtMain.Rows.Count + 5; l++)
            {
                dtfinal.Rows.Add();
                dtfinal.Rows[l][0] = dtMain.Rows[l - 5][0].ToString();
                dtfinal.Rows[l][1] = dtMain.Rows[l - 5][1].ToString();
                dtfinal.Rows[l][2] = dtMain.Rows[l - 5][2].ToString();
                dtfinal.Rows[l][3] = dtMain.Rows[l - 5][3].ToString();
                dtfinal.Rows[l][4] = dtMain.Rows[l - 5][4].ToString();
                dtfinal.Rows[l][5] = dtMain.Rows[l - 5][5].ToString();
                dtfinal.Rows[l][6] = dtMain.Rows[l - 5][6].ToString();
                dtfinal.Rows[l][7] = dtMain.Rows[l - 5][7].ToString();
                dtfinal.Rows[l][8] = dtMain.Rows[l - 5][8].ToString();
                dtfinal.Rows[l][9] = dtMain.Rows[l - 5][9].ToString();
                dtfinal.Rows[l][10] = dtMain.Rows[l - 5][10].ToString();
                dtfinal.Rows[l][11] = dtMain.Rows[l - 5][11].ToString();
                dtfinal.Rows[l][12] = dtMain.Rows[l - 5][12].ToString();
                dtfinal.Rows[l][13] = dtMain.Rows[l - 5][13].ToString();
                dtfinal.Rows[l][14] = dtMain.Rows[l - 5][14].ToString();
            }

            ExportToExcel(dtfinal, Output_Path, outputFileName);
        }

        public void ExportToExcel(DataTable tbl, string Output_Path, string OutputFileName)
        {
            // load excel, and create a new workbook
            var excelApp = new Microsoft.Office.Interop.Excel.Application();

            Microsoft.Office.Interop.Excel.Workbook workBook = null;
            workBook = excelApp.Workbooks.Add(Type.Missing);                // single worksheet
            Microsoft.Office.Interop.Excel._Worksheet workSheet = (Microsoft.Office.Interop.Excel.Worksheet)workBook.Worksheets.Add(Type.Missing);
            excelApp.DisplayAlerts = false;
            excelApp.Visible = false;
            
            // rows
            for (var i = 0; i < tbl.Rows.Count; i++)
            {
                // to do: format datetime values before printing
                for (var j = 0; j < tbl.Columns.Count; j++)
                {
                    workSheet.Cells[i + 1, j + 1] = tbl.Rows[i][j];
                }
            }
            try
            {
                Excel.Range usedrange = workSheet.UsedRange;
                Excel.Range r = usedrange.get_Range("G2", Type.Missing);
                r.EntireRow.Font.Bold = true;
                //Excel.Range r1 = usedrange.Rows[(1), System.Reflection.Missing.Value] as Microsoft.Office.Interop.Excel.Range;
                r.Font.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Blue);
                r.Font.Size = 12;
                r.Font.Name = "Arial";
                r.Font.Underline = true;
                
                Excel.Range r1 = usedrange.get_Range("A1", Type.Missing);
                r1.EntireRow.Font.Bold = true;

                Excel.Range r2 = usedrange.get_Range("A3", Type.Missing);
                r2.EntireRow.Font.Bold = true;

                Excel.Range r3 = usedrange.get_Range("A4", Type.Missing);
                r3.EntireRow.Font.Bold = true;

                Excel.Range r4 = usedrange.get_Range("A5", Type.Missing);
                r4.EntireRow.Font.Bold = true;

                Excel.Range r5 = usedrange.get_Range("B4:B4");
                r5.NumberFormat = "dd mmm yy";

                workSheet.Columns.EntireColumn.AutoFit();
                if (!File.Exists(Output_Path + OutputFileName))
                    workBook.SaveCopyAs(Output_Path + OutputFileName);
                else
                    workBook.SaveCopyAs(Output_Path + OutputFileName);
                //File.Copy(excelFilePath, (Output_Path + "Final_Output.xls"));
                excelApp.Quit();
            }
            catch
            {

            }
            ReleaseComObject(workSheet);
            ReleaseComObject(workBook);
            ReleaseComObject(excelApp);
            //RenameExtension();
        }
        public void ReleaseComObject(object ob)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(ob);
                ob = null;
            }
            catch
            {
                ob = null;
            }
            finally
            {
                GC.Collect(GC.MaxGeneration);
                GC.WaitForPendingFinalizers();
            }
        }
    }
}
