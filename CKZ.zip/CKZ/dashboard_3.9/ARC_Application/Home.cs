﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace ARC_Application
{
    public partial class Home : Form
    {
        string conString = ConfigurationManager.ConnectionStrings["ARC_conStr"].ConnectionString;
        public Home()
        {
            InitializeComponent();
            ViewRecords();
        }
        DateTime productDate = DateTime.Now;

        public void ViewRecords()
        {
            SqlConnection con = new SqlConnection(@"Data Source=ukwpidsql500i1.gdc-dev.net\DEV_CL01_IN01, 10501;Initial Catalog=CRC_QMT;User ID=CRCAdmin;Password=c275bpOSJ;");
            string date = DateTime.Now.ToString("hh:mm");
            con.Open();
            SqlCommand cmd = new SqlCommand("Select Team,Country_Name,Recon,CONVERT(varchar(5),convert(TIME, convert(DATETIME, ARC_Scope_BaseLine.SLA_Time, 120))) as SLA_Time,CONVERT(varchar(5),convert(TIME, convert(DATETIME, ARC_Scope_BaseLine.Receipt_Time, 120))) as Reciept_Time,Report_Source_File_Name,FTP_File_Format_Name,Source_Application,Remarks,IsProcessed FROM ARC_Scope_BaseLine", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dt.Columns.Add("Actions", typeof(byte[]));
            if (dt.Columns.Contains("Actions"))
            {
                for (int indx = 0; indx < dt.Rows.Count; indx++)
                {
                    DateTime d = Convert.ToDateTime(dt.Rows[indx][3]);
                    DateTime d1 = Convert.ToDateTime(date);
                    if (Convert.ToBoolean(dt.Rows[indx][9]) == true && d.TimeOfDay < d1.TimeOfDay)
                    {
                       // dt.Rows[indx][10] = imageToByteArray(i1);
                    }
                    else if (Convert.ToBoolean(dt.Rows[indx][9]) == false && d.TimeOfDay > d1.TimeOfDay)
                    {
                       // dt.Rows[indx][10] = imageToByteArray(i3);
                    }
                    else if (Convert.ToBoolean(dt.Rows[indx][9]) == false && d.TimeOfDay < d1.TimeOfDay)
                    {
                       // dt.Rows[indx][10] = imageToByteArray(i2);
                    }
                    else if (Convert.ToBoolean(dt.Rows[indx][9]) == true && d.TimeOfDay > d1.TimeOfDay)
                    {
                        //dt.Rows[indx][10] = imageToByteArray(i1);
                    }
                }
            }
            dataGridView1.DataSource = dt;
            con.Close();
           // Total_count();
            dataGridView1.AllowUserToAddRows = false;
        }

    }
}
