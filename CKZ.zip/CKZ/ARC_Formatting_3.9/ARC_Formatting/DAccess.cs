﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.Collections;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Security.Cryptography;

namespace ARC_Formatting
{
    class DAccess
    {
        string conString = ConfigurationManager.ConnectionStrings["ARC_conStr"].ConnectionString;

        public DAccess()
        {
            if (!conString.StartsWith("Data"))
            {
                conString = Decrypt(conString);
            }
        }

        

        public DataTable Select_Table(string strquery, Hashtable hat, string Query_Type)
        {
            DataTable dt = new DataTable();
            SqlConnection con = new SqlConnection(conString);
            SqlCommand cmd = new SqlCommand();

            try
            {
                con.Close();
                con.Open();
                SqlDataAdapter ad = new SqlDataAdapter(strquery, con);

                if (Query_Type.Trim().ToLower() == "sp")
                {
                    ad.SelectCommand.CommandType = CommandType.StoredProcedure;

                    foreach (DictionaryEntry hatval in hat)
                    {
                        ad.SelectCommand.Parameters.AddWithValue(hatval.Key.ToString(), hatval.Value.ToString());
                    }
                }
                else
                {
                    ad.SelectCommand.CommandType = CommandType.Text;
                }

                ad.Fill(dt);
            }
            catch 
            {
              
            }
            finally
            {
                con.Close();
            }
            return dt;
        }

        public int ins_upd_fun(string strquery, Hashtable hat, string Query_type)
        {
            int insupval = 0;
            SqlConnection con = new SqlConnection(conString);
            SqlCommand cmd = new SqlCommand();

            try
            {
                con.Close();
                con.Open();
                cmd = new SqlCommand(strquery, con);
                if (Query_type == "sp")
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    foreach (DictionaryEntry hatval in hat)
                    {
                        cmd.Parameters.AddWithValue(hatval.Key.ToString(), hatval.Value.ToString());
                    }
                }
                else
                {
                    cmd.CommandType = CommandType.Text;
                }

                insupval = cmd.ExecuteNonQuery();
            }
            catch 
            {
                
            }
            finally
            {
                con.Close();
            }
            return insupval;
        }

        public bool Text_File_Vaules_Checking(string strTextFilePath, int intMyDate, string strCheckingValues)
        {
            bool hasval = false;
            try
            {
                DateTime dtch = new DateTime(DateTime.Now.Year, 1, 1).AddDays(intMyDate - 1);

                if (intMyDate != 0)
                {
                    string date1 = string.Format("{0:MMdd}", dtch);
                    strCheckingValues = strCheckingValues + "~" + date1 + " - " + date1;
                }

                string[] spd = strCheckingValues.Split('~');

                StreamReader objReader = new StreamReader(strTextFilePath);
                string[] lines = System.IO.File.ReadAllLines(strTextFilePath);

                string temp = "";

                for (int i = 0; i <= lines.Length - 1; i++)
                {
                    temp = lines[i].ToString();
                    bool strRowHasValue = true;
                    if (spd.Length > 0)
                    {
                        for (int tsh = 0; tsh < spd.Length; tsh++)
                        {
                            if (spd[tsh].ToString().Trim() != "")
                            {
                                if (!temp.ToUpper().Contains(spd[tsh].ToString().ToUpper()))
                                {
                                    strRowHasValue = false;
                                    tsh = spd.Length + 1;
                                }
                            }
                        }
                    }
                    else
                    {
                        strRowHasValue = false;
                    }

                    //if (temp.Contains("SMSACQTL") && temp.Contains("9999 - 9999") && temp.Contains(date1 + " - " + date1))
                    if (strRowHasValue == true)
                    {
                        hasval = true;
                        i = lines.Length + 1;
                    }
                }
            }
            catch
            {

            }
            return hasval;
        }

        public string Encrypt(string clearText)
        {
            string EncryptionKey = "MAKV2SPBNI99212";
            byte[] clearBytes = Encoding.Unicode.GetBytes(clearText);
            using (Aes encryptor = Aes.Create())
            {
                Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
                encryptor.Key = pdb.GetBytes(32);
                encryptor.IV = pdb.GetBytes(16);
                using (MemoryStream ms = new MemoryStream())
                {
                    using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateEncryptor(), CryptoStreamMode.Write))
                    {
                        cs.Write(clearBytes, 0, clearBytes.Length);
                        cs.Close();
                    }
                    clearText = Convert.ToBase64String(ms.ToArray());
                }
            }
            return clearText;
        }

        public string Decrypt(string cipherText)
        {

            string EncryptionKey = "MAKV2SPBNI99212";
            byte[] cipherBytes = Convert.FromBase64String(cipherText);
            using (Aes encryptor = Aes.Create())
            {
                Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
                encryptor.Key = pdb.GetBytes(32);
                encryptor.IV = pdb.GetBytes(16);
                using (MemoryStream ms = new MemoryStream())
                {
                    using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateDecryptor(), CryptoStreamMode.Write))
                    {
                        cs.Write(cipherBytes, 0, cipherBytes.Length);
                        cs.Close();
                    }
                    cipherText = Encoding.Unicode.GetString(ms.ToArray());
                }
            }
            return cipherText;
        }
    }
}
