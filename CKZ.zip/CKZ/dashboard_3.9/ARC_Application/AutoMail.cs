﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Net.Mail;

namespace ARC_Application
{
    partial class AutoMail : ServiceBase
    {
        public AutoMail()
        {
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            // TODO: Add code here to start your service.
            //MyLogEvent.WriteEntry("In OnStart --- Sending Mail to" + Dt);

            System.Timers.Timer time = new System.Timers.Timer();

            time.Start();

            time.Interval = 300000;

            time.Elapsed += timer1_Tick;
        }

        protected override void OnStop()
        {
            // TODO: Add code here to perform any tear-down necessary to stop your service.
        }

        public void AutoMails()
        {
            if (!System.Diagnostics.EventLog.SourceExists("MailSend"))
            {
                System.Diagnostics.EventLog.CreateEventSource(

                "MailSend", "AutoMailLog");

            }
            MyLogEvent.Source = "MailSend";

            MyLogEvent.Log = "AutoMailLog";
        }

        public void timer1_Tick(object sender, EventArgs e)
        {
            MyLogEvent.WriteEntry("Mail Sending on " + DateTime.Now.ToString());

            SendEmail("Kiran.H@sc.com", "AneeshKumar.G@sc.com", "Automatic Mail sending", "Successfully working contact AneeshKumar.G@sc.com");
        }
        public bool SendEmail(string strTo, string strFrom, string strSubject, string strBody)
        {
            bool flag = false;

            MailMessage mailMsg = new MailMessage();

            MailAddress mailAddress = null;
           // Outlook.Application app = new Outlook.Application();
            //Outlook.MailItem mailItem = app.CreateItem(Outlook.OlItemType.olMailItem);


            try
            {
                // To

                mailMsg.To.Add(strTo);
                mailAddress = new MailAddress(strFrom);

                mailMsg.From = mailAddress;
                mailMsg.Subject = strSubject;

                mailMsg.Body = strBody;
                SmtpClient smtpClient = new SmtpClient("97.0.0.6", Convert.ToInt32(25));

                System.Net.NetworkCredential credentials = new System.Net.NetworkCredential();

                smtpClient.Credentials = credentials;

                smtpClient.Send(mailMsg);
                flag = true;

                MyLogEvent.WriteEntry("Mail Send Successfully");

            }
            catch
            {

                MyLogEvent.WriteEntry("Error occured");

                //Response.Write(ex.Message);

            }
            finally
            {
                mailMsg = null;

                mailAddress = null;

            }
            return flag;

        }
    }
}
