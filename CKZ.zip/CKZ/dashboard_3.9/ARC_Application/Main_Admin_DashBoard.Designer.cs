﻿namespace ARC_Application
{
    partial class Main_Admin_DashBoard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main_Admin_DashBoard));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.Ref = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lbl_cntry = new System.Windows.Forms.Label();
            this.cmb_cntry = new System.Windows.Forms.ComboBox();
            this.lbl_pen = new System.Windows.Forms.Label();
            this.lbl_Prd = new System.Windows.Forms.Label();
            this.lbl_pen_cnt = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Pnl_User = new System.Windows.Forms.Panel();
            this.Btn_Export = new System.Windows.Forms.Button();
            this.Btn_Excel = new System.Windows.Forms.Button();
            this.lbl_com = new System.Windows.Forms.Label();
            this.cmb_Prdt = new System.Windows.Forms.ComboBox();
            this.lbl_com_cnt = new System.Windows.Forms.Label();
            this.lbl_rec = new System.Windows.Forms.Label();
            this.lbl_cnt = new System.Windows.Forms.Label();
            this.DGV_AData = new System.Windows.Forms.DataGridView();
            this.Btn_Clr = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.To_Date = new System.Windows.Forms.DateTimePicker();
            this.label5 = new System.Windows.Forms.Label();
            this.btn_GenerateReport = new System.Windows.Forms.Button();
            this.btn_AuditReport = new System.Windows.Forms.Button();
            this.From_Date = new System.Windows.Forms.DateTimePicker();
            this.label4 = new System.Windows.Forms.Label();
            this.btn_EODstatus = new System.Windows.Forms.Button();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btn_Clear = new System.Windows.Forms.Button();
            this.Btn_PageAccess_Rev = new System.Windows.Forms.Button();
            this.Btn_PageAccess_Frd = new System.Windows.Forms.Button();
            this.Lst_PageAccess_02 = new System.Windows.Forms.ListBox();
            this.label9 = new System.Windows.Forms.Label();
            this.Btn_Countr_Rev = new System.Windows.Forms.Button();
            this.Btn_Countr_Frd = new System.Windows.Forms.Button();
            this.Lst_Countries_02 = new System.Windows.Forms.ListBox();
            this.Lst_Countries_01 = new System.Windows.Forms.ListBox();
            this.label11 = new System.Windows.Forms.Label();
            this.lbl_Prdt = new System.Windows.Forms.Label();
            this.Btn_Prdt_Rev = new System.Windows.Forms.Button();
            this.Btn_Prdt_Fwd = new System.Windows.Forms.Button();
            this.Lst_Prdt_02 = new System.Windows.Forms.ListBox();
            this.Lst_Prdt_01 = new System.Windows.Forms.ListBox();
            this.Lst_PageAccess_01 = new System.Windows.Forms.ListBox();
            this.Btn_App_Rev01 = new System.Windows.Forms.Button();
            this.Btn_App_Frd01 = new System.Windows.Forms.Button();
            this.Lst_Application_02 = new System.Windows.Forms.ListBox();
            this.Lst_Application_01 = new System.Windows.Forms.ListBox();
            this.lbl_Appl = new System.Windows.Forms.Label();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.UserName = new System.Windows.Forms.TextBox();
            this.ManagerID = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.Acc_Type = new System.Windows.Forms.ComboBox();
            this.PSID = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.btn_DeleteUser = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.btn_EditUser = new System.Windows.Forms.Button();
            this.btn_AddUser = new System.Windows.Forms.Button();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.btnEditUser = new System.Windows.Forms.Button();
            this.cmbAccessType = new System.Windows.Forms.ComboBox();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnSearch = new System.Windows.Forms.Button();
            this.dataGridView = new System.Windows.Forms.DataGridView();
            this.btnAddUser = new System.Windows.Forms.Button();
            this.btnDeleteUser = new System.Windows.Forms.Button();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.chklstPageAccess = new System.Windows.Forms.CheckedListBox();
            this.chklstCountries = new System.Windows.Forms.CheckedListBox();
            this.chklstProduct = new System.Windows.Forms.CheckedListBox();
            this.chklstApplication = new System.Windows.Forms.CheckedListBox();
            this.txtLineManager = new System.Windows.Forms.TextBox();
            this.txtUserName = new System.Windows.Forms.TextBox();
            this.txtUserPSID = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.txt_HolidayReson = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.dtPicker_From = new System.Windows.Forms.DateTimePicker();
            this.label21 = new System.Windows.Forms.Label();
            this.btn_DeleteCalendar = new System.Windows.Forms.Button();
            this.btn_AddCalendar = new System.Windows.Forms.Button();
            this.DGV_Holiday = new System.Windows.Forms.DataGridView();
            this.btn_EditCalendar = new System.Windows.Forms.Button();
            this.btn_ViewCalendar = new System.Windows.Forms.Button();
            this.label20 = new System.Windows.Forms.Label();
            this.cmb_Holiday = new System.Windows.Forms.ComboBox();
            this.TabImages = new System.Windows.Forms.ImageList(this.components);
            this.lnk_Logout = new System.Windows.Forms.LinkLabel();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.panel6 = new System.Windows.Forms.Panel();
            this.Logout = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Loading = new System.Windows.Forms.PictureBox();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Ref)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.Pnl_User.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_AData)).BeginInit();
            this.tabPage3.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.tabPage4.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.tabPage5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).BeginInit();
            this.tabPage6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_Holiday)).BeginInit();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Logout)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Loading)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Controls.Add(this.tabPage6);
            this.tabControl1.Cursor = System.Windows.Forms.Cursors.Default;
            this.tabControl1.Font = new System.Drawing.Font("Cambria", 9.75F);
            this.tabControl1.ImageList = this.TabImages;
            this.tabControl1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.tabControl1.Location = new System.Drawing.Point(3, 137);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1181, 700);
            this.tabControl1.TabIndex = 7;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.Ref);
            this.tabPage1.Controls.Add(this.panel2);
            this.tabPage1.Controls.Add(this.DGV_AData);
            this.tabPage1.Controls.Add(this.Btn_Clr);
            this.tabPage1.ImageKey = "DashBoard";
            this.tabPage1.Location = new System.Drawing.Point(4, 24);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1173, 672);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "DashBoard";
            this.tabPage1.ToolTipText = "DashBoard";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // Ref
            // 
            this.Ref.Image = global::ARC_Application.Properties.Resources.arrow_refresh_4_icon;
            this.Ref.Location = new System.Drawing.Point(1066, 8);
            this.Ref.Name = "Ref";
            this.Ref.Size = new System.Drawing.Size(24, 24);
            this.Ref.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.Ref.TabIndex = 58;
            this.Ref.TabStop = false;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.lbl_cntry);
            this.panel2.Controls.Add(this.cmb_cntry);
            this.panel2.Controls.Add(this.lbl_pen);
            this.panel2.Controls.Add(this.lbl_Prd);
            this.panel2.Controls.Add(this.lbl_pen_cnt);
            this.panel2.Controls.Add(this.panel1);
            this.panel2.Controls.Add(this.lbl_com);
            this.panel2.Controls.Add(this.cmb_Prdt);
            this.panel2.Controls.Add(this.lbl_com_cnt);
            this.panel2.Controls.Add(this.lbl_rec);
            this.panel2.Controls.Add(this.lbl_cnt);
            this.panel2.Location = new System.Drawing.Point(4, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1059, 35);
            this.panel2.TabIndex = 46;
            // 
            // lbl_cntry
            // 
            this.lbl_cntry.AutoSize = true;
            this.lbl_cntry.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_cntry.Location = new System.Drawing.Point(251, 8);
            this.lbl_cntry.Name = "lbl_cntry";
            this.lbl_cntry.Size = new System.Drawing.Size(51, 15);
            this.lbl_cntry.TabIndex = 20;
            this.lbl_cntry.Text = "Country";
            // 
            // cmb_cntry
            // 
            this.cmb_cntry.FormattingEnabled = true;
            this.cmb_cntry.Location = new System.Drawing.Point(328, 4);
            this.cmb_cntry.Name = "cmb_cntry";
            this.cmb_cntry.Size = new System.Drawing.Size(121, 23);
            this.cmb_cntry.TabIndex = 2;
            this.cmb_cntry.SelectedIndexChanged += new System.EventHandler(this.cmb_cntry_SelectedIndexChanged);
            // 
            // lbl_pen
            // 
            this.lbl_pen.AutoSize = true;
            this.lbl_pen.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_pen.Location = new System.Drawing.Point(876, 6);
            this.lbl_pen.Name = "lbl_pen";
            this.lbl_pen.Size = new System.Drawing.Size(69, 15);
            this.lbl_pen.TabIndex = 57;
            this.lbl_pen.Text = "Pending:-";
            // 
            // lbl_Prd
            // 
            this.lbl_Prd.AutoSize = true;
            this.lbl_Prd.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Prd.Location = new System.Drawing.Point(17, 8);
            this.lbl_Prd.Name = "lbl_Prd";
            this.lbl_Prd.Size = new System.Drawing.Size(52, 15);
            this.lbl_Prd.TabIndex = 17;
            this.lbl_Prd.Text = "Products";
            // 
            // lbl_pen_cnt
            // 
            this.lbl_pen_cnt.AutoSize = true;
            this.lbl_pen_cnt.Location = new System.Drawing.Point(973, 7);
            this.lbl_pen_cnt.Name = "lbl_pen_cnt";
            this.lbl_pen_cnt.Size = new System.Drawing.Size(56, 15);
            this.lbl_pen_cnt.TabIndex = 56;
            this.lbl_pen_cnt.Text = "Pend_cnt";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.dataGridView1);
            this.panel1.Controls.Add(this.Pnl_User);
            this.panel1.Controls.Add(this.Btn_Excel);
            this.panel1.Location = new System.Drawing.Point(0, 180);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1054, 215);
            this.panel1.TabIndex = 9;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(39, 12);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(651, 150);
            this.dataGridView1.TabIndex = 4;
            // 
            // Pnl_User
            // 
            this.Pnl_User.Controls.Add(this.Btn_Export);
            this.Pnl_User.Location = new System.Drawing.Point(1, 231);
            this.Pnl_User.Name = "Pnl_User";
            this.Pnl_User.Size = new System.Drawing.Size(1053, 10);
            this.Pnl_User.TabIndex = 12;
            this.Pnl_User.Visible = false;
            // 
            // Btn_Export
            // 
            this.Btn_Export.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.Btn_Export.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_Export.ForeColor = System.Drawing.Color.White;
            this.Btn_Export.Location = new System.Drawing.Point(951, 210);
            this.Btn_Export.Name = "Btn_Export";
            this.Btn_Export.Size = new System.Drawing.Size(75, 28);
            this.Btn_Export.TabIndex = 12;
            this.Btn_Export.Text = "Export";
            this.Btn_Export.UseVisualStyleBackColor = false;
            // 
            // Btn_Excel
            // 
            this.Btn_Excel.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.Btn_Excel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_Excel.ForeColor = System.Drawing.Color.White;
            this.Btn_Excel.Location = new System.Drawing.Point(724, 174);
            this.Btn_Excel.Name = "Btn_Excel";
            this.Btn_Excel.Size = new System.Drawing.Size(104, 28);
            this.Btn_Excel.TabIndex = 5;
            this.Btn_Excel.Text = "Export to Excel";
            this.Btn_Excel.UseVisualStyleBackColor = false;
            // 
            // lbl_com
            // 
            this.lbl_com.AutoSize = true;
            this.lbl_com.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_com.Location = new System.Drawing.Point(695, 6);
            this.lbl_com.Name = "lbl_com";
            this.lbl_com.Size = new System.Drawing.Size(85, 15);
            this.lbl_com.TabIndex = 55;
            this.lbl_com.Text = "Completed:-";
            // 
            // cmb_Prdt
            // 
            this.cmb_Prdt.FormattingEnabled = true;
            this.cmb_Prdt.Location = new System.Drawing.Point(89, 5);
            this.cmb_Prdt.Name = "cmb_Prdt";
            this.cmb_Prdt.Size = new System.Drawing.Size(121, 23);
            this.cmb_Prdt.TabIndex = 1;
            this.cmb_Prdt.SelectedIndexChanged += new System.EventHandler(this.cmb_Prdt_SelectedIndexChanged);
            // 
            // lbl_com_cnt
            // 
            this.lbl_com_cnt.AutoSize = true;
            this.lbl_com_cnt.Location = new System.Drawing.Point(797, 6);
            this.lbl_com_cnt.Name = "lbl_com_cnt";
            this.lbl_com_cnt.Size = new System.Drawing.Size(54, 15);
            this.lbl_com_cnt.TabIndex = 54;
            this.lbl_com_cnt.Text = "Com_cnt";
            // 
            // lbl_rec
            // 
            this.lbl_rec.AutoSize = true;
            this.lbl_rec.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_rec.Location = new System.Drawing.Point(474, 6);
            this.lbl_rec.Name = "lbl_rec";
            this.lbl_rec.Size = new System.Drawing.Size(143, 15);
            this.lbl_rec.TabIndex = 52;
            this.lbl_rec.Text = "Total No:of Records:-";
            // 
            // lbl_cnt
            // 
            this.lbl_cnt.AutoSize = true;
            this.lbl_cnt.Location = new System.Drawing.Point(623, 6);
            this.lbl_cnt.Name = "lbl_cnt";
            this.lbl_cnt.Size = new System.Drawing.Size(45, 15);
            this.lbl_cnt.TabIndex = 53;
            this.lbl_cnt.Text = "Ttl_cnt";
            // 
            // DGV_AData
            // 
            this.DGV_AData.AllowUserToAddRows = false;
            this.DGV_AData.AllowUserToDeleteRows = false;
            this.DGV_AData.AllowUserToResizeRows = false;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Info;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.Color.Transparent;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.Color.Black;
            this.DGV_AData.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle7;
            this.DGV_AData.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DGV_AData.BackgroundColor = System.Drawing.Color.White;
            this.DGV_AData.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.DGV_AData.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Sunken;
            this.DGV_AData.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Cambria", 9.75F);
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DGV_AData.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle8;
            this.DGV_AData.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle9.BackColor = System.Drawing.Color.MintCream;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Cambria", 9.75F);
            dataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.DGV_AData.DefaultCellStyle = dataGridViewCellStyle9;
            this.DGV_AData.GridColor = System.Drawing.Color.Blue;
            this.DGV_AData.Location = new System.Drawing.Point(4, 41);
            this.DGV_AData.Name = "DGV_AData";
            this.DGV_AData.ReadOnly = true;
            this.DGV_AData.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.DGV_AData.RowHeadersVisible = false;
            this.DGV_AData.RowHeadersWidth = 31;
            this.DGV_AData.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.DGV_AData.Size = new System.Drawing.Size(1167, 348);
            this.DGV_AData.TabIndex = 49;
            // 
            // Btn_Clr
            // 
            this.Btn_Clr.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Btn_Clr.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_Clr.ForeColor = System.Drawing.Color.White;
            this.Btn_Clr.Location = new System.Drawing.Point(1091, 7);
            this.Btn_Clr.Name = "Btn_Clr";
            this.Btn_Clr.Size = new System.Drawing.Size(75, 28);
            this.Btn_Clr.TabIndex = 45;
            this.Btn_Clr.Text = "Refresh";
            this.Btn_Clr.UseVisualStyleBackColor = false;
            this.Btn_Clr.Click += new System.EventHandler(this.Btn_Clr_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.ImageKey = "Configuration";
            this.tabPage2.Location = new System.Drawing.Point(4, 24);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1173, 672);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Configuration Management";
            this.tabPage2.ToolTipText = "Configuration Management";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.groupBox1);
            this.tabPage3.ImageKey = "Reports";
            this.tabPage3.Location = new System.Drawing.Point(4, 24);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(1173, 672);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Reports";
            this.tabPage3.ToolTipText = "Reports";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.panel4);
            this.groupBox1.Controls.Add(this.pictureBox5);
            this.groupBox1.Location = new System.Drawing.Point(3, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1167, 298);
            this.groupBox1.TabIndex = 33;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "       Report";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(92)))), ((int)(((byte)(132)))));
            this.panel4.Controls.Add(this.pictureBox10);
            this.panel4.Controls.Add(this.pictureBox9);
            this.panel4.Controls.Add(this.pictureBox8);
            this.panel4.Controls.Add(this.pictureBox7);
            this.panel4.Controls.Add(this.pictureBox6);
            this.panel4.Controls.Add(this.label3);
            this.panel4.Controls.Add(this.label2);
            this.panel4.Controls.Add(this.label1);
            this.panel4.Controls.Add(this.To_Date);
            this.panel4.Controls.Add(this.label5);
            this.panel4.Controls.Add(this.btn_GenerateReport);
            this.panel4.Controls.Add(this.btn_AuditReport);
            this.panel4.Controls.Add(this.From_Date);
            this.panel4.Controls.Add(this.label4);
            this.panel4.Controls.Add(this.btn_EODstatus);
            this.panel4.Location = new System.Drawing.Point(265, 15);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(657, 279);
            this.panel4.TabIndex = 56;
            // 
            // pictureBox10
            // 
            this.pictureBox10.Image = global::ARC_Application.Properties.Resources.Report;
            this.pictureBox10.Location = new System.Drawing.Point(75, 194);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(48, 48);
            this.pictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox10.TabIndex = 70;
            this.pictureBox10.TabStop = false;
            // 
            // pictureBox9
            // 
            this.pictureBox9.Image = global::ARC_Application.Properties.Resources.View291;
            this.pictureBox9.Location = new System.Drawing.Point(75, 85);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(32, 32);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox9.TabIndex = 69;
            this.pictureBox9.TabStop = false;
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = global::ARC_Application.Properties.Resources.clock_icon;
            this.pictureBox8.Location = new System.Drawing.Point(75, 11);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(32, 32);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox8.TabIndex = 68;
            this.pictureBox8.TabStop = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = global::ARC_Application.Properties.Resources.data_chooser_icon;
            this.pictureBox7.Location = new System.Drawing.Point(329, 142);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(24, 24);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox7.TabIndex = 67;
            this.pictureBox7.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global::ARC_Application.Properties.Resources.data_chooser_icon;
            this.pictureBox6.Location = new System.Drawing.Point(329, 89);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(24, 24);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox6.TabIndex = 66;
            this.pictureBox6.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(149, 210);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(86, 15);
            this.label3.TabIndex = 65;
            this.label3.Text = "Audit Report";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(149, 90);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(104, 15);
            this.label2.TabIndex = 64;
            this.label2.Text = "Monthly Report";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(149, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(130, 15);
            this.label1.TabIndex = 63;
            this.label1.Text = "Daily Status Report";
            // 
            // To_Date
            // 
            this.To_Date.CustomFormat = "dd/MM/yyyy";
            this.To_Date.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.To_Date.Location = new System.Drawing.Point(402, 142);
            this.To_Date.Name = "To_Date";
            this.To_Date.Size = new System.Drawing.Size(106, 23);
            this.To_Date.TabIndex = 62;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(353, 147);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(27, 16);
            this.label5.TabIndex = 61;
            this.label5.Text = "To";
            // 
            // btn_GenerateReport
            // 
            this.btn_GenerateReport.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btn_GenerateReport.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_GenerateReport.ForeColor = System.Drawing.Color.White;
            this.btn_GenerateReport.Location = new System.Drawing.Point(329, 183);
            this.btn_GenerateReport.Name = "btn_GenerateReport";
            this.btn_GenerateReport.Size = new System.Drawing.Size(136, 28);
            this.btn_GenerateReport.TabIndex = 60;
            this.btn_GenerateReport.Text = "Generate Report";
            this.btn_GenerateReport.UseVisualStyleBackColor = false;
            this.btn_GenerateReport.Click += new System.EventHandler(this.btn_GenerateReport_Click_2);
            // 
            // btn_AuditReport
            // 
            this.btn_AuditReport.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btn_AuditReport.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_AuditReport.ForeColor = System.Drawing.Color.White;
            this.btn_AuditReport.Location = new System.Drawing.Point(329, 223);
            this.btn_AuditReport.Name = "btn_AuditReport";
            this.btn_AuditReport.Size = new System.Drawing.Size(122, 28);
            this.btn_AuditReport.TabIndex = 59;
            this.btn_AuditReport.Text = "Audit Report";
            this.btn_AuditReport.UseVisualStyleBackColor = false;
            // 
            // From_Date
            // 
            this.From_Date.CustomFormat = "dd/MM/yyyy";
            this.From_Date.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.From_Date.Location = new System.Drawing.Point(402, 85);
            this.From_Date.Name = "From_Date";
            this.From_Date.Size = new System.Drawing.Size(106, 23);
            this.From_Date.TabIndex = 58;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(353, 89);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(43, 16);
            this.label4.TabIndex = 57;
            this.label4.Text = "From";
            // 
            // btn_EODstatus
            // 
            this.btn_EODstatus.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btn_EODstatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_EODstatus.ForeColor = System.Drawing.Color.White;
            this.btn_EODstatus.Location = new System.Drawing.Point(329, 15);
            this.btn_EODstatus.Name = "btn_EODstatus";
            this.btn_EODstatus.Size = new System.Drawing.Size(136, 28);
            this.btn_EODstatus.TabIndex = 56;
            this.btn_EODstatus.Text = "EOD Status";
            this.btn_EODstatus.UseVisualStyleBackColor = false;
            this.btn_EODstatus.Click += new System.EventHandler(this.btn_EODstatus_Click_1);
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::ARC_Application.Properties.Resources.Report21;
            this.pictureBox5.Location = new System.Drawing.Point(6, -3);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(22, 25);
            this.pictureBox5.TabIndex = 49;
            this.pictureBox5.TabStop = false;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.panel3);
            this.tabPage4.ImageKey = "UserMgt";
            this.tabPage4.Location = new System.Drawing.Point(4, 24);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(1173, 672);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "User Management";
            this.tabPage4.ToolTipText = "UserManagement";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(92)))), ((int)(((byte)(132)))));
            this.panel3.Controls.Add(this.btn_Clear);
            this.panel3.Controls.Add(this.Btn_PageAccess_Rev);
            this.panel3.Controls.Add(this.Btn_PageAccess_Frd);
            this.panel3.Controls.Add(this.Lst_PageAccess_02);
            this.panel3.Controls.Add(this.label9);
            this.panel3.Controls.Add(this.Btn_Countr_Rev);
            this.panel3.Controls.Add(this.Btn_Countr_Frd);
            this.panel3.Controls.Add(this.Lst_Countries_02);
            this.panel3.Controls.Add(this.Lst_Countries_01);
            this.panel3.Controls.Add(this.label11);
            this.panel3.Controls.Add(this.lbl_Prdt);
            this.panel3.Controls.Add(this.Btn_Prdt_Rev);
            this.panel3.Controls.Add(this.Btn_Prdt_Fwd);
            this.panel3.Controls.Add(this.Lst_Prdt_02);
            this.panel3.Controls.Add(this.Lst_Prdt_01);
            this.panel3.Controls.Add(this.Lst_PageAccess_01);
            this.panel3.Controls.Add(this.Btn_App_Rev01);
            this.panel3.Controls.Add(this.Btn_App_Frd01);
            this.panel3.Controls.Add(this.Lst_Application_02);
            this.panel3.Controls.Add(this.Lst_Application_01);
            this.panel3.Controls.Add(this.lbl_Appl);
            this.panel3.Controls.Add(this.pictureBox12);
            this.panel3.Controls.Add(this.pictureBox11);
            this.panel3.Controls.Add(this.UserName);
            this.panel3.Controls.Add(this.ManagerID);
            this.panel3.Controls.Add(this.label10);
            this.panel3.Controls.Add(this.label6);
            this.panel3.Controls.Add(this.pictureBox4);
            this.panel3.Controls.Add(this.pictureBox3);
            this.panel3.Controls.Add(this.Acc_Type);
            this.panel3.Controls.Add(this.PSID);
            this.panel3.Controls.Add(this.label7);
            this.panel3.Controls.Add(this.btn_DeleteUser);
            this.panel3.Controls.Add(this.label8);
            this.panel3.Controls.Add(this.btn_EditUser);
            this.panel3.Controls.Add(this.btn_AddUser);
            this.panel3.ForeColor = System.Drawing.Color.White;
            this.panel3.Location = new System.Drawing.Point(3, 3);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1167, 394);
            this.panel3.TabIndex = 57;
            // 
            // btn_Clear
            // 
            this.btn_Clear.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btn_Clear.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Clear.ForeColor = System.Drawing.Color.White;
            this.btn_Clear.Location = new System.Drawing.Point(632, 343);
            this.btn_Clear.Name = "btn_Clear";
            this.btn_Clear.Size = new System.Drawing.Size(141, 28);
            this.btn_Clear.TabIndex = 99;
            this.btn_Clear.Text = "Clear";
            this.btn_Clear.UseVisualStyleBackColor = false;
            this.btn_Clear.Click += new System.EventHandler(this.btn_Clear_Click);
            // 
            // Btn_PageAccess_Rev
            // 
            this.Btn_PageAccess_Rev.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Btn_PageAccess_Rev.Location = new System.Drawing.Point(407, 270);
            this.Btn_PageAccess_Rev.Name = "Btn_PageAccess_Rev";
            this.Btn_PageAccess_Rev.Size = new System.Drawing.Size(39, 23);
            this.Btn_PageAccess_Rev.TabIndex = 98;
            this.Btn_PageAccess_Rev.Text = "<<";
            this.Btn_PageAccess_Rev.UseVisualStyleBackColor = false;
            this.Btn_PageAccess_Rev.Click += new System.EventHandler(this.Btn_PageAccess_Rev_Click);
            // 
            // Btn_PageAccess_Frd
            // 
            this.Btn_PageAccess_Frd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Btn_PageAccess_Frd.Location = new System.Drawing.Point(407, 241);
            this.Btn_PageAccess_Frd.Name = "Btn_PageAccess_Frd";
            this.Btn_PageAccess_Frd.Size = new System.Drawing.Size(39, 23);
            this.Btn_PageAccess_Frd.TabIndex = 97;
            this.Btn_PageAccess_Frd.Text = ">>";
            this.Btn_PageAccess_Frd.UseVisualStyleBackColor = false;
            this.Btn_PageAccess_Frd.Click += new System.EventHandler(this.Btn_PageAccess_Frd_Click);
            // 
            // Lst_PageAccess_02
            // 
            this.Lst_PageAccess_02.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(92)))), ((int)(((byte)(132)))));
            this.Lst_PageAccess_02.ForeColor = System.Drawing.Color.White;
            this.Lst_PageAccess_02.FormattingEnabled = true;
            this.Lst_PageAccess_02.ItemHeight = 15;
            this.Lst_PageAccess_02.Location = new System.Drawing.Point(452, 210);
            this.Lst_PageAccess_02.Name = "Lst_PageAccess_02";
            this.Lst_PageAccess_02.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.Lst_PageAccess_02.Size = new System.Drawing.Size(125, 109);
            this.Lst_PageAccess_02.TabIndex = 96;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(131, 249);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(88, 15);
            this.label9.TabIndex = 95;
            this.label9.Text = "Page Access";
            // 
            // Btn_Countr_Rev
            // 
            this.Btn_Countr_Rev.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Btn_Countr_Rev.Location = new System.Drawing.Point(836, 270);
            this.Btn_Countr_Rev.Name = "Btn_Countr_Rev";
            this.Btn_Countr_Rev.Size = new System.Drawing.Size(39, 23);
            this.Btn_Countr_Rev.TabIndex = 94;
            this.Btn_Countr_Rev.Text = "<<";
            this.Btn_Countr_Rev.UseVisualStyleBackColor = false;
            this.Btn_Countr_Rev.Click += new System.EventHandler(this.Btn_Countr_Rev_Click);
            // 
            // Btn_Countr_Frd
            // 
            this.Btn_Countr_Frd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Btn_Countr_Frd.Location = new System.Drawing.Point(836, 241);
            this.Btn_Countr_Frd.Name = "Btn_Countr_Frd";
            this.Btn_Countr_Frd.Size = new System.Drawing.Size(39, 23);
            this.Btn_Countr_Frd.TabIndex = 93;
            this.Btn_Countr_Frd.Text = ">>";
            this.Btn_Countr_Frd.UseVisualStyleBackColor = false;
            this.Btn_Countr_Frd.Click += new System.EventHandler(this.Btn_Countr_Frd_Click);
            // 
            // Lst_Countries_02
            // 
            this.Lst_Countries_02.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(92)))), ((int)(((byte)(132)))));
            this.Lst_Countries_02.ForeColor = System.Drawing.Color.White;
            this.Lst_Countries_02.FormattingEnabled = true;
            this.Lst_Countries_02.ItemHeight = 15;
            this.Lst_Countries_02.Location = new System.Drawing.Point(881, 210);
            this.Lst_Countries_02.Name = "Lst_Countries_02";
            this.Lst_Countries_02.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.Lst_Countries_02.Size = new System.Drawing.Size(125, 109);
            this.Lst_Countries_02.TabIndex = 92;
            // 
            // Lst_Countries_01
            // 
            this.Lst_Countries_01.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(92)))), ((int)(((byte)(132)))));
            this.Lst_Countries_01.ForeColor = System.Drawing.Color.White;
            this.Lst_Countries_01.FormattingEnabled = true;
            this.Lst_Countries_01.ItemHeight = 15;
            this.Lst_Countries_01.Location = new System.Drawing.Point(705, 210);
            this.Lst_Countries_01.Name = "Lst_Countries_01";
            this.Lst_Countries_01.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.Lst_Countries_01.Size = new System.Drawing.Size(125, 109);
            this.Lst_Countries_01.TabIndex = 91;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(583, 249);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(68, 15);
            this.label11.TabIndex = 90;
            this.label11.Text = "Countries";
            // 
            // lbl_Prdt
            // 
            this.lbl_Prdt.AutoSize = true;
            this.lbl_Prdt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Prdt.ForeColor = System.Drawing.Color.White;
            this.lbl_Prdt.Location = new System.Drawing.Point(583, 128);
            this.lbl_Prdt.Name = "lbl_Prdt";
            this.lbl_Prdt.Size = new System.Drawing.Size(63, 15);
            this.lbl_Prdt.TabIndex = 89;
            this.lbl_Prdt.Text = "Products";
            // 
            // Btn_Prdt_Rev
            // 
            this.Btn_Prdt_Rev.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Btn_Prdt_Rev.Location = new System.Drawing.Point(836, 154);
            this.Btn_Prdt_Rev.Name = "Btn_Prdt_Rev";
            this.Btn_Prdt_Rev.Size = new System.Drawing.Size(39, 23);
            this.Btn_Prdt_Rev.TabIndex = 88;
            this.Btn_Prdt_Rev.Text = "<<";
            this.Btn_Prdt_Rev.UseVisualStyleBackColor = false;
            this.Btn_Prdt_Rev.Click += new System.EventHandler(this.Btn_Prdt_Rev_Click);
            // 
            // Btn_Prdt_Fwd
            // 
            this.Btn_Prdt_Fwd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Btn_Prdt_Fwd.Location = new System.Drawing.Point(836, 125);
            this.Btn_Prdt_Fwd.Name = "Btn_Prdt_Fwd";
            this.Btn_Prdt_Fwd.Size = new System.Drawing.Size(39, 23);
            this.Btn_Prdt_Fwd.TabIndex = 87;
            this.Btn_Prdt_Fwd.Text = ">>";
            this.Btn_Prdt_Fwd.UseVisualStyleBackColor = false;
            this.Btn_Prdt_Fwd.Click += new System.EventHandler(this.Btn_Prdt_Fwd_Click);
            // 
            // Lst_Prdt_02
            // 
            this.Lst_Prdt_02.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(92)))), ((int)(((byte)(132)))));
            this.Lst_Prdt_02.ForeColor = System.Drawing.Color.White;
            this.Lst_Prdt_02.FormattingEnabled = true;
            this.Lst_Prdt_02.ItemHeight = 15;
            this.Lst_Prdt_02.Location = new System.Drawing.Point(881, 95);
            this.Lst_Prdt_02.Name = "Lst_Prdt_02";
            this.Lst_Prdt_02.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.Lst_Prdt_02.Size = new System.Drawing.Size(125, 109);
            this.Lst_Prdt_02.TabIndex = 86;
            // 
            // Lst_Prdt_01
            // 
            this.Lst_Prdt_01.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(92)))), ((int)(((byte)(132)))));
            this.Lst_Prdt_01.ForeColor = System.Drawing.Color.White;
            this.Lst_Prdt_01.FormattingEnabled = true;
            this.Lst_Prdt_01.ItemHeight = 15;
            this.Lst_Prdt_01.Location = new System.Drawing.Point(703, 95);
            this.Lst_Prdt_01.Name = "Lst_Prdt_01";
            this.Lst_Prdt_01.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.Lst_Prdt_01.Size = new System.Drawing.Size(125, 109);
            this.Lst_Prdt_01.TabIndex = 85;
            // 
            // Lst_PageAccess_01
            // 
            this.Lst_PageAccess_01.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(92)))), ((int)(((byte)(132)))));
            this.Lst_PageAccess_01.ForeColor = System.Drawing.Color.White;
            this.Lst_PageAccess_01.FormattingEnabled = true;
            this.Lst_PageAccess_01.ItemHeight = 15;
            this.Lst_PageAccess_01.Location = new System.Drawing.Point(279, 210);
            this.Lst_PageAccess_01.Name = "Lst_PageAccess_01";
            this.Lst_PageAccess_01.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.Lst_PageAccess_01.Size = new System.Drawing.Size(125, 109);
            this.Lst_PageAccess_01.TabIndex = 84;
            // 
            // Btn_App_Rev01
            // 
            this.Btn_App_Rev01.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Btn_App_Rev01.Location = new System.Drawing.Point(407, 154);
            this.Btn_App_Rev01.Name = "Btn_App_Rev01";
            this.Btn_App_Rev01.Size = new System.Drawing.Size(39, 23);
            this.Btn_App_Rev01.TabIndex = 83;
            this.Btn_App_Rev01.Text = "<<";
            this.Btn_App_Rev01.UseVisualStyleBackColor = false;
            this.Btn_App_Rev01.Click += new System.EventHandler(this.Btn_App_Rev01_Click);
            // 
            // Btn_App_Frd01
            // 
            this.Btn_App_Frd01.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Btn_App_Frd01.ForeColor = System.Drawing.Color.White;
            this.Btn_App_Frd01.Location = new System.Drawing.Point(407, 120);
            this.Btn_App_Frd01.Name = "Btn_App_Frd01";
            this.Btn_App_Frd01.Size = new System.Drawing.Size(39, 23);
            this.Btn_App_Frd01.TabIndex = 82;
            this.Btn_App_Frd01.Text = ">>";
            this.Btn_App_Frd01.UseVisualStyleBackColor = false;
            this.Btn_App_Frd01.Click += new System.EventHandler(this.Btn_App_Frd01_Click);
            // 
            // Lst_Application_02
            // 
            this.Lst_Application_02.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(92)))), ((int)(((byte)(132)))));
            this.Lst_Application_02.ForeColor = System.Drawing.Color.White;
            this.Lst_Application_02.FormattingEnabled = true;
            this.Lst_Application_02.ItemHeight = 15;
            this.Lst_Application_02.Location = new System.Drawing.Point(454, 95);
            this.Lst_Application_02.Name = "Lst_Application_02";
            this.Lst_Application_02.Size = new System.Drawing.Size(123, 109);
            this.Lst_Application_02.TabIndex = 81;
            // 
            // Lst_Application_01
            // 
            this.Lst_Application_01.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(92)))), ((int)(((byte)(132)))));
            this.Lst_Application_01.ForeColor = System.Drawing.Color.White;
            this.Lst_Application_01.FormattingEnabled = true;
            this.Lst_Application_01.ItemHeight = 15;
            this.Lst_Application_01.Location = new System.Drawing.Point(279, 95);
            this.Lst_Application_01.Name = "Lst_Application_01";
            this.Lst_Application_01.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.Lst_Application_01.Size = new System.Drawing.Size(125, 109);
            this.Lst_Application_01.TabIndex = 80;
            // 
            // lbl_Appl
            // 
            this.lbl_Appl.AutoSize = true;
            this.lbl_Appl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Appl.ForeColor = System.Drawing.Color.White;
            this.lbl_Appl.Location = new System.Drawing.Point(138, 133);
            this.lbl_Appl.Name = "lbl_Appl";
            this.lbl_Appl.Size = new System.Drawing.Size(78, 15);
            this.lbl_Appl.TabIndex = 79;
            this.lbl_Appl.Text = "Application";
            // 
            // pictureBox12
            // 
            this.pictureBox12.Image = global::ARC_Application.Properties.Resources.admin_icon1;
            this.pictureBox12.Location = new System.Drawing.Point(514, 47);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(31, 30);
            this.pictureBox12.TabIndex = 78;
            this.pictureBox12.TabStop = false;
            // 
            // pictureBox11
            // 
            this.pictureBox11.Image = global::ARC_Application.Properties.Resources.User11;
            this.pictureBox11.Location = new System.Drawing.Point(514, 7);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(31, 30);
            this.pictureBox11.TabIndex = 77;
            this.pictureBox11.TabStop = false;
            // 
            // UserName
            // 
            this.UserName.Location = new System.Drawing.Point(703, 11);
            this.UserName.Name = "UserName";
            this.UserName.Size = new System.Drawing.Size(203, 23);
            this.UserName.TabIndex = 75;
            // 
            // ManagerID
            // 
            this.ManagerID.Location = new System.Drawing.Point(703, 52);
            this.ManagerID.Name = "ManagerID";
            this.ManagerID.Size = new System.Drawing.Size(203, 23);
            this.ManagerID.TabIndex = 74;
            this.ManagerID.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ManagerID_KeyPress);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(551, 54);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(132, 15);
            this.label10.TabIndex = 73;
            this.label10.Text = "Line Manager PSID";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(551, 13);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(79, 15);
            this.label6.TabIndex = 69;
            this.label6.Text = "User Name";
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::ARC_Application.Properties.Resources.signature_icon;
            this.pictureBox4.Location = new System.Drawing.Point(71, 47);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(31, 30);
            this.pictureBox4.TabIndex = 68;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::ARC_Application.Properties.Resources.Keysicon;
            this.pictureBox3.Location = new System.Drawing.Point(71, 7);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(31, 30);
            this.pictureBox3.TabIndex = 67;
            this.pictureBox3.TabStop = false;
            // 
            // Acc_Type
            // 
            this.Acc_Type.FormattingEnabled = true;
            this.Acc_Type.Items.AddRange(new object[] {
            "--SELECT--",
            "DataUpload User",
            "DataUpload Admin",
            "DataUpload Admin/DataUpload User"});
            this.Acc_Type.Location = new System.Drawing.Point(283, 47);
            this.Acc_Type.Name = "Acc_Type";
            this.Acc_Type.Size = new System.Drawing.Size(203, 23);
            this.Acc_Type.TabIndex = 66;
            // 
            // PSID
            // 
            this.PSID.Location = new System.Drawing.Point(283, 7);
            this.PSID.Name = "PSID";
            this.PSID.Size = new System.Drawing.Size(203, 23);
            this.PSID.TabIndex = 65;
            this.PSID.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.PSID_KeyPress);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(131, 54);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(85, 15);
            this.label7.TabIndex = 64;
            this.label7.Text = "Access Type";
            // 
            // btn_DeleteUser
            // 
            this.btn_DeleteUser.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btn_DeleteUser.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_DeleteUser.ForeColor = System.Drawing.Color.White;
            this.btn_DeleteUser.Location = new System.Drawing.Point(368, 343);
            this.btn_DeleteUser.Name = "btn_DeleteUser";
            this.btn_DeleteUser.Size = new System.Drawing.Size(150, 28);
            this.btn_DeleteUser.TabIndex = 48;
            this.btn_DeleteUser.Text = "Delete User";
            this.btn_DeleteUser.UseVisualStyleBackColor = false;
            this.btn_DeleteUser.Click += new System.EventHandler(this.btn_DeleteUser_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(131, 13);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(39, 15);
            this.label8.TabIndex = 63;
            this.label8.Text = "PSID";
            // 
            // btn_EditUser
            // 
            this.btn_EditUser.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btn_EditUser.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_EditUser.ForeColor = System.Drawing.Color.White;
            this.btn_EditUser.Location = new System.Drawing.Point(865, 343);
            this.btn_EditUser.Name = "btn_EditUser";
            this.btn_EditUser.Size = new System.Drawing.Size(141, 28);
            this.btn_EditUser.TabIndex = 47;
            this.btn_EditUser.Text = "Edit User";
            this.btn_EditUser.UseVisualStyleBackColor = false;
            this.btn_EditUser.Click += new System.EventHandler(this.btn_EditUser_Click);
            // 
            // btn_AddUser
            // 
            this.btn_AddUser.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btn_AddUser.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_AddUser.ForeColor = System.Drawing.Color.White;
            this.btn_AddUser.Location = new System.Drawing.Point(134, 343);
            this.btn_AddUser.Name = "btn_AddUser";
            this.btn_AddUser.Size = new System.Drawing.Size(127, 28);
            this.btn_AddUser.TabIndex = 46;
            this.btn_AddUser.Text = "Add User";
            this.btn_AddUser.UseVisualStyleBackColor = false;
            this.btn_AddUser.Click += new System.EventHandler(this.btn_AddUser_Click);
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.btnEditUser);
            this.tabPage5.Controls.Add(this.cmbAccessType);
            this.tabPage5.Controls.Add(this.btnClear);
            this.tabPage5.Controls.Add(this.btnSearch);
            this.tabPage5.Controls.Add(this.dataGridView);
            this.tabPage5.Controls.Add(this.btnAddUser);
            this.tabPage5.Controls.Add(this.btnDeleteUser);
            this.tabPage5.Controls.Add(this.label19);
            this.tabPage5.Controls.Add(this.label18);
            this.tabPage5.Controls.Add(this.label17);
            this.tabPage5.Controls.Add(this.label16);
            this.tabPage5.Controls.Add(this.chklstPageAccess);
            this.tabPage5.Controls.Add(this.chklstCountries);
            this.tabPage5.Controls.Add(this.chklstProduct);
            this.tabPage5.Controls.Add(this.chklstApplication);
            this.tabPage5.Controls.Add(this.txtLineManager);
            this.tabPage5.Controls.Add(this.txtUserName);
            this.tabPage5.Controls.Add(this.txtUserPSID);
            this.tabPage5.Controls.Add(this.label15);
            this.tabPage5.Controls.Add(this.label14);
            this.tabPage5.Controls.Add(this.label13);
            this.tabPage5.Controls.Add(this.label12);
            this.tabPage5.ImageKey = "Recon Details";
            this.tabPage5.Location = new System.Drawing.Point(4, 24);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(1173, 672);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "User_Management-Test";
            this.tabPage5.ToolTipText = "Recon Details";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // btnEditUser
            // 
            this.btnEditUser.Location = new System.Drawing.Point(575, 267);
            this.btnEditUser.Name = "btnEditUser";
            this.btnEditUser.Size = new System.Drawing.Size(96, 23);
            this.btnEditUser.TabIndex = 116;
            this.btnEditUser.Text = "EDIT USER";
            this.btnEditUser.UseVisualStyleBackColor = true;
            this.btnEditUser.Click += new System.EventHandler(this.btnEditUser_Click);
            // 
            // cmbAccessType
            // 
            this.cmbAccessType.FormattingEnabled = true;
            this.cmbAccessType.Items.AddRange(new object[] {
            "--SELECT--",
            "DataUpload User",
            "DataUpload Admin",
            "DataUpload Admin/DataUpload User"});
            this.cmbAccessType.Location = new System.Drawing.Point(268, 71);
            this.cmbAccessType.Name = "cmbAccessType";
            this.cmbAccessType.Size = new System.Drawing.Size(203, 23);
            this.cmbAccessType.TabIndex = 115;
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(724, 267);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(75, 23);
            this.btnClear.TabIndex = 114;
            this.btnClear.Text = "CLEAR";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(432, 267);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(75, 23);
            this.btnSearch.TabIndex = 113;
            this.btnSearch.Text = "SEARCH";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // dataGridView
            // 
            this.dataGridView.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView.GridColor = System.Drawing.Color.Blue;
            this.dataGridView.Location = new System.Drawing.Point(162, 317);
            this.dataGridView.Name = "dataGridView";
            this.dataGridView.Size = new System.Drawing.Size(700, 150);
            this.dataGridView.TabIndex = 112;
            // 
            // btnAddUser
            // 
            this.btnAddUser.Location = new System.Drawing.Point(162, 267);
            this.btnAddUser.Name = "btnAddUser";
            this.btnAddUser.Size = new System.Drawing.Size(75, 23);
            this.btnAddUser.TabIndex = 111;
            this.btnAddUser.Text = "ADD USER";
            this.btnAddUser.UseVisualStyleBackColor = true;
            this.btnAddUser.Click += new System.EventHandler(this.btnAddUser_Click);
            // 
            // btnDeleteUser
            // 
            this.btnDeleteUser.Location = new System.Drawing.Point(286, 267);
            this.btnDeleteUser.Name = "btnDeleteUser";
            this.btnDeleteUser.Size = new System.Drawing.Size(96, 23);
            this.btnDeleteUser.TabIndex = 110;
            this.btnDeleteUser.Text = "DELETE USER";
            this.btnDeleteUser.UseVisualStyleBackColor = true;
            this.btnDeleteUser.Click += new System.EventHandler(this.btnDeleteUser_Click);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(792, 99);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(78, 15);
            this.label19.TabIndex = 108;
            this.label19.Text = "Page Access";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(526, 109);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(65, 15);
            this.label18.TabIndex = 107;
            this.label18.Text = "Countries";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(83, 108);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(61, 15);
            this.label17.TabIndex = 106;
            this.label17.Text = "Products";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(298, 109);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(76, 15);
            this.label16.TabIndex = 105;
            this.label16.Text = "Application";
            // 
            // chklstPageAccess
            // 
            this.chklstPageAccess.FormattingEnabled = true;
            this.chklstPageAccess.Location = new System.Drawing.Point(758, 136);
            this.chklstPageAccess.Name = "chklstPageAccess";
            this.chklstPageAccess.Size = new System.Drawing.Size(153, 112);
            this.chklstPageAccess.TabIndex = 104;
            // 
            // chklstCountries
            // 
            this.chklstCountries.CheckOnClick = true;
            this.chklstCountries.FormattingEnabled = true;
            this.chklstCountries.Location = new System.Drawing.Point(497, 136);
            this.chklstCountries.Name = "chklstCountries";
            this.chklstCountries.Size = new System.Drawing.Size(153, 112);
            this.chklstCountries.TabIndex = 103;
            // 
            // chklstProduct
            // 
            this.chklstProduct.CheckOnClick = true;
            this.chklstProduct.FormattingEnabled = true;
            this.chklstProduct.Location = new System.Drawing.Point(35, 136);
            this.chklstProduct.Name = "chklstProduct";
            this.chklstProduct.Size = new System.Drawing.Size(153, 112);
            this.chklstProduct.TabIndex = 102;
            // 
            // chklstApplication
            // 
            this.chklstApplication.FormattingEnabled = true;
            this.chklstApplication.Location = new System.Drawing.Point(268, 136);
            this.chklstApplication.Name = "chklstApplication";
            this.chklstApplication.Size = new System.Drawing.Size(153, 112);
            this.chklstApplication.TabIndex = 101;
            // 
            // txtLineManager
            // 
            this.txtLineManager.Location = new System.Drawing.Point(724, 71);
            this.txtLineManager.Name = "txtLineManager";
            this.txtLineManager.Size = new System.Drawing.Size(100, 23);
            this.txtLineManager.TabIndex = 6;
            // 
            // txtUserName
            // 
            this.txtUserName.Location = new System.Drawing.Point(728, 19);
            this.txtUserName.Name = "txtUserName";
            this.txtUserName.Size = new System.Drawing.Size(100, 23);
            this.txtUserName.TabIndex = 5;
            // 
            // txtUserPSID
            // 
            this.txtUserPSID.Location = new System.Drawing.Point(268, 16);
            this.txtUserPSID.Name = "txtUserPSID";
            this.txtUserPSID.Size = new System.Drawing.Size(100, 23);
            this.txtUserPSID.TabIndex = 4;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(141, 19);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(33, 15);
            this.label15.TabIndex = 3;
            this.label15.Text = "PSID";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(584, 74);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(110, 15);
            this.label14.TabIndex = 2;
            this.label14.Text = "Line Manager PSID";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(141, 74);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(78, 15);
            this.label13.TabIndex = 1;
            this.label13.Text = "Access_Type";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(584, 19);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(69, 15);
            this.label12.TabIndex = 0;
            this.label12.Text = "User_Name";
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.txt_HolidayReson);
            this.tabPage6.Controls.Add(this.label22);
            this.tabPage6.Controls.Add(this.dtPicker_From);
            this.tabPage6.Controls.Add(this.label21);
            this.tabPage6.Controls.Add(this.btn_DeleteCalendar);
            this.tabPage6.Controls.Add(this.btn_AddCalendar);
            this.tabPage6.Controls.Add(this.DGV_Holiday);
            this.tabPage6.Controls.Add(this.btn_EditCalendar);
            this.tabPage6.Controls.Add(this.btn_ViewCalendar);
            this.tabPage6.Controls.Add(this.label20);
            this.tabPage6.Controls.Add(this.cmb_Holiday);
            this.tabPage6.Location = new System.Drawing.Point(4, 24);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Size = new System.Drawing.Size(1173, 672);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "Holiday Calendar";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // txt_HolidayReson
            // 
            this.txt_HolidayReson.Location = new System.Drawing.Point(314, 61);
            this.txt_HolidayReson.Name = "txt_HolidayReson";
            this.txt_HolidayReson.Size = new System.Drawing.Size(271, 23);
            this.txt_HolidayReson.TabIndex = 80;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(219, 64);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(89, 15);
            this.label22.TabIndex = 79;
            this.label22.Text = "Holiday Reason";
            // 
            // dtPicker_From
            // 
            this.dtPicker_From.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtPicker_From.Location = new System.Drawing.Point(88, 60);
            this.dtPicker_From.Name = "dtPicker_From";
            this.dtPicker_From.Size = new System.Drawing.Size(110, 23);
            this.dtPicker_From.TabIndex = 77;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(14, 64);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(68, 15);
            this.label21.TabIndex = 76;
            this.label21.Text = "Date Range";
            // 
            // btn_DeleteCalendar
            // 
            this.btn_DeleteCalendar.Location = new System.Drawing.Point(871, 60);
            this.btn_DeleteCalendar.Name = "btn_DeleteCalendar";
            this.btn_DeleteCalendar.Size = new System.Drawing.Size(125, 23);
            this.btn_DeleteCalendar.TabIndex = 75;
            this.btn_DeleteCalendar.Text = "Delete Calendar";
            this.btn_DeleteCalendar.UseVisualStyleBackColor = true;
            this.btn_DeleteCalendar.Click += new System.EventHandler(this.btn_DeleteCalendar_Click);
            // 
            // btn_AddCalendar
            // 
            this.btn_AddCalendar.Location = new System.Drawing.Point(740, 60);
            this.btn_AddCalendar.Name = "btn_AddCalendar";
            this.btn_AddCalendar.Size = new System.Drawing.Size(125, 23);
            this.btn_AddCalendar.TabIndex = 74;
            this.btn_AddCalendar.Text = "Add Calendar";
            this.btn_AddCalendar.UseVisualStyleBackColor = true;
            this.btn_AddCalendar.Click += new System.EventHandler(this.btn_AddCalendar_Click);
            // 
            // DGV_Holiday
            // 
            this.DGV_Holiday.AllowUserToAddRows = false;
            this.DGV_Holiday.AllowUserToDeleteRows = false;
            this.DGV_Holiday.AllowUserToResizeRows = false;
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle10.BackColor = System.Drawing.SystemColors.Info;
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.Color.Transparent;
            dataGridViewCellStyle10.SelectionForeColor = System.Drawing.Color.Black;
            this.DGV_Holiday.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle10;
            this.DGV_Holiday.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DGV_Holiday.BackgroundColor = System.Drawing.Color.White;
            this.DGV_Holiday.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.DGV_Holiday.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Sunken;
            this.DGV_Holiday.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle11.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle11.Font = new System.Drawing.Font("Cambria", 9.75F);
            dataGridViewCellStyle11.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle11.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DGV_Holiday.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle11;
            this.DGV_Holiday.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle12.BackColor = System.Drawing.Color.MintCream;
            dataGridViewCellStyle12.Font = new System.Drawing.Font("Cambria", 9.75F);
            dataGridViewCellStyle12.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.DGV_Holiday.DefaultCellStyle = dataGridViewCellStyle12;
            this.DGV_Holiday.GridColor = System.Drawing.Color.Blue;
            this.DGV_Holiday.Location = new System.Drawing.Point(5, 104);
            this.DGV_Holiday.Name = "DGV_Holiday";
            this.DGV_Holiday.ReadOnly = true;
            this.DGV_Holiday.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.DGV_Holiday.RowHeadersVisible = false;
            this.DGV_Holiday.RowHeadersWidth = 31;
            this.DGV_Holiday.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.DGV_Holiday.Size = new System.Drawing.Size(1161, 329);
            this.DGV_Holiday.TabIndex = 50;
            this.DGV_Holiday.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DGV_Holiday_CellContentClick);
            // 
            // btn_EditCalendar
            // 
            this.btn_EditCalendar.Location = new System.Drawing.Point(609, 60);
            this.btn_EditCalendar.Name = "btn_EditCalendar";
            this.btn_EditCalendar.Size = new System.Drawing.Size(125, 23);
            this.btn_EditCalendar.TabIndex = 27;
            this.btn_EditCalendar.Text = "Update Calendar";
            this.btn_EditCalendar.UseVisualStyleBackColor = true;
            this.btn_EditCalendar.Click += new System.EventHandler(this.btn_EditCalendar_Click);
            // 
            // btn_ViewCalendar
            // 
            this.btn_ViewCalendar.Location = new System.Drawing.Point(358, 17);
            this.btn_ViewCalendar.Name = "btn_ViewCalendar";
            this.btn_ViewCalendar.Size = new System.Drawing.Size(125, 23);
            this.btn_ViewCalendar.TabIndex = 26;
            this.btn_ViewCalendar.Text = "View Calendar";
            this.btn_ViewCalendar.UseVisualStyleBackColor = true;
            this.btn_ViewCalendar.Click += new System.EventHandler(this.btn_ViewCalendar_Click);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(14, 20);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(51, 15);
            this.label20.TabIndex = 22;
            this.label20.Text = "Country";
            // 
            // cmb_Holiday
            // 
            this.cmb_Holiday.FormattingEnabled = true;
            this.cmb_Holiday.Location = new System.Drawing.Point(71, 17);
            this.cmb_Holiday.Name = "cmb_Holiday";
            this.cmb_Holiday.Size = new System.Drawing.Size(237, 23);
            this.cmb_Holiday.TabIndex = 21;
            // 
            // TabImages
            // 
            this.TabImages.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("TabImages.ImageStream")));
            this.TabImages.TransparentColor = System.Drawing.Color.Transparent;
            this.TabImages.Images.SetKeyName(0, "Recon Details");
            this.TabImages.Images.SetKeyName(1, "Reports");
            this.TabImages.Images.SetKeyName(2, "UserMgt");
            this.TabImages.Images.SetKeyName(3, "DashBoard");
            this.TabImages.Images.SetKeyName(4, "Configuration");
            // 
            // lnk_Logout
            // 
            this.lnk_Logout.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lnk_Logout.AutoSize = true;
            this.lnk_Logout.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnk_Logout.Location = new System.Drawing.Point(1122, 81);
            this.lnk_Logout.Name = "lnk_Logout";
            this.lnk_Logout.Size = new System.Drawing.Size(53, 15);
            this.lnk_Logout.TabIndex = 47;
            this.lnk_Logout.TabStop = true;
            this.lnk_Logout.Text = "LogOut";
            this.lnk_Logout.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnk_Logout_LinkClicked);
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.lnk_Logout);
            this.panel6.Controls.Add(this.Logout);
            this.panel6.Controls.Add(this.pictureBox2);
            this.panel6.Controls.Add(this.pictureBox1);
            this.panel6.Controls.Add(this.Loading);
            this.panel6.Location = new System.Drawing.Point(3, 3);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(1181, 128);
            this.panel6.TabIndex = 58;
            // 
            // Logout
            // 
            this.Logout.Image = global::ARC_Application.Properties.Resources.Logout1;
            this.Logout.Location = new System.Drawing.Point(1091, 77);
            this.Logout.Name = "Logout";
            this.Logout.Size = new System.Drawing.Size(24, 24);
            this.Logout.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.Logout.TabIndex = 48;
            this.Logout.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(3, 3);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(143, 122);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox2.TabIndex = 6;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(1029, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(146, 65);
            this.pictureBox1.TabIndex = 5;
            this.pictureBox1.TabStop = false;
            // 
            // Loading
            // 
            this.Loading.Image = global::ARC_Application.Properties.Resources.loader;
            this.Loading.Location = new System.Drawing.Point(520, 3);
            this.Loading.Name = "Loading";
            this.Loading.Size = new System.Drawing.Size(180, 118);
            this.Loading.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.Loading.TabIndex = 57;
            this.Loading.TabStop = false;
            this.Loading.Visible = false;
            // 
            // Main_Admin_DashBoard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(1350, 662);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.tabControl1);
            this.Name = "Main_Admin_DashBoard";
            this.Text = "Main_Admin_DashBoard";
            this.Load += new System.EventHandler(this.Main_Admin_DashBoard_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Ref)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.Pnl_User.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DGV_AData)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).EndInit();
            this.tabPage6.ResumeLayout(false);
            this.tabPage6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_Holiday)).EndInit();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Logout)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Loading)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Button Btn_Clr;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.LinkLabel lnk_Logout;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lbl_cntry;
        private System.Windows.Forms.ComboBox cmb_cntry;
        private System.Windows.Forms.Label lbl_Prd;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Panel Pnl_User;
        private System.Windows.Forms.Button Btn_Export;
        private System.Windows.Forms.Button Btn_Excel;
        private System.Windows.Forms.ComboBox cmb_Prdt;
        private System.Windows.Forms.Label lbl_pen;
        private System.Windows.Forms.Label lbl_pen_cnt;
        private System.Windows.Forms.Label lbl_com;
        private System.Windows.Forms.Label lbl_com_cnt;
        private System.Windows.Forms.Label lbl_cnt;
        private System.Windows.Forms.Label lbl_rec;
        private System.Windows.Forms.DataGridView DGV_AData;
        private System.Windows.Forms.ImageList TabImages;
        private System.Windows.Forms.PictureBox Logout;
        private System.Windows.Forms.PictureBox Ref;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker To_Date;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btn_GenerateReport;
        private System.Windows.Forms.Button btn_AuditReport;
        private System.Windows.Forms.DateTimePicker From_Date;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btn_EODstatus;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox Loading;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Button btn_AddUser;
        private System.Windows.Forms.Button btn_DeleteUser;
        private System.Windows.Forms.Button btn_EditUser;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.ComboBox Acc_Type;
        private System.Windows.Forms.TextBox PSID;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.TextBox UserName;
        private System.Windows.Forms.TextBox ManagerID;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button Btn_PageAccess_Rev;
        private System.Windows.Forms.Button Btn_PageAccess_Frd;
        private System.Windows.Forms.ListBox Lst_PageAccess_02;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button Btn_Countr_Rev;
        private System.Windows.Forms.Button Btn_Countr_Frd;
        private System.Windows.Forms.ListBox Lst_Countries_02;
        private System.Windows.Forms.ListBox Lst_Countries_01;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label lbl_Prdt;
        private System.Windows.Forms.Button Btn_Prdt_Rev;
        private System.Windows.Forms.Button Btn_Prdt_Fwd;
        private System.Windows.Forms.ListBox Lst_Prdt_02;
        private System.Windows.Forms.ListBox Lst_Prdt_01;
        private System.Windows.Forms.ListBox Lst_PageAccess_01;
        private System.Windows.Forms.Button Btn_App_Rev01;
        private System.Windows.Forms.Button Btn_App_Frd01;
        private System.Windows.Forms.ListBox Lst_Application_02;
        private System.Windows.Forms.ListBox Lst_Application_01;
        private System.Windows.Forms.Label lbl_Appl;
        private System.Windows.Forms.Button btn_Clear;
        private System.Windows.Forms.TextBox txtLineManager;
        private System.Windows.Forms.TextBox txtUserName;
        private System.Windows.Forms.TextBox txtUserPSID;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.CheckedListBox chklstPageAccess;
        private System.Windows.Forms.CheckedListBox chklstCountries;
        private System.Windows.Forms.CheckedListBox chklstProduct;
        private System.Windows.Forms.CheckedListBox chklstApplication;
        private System.Windows.Forms.Button btnAddUser;
        private System.Windows.Forms.Button btnDeleteUser;
        private System.Windows.Forms.DataGridView dataGridView;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.ComboBox cmbAccessType;
        private System.Windows.Forms.Button btnEditUser;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.Button btn_EditCalendar;
        private System.Windows.Forms.Button btn_ViewCalendar;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.ComboBox cmb_Holiday;
        private System.Windows.Forms.DataGridView DGV_Holiday;
        private System.Windows.Forms.Button btn_AddCalendar;
        private System.Windows.Forms.Button btn_DeleteCalendar;
        private System.Windows.Forms.TextBox txt_HolidayReson;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.DateTimePicker dtPicker_From;
        private System.Windows.Forms.Label label21;

    }
}