﻿namespace ARC_Application
{
    partial class Main_Admin_DashBoard_New
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main_Admin_DashBoard_New));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.dashboard_panel = new System.Windows.Forms.Panel();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.admin_panel = new System.Windows.Forms.Panel();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.txtToAccountNumber = new System.Windows.Forms.TextBox();
            this.btnAccountNumberDelete = new System.Windows.Forms.Button();
            this.lblAccountNumber = new System.Windows.Forms.Label();
            this.txtAccountNumber = new System.Windows.Forms.TextBox();
            this.cbRecon = new System.Windows.Forms.ComboBox();
            this.lblRecon = new System.Windows.Forms.Label();
            this.dgvAccountNumber = new System.Windows.Forms.DataGridView();
            this.btnAccountAdd = new System.Windows.Forms.Button();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.lbl_Country = new System.Windows.Forms.Label();
            this.cbHLLastTransactionDate = new System.Windows.Forms.ComboBox();
            this.cbHLCountry = new System.Windows.Forms.ComboBox();
            this.lbl_Prd = new System.Windows.Forms.Label();
            this.cbHLProduct = new System.Windows.Forms.ComboBox();
            this.btnHLDelete = new System.Windows.Forms.Button();
            this.btnHLSave = new System.Windows.Forms.Button();
            this.lblTransactionDate = new System.Windows.Forms.Label();
            this.cbAlternateSunFileAvailable = new System.Windows.Forms.CheckBox();
            this.cbAlternateSatFileAvailable = new System.Windows.Forms.CheckBox();
            this.cbAlternateWeek = new System.Windows.Forms.CheckBox();
            this.cbHolidayFileAvailable = new System.Windows.Forms.CheckBox();
            this.cbSunFileAvailable = new System.Windows.Forms.CheckBox();
            this.cbSatFileAvailable = new System.Windows.Forms.CheckBox();
            this.cbHolidayReconRun = new System.Windows.Forms.CheckBox();
            this.cbSunReconRun = new System.Windows.Forms.CheckBox();
            this.cbSatFileRun = new System.Windows.Forms.CheckBox();
            this.lblHLRecon = new System.Windows.Forms.Label();
            this.cbHLRecon = new System.Windows.Forms.ComboBox();
            this.TabImages = new System.Windows.Forms.ImageList(this.components);
            this.lnk_Logout = new System.Windows.Forms.LinkLabel();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.panel6 = new System.Windows.Forms.Panel();
            this.Ref = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Loading = new System.Windows.Forms.PictureBox();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAccountNumber)).BeginInit();
            this.tabPage4.SuspendLayout();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Ref)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Loading)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Cursor = System.Windows.Forms.Cursors.Default;
            this.tabControl1.Font = new System.Drawing.Font("Cambria", 9.75F);
            this.tabControl1.ImageList = this.TabImages;
            this.tabControl1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.tabControl1.Location = new System.Drawing.Point(3, 137);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1335, 557);
            this.tabControl1.TabIndex = 7;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.dashboard_panel);
            this.tabPage1.ImageKey = "DashBoard";
            this.tabPage1.Location = new System.Drawing.Point(4, 24);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1327, 529);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "DashBoard";
            this.tabPage1.ToolTipText = "DashBoard";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // dashboard_panel
            // 
            this.dashboard_panel.Location = new System.Drawing.Point(6, 6);
            this.dashboard_panel.Name = "dashboard_panel";
            this.dashboard_panel.Size = new System.Drawing.Size(1309, 519);
            this.dashboard_panel.TabIndex = 1;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.admin_panel);
            this.tabPage2.ImageKey = "Configuration";
            this.tabPage2.Location = new System.Drawing.Point(4, 24);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1337, 529);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Admin Configuration";
            this.tabPage2.ToolTipText = "Configuration Management";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // admin_panel
            // 
            this.admin_panel.Location = new System.Drawing.Point(4, 4);
            this.admin_panel.Name = "admin_panel";
            this.admin_panel.Size = new System.Drawing.Size(1333, 522);
            this.admin_panel.TabIndex = 0;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.txtToAccountNumber);
            this.tabPage3.Controls.Add(this.btnAccountNumberDelete);
            this.tabPage3.Controls.Add(this.lblAccountNumber);
            this.tabPage3.Controls.Add(this.txtAccountNumber);
            this.tabPage3.Controls.Add(this.cbRecon);
            this.tabPage3.Controls.Add(this.lblRecon);
            this.tabPage3.Controls.Add(this.dgvAccountNumber);
            this.tabPage3.Controls.Add(this.btnAccountAdd);
            this.tabPage3.Location = new System.Drawing.Point(4, 24);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(1337, 529);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Add Account List";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // txtToAccountNumber
            // 
            this.txtToAccountNumber.Location = new System.Drawing.Point(471, 86);
            this.txtToAccountNumber.Name = "txtToAccountNumber";
            this.txtToAccountNumber.Size = new System.Drawing.Size(257, 23);
            this.txtToAccountNumber.TabIndex = 7;
            // 
            // btnAccountNumberDelete
            // 
            this.btnAccountNumberDelete.Location = new System.Drawing.Point(854, 89);
            this.btnAccountNumberDelete.Name = "btnAccountNumberDelete";
            this.btnAccountNumberDelete.Size = new System.Drawing.Size(75, 23);
            this.btnAccountNumberDelete.TabIndex = 6;
            this.btnAccountNumberDelete.Text = "Delete";
            this.btnAccountNumberDelete.UseVisualStyleBackColor = true;
            this.btnAccountNumberDelete.Click += new System.EventHandler(this.btnAccountNumberDelete_Click);
            // 
            // lblAccountNumber
            // 
            this.lblAccountNumber.AutoSize = true;
            this.lblAccountNumber.Location = new System.Drawing.Point(52, 89);
            this.lblAccountNumber.Name = "lblAccountNumber";
            this.lblAccountNumber.Size = new System.Drawing.Size(100, 15);
            this.lblAccountNumber.TabIndex = 5;
            this.lblAccountNumber.Text = "Account Number";
            // 
            // txtAccountNumber
            // 
            this.txtAccountNumber.Location = new System.Drawing.Point(181, 86);
            this.txtAccountNumber.Name = "txtAccountNumber";
            this.txtAccountNumber.Size = new System.Drawing.Size(257, 23);
            this.txtAccountNumber.TabIndex = 4;
            // 
            // cbRecon
            // 
            this.cbRecon.FormattingEnabled = true;
            this.cbRecon.Items.AddRange(new object[] {
            "Bony and Clearstream",
            "Thailand  CMS 4121(STS) SNS (Manual)"});
            this.cbRecon.Location = new System.Drawing.Point(181, 35);
            this.cbRecon.Name = "cbRecon";
            this.cbRecon.Size = new System.Drawing.Size(257, 23);
            this.cbRecon.TabIndex = 3;
            this.cbRecon.SelectedIndexChanged += new System.EventHandler(this.cbRecon_SelectedIndexChanged);
            // 
            // lblRecon
            // 
            this.lblRecon.AutoSize = true;
            this.lblRecon.Location = new System.Drawing.Point(49, 38);
            this.lblRecon.Name = "lblRecon";
            this.lblRecon.Size = new System.Drawing.Size(41, 15);
            this.lblRecon.TabIndex = 2;
            this.lblRecon.Text = "Recon";
            // 
            // dgvAccountNumber
            // 
            this.dgvAccountNumber.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvAccountNumber.Location = new System.Drawing.Point(52, 170);
            this.dgvAccountNumber.Name = "dgvAccountNumber";
            this.dgvAccountNumber.Size = new System.Drawing.Size(877, 236);
            this.dgvAccountNumber.TabIndex = 1;
            this.dgvAccountNumber.Visible = false;
            // 
            // btnAccountAdd
            // 
            this.btnAccountAdd.Location = new System.Drawing.Point(752, 89);
            this.btnAccountAdd.Name = "btnAccountAdd";
            this.btnAccountAdd.Size = new System.Drawing.Size(75, 23);
            this.btnAccountAdd.TabIndex = 0;
            this.btnAccountAdd.Text = "ADD";
            this.btnAccountAdd.UseVisualStyleBackColor = true;
            this.btnAccountAdd.Click += new System.EventHandler(this.btnAccountAdd_Click);
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.lbl_Country);
            this.tabPage4.Controls.Add(this.cbHLLastTransactionDate);
            this.tabPage4.Controls.Add(this.cbHLCountry);
            this.tabPage4.Controls.Add(this.lbl_Prd);
            this.tabPage4.Controls.Add(this.cbHLProduct);
            this.tabPage4.Controls.Add(this.btnHLDelete);
            this.tabPage4.Controls.Add(this.btnHLSave);
            this.tabPage4.Controls.Add(this.lblTransactionDate);
            this.tabPage4.Controls.Add(this.cbAlternateSunFileAvailable);
            this.tabPage4.Controls.Add(this.cbAlternateSatFileAvailable);
            this.tabPage4.Controls.Add(this.cbAlternateWeek);
            this.tabPage4.Controls.Add(this.cbHolidayFileAvailable);
            this.tabPage4.Controls.Add(this.cbSunFileAvailable);
            this.tabPage4.Controls.Add(this.cbSatFileAvailable);
            this.tabPage4.Controls.Add(this.cbHolidayReconRun);
            this.tabPage4.Controls.Add(this.cbSunReconRun);
            this.tabPage4.Controls.Add(this.cbSatFileRun);
            this.tabPage4.Controls.Add(this.lblHLRecon);
            this.tabPage4.Controls.Add(this.cbHLRecon);
            this.tabPage4.Location = new System.Drawing.Point(4, 24);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(1337, 529);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Holiday Logic Recon Settings";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // lbl_Country
            // 
            this.lbl_Country.AutoSize = true;
            this.lbl_Country.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Country.Location = new System.Drawing.Point(448, 67);
            this.lbl_Country.Name = "lbl_Country";
            this.lbl_Country.Size = new System.Drawing.Size(51, 15);
            this.lbl_Country.TabIndex = 44;
            this.lbl_Country.Text = "Country";
            // 
            // cbHLLastTransactionDate
            // 
            this.cbHLLastTransactionDate.FormattingEnabled = true;
            this.cbHLLastTransactionDate.Items.AddRange(new object[] {
            "0",
            "-1",
            "-2",
            "-3"});
            this.cbHLLastTransactionDate.Location = new System.Drawing.Point(246, 169);
            this.cbHLLastTransactionDate.Name = "cbHLLastTransactionDate";
            this.cbHLLastTransactionDate.Size = new System.Drawing.Size(121, 23);
            this.cbHLLastTransactionDate.TabIndex = 43;
            // 
            // cbHLCountry
            // 
            this.cbHLCountry.FormattingEnabled = true;
            this.cbHLCountry.Location = new System.Drawing.Point(517, 62);
            this.cbHLCountry.Name = "cbHLCountry";
            this.cbHLCountry.Size = new System.Drawing.Size(198, 23);
            this.cbHLCountry.TabIndex = 41;
            this.cbHLCountry.SelectedIndexChanged += new System.EventHandler(this.cbReconFilter_SelectIndexChanges);
            // 
            // lbl_Prd
            // 
            this.lbl_Prd.AutoSize = true;
            this.lbl_Prd.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Prd.Location = new System.Drawing.Point(48, 62);
            this.lbl_Prd.Name = "lbl_Prd";
            this.lbl_Prd.Size = new System.Drawing.Size(52, 15);
            this.lbl_Prd.TabIndex = 42;
            this.lbl_Prd.Text = "Products";
            // 
            // cbHLProduct
            // 
            this.cbHLProduct.FormattingEnabled = true;
            this.cbHLProduct.Location = new System.Drawing.Point(246, 59);
            this.cbHLProduct.Name = "cbHLProduct";
            this.cbHLProduct.Size = new System.Drawing.Size(170, 23);
            this.cbHLProduct.TabIndex = 40;
            this.cbHLProduct.SelectedIndexChanged += new System.EventHandler(this.cbReconFilter_SelectIndexChanges);
            // 
            // btnHLDelete
            // 
            this.btnHLDelete.Location = new System.Drawing.Point(300, 398);
            this.btnHLDelete.Name = "btnHLDelete";
            this.btnHLDelete.Size = new System.Drawing.Size(75, 23);
            this.btnHLDelete.TabIndex = 39;
            this.btnHLDelete.Text = "Delete";
            this.btnHLDelete.UseVisualStyleBackColor = true;
            this.btnHLDelete.Click += new System.EventHandler(this.btnHLDelete_Click);
            // 
            // btnHLSave
            // 
            this.btnHLSave.Location = new System.Drawing.Point(135, 398);
            this.btnHLSave.Name = "btnHLSave";
            this.btnHLSave.Size = new System.Drawing.Size(75, 23);
            this.btnHLSave.TabIndex = 38;
            this.btnHLSave.Text = "Save";
            this.btnHLSave.UseVisualStyleBackColor = true;
            this.btnHLSave.Click += new System.EventHandler(this.btnHLSave_Click);
            // 
            // lblTransactionDate
            // 
            this.lblTransactionDate.AutoSize = true;
            this.lblTransactionDate.Location = new System.Drawing.Point(48, 169);
            this.lblTransactionDate.Name = "lblTransactionDate";
            this.lblTransactionDate.Size = new System.Drawing.Size(101, 15);
            this.lblTransactionDate.TabIndex = 37;
            this.lblTransactionDate.Text = "Transaction Date";
            // 
            // cbAlternateSunFileAvailable
            // 
            this.cbAlternateSunFileAvailable.AutoSize = true;
            this.cbAlternateSunFileAvailable.Location = new System.Drawing.Point(433, 323);
            this.cbAlternateSunFileAvailable.Name = "cbAlternateSunFileAvailable";
            this.cbAlternateSunFileAvailable.Size = new System.Drawing.Size(210, 19);
            this.cbAlternateSunFileAvailable.TabIndex = 36;
            this.cbAlternateSunFileAvailable.Text = "Is Alternate Sunday File Available";
            this.cbAlternateSunFileAvailable.UseVisualStyleBackColor = true;
            // 
            // cbAlternateSatFileAvailable
            // 
            this.cbAlternateSatFileAvailable.AutoSize = true;
            this.cbAlternateSatFileAvailable.Location = new System.Drawing.Point(246, 323);
            this.cbAlternateSatFileAvailable.Name = "cbAlternateSatFileAvailable";
            this.cbAlternateSatFileAvailable.Size = new System.Drawing.Size(186, 19);
            this.cbAlternateSatFileAvailable.TabIndex = 35;
            this.cbAlternateSatFileAvailable.Text = "Is Alternate Sat File Available";
            this.cbAlternateSatFileAvailable.UseVisualStyleBackColor = true;
            // 
            // cbAlternateWeek
            // 
            this.cbAlternateWeek.AutoSize = true;
            this.cbAlternateWeek.Location = new System.Drawing.Point(45, 323);
            this.cbAlternateWeek.Name = "cbAlternateWeek";
            this.cbAlternateWeek.Size = new System.Drawing.Size(109, 19);
            this.cbAlternateWeek.TabIndex = 34;
            this.cbAlternateWeek.Text = "Alternate Week";
            this.cbAlternateWeek.UseVisualStyleBackColor = true;
            // 
            // cbHolidayFileAvailable
            // 
            this.cbHolidayFileAvailable.AutoSize = true;
            this.cbHolidayFileAvailable.Location = new System.Drawing.Point(433, 266);
            this.cbHolidayFileAvailable.Name = "cbHolidayFileAvailable";
            this.cbHolidayFileAvailable.Size = new System.Drawing.Size(161, 19);
            this.cbHolidayFileAvailable.TabIndex = 33;
            this.cbHolidayFileAvailable.Text = "Is Holiday File Available";
            this.cbHolidayFileAvailable.UseVisualStyleBackColor = true;
            // 
            // cbSunFileAvailable
            // 
            this.cbSunFileAvailable.AutoSize = true;
            this.cbSunFileAvailable.Location = new System.Drawing.Point(246, 266);
            this.cbSunFileAvailable.Name = "cbSunFileAvailable";
            this.cbSunFileAvailable.Size = new System.Drawing.Size(157, 19);
            this.cbSunFileAvailable.TabIndex = 32;
            this.cbSunFileAvailable.Text = "Is Sunday File Available";
            this.cbSunFileAvailable.UseVisualStyleBackColor = true;
            // 
            // cbSatFileAvailable
            // 
            this.cbSatFileAvailable.AutoSize = true;
            this.cbSatFileAvailable.Location = new System.Drawing.Point(45, 266);
            this.cbSatFileAvailable.Name = "cbSatFileAvailable";
            this.cbSatFileAvailable.Size = new System.Drawing.Size(165, 19);
            this.cbSatFileAvailable.TabIndex = 31;
            this.cbSatFileAvailable.Text = "Is Saturday File Available";
            this.cbSatFileAvailable.UseVisualStyleBackColor = true;
            // 
            // cbHolidayReconRun
            // 
            this.cbHolidayReconRun.AutoSize = true;
            this.cbHolidayReconRun.Location = new System.Drawing.Point(433, 209);
            this.cbHolidayReconRun.Name = "cbHolidayReconRun";
            this.cbHolidayReconRun.Size = new System.Drawing.Size(145, 19);
            this.cbHolidayReconRun.TabIndex = 30;
            this.cbHolidayReconRun.Text = "Is Holiday Recon Run";
            this.cbHolidayReconRun.UseVisualStyleBackColor = true;
            // 
            // cbSunReconRun
            // 
            this.cbSunReconRun.AutoSize = true;
            this.cbSunReconRun.Location = new System.Drawing.Point(246, 209);
            this.cbSunReconRun.Name = "cbSunReconRun";
            this.cbSunReconRun.Size = new System.Drawing.Size(141, 19);
            this.cbSunReconRun.TabIndex = 29;
            this.cbSunReconRun.Text = "Is Sunday Recon Run";
            this.cbSunReconRun.UseVisualStyleBackColor = true;
            // 
            // cbSatFileRun
            // 
            this.cbSatFileRun.AutoSize = true;
            this.cbSatFileRun.Location = new System.Drawing.Point(45, 209);
            this.cbSatFileRun.Name = "cbSatFileRun";
            this.cbSatFileRun.Size = new System.Drawing.Size(149, 19);
            this.cbSatFileRun.TabIndex = 28;
            this.cbSatFileRun.Text = "Is Saturday Recon Run";
            this.cbSatFileRun.UseVisualStyleBackColor = true;
            // 
            // lblHLRecon
            // 
            this.lblHLRecon.AutoSize = true;
            this.lblHLRecon.Location = new System.Drawing.Point(48, 102);
            this.lblHLRecon.Name = "lblHLRecon";
            this.lblHLRecon.Size = new System.Drawing.Size(41, 15);
            this.lblHLRecon.TabIndex = 27;
            this.lblHLRecon.Text = "Recon";
            // 
            // cbHLRecon
            // 
            this.cbHLRecon.FormattingEnabled = true;
            this.cbHLRecon.Location = new System.Drawing.Point(246, 102);
            this.cbHLRecon.Name = "cbHLRecon";
            this.cbHLRecon.Size = new System.Drawing.Size(769, 23);
            this.cbHLRecon.TabIndex = 26;
            this.cbHLRecon.SelectedIndexChanged += new System.EventHandler(this.cbHLRecon_SelectIndexChanges);
            // 
            // TabImages
            // 
            this.TabImages.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("TabImages.ImageStream")));
            this.TabImages.TransparentColor = System.Drawing.Color.Transparent;
            this.TabImages.Images.SetKeyName(0, "Recon Details");
            this.TabImages.Images.SetKeyName(1, "Reports");
            this.TabImages.Images.SetKeyName(2, "UserMgt");
            this.TabImages.Images.SetKeyName(3, "DashBoard");
            this.TabImages.Images.SetKeyName(4, "Configuration");
            // 
            // lnk_Logout
            // 
            this.lnk_Logout.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lnk_Logout.AutoSize = true;
            this.lnk_Logout.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnk_Logout.Location = new System.Drawing.Point(1230, 68);
            this.lnk_Logout.Name = "lnk_Logout";
            this.lnk_Logout.Size = new System.Drawing.Size(53, 15);
            this.lnk_Logout.TabIndex = 47;
            this.lnk_Logout.TabStop = true;
            this.lnk_Logout.Text = "LogOut";
            this.lnk_Logout.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnk_Logout_LinkClicked);
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.Ref);
            this.panel6.Controls.Add(this.pictureBox3);
            this.panel6.Controls.Add(this.lnk_Logout);
            this.panel6.Controls.Add(this.pictureBox1);
            this.panel6.Controls.Add(this.Loading);
            this.panel6.Location = new System.Drawing.Point(3, 3);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(1345, 128);
            this.panel6.TabIndex = 58;
            // 
            // Ref
            // 
            this.Ref.Image = global::ARC_Application.Properties.Resources.arrow_refresh_4_icon;
            this.Ref.Location = new System.Drawing.Point(1201, 63);
            this.Ref.Name = "Ref";
            this.Ref.Size = new System.Drawing.Size(24, 24);
            this.Ref.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.Ref.TabIndex = 59;
            this.Ref.TabStop = false;
            this.Ref.Click += new System.EventHandler(this.Ref_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(0, 0);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(192, 125);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox3.TabIndex = 58;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(1199, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(146, 65);
            this.pictureBox1.TabIndex = 5;
            this.pictureBox1.TabStop = false;
            // 
            // Loading
            // 
            this.Loading.Image = global::ARC_Application.Properties.Resources.loader;
            this.Loading.Location = new System.Drawing.Point(507, 1);
            this.Loading.Name = "Loading";
            this.Loading.Size = new System.Drawing.Size(80, 64);
            this.Loading.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Loading.TabIndex = 57;
            this.Loading.TabStop = false;
            this.Loading.Visible = false;
            // 
            // Main_Admin_DashBoard_New
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(1350, 694);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.tabControl1);
            this.Name = "Main_Admin_DashBoard_New";
            this.Text = "Main_Admin_DashBoard";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAccountNumber)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Ref)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Loading)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.LinkLabel lnk_Logout;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.ImageList TabImages;
        private System.Windows.Forms.PictureBox Loading;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Panel admin_panel;
        private System.Windows.Forms.Panel dashboard_panel;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.ComboBox cbRecon;
        private System.Windows.Forms.Label lblRecon;
        private System.Windows.Forms.DataGridView dgvAccountNumber;
        private System.Windows.Forms.Button btnAccountAdd;
        private System.Windows.Forms.Label lblAccountNumber;
        private System.Windows.Forms.TextBox txtAccountNumber;
        private System.Windows.Forms.Button btnAccountNumberDelete;
        private System.Windows.Forms.TextBox txtToAccountNumber;
        private System.Windows.Forms.PictureBox Ref;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.ComboBox cbHLLastTransactionDate;
        private System.Windows.Forms.ComboBox cbHLCountry;
        private System.Windows.Forms.Label lbl_Prd;
        private System.Windows.Forms.ComboBox cbHLProduct;
        private System.Windows.Forms.Button btnHLDelete;
        private System.Windows.Forms.Button btnHLSave;
        private System.Windows.Forms.Label lblTransactionDate;
        private System.Windows.Forms.CheckBox cbAlternateSunFileAvailable;
        private System.Windows.Forms.CheckBox cbAlternateSatFileAvailable;
        private System.Windows.Forms.CheckBox cbAlternateWeek;
        private System.Windows.Forms.CheckBox cbHolidayFileAvailable;
        private System.Windows.Forms.CheckBox cbSunFileAvailable;
        private System.Windows.Forms.CheckBox cbSatFileAvailable;
        private System.Windows.Forms.CheckBox cbHolidayReconRun;
        private System.Windows.Forms.CheckBox cbSunReconRun;
        private System.Windows.Forms.CheckBox cbSatFileRun;
        private System.Windows.Forms.Label lblHLRecon;
        private System.Windows.Forms.ComboBox cbHLRecon;
        private System.Windows.Forms.Label lbl_Country;

    }
}