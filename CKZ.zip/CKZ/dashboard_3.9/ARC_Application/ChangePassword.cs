﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
using System.Configuration;

namespace ARC_Application
{
    public partial class ChangePassword : Form
    {
        //private string p;
        string conString = ConfigurationManager.ConnectionStrings["ARC_conStr"].ConnectionString;
        public SqlConnection conn;
        public SqlCommand com;
        SQLEncryption ecp = new SQLEncryption();

        public ChangePassword(string p)
        {
            InitializeComponent();
            Lbl_UID.Text = p;
            if (!conString.StartsWith("Data"))
            {
                conString = ecp.Decrypt(conString);
            }
        }

        private void Initialize()
        {

        }

        private void BtnUpd_Click(object sender, EventArgs e)
        {
            txtpassword(txt_Npsd.Text);
            string Psd ="";
            conn = new SqlConnection(conString);
            if (txt_Npsd.Text == "" || txt_Rpsd.Text == "" || txt_CurPsd.Text == "")
            {
                MessageBox.Show("Please enter values");
                txt_Npsd.Text = "";
                return;
            }
            if (txt_Npsd.Text != txt_Rpsd.Text)
            {
                MessageBox.Show("confirm password not matching with new passsword");
                txt_Npsd.Focus();
                return;
            }

            else
            {
                
                if (txt_CurPsd.Text != "")
                {
                    conn.Open();
                   
                    SqlCommand com = new SqlCommand("select Password from dbo.ARC_User_Info where UserID=@UserID", conn);
                    com.CommandType = CommandType.Text;
                    com.Parameters.AddWithValue("@UserID", Lbl_UID.Text);
                    SqlDataReader dr = com.ExecuteReader();
                    while (dr.Read())
                    {
                        if (dr.HasRows == true)
                        {
                            string Password = (string)dr["Password"];
                            Psd = ecp.Decrypt(Password.Trim());                          

                        }
                    }
                    conn.Close();
                    if (Psd == txt_CurPsd.Text)
                    {

                        DateTime date = DateTime.Today;
                        DateTime date1 = DateTime.Today.AddDays(90);
                        string strRegex = @"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&]{8,10}";
                        Regex re = new Regex(strRegex);
                        if (re.IsMatch(txt_Npsd.Text))
                        {
                            conn.Open();
                            string UpdatQuery = "update dbo.ARC_User_Info set Password=@Password,StartDate=@StartDate,EndDate=@EndDate,Is_FirstTimeLogin=@Is_FirstTimeLogin where UserID='" + Lbl_UID.Text + "'";
                            com = new SqlCommand(UpdatQuery, conn);
                            com.Parameters.AddWithValue("@Password", ecp.Encrypt(txt_Npsd.Text.Trim()));
                            com.Parameters.AddWithValue("@StartDate", date);
                            com.Parameters.AddWithValue("@EndDate", date1);
                            com.Parameters.AddWithValue("@Is_FirstTimeLogin", 1);
                            com.ExecuteNonQuery();
                            MessageBox.Show("Password Updated Successfully");
                            conn.Close();
                            //conn.Open();
                            this.Hide();
                            ARC_Login_New log = new ARC_Login_New();
                            log.Show();
                        }

                        else
                        {
                            MessageBox.Show("Password should be a combination of uppercase, lowercase, symbol & numeric alphabets and at least 8 characters");
                        }
                    }
                    else
                    {
                        MessageBox.Show(" Your Current Password is Not Correct!");
                    }
                }
               
            }

        }

        private void Btn_Cnl_Click(object sender, EventArgs e)
        {
            this.Hide();
            ARC_Login_New log = new ARC_Login_New();
            log.Show();
        }

        private static bool txtpassword(string psd)
        {
            //string strRegex = @"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&]{8,10}";
            string strRegex = @"^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$";
            Regex re = new Regex(strRegex);
            if (re.IsMatch(psd))
                return (true);
            else
                return (false);
            //try
            //{
            //    if (System.Text.RegularExpressions.Regex.IsMatch("$#%hg#$Y%#$", @"^(?=.*[a-zA-Z])(?=.*[!@#$%^&*])"))
            //        return;
            //    else
            //    {
            //        //e.Handled = true;
            //        //MessageBox.Show("Please Enter your UserID!");
            //        label1.Visible = true;
            //        label1.Text = "Enter at least one uppercase and leter in uppercase and lower case & special character";
            //    }


            //}
            //catch (Exception e)
            //{
            //    label1.Visible = true;
            //    label1.Text = "Enter at least one uppercase and leter in uppercase and lower case & special character";
            //}
        }

        private void txt_Npsd_KeyPress(object sender, KeyPressEventArgs e)
        {
            //if (txt_Npsd.Text.Length >= 8)
            //{
            //    MessageBox.Show("Password limit is should be less than 8!");
            //}
        }

        private void txt_Rpsd_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (txt_Rpsd.Text.Length >= 8)
            {
                MessageBox.Show("Password limit is should be less than 8!");
            }
        }
    }
}
