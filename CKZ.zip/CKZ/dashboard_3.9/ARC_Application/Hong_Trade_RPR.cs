﻿using System;
using System.Data;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using System.Drawing;
using System.Data.OleDb;
using System.Globalization;
using Excel = Microsoft.Office.Interop.Excel;
using System.Reflection;
using System.Text.RegularExpressions;


namespace ARC_Application
{
    class Hong_Trade_RPR
    {
        Formatting_Logics obj = new Formatting_Logics();

        int j = 0;
        System.Data.DataTable dt1 = new System.Data.DataTable();
        System.Data.DataTable dt2 = new System.Data.DataTable();
        string d = DateTime.Now.ToString("dd-MMM-yyyy");

        public DataTable getData(string Count, string FilePath)
        {
            Excel.Application app = new Excel.Application();
            Excel.Workbook book = null;
            Excel.Range range = null;
            Excel.Worksheet sheet = null;

            DataTable dt = new DataTable();
            try
            {
                app.Visible = false;
                app.ScreenUpdating = false;
                app.DisplayAlerts = false;


                string execPath = Path.GetDirectoryName(Assembly.GetExecutingAssembly().CodeBase);

                book = app.Workbooks.Open(FilePath, Missing.Value, Missing.Value, Missing.Value
                                                  , Missing.Value, Missing.Value, Missing.Value, Missing.Value
                                                 , Missing.Value, Missing.Value, Missing.Value, Missing.Value
                                                , Missing.Value, Missing.Value, Missing.Value);
                
                sheet = (Microsoft.Office.Interop.Excel.Worksheet)book.Sheets.get_Item(1);
                dt.Columns.Add("CLIENTID");
                int a = Convert.ToInt32(Count);
                range = sheet.get_Range("A1", "A" + a);
                for (int j = 0; j <= range.Rows.Count + 1; j++)
                {
                    dt.Rows.Add();
                    if (j > 0)
                    {
                        dt.Rows[j][0] = Convert.ToString((sheet.Cells[j, 9] as Excel.Range).Value2);
                    }
                }
                dt.Rows.RemoveAt(0);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
            finally
            {
                if (range != null)
                    obj.ReleaseComObject(range);
                range = null;
                if (book != null)
                    book.Close(false, Missing.Value, Missing.Value);
                obj.ReleaseComObject(book);
                book = null;
                if (app != null)
                    app.Quit();
                obj.ReleaseComObject(app);
                app = null;
            }
            return dt;
        }

        public void Hong_Kong_Trade_RPR(string Source_Path, string Country_Name, string ConStr, string FileName, string Output_Path, string File_Ext, string Recon_Date, string Main_DIR_Path)
        {
            try
            {
                string folderdate = DateTime.Now.ToString("dd-MMM-yyyy");
                string date = Recon_Date;

                //string filePath = @"\\10.132.5.214\TempFiles\SAHIL\UAT_Runtimes\ARCRuntime\" + folderdate + "_Files\\Files_For_Formatting_Or_Non_Formatting\\Formatting\\HongKong_trade_RPR\\TB_OPS_DAILY_TRADE_REPORT-" + date + "-0010-GMT.csv";
                //string ExcelfilePath = @"\\10.132.5.214\TempFiles\SAHIL\UAT_Runtimes\ARCRuntime\" + folderdate + "_Files\\Files_For_Formatting_Or_Non_Formatting\\Formatting\\HongKong_trade_RPR\\TB_OPS_DAILY_TRADE_REPORT-" + date + "-0010-GMT.xlsx";
                //string ExcelfilePath = @"C:\Users\1554577\Desktop\Copy of TB_OPS_DAILY_TRADE_REPORT-20170207-0010-GMT.xls";
                bool hasHeaders = true;
                Source_Path = Source_Path + FileName +"."+ File_Ext;
                if (File.Exists(Source_Path))
                {
                    string HDR = hasHeaders ? "Yes" : "No";
                    string strConn;
                    Microsoft.Office.Interop.Excel.Application app = new Microsoft.Office.Interop.Excel.Application();
                    app.DisplayAlerts = false;
                    app.Visible = false;
                    Excel.Workbook wb = app.Workbooks.Open(Source_Path, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                    wb.SaveAs(Output_Path + FileName + ".xls", Excel.XlFileFormat.xlOpenXMLWorkbook, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Excel.XlSaveAsAccessMode.xlExclusive, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                    wb.Close();
                    app.Quit();
                    if (File.Exists(Output_Path + FileName + ".xls"))
                    {
                        System.Threading.Thread.Sleep(2500);
                        wb = app.Workbooks.Open(Output_Path + FileName + ".xls", Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                        //System.Threading.Thread.Sleep(2500);
                    }
                    strConn = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + Output_Path + FileName + ".xls" + ";Extended Properties=\"Excel 8.0;HDR=" + HDR + ";IMEX=1\"";
                    System.Data.DataTable dtexcel = new System.Data.DataTable();
                    OleDbConnection conn = new OleDbConnection(strConn);
                    conn.Open();
                    System.Data.DataTable schemaTable = conn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, new object[] { null, null, null, "TABLE" });

                    DataRow schemaRow = schemaTable.Rows[0];
                    string sheet = schemaRow["TABLE_NAME"].ToString();
                    DataTable dd = new DataTable();
                    if (!sheet.EndsWith("_"))
                    {
                        string query = "SELECT  * FROM [" + sheet + "]";
                        OleDbDataAdapter da = new OleDbDataAdapter(query, conn);
                        dtexcel.Locale = CultureInfo.CurrentCulture;
                        da.Fill(dtexcel);

                    }
                    wb.Close();
                    app.Quit();
                    obj.ReleaseComObject(wb);
                    obj.ReleaseComObject(app);
                    DataTable t = getData(dtexcel.Rows.Count.ToString(), Output_Path + FileName + ".xls");
                    dtexcel.Columns.RemoveAt(8);
                    if (t.Rows[0][0].ToString() == "")
                    {
                        DataRow newRow = dtexcel.NewRow();
                        dtexcel.Rows.InsertAt(newRow, 0);
                    }
                    dtexcel.Columns.Add("CLIENTID");
                    t.Rows.RemoveAt(0);
                    int a = dtexcel.Rows.Count;
                    int track = 0;

                    for (int i = 0; i <= t.Rows.Count - 1; i++)
                    {

                        dtexcel.Rows[i]["CLIENTID"] = t.Rows[i]["CLIENTID"];

                        track = track + 1;
                    }

                    //******************************************************************************//
                    dt1.Columns.Add("FRONTOFFICEREF1");
                    dt1.Columns.Add("13 DIG", typeof(string));
                    dt1.Columns.Add("CON", typeof(string));
                    dt1.Columns.Add("TRADEID2");
                    dt1.Columns.Add("FRONTOFFICEREF2");
                    dt1.Columns.Add("BASECCY");
                    dt1.Columns.Add("BASECCYAMOUNT");
                    dt1.Columns.Add("TERMCCY");
                    dt1.Columns.Add("TERMCCYAMOUNT");
                    dt1.Columns.Add("VALUEDATE");

                    dt2.Columns.Add("FRONTOFFICEREF1");
                    dt2.Columns.Add("13 DIG", typeof(string));
                    dt2.Columns.Add("CON", typeof(string));
                    dt2.Columns.Add("TRADEID2");
                    dt2.Columns.Add("FRONTOFFICEREF2");
                    dt2.Columns.Add("BASECCY");
                    dt2.Columns.Add("BASECCYAMOUNT");
                    dt2.Columns.Add("TERMCCY");
                    dt2.Columns.Add("TERMCCYAMOUNT");
                    dt2.Columns.Add("VALUEDATE");
                    System.Data.DataTable dt3 = new System.Data.DataTable();
                    dt3.Columns.Add("CROSS CURRENCY");


                    for (int i = 0; i <= dtexcel.Rows.Count - 1; i++)
                    {

                        try
                        {
                            dt1.Rows.Add();
                            dt2.Rows.Add();
                            if (dtexcel.Rows[i]["Client Booking Location"].ToString().Trim().ToLower() == "hongkong" && dtexcel.Rows[i]["TERMCCY"].ToString().Trim().ToUpper() == "HKD")
                            {
                                dt1.Rows[i]["FRONTOFFICEREF1"] = dtexcel.Rows[i]["FRONTOFFICEREF"];

                                if (Regex.IsMatch(dtexcel.Rows[i]["CLIENTID"].ToString(), @"^[0-9]"))
                                {
                                    string s = string.Join("", dtexcel.Rows[i]["CLIENTID"].ToString().Where(char.IsDigit));

                                    if (s.Length >= 13)
                                    {
                                        dt1.Rows[i]["13 DIG"] = s.Substring(0, 12);
                                        dt1.Rows[i]["CON"] = s.Substring(0, 12) + "-" + dtexcel.Rows[i]["BASECCYAMOUNT"];
                                    }
                                    else
                                    {
                                        dt1.Rows[i]["13 DIG"] = s.Substring(0, 11);
                                        dt1.Rows[i]["CON"] = s.Substring(0, 11) + "0-" + dtexcel.Rows[i]["BASECCYAMOUNT"];
                                    }
                                }
                                else
                                {
                                    dt1.Rows[i]["13 DIG"] = dtexcel.Rows[i]["CLIENTID"].ToString().Substring(0, 13);
                                    dt1.Rows[i]["CON"] = dtexcel.Rows[i]["CLIENTID"].ToString().Substring(0, 13) + "-" + dtexcel.Rows[i]["BASECCYAMOUNT"];
                                }

                                dt1.Rows[i]["TRADEID2"] = dtexcel.Rows[i]["TRADEID"];
                                dt1.Rows[i]["FRONTOFFICEREF2"] = dtexcel.Rows[i]["FRONTOFFICEREF"];
                                dt1.Rows[i]["BASECCY"] = dtexcel.Rows[i]["BASECCY"];
                                dt1.Rows[i]["BASECCYAMOUNT"] = dtexcel.Rows[i]["BASECCYAMOUNT"];
                                dt1.Rows[i]["TERMCCY"] = dtexcel.Rows[i]["TERMCCY"];
                                dt1.Rows[i]["TERMCCYAMOUNT"] = dtexcel.Rows[i]["TERMCCYAMOUNT"];

                                string[] date1 = dtexcel.Rows[i]["VALUEDATE"].ToString().Split('/');
                                string[] o = date1[2].ToString().Split(' ');
                                dt1.Rows[i]["VALUEDATE"] = date1[0] + "-" + date1[1] + "-" + o[0];

                            }
                            else if (dtexcel.Rows[i]["Client Booking Location"].ToString().Trim().ToLower() == "hongkong" && dtexcel.Rows[i]["TERMCCY"].ToString().Trim().ToUpper() != "HKD")
                            {
                                dt2.Rows[i]["FRONTOFFICEREF1"] = dtexcel.Rows[i]["FRONTOFFICEREF"];

                                if (Regex.IsMatch(dtexcel.Rows[i]["CLIENTID"].ToString(), @"^[0-9]"))
                                {
                                    string s = string.Join("", dtexcel.Rows[i]["CLIENTID"].ToString().Where(char.IsDigit));

                                    if (s.Length >= 13)
                                    {
                                        dt2.Rows[i]["13 DIG"] = s.Substring(0, 12);
                                        dt2.Rows[i]["CON"] = s.Substring(0, 12) + "-" + dtexcel.Rows[i]["BASECCYAMOUNT"];
                                    }
                                    else
                                    {
                                        dt2.Rows[i]["13 DIG"] = s.Substring(0, 11);
                                        dt2.Rows[i]["CON"] = s.Substring(0, 11) + "0-" + dtexcel.Rows[i]["BASECCYAMOUNT"];
                                    }
                                }
                                else
                                {

                                    dt2.Rows[i]["13 DIG"] = dtexcel.Rows[i]["CLIENTID"].ToString().Substring(0, 13);
                                    dt2.Rows[i]["CON"] = dtexcel.Rows[i]["CLIENTID"].ToString().Substring(0, 13) + "-" + dtexcel.Rows[i]["BASECCYAMOUNT"];


                                }

                                dt2.Rows[i]["TRADEID2"] = dtexcel.Rows[i]["TRADEID"];
                                dt2.Rows[i]["FRONTOFFICEREF2"] = dtexcel.Rows[i]["FRONTOFFICEREF"];
                                dt2.Rows[i]["BASECCY"] = dtexcel.Rows[i]["BASECCY"];
                                dt2.Rows[i]["BASECCYAMOUNT"] = dtexcel.Rows[i]["BASECCYAMOUNT"];
                                dt2.Rows[i]["TERMCCY"] = dtexcel.Rows[i]["TERMCCY"];
                                dt2.Rows[i]["TERMCCYAMOUNT"] = dtexcel.Rows[i]["TERMCCYAMOUNT"];

                                string[] date1 = dtexcel.Rows[i]["VALUEDATE"].ToString().Split('/');
                                string[] o = date1[2].ToString().Split(' ');
                                dt2.Rows[i]["VALUEDATE"] = date1[0] + "-" + date1[1] + "-" + o[0];
                                j = j + 1;

                            }


                        }

                        catch (Exception ex)
                        {
                            throw ex;
                        }

                    }


                    for (int i = dt1.Rows.Count - 1; i >= 0; i--)
                    {

                        if (dt1.Rows[i][0].ToString().Trim() == "")
                        {

                            dt1.Rows.RemoveAt(i);
                        }
                    }
                    for (int i = dt2.Rows.Count - 1; i >= 0; i--)
                    {

                        if (dt2.Rows[i][0].ToString().Trim() == "")
                        {

                            dt2.Rows.RemoveAt(i);
                        }
                    }
                    System.Data.DataTable ds = new System.Data.DataTable();
                    ds.Columns.Add("FRONTOFFICEREF1");
                    ds.Columns.Add("13 DIG", typeof(string));
                    ds.Columns.Add("CON", typeof(string));
                    ds.Columns.Add("TRADEID2");
                    ds.Columns.Add("FRONTOFFICEREF2");
                    ds.Columns.Add("BASECCY");
                    ds.Columns.Add("BASECCYAMOUNT");
                    ds.Columns.Add("TERMCCY");
                    ds.Columns.Add("TERMCCYAMOUNT");
                    ds.Columns.Add("VALUEDATE");
                    for (int i = 0; i <= dt2.Rows.Count - 1; i++)
                    {
                        ds.Rows.Add();
                        ds.Rows[i]["FRONTOFFICEREF1"] = dt2.Rows[i]["FRONTOFFICEREF1"];

                        ds.Rows[i]["13 DIG"] = dt2.Rows[i]["13 DIG"];
                        ds.Rows[i]["CON"] = dt2.Rows[i]["CON"];

                        //string s=string.Join("", dtexcel.Rows[i]["CLIENTID"].ToString().Where(char.IsDigit));
                        //dt1.Rows[i]["TRADE REFERENCE"] = s.Substring(0,12);

                        ds.Rows[i]["TRADEID2"] = dt2.Rows[i]["TRADEID2"];
                        ds.Rows[i]["FRONTOFFICEREF2"] = dt2.Rows[i]["FRONTOFFICEREF2"];
                        ds.Rows[i]["BASECCY"] = dt2.Rows[i]["TERMCCY"];
                        ds.Rows[i]["BASECCYAMOUNT"] = dt2.Rows[i]["TERMCCYAMOUNT"];
                        ds.Rows[i]["TERMCCY"] = dt2.Rows[i]["BASECCY"];
                        ds.Rows[i]["TERMCCYAMOUNT"] = dt2.Rows[i]["BASECCYAMOUNT"];
                        ds.Rows[i]["VALUEDATE"] = dt2.Rows[i]["VALUEDATE"];

                    }
                    dt1.Merge(ds);
                    Hong_Kong_ExportToExcel(dt1, Output_Path + "Final_TB_OPS_DAILY_TRADE_REPORT.xls", Main_DIR_Path);//Put the Output Path
                    //obj.ExportToExcel(dt1,);
                }
                else
                {
                    MessageBox.Show("File not Present");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        public void HongKong_Get_IMXHP2B1(string Source_Path, string Country_Name, string ConStr, string FileName, string Output_Path, string File_Ext, string Main_DIR_Path)
        {
            try
            {
                string RequiredPath = Output_Path + "Final_TB_OPS_DAILY_TRADE_REPORT.xls";
                //string fileName = path5 + "IMXHP2B1.txt";
                DataTable dt = new DataTable();
                DataTable dt1 = new DataTable();
                dt1.Columns.Add("Temp");

                dt.Columns.Add("ORIGINAL");
                dt.Columns.Add("CURR/AMOUNT1");
                dt.Columns.Add("RC");
                dt.Columns.Add("EXCH RATE");
                dt.Columns.Add("EQV.");
                dt.Columns.Add("CURR/AMOUNT2");
                dt.Columns.Add("F.E CONT. #");
                dt.Columns.Add("CUST");
                dt.Columns.Add("ID/DEAL NO/STEP ID");
                dt.Columns.Add("PURCHASE/SALE");
                dt.Columns.Add("REMARKS");

                StreamReader objReader;
                Source_Path = Source_Path + FileName + "." + File_Ext;
                if (File.Exists(Source_Path))
                {
                    objReader = new StreamReader(Source_Path);
                    string[] lines = System.IO.File.ReadAllLines(Source_Path);
                    foreach (string line in lines)
                    {
                        string[] ar = System.Text.RegularExpressions.Regex.Split(line, @"\s{2,}");
                        if (ar[0].Length == 3)
                        {
                            dt1.Rows.Add(line);
                        }
                    }
                    for (int i = 0; i <= dt1.Rows.Count - 1; i++)
                    {
                        string[] ar = System.Text.RegularExpressions.Regex.Split(dt1.Rows[i][0].ToString(), @"\s{2,}");
                        var cpyArray = new string[ar.Length + 1];
                        ar.CopyTo(cpyArray, 0);
                        cpyArray[cpyArray.Length - 1] = null;

                        if (ar.Length < 11 && Regex.IsMatch(ar[6].ToString(), @"^[A-Z0-9]*$") || ar.Length == 11)
                        {


                            dt.Rows.Add();
                            dt.Rows[i][0] = cpyArray[0];
                            dt.Rows[i][1] = cpyArray[1];
                            dt.Rows[i][2] = cpyArray[2];
                            dt.Rows[i][3] = cpyArray[3];
                            dt.Rows[i][4] = cpyArray[4];
                            dt.Rows[i][5] = cpyArray[5];
                            dt.Rows[i][6] = cpyArray[6];
                            dt.Rows[i][7] = cpyArray[7];
                            dt.Rows[i][8] = cpyArray[8];
                            dt.Rows[i][9] = cpyArray[9];
                            dt.Rows[i][10] = cpyArray[10];
                        }
                        else
                        {
                            //Regex.Replace(ar[6], @"\s+", "");
                            if (ar.Length < 11 && Regex.IsMatch(Regex.Replace(ar[6], @"\s+", ""), @"^[0-9]*$"))
                            {
                                dt.Rows.Add();
                                dt.Rows[i][0] = cpyArray[0];
                                dt.Rows[i][1] = cpyArray[1];
                                dt.Rows[i][2] = cpyArray[2];
                                dt.Rows[i][3] = cpyArray[3];
                                dt.Rows[i][4] = cpyArray[4];
                                dt.Rows[i][5] = cpyArray[5];
                                dt.Rows[i][6] = "";
                                dt.Rows[i][7] = cpyArray[6];
                                dt.Rows[i][8] = cpyArray[7];
                                dt.Rows[i][9] = cpyArray[8];
                                dt.Rows[i][10] = cpyArray[9];
                            }
                        }

                    }

                }
                DataTable da = new DataTable();
                da.Columns.Add("PURCHASE/SALE");
                da.Columns.Add("REMARKS");

                for (int i = 0; i <= dt.Rows.Count - 1; i++)
                {
                    da.Rows.Add();
                    da.Rows[i][0] = dt.Rows[i][9].ToString().Substring(0, 2);
                    if (dt.Rows[i][9].ToString().Length > 2)
                    {
                        da.Rows[i][1] = dt.Rows[i][9].ToString().Substring(2, dt.Rows[i][9].ToString().Length - 2).Trim();
                    }
                    else
                    {
                        da.Rows[i][1] = "";
                    }
                }

                for (int i = dt.Rows.Count - 1; i >= 0; i--)
                {
                    dt.Rows[i][9] = "";
                    dt.Rows[i][10] = "";
                }

                for (int i = 0; i <= dt.Rows.Count - 1; i++)
                {
                    dt.Rows[i][9] = da.Rows[i][0];
                    dt.Rows[i][10] = da.Rows[i][1];
                }

                for (int i = 0; i <= dt.Rows.Count - 1; i++)
                {
                    if (dt.Rows[i][2].ToString().Trim() == "B" || dt.Rows[i][10].ToString().Trim().Contains("CR OLBA"))
                    {
                        dt.Rows.RemoveAt(i);
                    }
                }
                DataTable d1 = new DataTable();
                d1.Columns.Add("ORIGINAL");
                d1.Columns.Add("CURR/AMOUNT1");
                d1.Columns.Add("RC");
                d1.Columns.Add("EXCH RATE");
                d1.Columns.Add("EQV.");
                d1.Columns.Add("CURR/AMOUNT2");
                d1.Columns.Add("F.E CONT. #");
                d1.Columns.Add("CUST");
                d1.Columns.Add("ID/DEAL NO/STEP ID");
                d1.Columns.Add("PURCHASE/SALE");
                d1.Columns.Add("REMARKS");
                d1.Columns.Add("13 DIG");
                d1.Columns.Add("CON");
                d1.Columns.Add("TREASURY REF");
                d1.Columns.Add("VALUE DATE");
                d1.Columns.Add("RECON DATE");
                d1.Columns.Add("NARRATION");
                d1.Columns.Add("3 DIG");
                d1.Columns.Add("AACODE");
                for (int i = 0; i <= dt.Rows.Count - 1; i++)
                {
                    if (dt.Rows[i][0].ToString().Trim() != "HKD")
                    {
                        d1.Rows.Add();
                        d1.Rows[i][0] = dt.Rows[i][4];
                        d1.Rows[i][1] = dt.Rows[i][5];
                        d1.Rows[i][2] = dt.Rows[i][2];
                        d1.Rows[i][3] = dt.Rows[i][3];
                        d1.Rows[i][4] = dt.Rows[i][0];
                        d1.Rows[i][5] = dt.Rows[i][1];
                        d1.Rows[i][6] = dt.Rows[i][6];
                        d1.Rows[i][7] = dt.Rows[i][7];
                        d1.Rows[i][8] = dt.Rows[i][8];
                        if (dt.Rows[i][9].ToString().Trim() == "DR")
                        {
                            d1.Rows[i][9] = "CR";
                        }
                        else
                        {
                            d1.Rows[i][9] = "DR";
                        }
                        d1.Rows[i][10] = dt.Rows[i][10];
                    }
                    else
                    {
                        d1.Rows.Add();
                        d1.Rows[i][0] = dt.Rows[i][0];
                        d1.Rows[i][1] = dt.Rows[i][1];
                        d1.Rows[i][2] = dt.Rows[i][2];
                        d1.Rows[i][3] = dt.Rows[i][3];
                        d1.Rows[i][4] = dt.Rows[i][4];
                        d1.Rows[i][5] = dt.Rows[i][5];
                        d1.Rows[i][6] = dt.Rows[i][6];
                        d1.Rows[i][7] = dt.Rows[i][7];
                        d1.Rows[i][8] = dt.Rows[i][8];
                        d1.Rows[i][9] = dt.Rows[i][9];
                        d1.Rows[i][10] = dt.Rows[i][10];
                    }
                }

                string f1 = RequiredPath;
                if (File.Exists(f1))
                {
                    string strConn1;

                    if (f1.Substring(f1.LastIndexOf('.')).ToLower() == ".xls")
                        strConn1 = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + f1 + ";Extended Properties=\"Excel 12.0;HDR=Yes;IMEX=1\"";
                    //strConn = "Provider=Microsoft.Jet.OleDb.4.0; Data Source = " + System.IO.Path.GetDirectoryName(ExcelfilePath) + "; Extended Properties = 'text;HDR=YES;IMEX=1v;FMT=Delimited(,)';";
                    else
                        strConn1 = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + f1 + ";Extended Properties=\"Excel 8.0;HDR=Yes;IMEX=1\"";
                    System.Data.DataTable dtexcel1 = new System.Data.DataTable();
                    OleDbConnection conn1 = new OleDbConnection(strConn1);
                    
                    Microsoft.Office.Interop.Excel.Application app = new Microsoft.Office.Interop.Excel.Application();
                    app.DisplayAlerts = false;
                    app.Visible = false;
                    Excel.Workbook wb = app.Workbooks.Open(f1, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                    conn1.Open();
                    System.Data.DataTable schemaTable1 = conn1.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, new object[] { null, null, null, "TABLE" });
                    

                    string sheet1 = "TB_OPS_DAILY_TRADE_REPORT-20170$";
                    if (!sheet1.EndsWith("_"))
                    {
                        string query1 = "SELECT  * FROM [" + schemaTable1.Rows[3]["Table_Name"] + "]";
                        OleDbDataAdapter daexcel1 = new OleDbDataAdapter(query1, conn1);
                        dtexcel1.Locale = CultureInfo.CurrentCulture;
                        daexcel1.Fill(dtexcel1);

                    }
                    wb.Close();
                    app.Quit();
                    obj.ReleaseComObject(wb);
                    obj.ReleaseComObject(app);
                    DataTable d2 = new DataTable();
                    d2.Columns.Add("ORIGINAL");
                    d2.Columns.Add("CURR/AMOUNT1");
                    d2.Columns.Add("RC");
                    d2.Columns.Add("EXCH RATE");
                    d2.Columns.Add("EQV.");
                    d2.Columns.Add("CURR/AMOUNT2");
                    d2.Columns.Add("F.E CONT. #");
                    d2.Columns.Add("CUST");
                    d2.Columns.Add("ID/DEAL NO/STEP ID");
                    d2.Columns.Add("PURCHASE/SALE");
                    d2.Columns.Add("REMARKS");
                    d2.Columns.Add("13 DIG");
                    d2.Columns.Add("CON");
                    d2.Columns.Add("TREASURY REF");
                    d2.Columns.Add("VALUE DATE");
                    d2.Columns.Add("RECON DATE");
                    d2.Columns.Add("NARRATION");
                    d2.Columns.Add("3 DIG");
                    d2.Columns.Add("AACODE");
                    for (int i = 0; i <= d1.Rows.Count - 1; i++)
                    {
                        string[] ar = System.Text.RegularExpressions.Regex.Split(d1.Rows[i][7].ToString(), @"\s{1,}");
                        d2.Rows.Add();
                        d2.Rows[i]["13 DIG"] = ar[1];
                        d2.Rows[i]["CON"] = ar[1] + "-" + d1.Rows[i][1].ToString();
                    }
                    for (int i = 0; i <= d1.Rows.Count - 1; i++)
                    {
                        for (int j = 0; j <= dtexcel1.Rows.Count - 1; j++)
                        {
                            if (d2.Rows[i]["CON"].ToString() == dtexcel1.Rows[j]["CON"].ToString())
                            {
                                string[] date1 = dtexcel1.Rows[i]["VALUEDATE"].ToString().Split('/');
                                string[] o = date1[2].ToString().Split(' ');
                                d2.Rows[i]["TREASURY REF"] = dtexcel1.Rows[j]["FRONTOFFICEREF"];
                                d2.Rows[i]["VALUE DATE"] = date1[1] + "-" + date1[0] + "-" + o[0];

                            }
                            if (DateTime.Now.AddDays(-1).DayOfWeek.ToString() == "Sunday")
                            {
                                string date = DateTime.Now.AddDays(-3).ToString("dd-MM-yyyy");
                                d2.Rows[i]["RECON DATE"] = date.ToString();
                            }
                            else
                            {
                                string date = DateTime.Now.AddDays(-1).ToString("dd-MM-yyyy");
                                d2.Rows[i]["RECON DATE"] = date.ToString();
                            }

                        }
                    }

                    for (int i = 0; i <= d2.Rows.Count - 1; i++)
                    {
                        if (d2.Rows[i]["TREASURY REF"].ToString() == "")
                        {
                            d2.Rows[i]["TREASURY REF"] = "NA";
                            d2.Rows[i]["VALUE DATE"] = "NA";
                        }
                    }
                    for (int i = 0; i <= d1.Rows.Count - 1; i++)
                    {
                        d1.Rows[i]["13 DIG"] = d2.Rows[i]["13 DIG"];
                        d1.Rows[i]["CON"] = d2.Rows[i]["CON"];
                        d1.Rows[i]["TREASURY REF"] = d2.Rows[i]["TREASURY REF"];
                        d1.Rows[i]["VALUE DATE"] = d2.Rows[i]["VALUE DATE"];
                        d1.Rows[i]["RECON DATE"] = d2.Rows[i]["RECON DATE"];
                    }
                    //d1.Merge(d2);

                    DataTable d3 = new DataTable();
                    d3.Columns.Add("ORIGINAL");
                    d3.Columns.Add("CURR/AMOUNT1");
                    d3.Columns.Add("RC");
                    d3.Columns.Add("EXCH RATE");
                    d3.Columns.Add("EQV.");
                    d3.Columns.Add("CURR/AMOUNT2");
                    d3.Columns.Add("F.E CONT. #");
                    d3.Columns.Add("CUST");
                    d3.Columns.Add("ID/DEAL NO/STEP ID");
                    d3.Columns.Add("PURCHASE/SALE");
                    d3.Columns.Add("REMARKS");

                    d3.Columns.Add("13 DIG");
                    d3.Columns.Add("CON");
                    d3.Columns.Add("TREASURY REF");
                    d3.Columns.Add("VALUE DATE");
                    d3.Columns.Add("RECON DATE");
                    d3.Columns.Add("NARRATION");
                    d3.Columns.Add("3 DIG");
                    d3.Columns.Add("AACODE");
                    DataTable d4 = new DataTable();
                    d4.Columns.Add("ORIGINAL");
                    d4.Columns.Add("CURR/AMOUNT1");
                    d4.Columns.Add("RC");
                    d4.Columns.Add("EXCH RATE");
                    d4.Columns.Add("EQV.");
                    d4.Columns.Add("CURR/AMOUNT2");
                    d4.Columns.Add("F.E CONT. #");
                    d4.Columns.Add("CUST");
                    d4.Columns.Add("ID/DEAL NO/STEP ID");
                    d4.Columns.Add("PURCHASE/SALE");
                    d4.Columns.Add("REMARKS");
                    d4.Columns.Add("13 DIG");
                    d4.Columns.Add("CON");
                    d4.Columns.Add("TREASURY REF");
                    d4.Columns.Add("VALUE DATE");
                    d4.Columns.Add("RECON DATE");
                    d4.Columns.Add("NARRATION");
                    d4.Columns.Add("3 DIG");
                    d4.Columns.Add("AACODE");
                    int x = 0;
                    int y = 0;
                    for (int i = 0; i <= d1.Rows.Count - 1; i++)
                    {

                        if (d1.Rows[i]["PURCHASE/SALE"].ToString().Trim() == "CR")
                        {
                            string[] split1 = d1.Rows[i]["CUST"].ToString().Split(' ');
                            d3.Rows.Add();
                            d3.Rows[x]["ORIGINAL"] = d1.Rows[i]["ORIGINAL"];
                            d3.Rows[x]["CURR/AMOUNT1"] = d1.Rows[i]["CURR/AMOUNT1"];
                            d3.Rows[x]["RC"] = d1.Rows[i]["RC"];
                            d3.Rows[x]["EXCH RATE"] = d1.Rows[i]["EXCH RATE"];
                            d3.Rows[x]["EQV."] = d1.Rows[i]["EQV."];
                            d3.Rows[x]["CURR/AMOUNT2"] = d1.Rows[i]["CURR/AMOUNT2"];
                            d3.Rows[x]["F.E CONT. #"] = d1.Rows[i]["F.E CONT. #"];
                            d3.Rows[x]["CUST"] = split1[0].Trim();
                            d3.Rows[x]["ID/DEAL NO/STEP ID"] = split1[1].Trim() + " " + d1.Rows[i]["ID/DEAL NO/STEP ID"];
                            d3.Rows[x]["PURCHASE/SALE"] = d1.Rows[i]["PURCHASE/SALE"];
                            d3.Rows[x]["REMARKS"] = d1.Rows[i]["REMARKS"];
                            d3.Rows[x]["13 DIG"] = d1.Rows[i]["13 DIG"];
                            d3.Rows[x]["CON"] = d1.Rows[i]["CON"];
                            d3.Rows[x]["TREASURY REF"] = d1.Rows[i]["TREASURY REF"];
                            d3.Rows[x]["VALUE DATE"] = d1.Rows[i]["VALUE DATE"];
                            d3.Rows[x]["RECON DATE"] = d1.Rows[i]["RECON DATE"];
                            //d3.Rows[x]["TREASURY REF"] = d1.Rows[i]["TREASURY REF"];
                            d3.Rows[x]["NARRATION"] = d1.Rows[i]["NARRATION"];
                            d3.Rows[x]["3 DIG"] = d1.Rows[i]["3 DIG"];
                            d3.Rows[x]["AACODE"] = d1.Rows[i]["AACODE"];
                            x++;
                        }
                        else if (d1.Rows[i]["PURCHASE/SALE"].ToString().Trim() == "DR")
                        {
                            string[] split1 = d1.Rows[i]["CUST"].ToString().Split(' ');
                            d4.Rows.Add();
                            d4.Rows[y]["ORIGINAL"] = d1.Rows[i]["ORIGINAL"];
                            d4.Rows[y]["CURR/AMOUNT1"] = d1.Rows[i]["CURR/AMOUNT1"];
                            d4.Rows[y]["RC"] = d1.Rows[i]["RC"];
                            d4.Rows[y]["EXCH RATE"] = d1.Rows[i]["EXCH RATE"];
                            d4.Rows[y]["EQV."] = d1.Rows[i]["EQV."];
                            d4.Rows[y]["CURR/AMOUNT2"] = d1.Rows[i]["CURR/AMOUNT2"];
                            d4.Rows[y]["F.E CONT. #"] = d1.Rows[i]["F.E CONT. #"];
                            d4.Rows[y]["CUST"] = split1[0].Trim();
                            d4.Rows[y]["ID/DEAL NO/STEP ID"] = split1[1].Trim() + " " + d1.Rows[i]["ID/DEAL NO/STEP ID"];
                            d4.Rows[y]["PURCHASE/SALE"] = d1.Rows[i]["PURCHASE/SALE"];
                            d4.Rows[y]["REMARKS"] = d1.Rows[i]["REMARKS"];
                            d4.Rows[y]["13 DIG"] = d1.Rows[i]["13 DIG"];
                            d4.Rows[y]["CON"] = d1.Rows[i]["CON"];
                            d4.Rows[y]["TREASURY REF"] = d1.Rows[i]["TREASURY REF"];
                            d4.Rows[y]["VALUE DATE"] = d1.Rows[i]["VALUE DATE"];
                            d4.Rows[y]["RECON DATE"] = d1.Rows[i]["RECON DATE"];
                            //d4.Rows[y]["TREASURY REF"] = d1.Rows[i]["TREASURY REF"];
                            d4.Rows[y]["NARRATION"] = d1.Rows[i]["NARRATION"];
                            d4.Rows[y]["3 DIG"] = d1.Rows[i]["3 DIG"];
                            d4.Rows[y]["AACODE"] = d1.Rows[i]["AACODE"];
                            y++;
                        }

                    }
                    d3.Merge(d4);
                    d3.Columns["PURCHASE/SALE"].SetOrdinal(2);
                    for (int i = 0; i <= d1.Rows.Count - 1; i++)
                    {
                        if (d3.Rows[i]["PURCHASE/SALE"].ToString() == "CR")
                        {
                            d3.Rows[i]["CURR/AMOUNT1"] = "-" + d3.Rows[i]["CURR/AMOUNT1"];
                            d3.Rows[i]["NARRATION"] = "TREASURY POSTED PURCHASE";
                            d3.Rows[i]["3 DIG"] = "TREASURY POSTED PURCHASE";
                            d3.Rows[i]["3 DIG"] = d3.Rows[i]["ID/DEAL NO/STEP ID"].ToString().Trim().Substring(0, 3);
                        }
                        else
                        {
                            d3.Rows[i]["CURR/AMOUNT1"] = "+" + d3.Rows[i]["CURR/AMOUNT1"];
                            d3.Rows[i]["NARRATION"] = "TREASURY POSTED SALE";
                            d3.Rows[i]["3 DIG"] = d3.Rows[i]["ID/DEAL NO/STEP ID"].ToString().Trim().Substring(0, 3);
                        }
                    }
                    System.Data.DataTable table = new System.Data.DataTable();

                    SqlConnection con = new SqlConnection(ConStr);
                    SqlDataAdapter ad = new SqlDataAdapter("ARC_SP_GetListForHongkongTrade_RPR_21B", con);
                    ad.SelectCommand.CommandType = CommandType.StoredProcedure;

                    con.Open();
                    ad.Fill(table);
                    con.Close();
                    DataTable d5 = new DataTable();
                    d5.Columns.Add("AACODE");
                    for (int i = 0; i <= d3.Rows.Count - 1; i++)
                    {
                        for (int j = 0; j <= table.Rows.Count - 1; j++)
                        {
                            d5.Rows.Add();
                            if (d3.Rows[i]["3 DIG"].ToString().Trim() == table.Rows[j][1].ToString().Trim())
                            {
                                d5.Rows[i]["AACODE"] = table.Rows[j][0];
                            }

                        }
                    }

                    for (int i = 0; i <= d3.Rows.Count - 1; i++)
                    {
                        d3.Rows[i]["AACODE"] = d5.Rows[i]["AACODE"];
                    }
                    for (int i = 0; i <= d3.Rows.Count - 1; i++)
                    {
                        if (d3.Rows[i]["RC"].ToString().Trim() == "B")
                        {
                            d3.Rows.RemoveAt(i);
                        }
                    }

                    Hong_Kong_ExportToExcel(d3, Output_Path + "Final_TB_OPS_DAILY_TRADE_REPORT_1.xls", Main_DIR_Path);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void HongKong_Formatting_60opx(string Source_Path, string Country_Name, string ConStr, string FileName, string Output_Path, string File_Ext, string Main_DIR_Path)
        {
            try
            {
                string RequiredPath_1 = Output_Path + "TB_OPS_DAILY_TRADE_REPORT " + DateTime.Now.ToString("dd-MMM-yyyy") + "." + File_Ext;
                string RequiredPath_2 = Output_Path + "TB_OPS_DAILY_TRADE_REPORT " + DateTime.Now.AddDays(-1).ToString("dd-MMM-yyyy") + "." + File_Ext;
                string date = DateTime.Now.AddDays(-1).ToString("yyyyMMdd");
                bool hasHeaders = true;
                if (File.Exists(Source_Path))
                {
                    string HDR = hasHeaders ? "Yes" : "No";
                    string strConn;

                    if (Source_Path.Substring(Source_Path.LastIndexOf('.')).ToLower() == ".xls")
                        strConn = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + Source_Path + ";Extended Properties=\"Excel 12.0;HDR=" + HDR + ";IMEX=1\"";
                    //strConn = "Provider=Microsoft.Jet.OleDb.4.0; Data Source = " + System.IO.Path.GetDirectoryName(ExcelfilePath) + "; Extended Properties = 'text;HDR=YES;IMEX=1v;FMT=Delimited(,)';";
                    else
                        strConn = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + Source_Path + ";Extended Properties=\"Excel 8.0;HDR=" + HDR + ";IMEX=1\"";
                    System.Data.DataTable dtexcel = new System.Data.DataTable();
                    OleDbConnection conn = new OleDbConnection(strConn);
                    conn.Open();
                    System.Data.DataTable schemaTable = conn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, new object[] { null, null, null, "TABLE" });

                    DataRow schemaRow = schemaTable.Rows[0];
                    string sheet = schemaRow["TABLE_NAME"].ToString();
                    if (!sheet.EndsWith("_"))
                    {
                        string query = "SELECT  * FROM [" + sheet + "]";
                        OleDbDataAdapter daexcel = new OleDbDataAdapter(query, conn);
                        dtexcel.Locale = CultureInfo.CurrentCulture;
                        daexcel.Fill(dtexcel);
                    }
                    for (int i = 0; i <= dtexcel.Rows.Count - 1; i++)
                    {
                        if (dtexcel.Rows[i][0].ToString() == "")
                        {
                            string s = dtexcel.Rows[i][1].ToString();
                            if (s.All(char.IsDigit) == true)
                            {
                                dtexcel.Rows[i][0] = dtexcel.Rows[i - 1][1];
                            }
                            else
                            {
                                dtexcel.Rows[i][0] = dtexcel.Rows[i - 1][0];
                            }
                        }
                    }
                    for (int i = 0; i <= dtexcel.Rows.Count - 1; i++)
                    {
                        string s = dtexcel.Rows[i][0].ToString();
                        if (s.All(char.IsDigit) == true)
                        {
                            dtexcel.Rows[i][0] = dtexcel.Rows[i - 1][0];
                        }
                    }
                    for (int i = dtexcel.Rows.Count - 1; i >= 0; i--)
                    {
                        if (dtexcel.Rows[i][0].ToString().Contains("AA Code"))
                        {
                            dtexcel.Rows.RemoveAt(i);
                        }
                    }
                    dtexcel.Rows.RemoveAt(0);
                    dtexcel.Rows.RemoveAt(1);
                    System.Data.DataTable table = new System.Data.DataTable();
                    string con_Str = @"Data Source=ukwpidsql500i1.gdc-dev.net\DEV_CL01_IN01, 10501; Initial Catalog=CRC_QMT; User id=CRCAdmin; Password=c275bpOSJ";
                    SqlConnection con = new SqlConnection(con_Str);
                    SqlDataAdapter ad = new SqlDataAdapter("ARC_SP_GetListForHongkongTrade_RPR_60opx", con);
                    ad.SelectCommand.CommandType = CommandType.StoredProcedure;

                    con.Open();
                    ad.Fill(table);
                    con.Close();
                    System.Data.DataTable dt1 = new System.Data.DataTable();

                    System.Data.DataTable dd1 = new System.Data.DataTable();
                    dd1.Columns.Add("AACODE");
                    dd1.Columns.Add("DEALNO");
                    dd1.Columns.Add("MNEMONIC");
                    dd1.Columns.Add("NULL");
                    dd1.Columns.Add("PURCH CCY");
                    dd1.Columns.Add("AMOUNT1");
                    dd1.Columns.Add("BASE AMOUNT1");
                    dd1.Columns.Add("SALE CCY");
                    dd1.Columns.Add("AMOUNT2");
                    dd1.Columns.Add("BASE AMOUNT2");
                    int y = 0;
                    for (int i = 0; i <= dtexcel.Rows.Count - 1; i++)
                    {
                        for (int j = 0; j <= table.Rows.Count - 1; j++)
                        {
                            string datasheet = table.Rows[j][0].ToString();
                            string actual = dtexcel.Rows[i][0].ToString();
                            if (datasheet.Trim() == actual.Trim())
                            {
                                dd1.Rows.Add();
                                dd1.Rows[y]["AACODE"] = dtexcel.Rows[i][0];
                                dd1.Rows[y]["DEALNO"] = dtexcel.Rows[i][1];
                                dd1.Rows[y]["MNEMONIC"] = dtexcel.Rows[i][2];
                                dd1.Rows[y]["PURCH CCY"] = dtexcel.Rows[i][4];
                                dd1.Rows[y]["AMOUNT1"] = dtexcel.Rows[i][5];
                                dd1.Rows[y]["BASE AMOUNT1"] = dtexcel.Rows[i][6];
                                dd1.Rows[y]["SALE CCY"] = dtexcel.Rows[i][8];
                                dd1.Rows[y]["AMOUNT2"] = dtexcel.Rows[i][9];
                                dd1.Rows[y]["BASE AMOUNT2"] = dtexcel.Rows[i][10];
                                y++;
                            }
                        }
                    }

                    System.Data.DataTable dt = new System.Data.DataTable();
                    dt.Columns.Add("AACODE");
                    dt.Columns.Add("DEALNO");
                    dt.Columns.Add("MNEMONIC");
                    dt.Columns.Add("PURCH CCY");
                    dt.Columns.Add("AMOUNT1");
                    dt.Columns.Add("BASE AMOUNT1");

                    for (int i = 0; i <= dd1.Rows.Count - 1; i++)
                    {
                        dt.Rows.Add();
                        dt.Rows[i]["AACODE"] = dd1.Rows[i]["AACODE"];
                        dt.Rows[i]["DEALNO"] = dd1.Rows[i]["DEALNO"];
                        dt.Rows[i]["MNEMONIC"] = dd1.Rows[i]["MNEMONIC"];
                        dt.Rows[i]["PURCH CCY"] = dd1.Rows[i]["PURCH CCY"];
                        dt.Rows[i]["AMOUNT1"] = dd1.Rows[i]["AMOUNT1"];
                        dt.Rows[i]["BASE AMOUNT1"] = dd1.Rows[i]["BASE AMOUNT1"];
                    }

                    System.Data.DataTable d1 = new System.Data.DataTable();
                    d1.Columns.Add("AACODE");
                    d1.Columns.Add("DEALNO");
                    d1.Columns.Add("MNEMONIC");

                    d1.Columns.Add("PURCH CCY");
                    d1.Columns.Add("AMOUNT1");
                    d1.Columns.Add("BASE AMOUNT1");
                    d1.Columns.Add("PURCHASE/SALE");
                    for (int i = 0; i <= dd1.Rows.Count - 1; i++)
                    {
                        d1.Rows.Add();
                        d1.Rows[i]["AACODE"] = dd1.Rows[i]["AACODE"];
                        d1.Rows[i]["DEALNO"] = dd1.Rows[i]["DEALNO"];
                        d1.Rows[i]["MNEMONIC"] = dd1.Rows[i]["MNEMONIC"];
                        d1.Rows[i]["PURCH CCY"] = dd1.Rows[i]["SALE CCY"];
                        d1.Rows[i]["AMOUNT1"] = "-" + dd1.Rows[i]["AMOUNT2"];
                        string cmp = dtexcel.Rows[0][3].ToString();
                        d1.Rows[i]["BASE AMOUNT1"] = "-" + dd1.Rows[i]["BASE AMOUNT2"];
                        d1.Rows[i]["PURCHASE/SALE"] = "TREASURY POSTED SALE";

                    }
                    System.Data.DataTable d2 = new System.Data.DataTable();
                    d2.Columns.Add("AACODE");
                    d2.Columns.Add("DEALNO");
                    d2.Columns.Add("MNEMONIC");

                    d2.Columns.Add("PURCH CCY");
                    d2.Columns.Add("AMOUNT1");
                    d2.Columns.Add("BASE AMOUNT1");
                    d2.Columns.Add("PURCHASE/SALE");

                    for (int i = 0; i <= dd1.Rows.Count - 1; i++)
                    {
                        d2.Rows.Add();

                        d2.Rows[i]["AACODE"] = dd1.Rows[i]["AACODE"];
                        d2.Rows[i]["DEALNO"] = dd1.Rows[i]["DEALNO"];

                        d2.Rows[i]["MNEMONIC"] = dd1.Rows[i]["MNEMONIC"];

                        d2.Rows[i]["PURCH CCY"] = dd1.Rows[i]["PURCH CCY"];
                        d2.Rows[i]["AMOUNT1"] = dd1.Rows[i]["AMOUNT1"];
                        d2.Rows[i]["BASE AMOUNT1"] = dd1.Rows[i]["BASE AMOUNT1"];
                        d2.Rows[i]["PURCHASE/SALE"] = "TREASURY POSTED PURCHASE";

                    }

                    d2.Merge(d1);
                    for (int i = d2.Rows.Count - 1; i >= 0; i--)
                    {
                        if (d2.Rows[i]["PURCH CCY"].ToString().Trim() == "")
                        {
                            d2.Rows.RemoveAt(i);
                        }
                    }
                    d2.Columns.Add("13 DIG").SetOrdinal(2);
                    d2.Columns.Add("TRADEID1").SetOrdinal(3);
                    d2.Columns.Add("VALUEDATE").SetOrdinal(4);

                    if (File.Exists(RequiredPath_1))//1st File
                    {
                        string HDR1 = hasHeaders ? "Yes" : "No";
                        string strConn1;

                        if (Source_Path.Substring(Source_Path.LastIndexOf('.')).ToLower() == ".xls")
                            strConn1 = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + RequiredPath_1 + ";Extended Properties=\"Excel 12.0;HDR=" + HDR1 + ";IMEX=1\"";
                        //strConn = "Provider=Microsoft.Jet.OleDb.4.0; Data Source = " + System.IO.Path.GetDirectoryName(ExcelfilePath) + "; Extended Properties = 'text;HDR=YES;IMEX=1v;FMT=Delimited(,)';";
                        else
                            strConn1 = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + RequiredPath_1 + ";Extended Properties=\"Excel 8.0;HDR=" + HDR + ";IMEX=1\"";
                        System.Data.DataTable dtexcel1 = new System.Data.DataTable();
                        OleDbConnection conn1 = new OleDbConnection(strConn1);
                        conn1.Open();
                        System.Data.DataTable schemaTable1 = conn1.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, new object[] { null, null, null, "TABLE" });

                        string sheet1 = "TB_OPS_DAILY_TRADE_REPORT-20170$";
                        if (!sheet.EndsWith("_"))
                        {
                            string query1 = "SELECT  * FROM [" + sheet1 + "]";
                            OleDbDataAdapter daexcel1 = new OleDbDataAdapter(query1, conn1);
                            dtexcel1.Locale = CultureInfo.CurrentCulture;
                            daexcel1.Fill(dtexcel1);
                        }
                        System.Data.DataTable d3 = new System.Data.DataTable();
                        d3.Columns.Add("FRONTOFFICE1");
                        d3.Columns.Add("13 DIG");
                        d3.Columns.Add("TRADEID1");
                        d3.Columns.Add("VALUEDATE");
                        for (int i = 0; i <= dtexcel1.Rows.Count - 1; i++)
                        {
                            d3.Rows.Add();
                            d3.Rows[i]["FRONTOFFICE1"] = dtexcel1.Rows[i]["FRONTOFFICEREF1"];
                            if (Regex.IsMatch(dtexcel1.Rows[i]["CLIENTID"].ToString(), @"^[0-9]"))
                            {
                                string s = string.Join("", dtexcel1.Rows[i]["CLIENTID"].ToString().Where(char.IsDigit));

                                if (s.Length >= 13)
                                {
                                    d3.Rows[i]["13 DIG"] = s.Substring(0, 12);
                                }
                                else
                                {
                                    d3.Rows[i]["13 DIG"] = s.Substring(0, 11);
                                }
                            }
                            else
                            {
                                d3.Rows[i]["13 DIG"] = dtexcel1.Rows[i]["CLIENTID"].ToString().Substring(0, 13);
                            }

                            d3.Rows[i]["TRADEID1"] = dtexcel1.Rows[i]["TRADEID1"];
                            d3.Rows[i]["VALUEDATE"] = Convert.ToDateTime(dtexcel1.Rows[i]["VALUEDATE"]).ToString("dd-MM-yyyy");
                        }
                        System.Data.DataTable Finddeal = new System.Data.DataTable();
                        Finddeal.Columns.Add("FRONTOFFICE1");
                        Finddeal.Columns.Add("13 DIG");
                        Finddeal.Columns.Add("TRADEID1");
                        Finddeal.Columns.Add("VALUEDATE");

                        for (int i = 0; i <= d2.Rows.Count - 1; i++)
                        {
                            for (int j = 0; j <= d3.Rows.Count - 1; j++)
                            {

                                string datasheet = d3.Rows[j][0].ToString();
                                string actual = d2.Rows[i][1].ToString();
                                if (datasheet.Trim() == actual.Trim())
                                {
                                    d2.Rows[i]["13 DIG"] = d3.Rows[j]["13 DIG"];
                                    d2.Rows[i]["TRADEID1"] = d3.Rows[j]["TRADEID1"];
                                    d2.Rows[i]["VALUEDATE"] = d3.Rows[j]["VALUEDATE"];
                                }
                            }
                        }
                    }

                    if (File.Exists(RequiredPath_2))//PreviousDay_File
                    {
                        string HDR1 = hasHeaders ? "Yes" : "No";
                        string strConn1;

                        if (Source_Path.Substring(Source_Path.LastIndexOf('.')).ToLower() == ".xls")
                            strConn1 = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + RequiredPath_2 + ";Extended Properties=\"Excel 12.0;HDR=" + HDR1 + ";IMEX=1\"";
                        //strConn = "Provider=Microsoft.Jet.OleDb.4.0; Data Source = " + System.IO.Path.GetDirectoryName(ExcelfilePath) + "; Extended Properties = 'text;HDR=YES;IMEX=1v;FMT=Delimited(,)';";
                        else
                            strConn1 = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + RequiredPath_2 + ";Extended Properties=\"Excel 8.0;HDR=" + HDR1 + ";IMEX=1\"";
                        System.Data.DataTable dtexcel1 = new System.Data.DataTable();
                        OleDbConnection conn1 = new OleDbConnection(strConn1);
                        conn1.Open();
                        System.Data.DataTable schemaTable1 = conn1.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, new object[] { null, null, null, "TABLE" });

                        string sheet1 = "TB_OPS_DAILY_TRADE_REPORT-20170$";
                        if (!sheet.EndsWith("_"))
                        {
                            string query1 = "SELECT  * FROM [" + sheet1 + "]";
                            OleDbDataAdapter daexcel1 = new OleDbDataAdapter(query1, conn1);
                            dtexcel1.Locale = CultureInfo.CurrentCulture;
                            daexcel1.Fill(dtexcel1);
                        }
                        System.Data.DataTable d3 = new System.Data.DataTable();
                        d3.Columns.Add("FRONTOFFICE1");
                        d3.Columns.Add("13 DIG");
                        d3.Columns.Add("TRADEID1");
                        d3.Columns.Add("VALUEDATE");
                        for (int i = 0; i <= dtexcel1.Rows.Count - 1; i++)
                        {
                            d3.Rows.Add();
                            d3.Rows[i]["FRONTOFFICE1"] = dtexcel1.Rows[i]["FRONTOFFICEREF1"];
                            if (Regex.IsMatch(dtexcel1.Rows[i]["CLIENTID"].ToString(), @"^[0-9]"))
                            {
                                string s = string.Join("", dtexcel1.Rows[i]["CLIENTID"].ToString().Where(char.IsDigit));

                                if (s.Length >= 13)
                                {
                                    d3.Rows[i]["13 DIG"] = s.Substring(0, 12);

                                }
                                else
                                {
                                    d3.Rows[i]["13 DIG"] = s.Substring(0, 11);
                                }
                            }
                            else
                            {
                                d3.Rows[i]["13 DIG"] = dtexcel1.Rows[i]["CLIENTID"].ToString().Substring(0, 13);
                            }
                            d3.Rows[i]["TRADEID1"] = dtexcel1.Rows[i]["TRADEID1"];
                            d3.Rows[i]["VALUEDATE"] = Convert.ToDateTime(dtexcel1.Rows[i]["VALUEDATE"]).ToString("dd-MM-yyyy");
                        }
                        System.Data.DataTable Finddeal = new System.Data.DataTable();
                        Finddeal.Columns.Add("FRONTOFFICE1");
                        Finddeal.Columns.Add("13 DIG");
                        Finddeal.Columns.Add("TRADEID1");
                        Finddeal.Columns.Add("VALUEDATE");

                        for (int i = 0; i <= d2.Rows.Count - 1; i++)
                        {
                            for (int j = 0; j <= d3.Rows.Count - 1; j++)
                            {
                                if (j <= d3.Rows.Count - 1)
                                {
                                    string datasheet = d3.Rows[j][0].ToString();
                                    string actual = d2.Rows[i][1].ToString();
                                    if (datasheet.Trim() == actual.Trim())
                                    {
                                        d2.Rows[i]["13 DIG"] = d3.Rows[j]["13 DIG"];
                                        d2.Rows[i]["TRADEID1"] = d3.Rows[j]["TRADEID1"];
                                        d2.Rows[i]["VALUEDATE"] = d3.Rows[j]["VALUEDATE"];
                                    }
                                }
                            }
                        }

                    }
                    Hong_Kong_ExportToExcel(d2, Output_Path + FileName + "." + File_Ext, Main_DIR_Path);
                }
                else
                {
                    MessageBox.Show("File not Present");
                }
            }
            catch 
            {
                MessageBox.Show("File not Present");
            }
        }

        public void Hong_Kong_ExportToExcel(System.Data.DataTable dtt, string f1, string Main_DIR_Path)
        {

            string folderdate = DateTime.Now.ToString("dd-MMM-yyyy");
            string excelFilePath = Main_DIR_Path + folderdate + "_Files\\Output\\Hong Kong Trade RPR\\HongKong_trade_RPR_TB_OPS_" + folderdate + ".xls";
            if (dtt == null || dtt.Columns.Count == 0)
                throw new Exception("ExportToExcel: Null or empty input table!\n");

            // load excel, and create a new workbook
            var excelApp = new Microsoft.Office.Interop.Excel.Application();

            Microsoft.Office.Interop.Excel.Workbook workBook = null;
            workBook = excelApp.Workbooks.Add(Type.Missing);               // single worksheet
            Microsoft.Office.Interop.Excel._Worksheet workSheet = (Excel.Worksheet)workBook.Worksheets.Add(Type.Missing);
            excelApp.DisplayAlerts = false;
            excelApp.Visible = false;
            //Microsoft.Office.Interop.Excel.Range range;
            // column headings
            for (var i = 0; i < dtt.Columns.Count; i++)
            {
                workSheet.Cells[1, i + 1] = dtt.Columns[i].ColumnName;
            }

            // rows
            for (var i = 0; i < dtt.Rows.Count; i++)
            {
                // to do: format datetime values before printing
                for (var k = 0; k < dtt.Columns.Count; k++)
                {
                    workSheet.Cells[i + 2, k + 1] = dtt.Rows[i][k];

                }
            }
            Microsoft.Office.Interop.Excel.Range usedrange = workSheet.UsedRange;
            Microsoft.Office.Interop.Excel.Range rows = usedrange.Rows;
            int count = 0;
            foreach (Microsoft.Office.Interop.Excel.Range row in rows)
            {
                if (count > 0)
                {
                    Microsoft.Office.Interop.Excel.Range firstcell = (Excel.Range)row.Cells[8];
                    string fsv = firstcell.Value as String;
                    if (fsv != "HKD")
                    {
                        row.Interior.Color = System.Drawing.Color.Yellow;
                    }
                }
                count++;
            }
            Excel.Range r = usedrange.get_Range("A1", Type.Missing);
            r.EntireRow.Font.Bold = true;
            Microsoft.Office.Interop.Excel.Borders border = usedrange.Borders;
            border.LineStyle = Microsoft.Office.Interop.Excel.XlLineStyle.xlContinuous;
            border.Weight = 2d;
            workSheet.Columns.EntireColumn.AutoFit();
            /*workSheet.Columns[2].ColumnWidth = 25;
            workSheet.Columns[3].ColumnWidth = 25;
            workSheet.Columns[6].ColumnWidth = 40;
            workSheet.Columns[7].ColumnWidth = 18;
            workSheet.Columns[8].ColumnWidth = 18;
            workSheet.Columns[9].ColumnWidth = 18;
            workSheet.Columns[10].ColumnWidth = 30;*/
            // check file path
            if (!string.IsNullOrEmpty(excelFilePath))
            {

                workBook.SaveCopyAs(excelFilePath);
                if (File.Exists(excelFilePath))
                {
                    File.Copy(excelFilePath, f1);
                }
                excelApp.Quit();

                obj.ReleaseComObject(workSheet);
                obj.ReleaseComObject(workBook);
                obj.ReleaseComObject(excelApp);
            }
        }
    }
}
