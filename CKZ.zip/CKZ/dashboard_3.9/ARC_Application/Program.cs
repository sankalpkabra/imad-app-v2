﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace ARC_Application
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new ARC_Login_New());//Dashboard//ARC_Login//Dashboard//Main_Admin_DashBoard_New//ARC_Login_New
        }
    }
}
