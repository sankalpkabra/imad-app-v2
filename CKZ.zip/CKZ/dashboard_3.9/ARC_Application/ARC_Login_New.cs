﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;
using System.Security.Cryptography;
using System.Configuration;
using Scripting;
using System.Collections;
using DAccesss;
//using Microsoft.Office.Interop.Outlook;


namespace ARC_Application
{
    public partial class ARC_Login_New : Form
    {
        ApplicationClass Aps = new ApplicationClass();
        string conString = ConfigurationManager.ConnectionStrings["ARC_conStr"].ConnectionString;
        SQLEncryption ecp = new SQLEncryption();
        public string setValue;
        public SqlConnection conn;
        public SqlCommand com;
        DAccesss.Program das = new DAccesss.Program();

        public ARC_Login_New()
        {
            InitializeComponent();
            comboBox1.SelectedIndex = 0;
            if (!conString.StartsWith("Data"))
            {
                conString = ecp.Decrypt(conString);
            }
        }
        public void CheckFileRunning()
        {
            #region Checking Drive
            FileSystemObject FSO = new FileSystemObject();
            string sDrive = FSO.GetDriveName(Application.ExecutablePath);
            Drive drvName = FSO.GetDrive(sDrive);
            string sShare = drvName.ShareName;
            bool sExist = FSO.DriveExists(sDrive);
            bool sFolderExist = FSO.FolderExists(Application.ExecutablePath);
            bool sFileExist = FSO.FileExists(Application.ExecutablePath);
            if (sExist && sFolderExist || sFileExist)
            {
                if (sFileExist)
                {
                    if (sShare == null)
                    {
                        MessageBox.Show("Sorry! You can't use this Utility From Local Drive.!...", "Application Not Running!..", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        this.Close();
                        Application.Exit();

                    }
                }
                else
                {
                    comboBox1.SelectedIndex = 0;
                }
            }
            #endregion
        }
        private void Initialize()
        {

        }

        private string Encrypt(string clearText)
        {
            try
            {
                string EncryptionKey = "MAKV2SPBNI99212";
                byte[] clearBytes = Encoding.Unicode.GetBytes(clearText);
                using (Aes encryptor = Aes.Create())
                {
                    Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
                    encryptor.Key = pdb.GetBytes(32);
                    encryptor.IV = pdb.GetBytes(16);
                    using (MemoryStream ms = new MemoryStream())
                    {
                        using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateEncryptor(), CryptoStreamMode.Write))
                        {
                            cs.Write(clearBytes, 0, clearBytes.Length);
                            cs.Close();
                        }
                        clearText = Convert.ToBase64String(ms.ToArray());
                    }
                }
                return clearText;
            }
            catch
            {
                return null;
            }
        }

        private string Decrypt(string cipherText)
        {
            try
            {
                string EncryptionKey = "MAKV2SPBNI99212";
                byte[] cipherBytes = Convert.FromBase64String(cipherText);
                using (Aes encryptor = Aes.Create())
                {
                    Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
                    encryptor.Key = pdb.GetBytes(32);
                    encryptor.IV = pdb.GetBytes(16);
                    using (MemoryStream ms = new MemoryStream())
                    {
                        using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateDecryptor(), CryptoStreamMode.Write))
                        {
                            cs.Write(cipherBytes, 0, cipherBytes.Length);
                            cs.Close();
                        }
                        cipherText = Encoding.Unicode.GetString(ms.ToArray());
                    }
                }
                return cipherText;
            }
            catch
            {
                return null;
            }
        }

        public void Login_Check()
        {
            try
            {
                string UserID = Txt_UserID.Text;
                if (Txt_UserID.Text == Environment.UserName)
                {
                    SqlConnection con = new SqlConnection(conString);
                    con.Open();
                    SqlCommand com = new SqlCommand("select EndDate from dbo.ARC_User_Info where UserID=@UserID", con);
                    com.CommandType = CommandType.Text;
                    com.Parameters.AddWithValue("@UserID", UserID);
                    SqlDataReader dr = com.ExecuteReader();
                    while (dr.Read())
                    {
                        if (dr.HasRows == true)
                        {
                            DateTime LastDate = (DateTime)dr["EndDate"];
                            DateTime LastDate1 = LastDate.AddDays(-1);
                            DateTime LastDate2 = LastDate.AddDays(-2);
                            DateTime ValidDate = DateTime.Today;///Changed
                            int DaysRemaining = LastDate.Day - ValidDate.Day;
                           
                            if ((LastDate1 == ValidDate) || (LastDate2 == ValidDate))
                            {
                                Microsoft.Office.Interop.Outlook.Application app = new Microsoft.Office.Interop.Outlook.Application();
                                Microsoft.Office.Interop.Outlook.MailItem mailItem = app.CreateItem(Microsoft.Office.Interop.Outlook.OlItemType.olMailItem);
                                mailItem.Subject = "Remainder: ARC Password Reset";
                                mailItem.To = UserID;
                                mailItem.Body = "Dear User, \n"
                                             + "\n"
                                             + "Your LAN ID password is about to expire in " + DaysRemaining + " days. \n" + " \n"
                                             + "User ID: " + Environment.UserName + " \n"
                                             + "Password Expiry Date: " + LastDate.ToShortDateString() + " \n"
                                             + "\n"
                                             + "Please change the password before it expires in order to avoid disruption to your access to SCB systems.  \n"
                                             + "\n"
                                             + "User are required to change password every 90 days as part of the security requirement. \n"
                                             + "If you have recently changed your LAN ID password, you can disregard this email. \n"
                                             + "\n"
                                             + "This is a computer generated email, please do NOT reply to this email. \n";

                                mailItem.Importance = Microsoft.Office.Interop.Outlook.OlImportance.olImportanceHigh;
                                mailItem.Display(false);
                                mailItem.Send();
                            }

                        }
                    }
                    con.Close();
                }
                else
                {
                    MessageBox.Show("Unauthorized user login");
                    Txt_Psd.Text = "";
                }
            }
            catch
            {

            }


        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                conn = new SqlConnection(conString);
                string UserID = Txt_UserID.Text;
                //string Psd = Aps.Encryption(Txt_Psd.Text, "rajaking");
                string Psd = Txt_Psd.Text;
                string role = "Admin";
                conn.Open();
                com = new SqlCommand("insert into ARC_User_Info(UserID,Password,UserRole) values(@UserID,@Password,@UserRole)", conn);
                com.CommandType = CommandType.Text;
                com.Parameters.AddWithValue("@UserID", UserID);
                com.Parameters.AddWithValue("@Password", Encrypt(Psd.Trim()));
                com.Parameters.AddWithValue("@UserRole", role);
                com.ExecuteNonQuery();
                conn.Close();
            }
            catch
            {

            }
        }

        private void ARC_Login_Load(object sender, EventArgs e)
        {
            conn = new SqlConnection(conString);
            try
            {
                //CheckFileRunning();

                Txt_UserID.Text = Environment.UserName;
                Txt_UserID.Enabled = false;

                if (Txt_UserID.Text == string.Empty)
                {
                    comboBox1.Enabled = false;
                }

                conn.Open();
                string qry1 = "select UserRole from dbo.ARC_User_Info where UserID='" + Txt_UserID.Text + "'";
                com = new SqlCommand(qry1, conn);
                com.Parameters.AddWithValue("@UserID", Txt_UserID.Text);
                SqlDataReader dr = com.ExecuteReader();// this line show the exception....
                while (dr.Read())
                {
                    if (dr.HasRows == true)
                    {
                        string UserRole = (string)dr["UserRole"];
                        string cmb = comboBox1.SelectedItem.ToString();
                        if (UserRole.Equals("DataUpload User"))
                        {
                            comboBox1.Enabled = false;
                        }

                    }
                }
                conn.Close();
               
            }
            catch (SqlException ex)
            {
                if(ex.Message.ToLower().Contains("timeout"))
                    MessageBox.Show("Connection Timedout. Please try again after sometimes.");

                if (ex.Message.ToLower().Contains("network"))
                    MessageBox.Show("Network Related Issue. Please try again after sometimes.");

                this.Close();
            }
        }

        private void CheckEnterKeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Return)
            {
                Btn_login_Click_1(sender, e);
            }
        }

        public void Btn_login_Click_1(object sender, EventArgs e)
        {
            conn = new SqlConnection(conString);
            string UserID = Txt_UserID.Text;
            string Psd = Txt_Psd.Text;
            object FirsttimeLogin = null;
            int Flag = 0;
            try
            {
                if (Txt_UserID.Text == string.Empty)
                {
                    MessageBox.Show("Please Enter a valid UserID!");
                    return;
                }
                if (Txt_UserID.Text == Environment.UserName)
                {
                    Login_Check();
                   
                    conn.Open();
                    string qrry1 = "select Is_FirstTimeLogin from dbo.ARC_User_Info where UserID=@UserID and Password=@Password";
                    com = new SqlCommand(qrry1, conn);
                    com.Parameters.AddWithValue("@UserID", UserID);
                    com.Parameters.AddWithValue("@Password", ecp.Encrypt(Psd.Trim()));
                    SqlDataReader dr1 = com.ExecuteReader();// this line show the exception....

                    while (dr1.Read())
                    {

                        if (dr1.HasRows == true)
                        {
                            //MessageBox.Show("Login Successfull", "Login Information");
                            foreach (var p in System.Diagnostics.Process.GetProcessesByName("OpenSpan.Runtime"))
                            {
                                p.Kill();
                            }
                            this.Hide();

                            FirsttimeLogin = dr1["Is_FirstTimeLogin"];

                        }
                    }
                    if (dr1.HasRows == false)
                    {
                        MessageBox.Show("User id and password does not match");
                        Flag = 1;
                        Txt_Psd.Text = "";
                    }

                    if (FirsttimeLogin == DBNull.Value)
                    {
                        ChangePassword chpwd = new ChangePassword(Txt_UserID.Text);
                        chpwd.Show();
                    }
                    else
                    {
                        conn.Close();
                        if (UserID == string.Empty)
                        {
                            MessageBox.Show("Please enter a valid UserID!");
                            return;
                        }
                        else if (Psd == string.Empty)
                        {
                            MessageBox.Show("Please enter a valid  Password!");
                            Txt_Psd.Text = "";
                            return;
                        }
                        else
                        {
                            DateTime currDate = DateTime.Now;
                            Hashtable hat = new Hashtable();
                            DataTable dtHolidayCheck = das.Select_Table("select recon from arc_scope_baseline where [Current_Date]='" + currDate.ToString("yyyy/MM/dd") + "'", hat, "Text");

                            if (dtHolidayCheck.Rows.Count < 1)///Changed
                            {
                                MessageBox.Show("Files moving in progress..! Please try later");
                                this.Show();
                            }
                            else
                            {
                                SqlConnection conu = new SqlConnection(conString);
                                conu.Open();
                                com = new SqlCommand("select EndDate from dbo.ARC_User_Info where UserID=@UserID", conu);
                                com.CommandType = CommandType.Text;
                                com.Parameters.AddWithValue("@UserID", UserID);
                                SqlDataReader dr4 = com.ExecuteReader();
                                while (dr4.Read())
                                {
                                    if (dr4.HasRows == true)
                                    {
                                        DateTime LastDate = (DateTime)dr4["EndDate"];
                                        DateTime LastDate1 = LastDate.AddDays(-1);
                                        DateTime LastDate2 = LastDate.AddDays(-2);
                                        DateTime ValidDate = DateTime.Today; ///Changed
                                        if (LastDate == ValidDate || LastDate < ValidDate)
                                        {
                                            this.Hide();
                                            ChangePassword Cp = new ChangePassword(Txt_UserID.Text);
                                            Cp.Show();
                                        }
                                        else
                                        {
                                            conn.Open();
                                            string qry1 = "select UserID,Password,UserRole from dbo.ARC_User_Info where UserID=@UserID and Password=@Password";
                                            com = new SqlCommand(qry1, conn);
                                            com.Parameters.AddWithValue("@UserID", UserID);
                                            com.Parameters.AddWithValue("@Password", ecp.Encrypt(Psd.Trim()));
                                            // com.Parameters.AddWithValue("@Password", Encrypt(Psd.Trim()));
                                            SqlDataReader dr = com.ExecuteReader();// this line show the exception....

                                            while (dr.Read())
                                            {

                                                if (dr.HasRows == true)
                                                {
                                                    //MessageBox.Show("Login Successfull", "Login Information");
                                                    foreach (var p in System.Diagnostics.Process.GetProcessesByName("OpenSpan.Runtime"))
                                                    {
                                                        p.Kill();
                                                    }
                                                    this.Hide();
                                                    string UserRole = (string)dr["UserRole"];
                                                    string cmb = comboBox1.SelectedItem.ToString();
                                                    DataSet ds = new DataSet();
                                                    SqlConnection con = new SqlConnection(conString);
                                                    con.Open();
                                                    SqlCommand cc = new SqlCommand("dbo.ARC_SP_Get_User_Access", con);
                                                    cc.Parameters.AddWithValue("@User_Id", UserID);
                                                    cc.CommandType = CommandType.StoredProcedure;
                                                    SqlDataAdapter da = new SqlDataAdapter(cc);
                                                    da.Fill(ds);

                                                    if (UserRole.Contains(cmb) && ds.Tables[0].Rows[0][0].ToString().Contains(cmb))
                                                    {
                                                        if (cmb.Contains("DataUpload Admin"))
                                                        {
                                                            Main_Admin_DashBoard_New adm = new Main_Admin_DashBoard_New();
                                                            //Main_Admin_DashBoard adm = new Main_Admin_DashBoard();
                                                            adm.Show();
                                                        }
                                                        else if (cmb.Contains("DataUpload User"))
                                                        {
                                                            Dashboard dash = new Dashboard();
                                                            dash.Show();
                                                            System.Diagnostics.Process.Start(@"C:\Program Files (x86)\OpenSpan\OpenSpan Runtime Enterprise\OpenSpan.Runtime.exe");
                                                        }
                                                    }
                                                    else
                                                    {
                                                        MessageBox.Show("User is not Authorized to view this Dashboard");
                                                        ARC_Login_New a = new ARC_Login_New();
                                                        a.Show();
                                                    }
                                                    //else if (UserRole == "DataUpload User")
                                                    //{
                                                    //    Dashboard dash = new Dashboard();
                                                    //    dash.Show();
                                                    //    System.Diagnostics.Process.Start(@"C:\Program Files (x86)\OpenSpan\OpenSpan Runtime Enterprise\OpenSpan.Runtime.exe");
                                                    //    //System.Diagnostics.Process.Start(@"C:\Program Files (x86)\OpenSpan\OpenSpan Studio for Microsoft Visual Studio 2010\Application\OpenSpan.Runtime.exe");
                                                    //}
                                                }
                                            }
                                            if (dr.HasRows == false)
                                            {
                                                if (Flag == 0)
                                                {
                                                    MessageBox.Show("User id and password does not match");
                                                    Txt_Psd.Text = "";
                                                }
                                            }
                                            conn.Close();
                                        }
                                    }
                                }
                                conu.Close();
                            }
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Unauthorized user login");
                    Txt_Psd.Text = "";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }

        private void Btn_Cancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void linkLabel1_LinkClicked_1(object sender, LinkLabelLinkClickedEventArgs e)
        {
            try
            {
                string UserID = Txt_UserID.Text;

                if (Txt_UserID.Text == string.Empty)
                {
                    MessageBox.Show("Please Enter a valid UserID!");
                    return;
                }
                if (Txt_UserID.Text == Environment.UserName)
                {
                    Txt_Psd.Text = "";
                    SqlConnection con = new SqlConnection(conString);
                    con.Open();
                    SqlCommand com = new SqlCommand("select Password from dbo.ARC_User_Info where UserID=@UserID", con);
                    com.CommandType = CommandType.Text;
                    com.Parameters.AddWithValue("@UserID", UserID);
                    SqlDataReader dr = com.ExecuteReader();
                    while (dr.Read())
                    {
                        if (dr.HasRows == true)
                        {
                            string Password = (string)dr["Password"];
                            string Psd = ecp.Decrypt(Password.Trim());
                            Microsoft.Office.Interop.Outlook.Application app = new Microsoft.Office.Interop.Outlook.Application();
                            Microsoft.Office.Interop.Outlook.MailItem mailItem = app.CreateItem(Microsoft.Office.Interop.Outlook.OlItemType.olMailItem);
                            mailItem.Subject = "SCB: Password Reset";
                            mailItem.To = UserID;
                            mailItem.Body = "Dear User.\n \n Your Login Password For ARC Applications is " + Psd + "";
                            mailItem.Importance = Microsoft.Office.Interop.Outlook.OlImportance.olImportanceHigh;
                            mailItem.Send();

                        }
                    }
                    con.Close();
                }
                else
                {
                    MessageBox.Show("Unauthorized user login");
                    Txt_Psd.Text = "";
                }
            }
            catch
            {
                MessageBox.Show("Network Error ! Please Login");
            }
        }

        private void lbl_RstPsd_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            try
            {
                if (Txt_UserID.Text == string.Empty)
                {
                    MessageBox.Show("Please Enter a valid UserID!");
                    return;
                }
                else
                {
                    if (Txt_UserID.Text == Environment.UserName)
                    {
                        this.Hide();
                        ChangePassword cpd = new ChangePassword(Txt_UserID.Text);
                        cpd.Show();
                    }
                    else
                    {
                        MessageBox.Show("Unauthorized user login");
                        Txt_Psd.Text = "";
                    }
                }
            }
            catch
            {

            }
        }

        private void Txt_UserID_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) || Txt_UserID.Text.Length >= 7 && e.KeyChar != 8)// || Txt_UserID.Text.Length == 7)
            {
                e.Handled = true;
                //MessageBox.Show("Please Enter your UserID!");
            }

        }

        private void ARC_Login_New_FormClosed(object sender, FormClosedEventArgs e)
        {
            foreach (var p in System.Diagnostics.Process.GetProcessesByName("OpenSpan.Runtime"))
            {
                p.Kill();
            }

            foreach (var p in System.Diagnostics.Process.GetProcessesByName("ARC_Application"))
            {
                p.Kill();
            }
        }

    }
}
